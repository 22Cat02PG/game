"""Print the canonical hash to bind a job or a draft to its review."""
from pathlib import Path
import argparse
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from nagishima.codec import digest, read_json

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="原稿・依頼の正規化JSONのSHA-256を表示する。")
    parser.add_argument("file")
    parser.add_argument("--key", choices=("job", "draft"))
    args = parser.parse_args()
    value = read_json(args.file)
    print(digest(value[args.key] if args.key else value))
