"""Human CLI, UTF-8 JSONL, batch play, autoplay, and verified replay."""
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import shutil
import sys
import time
from tempfile import TemporaryDirectory
from uuid import uuid4

from .auto_continue import auto_next, auto_speed
from .menus import AUTO_SPEED_LABELS
from .autoplay import next_command, next_social_command, next_presence_command
from .codec import decode
from .engine import Engine
from .errors import GameError, ensure
from .progression import life_day
from .recording import RunLog, fingerprint, runtime_hash
from .session import Session
from . import RULES_VERSION

ROOT = Path(__file__).resolve().parents[1]
REASONS = {"completed": "クリア", "max_turns": "コマンド回数の上限", "quit": "終了コマンド",
           "commands_exhausted": "コマンド列の終わり", "eof": "入力の終わり", "error": "エラー",
           "policy_stalled": "自動プレイヤーの対応経路外", "interrupted": "中断", "cleared": "関係4に到達（生活は続く）"}


def emit(value):
    print(json.dumps(value, ensure_ascii=False, allow_nan=False), flush=True)


def default_log():
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    return ROOT / "runs" / (stamp + "-" + uuid4().hex[:8] + ".jsonl")


def perform(session, log, raw, machine):
    token = session.engine.get_view()["session"]
    response = session.execute_line(raw)
    log.command(raw, token, response)
    if machine:
        emit({"type": "response", **response})
    elif not response["ok"]:
        print("エラー: " + response["error"]["message"])
    return response


PAGE_ONLY = ("menu.main", "menu.previous", "menu.next")


def duration_label(choice, now=None):
    """選択肢に添える所要分。now（009 だけ渡す）があれば、選ぶと眠って翌朝になる選択（休む、夜に終える・引き留めに「今日はここまで」）は、
    分数の代わりに「眠って翌朝」と出す（v8.2.19、試遊「今日はここまで（717分）」）。起きていられるのは翌朝5時までなので、
    所要分で暮らしの日（5:01〜翌5:00）をまたぐ選択は、眠りを挟む。翌朝の時刻は出さない（所要分には、休む前に自動で入る風呂の分が入らないため）。"""
    if not choice["duration"]:
        return ""
    if now is not None and life_day(now + choice["duration"]) > life_day(now):
        return " (眠って翌朝)"
    return f" ({choice['duration']}分)"


def show_choices(view, now=None):
    for index, choice in enumerate(view["choices"], 1):
        unavailable = "" if choice["available"] else "［" + view["explanations"].get(choice["id"], "今は選べない") + "］"
        duration = duration_label(choice, now)
        label = choice["label"]
        if choice["id"].startswith("menu.") and choice["id"] not in PAGE_ONLY and not label.startswith("→"):
            label = "→ " + label  # 一覧を開く項目（v8.2.3、5回目の試運転の指摘1）
        print(f"{index}. {label}{duration}　[{choice['id']}] {unavailable}")
    for warning in view["warnings"]:
        print(warning)


def show_record(record):
    """v8.2.12：二人の記録。"""
    results = {"satisfied": "満たされた", "unsatisfied": "物足りなかった", None: "―"}
    entry = record["by_entry"]
    print(f"エッチ {record['count']}回（部屋で {entry['private']}・誘われて {entry['invite']}・起こして {entry['wake']}）")
    print(f"初めて {record['first']}　最後 {record['last']}（{results[record['last_result']]}）")
    print(f"真帆が達した {record['maho_climaxes']}回　こちらが出した {record['finishes']}回　真帆から（誘い・申し出） {record['maho_led']}回")
    if record["top_acts"]:
        print("よくすること（選んだ回数）：" + "・".join(f"{row['label']}（{row['count']}）" for row in record["top_acts"]))
    if record["top_positions"]:
        print("よくする体位（選んだ回数）：" + "・".join(f"{row['label']}（{row['count']}）" for row in record["top_positions"]))
    if record["recent"]:
        print("最近（新しい順）：" + "　".join(f"{row['date'][5:]} {row['time']} {results[row['result']]}" for row in record["recent"]))
    if record["lewd_label"]:
        print(f"淫乱度 {record['lewdness']}（{record['lewd_label']}）")
    if record["maho_line"]:
        print("\n" + record["maho_line"])


def show(session, narration=True):
    observation = session.observe()
    view, state = observation["view"], observation["state"]
    now = state["world"]["now"] if session.engine.pack.intimacy else None  # 「眠って翌朝」の表示は 009 だけ（v8.2.19）
    if not narration:
        # 一覧を開いただけのとき・選べなかったときは、前の本文をもう一度出さない（v8.2.3、5回目の試運転の指摘1）
        print(f"\n― {view['page_title']} ―")
        if "record" in view:
            show_record(view["record"])
        show_choices(view, now)
        return
    status = view["status"]
    print(f"\n{status['time']}　{status['player_location']}")
    print(status["presence"])
    print(f"関係 {state['relation']['stage']}/4: {status['relationship']}　操作 {session.turns}/{session.max_turns}")
    if "work" in status:
        print(f"仕事 {status['work']}")
    if "bath" in status:
        print(f"風呂 {status['bath']}")
    if "town" in status:
        print(status["town"])  # v8.5.11：店の閉まる時刻
    if "event" in status:
        event = status["event"]  # 段階C（010、v8.5.1）：イベントの様子
        print(f"{event['place']}（あと{event['minutes_left']}分）" + (f"　真帆：{event['drunk']}" if "drunk" in event else "") + (f"　{event['exposure']}" if "exposure" in event else "") + (f"　{event['position']}" if event["position"] else "") + (f"　真帆：{event['maho_sign']}　高まり {event['player_arousal']}" if "maho_sign" in event else ""))
    if "ask" in status:
        ask = status["ask"]  # 段階C（010、v8.5.10）：してもらっている様子
        print(f"{ask['place']}　{ask['kind']}　高まり {ask['player_arousal']}")
    if "sleep" in status:
        sleep = status["sleep"]  # 段階C（010）：寝込みの様子
        print(f"真帆：{sleep['kind']}（{sleep['look']}）" + (f"　{sleep['marks']}" if sleep["marks"] else ""))
        if "wake_bar" in sleep:
            print(f"目覚め {sleep['wake_bar']}　不快 {sleep['discomfort_bar']}　快感 {sleep['pleasure_bar']}")
    if "affinity" in status:
        print(f"親密度 {status['affinity']}　欲求 {status['desire']}" + (f"　淫乱度 {status['lewdness']}" if "lewdness" in status else ""))
    if "stamina" in status:
        print(f"余力 {status['stamina']}")
    if "intimacy" in status:
        intimate = status["intimacy"]
        # v8.2.19（試遊）：体位と真帆の服は上の様子の行（presence）に出ているので、ここでは残り（自分の服）だけを出す
        own = [part for part in intimate["clothing"].split("。") if part and part not in status["presence"]]
        if own:
            print("。".join(own) + "。")
        print(f"主人公 {intimate['player_arousal']}　真帆 {intimate['maho_sign']}　{intimate['night']}　区切り {intimate['deadline']}")
        if status["held_actions"]:
            print("続いている：" + "・".join(status["held_actions"]))  # v8.2.11：追加（玉も・先端も）も見えるように
        if "maho_arousal_bar" in intimate:
            print(f"真帆の高まり {intimate['maho_arousal_bar']}　満足 {intimate['maho_satisfaction_bar']}")
        elif "maho_arousal" in intimate:
            print(f"真帆の高まり {intimate['maho_arousal']}　満足 {intimate['maho_satisfaction']}")
    for block in view["blocks"]:
        print("\n" + block["body"])
    if "record" in view:
        print(f"\n― {view['page_title']} ―")
        show_record(view["record"])
    show_choices(view, now)


def show_auto(session):
    """v8.2.20：自動で続けるあいだは、本文と高まりの行だけを出す（選択肢の一覧は、止まったときに出す）。"""
    view = session.engine.get_view()
    for block in view["blocks"]:
        print("\n" + block["body"])
    intimate = view["status"].get("intimacy")
    if intimate:
        line = f"主人公 {intimate['player_arousal']}　真帆 {intimate['maho_sign']}"
        if "maho_arousal_bar" in intimate:
            line += f"　真帆の高まり {intimate['maho_arousal_bar']}"
        print("（" + line + "）")


def wait_key(milliseconds):
    """v8.2.20：自動で続ける待ち時間。("next", None)＝時間切れか Enter、("stop", 打った行か None)＝ほかの入力、("eof", None)＝入力の終わり。
    Windows はキー1つで判定する（打ったキーは捨てる）。ほかは行で判定し、打った行はそのまま操作として使う。"""
    if os.name == "nt":
        import msvcrt
        end = time.monotonic() + milliseconds / 1000
        while time.monotonic() < end:
            if msvcrt.kbhit():
                key = msvcrt.getwch()
                if key in ("\x00", "\xe0"):
                    msvcrt.getwch()  # 矢印などの2文字目
                return ("next", None) if key in ("\r", "\n") else ("stop", None)
            time.sleep(0.03)
        return "next", None
    import select
    ready, _, _ = select.select([sys.stdin], [], [], milliseconds / 1000)
    if not ready:
        return "next", None
    line = sys.stdin.readline()
    if line == "":
        return "eof", None
    line = line.strip()
    return ("next", None) if not line else ("stop", line)


AUTO_HELP = ("自動で続ける：動く・してもらうなどを続けると、数秒おきに同じ行為を自動で続ける。Enter で次へ、ほかのキーで止める。『自動』と打つと入・切。"
             "速さ（ゆっくり・ふつう・はやい・切）は、エッチの前に設定の画面で選ぶ。")


def human_command(line, view):
    words = line.strip().split()
    if not words:
        return {"command": "view"}  # 空行は画面をもう一度（v8.2.7、精査 E-02）
    if len(words) == 1 and words[0].isdigit():
        index = int(words[0]) - 1
        if 0 <= index < len(view["choices"]):
            return {"command": "choose", "id": view["choices"][index]["id"]}
        return {"command": "choose", "id": "invalid.number"}
    verb = words[0]
    if verb in ("終了", "q", "quit") and len(words) == 1:
        return {"command": "quit"}
    if verb in ("保存", "読込", "戻す", "save", "load") and len(words) in (1, 2):
        slot = words[1] if len(words) == 2 else "slot01"
        if slot.isdigit():
            slot = f"slot{int(slot):02d}"
        command = {"command": "save" if verb in ("保存", "save") else "load", "slot": slot}
        if verb == "戻す":
            command["backup"] = True
        return command
    if verb == "自動読込" and len(words) == 2:
        return {"command": "load", "slot": "auto" + words[1]}
    if verb in ("状態", "state", "view", "行動", "actions", "slots", "diagnostics") and len(words) == 1:
        return {"command": {"状態": "state", "行動": "actions"}.get(verb, verb)}
    if verb == "choose" and len(words) == 2:
        return {"command": "choose", "id": words[1]}
    if verb in ("チート", "cheat") and len(words) == 2:
        return {"command": "cheat", "action": {"接触解放": "contact_unlock", "全開放": "all"}.get(words[1], words[1])}
    if verb in ("原稿更新", "adopt") and len(words) == 2:
        return {"command": "adopt", "release": words[1]}
    if len(words) == 1:
        return {"command": "choose", "id": verb}
    return {"command": "choose", "id": "invalid.input"}  # 打ち間違いは「表示している操作から選ぶ」（v8.2.7、精査 E-02）


# v8.2.19（試遊）：「全開放」は名前から全部が開くように読めるので、009 では変わること・変わらないことを添える
CHEAT_ALL_NOTE = ("全開放で変わるのは、関係（恋人段階）・気分（上限）・親密度（足りなければ恋人の節目の値まで）だけ。エッチの回数（慣れ）・行為ごとの経験・淫乱度は変わらない。"
                  "慣れは `チート intimacy_tier:few`（数回）・`チート intimacy_tier:familiar`（慣れ）で設定する。")


def cheat_lines(session):
    lines = ["テストチート: `チート 全開放` で恋人段階と気分を引き上げる / `チート 接触解放` で接触条件のみ解除",
             "段階B: `チート intimacy_tier:first` / `チート intimacy_tier:few` / `チート intimacy_tier:familiar` で慣れを設定",
             "段階B: `チート lewdness:60` で淫乱度を設定（エッチを1回以上してから。0〜100）"]
    if session.engine.pack.intimacy:
        lines.insert(1, "段階B: " + CHEAT_ALL_NOTE)
    return lines


def interactive(session, log):
    print("凪島のふたり暮らし — テキスト試作版")
    print("目標: 真帆と『これからも共に暮らす』ことを選ぶ（関係4）。")
    print("番号 / choose 操作ID / 保存 1 / 読込 1 / 状態 / 行動 / help / 終了")
    print("文章の版: " + session.engine.active_release)
    if session.test_cheats:
        for line in cheat_lines(session):
            print(line)
    print("まず『話す → 好きな飲み物の話』と『一緒に過ごす → お茶』を試す。")
    auto_rules = session.engine.pack.intimacy.auto if session.engine.pack.intimacy else None
    auto_enabled = bool(auto_rules)  # v8.2.20：009 は既定で自動で続ける
    if auto_rules:
        print(AUTO_HELP)
    print("ログ: " + str(log.path))
    narration = True
    shown = None
    pending = None  # v8.2.20：(自動で選ぶ操作ID, 待つミリ秒)
    auto_run = 0  # 続けて自動で進んだ手の数
    while session.reason is None:
        blocks = [(b["variant"], b["body"]) for b in session.engine.get_view()["blocks"]]
        line = None
        if pending:
            show_auto(session)
            shown = blocks
            # v8.2.28（ユーザー 2026-09-30）：案内は毎手出す（1手目だけだと、止め方に気づかない）
            print("（自動で続ける・" + AUTO_SPEED_LABELS[auto_speed(session.engine.pack, session.engine.snapshot())] + "　Enter で次へ／ほかのキーで止める）")
            auto_run += 1
            outcome, typed = wait_key(pending[1])
            if outcome == "eof":
                session.finish("eof")
                break
            if outcome == "next":
                line = "choose " + pending[0]
            else:
                print("（自動を止めた）")
                auto_run = 0
                line = typed
                if line is None:
                    show(session, False)
            pending = None
        else:
            auto_run = 0
            # 本文の出ない選択（設定・やめる・状態・保存など）では、前の本文をもう一度出さない（v8.2.7、精査 C-23・A-11・E-01）
            show(session, narration and blocks != shown)
            shown = blocks
        if line is None:
            try:
                line = input("選択 > ").strip()
            except EOFError:
                session.finish("eof")
                break
        if auto_rules and line in ("自動", "auto"):
            speed = auto_speed(session.engine.pack, session.engine.snapshot())
            if speed == "off":
                print("自動で続ける：設定で「切」になっている（速さは、エッチの前に設定の画面で選ぶ）")  # v8.2.28
            else:
                auto_enabled = not auto_enabled
                print("自動で続ける：" + ("入（" + AUTO_SPEED_LABELS[speed] + "）" if auto_enabled else "切"))
            narration = False
            continue
        if line in ("help", "ヘルプ", "?"):
            print("表示中の番号か [操作ID] を入力。条件不足の理由は選択肢に表示される。")
            print("会話、共同活動、約束を通じて関係の節目が開く。習慣は別々の日に重ねる。")
            print("操作上限は起動時の --max-turns で変更できる。保存・読込でも残り回数は戻らない。")
            if session.test_cheats and session.engine.pack.intimacy:
                for text in cheat_lines(session):  # v8.2.19：009 では、ヘルプにもテストチートの中身を出す
                    print(text)
            if auto_rules:
                speed = auto_speed(session.engine.pack, session.engine.snapshot())
                print(AUTO_HELP + "（今は" + ("入・" + AUTO_SPEED_LABELS[speed] if auto_enabled and speed != "off" else "切") + "）")
            line = "view"
        request = None if line.startswith("{") else human_command(line, session.engine.get_view())
        raw = line if request is None else json.dumps(request, ensure_ascii=False)
        response = perform(session, log, raw, False)
        chosen = request.get("id", "") if request and request.get("command") == "choose" else ""
        narration = response["ok"] and not chosen.startswith("menu.")
        if auto_enabled and response["ok"] and chosen.startswith("touch.") and session.reason is None:
            observation = session.observe()
            wait = auto_next(session.engine.pack, observation["state"], observation["view"], chosen)
            pending = (chosen, wait) if wait is not None else None
        if response["ok"] and line in ("状態", "state", "slots", "diagnostics"):
            result = response["result"]
            rules = session.engine.pack.progression
            if line in ("状態", "state") and rules is not None and not rules.display and not session.test_cheats:
                result = {key: value for key, value in result.items() if key not in ("affinity", "desire")}
            if line in ("状態", "state") and session.engine.pack.intimacy is not None and result.get("settings", {}).get("gauges") == "hidden" and not session.test_cheats:
                # ゲージ表示が hidden のときは、真帆の高まり・満足も隠す（v8.0.5、監査 C-06）。
                result = dict(result)
                if result.get("intimacy"):
                    result["intimacy"] = {key: value for key, value in result["intimacy"].items() if key != "maho"}
            print(json.dumps(result, ensure_ascii=False, indent=2))
        elif response["ok"] and request and request.get("command") == "cheat":
            if response["result"]["action"] == "all":
                print("全開放チートを適用しました。関係は恋人段階、気分は上限です。部屋へ行けます。近さや姿勢などの条件は通常どおりです。")
                if session.engine.pack.intimacy:
                    print(CHEAT_ALL_NOTE)
            elif response["result"]["action"] == "lewdness":
                print("淫乱度を " + str(response["result"]["value"]) + " に設定しました。")
            elif response["result"]["action"] == "intimacy_tier":
                print("エッチの慣れを " + response["result"]["tier"] + " に設定しました。")
            else:
                print("接触解放チートを有効にしました。接触の段階条件だけを解除します。")


def stream_play(session, log, lines, exhausted):
    if session.reason is not None:
        return
    for raw in lines:
        response = perform(session, log, raw.rstrip("\r\n"), True)
        if not response["ok"] and exhausted == "commands_exhausted":
            session.finish("error")
            break
        if session.reason is not None:
            break
    if session.reason is None:
        session.finish(exhausted)


def autoplay(session, log, policy=next_command):
    while session.reason is None:
        if session.cleared:
            session.finish("cleared")
            break
        command = policy(session.engine.get_view(), session.engine.snapshot())
        if command is None:
            session.finish("policy_stalled")
            break
        if not perform(session, log, json.dumps(command, ensure_ascii=False), True)["ok"]:
            session.finish("error")
            break


def replay(args):
    path = Path(args.replay).resolve()
    with path.open(encoding="utf-8-sig") as source:
        header = decode(source.readline())
        ensure(type(header) is dict and header.get("type") == "start" and header.get("format") == 1,
               "replay_format", "対応する実行ログではない。")
        if header.get("rules_version") != RULES_VERSION and (header.get("rules_version") is not None or header.get("runtime_sha256") != runtime_hash()):
            emit({"type": "summary", "ok": False, "error": {"code": "rules_version_mismatch", "message": "ログと本体のルール版が異なるため、同一結果として再生できない。"}, "run": {"ended": True, "reason": "rules_version_mismatch", "completed": False}})
            return 3
        ensure(header.get("checkpoint") == path.name + ".initial", "replay_checkpoint", "開始時データの参照が違う。")
        initial = path.parent / header["checkpoint"] / "data"
        ensure(initial.is_dir(), "replay_checkpoint", "ログと一緒に .initial フォルダーを保管する。")
        config = header["config"]
        with TemporaryDirectory(prefix="nagishima-replay-") as temporary:
            data = Path(temporary) / "data"
            shutil.copytree(initial, data)
            engine = Engine(data, config["seed"], config["name"], config["release"], autosave=config["autosave"], test_cheats=config.get("test_cheats", False), opening=config.get("opening", False))
            if config["load"]:
                engine.load(config["load"])
            session = Session(engine, config["max_turns"], test_cheats=config.get("test_cheats", False))
            log = RunLog(args.log or default_log(), data, config, engine.pack.hash)
            extra = {"replay_verified": False, "runtime_matches": header["runtime_sha256"] == runtime_hash(),
                     "release_matches": header["release_sha256"] == engine.pack.hash}
            verified_end = False
            try:
                for raw_record in source:
                    record = decode(raw_record)
                    ensure(type(record) is dict, "replay_format", "ログレコードはJSONオブジェクトで指定する。")
                    if record.get("type") == "command":
                        raw = record["input"]
                        if record.get("rebind_session"):
                            request = decode(raw)
                            request["session"] = engine.get_view()["session"]
                            raw = json.dumps(request, ensure_ascii=False)
                        response = perform(session, log, raw, True)
                        if fingerprint(response) != record["sha256"]:
                            extra["mismatch_turn"] = session.turns
                            extra["expected_sha256"] = record["sha256"]
                            extra["actual_sha256"] = fingerprint(response)
                            session.finish("error")
                            break
                    elif record.get("type") == "end":
                        if session.reason is None:
                            session.finish(record["run"]["reason"])
                        extra["replay_verified"] = fingerprint(session.observe()) == record["sha256"]
                        verified_end = True
                        break
                    else:
                        raise GameError("replay_format", "未登録のログレコード。")
                if not verified_end and "mismatch_turn" not in extra:
                    extra["error"] = "incomplete_log"
                    session.finish("error")
                observation = session.observe()
                log.end(observation, **extra)
                emit({"type": "summary", "ok": extra["replay_verified"], **observation, **extra, "log": str(log.path)})
                return 0 if extra["replay_verified"] else 3
            finally:
                log.close()


class Parser(argparse.ArgumentParser):
    def error(self, message):
        raise GameError("arguments", message)


def main(argv=None):
    for stream in (sys.stdin, sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")
    argv = sys.argv[1:] if argv is None else argv
    machine = any(v in ("--json", "--batch", "--autoplay", "--autoplay-social", "--autoplay-presence", "--replay") or v.startswith(("--batch=", "--replay=")) for v in argv)
    parser = Parser(description="凪島のテキスト試作版。標準ライブラリのみ・外部通信なし。")
    modes = parser.add_mutually_exclusive_group()
    modes.add_argument("--json", action="store_true", help="UTF-8 JSON Linesで操作")
    modes.add_argument("--batch", metavar="PATH", help="JSONLコマンド列を一括実行")
    modes.add_argument("--autoplay", action="store_true", help="同梱の自動プレイヤーで実行")
    modes.add_argument("--autoplay-social", action="store_true", help="真帆の提案を受け入れる生活寄りの自動プレイヤーで実行")
    modes.add_argument("--autoplay-presence", action="store_true", help="会話・反復・触れ合い・真帆からの返答を通る自動プレイヤーで実行")
    modes.add_argument("--replay", metavar="LOG", help="ログを再生し全応答を比較")
    parser.add_argument("--data-dir", default=str(ROOT / "userdata"))
    parser.add_argument("--seed", type=int, default=20380407)
    parser.add_argument("--name", default="悠")
    parser.add_argument("--release", default="interaction_009")  # v8.3.0：009 を確定し、新規開始の既定に（それまでは 008）
    parser.add_argument("--load")
    parser.add_argument("--no-autosave", action="store_true")
    parser.add_argument("--max-turns", type=int, default=200)
    parser.add_argument("--test-cheats", action="store_true", help="テスト専用のcheatコマンドを許可")
    parser.add_argument("--log", help="ログ出力先。省略時runs/に新規作成")
    log = None
    session = None
    try:
        args = parser.parse_args(argv)
        if args.replay:
            return replay(args)
        ensure(1 <= args.max_turns <= 100000, "max_turns", "max-turnsは1〜100000。")
        opening = not args.load  # v8.5.11：新しく始めたときは導入から（導入のある版だけ）
        engine = Engine(args.data_dir, args.seed, args.name, args.release, autosave=not args.no_autosave, test_cheats=args.test_cheats, opening=opening)
        if args.load:
            engine.load(args.load)
        config = {"seed": args.seed, "name": args.name, "release": args.release, "load": args.load,
                  "autosave": not args.no_autosave, "max_turns": args.max_turns, "test_cheats": args.test_cheats, "opening": opening}
        session = Session(engine, args.max_turns, test_cheats=args.test_cheats)
        log = RunLog(args.log or default_log(), args.data_dir, config, engine.pack.hash)
        try:
            if args.json:
                stream_play(session, log, sys.stdin, "eof")
            elif args.batch:
                with Path(args.batch).open(encoding="utf-8-sig") as lines:
                    stream_play(session, log, lines, "commands_exhausted")
            elif args.autoplay or args.autoplay_social or args.autoplay_presence:
                policy = next_presence_command if args.autoplay_presence else next_social_command if args.autoplay_social else next_command
                autoplay(session, log, policy)
            else:
                interactive(session, log)
        except KeyboardInterrupt:
            session.finish("interrupted")
        observation = session.observe()
        log.end(observation)
        ok = session.reason not in ("error", "policy_stalled")
        if machine:
            emit({"type": "summary", "ok": ok, **observation, "log": str(log.path)})
        else:
            if observation["run"]["completed"]:
                for block in observation["view"]["blocks"]:
                    print("\n" + block["body"])
                print("\n" + observation["run"]["ending"])
            print(f"終了: {REASONS[session.reason]}（{session.turns}操作）。ログ: {log.path}")
        return 0 if ok else 1
    except (GameError, OSError, KeyError, TypeError, ValueError) as error:
        failure = {"code": getattr(error, "code", "io_error" if isinstance(error, OSError) else "invalid_input"), "message": str(error)}
        observation = session.finish("error") if session else {"run": {"ended": True, "reason": "startup_error", "completed": False}}
        if log:
            try:
                log.end(observation, error=failure)
            except OSError:
                pass
        if machine:
            emit({"type": "summary", "ok": False, "error": failure, **observation})
        else:
            print(failure["message"], file=sys.stderr)
        return 2
    finally:
        if log:
            log.close()


if __name__ == "__main__":
    sys.exit(main())
