"""v8.3.0（ユーザー 2026-10-02 13:09「確定して」）：段階B の原稿版 009 を確定し、新規開始の既定にする。
次の版 010 は、009 の保存から通常時に切り替えられる（010 を作ったとき用の準備）。"""
import contextlib
import io
import json
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from nagishima.__main__ import main
from nagishima.codec import bytes_digest, digest
from nagishima.engine import Engine
from nagishima.errors import GameError
from tools.build_intimacy_release import PUBLISHED

ROOT = Path(__file__).resolve().parents[1]
RELEASES = ROOT / "content/releases"


def next_release(data):
    """009 の写しで、版の名前を 010 にし、決まりを1つ変えた版（物足りないときの欲求の足し 50→40）を保存先の releases に置く。
    決まりが変わると、本文だけの版と違って、これまでは切り替えられなかった（010 への切り替えの確かめ用）。"""
    # v8.3.1：本物の 010 があるので、本物と混ざらない別の置き場（builtin）に 009 と、決まりを変えた 010 を置く
    shutil.copytree(RELEASES / "interaction_009", Path(data) / "builtin" / "interaction_009")
    target = Path(data) / "builtin" / "interaction_010"
    shutil.copytree(RELEASES / "interaction_009", target)
    intimacy = json.loads((target / "intimacy.json").read_text(encoding="utf-8"))
    intimacy["desire_after"]["unsatisfied_add"] = 40
    (target / "intimacy.json").write_text(json.dumps(intimacy, ensure_ascii=False), encoding="utf-8")
    manifest = json.loads((target / "release.json").read_text(encoding="utf-8"))
    manifest["id"] = "interaction_010"
    manifest["files"]["intimacy.json"] = bytes_digest((target / "intimacy.json").read_bytes())
    control = {"catalog": json.loads((target / "catalog.json").read_text(encoding="utf-8")), "actions": json.loads((target / "actions.json").read_text(encoding="utf-8"))}
    for name, field in (("progression.json", "progression"), ("life.json", "life"), ("intimacy.json", "intimacy")):
        control[field] = json.loads((target / name).read_text(encoding="utf-8"))
    manifest["control_sha256"] = digest(control)
    (target / "release.json").write_text(json.dumps(manifest, ensure_ascii=False), encoding="utf-8")


class V830(unittest.TestCase):
    def temp(self):
        temp = tempfile.TemporaryDirectory(prefix="nagishima-v830-")
        self.addCleanup(temp.cleanup)
        return temp.name

    # ---- 009 は確定済み：作り直さない。別の場所に作れば同じ ----
    def test_009_confirmed(self):
        self.assertIn("interaction_009", PUBLISHED)
        self.assertNotIn("interaction_010", PUBLISHED)
        refused = subprocess.run([sys.executable, str(ROOT / "tools/build_intimacy_release.py"), "--replace-unpublished"], cwd=ROOT, capture_output=True, text=True)
        self.assertNotEqual(refused.returncode, 0)
        self.assertIn("--verify", refused.stdout + refused.stderr)
        self.assertFalse((ROOT / ".rebuild_verify").exists())

    # ---- 009 のファイルは、記録した検査値のまま ----
    def test_009_in_goldens(self):
        goldens = json.loads((ROOT / "verification/stage_b_legacy_goldens.json").read_text(encoding="utf-8"))
        files = {k for k in goldens["published_files"] if k.startswith("interaction_009/")}
        self.assertEqual(files, {"interaction_009/" + p.name for p in (RELEASES / "interaction_009").iterdir() if p.is_file()})
        self.assertTrue(any(k.startswith("interaction_009/") for k in goldens["autoplay"]))

    # ---- 新規開始の既定は 009 ----
    def test_default_release(self):
        data = self.temp()
        buffer = io.StringIO()
        with mock.patch("builtins.input", side_effect=[EOFError]), contextlib.redirect_stdout(buffer):
            main(["--no-autosave", "--data-dir", data + "/data", "--log", data + "/run.jsonl"])
        self.assertIn("文章の版: interaction_009", buffer.getvalue())

    # ---- 009 の保存は、通常時に 010 へ切り替えられ、保存・読込もできる。二人の時間の最中は切り替えない ----
    def test_switch_to_next(self):
        data = self.temp()
        next_release(data)
        builtin = Path(data) / "builtin"
        engine = Engine(data, seed=830, release="interaction_009", builtin=builtin, autosave=False, test_cheats=True)
        engine.enable_test_cheat("all")
        engine.save("slot01")
        self.assertNotEqual(engine.repository.get("interaction_010").control_hash, engine.pack.control_hash)  # 決まりが違う版
        view = engine.adopt_release("interaction_010")
        self.assertEqual(engine.pack.intimacy.raw["desire_after"]["unsatisfied_add"], 40)
        self.assertEqual(engine.active_release, "interaction_010")
        self.assertEqual(view["release"], "interaction_010")
        engine.save("slot02")
        other = Engine(data, seed=1, release="interaction_009", builtin=builtin, autosave=False, test_cheats=True)
        self.assertEqual(other.load("slot02")["release"], "interaction_010")
        self.assertEqual(other.load("slot01")["release"], "interaction_009")
        # 二人の時間の最中は切り替えない
        engine = Engine(data, seed=831, release="interaction_009", builtin=builtin, autosave=False, test_cheats=True)
        engine.enable_test_cheat("all")
        view = engine.get_view()
        engine.choose("private.begin", view["revision"], view["session"])
        with self.assertRaises(GameError):
            engine.adopt_release("interaction_010")


if __name__ == "__main__":
    unittest.main()
