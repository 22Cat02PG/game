"""v8.5.7（ユーザー 2026-10-08「進めろ。次があるだろ」）：010 だけ。段階C 八歩目：主人公のうたた寝と、真帆の襲い返し（仕様 第5.3節）。"""
import unittest
from pathlib import Path

from nagishima.content import Pack
from tools.run_stage_b_routes import Route

ROOT = Path(__file__).resolve().parents[1]
P009 = Pack(ROOT / "content/releases/interaction_009")
P010 = Pack(ROOT / "content/releases/interaction_010")


def living_route(affinity=80, desire=30, hour=19, minute=40):
    route = Route(8, hour=hour, minute=minute, tier="familiar", release="interaction_010")
    state = route.engine._state
    state["affinity"]["value"], state["desire"] = affinity, desire
    route.engine._install_choices()
    return route


def meanings(view):
    return [b["meaning"] for b in view["blocks"]]


def ids(view):
    return [c["id"] for c in view["choices"]]


class V857(unittest.TestCase):
    def test_rules(self):
        self.assertIsNone(P009.intimacy.nap)
        rules = P010.intimacy.nap
        self.assertEqual((rules.minutes, rules.pull_desire), (20, 10))
        self.assertEqual(rules.pull, {"kiss", "lean", "cheek"})
        for meaning in rules.meanings():
            self.assertIn(meaning, P010.meanings)

    def test_window(self):
        """居間で、17:00〜23:30 だけ。"""
        route = living_route(hour=16, minute=30)
        self.assertNotIn("nap", ids(route.engine.get_view()))
        route.close()
        route = living_route()
        self.assertIn("nap", ids(route.engine.get_view()))
        route.close()

    def test_kiss_and_pull(self):
        """恋人で欲求が高ければ、唇に口づけていた。すぐあとなら引き寄せられる（欲求 +10）。その日はもう眠れない。"""
        route = living_route(desire=70)
        before = route.engine.snapshot()["world"]["now"]
        view = route.choose("nap")
        self.assertIn("nap.kiss", meanings(view))
        self.assertEqual(route.engine.snapshot()["world"]["now"], before + 20)
        self.assertTrue({"nap.pull", "nap.ignore"} <= set(ids(view)))
        self.assertNotIn("nap", ids(view))
        view = route.choose("nap.pull")
        self.assertEqual(meanings(view)[-1], "nap.pull.kiss")
        self.assertEqual(route.engine.snapshot()["desire"], 80)
        self.assertNotIn("nap.pull", ids(view))
        self.assertNotIn("nap", ids(view))
        route.close()

    def test_lean_cheek_and_ignore(self):
        """欲求が低ければ、もたれる（親密度 60 以上）か頬に口づける。気づかないふりもできる。時間が進むと選べなくなる。"""
        route = living_route(desire=0)
        view = route.choose("nap")
        self.assertIn("nap.lean", meanings(view))
        view = route.choose("nap.ignore")
        self.assertEqual(meanings(view)[-1], "nap.ignore.lean")
        route.close()
        route = living_route(affinity=40, desire=0)
        self.assertIn("nap.cheek", meanings(route.choose("nap")))
        view = route.choose("wait.30")
        self.assertNotIn("nap.pull", ids(view))
        route.close()

    def test_not_lover_blanket(self):
        """恋人になる前は、毛布をかけてくれる（引き寄せる・気づかないふりは出ない）。"""
        import tempfile
        from nagishima.engine import Engine
        with tempfile.TemporaryDirectory(prefix="nagishima-v857-") as temp:
            engine = Engine(temp, seed=8, release="interaction_010", autosave=False)
            state = engine._state
            now = state["world"]["now"] // 1440 * 1440 + 19 * 60 + 40
            state["world"].update(now=now, processed_until=now)
            for actor in state["actors"].values():
                actor["location"] = "living_room"
            engine._install_choices()
            view = engine.get_view()
            if "nap" not in ids(view):
                self.skipTest("この日の真帆は居間にいない")
            view = engine.choose("nap", view["revision"], view["session"])
            self.assertIn("nap.blanket", meanings(view))
            self.assertNotIn("nap.pull", ids(view))


if __name__ == "__main__":
    unittest.main()
