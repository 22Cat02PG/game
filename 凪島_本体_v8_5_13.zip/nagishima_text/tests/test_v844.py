"""v8.4.4（ユーザー 2026-10-06 14:17「進めていい」＝v8.4.3 の提案）：010 だけ。
前後の本文の流れ：直前の本文の仕草（目をそらす・目を細める・頬が赤くなる など）と同じ仕草を書いた本文、
前の本文の終わりの状態と食い違う「〜たまま」の本文を、ほかに本文がある限り後回しにする（settings.flow、nagishima/flow.py）。"""
import random
import unittest
from copy import deepcopy
from pathlib import Path

from nagishima.conditions import evaluate
from nagishima.content import Pack
from tools.run_stage_b_routes import Route

ROOT = Path(__file__).resolve().parents[1]
P009 = Pack(ROOT / "content/releases/interaction_009")
P010 = Pack(ROOT / "content/releases/interaction_010")


def fake(identity, body):
    return {"id": identity, "body": body}


class V844(unittest.TestCase):
    def test_009_unchanged(self):
        self.assertIsNone(P009.intimacy.flow)
        self.assertIsNotNone(P010.intimacy.flow)
        self.assertNotIn("flow", P009.intimacy.settings)

    def test_score(self):
        flow = P010.intimacy.flow
        away = fake("t.away", "真帆は小さく笑って、視線をそっと外した。")
        to = fake("t.to", "真帆はこちらを見つめたまま、唇をほどいた。")
        blush = fake("t.blush", "頬を赤く染めて、こちらへ身を寄せる。")
        plain = fake("t.plain", "指先が、こちらの手のひらに重なった。")
        self.assertEqual(flow.score([away], plain), 0)
        self.assertGreater(flow.score([away], to), flow.score([blush], to))  # 目をそらして終わった直後の「見つめたまま」は食い違い
        self.assertEqual(flow.score([blush], fake("t.blush2", "耳まで赤くなった。")), flow.weights["last"])
        self.assertEqual(flow.score([plain, blush], fake("t.blush3", "耳まで赤くなった。")), flow.weights["earlier"])
        back = fake("t.back", "目が合うと、真帆はすぐに視線をそらした。")  # 最後はそらしている
        self.assertEqual(flow.score([back], to) - len(flow.info(to)[0] & flow.info(back)[0]) * flow.weights["last"], flow.weights["contradict"])
        again = fake("t.again", "一度視線をそらしてから、またこちらを見つめた。")  # 最後は見ている
        self.assertEqual(flow.score([again], to) - len(flow.info(to)[0] & flow.info(again)[0]) * flow.weights["last"], 0)

    def test_follow(self):
        """せがんだ直後に照れる・笑う本文、達しかけた直後に笑う本文は、調子が飛ぶ。"""
        flow = P010.intimacy.flow
        urge = fake("t.urge", "「ねえ、もっと……待てない」")
        shy = fake("t.shy", "真帆は恥ずかしそうに身を縮めた。")
        calm = fake("t.calm", "指先が、こちらの手のひらに重なった。")
        self.assertEqual(flow.score([urge], shy), flow.weights["follow"])
        self.assertEqual(flow.score([urge], calm), 0)
        self.assertEqual(flow.score([fake("t.over", "声にならない息が詰まる。")], fake("t.laugh", "くすっと笑った。")), flow.weights["follow"])

    def test_select_prefers_flow(self):
        """直前の本文の仕草と重ならない本文を選ぶ（流れを見ないときより点が大きくならず、小さくなる場面がある）。"""
        route = Route(8441, tier="familiar", release="interaction_010", hour=21, day_offset=2)
        self.addCleanup(route.close)
        route.begin()
        for _ in range(3):
            while route.engine.snapshot()["offer"]:
                route.choose("offer.decline")
            route.action("h_kiss_deep")
        state = route.engine.snapshot()
        flow = P010.intimacy.flow
        rng = random.Random(844)
        tagged = [t for t in P010.by_text.values() if not t["fallback"] and flow.info(t)[0] and t["meaning"].startswith(("h_", "h."))]
        values = P010.registry.values(state)
        meanings = [m for m in ("h_kiss_deep.continue", "h_kiss_deep.settled", "h_check.start", "h_feel.start", "h_ear_neck.start", "h_hug.start")
                    if sum(1 for t in P010.by_meaning.get(m, ()) if not t["fallback"] and not t["slots"] and evaluate(t["when"], values) is True) > 3]
        lower, compared = 0, 0
        for meaning in meanings:
            for prev in rng.sample(tagged, 25):
                base = deepcopy(state)
                base["recent_text"] = base["recent_text"][-10:] + [{"id": prev["id"], "group": prev["group"], "release": "interaction_010"}]
                try:
                    on = P010.select(meaning, deepcopy(base), {}, values)[0]["variant"]
                    saved, P010.intimacy.flow = P010.intimacy.flow, None
                    try:
                        off = P010.select(meaning, deepcopy(base), {}, values)[0]["variant"]
                    finally:
                        P010.intimacy.flow = saved
                except Exception:
                    continue
                score_on, score_off = flow.score([prev], P010.by_text[on]), flow.score([prev], P010.by_text[off])
                self.assertLessEqual(score_on, score_off, (meaning, prev["id"], on, off))
                compared += 1
                lower += score_on < score_off
        self.assertGreater(compared, 50)
        self.assertGreater(lower, 0)


if __name__ == "__main__":
    unittest.main()
