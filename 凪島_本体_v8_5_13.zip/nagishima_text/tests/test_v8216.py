"""v8.2.16：深い口づけが続いているあいだは、真帆の台詞のある本文を出さない（v8.2.14 の依頼の点検 G-5 の残り、ユーザー了承 2026-09-28 21:13）。
口づけは指で触れる・素股・動く行為などでは途切れない。これまでの本文には、口づけの有無を条件にしていない台詞の本文がある。"""
import unittest

from tools.run_stage_b_routes import Route


def blocks(engine):
    return engine.get_view()["blocks"]


class V8216(unittest.TestCase):
    def route(self, *args, **kwargs):
        route = Route(*args, **kwargs)
        self.addCleanup(route.close)
        return route

    def main(self, route):
        while route.engine.snapshot()["offer"]:
            route.choose("offer.decline")
        if route.engine.get_view()["page"] != "main":
            route.choose("menu.main")

    def ready(self, seed, kiss):
        route = self.route(seed, tier="familiar", day_offset=2)
        route.begin()
        for key in ("h_strip_lower", "h_shift_under", "h_pos_lying_face"):
            route.action(key)
        route.engine._state["intimacy"]["maho"].update(arousal=60, band="mid")  # 準備：秘所に触れられるところまで
        route.engine._install_choices()
        self.main(route)
        if kiss:
            route.action("h_kiss_deep")
            self.main(route)
        return route

    def touch_bodies(self, kiss, seeds):
        found = []
        for seed in seeds:
            route = self.ready(seed, kiss)
            for _ in range(3):
                route.action("h_touch_direct")
                self.main(route)
                active = [c["action_id"] for c in route.engine.snapshot()["contacts"]]
                self.assertEqual("h_kiss_deep" in active, kiss)  # 口づけは指で触れても途切れない
                found += [b for b in blocks(route.engine) if b["meaning"].startswith("h_touch_direct")]
        return found

    def test_no_speech_while_kissing(self):
        texts = self.touch_bodies(True, range(1601, 1611))
        self.assertTrue(texts)
        for block in texts:
            self.assertNotIn("「", block["body"], block["variant"])

    def test_speech_texts_exist_without_kiss(self):
        # 口づけしていなければ、同じ場面で台詞のある本文も出る（上の試験が、台詞のない本文しかない場面を見ているのではないこと）
        texts = self.touch_bodies(False, range(1601, 1611))
        self.assertTrue(any("「" in block["body"] for block in texts))


    def test_no_fallback_when_only_spoken_texts_while_kissing(self):
        # v8.2.19：口づけしたまま初めて太ももを撫でると、台詞つきの本文しかなく、仮の本文「（太ももを撫でる）」が出ていた（GPT の試遊）
        for seed in range(1611, 1616):
            route = self.route(seed, tier="first", day_offset=2)
            route.begin()
            route.action("h_kiss_deep")
            self.main(route)
            route.action("h_thigh")
            self.assertIn("h_kiss_deep", [c["action_id"] for c in route.engine.snapshot()["contacts"]])
            found = [b for b in blocks(route.engine) if b["meaning"].startswith("h_thigh.")]
            self.assertTrue(found)
            for block in found:
                self.assertFalse(block["variant"].endswith(".base"), block)


if __name__ == "__main__":
    unittest.main()
