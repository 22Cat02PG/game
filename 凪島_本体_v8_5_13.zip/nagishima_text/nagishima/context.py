from copy import deepcopy

from .conditions import evaluate, typed, latest_memory
from .errors import ensure, GameError
from .scenes import Scenes
from .life import Life
from .director import Director
from .intimacy import Intimacy
from .sleep_play import SleepPlay
from .event_play import EventPlay
from .co_sleep import CoSleep
from .nap import Nap
from .ask import Ask
from .island import Island
from .progression import gain_affinity, change_desire
from .labels import END_LABELS


# v8.2.30：触れ合いの終わりの一言の種類（先にあるものほど優先）
CONTACT_END_GROUPS = (("lap_give", ("lap_pillow",)), ("lap_take", ("lap_pillow_take",)), ("hug", ("hug", "back_hug", "waist")), ("kiss", ("deep_kiss", "ear_kiss")))


class Context(Island, Ask, Nap, CoSleep, EventPlay, SleepPlay, Intimacy, Scenes, Life, Director):
    """One isolated semantic transaction. This object never writes files."""

    def __init__(self, state, pack, repository, old_frame, test_cheat_intimacy=False):
        self.s, self.pack, self.repo, self.old_frame = state, pack, repository, old_frame
        self.test_cheat_intimacy = bool(test_cheat_intimacy)
        self.events = []
        self.restore_frame = None
        self.preserve_question = False
        self.finished_scenes = []
        self.closed_scene = None
        self.allow_offer = False
        self.pending_private = False
        self.auto_minutes = 0

    def finalize(self):
        if self.pending_private:
            self.pending_private = False
            ensure(self.s["scene"] is None, "transition", "二人の時間への遷移は場面の終了時に行う。")
            self.begin_private()
        if self.s.get("sleep_play") or self.s.get("event_play") or self.s.get("co_sleep") or self.s.get("ask_play"):
            return  # 段階C（010）：寝込み・イベント・添い寝・してもらっている（v8.5.10）最中は、真帆の眠り・自動の仕事・食事・風呂を進めない
        if self.pack.life and self.pack.life.town:
            self.town_closing()  # 段階C（010、v8.5.11）：店の中で閉まる時刻を迎えたら、家へ戻る
        self.maho_routine()
        if self.pack.intimacy:
            self.auto_work()
            self.auto_lunch()  # v8.5.11：休日の昼の支度
            self.auto_dinner()
            self.auto_bath()

    @property
    def now(self):
        return self.s["world"]["now"]

    def new_id(self, prefix):
        identity = f"{prefix}.{self.s['world']['next_instance']}"
        self.s["world"]["next_instance"] += 1
        return identity

    def values(self):
        return self.pack.registry.values(self.s, self.s["scene"]["locals"] if self.s["scene"] else None)

    def emit(self, meaning, release=None):
        if self.pack.intimacy and self.s.get("intimacy") and meaning.startswith("h."):
            # v8.2.10：顔面騎乗・シックスナインのあいだの合図・達する・締め切りなどは、その向きの本文（meaning.<向き>）があればそれを出す
            facing = self.pack.intimacy.facing(self.s)
            if facing in ("face_sit", "sixty_nine") and meaning + "." + facing in self.pack.meanings:
                meaning = meaning + "." + facing
        bindings = {"player_name": self.s["actors"]["player"]["name"], "location": self.pack.catalog["locations"][self.s["actors"]["player"]["location"]]["label"]}
        if self.pack.intimacy:
            bindings.update(self.s["settings"]["terms"])
            outer = self.pack.intimacy.settings.get("outer_terms")
            action_key = meaning.partition(".")[0]
            for suffix in ("_fast", "_slow"):
                if action_key.endswith(suffix) and action_key[:-len(suffix)] in self.pack.intimacy.actions:
                    action_key = action_key[:-len(suffix)]  # v8.2.34：速さの本文（h_sumata_fast など）も、もとの行為として外側の語を使う
            if outer and (action_key in outer["actions"] or (action_key in outer.get("actions_not_inserted", ()) and not (self.s.get("intimacy") or {}).get("inserted"))):
                # v8.2.31（Opus の確かめ）：下着の上から・太もも・入り口をこする・下着を脱がせる本文の {vagina} は外側の語（「膣」→「秘所」）
                # v8.2.32（確かめ役 5）：胸・耳首筋・頭を撫でる本文も、入れていないときは外側の語（入れているときの「膣が締まる」はそのまま）
                bindings["vagina"] = outer["vagina"].get(bindings["vagina"], bindings["vagina"])
        remembered = latest_memory(self.s, "tea")
        if remembered:
            bindings["memory_place"] = self.pack.catalog["locations"][remembered["location"]]["label"]
        if self.s["scene"]:
            remembered_scene = next((m for m in self.s["scene"]["memories"] if m["kind"] == "tea"), None)
            if remembered_scene: bindings["scene_memory_place"] = self.pack.catalog["locations"][remembered_scene["location"]]["label"]
        chosen = self.s["facts"].get("shared.place", {}).get("value")
        if chosen:
            bindings["chosen_place"] = {"window": "窓辺", "table": "テーブル"}[chosen]
        self.events.append({"meaning": meaning, "release": release or self.pack.id, "bindings": bindings, "values": self.pack.registry.values(self.s)})

    def fact_set(self, identity, value):
        ensure(identity in self.pack.catalog["facts"], "fact", "事実が未登録。")
        typed(value, self.pack.catalog["facts"][identity]["spec"])
        old = self.s["facts"][identity]
        if type(old["value"]) is not type(value) or old["value"] != value:
            self.s["facts"][identity] = {"id": identity, "value": deepcopy(value), "revision": old["revision"] + 1, "source_event": f"operation.{self.s['world']['operation_seq']}", "created_at": self.now}

    def learn(self, actor, identity):
        ensure(actor in self.s["knowledge"] and identity in self.s["facts"] and self.s["facts"][identity]["value"] is not None, "knowledge", "伝えられる事実がない。")
        self.s["knowledge"][actor][identity] = {"snapshot": deepcopy(self.s["facts"][identity]), "learned_at": self.now}

    def remember(self, kind, facts=(), summary=None):
        ensure(kind in self.pack.catalog["memory_kinds"], "memory", "記憶の種類が未登録。")
        spec = self.pack.catalog["memory_specs"][kind]
        ensure(len(facts) == len(set(facts)) and set(facts) <= set(spec["facts"]), "memory", "記憶に残す事実が登録と一致しない。")
        summary = summary or {}
        ensure(type(summary) is dict and summary.keys() <= spec["summary"].keys(), "memory", "記憶の要約項目が未登録。")
        for key, value in summary.items(): typed(value, spec["summary"][key])
        ensure(all(key in self.s["facts"] and self.s["facts"][key]["value"] is not None for key in facts), "memory", "記憶に使う事実がない。")
        memory = {"id": self.new_id("memory"), "kind": kind, "at": self.now, "participants": ["player", "maho"], "location": self.s["actors"]["player"]["location"], "facts": [deepcopy(self.s["facts"][key]) for key in facts], "choice_summary": deepcopy(summary or {})}
        self.s["memories"]["recent"].append(memory)
        self.s["memories"]["recent"] = self.s["memories"]["recent"][-256:]
        entry = self.s["memories"]["summaries"].setdefault(kind, {"count": 0, "first": deepcopy(memory), "last": deepcopy(memory)})
        entry["count"] += 1
        entry["last"] = deepcopy(memory)
        return memory

    def capture_memory(self, kind):
        ensure(self.s["scene"] is not None, "memory", "記憶の控えを使う場面がない。")
        memory = latest_memory(self.s, kind)
        ensure(memory is not None, "memory", "この種類の思い出がまだない。")
        snapshots = [m for m in self.s["scene"]["memories"] if m["kind"] != kind]
        ensure(len(snapshots) < 8, "memory", "一場面の記憶の控えは8件まで。")
        self.s["scene"]["memories"] = snapshots + [deepcopy(memory)]

    def approach(self):
        self.require_awake()
        ensure(self.values()["together"], "location", "二人が同じ場所にいる必要がある。")
        ensure(self.s["distance"] != "near", "already_near", "真帆はもう、すぐそばにいる。")
        if self.pack.intimacy and self.pack.intimacy.sleep_play and self.sleep_guarded():
            self.charge_minutes("talk")
            self.emit("sp.guard.distance")  # 段階C（010）：好感度が低いうちに寝込みで見つかったあとの警戒の間は、距離をとられる
            return
        self.s["distance"] = "near"
        self.emit("system.approach")

    def action_side(self, identity, side):
        """v8.4.0（010、ユーザー 2026-10-06「てをつなぐを右手左手両手で選べるように」）：暮らしで、真帆のどちらの手を取るかを選んで手をつなぐ（始める・続ける・持ち替える）。"""
        daily = self.pack.intimacy.daily_sides.get(identity) if self.pack.intimacy else None
        ensure(daily is not None and side in daily["choices"], "action", "手を選べない。")
        self._daily_side = side
        try:
            return self.action(identity)
        finally:
            self._daily_side = None

    def action(self, identity, origin="player", lifetime="persistent", emit_text=True):
        ensure(identity in self.pack.actions and origin in ("player", "maho"), "action", "動作または開始者が未登録。")
        action = self.pack.actions[identity]
        self.require_awake()
        ensure(self.test_cheat_intimacy or self.s["relation"]["stage"] >= action["min_stage"], "relationship", "この距離で触れ合う関係には、まだ進んでいない。")
        ensure(not action["near"] or self.s["distance"] == "near", "distance", "先に近くへ寄る。")
        ensure(all(self.s["actors"][actor]["posture"] in action["postures"] for actor in ("player", "maho")), "posture", "今の姿勢ではできない。")
        active = next((x for x in self.s["contacts"] if x["action_id"] == identity), None)
        daily = self.pack.intimacy.daily_sides.get(identity) if self.pack.intimacy else None
        side = (getattr(self, "_daily_side", None) or daily["default"]) if daily else None  # v8.4.0（010）：手をつなぐ側
        if not active and self.pack.intimacy and identity in self.pack.intimacy.b2["gate"]["hints"] and evaluate(action["when"], self.values()) is not True:
            raise GameError("action_conditions", self.pack.intimacy.b2["gate"]["hints"][identity])  # B2：何をすれば選べるか
        ensure(evaluate(action["maintain"] if active else action["when"], self.values()) is True, "action_conditions", "この動作の条件が整っていない。")
        if active and daily and active.get("side", daily["default"]) != side:
            # v8.4.0（010）：つないでいる手を持ち替える（<行為>.side_<左右> の本文。なければ続ける本文）
            if origin == "player": self.charge_minutes("continue")
            self.s["interaction_streak"] = None
            active["side"] = side
            active["continues"] += 1
            switch = identity + "." + daily["switch_meaning"].format(side=side)
            if emit_text: self.emit(switch if switch in self.pack.meanings and self.pack.has_authored(switch, self.pack.registry.values(self.s)) else identity + ".continue")
            return "continue"
        if active:
            if origin == "player": self.charge_minutes("continue")
            self.s["interaction_streak"] = None
            active["continues"] += 1
            self.s["mood"]["ease"] = min(2, self.s["mood"]["ease"] + 1)
            if self.pack.progression and identity in self.pack.progression.touch_actions:
                change_desire(self.s, self.pack.progression, self.bath_desire(self.pack.progression.desire_touch_continue))
            phase = "settled" if active["continues"] >= 3 else "continue"
            if emit_text: self.emit(identity + "." + phase)
            return phase
        conflicts = [x for x in self.s["contacts"] if set(x["resources"]) & set(action["resources"])]
        blocked = [x["action_id"] for x in conflicts if x["action_id"] not in action["replaces"]]
        if blocked and self.pack.intimacy:
            # 009：何を続けていてふさがっているか、どうやめるかを出す（v8.0.8、試運転の指摘）。
            names, ends = [], []
            for key in blocked:
                if key in self.pack.intimacy.actions:
                    row = self.pack.intimacy.actions[key]
                    names.append(row["label"]); ends.append(row.get("end_label", row["label"] + "をやめる"))
                else:
                    names.append(self.pack.actions[key]["label"]); ends.append(END_LABELS.get(key, self.pack.actions[key]["label"] + "のをやめる"))
            raise GameError("resources", "「" + "」「".join(names) + "」を続けていて、手や姿勢がふさがっている。先に「" + "」「".join(ends) + "」を選ぶ。")
        ensure(all(x["action_id"] in action["replaces"] for x in conflicts), "resources", "手や姿勢がふさがっている。先に動作を終える。")
        ensure(lifetime in ("persistent", "scene", "private"), "owner", "動作の保持範囲が違う。")
        owner = None
        if lifetime == "scene":
            ensure(self.s["scene"] is not None, "owner", "動作を所有する話がない。")
            owner = self.s["scene"]["id"]
        elif lifetime == "private":
            ensure(self.s["private_instance"] is not None, "owner", "二人の時間が始まっていない。")
            owner = self.s["private_instance"]
        if origin == "player" and self.pack.progression:
            self.charge_minutes("talk" if identity in self.pack.progression.talk_actions else "touch")
        self.s["contacts"] = [x for x in self.s["contacts"] if x not in conflicts]
        if conflicts and self.pack.intimacy and self.pack.intimacy.release:
            self.contact_released([x["action_id"] for x in conflicts], identity)  # v8.4.5（010）
        experience = self.s["experience"][identity]
        previous = self.s["interaction_streak"]
        streak_count = (min(previous["count"] + 1, 2147483647)
                        if origin == "player" and previous and previous["action_id"] == identity else 1)
        self.s["interaction_streak"] = {"action_id": identity, "count": streak_count} if origin == "player" else None
        # v8.2.25（精査 A-1・C-01）：同じ体験とみなす行動（頼んで上になってもらう／真帆が申し出て上に乗る）のどれかをしていれば、初めてにしない
        same = self.pack.intimacy.same_first.get(identity, ()) if self.pack.intimacy else ()
        if experience["count"] == 0 and not any(self.s["experience"][other]["count"] for other in same):
            phase = "first"
        elif streak_count >= 3 and origin == "player" and identity + ".heated" in self.pack.meanings:
            phase = "heated"
        elif streak_count >= 2 and origin == "player" and identity + ".repeat" in self.pack.meanings:
            phase = "repeat"
        else:
            phase = "start"
        if experience["first_at"] is None:
            experience["first_at"] = self.now
        experience["last_at"] = self.now
        experience["count"] += 1
        experience["by_origin"][origin] += 1
        rules = self.pack.progression
        if rules:
            if origin == "player" and identity in rules.talk_actions:
                gain_affinity(self.s, rules, "talk")
                change_desire(self.s, rules, self.bath_desire(rules.desire_talk.get(identity, 0)))
            if identity in rules.touch_actions:
                if origin == "player": gain_affinity(self.s, rules, "touch")
                change_desire(self.s, rules, self.bath_desire(rules.desire_touch_start.get(identity, 0)))
        if action["ongoing"]:
            self.s["contacts"].append({"id": self.new_id("contact"), "action_id": identity, "origin": origin, "lifetime": lifetime, "owner_id": owner, "resources": list(action["resources"]), "started_at": self.now, "continues": 0,
                                       **({"side": side} if daily else {})})  # v8.4.0（010）：手をつなぐ側
        affectionate = {"affection", "compliment", "together_words", "reassurance", "kiss", "forehead", "hug", "waist"}
        gentle = {"head", "hair", "cheek", "shoulder", "arm", "back", "hands", "gratitude"}
        conversational = {"talk", "check_mood", "share_day"}
        self.s["mood"]["joy"] = min(2, self.s["mood"]["joy"] + 1)
        if identity in affectionate:
            self.s["mood"]["shy"] = min(2, self.s["mood"]["shy"] + 1)
        if identity in gentle:
            self.s["mood"]["ease"] = min(2, self.s["mood"]["ease"] + 1)
        if identity in conversational:
            self.s["mood"]["interest"] = min(2, self.s["mood"]["interest"] + 1)
        maho_meaning = identity + ".maho"
        if emit_text and origin == "maho" and self.pack.intimacy and maho_meaning in self.pack.meanings and self.pack.has_authored(maho_meaning, self.pack.registry.values(self.s)):
            # v8.2.25（精査 B-09）：真帆の申し出（手をつなぎたい・私からキスしたい・私から抱きしめたい）を受けたときは、真帆からする本文
            self.emit(maho_meaning)
        elif emit_text:
            text_phase = phase
            if phase == "first" and self.pack.intimacy:
                # 009：初めての本文が今の条件に合わないとき（慣れた回の深める触れ合いなど）は、始めの本文にする（B2 仕様 第4節。検査役G2 L-4）
                values = self.pack.registry.values(self.s)
                if not self.pack.has_authored(identity + ".first", values) and self.pack.has_authored(identity + ".start", values):
                    text_phase = "start"
            self.emit(identity + "." + text_phase)
        if emit_text and self.pack.intimacy and phase in ("first", "start") and identity in self.pack.intimacy.b2["gate"]["touches"] and self.s["mode"] == "normal" and not self.s["scene"] and not self.s["offer"]:
            self.gate_react(identity)  # B2：いつもの触れ合いから深めたときの真帆の反応
        if identity == "affection" and not self.s["scene"] and self.s["mode"] == "normal" and self.s["distance"] == "near" and any(x["action_id"] in ("head", "hands", "hug") for x in self.s["contacts"]):
            private_minutes = self.pack.catalog["activities"]["private_time"]["minutes"]
            # 009：仕事の前で二人の時間を取れないときは、自動で始めず、誘いも開かない（監査 D-07・D-08）。
            # v8.2.1（別係 L-03）：仕事の go_ahead 分（1時間）前からは、自動で始めず誘いも出さない（v8.1.0 の Director.boundary と同じ）
            fits_work = not self.pack.intimacy or self.minutes_to_work(max(private_minutes, self.pack.life.go_ahead)) is None
            if self.s["actors"]["player"]["location"] in ("player_room", "maho_room") and len(self.s["activities"]) < 4 and self.now + private_minutes <= self.s["world"]["awake_deadline"] and fits_work:
                self.begin_private()
            elif fits_work and self.can_offer("private") and (not self.pack.intimacy or self.offer_works({"op": "private.begin"})):
                self.open_offer("private", "private", "private.begin", "offer.decline")
        if origin == "player" and streak_count >= 2 and not self.s["scene"] and not self.s["offer"] and self.s["mode"] == "normal" and self.s["relation"]["stage"] >= 3 and not self.at_work():
            kind = "kiss_back" if identity == "kiss" else "reciprocal_hug" if identity in {"affection", "compliment", "together_words", "reassurance"} else None
            if kind in self.pack.catalog["offers"] and self.can_offer(kind):
                preview = type(self)(deepcopy(self.s), self.pack, self.repo, self.old_frame, self.test_cheat_intimacy)
                try:
                    preview.apply(preview.offer_plan(kind))
                    preview.finalize()
                except GameError:
                    pass
                else:
                    self.open_offer(kind, kind)
        return phase

    def charge_minutes(self, kind):
        """009：いつもの時間の話す・触れる・様子を見るは、少し時間が進む（v8.0.5、試運転の指摘2）。

        所要分は life.json の actions.minutes（009 だけにある）。場面や二人の時間の中では、その活動の時間に含まれるので進めない。
        仕事の時間に入ったら選べない。仕事の始まりと、起きていられる限界の手前で止める。
        """
        rules = self.pack.life
        minutes = rules.action_minutes.get(kind, 0) if rules else 0
        if not minutes or self.s["scene"] or self.s["mode"] != "normal":
            return
        limit = self.minutes_to_work(minutes)
        ensure(limit != 0, "work_time", "仕事の時間だ。「仕事に戻る」で仕事へ向かう。")
        minutes = min(minutes, minutes if limit is None else limit, max(0, self.s["world"]["awake_deadline"] - self.now))
        if minutes:
            self.advance(minutes)

    def offer_works(self, plan):
        preview = type(self)(deepcopy(self.s), self.pack, self.repo, self.old_frame, self.test_cheat_intimacy)
        try:
            preview.apply(plan)
            preview.finalize()
        except GameError:
            return False
        return True

    def end_action(self, identity):
        ensure(any(x["action_id"] == identity for x in self.s["contacts"]), "contact", "この動作はすでに終わっている。")
        self.s["contacts"] = [x for x in self.s["contacts"] if x["action_id"] != identity]
        self.contact_ended([identity])

    def contact_released(self, ended, identity):
        """v8.4.5（010）：手をつなぐ・抱きしめる・腕を引くを、別の触れ合いに入れ替えて（または服を脱ぐなどで）終えたとき、ほどく一言（system.contact_released.<組>）を、
        次の行動の本文の前に出す（これまでは黙って終わり、つないだ手をほどく書き方がないまま次の本文が出ていた）。同じ仲間の組どうしの入れ替え（片手 → 両手 など）では出さない。"""
        release = self.pack.intimacy.release
        new_family = release["family"].get(release["of"].get(identity))
        for group in release["order"]:
            if any(release["of"].get(key) == group for key in ended):
                if new_family is not None and release["family"][group] == new_family:
                    return
                meaning = "system.contact_released." + group
                if meaning in self.pack.meanings:
                    self.emit(meaning)
                return

    def contact_ended(self, ended):
        """v8.2.30（通し確かめ 15）：触れ合いの終わりの一言を、終えた触れ合いの種類で分ける（膝枕・抱擁でも「手を離した」だった）。
        いちばん大きな触れ合い（膝枕 → 抱擁 → 口づけ → 手）の本文。書いた本文がなければ、これまでの一言。"""
        for group, keys in CONTACT_END_GROUPS:
            meaning = "system.contact_ended." + group
            if any(key in keys for key in ended) and meaning in self.pack.meanings:
                self.emit(meaning)
                return
        self.emit("system.contact_ended")

    def close_owned(self, lifetime, owner):
        self.s["contacts"] = [x for x in self.s["contacts"] if not (x["lifetime"] == lifetime and x["owner_id"] == owner)]

    def story_complete(self, identity):
        ensure(identity in self.pack.catalog["stories"], "story", "話題が未登録。")
        field = self.pack.catalog["stories"][identity]["fact"]
        if self.s["facts"][field]["value"] is not True:
            self.fact_set(field, True)
            self.learn("player", field)
            self.learn("maho", field)
            self.s["progress"]["personal_stories"] += 1
            gain_affinity(self.s, self.pack.progression, "story_completed")
            self.remember("story", [field])

    def apply(self, plan):
        op = plan["op"]
        if op not in ("action", "settings.set"):  # 表示の設定を変えても、同じ行動の繰り返しは切らない（v8.0.5、監査 C-10）
            self.s["interaction_streak"] = None
        if op == "intimacy.action":
            self.intimacy_action(plan["id"], plan.get("origin", "player"))
        elif op == "intimacy.stop": self.intimacy_stop(plan["id"])
        elif op == "intimacy.pace": self.intimacy_pace(plan["id"], plan["pace"])
        elif op == "intimacy.side": self.intimacy_side(plan["id"], plan["side"])  # v8.2.29：胸に触れる左右
        elif op == "intimacy.end": self.intimacy_end()
        elif op == "intimacy.entry": self.intimacy_entry(plan["id"])
        elif op == "intimacy.self_entry": self.intimacy_self_entry()  # 段階C（010、v8.5.8）
        elif op == "settings.set": self.intimacy_setting(plan["name"], plan["value"])
        elif op == "action":
            self.action(plan["id"], plan.get("origin", "player"), plan.get("lifetime", "persistent"))
        elif op == "action.end": self.end_action(plan["id"])
        elif op == "action.side": self.action_side(plan["id"], plan["side"])  # v8.4.0（010）：手をつなぐ左右
        elif op == "approach": self.approach()
        elif op == "move": self.move(plan["location"], plan.get("together", False), plan.get("private_invitation", False))
        elif op == "prepare": self.prepare(plan["actor"], plan["outfit"], plan["hair"])
        elif op == "posture": self.posture(plan["value"])
        elif op == "scene.begin": self.begin_scene(plan["id"])
        elif op == "scene.choose": self.choose_scene(plan["id"])
        elif op == "scene.pause": self.pause_scene()
        elif op == "scene.resume": self.resume_scene(plan["id"])
        elif op == "scene.cancel": self.cancel_scene(plan.get("id"))
        elif op == "local.set": self.local_set(plan["name"], plan["value"])
        elif op == "local.inc": self.local_set(plan["name"], plan["value"], True)
        elif op == "fact.set": self.fact_set(plan["id"], plan["value"])
        elif op == "fact.learn": self.learn(plan["actor"], plan["id"])
        elif op == "story.complete": self.story_complete(plan["id"])
        elif op == "memory.record": self.remember(plan["kind"], plan.get("facts", []), plan.get("summary"))
        elif op == "memory.capture": self.capture_memory(plan["kind"])
        elif op == "anniversary.celebrate": self.celebrate(plan["kind"])
        elif op == "memory.pin": self.pin_memory(plan["id"], plan.get("pin", True))
        elif op == "reminisce":
            self.require_awake()
            ensure(self.values()["together"], "location", "同じ場所で思い出を話す。")
            ensure(latest_memory(self.s, "tea") is not None, "memory", "一緒にお茶をした思い出がまだない。")
            remember = self.pack.scenes.get("remember_tea") if self.pack.intimacy else None
            if remember and evaluate(remember["requires"], self.values()) is not True:
                raise GameError("memory", self.requires_reason(remember["requires"]))  # v8.2.25（精査 B-12）：お茶の思い出の話と同じ条件
            self.emit("memory.tea")
        elif op == "activity.begin": self.begin_activity(plan["kind"], plan.get("promise_id"))
        elif op == "activity.complete": self.complete_activity(plan["id"])
        elif op == "private.begin": self.begin_private()
        elif op == "private.end": self.end_private()
        elif op == "promise.create": self.create_promise(plan["kind"])
        elif op == "promise.postpone": self.postpone_promise(plan["id"])
        elif op == "promise.cancel": self.cancel_promise(plan["id"])
        elif op == "order.create": self.create_order(plan["kind"], plan.get("quantity", 1))
        elif op == "order.receive": self.receive_order(plan["id"])
        elif op == "order.cancel": self.cancel_order(plan["id"])
        elif op == "item.give": self.give_item(plan["id"])
        elif op == "project.plan": self.plan_project()
        elif op == "project.order": self.order_project()
        elif op == "project.install": self.install_project()
        elif op == "project.finish": self.finish_project()
        elif op == "project.cancel": self.cancel_project()
        elif op == "relation.commit": self.commit_relation(plan["stage"])
        elif op == "offer.accept": self.accept_offer()
        elif op == "offer.decline": self.decline_offer()
        elif op == "inbox.read": self.read_message(plan["id"])
        elif op == "sleep": self.sleep()
        elif op == "bath.invite": self.bath_invite()
        elif op == "wait":
            self.free()
            minutes = plan["minutes"]
            if self.pack.intimacy:
                # 009：待つのは仕事の始まりまで（そのまま仕事へ行く）。続けていた触れ合いは終える（v8.0.8、試運転の指摘）。
                limit = self.minutes_to_work(minutes)
                if limit is not None:
                    minutes = limit
                if self.pack.life and self.pack.life.town:
                    # v8.5.11：店の中で待つのは、閉まる時刻まで（閉まったら家へ戻る）
                    from .island import town_place
                    from .progression import day_time
                    row = town_place(self.s, self.pack)
                    if row is not None:
                        minutes = min(minutes, max(0, row["close"] - day_time(self.now)))
                if self.s["contacts"]:
                    ended = [c["action_id"] for c in self.s["contacts"]]
                    self.s["contacts"] = []
                    self.contact_ended(ended)
            self.advance(minutes, protect=False)
            self.emit("system.waited")
        elif op == "work.go": self.go_work()
        elif op == "trip.begin": self.begin_trip()
        elif op == "trip.advance": self.advance_trip(plan["phase"])
        elif op == "idle":
            self.require_awake()
            if self.pack.intimacy:
                ensure(self.values()["together"], "location", "真帆と同じ場所にいるときに選ぶ。")
            self.charge_minutes("listen")
            self.emit("system.listen")
            self.allow_offer = True
        elif op == "maho.wake": self.wake_maho()
        elif op == "sleep.begin": self.sleep_begin()  # 段階C（010、v8.5.0）：寝込み
        elif op == "sleep.visit": self.sleep_visit()
        elif op == "sleep.act": self.sleep_act(plan["id"])
        elif op == "sleep.leave": self.sleep_leave()
        elif op == "sleep.apologize": self.sleep_apologize()
        elif op == "event.invite": self.event_invite(plan["kind"])  # v8.5.3：晩酌に誘う
        elif op == "event.act": self.event_act(plan["id"])  # 段階C（010、v8.5.1）：イベントのエッチ（浴室）
        elif op == "event.leave": self.event_leave()
        elif op == "event.offer": self.event_offer(plan["accept"])
        elif op == "event.position": self.event_position(plan["id"])
        elif op == "event.next": self.event_next()
        elif op == "event.insert": self.event_insert()
        elif op == "event.move": self.event_move(plan["pace"])
        elif op == "event.touch": self.event_touch(plan["id"])
        elif op == "event.finish": self.event_finish(plan["where"])
        elif op == "nap": self.nap()  # v8.5.7：主人公のうたた寝
        elif op == "nap.answer": self.nap_answer(plan["pull"])
        elif op == "cosleep.invite": self.cosleep_invite()  # v8.5.6：添い寝
        elif op == "cosleep.talk": self.cosleep_talk()
        elif op == "cosleep.close_eyes": self.cosleep_close_eyes()
        elif op == "cosleep.look": self.cosleep_look()
        elif op == "event.hush": self.event_hush()  # v8.5.4：人目（野外）
        elif op == "event.hide": self.event_hide(plan["how"])
        elif op == "ask.show": self.ask_show()  # v8.5.10：頼む
        elif op == "ask.serve": self.ask_serve(plan["kind"])
        elif op == "ask.next": self.ask_next()
        elif op == "ask.finish": self.ask_finish()
        elif op == "ask.stop": self.ask_stop()
        elif op == "shop.order": self.shop_order(plan["kind"])  # v8.5.11：島の町の売店で取り寄せを頼む
        elif op == "fish.book": self.fish_book()  # v8.5.11：真帆の手帳の図鑑
        else: raise GameError("unknown_operation", "操作が未登録。")
