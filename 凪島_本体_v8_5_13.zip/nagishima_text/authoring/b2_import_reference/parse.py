import json, re, glob, collections, os
base='/home/claude/work/b2'
jobs={}
for w in (1,2,3):
    for j in json.load(open(f'{base}/grok_b2_wave_{w}.json',encoding='utf-8')): jobs[j['id']]=j
pool=collections.defaultdict(list); problems=[]; seen_ids=set()
for f in sorted(glob.glob('raw/*.txt')):
    t=open(f,encoding='utf-8').read()
    # extract JSON arrays; tolerate multiple arrays (続けて)
    rows=[]
    for m in re.finditer(r'\{\s*"id"\s*:\s*"(p[123]\.[^"]+)"\s*,\s*"job_id"\s*:\s*"(p[123]\.[^"]+)"\s*,\s*"body"\s*:\s*"((?:[^"\\]|\\.)*)"\s*\}', t, re.S):
        rows.append((m.group(1), m.group(2), json.loads('"'+m.group(3)+'"')))
    n_obj=len(re.findall(r'"job_id"', t))
    if n_obj!=len(rows): problems.append((f,'parse',n_obj,len(rows)))
    for tid,jid,body in rows:
        if jid == 'p1.h_check.start.few_familiar.back.s':  # grok が band_low の id を「back」と書いた（中身は落ち着いている様子。Opus 確認）
            jid = 'p1.h_check.start.few_familiar.back_band_low.s'; tid = jid + tid[tid.rindex('.v'):]
        if jid not in jobs: problems.append((f,'unknown job',jid)); continue
        if not tid.startswith(jid+'.v'): problems.append((f,'id mismatch',tid,jid))
        if tid in seen_ids: problems.append((f,'dup',tid)); continue
        seen_ids.add(tid)
        pool[jid].append({"id":tid,"job_id":jid,"body":body,"file":os.path.basename(f)})
missing=[j for j in jobs if j not in pool]
njobs=len(pool)
short=[(j,len(pool[j]),jobs[j]['candidates']) for j in jobs if 0<len(pool[j])<jobs[j]['candidates']]
over=[(j,len(pool[j]),jobs[j]['candidates']) for j in jobs if len(pool[j])>jobs[j]['candidates']]
print('texts',sum(len(v) for v in pool.values()),'jobs with texts',njobs,'of',len(jobs))
print('missing jobs',len(missing),missing[:10]); print('short',short[:10]); print('over',over[:5]); print('problems',problems[:10])
json.dump(pool, open('pool.json','w',encoding='utf-8'), ensure_ascii=False, indent=1)
