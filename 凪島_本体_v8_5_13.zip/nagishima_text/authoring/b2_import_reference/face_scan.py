"""背を向けた体位（後ろから・背を向けて乗る）の本文で、振り返りなしに顔の細部を書く文を探す（別係 T1-01・T2-01）。"""
import json, re, sys
texts = json.load(open("b2_texts.json", encoding="utf-8"))
FACE = re.compile(r"睫毛|まつげ|瞼|まぶた|目を|目が|目元|目尻|目の|眉|唇|口元|口角|頬|頰|笑み|瞳|視線|表情|瞬き|まばたき|涙|顔")
OK = re.compile(r"振り返|振り向|肩越し|横顔|横を向|首をひね|顔をこちらへ|こちらを向")
MINE = re.compile(r"こちらの(唇|顔|頬|頰|目|視線)|陰唇|唇を(当て|寄せ|押し当て|這わせ)|うなじに唇")
def split(body):
    return [s for s in re.split(r"(?<=[。！？」])", body) if s]
def targets(pattern):
    out = {}
    for t in texts:
        if re.search(pattern, t["job_id"]):
            hits = []
            for s in split(t["body"]):
                s2 = MINE.sub("", s)
                if FACE.search(s2) and not OK.search(t["body"]):
                    hits.append(s)
            if hits:
                out[t["id"]] = {"job_id": t["job_id"], "body": t["body"], "hits": hits}
    return out
if __name__ == "__main__":
    groups = {"from_behind": r"^p1\..*from_behind", "reverse_ride": r"^p3\..*reverse_ride", "side_lying": r"^p1\..*side_lying"}
    res = {k: targets(v) for k, v in groups.items()}
    for k, v in res.items():
        print(k, len(v), sum(1 for t in texts if re.search(groups[k], t["job_id"])))
    json.dump(res, open("face_targets.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
