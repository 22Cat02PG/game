"""Validated, release-local Stage B declarations."""
import re

from . import clock
from .codec import exact, identifier
from .errors import GameError, ensure
from .flow import Flow
from .progression import parse_time, day_time

RESIDENCE = frozenset({"living_room", "kitchen", "player_room", "maho_room"})  # 住まいの中の移動は5分（life.py の move と同じ）
CATEGORIES = ("position", "kiss", "caress", "undress", "insert", "move", "finish", "after", "words", "maho_lead", "service", "self", "tease", "grind", "mutual")  # tease：入り口をこすって焦らす（v8.2.8）
LEWD_BANDS = ("shy", "open", "eager", "bold")  # v8.2.12：淫乱度の段
PACES = ("slow", "normal", "fast")  # v8.2.13：続けている行為の速さ
LED_ON_TOP = ("h_lead_straddle", "h_lead_takein")  # v8.2.25（指摘 R1）：真帆が自分から上になる・入れる申し出（「動きは任せて」）
FINISH_ACTIONS = frozenset({"h_finish_inside", "h_finish_outside", "h_finish_hand", "h_finish_mouth", "h_finish_sumata", "h_finish_breasts", "h_finish_feet", "h_finish_sixty_nine"})


def check(value, keys, optional=()):
    try:
        exact(value, keys, optional)
    except (GameError, TypeError) as error:
        raise GameError("intimacy_data", "intimacy.json の項目が不足または未登録。") from error


def number(value, low, high):
    ensure(type(value) is int and low <= value <= high, "intimacy_data", "intimacy.json の数値が範囲外。")
    return value


def time(value):
    try:
        return parse_time(value)
    except GameError as error:
        raise GameError("intimacy_data", "intimacy.json の時刻が不正。") from error


def ids(values, allowed):
    ensure(type(values) is list and all(type(x) is str for x in values) and len(values) == len(set(values)) and set(values) <= set(allowed), "intimacy_data", "intimacy.json の参照が不正。")



FINISH_OUTCOMES = ("climax", "near", "high", "rest")  # v8.4.7（010）：中に出す手の真帆の結果

class IntimacyRules:
    def __init__(self, raw, catalog, actions):
        check(raw, ["format", "session", "nights", "maho", "player", "hold_back", "desire_after", "invite", "lead", "clothing", "deflect", "positions", "actions", "settings", "b2"], ["sleep_play", "events", "co_sleep", "nap", "self_entry", "ask"])
        ensure(raw["format"] == "nagishima.intimacy/1", "intimacy_data", "intimacy.json の形式名が不正。")
        self.raw = raw
        # 段階C（010、v8.5.0）：眠っている真帆に触れる（寝込み）・夜這い。節がない版（009）では None
        from .sleep_rules import SleepRules
        self.sleep_play = SleepRules(raw["sleep_play"], catalog) if "sleep_play" in raw else None
        # 段階C（010、v8.5.1）：たまに起きるイベントのエッチ（浴室）。節がない版では None
        from .event_rules import EventRules
        self.events = EventRules(raw["events"]) if "events" in raw else None
        # 段階C（010、v8.5.6）：添い寝。節がない版では None
        from .co_sleep import CoSleepRules
        self.co_sleep = CoSleepRules(raw["co_sleep"]) if "co_sleep" in raw else None
        # 段階C（010、v8.5.7）：主人公のうたた寝。節がない版では None
        from .nap import NapRules
        self.nap = NapRules(raw["nap"]) if "nap" in raw else None
        # 段階C（010、v8.5.10）：頼む（見せて・手と口でしてもらう）。節がない版では None
        from .ask import AskRules
        self.ask = AskRules(raw["ask"]) if "ask" in raw else None
        # 段階C（010、v8.5.8）：二人の時間（エッチの前）に自分で高める（仕様 第10節）。label・decline_when（真帆が困って話をそらす条件）・decline_desire（そのときの欲求の変化）
        self.self_entry = None
        if "self_entry" in raw:
            check(raw["self_entry"], ["_note", "label", "decline_when", "decline_desire"])
            ensure(type(raw["self_entry"]["label"]) is str and 1 <= len(raw["self_entry"]["label"]) <= 40 and type(raw["self_entry"]["decline_when"]) is dict
                   and "h_self" in raw["actions"], "intimacy_data", "自分で高める入口の決まりが不正。")
            self.self_entry = {"label": raw["self_entry"]["label"], "decline_when": raw["self_entry"]["decline_when"], "decline_desire": number(raw["self_entry"]["decline_desire"], -100, 0)}
        self.actions = raw["actions"]
        self.positions = raw["positions"]
        self.settings = raw["settings"]
        check(raw["session"], ["locations", "min_minutes", "rested_minutes", "decline_quiet_minutes", "start_position", "invite_room"])
        ids(raw["session"]["locations"], catalog["locations"])
        ensure(raw["session"]["locations"] and raw["session"]["invite_room"] in raw["session"]["locations"], "intimacy_data", "部屋の指定が不正。")
        for key in ("min_minutes", "rested_minutes", "decline_quiet_minutes"):
            number(raw["session"][key], 0, 1440)
        check(raw["session"]["start_position"], ["seated", "other"])
        ensure(set(raw["session"]["start_position"].values()) <= self.positions.keys(), "intimacy_data", "開始体位が未登録。")
        check(raw["nights"], ["workday_eve", "holiday_eve", "read_air_minutes", "grace_actions"])
        check(raw["nights"]["workday_eve"], ["private_until"])
        check(raw["nights"]["holiday_eve"], ["private_until", "bedtime"])
        self.workday_until = time(raw["nights"]["workday_eve"]["private_until"])
        self.holiday_until = time(raw["nights"]["holiday_eve"]["private_until"])
        self.holiday_bedtime = time(raw["nights"]["holiday_eve"]["bedtime"])
        number(raw["nights"]["read_air_minutes"], 0, 60)
        number(raw["nights"]["grace_actions"], 0, 10)
        check(raw["maho"], ["arousal_bands", "satisfaction_levels", "climax_at", "after_climax", "climax_satisfaction", "tier_percent", "first_heart_percent", "pace_percent", "wants_more_pace_at_or_below", "signs"])
        bands = raw["maho"]["arousal_bands"]
        check(bands, ["mid_from", "high_from", "near_from"])
        ensure(0 < number(bands["mid_from"], 0, 100) < number(bands["high_from"], 0, 100) < number(bands["near_from"], 0, 100) <= 100, "intimacy_data", "高まりの閾値が逆順。")
        levels = raw["maho"]["satisfaction_levels"]
        check(levels, ["mid_from", "high_from"])
        ensure(0 < number(levels["mid_from"], 0, 100) < number(levels["high_from"], 0, 100) <= 100, "intimacy_data", "満足の閾値が逆順。")
        for key in ("climax_at", "after_climax", "climax_satisfaction", "wants_more_pace_at_or_below"):
            number(raw["maho"][key], 0, 100)
        ensure(raw["maho"]["after_climax"] < raw["maho"]["climax_at"], "intimacy_data", "絶頂後の高まりが不正。")
        check(raw["maho"]["tier_percent"], ["first", "few", "familiar"])
        for value in raw["maho"]["tier_percent"].values(): number(value, 0, 500)
        number(raw["maho"]["first_heart_percent"], 0, 500)
        check(raw["maho"]["pace_percent"], ["low", "mid", "high"])
        for row in raw["maho"]["pace_percent"].values():
            check(row, ["slow", "normal", "fast"])
            for value in row.values(): number(value, 0, 500)
        check(raw["maho"]["signs"], ["low", "mid", "high", "near"])
        ensure(all(type(x) is str and x for x in raw["maho"]["signs"].values()), "intimacy_data", "様子の表示が不正。")
        check(raw["player"], ["stamina_max", "arousal_max", "finish_from", "cap_not_inserted", "endure", "refractory_actions"])
        player = raw["player"]
        number(player["stamina_max"], 1, 10)
        ensure(0 < number(player["finish_from"], 0, 100) <= number(player["arousal_max"], 1, 100), "intimacy_data", "主人公の高まりの閾値が不正。")
        number(player["cap_not_inserted"], 0, player["finish_from"])
        check(player["endure"], ["per_peak", "back_to"])
        number(player["endure"]["per_peak"], 0, 10)
        number(player["endure"]["back_to"], 0, player["finish_from"])
        number(player["refractory_actions"], 0, 10)
        check(raw["hold_back"], ["per_session"])
        number(raw["hold_back"]["per_session"], 0, 10)
        check(raw["desire_after"], ["satisfied", "unsatisfied_add"], ["keep_after_private"])
        for key in ("satisfied", "unsatisfied_add"): number(raw["desire_after"][key], 0, 100)
        # v8.2.38：true なら、エッチをしないまま二人の時間が終わっても欲求を変えない（progression の set_after_private を使わない）
        ensure(raw["desire_after"].get("keep_after_private", False) in (True, False), "intimacy_data", "keep_after_private が不正。")
        check(raw["invite"], ["from", "priority", "min_history"])
        self.invite_from = time(raw["invite"]["from"])
        number(raw["invite"]["priority"], 0, 1000)
        number(raw["invite"]["min_history"], 0, 1000)
        check(raw["lead"], ["tier_from", "chance_percent", "per_session", "actions"], ["_note", "session_percent", "quiet_before_deadline"])
        # v8.2.30（通し確かめ 6）：申し出る回を慣れごとの割合で決める（その回に申し出るか）。締め切りの前（仕事／夜）は申し出ない
        for tier, percent in raw["lead"].get("session_percent", {}).items():
            ensure(tier in ("first", "few", "familiar"), "intimacy_data", "申し出る回の割合の慣れが不正。")
            number(percent, 0, 100)
        for kind, minutes in raw["lead"].get("quiet_before_deadline", {}).items():
            ensure(kind in ("work", "night"), "intimacy_data", "申し出を控える締め切りの種類が不正。")
            number(minutes, 0, 180)
        ensure(raw["lead"]["tier_from"] in ("first", "few", "familiar"), "intimacy_data", "提案の慣れが不正。")
        number(raw["lead"]["chance_percent"], 0, 100)
        number(raw["lead"]["per_session"], 0, 10)
        ids(raw["lead"]["actions"], self.actions)
        check(raw["clothing"], ["maho", "player", "labels"])
        for actor, layers in (("maho", {"upper": {"worn", "raised", "off"}, "lower": {"worn", "underwear", "aside", "off"}}), ("player", {"upper": {"worn", "off"}, "lower": {"worn", "off"}})):
            check(raw["clothing"][actor], ["upper", "lower"])
            for layer, choices in layers.items():
                ids(raw["clothing"][actor][layer], choices)
                ensure(set(raw["clothing"][actor][layer]) == choices, "intimacy_data", "服の状態が不足。")
        labels = raw["clothing"]["labels"]
        check(labels, ["maho.upper", "maho.lower", "player.upper", "player.lower"])
        for label, values in labels.items():
            check(values, raw["clothing"][label.split(".")[0]][label.split(".")[1]])
            ensure(all(type(x) is str for x in values.values()), "intimacy_data", "服の表示が不正。")
        check(raw["deflect"], ["hand", "insert", "fast"], ["deep"])  # deep：一気に奥まで入れる（v8.2.5）
        deflected = []
        for values in raw["deflect"].values():
            ids(values, self.actions)
            deflected += values
        ensure(len(deflected) == len(set(deflected)), "intimacy_data", "止める行動が重複。")
        ensure(type(self.positions) is dict and self.positions, "intimacy_data", "体位が不足。")
        for key, row in self.positions.items():
            identifier(key)
            check(row, ["label", "presence", "postures", "insertion", "tier_from", "facing", "linked"])
            check(row["postures"], ["player", "maho"])
            ensure(row["facing"] in ("face", "back", "face_sit", "sixty_nine"), "intimacy_data", "体位の向きが不正。")  # v8.2.10：顔面騎乗・シックスナイン
            ids(row["linked"], self.positions)
            ensure(key not in row["linked"] and (not row["linked"] or row["insertion"]), "intimacy_data", "入れたまま移れる体位が不正。")
            ensure(all(posture in catalog["postures"] for posture in row["postures"].values()) and type(row["insertion"]) is bool and row["tier_from"] in ("first", "few", "familiar"), "intimacy_data", "体位の状態が不正。")
            ensure(type(row["label"]) is str and row["label"] and type(row["presence"]) is str and row["presence"], "intimacy_data", "体位の表示が不正。")
        ensure(type(self.actions) is dict and set(self.actions) <= set(actions) and len(self.actions) >= 26, "intimacy_data", "エッチの行動の登録が不正。")
        for key, row in self.actions.items():
            identifier(key)
            check(row, ["label", "category", "origin", "ongoing", "entry", "offer_only", "minutes", "pace", "heart", "positions", "needs", "effects", "sets"] + (["continue_label", "end_label"] if row.get("ongoing") else []))
            ensure(row["label"] == actions[key]["label"] and row["origin"] in ("player", "maho") and all(type(row[x]) is bool for x in ("ongoing", "entry", "offer_only", "heart")), "intimacy_data", "行動の宣言が不正。")
            ensure(row["ongoing"] == actions[key]["ongoing"] and row["pace"] in ("none", "slow", "normal", "fast"), "intimacy_data", "行動の速さが不正。")
            ensure(row["category"] in CATEGORIES, "intimacy_data", "行動の分類が未登録。")
            number(row["minutes"], 0, 60)
            ids(row["positions"], self.positions)
            ensure(row["positions"], "intimacy_data", "行動の体位が不足。")
            needs = row["needs"]
            check(needs, ["maho_clothing", "player_clothing", "inserted", "maho_ready", "maho_band", "player_ready", "player_arousal", "after", "tier_from"])
            for actor in ("maho", "player"):
                ensure(set(needs[actor + "_clothing"]) <= {"upper", "lower"}, "intimacy_data", "服の参照が不正。")
                for layer, values in needs[actor + "_clothing"].items(): ids(values, raw["clothing"][actor][layer])
            ensure(needs["inserted"] in (None, True, False) and needs["maho_ready"] in (None, "mid", "high", "near") and needs["maho_band"] in (None, "mid", "high", "near") and needs["player_arousal"] in (None, "finish", "max") and type(needs["player_ready"]) is bool and type(needs["after"]) is bool and needs["tier_from"] in ("first", "few", "familiar"), "intimacy_data", "行動条件が不正。")
            ensure((key in deflected) == (needs["maho_ready"] is not None), "intimacy_data", "止める行動と準備条件が食い違う。")
            effects = row["effects"]
            check(effects, ["maho_arousal", "maho_arousal_cap", "satisfaction", "satisfaction_per_session", "player_arousal"])
            for field in effects: number(effects[field], 0, 100)
            sets = row["sets"]
            check(sets, ["position", "maho_clothing", "player_clothing", "inserted"])
            ensure(sets["position"] is None or sets["position"] in self.positions, "intimacy_data", "変更先の体位が未登録。")
            ensure(sets["inserted"] in (None, True, False), "intimacy_data", "挿入状態の変更が不正。")
            for actor in ("maho", "player"):
                ensure(set(sets[actor + "_clothing"]) <= {"upper", "lower"}, "intimacy_data", "服の変更が不正。")
                for layer, value in sets[actor + "_clothing"].items():
                    ensure(value in raw["clothing"][actor][layer], "intimacy_data", "変更先の服が未登録。")
        self._check_b2(raw["b2"], catalog, actions)
        check(self.settings, ["terms", "term_presets", "density", "speech_offset", "gauges", "default"], ["intensity", "quiet_contacts", "short_layer", "auto_continue", "outer_terms", "recent_text_window", "self_offer_replaces_line", "maho_led_moves", "thrust_up", "action_position_labels", "touch_sides", "after_stops", "action_facings", "action_pages", "keep_service", "inserted_stops", "position_stops", "action_stops", "move_before", "position_from", "flow", "calm", "release_lines", "finish_outcome", "afterglow", "again_actions", "text_memory"])
        # v8.2.37：同じ本文を避ける記録の長さ（state.schema.json の recent_text の maxItems まで）。ない版は 64
        if "recent_text_window" in self.settings:
            ensure(type(self.settings["recent_text_window"]) is int and 64 <= self.settings["recent_text_window"] <= 256, "intimacy_data", "recent_text_window が不正。")
        # v8.4.0（010 だけ）：手をつなぐの左右（エッチ中は向きで既定を決める）、暮らしの左右、隠す暮らしの触れ合い、余韻で終える行為
        self.side_defaults, self.side_labels, self.daily_sides, self.daily_hidden, self.daily_extra = {}, {}, {}, (), ()
        self.one_hand = None
        sides_setting = self.settings.get("touch_sides")
        if sides_setting:
            check(sides_setting, ["_note", "intimacy", "daily", "daily_hidden", "daily_extra"], ["one_hand"])
            # v8.4.2（010）：こちらの片手がふさがっている（手をつなぐ・片腕を引く）あいだ、胸に触れるのは片手（両方は選べない。既定は向きで決める）
            if "one_hand" in sides_setting:
                one = sides_setting["one_hand"]
                check(one, ["_note", "actions", "while", "side"])
                ensure(set(one["actions"]) <= set(self.sides) and all("both" in self.sides[key] for key in one["actions"]), "intimacy_data", "片手の左右は、両方を選べる行為に付ける。")
                ensure(set(one["while"]) <= set(actions) and type(one["side"]) is dict and set(one["side"].values()) <= {"right", "left"} and "default" in one["side"], "intimacy_data", "片手の左右が不正。")
                self.one_hand = {"actions": tuple(one["actions"]), "while": tuple(one["while"]), "side": dict(one["side"])}
            for key, row in sides_setting["intimacy"].items():
                check(row, ["default", "labels"])
                ensure(key in self.sides, "intimacy_data", "左右の既定は、左右を選べる行為に付ける。")
                ensure(type(row["default"]) is dict and set(row["default"].values()) <= set(self.sides[key]), "intimacy_data", "左右の既定が不正。")
                check(row["labels"], ["start", "keep", "switch"])
                ensure(set(row["labels"]["start"]) == set(self.sides[key]) == set(row["labels"]["switch"]) and type(row["labels"]["keep"]) is str, "intimacy_data", "左右の名前が不正。")
                self.side_defaults[key], self.side_labels[key] = row["default"], row["labels"]
            for key, row in sides_setting["daily"].items():
                check(row, ["choices", "default", "labels", "switch_meaning"])
                ensure(key in actions and actions[key]["ongoing"], "intimacy_data", "暮らしの左右は、続けられる触れ合いに付ける。")
                ensure(type(row["choices"]) is list and len(row["choices"]) >= 2 and set(row["choices"]) <= {"right", "left"} and row["default"] in row["choices"], "intimacy_data", "暮らしの左右が不正。")
                check(row["labels"], ["start", "keep", "switch"])
                ensure(set(row["labels"]["start"]) == set(row["choices"]) == set(row["labels"]["switch"]) and type(row["labels"]["keep"]) is str, "intimacy_data", "暮らしの左右の名前が不正。")
                self.daily_sides[key] = row
            ensure(set(sides_setting["daily_hidden"]) <= set(actions) and set(sides_setting["daily_extra"]) <= set(actions), "intimacy_data", "暮らしの触れ合いの指定が不正。")
            self.daily_hidden, self.daily_extra = tuple(sides_setting["daily_hidden"]), tuple(sides_setting["daily_extra"])
        self.after_stops = tuple(self.settings.get("after_stops", ()))
        # v8.4.0（010）：向きを選ぶ行為（額を寄せるは向かい合うときだけ、など）。{"_note", 行為: [向き]}
        self.action_facings = {key: tuple(value) for key, value in self.settings.get("action_facings", {}).items() if key != "_note"}
        # v8.4.0（010）：行為を置く頁（手と体＝h_close。v8.4.1 で「寄り添う」から名前を変えた）。ない版は種類で頁を決める
        self.action_pages = {key: value for key, value in self.settings.get("action_pages", {}).items() if key != "_note"}
        # v8.4.0（010）：選んでも終わらない口の行為（手をつなぐ・頬に触れるあいだも、口でしてもらう・口で愛撫するは続く）
        self.keep_service = {key: tuple(value) for key, value in self.settings.get("keep_service", {}).items() if key != "_note"}
        ensure(all(key in self.actions and set(value) <= set(self.actions) for key, value in self.keep_service.items()), "intimacy_data", "続く口の行為の指定が不正。")
        ensure(all(key in self.actions and value in ("h_close",) for key, value in self.action_pages.items()), "intimacy_data", "行為を置く頁の指定が不正。")
        ensure(all(key in self.actions and value for key, value in self.action_facings.items()), "intimacy_data", "向きを選ぶ行為の指定が不正。")
        ensure(set(self.after_stops) <= set(self.actions), "intimacy_data", "余韻で終える行為が未登録。")
        # v8.4.1（010）：抜いたら終える行為（腕を引く・引き寄せて抱きしめる）、体位を変えたら終える行為（手をつなぐ・抱きしめるなど。体を組み替えるため）
        self.inserted_stops = tuple(key for key in self.settings.get("inserted_stops", ()) if key != "_note")
        self.position_stops = tuple(key for key in self.settings.get("position_stops", ()) if key != "_note")
        ensure(set(self.inserted_stops) <= set(self.actions) and set(self.position_stops) <= set(self.actions), "intimacy_data", "抜いたら・体位を変えたら終える行為が未登録。")
        # v8.4.2（010）：その行為をしたら終える触れ合い（上の服を脱ぐ・脱がせるなら、手をつなぐ・片腕を引くを終える。袖から腕を抜く）。{"_note", 行為: [終える行為]}
        self.action_stops = {key: tuple(value) for key, value in self.settings.get("action_stops", {}).items() if key != "_note"}
        # v8.4.2（010）：動く速さを変えた直前の速さを持つ（条件 intimacy.move_before）。ない版は持たない（009）
        self.move_before = "move_before" in self.settings
        # v8.4.3（010）：体位を移る前の体位を持つ（条件 intimacy.position_from・facing_from）。ない版は持たない（009）
        self.position_from = "position_from" in self.settings
        # 体位を移る本文のうち、移る前の体位に合わせて書いた本文（背を向けた体位・顔面騎乗・膝に乗る などから）を、最近出ていない限り先に出すか
        self.position_from_prefer = bool(self.position_from and self.settings["position_from"].get("prefer"))
        # v8.4.4（010）：前後の本文の流れ（直前の本文の仕草と重なる本文・前の状態と食い違う「〜たまま」を後回しにする）。ない版は見ない（009）
        self.flow = Flow(self.settings["flow"]) if "flow" in self.settings else None
        # v8.4.5（010）：刺激のない手（段を上げない・続くと高まりが一段下がる）。ない版は区別しない（009）
        # v8.4.7（010）：中に出す手で、真帆がどうなったか（達した・あと一歩・高い・それ以下）を本文の条件 intimacy.finish_outcome に出し、
        # その手では高まりの合図を出さない（果てる本文の中で真帆の様子を書く）。prefer：結果ごとに先に出す本文（真帆の高まりを書いた本文）
        self.finish_outcome = None
        if "finish_outcome" in self.settings:
            finish = self.settings["finish_outcome"]
            check(finish, ["_note", "actions", "prefer"])
            ensure(set(finish["actions"]) <= set(self.actions) and type(finish["prefer"]) is dict and set(finish["prefer"]) <= set(FINISH_OUTCOMES)
                   and all(type(v) is list and all(type(i) is str for i in v) for v in finish["prefer"].values()), "intimacy_data", "果てる手の結果の設定が不正。")
            self.finish_outcome = {"actions": frozenset(finish["actions"]), "prefer": {k: frozenset(v) for k, v in finish["prefer"].items()}}
        # v8.4.8（010）：真帆が達したあと、min_hands 手を過ぎ、高まりが until_arousal に戻るまでを「余韻」とし、本文の条件 intimacy.maho.afterglow にする
        # （達すると高まりは中くらいの段に戻るので、高まりはじめの本文「だんだん、気持ちよくなってきた」が出ていた）
        self.afterglow = None
        if "afterglow" in self.settings:
            afterglow = self.settings["afterglow"]
            check(afterglow, ["_note", "until_arousal", "min_hands"])
            ensure(type(afterglow["until_arousal"]) is int and self.raw["maho"]["after_climax"] < afterglow["until_arousal"] <= self.raw["maho"]["climax_at"]
                   and type(afterglow["min_hands"]) is int and 0 <= afterglow["min_hands"] <= 10, "intimacy_data", "余韻の設定が不正。")
            self.afterglow = {"until_arousal": afterglow["until_arousal"], "min_hands": afterglow["min_hands"]}
        # v8.4.9（010）：同じ回に2回目からは .again の本文を出す行為を足す（AGAIN_TEXT に加えて。口づけを挟んでもう一度したとき、初めて口づける書き方が出ていた）
        self.again_actions = ()
        if "again_actions" in self.settings:
            again = self.settings["again_actions"]
            check(again, ["_note", "actions"])
            ensure(type(again["actions"]) is list and set(again["actions"]) <= set(self.actions), "intimacy_data", "もう一度の本文を出す行為の設定が不正。")
            self.again_actions = tuple(again["actions"])
        # v8.4.11（010）：本文ごとに最後に出た番号を保存に覚え、同じ条件で選べる本文の中では、いちばん長く出ていない本文から出す。
        # horizon：覚えておく長さ（本文を選んだ回数）。それより前に出た本文は、まだ出ていない本文と同じに扱う（人も忘れている）
        self.text_memory = None
        if "text_memory" in self.settings:
            memory = self.settings["text_memory"]
            check(memory, ["_note", "horizon"], ["composed", "late_hot"])
            ensure(type(memory["horizon"]) is int and 512 <= memory["horizon"] <= 20000, "intimacy_data", "本文を覚えておく長さの設定が不正。")
            # v8.4.14（010）：部品を組み合わせた本文の比べ方。newest_first＝新しいほうの部品で比べる（v8.4.11、ない版の既定）、
            # reaction_first＝後半（真帆の反応）の部品で比べ、同じなら前半の部品で比べる（前半の部品は数が少なく、いつも新しいので、
            # 新しいほうで比べると前からある本文ばかりが古く見えて、半分ほどが前からある本文になっていた）
            ensure(memory.get("composed", "newest_first") in ("newest_first", "reaction_first"), "intimacy_data", "組み合わせた本文の比べ方の設定が不正。")
            # v8.4.18（010）：late_hot＝高まりが高いとき（濃さ high）に先に出す本文に、濃い本文（style）だけでなく、高まり high・near だけに出す本文も入れる
            # （続けている手の短い本文と同じ扱い。v8.2.23）。高いときの反応の部品を足しても、濃い本文ばかりが先に出て、そこで再会していた
            ensure(type(memory.get("late_hot", False)) is bool, "intimacy_data", "高いときに先に出す本文の設定が不正。")
            self.text_memory = {"horizon": memory["horizon"], "composed": memory.get("composed", "newest_first"), "late_hot": memory.get("late_hot", False)}
        self.calm = None
        if "calm" in self.settings:
            calm = self.settings["calm"]
            check(calm, ["_note", "actions", "neutral", "settle_after", "floor"])
            ensure(set(calm["actions"]) <= set(self.actions) and set(calm["neutral"]) <= set(calm["actions"]) and type(calm["settle_after"]) is int
                   and 1 <= calm["settle_after"] <= 10 and calm["floor"] in ("low", "mid", "high"), "intimacy_data", "刺激のない手の設定が不正。")
            self.calm = {"actions": frozenset(calm["actions"]), "neutral": frozenset(calm["neutral"]), "settle_after": calm["settle_after"], "floor": calm["floor"]}
        # v8.4.5（010）：手をつなぐ・抱きしめるなどを入れ替えで終えたときのほどく一言（system.contact_released.<組>）。ない版は出さない（009）
        self.release = None
        if "release_lines" in self.settings:
            lines = self.settings["release_lines"]
            check(lines, ["_note", "groups", "family"])
            ensure(type(lines["groups"]) is dict and set(lines["groups"]) == set(lines["family"]) and all(type(v) is list and v for v in lines["groups"].values()),
                   "intimacy_data", "ほどく一言の組が不正。")
            of = {}
            for group, keys in lines["groups"].items():
                for key in keys:
                    ensure(key not in of and (key in actions or key in self.actions), "intimacy_data", "ほどく一言の組の行為が不正。")
                    of[key] = group
            self.release = {"order": tuple(lines["groups"]), "of": of, "family": dict(lines["family"])}
        ensure(all(key in self.actions and set(value) <= set(self.actions) for key, value in self.action_stops.items()), "intimacy_data", "したら終える行為が未登録。")
        self.short = self.settings.get("short_layer")
        if self.short:
            # v8.2.20（009）：続けているあいだの短い本文。long_every の倍数の手だけ長い本文
            check(self.short, ["_note", "long_every", "choices", "default"])
            number(self.short["long_every"], 0, 100)  # v8.2.23：0 は、続けている手に長い本文を出さない
            ids(self.short["choices"], ["short", "long"])
            ensure(self.short["choices"] == ["short", "long"] and self.short["default"] in self.short["choices"], "intimacy_data", "続けるときの本文の設定が不正。")
        self.auto = self.settings.get("auto_continue")
        if self.auto:
            # v8.2.20（009）：テキスト版の「自動で続ける」
            auto = self.auto
            check(auto, ["_note", "actions", "keep_meanings", "base_ms", "per_char_ms", "min_ms", "max_ms"], ["speeds", "choices", "default"])
            ensure(type(auto["actions"]) is list and auto["actions"] and len(set(auto["actions"])) == len(auto["actions"]), "intimacy_data", "自動で続ける行為の指定が不正。")
            for key in auto["actions"]:
                ensure(key in self.actions and self.actions[key]["ongoing"], "intimacy_data", "自動で続ける行為は、続けられる行為でなければならない。")
            ensure(type(auto["keep_meanings"]) is list and all(type(x) is str and x for x in auto["keep_meanings"]), "intimacy_data", "自動で続けても止めない合図の指定が不正。")
            number(auto["base_ms"], 0, 60000)
            number(auto["per_char_ms"], 0, 1000)
            number(auto["min_ms"], 500, 60000)
            number(auto["max_ms"], auto["min_ms"], 60000)
            if "speeds" in auto:
                # v8.2.28：設定「自動で続ける」の速さ（待ち時間に掛ける百分率）。off は自動で続けない
                check(auto, ["_note", "actions", "keep_meanings", "base_ms", "per_char_ms", "min_ms", "max_ms", "speeds", "choices", "default"])
                ensure(type(auto["speeds"]) is dict and auto["speeds"] and "off" not in auto["speeds"], "intimacy_data", "自動で続ける速さの指定が不正。")
                for percent in auto["speeds"].values():
                    number(percent, 10, 500)
                ensure(auto["choices"] == list(auto["speeds"]) + ["off"] and auto["default"] in auto["speeds"], "intimacy_data", "自動で続ける速さの選択肢が不正。")
        if "quiet_contacts" in self.settings:
            # v8.2.16（009）：続いているあいだ真帆が話せない行為（深い口づけ）。本文の選び方で、台詞のない本文を先にする
            quiet = self.settings["quiet_contacts"]
            ensure(type(quiet) is list and quiet and len(set(quiet)) == len(quiet), "intimacy_data", "話せない行為の指定が不正。")
            for key in quiet:
                ensure(key in self.actions and self.actions[key]["ongoing"], "intimacy_data", "話せない行為は、続けられる行為でなければならない。")
        if "intensity" in self.settings:
            # v8.2.2（009）：濃い本文を高まりで出し分ける。描写の濃さの設定は画面に出さない
            config = self.settings["intensity"]
            check(config, ["player_mid_from", "player_high_from", "peak_meanings"])
            number(config["player_mid_from"], 1, 100)
            number(config["player_high_from"], config["player_mid_from"], 100)
            ensure(type(config["peak_meanings"]) is list and config["peak_meanings"] and all(type(x) is str and x for x in config["peak_meanings"]), "intimacy_data", "山の場面の指定が不正。")
        terms = self.settings["terms"]
        ensure(set(terms) == {"penis", "vagina", "semen", "breasts", "nipple", "clitoris", "love_juice"}, "intimacy_data", "差し込みの種類が不正。")
        for words in terms.values():
            ensure(type(words) is list and words and len(words) == len(set(words)) and all(type(w) is str and w for w in words), "intimacy_data", "差し込みの語が不正。")
        outer = self.settings.get("outer_terms")
        if outer is not None:
            # v8.2.31（009）：外側に触れる行為の本文では、{vagina} を外側の語で出す（「膣」を選んでいるときの「下着の上から膣を」を避ける）
            check(outer, ["_note", "actions", "vagina"], ["actions_not_inserted"])
            ensure(type(outer["actions"]) is list and outer["actions"] and all(key in self.actions for key in outer["actions"]), "intimacy_data", "外側の語を使う行為が未登録。")
            extra = outer.get("actions_not_inserted", [])
            ensure(type(extra) is list and all(key in self.actions and key not in outer["actions"] for key in extra), "intimacy_data", "入れていないときに外側の語を使う行為が未登録。")
            ensure(type(outer["vagina"]) is dict and outer["vagina"] and all(key in terms["vagina"] and type(word) is str and word and len(word) <= max(map(len, terms["vagina"])) for key, word in outer["vagina"].items()),
                   "intimacy_data", "外側の語の置き換えが不正。")
        check(self.settings["term_presets"], ["mild", "standard", "explicit"])
        for preset in self.settings["term_presets"].values():
            check(preset, terms)
            ensure(all(word in terms[key] for key, word in preset.items()), "intimacy_data", "一括設定に未登録の語がある。")
        ids(self.settings["density"], ["standard", "explicit"])
        check(self.settings["speech_offset"], ["few", "standard", "many"])
        for offset in self.settings["speech_offset"].values(): number(offset, -10, 10)
        ids(self.settings["gauges"], ["hidden", "shown"])
        check(self.settings["default"], ["term_preset", "density", "speech", "gauges"])
        default = self.settings["default"]
        ensure(default["term_preset"] in self.settings["term_presets"] and default["density"] in self.settings["density"] and default["speech"] in self.settings["speech_offset"] and default["gauges"] in self.settings["gauges"], "intimacy_data", "設定の既定値が不正。")

    def _check_b2(self, b2, catalog, actions):
        """段階Bの2版目（B2、2026-09-27）の宣言。"""
        check(b2, ["_note", "sleep_after", "self_cap", "help_offer", "quiet_sign_categories", "overflow", "gate"], ["requests", "sixty_nine", "lewdness", "pace", "stroke", "combos", "pat", "wants_more", "same_first",
                                                                                                                  "sides", "deadline_close", "limit_caress", "after_time", "first_time_minutes"])
        # v8.2.29（ユーザー 2026-09-30）：胸に触れる左右。最初の値が既定（touch.<行為>）
        self.sides = {}
        if "sides" in b2:
            check(b2["sides"], ["_note", "actions"])
            for key, choices in b2["sides"]["actions"].items():
                ensure(key in self.actions and self.actions[key]["ongoing"], "intimacy_data", "左右を選ぶ行為は、続けられる行為でなければならない。")
                ensure(type(choices) is list and len(choices) >= 2 and len(set(choices)) == len(choices) and set(choices) <= {"both", "right", "left"}, "intimacy_data", "左右の選択肢が不正。")
                self.sides[key] = tuple(choices)
        # v8.2.29：締め切りに、もうすぐ達しそうなら延ばす手の数／限界でも口づけ・愛撫／昼に終えたあとの時間
        self.deadline_close = b2.get("deadline_close")
        if self.deadline_close:
            check(self.deadline_close, ["_note", "grace_actions"])
            number(self.deadline_close["grace_actions"], 1, 10)
        self.limit_caress = b2.get("limit_caress")
        if self.limit_caress:
            check(self.limit_caress, ["_note", "cool"])
            number(self.limit_caress["cool"], 0, 50)
        # v8.2.30（通し確かめ 8）：初めての回は、締め切りまでこれだけ残っていないと始めない（真帆が先に延ばす）
        self.first_time_minutes = b2.get("first_time_minutes")
        if self.first_time_minutes is not None:
            number(self.first_time_minutes, 0, 240)
        self.after_time = b2.get("after_time")
        if self.after_time:
            check(self.after_time, ["_note", "minutes", "after"])
            number(self.after_time["minutes"], 0, 180)
            ids([self.after_time["after"]], catalog["locations"])
        # v8.2.25（精査 A-1・C-01）：同じ体験とみなす行動の組（どれかをしたことがあれば、ほかの行動も「初めて」の本文にしない）
        self.same_first = {}
        if "same_first" in b2:
            check(b2["same_first"], ["_note", "groups"])
            groups = b2["same_first"]["groups"]
            ensure(type(groups) is list and groups, "intimacy_data", "同じ体験の組が不正。")
            for group in groups:
                ensure(type(group) is list and len(group) >= 2 and len(set(group)) == len(group) and all(key in self.actions for key in group), "intimacy_data", "同じ体験の組が不正。")
                for key in group:
                    ensure(key not in self.same_first, "intimacy_data", "同じ体験の組が重なっている。")
                    self.same_first[key] = tuple(other for other in group if other != key)
        if "wants_more" in b2:
            # v8.2.24：物足りなさの合図の間（出した回数ごとに、次を出すまで続ける手の数）と、焦れた合図に変わる回数
            wants = b2["wants_more"]
            check(wants, ["_note", "gaps", "urge_from"])
            ensure(type(wants["gaps"]) is list and 1 <= len(wants["gaps"]) <= 5, "intimacy_data", "物足りなさの合図の間が不正。")
            for value in wants["gaps"]: number(value, 1, 30)
            number(wants["urge_from"], 1, 10)
        self.pat = b2.get("pat")
        if self.pat:
            # v8.2.22：胸に口づけている続きの手で、真帆が頭を撫でる一行
            check(self.pat, ["_note", "meanings", "chance_percent", "lewd_plus"])
            ensure(type(self.pat["meanings"]) is dict and self.pat["meanings"] and all(type(k) is str and type(v) is str and v for k, v in self.pat["meanings"].items()), "intimacy_data", "撫でる一行の指定が不正。")
            ensure(list(self.pat["chance_percent"]) == ["first", "few", "familiar"] and list(self.pat["lewd_plus"]) == list(LEWD_BANDS), "intimacy_data", "撫でる一行の確率が不足。")
            for value in list(self.pat["chance_percent"].values()) + list(self.pat["lewd_plus"].values()): number(value, 0, 100)
        self.combos = b2.get("combos", [])
        ensure(type(self.combos) is list, "intimacy_data", "組み合わせの指定が不正。")
        for combo in self.combos:
            # v8.2.21：二つの行為が同時に続いているときの本文（胸を吸いながら手でしてもらう）
            check(combo, ["_note", "actions", "meaning", "finish"])
            ensure(type(combo["actions"]) is list and len(combo["actions"]) == 2 and len(set(combo["actions"])) == 2
                   and all(key in self.actions and self.actions[key]["ongoing"] for key in combo["actions"]), "intimacy_data", "組み合わせの行為が不正。")
            ensure(type(combo["meaning"]) is str and combo["meaning"] and combo["meaning"] not in self.actions and combo["finish"] in self.actions
                   and combo["finish"].startswith("h_finish_") and not self.actions[combo["finish"]]["ongoing"], "intimacy_data", "組み合わせの本文・出す行動が不正。")
        check(b2["sleep_after"], ["from", "until"])
        self.sleep_from, self.sleep_until = time(b2["sleep_after"]["from"]), time(b2["sleep_after"]["until"])
        ensure(self.sleep_from < self.sleep_until, "intimacy_data", "一緒に眠る時刻の範囲が不正。")
        number(b2["self_cap"], 0, self.raw["player"]["arousal_max"] - 1)
        check(b2["help_offer"], ["chance_percent", "min_player_arousal", "mouth_tier_from"])
        number(b2["help_offer"]["chance_percent"], 0, 100)
        number(b2["help_offer"]["min_player_arousal"], 0, 100)
        ensure(b2["help_offer"]["mouth_tier_from"] in ("first", "few", "familiar"), "intimacy_data", "申し出の慣れが不正。")
        ids(b2["quiet_sign_categories"], CATEGORIES)
        ensure(type(b2["overflow"]) is dict, "intimacy_data", "こらえきれずに出す行動が不正。")
        for source, target in b2["overflow"].items():
            # 続ける行動（動き・手・口）と、v8.2.4 から入れる行動（限界のまま入れると、入れた途端に出る）
            ensure(source in self.actions and target in self.actions and (self.actions[source]["ongoing"] or self.actions[source]["sets"]["inserted"] is True and target == "h_finish_inside") and target in FINISH_ACTIONS, "intimacy_data", "こらえきれずに出す行動が不正。")
        if "requests" in b2:
            # v8.2.9：お願いの履歴で、真帆が自分から申し出る・追加する
            req = b2["requests"]
            check(req, ["_note", "threshold", "offer_chance_percent", "extra_chance_percent", "offer_min_player_arousal", "extra_bonus"])
            number(req["threshold"], 1, 100)
            for key in ("offer_chance_percent", "extra_chance_percent", "offer_min_player_arousal"):
                number(req[key], 0, 100)
            number(req["extra_bonus"], 0, 50)
        if "sixty_nine" in b2:
            check(b2["sixty_nine"], ["_note", "lead_min_player_arousal", "lead_min_experience"])  # v8.2.10
            number(b2["sixty_nine"]["lead_min_player_arousal"], 0, 100)
            number(b2["sixty_nine"]["lead_min_experience"], 0, 100)
        self.lewd = None
        if "lewdness" in b2:
            # v8.2.12：淫乱度（下がらない）。段ごとの効き目
            lewd = b2["lewdness"]
            check(lewd, ["_note", "per_session", "satisfied", "per_climax", "climax_max", "new_act", "max", "min_satisfaction", "bands", "labels", "threshold_minus", "chance_plus",
                         "lead_chance_plus", "sixty_nine_arousal_minus", "beg_arousal"])
            ensure(lewd["min_satisfaction"] in ("low", "mid", "high"), "intimacy_data", "淫乱度が上がる満足の段が不正。")
            for key in ("per_session", "satisfied", "per_climax", "climax_max", "new_act"):
                number(lewd[key], 0, 20)
            number(lewd["max"], 1, 1000)
            ensure(list(lewd["bands"]) == list(LEWD_BANDS) and lewd["bands"]["shy"] == 0 and all(lewd["bands"][a] < lewd["bands"][b] <= lewd["max"] for a, b in zip(LEWD_BANDS, LEWD_BANDS[1:])),
                   "intimacy_data", "淫乱度の段が不正。")
            for key in ("labels", "threshold_minus", "chance_plus", "lead_chance_plus", "sixty_nine_arousal_minus", "beg_arousal"):
                ensure(type(lewd[key]) is dict and list(lewd[key]) == list(LEWD_BANDS), "intimacy_data", "淫乱度の段ごとの値が不足。")
                for value in lewd[key].values():
                    if key == "labels":
                        ensure(type(value) is str and value, "intimacy_data", "淫乱度の段の名前が不正。")
                    else:
                        number(value, 0, 100)
            self.lewd = lewd
        self.pace = None
        if "pace" in b2:
            # v8.2.13：続けている行為の速さ
            pace = b2["pace"]
            check(pace, ["_note", "actions", "player_percent", "labels", "mouth_labels"], ["named_labels"])
            ensure(type(pace["actions"]) is dict and pace["actions"], "intimacy_data", "速さを変えられる行為が不足。")
            for key, target in pace["actions"].items():
                ensure(key in self.actions and self.actions[key]["ongoing"] and target in ("player", "maho", "both"), "intimacy_data", "速さを変えられる行為が不正。")
            ensure(list(pace["player_percent"]) == list(PACES), "intimacy_data", "速さの割合が不足。")
            for value in pace["player_percent"].values(): number(value, 0, 300)
            ensure({"service", "own"} <= set(pace["labels"]) and set(pace["labels"]) - {"service", "own"} <= set(pace["actions"]), "intimacy_data", "速さの名前が不正。")
            for row in pace["labels"].values():
                check(row, ["up", "down"])
            ensure(list(pace["mouth_labels"]) == list(PACES), "intimacy_data", "口の3段の名前が不足。")
            for key, names in pace.get("named_labels", {}).items():
                # v8.2.21：3段の名前で選ぶ行為（胸に口づける：舌で転がす／含んで吸う／強く吸う）
                ensure(key in pace["actions"] and key != "h_maho_mouth" and list(names) == list(PACES) and all(type(x) is str and x for x in names.values()), "intimacy_data", "3段の名前が不正。")
            self.pace = pace
        self.stroke = None
        if "stroke" in b2:
            # v8.2.14：頭をなでる・撫で返し
            stroke = b2["stroke"]
            check(stroke, ["_note", "lead_actions", "facings", "stroke_back"])
            ensure(all(key in self.actions and self.actions[key]["ongoing"] and self.pace and key in self.pace["actions"] for key in stroke["lead_actions"]) and "h_stroke_head" in self.actions,
                   "intimacy_data", "撫でると熱が入る行為が不正（速さを変えられる行為で、頭をなでる行動がある）。")
            ids(stroke["facings"], ["face", "back", "player_mouth", "maho_mouth", "maho_breasts", "maho_feet", "face_sit", "sixty_nine"])
            back = stroke["stroke_back"]
            check(back, ["chance_percent", "lewd_plus", "after"])
            ensure(list(back["chance_percent"]) == ["first", "few", "familiar"] and list(back["lewd_plus"]) == list(LEWD_BANDS), "intimacy_data", "撫で返しの確率が不足。")
            for value in list(back["chance_percent"].values()) + list(back["lewd_plus"].values()): number(value, 0, 100)
            ensure(all(key in self.actions for key in back["after"]), "intimacy_data", "撫で返しのきっかけが未登録。")
            self.stroke = stroke
        gate = b2["gate"]
        check(gate, ["touches", "hints", "public_rooms", "work_margin_minutes"])
        ensure(type(gate["touches"]) is dict and gate["touches"], "intimacy_data", "深める触れ合いが不足。")
        for key, row in gate["touches"].items():
            check(row, ["h_action", "strong"])
            ensure(key in actions and key not in self.actions and type(row["strong"]) is bool, "intimacy_data", "深める触れ合いが未登録。")
            ensure(row["h_action"] is None or row["h_action"] in self.actions and self.actions[row["h_action"]]["entry"], "intimacy_data", "深める触れ合いの続きが入口の行動でない。")
        check(gate["hints"], gate["touches"])
        ensure(all(type(x) is str and x for x in gate["hints"].values()), "intimacy_data", "深める触れ合いの説明が不正。")
        ids(gate["public_rooms"], catalog["locations"])
        number(gate["work_margin_minutes"], 0, 180)
        self.b2 = b2

    def tier(self, count, life):
        nth = count + 1
        return "first" if nth < life.few_from else "few" if nth < life.familiar_from else "familiar"

    def pace_of(self, state):
        """v8.2.13：いま速さを変えられる行為（最後にした、続いている行為）と、その速さ。なければ (None, "normal")。"""
        intimate = state["intimacy"]
        if not self.pace or not intimate:
            return None, "normal"
        focus = intimate["pace_focus"]
        if focus is None or not any(c["action_id"] == focus for c in state["contacts"]):
            return None, "normal"
        return focus, intimate["paces"].get(focus, "normal")

    def lewd_band(self, value):
        """v8.2.12：淫乱度の段（shy／open／eager／bold）。淫乱度を持たない版では shy。"""
        if self.lewd is None:
            return "shy"
        return [band for band in LEWD_BANDS if value >= self.lewd["bands"][band]][-1]

    def lewd_value(self, band, key, base=0):
        """段ごとの効き目（淫乱度を持たない版では base のまま）。"""
        return base if self.lewd is None else self.lewd[key][band]

    def band(self, value):
        bars = self.raw["maho"]["arousal_bands"]
        return "near" if value >= bars["near_from"] else "high" if value >= bars["high_from"] else "mid" if value >= bars["mid_from"] else "low"

    def satisfaction_level(self, value):
        bars = self.raw["maho"]["satisfaction_levels"]
        return "high" if value >= bars["high_from"] else "mid" if value >= bars["mid_from"] else "low"

    def maho_gain(self, base, tier, band, pace):
        gain = base * self.raw["maho"]["tier_percent"][tier] // 100
        pace_percent = 100 if pace == "none" else self.raw["maho"]["pace_percent"]["high" if band == "near" else band][pace]
        return gain * pace_percent // 100, pace_percent

    def facing(self, state):
        """B2：真帆との向き。口の行動を続けている間は mouth、それ以外は体位の向き。"""
        intimate = state["intimacy"]
        if not intimate:
            return "face"
        active = {c["action_id"] for c in state["contacts"]}
        own = self.positions[intimate["position"]]["facing"]
        if own in ("face_sit", "sixty_nine"):
            return own  # v8.2.10：顔面騎乗・シックスナインは、体位そのものの向き
        if "h_player_mouth" in active:
            return "player_mouth"
        if "h_maho_mouth" in active:
            return "maho_mouth"
        if "h_maho_breasts" in active:
            return "maho_breasts"  # v8.2.9：胸でしてもらっている（真帆はこちらの脚のあいだ）
        if "h_maho_feet" in active:
            return "maho_feet"  # v8.2.9：足でしてもらっている（真帆は向かいに座る）
        return self.positions[intimate["position"]]["facing"]

    def one_hand_busy(self, state, key):
        """v8.4.2（010）：こちらの片手がふさがっていて、胸に触れるのが片手だけか（settings.touch_sides.one_hand）。"""
        return bool(self.one_hand and state["intimacy"] and key in self.one_hand["actions"]
                    and any(c["action_id"] in self.one_hand["while"] for c in state["contacts"]))

    def side_choices(self, state, key):
        """v8.4.2：いま選べる左右（片手がふさがっていれば、両方は選べない）。"""
        return tuple(side for side in self.sides[key] if not (side == "both" and self.one_hand_busy(state, key)))

    def default_side(self, state, key):
        """v8.4.0：左右の既定。手をつなぐ（010）は向きで決める（向かい合えば真帆の右手、後ろからなら左手）。ほかは最初の値（v8.2.29）。
        v8.4.2（010）：こちらの片手がふさがっていれば、胸は片手（向き合えば真帆の左胸、後ろからなら右胸＝こちらの右手が届く側）。"""
        choices = self.sides[key]
        if self.one_hand_busy(state, key):
            return self.one_hand["side"].get(self.facing(state), self.one_hand["side"]["default"])
        if key in self.side_defaults and state["intimacy"]:
            return self.side_defaults[key].get(self.facing(state), choices[0])
        return choices[0]

    def side_of(self, state, key):
        """v8.2.29：胸に触れる左右（続いていなければ既定）。"""
        intimate = state["intimacy"]
        if not intimate:
            return self.sides[key][0]
        return intimate.get("sides", {}).get(key, self.default_side(state, key))

    def maho_led(self, state):
        """v8.2.25（指摘 R1）：この回に、真帆の「上になる」「自分から入れる」の申し出を受けたか（その行動をこの回の始まり以後にしたか）。"""
        intimate = state["intimacy"]
        if not intimate:
            return False
        return any(key in state["experience"] and state["experience"][key]["last_at"] is not None and state["experience"][key]["last_at"] >= intimate["started_at"]
                   for key in LED_ON_TOP)

    def maho_led_fresh(self, state):
        """v8.2.34（総ざらい 4）：申し出（上になる・自分から入れる）を受けてから、まだ「真帆に動いてもらう」の本文が出ていないか。
        最近の本文の id（意味の名前を含む）で見る（保存の形は変えない）。"""
        if not self.maho_led(state):
            return False
        for item in reversed(state["recent_text"]):
            parts = item["id"].split(".")
            if "h_maho_move" in parts:
                return False
            if any(key in parts for key in LED_ON_TOP):
                return True
        return False

    def sleep_night(self, now):
        """B2：この時刻にエッチを終えたら、そのまま一緒に眠る。"""
        return self.sleep_from <= day_time(now) < self.sleep_until  # 暮らしの一日は 5:00 から（01:30 は 25:30）

    def night_kind(self, now, life):
        base = now - day_time(now)
        next_weekday = (clock.date_time(base).weekday() + 1) % 7
        return "workday_eve" if next_weekday in life.weekdays else "holiday_eve"

    def deadline(self, now, life):
        base = now - day_time(now)
        kind = self.night_kind(now, life)
        limit = self.workday_until if kind == "workday_eve" else self.holiday_until
        return base + limit

    def invite_ready(self, state, progression, life):
        now = state["world"]["now"]
        maho = state["actors"]["maho"]
        history = state["intimacy_history"]
        from .life_rules import bath_level_bonus
        if state["relation"]["stage"] < 3 or progression.desire_level(state["desire"] + bath_level_bonus(state, life)) == "low": return False  # 湯上がりは誘いやすい（v8.2.0）
        if history["count"] < self.raw["invite"]["min_history"] or state["mode"] != "normal": return False
        if state["scene"] or state["offer"] or state["maho_sleep"]["state"] != "awake": return False
        if state["actors"]["player"]["location"] != maho["location"]: return False
        if day_time(now) < self.invite_from or day_time(now) >= self.holiday_bedtime: return False
        # 誘いを受けると真帆の部屋へ移るので、移動の分も残っているときだけ誘う（v8.0.5、監査 B-007）。
        location = state["actors"]["player"]["location"]
        if location == self.raw["session"]["invite_room"]: return False  # v8.2.25（精査 A U-1）：真帆の部屋の中で「部屋に行こう」と誘わない
        travel = 0 if location == self.raw["session"]["invite_room"] else 5 if location in RESIDENCE else 10
        if self.deadline(now, life) - now < self.raw["session"]["min_minutes"] + travel: return False
        if history["last_result"] == "satisfied" and now - history["last_at"] <= self.raw["session"]["rested_minutes"]: return False
        if history["declined_at"] is not None and now - history["declined_at"] <= self.raw["session"]["decline_quiet_minutes"]: return False
        return True
