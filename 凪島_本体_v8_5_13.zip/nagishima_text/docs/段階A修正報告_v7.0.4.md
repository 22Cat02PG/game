# 段階A修正報告 v7.0.4

2026-09-25。起点は v7.0.3。Opus 5.5 の差し戻し指示に基づく D-1〜D-3 の修正と試験補強。受入判定は Opus の再監査で行う。

## 変更ファイル

- 本体：`nagishima/progression.py`、`nagishima/autoplay.py`、`nagishima/__main__.py`、`nagishima/__init__.py`。
- 試験・梱包：`tests/test_stage_a.py`、`tests/fixtures/README.md`、`tests/fixtures/v62_normal.json`、`tests/fixtures/v62_cheat.json`、`tests/fixtures/v62_run.jsonl`、`tools/benchmark_runtime.py`、`tools/pack_runtime.py`。
- 文書：`docs/凪島_段階A_仕様と受入条件_2026-09-24.md`、本書、`README.md`、`引き継ぎ.md`。
- 検証結果：`verification/results.json`、`verification/test_results.txt`、`verification/stage_a_routes.json`、`verification/benchmark_release_interaction_006.json`、`verification/benchmark_release_interaction_007.json`、`verification/immersion_presence_v704.json`、本文検査・再生ログ。

`content/releases/` の59ファイルは、v7.0.3 とファイル数・SHA-256 が全件一致。旧ZIPも変更していない。`RULES_VERSION = nagishima-2.3`、`SAVE_SCHEMA = 3` を維持し、本体版のみ `2.3.1` とした。

## D-1〜D-3 と受入条件

| 項目 | 修正・結果 |
|---|---|
| D1-a | 生活日を5:01〜翌5:00に統一。就寝中に公開 `wait.30` で5:00へ進め、有効状態を確認。 |
| D1-b | 5:00で公開 `save` と `load` が成功し、状態が一致。 |
| D1-c | 5:00では親密度の集計日・回数は変化せず、就寝後の次の獲得時に更新。 |
| D1-d | 5日分の全分を旧式と比較。5:00ちょうど以外は同値。うたた寝予定も3シード×複数日で一致。`parse_time("05:00") == 1740`。 |
| D1-e | 3方針・30経路の全件が `cleared`・再現一致。v7.0.3 との操作数、節目の日付、最終状態SHA-256の差分0件。固定経路の更新なし。 |
| D2-a/b | 人間CLIの「状態」は通常起動で `affinity`・`desire` を表示せず、`--test-cheats` では表示。 |
| D2-c | JSONの `state` は両値を保持。 |
| D3 | `autoplay.py` の10・3・2を名前付き定数にし、節目条件も含めて `progression.json` と照合。試験用コピーの該当5項目を個別に変えると照合は失敗する。 |

`300` の参照点は `progression.py` の生活日式、`clock.py:26` の朝区分、`life.py:161` と `state.py:27` の次の5:00を示す `awake_deadline`。`autoplay.py` の生活日計算は `life_day` を使用。朝区分と締切は生活日の丸めではないため、そのまま維持した。

## T-1〜T-9 の試験

| 要件 | 追加した主な試験 |
|---|---|
| T-1 | `test_d1_a_b_c_asleep_can_reach_five_and_save_then_reset_after_sleep`、`test_d1_d_only_exact_five_changes_and_doze_days_remain_stable` |
| T-2 | `test_a11_all_seven_sources_have_configured_amount`、`test_a11_repeated_sources_respect_per_day_limits`、既存 `test_a10_a11_a13_sources_per_day_and_daily_cap` |
| T-3 | `test_a13_a31_maho_touch_continuation_and_desire_max`、`test_a13_hold_mug_is_not_exposed_in_007` |
| T-4 | `test_a32_private_completion_and_deadline_cancel` |
| T-5 | `test_a41_busy_day_skips_doze_and_a46_private_delays_bedtime` |
| T-6 | `test_a51_clear_then_400_operations_across_bedtime_two_seeds`。seed 11・37、各400公開操作、23:30通過。 |
| T-7 | `test_a70_real_v62_saves_resume_resave_and_adopt`。v6.2実物2件。 |
| T-8 | `test_a72_adopt_refused_with_offer_or_private`、`test_a73_real_v62_log_reports_rule_mismatch` |
| T-9 | `test_a43_wake_and_a49_a62_cheat_leave_unrelated_values` |

判定対象は `choose`、JSONコマンド、保存・読込・原稿更新、CLI再生から確認した。内部状態を準備に使ったのは、D1-d の旧関数との比較、T-4 の中断時刻、T-5 の二人の時間中の23:30、T-3 の欲求上限直前のみ。これらの後の判定は公開操作で行った。既存試験は変更していない。

## 検証

- Windows 版 Python 3.12.14 で全試験 **180件成功**。`tools/check_runtime.py` も同じ全試験に成功。結果は `verification/results.json` と `test_results.txt`。
- `tools/verify_text.py --release interaction_006` と `--release interaction_007` は各5シードで完走・再生一致。
- `tools/audit_autoplay_immersion.py --release interaction_007 --policy presence --seeds 20` は20シードでエラーなく `cleared`。
- `tools/check_progression_routes.py` は30経路すべて `cleared`・再現一致。節目は全件 `[1, 2, 4, 9]` 日。v7.0.3 の30経路との差分は0件。
- v7.0.3 のZIP起動ログ `runs/zip_smoke.jsonl` は新本体で `replay_verified: true`。本体ハッシュは修正により異なるが原稿ハッシュは一致。旧 rules 2.2 の実物ログは `rules_version_mismatch` を返した。
- 作成したZIPを別フォルダーに展開し、seed 42 の自動プレイが136操作で `cleared`、そのログが `replay_verified: true` と一致した。展開先の `start.bat` は終了入力まで起動成功し、`start_test.bat` は `チート 全開放` → `状態` で親密度表示と `private.begin` を確認した。
- Windows の `start.bat` はユーザー環境で、ZIP展開後にダブルクリックし起動画面が出ること、`start_test.bat` で `チート 全開放` → `状態` が使えること、通常起動の `状態` に親密度・欲求が出ないことを確認できる。CLIでは `python -m nagishima --seed 11`、`python -m nagishima --seed 11 --test-cheats`。

同じ4操作（`menu.talk`、`touch.talk`、`menu.main`、`wait.30`）を新規ゲームから各20回、起動時間を除いて計測した。単位はミリ秒。Windows上の参考値で、負荷状況に左右される。

| 操作 | 006 中央値 / p95 | 007 中央値 / p95 |
|---|---:|---:|
| menu.talk | 13.05 / 17.19 | 12.98 / 17.45 |
| touch.talk | 16.20 / 20.41 | 16.56 / 21.05 |
| menu.main | 5.18 / 6.71 | 5.91 / 7.21 |
| wait.30 | 6.54 / 10.35 | 6.85 / 11.02 |

## 独自判断・未解決・提案

- 旧 v6.2 セーブは擬似データに頼らず、v6.2 本体で実際に作成した2件を同梱した。作成経路は `tests/fixtures/README.md`。
- `interaction_007` は `touch.hold_mug` を公開メニューに出さない。T-3 の「カップを持つと増えない」は公開操作で検証不能であり、公開操作として拒否されることと値が変わらないことを確認した。公開原稿を変えない条件のため、行動を追加していない。Opusに受入可否の判断を求める。
- `story_completed` は007の内容では身の上話が1種類のみ。再読で追加獲得しないことは公開操作で確認したが、別の身の上話による `per_day = 1` 超過は作れない。ほかの繰り返し可能な発生源は公開操作で上限を確認した。
- Linux と真のASCIIロケール `LANG=C` は、このWindows環境にLinuxディストリビューションがないため実行できていない。Windowsでの全試験・本文・自動プレイ・再生結果は上記のとおり。Linux CIまたは別環境で同じ `python -m unittest discover -s tests -q` を実施する必要がある。
- 範囲外の提案：`hold_mug` を007の遊び方に出すか、A-13の対象から除くかを仕様側で決める。今回は実装しない。
