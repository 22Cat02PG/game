"""段階C（010、v8.5.10）：「頼む」。仕様 docs/凪島_段階C_仕様_2026-10-08.md の第20節。決まりは intimacy.json の ask 節。
いつもの時間（真帆と一緒、恋人、起きている）の「触れ合う」から頼む。場所は分類（家・職場・野外・町）で見る（v8.5.11：島の町を足した。仕様 第21.4節）。
- 連れて帰る（carry。v8.5.11）：町では、大胆の段でなければ、真帆が家（主人公の部屋）へ連れて帰ってからしてくれる（ask.serve.<種類>.begin.town_home。帰る分の時間も足す）。
- 見せて（show）：その場でこっそり見せてもらう（一瞬。部位は書かない）。返事は上から：
  1日の回数（淫乱度の段ごと）を超えた最初の一回は「今日はもうおしまい」（ask.show.enough。その日はあとグレーアウト）／
  その場所で受ける段に届いていなければ断る（ask.show.decline.<場所>）／中まで（段と、下着を見せた回数がそろえば。ask.show.<場所>.inside）／下着（ask.show.<場所>.under）。
  見せたら欲求が上がる。
- してもらう（serve：hand／mouth）：その場（職場・野外は隠れられる所へ。本文が書く）で短く。一回出したら終わり（ask_play）。
  返事は上から：1日の回数を超えた最初の一回（ask.serve.decline.enough）／場所の段に届いていない（ask.serve.decline.<場所>）／気分（decline_when。ask.serve.decline.mood）／受ける（ask.serve.<種類>.begin.<場所>）。
  受けたら「続けてもらう」で高まりが上がり（ask.serve.<種類>.step、段 low／mid／high）、finish_from から「出す」（ask.serve.<種類>.finish）、max ではもう続けられない。
  出したら余力 −1、真帆は満たされないので欲求が上がり、態度で見せる一言（ask.serve.close.<場所>。約束はしない）。エッチの回数・淫乱度には数えない。
  就寝の区切りは越えてよい。仕事の始まりもまたいで進められる（エッチと同じ）が、頼むときに次の仕事まで need_minutes 分ないならグレーアウト。
- グレーアウト（理由つき）：時間が足りない・余力がない・雨の野外・続けて頼んだ（interval）・断られたばかり・今日はもうおしまい。
  回数で開く口（tier_from）は、開くまで出さない（エッチの中と同じ。理由 h_tier）。"""
from .conditions import evaluate
from .errors import GameError, ensure
from .intimacy_rules import check, number
from .progression import change_desire, life_day

BANDS = ("shy", "open", "eager", "bold")
TIERS = ("first", "few", "familiar")
SLOTS = ("morning", "noon", "evening", "night")
KINDS = ("hand", "mouth")
LEVELS = ("under", "inside")
LABELS = ("show", "hand", "mouth", "next", "finish", "stop")
PLAY_BANDS = ("low", "mid", "high")


def _band(value, label):
    ensure(value in BANDS, "intimacy_data", f"頼むの{label}の段が不正。")
    return value


def _by_band(raw, label, low=0, high=20):
    check(raw, [], list(BANDS))
    return {k: number(v, low, high) for k, v in raw.items()}


class AskRules:
    def __init__(self, raw):
        check(raw, ["_note", "min_stage", "places", "spots", "rain_blocked", "labels", "show", "serve"], ["carry"])
        self.min_stage = number(raw["min_stage"], 0, 4)
        ensure(type(raw["places"]) is dict and raw["places"], "intimacy_data", "頼むの場所の分類が不正。")
        self.place_of = {}
        for cat, locations in raw["places"].items():
            ensure(type(cat) is str and type(locations) is list and locations and all(type(v) is str for v in locations), "intimacy_data", "頼むの場所の分類が不正。")
            for location in locations:
                ensure(location not in self.place_of, "intimacy_data", "頼むの場所が二つの分類に入っている。")
                self.place_of[location] = cat
        self.places = list(raw["places"])
        ensure(type(raw["spots"]) is dict and all(type(v) is str and 1 <= len(v) <= 12 and k in self.place_of for k, v in raw["spots"].items()), "intimacy_data", "頼むの隠れられる所が不正。")
        self.spots = raw["spots"]
        ensure(type(raw["rain_blocked"]) is list and set(raw["rain_blocked"]) <= set(self.places), "intimacy_data", "雨で頼めない場所の分類が不正。")
        self.rain_blocked = frozenset(raw["rain_blocked"])
        check(raw["labels"], list(LABELS))
        ensure(all(type(v) is str and 1 <= len(v) <= 40 for v in raw["labels"].values()), "intimacy_data", "頼むの選択肢の名前が不正。")
        self.labels = raw["labels"]
        show = raw["show"]
        check(show, ["minutes", "interval", "quiet", "desire", "daily", "under_from", "inside_from", "inside_after"])
        self.show = {"minutes": number(show["minutes"], 1, 30), "interval": number(show["interval"], 0, 600), "quiet": number(show["quiet"], 0, 600),
                     "desire": number(show["desire"], 0, 50), "daily": _by_band(show["daily"], "見せての回数", 1, 20),
                     "under_from": self._from(show["under_from"], "見せて（下着）"), "inside_from": self._from(show["inside_from"], "見せて（中）"),
                     "inside_after": number(show["inside_after"], 0, 50)}
        ensure(set(self.show["daily"]) == set(BANDS), "intimacy_data", "見せての1日の回数は、淫乱度の段ごとに書く。")
        serve = raw["serve"]
        check(serve, ["kinds", "from", "daily", "interval", "quiet", "need_minutes", "begin_minutes", "step_minutes", "finish_minutes", "finish_from", "max", "desire_after", "decline_when"])
        check(serve["kinds"], list(KINDS))
        self.kinds = {}
        for kind, row in serve["kinds"].items():
            check(row, ["tier_from", "gain"])
            ensure(row["tier_from"] in TIERS, "intimacy_data", "頼むの慣れの段が不正。")
            self.kinds[kind] = {"tier_from": row["tier_from"], "gain": number(row["gain"], 1, 100)}
        self.serve = {"from": self._from(serve["from"], "してもらう"), "daily": _by_band(serve["daily"], "してもらうの回数", 1, 20),
                      "interval": number(serve["interval"], 0, 600), "quiet": number(serve["quiet"], 0, 600), "need_minutes": number(serve["need_minutes"], 0, 180),
                      "begin_minutes": self._per_place(serve["begin_minutes"], "始めるまでの分"), "step_minutes": number(serve["step_minutes"], 1, 30),
                      "finish_minutes": number(serve["finish_minutes"], 1, 30), "finish_from": number(serve["finish_from"], 1, 100), "max": number(serve["max"], 1, 100),
                      "desire_after": number(serve["desire_after"], 0, 100), "decline_when": serve["decline_when"]}
        ensure(self.serve["finish_from"] <= self.serve["max"], "intimacy_data", "出せる値が上限を超えている。")
        # v8.5.11：連れて帰る（町）。その分類で below の段に届かないときは、真帆が to の場所へ連れて行き（minutes 分）、そこでしてくれる
        self.carry = {}
        for cat, row in raw.get("carry", {}).items():
            check(row, ["to", "minutes", "below"])
            ensure(cat in self.places and type(row["to"]) is str and row["to"] in self.place_of and self.place_of[row["to"]] != cat, "intimacy_data", "連れて帰る決まりが不正。")
            self.carry[cat] = {"to": row["to"], "minutes": number(row["minutes"], 0, 60), "below": _band(row["below"], "連れて帰る")}
        ensure(type(self.serve["decline_when"]) is dict, "intimacy_data", "してもらうを断る条件が不正。")

    def _per_place(self, raw, label):
        ensure(type(raw) is dict and set(raw) == set(self.places), "intimacy_data", f"頼むの{label}は場所の分類ごとに書く。")
        return {k: number(v, 0, 30) for k, v in raw.items()}

    def _from(self, raw, label):
        """場所の分類ごとに、受ける淫乱度の段。分類の値は段か、時間帯（world.slot）ごとの段。"""
        ensure(type(raw) is dict and set(raw) == set(self.places), "intimacy_data", f"{label}の受ける段は場所の分類ごとに書く。")
        result = {}
        for cat, value in raw.items():
            if type(value) is dict:
                ensure(set(value) == set(SLOTS), "intimacy_data", f"{label}の時間帯ごとの段が不正。")
                result[cat] = {slot: _band(v, label) for slot, v in value.items()}
            else:
                result[cat] = _band(value, label)
        return result

    def needed(self, table, cat, slot):
        value = table[cat]
        return value[slot] if type(value) is dict else value

    def meanings(self):
        result = ["ask.show.enough"] + ["ask.show.decline." + c for c in self.places] + [f"ask.show.{c}.{level}" for c in self.places for level in LEVELS]
        result += ["ask.serve.decline.enough", "ask.serve.decline.mood", "ask.serve.stop"] + ["ask.serve.decline." + c for c in self.places]
        result += ["ask.serve.close." + c for c in self.places]
        for kind in self.kinds:
            result += [f"ask.serve.{kind}.begin.{c}" for c in self.places] + [f"ask.serve.{kind}.step", f"ask.serve.{kind}.finish"]
            result += [f"ask.serve.{kind}.begin.{c}_home" for c in self.carry]  # v8.5.11：町から家へ連れて帰ってから
        return result

    def check_content(self, fields, meanings, validate_condition, catalog):
        validate_condition(self.serve["decline_when"], fields)
        ensure(set(self.place_of) <= set(catalog["locations"]), "intimacy_data", "頼むの場所が未登録。")
        missing = [m for m in self.meanings() if m not in meanings]
        ensure(not missing, "meaning", "頼むの本文の意味が未登録：" + "、".join(missing[:5]))


def _record(state):
    """その暮らしの日の頼むの記録（日が変われば数え直す）。保存の形は validate_ask を見る。"""
    today = life_day(state["world"]["now"])
    record = state.get("ask") or {"day": today, "shown": 0, "served": 0, "enough": [], "last_show": None, "last_serve": None, "declined": None, "under": 0, "inside": 0}
    if record["day"] != today:
        record = dict(record, day=today, shown=0, served=0, enough=[])
    return record


def ask_place(state, pack):
    rules = pack.intimacy.ask
    return rules.place_of.get(state["actors"]["player"]["location"])


def ask_listed(state, pack):
    """頼むの選択肢を並べるか（恋人で、いつもの時間に真帆と一緒、起きている、頼める場所）。並べたうえで選べない理由はグレーアウト。"""
    rules = pack.intimacy.ask
    player, maho = state["actors"]["player"], state["actors"]["maho"]
    return (state["mode"] == "normal" and not state["scene"] and not state["offer"] and state["relation"]["stage"] >= rules.min_stage
            and state["maho_sleep"]["state"] == "awake" and player["location"] == maho["location"] and player["location"] in rules.place_of
            and not any(state.get(k) for k in ("sleep_play", "event_play", "co_sleep", "ask_play")))


class Ask:
    @property
    def ar(self):
        rules = self.pack.intimacy.ask if self.pack.intimacy else None
        ensure(rules is not None, "ask", "この原稿版に「頼む」は登録されていない。")
        return rules

    def _ask_common(self, quiet):
        rules = self.ar
        self.free()
        self.require_awake()
        ensure(ask_listed(self.s, self.pack), "ask", "今は頼めない。")
        ensure(not self.at_work(), "work_time", "仕事の最中は頼めない。")
        from . import clock
        cat = ask_place(self.s, self.pack)
        if cat in rules.rain_blocked and clock.weather(self.s["world"]["seed"], self.now // 1440) == "rain":
            raise GameError("weather", "雨の日は、外では頼めない。")
        record = _record(self.s)
        if record["declined"] is not None and self.now - record["declined"] < quiet:
            raise GameError("h_quiet", "さっき断られたばかりだ。少し時間を置く。")
        return rules, cat, record

    def _ask_lewd(self):
        return self.ir.lewd_band(self.s["intimacy_history"]["lewdness"])

    def _ask_below(self, band, needed):
        return BANDS.index(band) < BANDS.index(needed)

    def ask_show(self):
        rules, cat, record = self._ask_common(self.ar.show["quiet"])
        show = rules.show
        if "show" in record["enough"]:
            raise GameError("ask_enough", "今日はもうおしまいと言われた。")
        if record["last_show"] is not None and self.now - record["last_show"] < show["interval"]:
            raise GameError("ask_interval", "さっき見せてもらったばかりだ。")
        from . import clock
        band, slot = self._ask_lewd(), clock.slot(self.now)
        self.require_time(show["minutes"])
        self.s["contacts"], self.s["interaction_streak"] = [], None
        if record["shown"] >= show["daily"][band]:
            record["enough"] = sorted(set(record["enough"]) | {"show"})
            self.s["ask"] = record
            self.emit("ask.show.enough")
            return
        if self._ask_below(band, rules.needed(show["under_from"], cat, slot)):
            record["declined"] = self.now
            self.s["ask"] = record
            self.emit("ask.show.decline." + cat)
            return
        inside = not self._ask_below(band, rules.needed(show["inside_from"], cat, slot)) and record["under"] >= show["inside_after"]
        level = "inside" if inside else "under"
        self.emit(f"ask.show.{cat}.{level}")  # 本文は、見せる前の回数で書き分ける（ask.under・ask.inside）
        self.advance(show["minutes"])
        record["shown"] += 1
        record[level] += 1
        record["last_show"] = self.now
        self.s["ask"] = record
        if self.pack.progression and show["desire"]:
            change_desire(self.s, self.pack.progression, show["desire"])

    def ask_serve(self, kind):
        rules = self.ar
        ensure(kind in rules.kinds, "ask", "頼む中身が違う。")
        tier = self.ir.tier(self.s["intimacy_history"]["count"], self.pack.life)
        if TIERS.index(tier) < TIERS.index(rules.kinds[kind]["tier_from"]):
            raise GameError("h_tier", "もう少し回数を重ねてから。")  # 開くまで一覧に出さない
        rules, cat, record = self._ask_common(rules.serve["quiet"])
        serve = rules.serve
        ensure(self.s["stamina"]["value"] > 0, "h_player", "余力が尽きた。")
        if "serve" in record["enough"]:
            raise GameError("ask_enough", "今日はもうおしまいと言われた。")
        if record["last_serve"] is not None and self.now - record["last_serve"] < serve["interval"]:
            raise GameError("ask_interval", "さっきしてもらったばかりだ。")
        from . import clock
        band, slot = self._ask_lewd(), clock.slot(self.now)
        carry = rules.carry.get(cat)
        carried = carry is not None and self._ask_below(band, carry["below"])  # v8.5.11：町では、大胆の段でなければ家へ連れて帰ってから
        extra = carry["minutes"] if carried else 0
        work = self.minutes_to_work(serve["need_minutes"] + extra + 1)
        if work is not None:
            raise GameError("work_time", f"次の仕事まであと{work}分。時間が足りない。")
        self.require_time(serve["begin_minutes"][rules.place_of[carry["to"]] if carried else cat] + extra)
        self.s["contacts"], self.s["interaction_streak"] = [], None
        limit = serve["daily"].get(band)
        if limit is not None and record["served"] >= limit:
            record["enough"] = sorted(set(record["enough"]) | {"serve"})
            self.s["ask"] = record
            self.emit("ask.serve.decline.enough")
            return
        if self._ask_below(band, rules.needed(serve["from"], cat, slot)):
            record["declined"] = self.now
            self.s["ask"] = record
            self.emit("ask.serve.decline." + cat)
            return
        if evaluate(serve["decline_when"], self.pack.registry.values(self.s)) is True:
            record["declined"] = self.now
            self.s["ask"] = record
            self.emit("ask.serve.decline.mood")
            return
        self.s["ask"] = record
        self.s["distance"] = "near"
        if carried:
            # v8.5.11：真帆が「ここじゃ無理」と、家（carry.to）へ連れて帰ってからしてくれる（本文が帰り道まで書く）
            home = rules.place_of[carry["to"]]
            for actor in self.s["actors"].values():
                actor["location"], actor["posture"] = carry["to"], "seated"
            self.s["ask_play"] = {"kind": kind, "place": home, "started_at": self.now, "arousal": 0, "steps": 0}
            self.emit(f"ask.serve.{kind}.begin.{cat}_home")
            self._ask_advance(extra + serve["begin_minutes"][home])
            return
        self.s["ask_play"] = {"kind": kind, "place": cat, "started_at": self.now, "arousal": 0, "steps": 0}
        self.emit(f"ask.serve.{kind}.begin.{cat}")
        self._ask_advance(serve["begin_minutes"][cat])

    def _ask_advance(self, minutes):
        """してもらっているあいだは、仕事の始まりもまたいで進める（エッチと同じ。終えたあとの締めで仕事へ向かう）。"""
        advancing = getattr(self, "_work_advancing", False)
        self._work_advancing = True
        try:
            self.require_time(minutes)
            self.advance(minutes)
        finally:
            self._work_advancing = advancing

    def _ask_state(self):
        play = self.s.get("ask_play")
        ensure(play is not None, "ask", "今は選べない。")
        return play, self.ar

    def ask_next(self):
        play, rules = self._ask_state()
        serve = rules.serve
        ensure(play["arousal"] < serve["max"], "ask", "もうこらえきれない。")
        play["steps"] += 1
        play["arousal"] = min(serve["max"], play["arousal"] + rules.kinds[play["kind"]]["gain"])
        self.emit(f"ask.serve.{play['kind']}.step")  # 本文は上がったあとの段（ask.band）で書き分ける
        self._ask_advance(serve["step_minutes"])

    def ask_finish(self):
        play, rules = self._ask_state()
        serve = rules.serve
        ensure(play["arousal"] >= serve["finish_from"] and self.s["stamina"]["value"] > 0, "ask", "まだ出せない。")
        self.emit(f"ask.serve.{play['kind']}.finish")
        self._ask_advance(serve["finish_minutes"])
        self.emit("ask.serve.close." + play["place"])  # 真帆は満たされないまま。約束はせず、態度で見せる
        self.s["stamina"]["value"] -= 1
        record = _record(self.s)
        record["served"] += 1
        record["last_serve"] = self.now
        self.s["ask"] = record
        self.s["ask_play"] = None
        if self.pack.progression and serve["desire_after"]:
            change_desire(self.s, self.pack.progression, serve["desire_after"])

    def ask_stop(self):
        play, _ = self._ask_state()
        self.emit("ask.serve.stop")
        record = _record(self.s)
        record["last_serve"] = self.now
        self.s["ask"] = record
        self.s["ask_play"] = None


def ask_band(state, rules):
    """してもらっているときの、こちらの高まりの段（low・mid・high＝出せる）。してもらっていなければ low。"""
    play = state.get("ask_play")
    if not play:
        return "low"
    serve = rules.serve
    return "high" if play["arousal"] >= serve["finish_from"] else "mid" if play["arousal"] >= serve["finish_from"] // 2 + 5 else "low"
