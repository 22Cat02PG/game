"""4回目の試運転の指摘（v8.2.0）の試験。公開の選択肢から確かめる（時刻・欲求などの準備だけ内部で行う）。"""
import unittest

from tools.run_stage_b_routes import Route


def choices(route):
    return {c["id"]: c for c in route.engine.get_view()["choices"]}


def meanings(route):
    return [b["meaning"] for b in route.engine.get_view()["blocks"]]


def touch(route, key):
    while route.engine.snapshot()["offer"]:
        route.choose("offer.accept" if route.engine.snapshot()["offer"]["kind"] == "kiss_back" else "offer.decline")
    if route.engine.get_view()["page"] != "touch":
        route.choose("menu.touch")
    route.choose("touch." + key)


class Playtest4(unittest.TestCase):
    def route(self, *args, **kwargs):
        route = Route(*args, **kwargs)
        self.addCleanup(route.close)
        return route

    def kissed(self, route, desire):
        route.engine._state["desire"] = desire  # 準備
        route.engine._install_choices()
        route.choose("near")
        for key in ("kiss", "kiss", "kiss", "deep_kiss"):
            touch(route, key)
        while route.engine.snapshot()["offer"]:
            route.choose("offer.decline")

    def test_2_push_down_after_deep_kiss_when_her_mood_is_up(self):
        low = self.route(21, tier="few", hour=16, day_offset=3)
        self.kissed(low, 10)
        if low.engine.get_view()["page"] != "touch":
            low.choose("menu.touch")
        self.assertFalse(choices(low)["touch.push_down"]["available"])
        self.assertIn("深いキスで真帆の気分が高まってから", low.engine.get_view()["explanations"]["touch.push_down"])
        high = self.route(21, tier="few", hour=16, day_offset=3)
        self.kissed(high, 70)
        if high.engine.get_view()["page"] != "touch":
            high.choose("menu.touch")
        self.assertTrue(choices(high)["touch.push_down"]["available"])

    def test_4_dinner_waits_while_deep_touches_continue(self):
        route = self.route(22, tier="few", hour=18, minute=20, day_offset=3, dinner=True)
        self.kissed(route, 10)
        self.assertIn("deep_kiss", [c["action_id"] for c in route.engine.snapshot()["contacts"]])
        for _ in range(8):  # 深いキスを続けて夕食の時間帯（18:30〜）に入る
            touch(route, "deep_kiss")
            self.assertNotIn("life.dinner", meanings(route))
        self.assertGreaterEqual(route.engine.snapshot()["world"]["now"] % 1440, 18 * 60 + 30)
        route.choose("end.deep_kiss")  # 触れ合うのページの「やめる」
        self.assertIn("life.dinner", meanings(route))  # やめたら夕食

    def test_5_finger_touch_from_the_starting_seated_position(self):
        route = self.route(23, tier="few", day_offset=2)
        route.begin()
        for _ in range(12):
            if route.engine.snapshot()["intimacy"]["maho"]["arousal"] >= 40:
                break
            route.action("h_kiss_deep")
        for key in ("h_strip_lower", "h_shift_under"):
            route.action(key)
        self.assertEqual(route.engine.snapshot()["intimacy"]["position"], "sitting_close")
        route.action("h_touch_direct")
        self.assertTrue(any(m.startswith("h_touch_direct.") for m in meanings(route)))

    def test_7_position_moves_are_listed_where_an_action_needs_them(self):
        route = self.route(24, tier="few", day_offset=2)
        route.begin()
        for _ in range(12):
            if route.engine.snapshot()["intimacy"]["maho"]["arousal"] >= 60:
                break
            route.action("h_kiss_deep")
        for key in ("h_strip_lower", "h_shift_under", "h_strip_self"):
            route.action(key)
        self.assertEqual(route.engine.snapshot()["intimacy"]["position"], "sitting_close")
        route.choose("menu.main")
        route.choose("menu.h_connect")
        rows = choices(route)
        self.assertFalse(rows["touch.h_insert"]["available"])  # 寄り添って座ったままでは入れない
        self.assertTrue(rows["touch.h_pos_player_above"]["available"])  # その場に体位の変更が並ぶ
        self.assertTrue(rows["touch.h_pos_player_above"]["label"].startswith("体位を変える："))
        self.assertIn("menu.h_position", rows)  # ほかのページへ直接移れる
        route.choose("touch.h_pos_player_above")
        self.assertEqual(route.engine.get_view()["page"], "h_connect")
        self.assertTrue(choices(route)["touch.h_insert"]["available"])
        route.choose("touch.h_insert")
        self.assertTrue(route.engine.snapshot()["intimacy"]["inserted"])

    def test_6_lying_face_connects_with_its_own_texts(self):
        """指摘6（v8.2.1、grok 第5陣）：向かい合って横になったまま入れて動き、出せる。"""
        route = self.route(25, tier="few", day_offset=2)
        route.begin()
        for _ in range(12):
            if route.engine.snapshot()["intimacy"]["maho"]["arousal"] >= 60:
                break
            route.action("h_kiss_deep")
        for key in ("h_strip_lower", "h_shift_under", "h_strip_self", "h_pos_lying_face"):
            route.action(key)
        route.choose("menu.main")
        route.choose("menu.h_connect")
        self.assertTrue(choices(route)["touch.h_insert"]["available"])
        found = []
        keys = ["h_insert", "h_move_slow"]
        for key in keys:
            route.action(key)
            found += [b["variant"] for b in route.engine.get_view()["blocks"] if b["meaning"].startswith(key + ".")]
        for _ in range(8):  # v8.2.29：入れてから出せる高さまでを長くした
            if route.engine.snapshot()["intimacy"]["player"]["arousal"] >= 70:
                break
            first = not any(v.startswith(("p5.h_move_normal", "x3.h_move_normal", "x4.h_move_normal")) for v in found)
            route.action("h_move_normal")
            if first:  # 続けた手の短い1行（声だけの行など）は体位を書かないので、始めの本文だけを見る
                found += [b["variant"] for b in route.engine.get_view()["blocks"] if b["meaning"].startswith("h_move_normal.")]
        route.action("h_finish_inside")
        found += [b["variant"] for b in route.engine.get_view()["blocks"] if b["meaning"].startswith("h_finish_inside.")]
        self.assertEqual(route.engine.snapshot()["intimacy"]["position"], "lying_face")
        self.assertTrue(found and all(".lying_face." in v for v in found), found)  # 第5陣（p5.）か、高まったときの濃い本文（x3.・x4.）


if __name__ == "__main__":
    unittest.main()
