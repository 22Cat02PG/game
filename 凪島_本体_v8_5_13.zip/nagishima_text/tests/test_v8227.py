"""v8.2.27（ユーザー 2026-09-30「じゃあ修正して」）：精査 D-5 の判断。山場の出し分けの仕組みはそのまま（初めての回は真帆がまだ中くらい、
真帆が高まっていれば手つきが濃いのは自然）。こちらの高まりを決めつける1本だけ、こちらが後半のときに限る。"""
import unittest
from pathlib import Path

from nagishima.content import Pack

ROOT = Path(__file__).resolve().parents[1]
LATE = {"field": "intimacy.player.arousal_band", "op": "in", "value": ["ready", "max"]}


class V8227(unittest.TestCase):
    def test_feet_ready_line_waits_for_player(self):
        pack = Pack(ROOT / "content/releases/interaction_009")
        source = "x8.h_maho_feet.continue.familiar.s.v4"
        self.assertIn("出そう", pack.by_text[source]["body"])
        self.assertIn(LATE, pack.by_text[source]["when"]["all"])
        for cut in ("sh.", "sh2."):
            conditions = pack.by_text[cut + source]["when"]["all"]
            self.assertEqual(conditions.count(LATE), 1, cut)  # 熱さの札と同じ条件は重ねない


if __name__ == "__main__":
    unittest.main()
