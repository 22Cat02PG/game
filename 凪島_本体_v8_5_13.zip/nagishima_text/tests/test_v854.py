"""v8.5.4（ユーザー 2026-10-08「君はイベントエッチのほう進めて」）：010 だけ。段階C の五歩目：野外（イベントの型）。
仕様 docs/凪島_段階C_仕様_2026-10-08.md の第9節・第17節。"""
import unittest
from pathlib import Path

from nagishima.content import Pack
from tools.run_stage_b_routes import Route

ROOT = Path(__file__).resolve().parents[1]
P009 = Pack(ROOT / "content/releases/interaction_009")
P010 = Pack(ROOT / "content/releases/interaction_010")


def outdoor_route(place="coast", desire=95, tier="familiar", seed=8, hour=21, minute=30, release="interaction_010", day_offset=0):
    """夕食・風呂を済ませた夜（既定 21:30）に、二人で屋外へ出たところ。"""
    route = Route(seed, hour=hour, minute=minute, tier=tier, release=release, day_offset=day_offset)
    route.engine._state["desire"] = desire
    route.engine._install_choices()
    route.choose("menu.move")
    route.choose("move.joint." + place)
    return route


def meanings(view):
    return [b["meaning"] for b in view["blocks"]]


def ids(view):
    return [c["id"] for c in view["choices"]]


def play(route):
    return route.engine.snapshot()["event_play"]


def until_notice(route, limit=12):
    for _ in range(limit):
        view = route.choose("event.pre.under")
        if any(m.startswith("ev.outdoor.notice.") for m in meanings(view)):
            return view
    raise AssertionError("反応しない")


def set_exposure(route, value):
    route.engine._state["event_play"]["exposure"] = value
    route.engine._install_choices()


class V854(unittest.TestCase):
    def test_009_has_no_outdoor(self):
        route = outdoor_route(release="interaction_009")
        self.assertNotIn("event.invite.outdoor", ids(route.engine.get_view()))
        route.close()

    def test_rules(self):
        outdoor = P010.intimacy.events.events["outdoor"]
        self.assertEqual(outdoor.entry["places"], ["coast", "pier", "garden"])
        self.assertEqual((outdoor.exposure["warn_at"], outdoor.exposure["max"], outdoor.exposure["hush"], outdoor.exposure["calm"]), (50, 100, -30, 20))
        self.assertEqual(outdoor.return_to["location"], "living_room")
        self.assertEqual(list(outdoor.positions), ["stand_face", "stand_back", "edge_lap"])
        for meaning in outdoor.meanings():
            self.assertIn(meaning, P010.meanings)
        for meaning in ("ev.outdoor.warn", "ev.outdoor.hush", "ev.outdoor.fix", "ev.outdoor.stop", "ev.outdoor.caught", "ev.outdoor.rumor"):
            self.assertIn(meaning, outdoor.meanings())
        for key in ("event.exposure", "event.h", "event.outdoor.count", "event.outdoor.days"):
            self.assertIn(key, P010.registry.fields)
        # 晩酌の入口は、書かなければ今までどおり（居間か台所で誘い、居間に座って始める）
        drink = P010.intimacy.events.events["drink"]
        self.assertEqual((drink.entry["places"], drink.entry["at"], drink.entry["posture"]), (["living_room", "kitchen"], "living_room", "seated"))

    def test_entry(self):
        """恋人で慣れ・夕食のあと 19:00〜23:00・雨でない日・海岸／桟橋／庭で真帆と二人のときだけ。家の中・慣れの前・早い時刻・雨の日には出ない。"""
        route = Route(8, hour=21, minute=30, tier="familiar", release="interaction_010")
        self.assertNotIn("event.invite.outdoor", ids(route.engine.get_view()))  # 居間
        route.close()
        for kwargs in ({"tier": "few"}, {"hour": 18, "minute": 0}, {"day_offset": 1}):  # 慣れの前・夕食の前・雨の日
            route = outdoor_route(**kwargs)
            self.assertNotIn("event.invite.outdoor", ids(route.engine.get_view()), kwargs)
            route.close()
        route = outdoor_route(place="garden")
        view = route.choose("event.invite.outdoor")
        self.assertIn("ev.outdoor.begin", meanings(view))
        self.assertEqual(view["page_title"], "庭の物陰")
        self.assertEqual(play(route)["exposure"], 5)  # 庭・夜の始まり
        self.assertEqual(route.engine.get_view()["status"]["event"]["exposure"], "人の気配はない")
        until_notice(route)
        route.choose("event.accept")
        self.assertEqual([i for i in ids(route.engine.get_view()) if i.startswith("event.pos.")], ["event.pos.stand_face", "event.pos.stand_back"])  # 庭に縁はない
        route.close()

    def test_deflect_and_decline_go_home(self):
        """欲求が低ければ「部屋に戻ろ」、「ここで……？」に「やっぱり家に戻ろう」と返しても、二人で家へ戻って終わる。"""
        for desire, last in ((0, "ev.outdoor.notice.deflect"), (95, "ev.outdoor.offer.decline")):
            route = outdoor_route(desire=desire)
            route.choose("event.invite.outdoor")
            view = until_notice(route)
            if desire:
                self.assertIn("ev.outdoor.notice.invite", meanings(view))
                view = route.choose("event.decline")
            self.assertEqual(meanings(view)[-1], last)
            state = route.engine.snapshot()
            self.assertIsNone(state["event_play"])
            self.assertEqual((state["actors"]["player"]["location"], state["actors"]["maho"]["location"]), ("living_room", "living_room"))
            self.assertNotIn("outdoor", state.get("event_record", {}))
            self.assertNotIn("event.invite.outdoor", ids(view))
            route.close()

    def test_warn_hush_and_caught(self):
        """人目が 50 に届くと足音が近づく（息を殺す／急いで服を直す／やめる）。息を殺しても 20 より下がらなければ、次は近づかずに 100 で見つかりかけて終わる。"""
        route = outdoor_route()
        route.choose("event.invite.outdoor")
        set_exposure(route, 49)
        view = route.choose("event.pre.kiss")
        self.assertEqual(meanings(view)[-1], "ev.outdoor.warn")
        self.assertEqual((play(route)["phase"], play(route)["resume"]), ("warn", "pre"))
        self.assertEqual(ids(view), ["event.hush", "event.fix", "event.stop"])
        self.assertEqual(route.engine.get_view()["status"]["event"]["exposure"], "足音が近い")
        view = route.choose("event.hush")
        self.assertIn("ev.outdoor.hush", meanings(view))
        self.assertEqual((play(route)["phase"], play(route)["exposure"], play(route)["warned"]), ("pre", 20, True))
        set_exposure(route, 97)
        view = route.choose("event.pre.under")
        self.assertEqual(meanings(view)[-1], "ev.outdoor.caught")
        state = route.engine.snapshot()
        self.assertIsNone(state["event_play"])
        self.assertEqual(state["actors"]["maho"]["location"], "living_room")
        route.close()

    def test_warn_during_h_and_fix(self):
        """入れている最中に足音が近づき、急いで服を直して家へ戻る。エッチまで進んだので記録する。"""
        route = outdoor_route()
        route.choose("event.invite.outdoor")
        until_notice(route)
        route.choose("event.accept")
        route.choose("event.pos.stand_back")
        route.choose("event.next")
        route.choose("event.insert")
        set_exposure(route, 57)
        view = route.choose("event.move.fast")
        self.assertEqual(meanings(view)[-1], "ev.outdoor.warn")
        self.assertTrue(route.engine.pack.registry.values(route.engine.snapshot())["event.h"])
        view = route.choose("event.fix")
        self.assertEqual(meanings(view)[-1], "ev.outdoor.fix")
        state = route.engine.snapshot()
        self.assertIsNone(state["event_play"])
        self.assertEqual(state["event_record"]["outdoor"]["count"], 1)
        route.close()

    def test_h_and_rumor(self):
        """物陰のエッチ → 家へ戻る（10分） → 翌朝の仕事で、島の人に遠回しに言われる（割合は data の percent。ここでは 100 にして確かめる）。"""
        route = outdoor_route(place="pier")  # 晴れの水曜（翌日は仕事）
        rule = route.engine.pack.intimacy.events.events["outdoor"].rumor
        saved = dict(rule)
        try:
            rule["percent"] = 100
            route.choose("event.invite.outdoor")
            until_notice(route)
            route.choose("event.accept")
            view = route.choose("event.pos.edge_lap")
            self.assertIn("ev.outdoor.pos.edge_lap", meanings(view))
            route.choose("event.next")
            route.choose("event.insert")
            for _ in range(20):
                if not play(route) or "event.finish.inside" in ids(route.engine.get_view()):
                    break
                if play(route)["phase"] == "warn":
                    route.choose("event.hush")
                else:
                    route.choose("event.move.slow")
            view = route.choose("event.finish.inside")
            self.assertTrue(meanings(view)[-1].startswith("ev.outdoor.end."))
            state = route.engine.snapshot()
            self.assertEqual((state["actors"]["player"]["location"], state["actors"]["player"]["posture"]), ("living_room", "seated"))
            self.assertEqual(state["event_record"]["outdoor"]["count"], 1)
            route.choose("sleep")
            for _ in range(6):
                if "work.go" in ids(route.engine.get_view()):
                    break
                route.choose("wait.30")
            view = route.choose("work.go")
            self.assertIn("ev.outdoor.rumor", meanings(view))
            for _ in range(12):
                if "work.go" in ids(route.engine.get_view()):
                    break
                route.choose("wait.30")
            view = route.choose("work.go")
            self.assertNotIn("ev.outdoor.rumor", meanings(view))  # その日の二度目の仕事では出さない
        finally:
            rule.clear()
            rule.update(saved)
            route.close()


if __name__ == "__main__":
    unittest.main()
