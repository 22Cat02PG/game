@echo off
chcp 65001 >nul
cd /d "%~dp0"
set PYTHONUTF8=1
if defined NAGISHIMA_PYTHON goto custom
py -3.12 -c "import sys" >nul 2>nul
if not errorlevel 1 goto launcher
python -c "import sys; assert sys.version_info >= (3,12)" >nul 2>nul
if not errorlevel 1 goto python
set "NAGISHIMA_PYTHON=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
if exist "%NAGISHIMA_PYTHON%" goto custom
echo Python 3.12 or later is required. 1>&2
exit /b 2
:launcher
py -3.12 -m nagishima %*
exit /b %errorlevel%
:python
python -m nagishima %*
exit /b %errorlevel%
:custom
"%NAGISHIMA_PYTHON%" -m nagishima %*
exit /b %errorlevel%
