"""Rebuild 009 inside a newly extracted distribution ZIP and compare every file."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import zipfile


def digests(path):
    return {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in path.iterdir() if p.is_file()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("zip", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    with tempfile.TemporaryDirectory(prefix="nagishima-009-zip-") as name:
        with zipfile.ZipFile(args.zip) as archive:
            if archive.testzip() is not None:
                raise SystemExit("ZIP CRC mismatch")
            archive.extractall(name)
        root = Path(name) / "nagishima_text"
        release = root / "content/releases/interaction_009"
        before = digests(release)
        # v8.3.0：009 は確定済み。別の場所に作って同じかを比べる（--verify）。作り直さないことも確かめる
        refused = subprocess.run([sys.executable, str(root / "tools/build_intimacy_release.py"), "--replace-unpublished"], cwd=root, capture_output=True)
        verified = subprocess.run([sys.executable, str(root / "tools/build_intimacy_release.py"), "--verify"], cwd=root, capture_output=True)
        after = digests(release) if refused.returncode != 0 and verified.returncode == 0 else {}
        result = {"zip": args.zip.name, "files": len(before), "identical": before == after,
                  "changed": [key for key in sorted(before.keys() | after.keys()) if before.get(key) != after.get(key)]}
    if args.output:
        args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False))
    return 0 if result["identical"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
