"""5回目の試運転の指摘（2026-09-27、v8.2.3）に合わせた grok への依頼（Opus）。

- 第7陣（p7.）：
  - 拭いてあげる（h_wipe.start）：最後に出した場所（中・外・手・口）× 慣れ。指摘5。
  - 入れていないときにこらえる（h_endure.hand＝真帆の手を止めてもらう、h_endure.mouth＝口を離してもらう）× 慣れ。指摘4。
  - 真帆が達した直後の敏感さ（h.sign.sensitive）× 慣れ × 入れているか。任された「達した直後の敏感さ」。
  いずれも Opus の本文（opus_texts_009.json の o7・o9・o10）がすでにあり、grok の本文はそれに足す（標準の本文。濃い版ではない）。

- 濃い版（x6.、v8.2.4 で足した）：限界のまま入れて、入れた途端にこらえきれずに中で出る（h_overflow.insert）× 慣れ × 向き。
  ユーザーの要望（「割と好まれてるシチュエーション」）。達する場面なので濃い本文が先に出る。Opus の本文（o11）がすでにある。

- 一気に奥まで入れる（h_insert_deep.start、v8.2.5 で足した。ユーザー了承 2026-09-28 06:09）：数回・慣れ × 向き。標準（p7.）と濃い版（x6.）。
  Opus の本文（o12）がすでにある。

出力：grok_b2_wave_7.json・grok_b2_wave_x6.json、grok依頼_B2_第7陣/（01〜04＝第7陣、05・06＝濃い版、07＝一気に奥まで・標準、08＝同・濃い版）、第7陣_一覧.json
"""
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
PROMPT = (OUT / "grokプロンプト_v3_0.txt").read_text(encoding="utf-8")
BED = "二人の個室のどちらか（どちらの部屋か、ベッドの上かどうかは書かない）"
TIER = {"first": "初回（1回目のエッチ）", "few": "数回（2〜5回目）", "familiar": "慣れ（6回目以降）", "few_familiar": "数回か慣れ（2回目以降）"}
TIER_WHEN = {"first": ("eq", "first"), "few": ("eq", "few"), "familiar": ("eq", "familiar"), "few_familiar": ("in", ["few", "familiar"])}
ANY_POSE = "書かない（どの体位のあとでも出る。寝ているか座っているか・向きも書かない）"
LOWER_OPEN = "真帆の下は、下着をずらしてあるか脱いでいる（下着について書かない）。こちらは下を脱いでいる"
rows = []


def job(meaning, tier, s, meaning_text, state, *, other=None, must_not=None, when=None, length="100〜160字"):
    identity = ".".join(["p7", meaning, tier] + ([other] if other else []) + [s])
    op, value = TIER_WHEN[tier]
    conditions = [{"field": "intimacy.tier", "op": op, "value": value}] + list(when or [])
    row = {"id": identity, "meaning": meaning_text, "speech": s == "s", "length": length, "origin": "主人公", "candidates": 5,
           "state": state, "_wave": "B2-7", "_meaning": meaning, "_split": {"tier": tier, "position": None, "other": other},
           "when": {"all": conditions}, "group": "b." + meaning}
    if must_not:
        row["must_not"] = must_not
    assert not any(r["id"] == identity for r in rows), identity
    rows.append(row)


# ---- 拭いてあげる（出したあと） ----
WIPE = {
    "inside": ("こちらが真帆の中で出したあと（もう抜いている）、真帆の脚のあいだをティッシュで拭いてあげる", ("first", "few_familiar")),
    "outside": ("こちらが真帆の外に出したあと、肌に散ったものをティッシュで拭いてあげる（どこに散ったか・誰の肌かは書かない）", ("first", "few_familiar")),
    "hand": ("真帆の手の中に出したあと、真帆の手をティッシュで拭いてあげる", ("first", "few_familiar")),
    "mouth": ("真帆の口の中に出したあと、真帆の口元を拭いてあげる（飲んだかどうかは書かない）", ("few_familiar",)),
}
WIPE_MUST = "もう一度始める・誘う。服を着る。体位を変える。部屋を出る。出した場面をもう一度書く"
for where, (text, tiers) in WIPE.items():
    for tier in tiers:
        for s in ("s", "n"):
            job("h_wipe.start", tier, s, text, {"場所": BED, "慣れ": TIER[tier], "体位": ANY_POSE, "服": LOWER_OPEN, "挿入": "していない",
                                              "主人公": "少し前に出した（もう高まってはいない）"},
                other=where, must_not=WIPE_MUST, when=[{"field": "intimacy.mess", "op": "eq", "value": where}])

# ---- 入れていないときにこらえる ----
ENDURE_MUST = "出す・果てる。入れる。体位を変える。真帆が台詞で出すことを促す（「出して」など）"
for tier in ("first", "few", "familiar"):
    for s in ("s", "n"):
        job("h_endure.hand", tier, s, "限界の手前で、真帆の手を止めてもらって、こらえる（出さない）",
            {"場所": BED, "慣れ": TIER[tier], "体位": "書かない（向かい合っている。寝ているか座っているかは書かない）", "服": "こちらは下を脱いでいる（真帆の服は書かない）",
             "続いている動作": "前の本文から、真帆が手でこちらのものを愛撫していた（この本文で止まる）", "挿入": "していない",
             "主人公": "もう限界だった。出すと決めてはいない"}, must_not=ENDURE_MUST)
for tier in ("few", "familiar"):
    for s in ("s", "n"):
        job("h_endure.mouth", tier, s, "限界の手前で、真帆に口を離してもらって、こらえる（出さない）",
            {"場所": BED, "慣れ": TIER[tier], "体位": "書かない（真帆がこちらの脚のあいだに顔を寄せている。寝ているか座っているかは書かない）", "服": "こちらは下を脱いでいる（真帆の服は書かない）",
             "続いている動作": "前の本文から、真帆が口でこちらのものを愛撫していた（この本文で口を離す）", "挿入": "していない",
             "主人公": "もう限界だった。出すと決めてはいない"}, must_not=ENDURE_MUST + "。口に含んだまま話す")

# ---- 真帆が達した直後の敏感さ ----
SENSITIVE_MUST = "もう一度達する。行為を止めさせる・やめる。体位を変える。こちらの行動を書く（前の本文で書いた）"
for tier in ("first", "few", "familiar"):
    for inserted, other, detail in ((True, "inserted", "している（こちらが動き続けている）"), (False, "not_inserted", "していない（こちらが指か口で触れ続けている。どちらかは書かない）")):
        for s in ("s", "n"):
            job("h.sign.sensitive", tier, s, "真帆が達した直後なのに、こちらが続けたので、敏感になった真帆の体が過敏に反応する（真帆の反応だけを書く）",
                {"場所": BED, "慣れ": TIER[tier], "体位": "書かない（向きも書かない）", "服": LOWER_OPEN, "挿入": detail,
                 "真帆": "ついさっき達したばかり（達したことは前の本文で書いた）"},
                other=other, must_not=SENSITIVE_MUST, when=[{"field": "intimacy.inserted", "op": "eq", "value": inserted}], length="60〜120字")

# ---- 濃い版（x6.）：限界のまま入れて、入れた途端に出る ----
DENSE = "濃い：性器・体液・結合部の音と感触・体の反応を具体的に、露骨に書く（記号 {penis} {vagina} {semen} {love_juice} {clitoris} {nipple} {breasts} を積極的に使う。擬音も使ってよい）"
FINISH_MUST = "妊娠・避妊に触れる。真帆が止める。台詞で「待って」「止まって」と言う（止める意味に読める）。中・外に触れる台詞。「入った」「出てる」のような実況の台詞"
dense_rows = []
FACING = {"face": ("向かい合っている（寝ているか座っているか、どちらが上かは書かない）", None),
          "back": ("真帆がこちらに背を向けている（寝ているか立っているか、どちらが上かは書かない）", "真帆の顔は見えない（肩越しに振り返るときだけ、横顔を書いてよい）")}
for tier in ("first", "few", "familiar"):
    for facing, (pose, face) in FACING.items():
        for s_ in ("s", "n"):
            identity = ".".join(["x6", "h_overflow.insert", tier, facing, s_])
            state = {"場所": BED, "慣れ": TIER[tier], "体位": pose, **({"顔": face} if face else {}), "服": LOWER_OPEN,
                     "挿入": "この本文で入れる（入れた途端に果てる）", "主人公": "もう限界だった。こらえずにそのまま入れた（出すと決めてはいない）", "描写": DENSE}
            op, value = TIER_WHEN[tier]
            dense_rows.append({"id": identity, "meaning": "限界まで高まっていたこちらが、真帆の中に入れた途端、こらえきれずに中で果てる", "speech": s_ == "s",
                               "length": "120〜200字", "origin": "主人公", "candidates": 5, "state": state, "_wave": "B2-x6", "_meaning": "h_overflow.insert",
                               "_split": {"tier": tier, "position": None, "other": facing},
                               "when": {"all": [{"field": "intimacy.tier", "op": op, "value": value}, {"field": "intimacy.facing", "op": "eq", "value": facing}]},
                               "group": "b.h_overflow.insert", "style": "explicit",
                               "must_not": FINISH_MUST + "。出すと自分で決めたように書く。入れたあと動き始める（入れた直後に果てる）。体位を変える"})
DENSE_NOTE = ("\n\nこの依頼は、エッチの高まりが強い場面で出る「濃い本文」です（同じ場面の短い標準の本文はすでにあります）。"
              "限界まで高まっていたのに、こらえずにそのまま入れたので、入れた途端にこらえきれずに果てる場面です。真帆の反応（驚き・照れ・慣れていればからかう、受け止める）まで書いてください。"
              "標準より露骨に、性器・体液・結合部の音と感触・体の反応を具体的に書いてください（state の「描写」のとおり）。"
              "この依頼に限り、プロンプトの「部位の語と記号は地の文で1本に2つまで」は「4つまで（同じ語・記号は2回まで）」に読み替えてください。擬音も使ってよいです。"
              "\nstate の慣れが「初回」の job では、露骨に書くのは地の文の感触と体の反応だけです。真帆の台詞・表情・動作は初回の戸惑いと照れのままにし、台詞の語は初回の語（胸、ここ）だけにしてください。地の文に「初めて」と書かない規則も同じです。"
              "state に「顔」があるときは、そのとおりにしてください（真帆の表情を正面から見たようには書かない）。"
              "\n出す・果てる本文では、台詞で「待って」「止まって」を使わない。「入った」「出てる」のような実況の台詞にしない。出すと決めて出したように書かない（こらえきれなかった流れで）。"
              "果てた直後の台詞で「大丈夫」「そのままでいい」「離さなくていい」のような、中に出したことを許す意味に読める言い方を使わない。"
              "\nそれ以外の規則（台詞の数、慣れの段階の語、地の文で器官を名前で呼ばず記号を使う、記号を台詞に書かない、妊娠・避妊に触れない、must_not）は同じです。")

NOTE = ("\n\nこの依頼は、5回目の試運転の指摘から足した場面です。どの場面にも、別の短い本文がすでにあります。"
        "「拭いてあげる」は出したあとの後始末で、どこに出したかは state のとおりです。胸・腹・背中のような細かい場所は書かないでください（前の本文と食い違うため）。"
        "「敏感さ」の本文は、こちらの行動の本文のすぐあとに続けて出る短い本文なので、真帆の反応だけを書き、こちらの行動は書かないでください。")
(OUT / "grok_b2_wave_7.json").write_text(json.dumps(rows, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
folder = OUT / "grok依頼_B2_第7陣"
folder.mkdir(exist_ok=True)
for old in folder.glob("*.txt"):
    old.unlink()
number = 0
for speech, kind in ((True, "台詞あり"), (False, "台詞なし")):
    part = [r for r in rows if r["speech"] == speech]
    count = -(-len(part) // 13)
    size = -(-len(part) // count)
    for index in range(0, len(part), size):
        chunk = part[index:index + size]
        number += 1
        lines = [json.dumps({"id": r["id"], "meaning": r["meaning"], "speech": r["speech"], "length": r["length"], "origin": r["origin"], "本数": r["candidates"],
                             **({"must_not": r["must_not"]} if r.get("must_not") else {}), "state": r["state"]}, ensure_ascii=False) for r in chunk]
        body = ("指示\n"
                f"次の{len(chunk)}件の job を書いてください（段階Bの2版目・第7陣（後始末・こらえる・達した直後）・{kind}）。本数は各 job の「本数」のとおりです（合わせて{sum(r['candidates'] for r in chunk)}本）。"
                "途中で切れそうなら、job の区切りで止めてください。「続けて」と言われたら、止めた job の次から出してください。"
                + NOTE + "\n\n[\n  " + ",\n  ".join(lines) + "\n]\n\n" "プロンプト\n" + PROMPT)
        (folder / f"B2_第7陣_{number:02d}.txt").write_text(body, encoding="utf-8")
first_files = sorted(p.name for p in folder.glob("*.txt"))
(OUT / "grok_b2_wave_x6.json").write_text(json.dumps(dense_rows, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
for speech, kind in ((True, "台詞あり"), (False, "台詞なし")):
    chunk = [r for r in dense_rows if r["speech"] == speech]
    number += 1
    lines = [json.dumps({"id": r["id"], "meaning": r["meaning"], "speech": r["speech"], "length": r["length"], "origin": r["origin"], "本数": r["candidates"],
                         "must_not": r["must_not"], "state": r["state"]}, ensure_ascii=False) for r in chunk]
    body = ("指示\n"
            f"次の{len(chunk)}件の job を書いてください（段階Bの2版目・濃い本文・限界のまま入れて果てる・{kind}）。本数は各 job の「本数」のとおりです（合わせて{sum(r['candidates'] for r in chunk)}本）。"
            "途中で切れそうなら、job の区切りで止めてください。「続けて」と言われたら、止めた job の次から出してください。"
            + DENSE_NOTE + "\n\n[\n  " + ",\n  ".join(lines) + "\n]\n\n" "プロンプト\n" + PROMPT)
    (folder / f"B2_第7陣_{number:02d}.txt").write_text(body, encoding="utf-8")
# ---- 一気に奥まで入れる（v8.2.5）：標準（p7.）と濃い版（x6.） ----
before_deep = sorted(p.name for p in folder.glob("*.txt"))
DEEP_MUST = "入れたあと動き始める（奥まで届いたところまで）。体位を変える。達する。痛がる・嫌がる"
deep_std, deep_dense = [], []
for tier in ("few", "familiar"):
    for facing, (pose, face) in FACING.items():
        for s_ in ("s", "n"):
            op, value = TIER_WHEN[tier]
            state = {"場所": BED, "慣れ": TIER[tier], "体位": pose, **({"顔": face} if face else {}), "服": LOWER_OPEN,
                     "挿入": "この本文で入れる（ゆっくりではなく、一気に奥まで）", "真帆": "十分に高まっていて、待ちかねている"}
            common = {"meaning": "こちらが一気に奥まで、真帆の中に入れる", "speech": s_ == "s", "origin": "主人公", "candidates": 5, "_meaning": "h_insert_deep.start",
                      "_split": {"tier": tier, "position": None, "other": facing},
                      "when": {"all": [{"field": "intimacy.tier", "op": op, "value": value}, {"field": "intimacy.facing", "op": "eq", "value": facing}]},
                      "group": "b.h_insert_deep.start", "must_not": DEEP_MUST}
            deep_std.append({"id": ".".join(["p7", "h_insert_deep.start", tier, facing, s_]), "length": "100〜160字", "state": state, "_wave": "B2-7", **common})
            deep_dense.append({"id": ".".join(["x6", "h_insert_deep.start", tier, facing, s_]), "length": "120〜200字", "state": {**state, "描写": DENSE},
                               "_wave": "B2-x6", "style": "explicit", **common})
(OUT / "grok_b2_wave_7.json").write_text(json.dumps(rows + deep_std, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
(OUT / "grok_b2_wave_x6.json").write_text(json.dumps(dense_rows + deep_dense, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
DEEP_NOTE = ("\n\nこの依頼は、新しく足した行動「一気に奥まで入れる」の本文です（同じ場面の短い本文はすでにあります。「ゆっくり入れる」の本文とは別の行動です）。"
             "真帆は十分に高まっていて、一息に奥まで入る衝撃と、それを待ちかねていた反応（数回は驚きが勝つ、慣れは受け止めて求める）を書いてください。"
             "入れて奥に届いたところで本文を終え、動き始めないでください。state に「顔」があるときは、そのとおりにしてください（真帆の表情を正面から見たようには書かない）。")
DEEP_DENSE_NOTE = DEEP_NOTE + ("\nこの依頼は高まりが強い場面で出る「濃い本文」です。標準より露骨に、性器・体液・結合部の音と感触・体の反応を具体的に書いてください（state の「描写」のとおり）。"
                               "この依頼に限り、プロンプトの「部位の語と記号は地の文で1本に2つまで」は「4つまで（同じ語・記号は2回まで）」に読み替えてください。擬音も使ってよいです。")
for chunk, label, note in ((deep_std, "一気に奥まで入れる", DEEP_NOTE), (deep_dense, "濃い本文・一気に奥まで入れる", DEEP_DENSE_NOTE)):
    number += 1
    lines = [json.dumps({"id": r["id"], "meaning": r["meaning"], "speech": r["speech"], "length": r["length"], "origin": r["origin"], "本数": r["candidates"],
                         "must_not": r["must_not"], "state": r["state"]}, ensure_ascii=False) for r in chunk]
    body = ("指示\n"
            f"次の{len(chunk)}件の job を書いてください（段階Bの2版目・{label}・台詞ありと台詞なし）。本数は各 job の「本数」のとおりです（合わせて{sum(r['candidates'] for r in chunk)}本）。"
            "speech が true の job は真帆の台詞がちょうど1つ、false の job は台詞なしです。途中で切れそうなら、job の区切りで止めてください。「続けて」と言われたら、止めた job の次から出してください。"
            + note + "\nそれ以外の規則（台詞の数、慣れの段階の語、地の文で器官を名前で呼ばず記号を使う、記号を台詞に書かない、妊娠・避妊に触れない、must_not）は同じです。"
            + "\n\n[\n  " + ",\n  ".join(lines) + "\n]\n\n" "プロンプト\n" + PROMPT)
    (folder / f"B2_第7陣_{number:02d}.txt").write_text(body, encoding="utf-8")
listing = {"第7陣": {"jobs": len(rows), "texts": sum(r["candidates"] for r in rows), "files": first_files},
           "一気に奥まで入れる": {"jobs": len(deep_std) + len(deep_dense), "texts": 5 * (len(deep_std) + len(deep_dense)),
                           "files": sorted(p.name for p in folder.glob("*.txt") if p.name not in before_deep)},
           "濃い版_限界のまま入れる": {"jobs": len(dense_rows), "texts": sum(r["candidates"] for r in dense_rows),
                                "files": sorted(name for name in before_deep if name not in first_files)}}
(OUT / "第7陣_一覧.json").write_text(json.dumps(listing, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
print(json.dumps(listing, ensure_ascii=False))
