"""Stage A2 acceptance through displayed choices; seed and commands remain reproducible."""
import json
import shutil
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from nagishima import clock
from nagishima.codec import bytes_digest, digest
from nagishima.content import Pack
from nagishima.conditions import evaluate
from nagishima.engine import Engine
from nagishima.errors import GameError
from nagishima.progression import life_day

ROOT = Path(__file__).resolve().parents[1]
RELEASES = ROOT / "content" / "releases"


class StageA2(unittest.TestCase):
    seed = 42

    def setUp(self):
        self.temporary = TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.engine = Engine(Path(self.temporary.name) / "save", seed=self.seed, release="interaction_008", autosave=False)
        self.commands = []

    def choose(self, identity):
        view = self.engine.get_view()
        self.commands.append(identity)
        try:
            return self.engine.choose(identity, view["revision"], view["session"])
        except Exception as error:
            self.fail(f"seed={self.seed} commands={self.commands}: {error}")

    def clear_offer(self):
        if self.engine.snapshot()["offer"]:
            self.choose("offer.decline")

    def choice(self, identity):
        return next((x for x in self.engine.get_view()["choices"] if x["id"] == identity), None)

    def work_all(self):
        for _ in range(3):
            self.clear_offer()
            self.choose("work.go")
        self.clear_offer()

    def complete_tea(self):
        self.clear_offer()
        if self.engine.get_view()["page"] != "main":
            self.choose("menu.main")
        self.choose("menu.activities")
        self.choose("activity.tea")
        self.choose("scene.finish")

    def reach_shared_offer(self):
        self.work_all()
        self.choose("menu.talk")
        self.choose("begin.two_cups")
        self.choose("scene.tea")
        self.choose("scene.remember")
        self.choose("menu.activities")
        self.choose("activity.tea")
        self.choose("scene.finish")
        self.assertEqual(self.engine.snapshot()["offer"]["kind"], "shared")

    def test_b01_legacy_release_has_no_life_rules_or_new_field(self):
        for release in ("interaction_003", "interaction_004", "interaction_005", "interaction_006", "interaction_007"):
            pack = Pack(RELEASES / release)
            self.assertIsNone(pack.life)
            self.assertNotIn("experience.head.tier", pack.registry.fields)

    def test_b02_life_data_rejects_malformed_sections_and_hash_change(self):
        source = RELEASES / "interaction_008"
        variants = [
            lambda d: d.update(format="wrong"),
            lambda d: d["offers"]["shared_by_time"][0].update(to="15:58"),
            lambda d: d["offers"]["once_per_day"].append("missing"),
            lambda d: d["offers"]["once_per_day"].append([]),
            lambda d: d["drinks"].update(per_day=0),
            lambda d: d["speech"]["spacing"].update(start=11),
            lambda d: d["familiarity"].update(few_from=1),
            lambda d: d["work"]["weekdays"].append(0),
            lambda d: d["work"]["weekdays"].append([]),
            lambda d: d["work"]["blocks"][0].update(after="town"),
            lambda d: d["work"]["events"]["random"].update(chance_percent=101),
            lambda d: d["work"]["events"]["random"]["ids"].append([]),
        ]
        for index, mutate in enumerate(variants):
            target = Path(self.temporary.name) / f"bad{index}"
            shutil.copytree(source, target)
            data = json.loads((target / "life.json").read_text(encoding="utf-8"))
            mutate(data)
            (target / "life.json").write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
            with self.subTest(index=index), self.assertRaises(GameError) as hash_error:
                Pack(target)
            self.assertEqual(hash_error.exception.code, "release_hash")
            manifest = json.loads((target / "release.json").read_text(encoding="utf-8"))
            manifest["files"]["life.json"] = bytes_digest((target / "life.json").read_bytes())
            manifest["control_sha256"] = digest({"catalog": json.loads((target / "catalog.json").read_text(encoding="utf-8")),
                "actions": json.loads((target / "actions.json").read_text(encoding="utf-8")),
                "progression": json.loads((target / "progression.json").read_text(encoding="utf-8")), "life": data})
            (target / "release.json").write_text(json.dumps(manifest), encoding="utf-8")
            with self.subTest(index=index), self.assertRaises(GameError) as data_error:
                Pack(target)
            self.assertEqual(data_error.exception.code, "life_data")

    def test_b02_life_requires_progression(self):
        target = Path(self.temporary.name) / "no_progression"
        shutil.copytree(RELEASES / "interaction_008", target)
        manifest = json.loads((target / "release.json").read_text(encoding="utf-8"))
        del manifest["files"]["progression.json"]
        manifest["control_sha256"] = digest({"catalog": json.loads((target / "catalog.json").read_text(encoding="utf-8")),
            "actions": json.loads((target / "actions.json").read_text(encoding="utf-8")),
            "life": json.loads((target / "life.json").read_text(encoding="utf-8"))})
        (target / "release.json").write_text(json.dumps(manifest), encoding="utf-8")
        with self.assertRaises(GameError) as error:
            Pack(target)
        self.assertEqual(error.exception.code, "life_data")

    def test_b20_work_time_boundary_and_exact_start(self):
        self.assertEqual(self.choice("wait.120")["reason"], "work_time")
        self.assertTrue(self.choice("wait.30")["available"])
        self.choose("wait.30")
        self.clear_offer()
        self.assertTrue(self.choice("wait.30")["available"])
        self.choose("wait.30")
        self.clear_offer()
        self.assertEqual(self.choice("wait.30")["reason"], "work_time")
        self.assertTrue(self.choice("work.go")["available"])

    def test_b10_b11_shared_offer_consumed_on_decline_and_activity_matches(self):
        self.reach_shared_offer()
        meaning = self.engine.get_view()["blocks"][-1]["meaning"]
        self.assertEqual(meaning, "offer.shared.quiet")
        day = life_day(self.engine.snapshot()["world"]["now"])
        self.assertTrue(any(x["group"] == "shared" and x["day"] == day for x in self.engine.snapshot()["cooldowns"]))
        self.choose("offer.accept")
        self.assertEqual(next(x for x in self.engine.snapshot()["activities"] if x["status"] == "running")["kind"], "quiet")
        self.choose("scene.finish")
        self.clear_offer()
        for _ in range(3):
            self.choose("listen")
            self.assertFalse(self.engine.snapshot()["offer"] and self.engine.snapshot()["offer"]["kind"] == "shared")
            self.clear_offer()
        self.choose("sleep")
        self.assertNotEqual(life_day(self.engine.snapshot()["world"]["now"]), day)
        self.assertFalse(any(x["group"] == "shared" for x in self.engine.snapshot()["cooldowns"]))

    def test_b10_declined_shared_offer_returns_on_next_life_day(self):
        self.reach_shared_offer()
        first_day = life_day(self.engine.snapshot()["world"]["now"])
        self.choose("offer.decline")
        for _ in range(3):
            self.choose("listen")
            self.assertFalse(self.engine.snapshot()["offer"] and self.engine.snapshot()["offer"]["kind"] == "shared")
            self.clear_offer()
        self.choose("sleep")
        self.assertGreater(life_day(self.engine.snapshot()["world"]["now"]), first_day)
        self.choose("listen")
        self.assertEqual(self.engine.snapshot()["offer"]["kind"], "shared")

    def test_b12_drink_limit_and_promise_exception(self):
        self.work_all()
        for _ in range(3):
            self.complete_tea()
        self.clear_offer()
        self.choose("menu.activities")
        self.assertEqual(self.choice("activity.tea")["reason"], "drink_limit")
        self.choose("menu.main")
        self.choose("menu.plans")
        self.choose("begin.promise_tea")
        self.choose("scene.yes")
        self.clear_offer()
        self.choose("menu.plans")
        promise = next(x for x in self.engine.snapshot()["promises"] if x["kind"] == "tea")
        self.assertTrue(self.choice("fulfil." + promise["id"])["available"])
        self.choose("fulfil." + promise["id"])
        self.assertEqual(next(x for x in self.engine.snapshot()["activities"] if x["status"] == "running")["promise_id"], promise["id"])

    def test_b13_maho_waits_between_tea_player_can_choose_it(self):
        self.choose("work.go")
        self.clear_offer()
        self.choose("menu.activities")
        self.choose("activity.tea")
        self.choose("scene.finish")
        self.clear_offer()
        self.choose("listen")
        self.assertFalse(self.engine.snapshot()["offer"] and self.engine.snapshot()["offer"]["kind"] == "shared")
        self.clear_offer()
        self.choose("menu.activities")
        self.assertTrue(self.choice("activity.tea")["available"])

    def test_b23_fixed_event_and_deterministic_random_roll(self):
        # Time-only fixture setup on Monday; choice and emitted text use the public engine.
        now = clock.minutes("2038-04-12T07:30")
        self.engine._state["world"].update(now=now, processed_until=now, awake_deadline=clock.next_clock(now, 300))
        self.engine._install_choices()
        before = self.engine.snapshot()["world"]["rng"].copy()
        self.choose("work.go")
        meanings = [x["meaning"] for x in self.engine.get_view()["blocks"]]
        self.assertIn("work.block.morning", meanings)
        self.assertIn("work.event.report", meanings)
        after = self.engine.snapshot()["world"]["rng"]
        self.assertEqual(before["world"], after["world"])
        # The normal post-action goal selection advances director once; the event roll does not.
        self.assertEqual(before["director"] + 1, after["director"])

    def test_b23_random_daily_cap_and_rain_weather(self):
        # Only the date is prepared internally; each work block runs through choose().
        releases = Path(self.temporary.name) / "event_releases"
        target = releases / "interaction_008"
        shutil.copytree(RELEASES / "interaction_008", target)
        data = json.loads((target / "life.json").read_text(encoding="utf-8"))
        data["work"]["events"]["random"].update(chance_percent=100, max_per_day=1)
        (target / "life.json").write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        manifest = json.loads((target / "release.json").read_text(encoding="utf-8"))
        manifest["files"]["life.json"] = bytes_digest((target / "life.json").read_bytes())
        manifest["control_sha256"] = digest({
            "catalog": json.loads((target / "catalog.json").read_text(encoding="utf-8")),
            "actions": json.loads((target / "actions.json").read_text(encoding="utf-8")),
            "progression": json.loads((target / "progression.json").read_text(encoding="utf-8")),
            "life": data,
        })
        (target / "release.json").write_text(json.dumps(manifest), encoding="utf-8")
        for seed, expected_afternoon in ((0, "work.event.repair"), (1, None)):
            with self.subTest(seed=seed):
                engine = Engine(Path(self.temporary.name) / f"event_{seed}", seed=seed,
                                release="interaction_008", builtin=releases, autosave=False)
                now = clock.minutes("2038-04-12T07:30")
                engine._state["world"].update(now=now, processed_until=now,
                                               awake_deadline=clock.next_clock(now, 300))
                engine._install_choices()
                observed = []
                for _ in range(3):
                    view = engine.get_view()
                    if engine.snapshot()["offer"]:
                        engine.choose("offer.decline", view["revision"], view["session"])
                        view = engine.get_view()
                    result = engine.choose("work.go", view["revision"], view["session"])
                    observed.append([block["meaning"] for block in result["blocks"]])
                self.assertIn("work.event.report", observed[0])
                if expected_afternoon:
                    self.assertIn(expected_afternoon, observed[1])
                    self.assertFalse(any(x.startswith("work.event.") for x in observed[2]))
                else:
                    self.assertNotIn("work.event.rain", observed[1])

    def test_b31_familiarity_tier_boundaries_after_public_touch(self):
        engine = Engine(Path(self.temporary.name) / "touch", seed=self.seed, release="interaction_008", autosave=False, test_cheats=True)
        engine.enable_test_cheat("all")
        def choose(identity):
            view = engine.get_view()
            engine.choose(identity, view["revision"], view["session"])
        choose("near")
        choose("menu.touch")
        for count in range(1, 7):
            choose("touch.head")
            values = engine.pack.registry.values(engine.snapshot())
            self.assertEqual(values["experience.head.tier"], "first" if count == 1 else "few" if count < 6 else "familiar")
            self.assertEqual(evaluate({"field": "experience.head.tier", "op": "eq", "value": "familiar"}, values), count == 6)
            choose("end.head")

    def test_b30_speech_spacing_and_dialogue_only_fallback(self):
        # A temporary test release changes only text; all actions remain public choose() calls.
        releases = Path(self.temporary.name) / "releases"
        target = releases / "interaction_008"
        shutil.copytree(RELEASES / "interaction_008", target)
        texts = json.loads((target / "texts.json").read_text(encoding="utf-8"))
        for text in texts:
            if text["meaning"] == "talk.start":
                text["body"] = "「うん、聞いているよ」"
                text["slots"] = []
            if text["meaning"] == "hair.start":
                text["body"] = "「髪に触れられると、少しくすぐったい」"
                text["slots"] = []
        texts.extend([
            {"id": "a2.test.head.dialogue", "meaning": "head.start", "when": {"all": []}, "slots": [], "group": "a2.dialogue", "body": "「もう一度、撫でてくれる？」", "fallback": False},
            {"id": "a2.test.head.narration", "meaning": "head.start", "when": {"all": []}, "slots": [], "group": "a2.narration", "body": "真帆は目を細めて、手の温かさを受け止めた。", "fallback": False},
            {"id": "a2.test.hair.dialogue", "meaning": "hair.start", "when": {"all": []}, "slots": [], "group": "a2.dialogue", "body": "「髪、触れてもいいよ」", "fallback": False},
        ])
        (target / "texts.json").write_text(json.dumps(texts, ensure_ascii=False), encoding="utf-8")
        manifest = json.loads((target / "release.json").read_text(encoding="utf-8"))
        manifest["files"]["texts.json"] = bytes_digest((target / "texts.json").read_bytes())
        (target / "release.json").write_text(json.dumps(manifest), encoding="utf-8")
        engine = Engine(Path(self.temporary.name) / "spacing", seed=self.seed, release="interaction_008", builtin=releases, autosave=False, test_cheats=True)
        engine.enable_test_cheat("all")
        def choose(identity):
            view = engine.get_view()
            return engine.choose(identity, view["revision"], view["session"])
        choose("near")
        choose("menu.touch")
        choose("touch.head")
        choose("end.head")
        choose("menu.main")
        choose("menu.talk")
        choose("touch.talk")
        choose("menu.main")
        choose("menu.touch")
        view = choose("touch.head")
        self.assertEqual(view["blocks"][-1]["variant"], "a2.test.head.narration")
        choose("end.head")
        choose("touch.hair")
        choose("end.hair")
        choose("menu.main")
        choose("menu.talk")
        choose("touch.talk")
        choose("menu.main")
        choose("menu.touch")
        view = choose("touch.hair")
        self.assertIn("「", view["blocks"][-1]["body"])

    def test_b21_work_blocks_move_both_people(self):
        expected = [("12:00", "kitchen"), ("15:00", "observatory"), ("17:30", "living_room")]
        for suffix, location in expected:
            self.clear_offer()
            self.choose("work.go")
            state = self.engine.snapshot()
            self.assertTrue(self.engine.get_view()["status"]["time"].endswith(suffix))
            self.assertEqual([state["actors"][name]["location"] for name in ("player", "maho")], [location, location])
            self.assertEqual(state["distance"], "normal")

    def test_b22_weekend_has_no_work(self):
        # Time-only fixture setup: all judged actions go through choose().
        now = clock.minutes("2038-04-10T07:30")
        self.engine._state["world"].update(now=now, processed_until=now, awake_deadline=clock.next_clock(now, 300))
        self.engine._install_choices()
        self.assertIsNone(self.choice("work.go"))
        self.assertTrue(self.choice("wait.120")["available"])
        self.choose("wait.120")

    def test_b24_adoption_mid_block_only_work_advances(self):
        old = Engine(Path(self.temporary.name) / "old", seed=self.seed, release="interaction_007", autosave=False)
        view = old.get_view()
        old.choose("wait.120", view["revision"], view["session"])
        self.assertTrue(old.get_view()["status"]["time"].endswith("09:30"))
        old.adopt_release("interaction_008")
        choices = {x["id"]: x for x in old.get_view()["choices"]}
        self.assertEqual(choices["wait.30"]["reason"], "work_time")
        self.assertTrue(choices["work.go"]["available"])

    def test_b25_sleep_routine_after_work(self):
        self.work_all()
        for _ in range(3):
            self.choose("wait.120")
            self.clear_offer()
        self.assertEqual(self.engine.snapshot()["maho_sleep"]["state"], "asleep")

    def test_b40_adoption_rules(self):
        for release in ("interaction_003", "interaction_004", "interaction_005", "interaction_006", "interaction_007"):
            old = Engine(Path(self.temporary.name) / release, seed=self.seed, release=release, autosave=False)
            old.adopt_release("interaction_008")
            self.assertEqual(old.active_release, "interaction_008")
            with self.assertRaises(GameError) as error:
                old.adopt_release(release)
            self.assertEqual(error.exception.code, "control_change")

    def test_b40_adoption_rejects_question_and_suspended_scene(self):
        old = Engine(Path(self.temporary.name) / "oldscene", seed=self.seed, release="interaction_007", autosave=False)
        def choose(identity):
            view = old.get_view()
            old.choose(identity, view["revision"], view["session"])
        choose("menu.talk")
        choose("begin.two_cups")
        with self.assertRaises(GameError) as error:
            old.adopt_release("interaction_008")
        self.assertEqual(error.exception.code, "answer_first")
        choose("scene.pause")
        with self.assertRaises(GameError) as error:
            old.adopt_release("interaction_008")
        self.assertEqual(error.exception.code, "control_change")

    def test_b40_adoption_rejects_offer_and_private_mode(self):
        old = Engine(Path(self.temporary.name) / "oldoffer", seed=self.seed, release="interaction_007", autosave=False)
        # Listen until an offer appears; all changes are public.
        for _ in range(6):
            if old.snapshot()["offer"]:
                break
            view = old.get_view()
            if view["page"] != "main":
                old.choose("menu.main", view["revision"], view["session"])
                continue
            old.choose("listen", view["revision"], view["session"])
        self.assertIsNotNone(old.snapshot()["offer"])
        with self.assertRaises(GameError) as error:
            old.adopt_release("interaction_008")
        self.assertEqual(error.exception.code, "answer_first")
        private = Engine(Path(self.temporary.name) / "oldprivate", seed=self.seed, release="interaction_007", autosave=False, test_cheats=True)
        private.enable_test_cheat("all")
        view = private.get_view()
        private.choose("private.begin", view["revision"], view["session"])
        with self.assertRaises(GameError) as error:
            private.adopt_release("interaction_008")
        self.assertEqual(error.exception.code, "control_change")


if __name__ == "__main__":
    unittest.main()
