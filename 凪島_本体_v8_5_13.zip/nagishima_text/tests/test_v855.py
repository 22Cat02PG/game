"""v8.5.5（ユーザー 2026-10-08「進めろ。次があるだろ」）：010 だけ。段階C 六歩目：真帆が来る（逆向きの夜這い。イベントの型）。
仕様 docs/凪島_段階C_仕様_2026-10-08.md の第5.2節・第17節。"""
import unittest
from pathlib import Path

from nagishima.content import Pack
from tools.run_stage_b_routes import Route

ROOT = Path(__file__).resolve().parents[1]
P009 = Pack(ROOT / "content/releases/interaction_009")
P010 = Pack(ROOT / "content/releases/interaction_010")


class NightRoute:
    """22:30 の夜。day_offset=2 は金曜（翌日は休み＝休日前の夜）、0 は水曜（翌日は仕事）。percent を 100 にして必ず来るようにする（終えたら戻す）。"""
    def __init__(self, day_offset=2, desire=95, tier="familiar", percent=100):
        self.route = Route(8, hour=22, minute=30, tier=tier, release="interaction_010", day_offset=day_offset)
        self.night = self.route.engine.pack.intimacy.events.events["visit"].night
        self.saved = self.night["percent"]
        self.night["percent"] = percent
        self.route.engine._state["desire"] = desire
        self.route.engine._install_choices()

    def __enter__(self):
        return self.route

    def __exit__(self, *args):
        self.night["percent"] = self.saved
        self.route.close()


def meanings(view):
    return [b["meaning"] for b in view["blocks"]]


def ids(view):
    return [c["id"] for c in view["choices"]]


class V855(unittest.TestCase):
    def test_rules(self):
        self.assertIsNone(P009.intimacy.events)
        visit = P010.intimacy.events.events["visit"]
        self.assertEqual((visit.night["from"], visit.night["until"], visit.night["percent"]), (1500, 1560, 40))
        self.assertTrue(visit.sleep_after)
        self.assertTrue(visit.decline_close)
        self.assertEqual(list(visit.positions), ["maho_above", "side_face"])
        for meaning in visit.meanings():
            self.assertIn(meaning, P010.meanings)
        self.assertIn("event.acts", P010.registry.fields)

    def test_pretend_and_h(self):
        """休日前の夜に眠ると、1〜2時に真帆が来る。寝たふりを3回続けると「……起きてるでしょ」。応えてエッチ → 同じベッドで眠って翌朝。"""
        with NightRoute() as route:
            view = route.choose("sleep")
            self.assertEqual(meanings(view)[-1], "ev.visit.begin")
            state = route.engine.snapshot()
            self.assertTrue(1500 <= (state["world"]["now"] - 300 - 1) % 1440 + 301 < 1560)  # 1:00〜2:00
            self.assertEqual((state["actors"]["player"]["location"], state["actors"]["maho"]["location"]), ("player_room", "player_room"))
            self.assertEqual(state["maho_sleep"]["state"], "awake")
            self.assertEqual(view["page_title"], "自分の部屋（夜更け）")
            self.assertEqual(ids(view), ["event.pre.pretend", "event.pre.wake", "event.leave"])
            bodies = []
            for n in (1, 2, 3):
                view = route.choose("event.pre.pretend")
                self.assertEqual(route.engine.pack.by_text[view["blocks"][0]["variant"]]["when"]["all"][0], {"field": "event.acts", "op": "eq", "value": n})
                bodies.append(view["blocks"][0]["body"])
            self.assertEqual(meanings(view)[-1], "ev.visit.notice.caught")
            route.choose("event.accept")
            view = route.choose("event.pos.maho_above")
            self.assertIn("ev.visit.pos.maho_above", meanings(view))
            route.choose("event.next")
            route.choose("event.insert")
            for _ in range(20):
                if "event.finish.inside" in ids(route.engine.get_view()):
                    break
                route.choose("event.move.normal")
            view = route.choose("event.finish.inside")
            got = meanings(view)
            self.assertTrue(any(m.startswith("ev.visit.end.") for m in got))
            # v8.5.9：一緒に眠った朝の一言（h.morning_together）の代わりに、真帆が来た夜の翌朝の一言
            self.assertIn("ev.visit.morning.h", got)
            self.assertFalse(any(m.startswith("h.morning_together.") for m in got))
            state = route.engine.snapshot()
            self.assertIsNone(state["event_play"])
            self.assertEqual(state["event_record"]["visit"]["count"], 1)
            self.assertFalse(state["intimacy_history"]["slept_together"])  # 翌朝の一言を出したら戻す
            self.assertEqual(state["maho_sleep"]["state"], "awake")
            self.assertGreaterEqual(state["world"]["now"] % 1440, 450)  # 朝（7:30 から朝食）

    def test_wake_then_decline(self):
        """起きて応えると、真帆が驚いて照れる。「今夜は眠い」と断ると、真帆は部屋へ戻り、そのまま翌朝（エッチの記録はない）。"""
        with NightRoute() as route:
            route.choose("sleep")
            view = route.choose("event.pre.wake")
            self.assertEqual(meanings(view)[-2:], ["ev.visit.pre.wake", "ev.visit.notice.woke"])
            view = route.choose("event.decline")
            got = meanings(view)
            self.assertIn("ev.visit.offer.decline", got)
            self.assertIn("system.slept", got)
            state = route.engine.snapshot()
            self.assertIsNone(state["event_play"])
            self.assertNotIn("visit", state.get("event_record", {}))
            self.assertGreaterEqual(state["world"]["now"] % 1440, 450)

    def test_leave(self):
        """寝たふりの途中で、やんわり断る。"""
        with NightRoute() as route:
            route.choose("sleep")
            route.choose("event.pre.pretend")
            view = route.choose("event.leave")
            self.assertIn("ev.visit.leave", meanings(view))
            self.assertIn("system.slept", meanings(view))
            self.assertIsNone(route.engine.snapshot()["event_play"])

    def test_not_on_other_nights(self):
        """翌日が仕事の夜・欲求が press でない夜・恋人で初めての前・お酒を飲んだ夜には来ない（割合を 100 にしても）。"""
        for kwargs in ({"day_offset": 0}, {"desire": 60}, {"tier": "first"}):
            with NightRoute(**kwargs) as route:
                view = route.choose("sleep")
                self.assertNotIn("ev.visit.begin", meanings(view), kwargs)
                self.assertIn("system.slept", meanings(view), kwargs)
        with NightRoute() as route:
            from nagishima.progression import life_day
            route.engine._state["drink_night"] = {"day": life_day(route.engine._state["world"]["now"]), "drunk": 1}
            route.engine._install_choices()
            view = route.choose("sleep")
            self.assertNotIn("ev.visit.begin", meanings(view))

    def test_percent_is_by_night(self):
        """割合はその夜ごとに決まる（同じ seed・同じ夜なら同じ）。40% のままでも、来る夜と来ない夜がある。"""
        came = []
        for offset in (2, 9, 16, 23, 30, 37):
            with NightRoute(day_offset=offset, percent=40) as route:
                came.append("ev.visit.begin" in meanings(route.choose("sleep")))
        self.assertTrue(any(came) and not all(came), came)


if __name__ == "__main__":
    unittest.main()
