"""v8.5.10（ユーザー 2026-10-08 19:11「では始めて」）：010 だけ。段階C：頼む（見せて・手と口でしてもらう）。仕様 docs/凪島_段階C_仕様_2026-10-08.md の第20節。"""
import unittest
from pathlib import Path

from nagishima import clock
from nagishima.content import Pack
from tools.run_stage_b_routes import Route

ROOT = Path(__file__).resolve().parents[1]
P009 = Pack(ROOT / "content/releases/interaction_009")
P010 = Pack(ROOT / "content/releases/interaction_010")
LEWD = {"shy": 0, "open": 20, "eager": 40, "bold": 65}


def ask_route(lewd="shy", desire=70, tier="familiar", hour=19, minute=40, day_offset=0, place=None, release="interaction_010"):
    route = Route(8, hour=hour, minute=minute, tier=tier, day_offset=day_offset, release=release)
    state = route.engine._state
    state["affinity"]["value"], state["desire"] = 80, desire
    if release == "interaction_010":
        state["intimacy_history"]["lewdness"] = LEWD[lewd]
    if place:
        for actor in state["actors"].values():
            actor["location"] = place
    route.engine._install_choices()
    route.choose("menu.touch")
    return route


def meanings(view):
    return [b["meaning"] for b in view["blocks"]]


def choices(route):
    view = route.engine.get_view()
    return {c["id"]: (c["available"], view["explanations"].get(c["id"])) for c in view["choices"]}


def weather_day(rain, weekday=0):
    """Route の day_offset で、雨の日（rain=True）・雨でない日を探す。weekday：0＝水曜（Route の始まりと同じ曜日）、3＝土曜。"""
    route = Route(8, release="interaction_010")
    base = route.engine._state["world"]["now"] // 1440
    seed = route.engine._state["world"]["seed"]
    route.close()
    for offset in range(weekday, 120, 7):
        if (clock.weather(seed, base + offset) == "rain") == rain:
            return offset
    raise AssertionError("見つからない")


class V8510(unittest.TestCase):
    def test_rules_and_texts(self):
        self.assertIsNone(P009.intimacy.ask)
        rules = P010.intimacy.ask
        self.assertEqual(rules.place_of["observatory"], "work")
        self.assertEqual(rules.show["daily"], {"shy": 1, "open": 2, "eager": 3, "bold": 4})
        never = {"ask.show.decline.home", "ask.serve.decline.home"}  # 家は恥ずかしがりの段から受けるので出ない
        never.add("ask.serve.decline.town")  # v8.5.11：島の町のしてもらうも恥ずかしがりの段から受ける（大胆の段でなければ家へ連れて帰る）
        for meaning in rules.meanings():
            self.assertIn(meaning, P010.meanings)
            if meaning not in never:
                self.assertTrue(any(t["meaning"] == meaning and not t["fallback"] for t in P010.by_text.values()), meaning)
        route = ask_route(release="interaction_009")
        self.assertFalse(any(k.startswith("ask.") for k in choices(route)))
        route.close()

    def test_listing(self):
        """恋人の、いつもの時間の「触れ合う」に並ぶ。口は慣れ few から（開くまで出さない）。恋人になる前は出ない。"""
        route = ask_route(tier="first")
        got = choices(route)
        self.assertTrue(got["ask.show"][0] and got["ask.serve.hand"][0])
        self.assertNotIn("ask.serve.mouth", got)
        route.close()
        route = ask_route()
        self.assertIn("ask.serve.mouth", choices(route))
        route.engine._state["relation"]["stage"] = 2
        route.engine._install_choices()
        self.assertFalse(any(k.startswith("ask.") for k in choices(route)))
        route.close()

    def test_show_daily_and_interval(self):
        """恥ずかしがりの段は1日1回。続けて頼むとグレーアウト（理由つき）。上限を超えた最初の一回は「今日はもうおしまい」、そのあとはグレーアウト。"""
        route = ask_route()
        desire = route.engine.snapshot()["desire"]
        view = route.choose("ask.show")
        self.assertEqual(meanings(view)[-1], "ask.show.home.under")
        self.assertEqual(route.engine.snapshot()["desire"], desire + 5)
        self.assertEqual(choices(route)["ask.show"], (False, "さっき見せてもらったばかりだ。"))
        route.engine._state["world"]["now"] += 30
        route.engine._state["world"]["processed_until"] = route.engine._state["world"]["now"]
        route.engine._install_choices()
        view = route.choose("ask.show")
        self.assertEqual(meanings(view)[-1], "ask.show.enough")
        self.assertEqual(choices(route)["ask.show"], (False, "今日はもうおしまいと言われた。"))
        route.close()

    def test_show_inside_after_under(self):
        """素直になってきた段なら、家で下着を2回見せたあとは中まで。"""
        route = ask_route(lewd="open")
        route.engine._state["ask"] = {"day": 0, "shown": 0, "served": 0, "enough": [], "last_show": None, "last_serve": None, "declined": None, "under": 2, "inside": 0}
        route.engine._install_choices()
        view = route.choose("ask.show")
        self.assertEqual(meanings(view)[-1], "ask.show.home.inside")
        self.assertEqual(route.engine.snapshot()["ask"]["inside"], 1)
        route.close()

    def test_show_work_decline(self):
        """職場では素直になってきた段から。恥ずかしがりの段では断られ、少しのあいだグレーアウト。"""
        route = ask_route(place="observatory")
        view = route.choose("ask.show")
        self.assertEqual(meanings(view)[-1], "ask.show.decline.work")
        self.assertEqual(choices(route)["ask.show"], (False, "さっき断られたばかりだ。少し時間を置く。"))
        route.close()

    def test_serve_home(self):
        """家で手でしてもらう：続けてもらうと高まり、出せる値から「出す」、上限では続けられない。出したら終わり（余力 −1、欲求 +10、エッチの回数・淫乱度は変わらない）。"""
        route = ask_route()
        before = route.engine.snapshot()
        view = route.choose("ask.serve.hand")
        self.assertEqual(meanings(view)[-1], "ask.serve.hand.begin.home")
        self.assertEqual(view["page_title"], "居間")
        self.assertEqual(set(choices(route)), {"ask.next", "ask.stop"})
        for _ in range(9):
            view = route.choose("ask.next")
        self.assertEqual(route.engine.snapshot()["ask_play"]["arousal"], 100)
        self.assertEqual(set(choices(route)), {"ask.finish", "ask.stop"})  # 上限ではもう続けられない
        view = route.choose("ask.finish")
        self.assertEqual(meanings(view)[-2:], ["ask.serve.hand.finish", "ask.serve.close.home"])
        after = route.engine.snapshot()
        self.assertIsNone(after["ask_play"])
        self.assertEqual(after["stamina"]["value"], before["stamina"]["value"] - 1)
        self.assertEqual(after["desire"], before["desire"] + 10)
        self.assertEqual(after["intimacy_history"]["count"], before["intimacy_history"]["count"])
        self.assertEqual(after["intimacy_history"]["lewdness"], before["intimacy_history"]["lewdness"])
        self.assertEqual(choices(route)["ask.serve.hand"], (False, "さっきしてもらったばかりだ。"))
        route.close()

    def test_serve_finish_from_and_stop(self):
        """出せるのは高まり 70 から。やめてもらうといつでも終わる（余力は減らない）。"""
        route = ask_route()
        route.choose("ask.serve.mouth")
        for _ in range(4):
            route.choose("ask.next")
        self.assertEqual(route.engine.snapshot()["ask_play"]["arousal"], 64)
        self.assertNotIn("ask.finish", choices(route))
        route.choose("ask.next")
        self.assertIn("ask.finish", choices(route))
        stamina = route.engine.snapshot()["stamina"]["value"]
        view = route.choose("ask.stop")
        self.assertEqual(meanings(view)[-1], "ask.serve.stop")
        self.assertIsNone(route.engine.snapshot()["ask_play"])
        self.assertEqual(route.engine.snapshot()["stamina"]["value"], stamina)
        route.close()

    def test_serve_before_work(self):
        """平日の昼休み 12:40（午後の仕事は 13:00）は、次の仕事まで時間が足りないのでグレーアウト（残りの分を出す）。12:30 なら頼める。"""
        route = ask_route(hour=12, minute=40, place="kitchen")
        self.assertEqual(choices(route)["ask.serve.hand"], (False, "次の仕事まであと20分。時間が足りない。"))
        self.assertTrue(choices(route)["ask.show"][0])
        route.close()
        route = ask_route(hour=12, minute=30, place="kitchen")
        self.assertTrue(choices(route)["ask.serve.hand"][0])
        route.close()

    def test_serve_past_bedtime_and_save(self):
        """翌日が仕事の夜、就寝の区切りの直前に頼んでも、一回出すまで続けられる（区切りを越えてよい）。途中で保存・読込できる。"""
        route = ask_route(hour=21, minute=50)
        route.choose("ask.serve.hand")
        route.choose("ask.next")
        route.engine.save("slot01")
        route.engine.load("slot01")
        self.assertEqual(route.engine.snapshot()["ask_play"]["arousal"], 12)
        while "ask.finish" not in choices(route):
            route.choose("ask.next")
        self.assertGreater(route.engine.snapshot()["world"]["now"] % 1440, 22 * 60)
        route.choose("ask.finish")
        self.assertIsNone(route.engine.snapshot()["ask_play"])
        route.close()

    def test_serve_mood_and_place(self):
        """気分が乗らない（欲求が低く、淫乱度が素直になってきた段まで）と断られる。外は夕方〜夜は自分から求める段から、昼は大胆の段から。雨の日の外はグレーアウト。"""
        route = ask_route(desire=0)
        self.assertEqual(meanings(route.choose("ask.serve.hand"))[-1], "ask.serve.decline.mood")
        route.close()
        dry = weather_day(False)
        route = ask_route(lewd="eager", hour=13, minute=30, day_offset=weather_day(False, 3), place="coast")  # 土曜の昼
        self.assertEqual(meanings(route.choose("ask.serve.hand"))[-1], "ask.serve.decline.outdoor")
        route.close()
        route = ask_route(lewd="eager", hour=19, minute=40, day_offset=dry, place="coast")
        view = route.choose("ask.serve.hand")
        self.assertEqual(meanings(view)[-1], "ask.serve.hand.begin.outdoor")
        self.assertEqual(view["page_title"], "海岸（岩陰）")
        route.close()
        route = ask_route(lewd="eager", day_offset=weather_day(True), place="coast")
        self.assertEqual(choices(route)["ask.serve.hand"], (False, "雨の日は、外では頼めない。"))
        route.close()

    def test_serve_daily_shy(self):
        """恥ずかしがりの段は1日1回まで。2回目は「今日はもうしたでしょ」と断られ、そのあとはグレーアウト。"""
        route = ask_route()
        route.engine._state["ask"] = {"day": 0, "shown": 0, "served": 1, "enough": [], "last_show": None, "last_serve": None, "declined": None, "under": 0, "inside": 0}
        from nagishima.progression import life_day
        route.engine._state["ask"]["day"] = life_day(route.engine._state["world"]["now"])
        route.engine._install_choices()
        self.assertEqual(meanings(route.choose("ask.serve.hand"))[-1], "ask.serve.decline.enough")
        self.assertEqual(choices(route)["ask.serve.hand"], (False, "今日はもうおしまいと言われた。"))
        route.close()


if __name__ == "__main__":
    unittest.main()
