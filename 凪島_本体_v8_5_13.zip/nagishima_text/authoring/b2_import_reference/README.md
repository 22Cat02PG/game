# grok の返事の取り込み（参考の道具）

これまで Opus が作業フォルダ（/home/claude/work/b2import）で使っていた道具の写し。中の絶対パス（/home/claude/work/...）は、使う環境に合わせて直す。

流れ（陣ごと）：
1. `parse_NN.py`：返事のテキスト（ユーザーが PC に置いた「新規 テキスト ドキュメント (NN).txt」など）から `{"id","job_id","body"}` を読み取り、job ごとにまとめる（pool）。id の食い違い・重なり・本数の過不足を出す。例は `parse_14.py`（第14陣）、`parse.py`（第1〜3陣）。
2. `machine_check.py`：機械検査（部位の語・呼び方の差し込み・妊娠の語・地の文の禁止語・字数・慣れの語 など）。fail は採用しない（直せるものは直して採用）、warn は読む。
3. `verdicts_NN.py`：Opus（と読む係）の判定（採用・直し・不採用）を書いた記録。例は `verdicts_14.py`。
4. `apply_edits.py`：判定と直しを `b2_判定.json` に重ね、`tools/stage_b/b2_texts.json` と `authoring/b2_results/` を書き直す。
5. `lint_edits.py`・`face_scan.py`：直した本文の機械点検（台詞の数、部位の語の数、顔の語と向き など）。
6. 本体を作り直し、関係する試験を流す。
