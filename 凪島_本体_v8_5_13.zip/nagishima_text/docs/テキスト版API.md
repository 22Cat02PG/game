# テキスト試作版の操作API

この文書は、添付された本体骨組みv2.1に、テストフェーズ向けの一括実行・自動プレイ・再現ログを追加した入口を説明する。添付資料のGUI制作、販売、全原稿の指示は今回の完了条件に含めない。ゲームのルールは `nagishima.engine.Engine` にあり、人間CLI、JSON Lines、自動プレイヤーは同じ `Engine.choose` を通る。

## 起動

本体フォルダーでPython 3.12以降を使う。

現在のCLIは`interaction_008`（段階A2）で新規開始する。段階Bは`--release interaction_009`で明示的に選ぶ。Pythonで`Engine(...)`を直接作る場合も段階Bには`Engine(..., release="interaction_009")`を指定する。003〜008の公開版は残している。

```text
python -m nagishima
python -m nagishima --autoplay --seed 42 --max-turns 200 --no-autosave --log runs/auto.jsonl
python -m nagishima --autoplay-social --seed 42 --max-turns 200 --no-autosave --log runs/social.jsonl
python -m nagishima --batch examples/clear.jsonl --release base --seed 42 --max-turns 200 --no-autosave --log runs/batch.jsonl
python -m nagishima --replay runs/auto.jsonl
```

`--json`、`--batch`、`--autoplay`、`--autoplay-social`、`--replay` は同時に一つだけ指定する。機械向けモードは標準入出力をUTF-8のJSON Linesに固定する。ゲーム本文を自由生成するAIや外部通信は使わない。

009（v8.2.0）では、夜の風呂の時間帯と湯上がりの間に `view.status.bath`（例「21:00ごろ（手が空いたら入る）」「湯上がり（22:35まで）」「済み」）が出る。選択肢 `bath.invite`（一緒にお風呂に入ろうと誘う）、状態 `state.bath`、条件項目 `bath.after`・`bath.together`・`bath.together_count` がある。

009では、`view.status.intimacy` に体位・服・挿入・余力・高まり・夜の締め切りが出る。`view.status.settings` は表現設定、`state.intimacy_history` は終えた回数と結果を返す。JSONの状態は数値も含む。人間用CLIの真帆の数値ゲージは設定を`shown`にしたとき、または`--test-cheats`付きで表示する。

テスト用に`--test-cheats`を付けた場合、`{"command":"cheat","action":"all"}`で関係段階3へ、`{"command":"cheat","action":"intimacy_tier:few"}`などで真帆の慣れを設定できる（v8.0.5：関係段階3以上で、問いがないときだけ。使った保存はチート使用済み）。人間用CLIなら`チート 全開放`、`チート intimacy_tier:few`。設定は通常時とエッチの前の二人の時間に「設定」画面から公開操作で変えられる。エッチ中の保存・読込も可能。

人間用CLIでは表示された番号か操作IDを入力する。`保存 1`、`読込 1`、`戻す 1`、`自動読込 1`、`状態`、`行動`、`終了`も使える。条件を満たさない行動には理由が付く。

## コマンドと応答

JSON Linesでは、1行のリクエストに1行の応答を返す。

```json
{"command":"view"}
{"command":"choose","id":"menu.talk"}
{"command":"choose","id":"begin.two_cups"}
{"command":"save","slot":"slot01"}
{"command":"load","slot":"slot01"}
{"command":"diagnostics"}
{"command":"cheat","action":"contact_unlock"}
{"command":"quit"}
```

`choose` の `revision` と `session` は、両方省略すれば現在の表示から補われ、両方指定すれば古い表示や二重送信を検査できる。片方だけの指定はエラーになる。利用可能な操作は `view.choices` の `available: true` だけで、`available_actions`にも同じ内容が返る。表示・状態・行動一覧・診断・保存枠の照会はシミュレーション時刻や乱数を進めない。

成功・失敗にかかわらず、応答には状態・表示・実行状況が含まれる。

```json
{
  "ok": true,
  "result": {},
  "state": {},
  "view": {},
  "available_actions": [],
  "run": {
    "turns": 1,
    "max_turns": 200,
    "ended": false,
    "reason": null,
    "completed": false,
    "cleared": false
  }
}
```

`state`は読み取り専用のコピーで、直接変更してもゲームへ反映されない。`view`には現在の本文、状態表示、全選択肢、選べない理由、`revision`、`session`がある。`view.status.presence`は真帆の場所、姿勢、距離、続いている触れ合い、外から見える気分を一文で返す。`view.status.mood`は喜び・照れ・安心・関心の0〜2、`mood_label`は人間向けの短い要約。すでに近い状態の「そばへ寄る」、現在と同じ姿勢・移動先・身支度は選択肢から外れる。継続中の触れ合いは操作名が「抱きしめたままでいる」などに変わり、その直後に「腕をほどく」などの終了操作が並ぶ。`run.turns`は送信したコマンド、照会、形式エラーを数える。`Session.observe()`だけは数えない。`--max-turns`は1〜100000で、既定値は200。保存・読込でこの実行回数は戻らない。

終了理由は `completed`、`max_turns`、`quit`、`commands_exhausted`、`eof`、`error`、`policy_stalled`、`interrupted`、`cleared` のいずれかである。`cleared`は自動プレイだけが使い、関係4の後も生活が続く原稿版（`interaction_007`）で関係4に達したことを表す。そのような原稿版では`completed`にならず、`run.cleared`がtrueになる。`completed`は関係段階4、場面なし、提案なしをすべて満たした場合だけである。上限到達やコマンド列終了は正常な停止だが、`run.completed`はfalseなので、機械側は両方を確認する。終了後の追加コマンドは`run_ended`エラーになり、回数も状態も変わらない。

`interaction_007` では `view.status.maho_sleep`（`awake`／`dozing`／`asleep`）を返す。親密度と欲求は、`--test-cheats` 付きの起動か、progression.json の `display` が true のときだけ `view.status.affinity`／`view.status.desire` に出る。`state` には常に `affinity`、`desire`、`maho_sleep` が含まれる。`diagnostics` の `progression` に、親密度の集計、欲求の水準、生活日、節目からの日数、今日のうたた寝の予定、次の節目で足りない条件が出る。真帆が眠っている間、真帆を相手にする選択肢は理由 `maho_sleeping` で選べない。

## Pythonからの自動操作

外部AIやテストコードは、表示を読んでコマンドを返し、結果だけを保存できる。

```python
from nagishima.engine import Engine
from nagishima.session import Session

game = Session(Engine("userdata", seed=42, release="interaction_007", autosave=False), max_turns=200)
while not game.observe()["run"]["ended"]:
    view = game.observe()["view"]
    choice = next(c for c in view["choices"] if c["available"])
    response = game.execute({"command": "choose", "id": choice["id"]})
    if not response["ok"]:
        game.finish("error")
        break
print(game.observe()["run"])
```

同梱の `nagishima.autoplay.next_command(view, state)` は固定した再現用経路、`next_social_command(view, state)`は真帆の提案を受け入れる生活寄り経路である。どちらも公開された表示と状態だけを読み、現在選べる`choose`コマンドを一つ返す。待ち時間や対話的な一時停止はない。`examples/clear.jsonl`はseed 42の再現用経路で、67操作で最後まで到達する。生活寄り経路は70操作で到達する。

## 一括実行と再現ログ

`--batch PATH`はJSON Linesを先頭から実行し、行が尽きたら`commands_exhausted`で終了する。エラーになった行で停止し、それより後ろは実行しない。`--autoplay`と`--autoplay-social`は同梱ポリシーを使い、`--max-turns`で必ず停止する。

`--log PATH`を指定すると、開始時のseed、名前、原稿版、読込枠、上限、各入力と応答、最終状態をJSON Linesへ保存する。同名ログは上書きしない。ログと同名の`.initial`フォルダーに開始時の`data-dir`をコピーするため、再現には`.jsonl`と`.jsonl.initial`を一緒に保管する。開始データに個人情報を置かないテスト用`data-dir`を推奨する。

`--replay LOG`は開始チェックポイントから同じ入力列を実行し、安定した状態・表示・エラーをハッシュ比較する。毎回変わるUIセッション識別子は比較から除く。ルール版や原稿版が変わった場合も、どの応答で不一致になったかを記録する。ログを改変した再生は終了コード3になる。

## 保存と決定性

同じ原稿版、seed、名前、初期保存、コマンド列なら、状態・本文・行動結果を再現できる。`slot01`〜`slot10`は手動保存、`auto1`〜`auto3`は自動保存で、既存の保存はバックアップを残してから置き換える。保存はJSONと検査値を使い、破損・未知の型・登録外の参照を拒否する。

## テストチート

テストチートは --test-cheats を付けた起動でだけ使用できます。{"command":"cheat","action":"all"}（人間用は `チート 全開放`）は、真帆と同じ場所にいて通常時であり、進行中の話・誘い・保留中の関係の話がないときに、関係の節目を1→2→3の順に確定し、気分の4項目を各2にします。成功時には同じ行動の連続記録を空にします。恋人段階で「二人で部屋へ行く」が選べます。終了条件の段階4には進めません。距離、姿勢、場所、時間、資源などは通常どおり検査されます。{"command":"cheat","action":"contact_unlock"}（人間用は `チート 接触解放`）は従来の親密度チートと同じく、関係段階と連続記録を変えず、接触の段階条件だけを解除します。旧名の `intimacy`／`チート 親密度` は `cheat_renamed` で拒否します。`interaction_007` の全開放は、真帆が起きているときだけ使え（眠っていれば `maho_sleeping`）、親密度を35以上に引き上げます。チート中に作った保存にはテスト設定も記録されるため、同じ --test-cheats で読み込めます。通常起動では、その保存も拒否されます。

## 完了判定

テキスト試作版の区切りは「関係段階4へ到達し、場面と提案を残さない」こと。画像、音声、GUI、販売用の原稿量、Python不要の配布形式、対象OS全実機確認は次工程であり、この試作版の完了には含めない。
