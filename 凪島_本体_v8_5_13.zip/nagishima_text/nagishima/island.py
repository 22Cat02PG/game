"""段階C（010、v8.5.11）：島の町（喫茶店・売店）・釣り・休日の昼の支度。仕様 docs/凪島_段階C_仕様_2026-10-08.md の第21節。
決まりは life.json の town・fishing・holiday_lunch 節（nagishima/life_rules.py）。009 にはない。
- 島の町：店は開いている時刻だけ行ける。店の中で閉まる時刻を迎えたら、家へ戻る（town.close.<店>）。売店では品の取り寄せを頼める（今ある注文の仕組み。town.order.<品>）。
  二人で来た回数を店ごとに覚え（state の town.visits）、初めて・常連（regular_from 回目から、店の人に覚えられる）の本文を書き分ける。
  島の町にいるあいだは、夕食の支度・風呂は始まらない（家に戻ってから）。
- 釣り：桟橋で「釣りをする」を終えると、釣果が一つ決まる（本文は場面の終わり activity.fishing.end を fish.last・fish.new で書き分ける）。真帆の手帳の図鑑に数を残し、釣った魚はその日の夕食に出る（fish.dinner.<種>）。
- 休日の昼の支度：仕事のない日の昼、二人で家にいて手が空いたら、台所のイベント（昼の印 meal＝lunch）。終えたら昼食（life.lunch.holiday）。"""
from . import clock
from .codec import digest
from .errors import GameError, ensure
from .progression import day_time, life_day

SEASONS = {3: "spring", 4: "spring", 5: "spring", 6: "summer", 7: "summer", 8: "summer", 9: "autumn", 10: "autumn", 11: "autumn", 12: "winter", 1: "winter", 2: "winter"}


def season(now):
    """ゲームの中の月で決める季節。"""
    return SEASONS[clock.date_time(now).month]


def fish_slot(now):
    """釣りの時間帯（朝 5:01〜12:00・昼〜17:00・夕方〜21:00・夜〜23:00）。"""
    return clock.slot(now)


def town_place(state, pack):
    """二人（こちら）がいる店の決まり。店でなければ None。"""
    town = pack.life.town if pack.life else None
    return town["places"].get(state["actors"]["player"]["location"]) if town else None


def in_town(state, pack, actor="player"):
    town = pack.life.town if pack.life else None
    return bool(town) and state["actors"][actor]["location"] in town["places"]


def hhmm(minute):
    minute %= 1440
    return f"{minute // 60}時" + (f"{minute % 60}分" if minute % 60 else "")


def town_closed(pack, location, now):
    """その店へ今は行けない理由。行けるなら None。"""
    town = pack.life.town if pack.life else None
    row = town["places"].get(location) if town else None
    if row is None:
        return None
    if not row["open"] <= day_time(now) < row["close"]:
        label = pack.catalog["locations"][location]["label"]
        return f"{label}が開いているのは{hhmm(row['open'])}から{hhmm(row['close'])}まで。"
    return None


def fish_book_text(state, pack):
    """真帆の手帳の図鑑（釣った種と数）。"""
    rules = pack.life.fishing
    book = (state.get("fish") or {}).get("book", {})
    caught = [(key, row["label"]) for key, row in rules["species"].items() if book.get(key)]
    lines = ["真帆の手帳の、釣った魚のページ。"]
    lines += ["・" + label + "　" + str(book[key]) + "匹" for key, label in caught]
    rest = len(rules["species"]) - len(caught)
    lines.append(f"（{len(rules['species'])}種のうち {len(caught)}種。" + (f"まだ釣っていない魚が{rest}種いる。）" if rest else "全部の魚を釣った。）"))
    return "\n".join(lines)


def fish_record(state):
    """その暮らしの日の釣りの記録（日が変われば、その日の数と夕食に出す魚を消す）。保存の形は validate_fish を見る。"""
    today = life_day(state["world"]["now"])
    record = state.get("fish") or {"book": {}, "day": today, "sessions": 0, "last": None, "new": False, "dinner": None}
    if record["day"] != today:
        record = dict(record, day=today, sessions=0, dinner=None)
    return record


class Island:
    # ---- 島の町 ----
    def in_town(self):
        return in_town(self.s, self.pack)

    def town_closing(self):
        """店の中で閉まる時刻（または開く前）を迎えたら、店を出て家へ戻る（一緒なら二人で）。finalize から呼ぶ。"""
        row = town_place(self.s, self.pack)
        if row is None or row["open"] <= day_time(self.now) < row["close"]:
            return
        if self.s["mode"] != "normal" or self.s["scene"] or self.s["offer"] or any(x["status"] == "running" for x in self.s["activities"]):
            return
        place = self.s["actors"]["player"]["location"]
        together = self.s["actors"]["maho"]["location"] == place
        self.s["contacts"], self.s["distance"] = [], "normal"
        self.emit("town.close." + place)
        for actor in (("player", "maho") if together else ("player",)):
            self.s["actors"][actor]["location"], self.s["actors"][actor]["posture"] = row["home"], "seated"
        minutes = min(row["minutes"], max(0, self.s["world"]["awake_deadline"] - self.now))
        if minutes:
            before = self.now
            self.advance(minutes)
            self.auto_minutes += self.now - before

    def shop_order(self, kind):
        """売店で、品の取り寄せを頼む（今ある注文の仕組み。次の便で届き、居間の保管場所で受け取る）。一人でも頼める。"""
        town = self.pack.life.town if self.pack.life else None
        ensure(town is not None, "town", "この原稿版に島の町はない。")
        order = town["order"]
        ensure(self.s["actors"]["player"]["location"] == order["place"], "shop", self.pack.catalog["locations"][order["place"]]["label"] + "で頼む。")
        ensure(kind in order["items"], "shop", "この店では頼めない。")
        self.free()
        self.require_time(order["minutes"])
        before = len(self.events)
        self.create_order(kind)
        del self.events[before:]  # 注文の一言（order.created）の代わりに、売店で頼む本文
        if order["minutes"]:
            self.advance(order["minutes"])
        self.emit("town.order." + kind)

    def town_visit(self, place):
        """二人で店に着いたら、その店に来た回数を一つ足す（着いた本文を出したあとに呼ぶ。本文は足す前の回数で書き分ける）。"""
        record = dict(self.s.get("town") or {"visits": {}})
        visits = dict(record["visits"])
        visits[place] = visits.get(place, 0) + 1
        self.s["town"] = dict(record, visits=visits)

    # ---- 釣り ----
    def fishing_block(self):
        """釣りを始められない理由（時刻。終わりが夜釣りの終わり until を過ぎるなら始めない）。始められるなら None。雨の日もできる。"""
        rules = self.pack.life.fishing
        start = day_time(self.now)
        if not rules["from"] <= start or start + self.pack.catalog["activities"][rules["activity"]]["minutes"] > rules["until"]:
            return "夜釣りは23時まで。今からでは、もう竿を出せない。"
        return None

    def fishing_result(self):
        """「釣りをする」を終えたとき：釣果を決めて本文を出し、図鑑と夕食に出す魚を覚える。"""
        rules = self.pack.life.fishing
        record = fish_record(self.s)
        slot, now_season = fish_slot(self.now), season(self.now)
        weather = clock.weather(self.s["world"]["seed"], self.now // 1440)
        weights = [("none", rules["none"])]
        for key, row in rules["species"].items():
            if slot not in row["slots"] or weather not in row["weathers"]:
                continue
            weight = rules["rarity"][row["rarity"]]
            if now_season in row["seasons"]:
                weight = weight * rules["season_percent"] // 100
            weights.append((key, weight))
        total = sum(w for _, w in weights)
        value = int(digest([self.s["world"]["seed"], "fish", record["day"], record["sessions"]])[:12], 16) % total
        caught = None
        for key, weight in weights:
            if value < weight:
                caught = key
                break
            value -= weight
        record["sessions"] += 1
        if caught == "none":
            record.update(last="none", new=False)
            self.s["fish"] = record
            return  # 本文は場面の終わり（activity.fishing.end、fish.last＝none）
        book = dict(record["book"])
        record["new"] = caught not in book
        book[caught] = book.get(caught, 0) + 1
        record.update(book=book, last=caught)
        if rules["species"][caught]["dinner"]:
            order = list(rules["rarity"])  # めずらしさの重みの並び（先ほどよく釣れる）
            current = record["dinner"]
            if current is None or order.index(rules["species"][caught]["rarity"]) >= order.index(rules["species"][current]["rarity"]):
                record["dinner"] = caught  # その日いちばんめずらしい魚（同じなら新しい方）を夕食に
        self.s["fish"] = record  # 本文は場面の終わり（activity.fishing.end、fish.last＝その種・fish.new）

    def fish_book(self):
        ensure(self.pack.life and self.pack.life.fishing, "fish", "この原稿版に釣りはない。")
        ensure((self.s.get("fish") or {}).get("book"), "fish", "まだ魚を釣っていない。")
        self.emit("fish.book")
        self.events[-1]["body"] = fish_book_text(self.s, self.pack)

    def fish_dinner_take(self):
        """夕食に出す、その日に釣った魚（なければ None）。出したら消す。"""
        if not (self.pack.life and self.pack.life.fishing):
            return None
        record = self.s.get("fish")
        if not record or record["day"] != life_day(self.now) or record["dinner"] is None:
            return None
        caught = record["dinner"]
        self.s["fish"] = dict(record, dinner=None)
        return caught

    # ---- 休日の昼の支度 ----
    def auto_lunch(self):
        """仕事のない日の昼、二人で家にいて手が空いたら、真帆が台所で昼の支度を始める（台所のイベント、昼の印）。finalize から呼ぶ。"""
        life = self.pack.life
        rules = life.holiday_lunch if life else None
        if not rules or not self.pack.intimacy or not self.pack.intimacy.events or "kitchen" not in self.pack.intimacy.events.events:
            return
        if clock.date_time(life_day(self.now) * 1440).weekday() in life.weekdays:
            return
        if not rules["from"] <= day_time(self.now) < rules["until"]:
            return
        if self.s["mode"] != "normal" or self.s["scene"] or self.s["offer"] or any(x["status"] == "running" for x in self.s["activities"]):
            return
        if self.s["maho_sleep"]["state"] != "awake" or not self.can_offer("meal_lunch") or self.deep_touching():
            return
        groups = {self.pack.catalog["locations"][self.s["actors"][a]["location"]]["group"] for a in ("player", "maho")}
        if groups != {"residence"}:
            return  # 家の外（島・町）にいるときは始めない
        self.s["contacts"] = []
        for actor in self.s["actors"].values():
            actor["location"], actor["posture"] = "kitchen", "standing"
        self.event_begin("kitchen", meal="lunch")

    def eat_lunch(self, text=True):
        """休日の昼食（台所で食べて、食後は居間へ）。"""
        minutes = min(self.pack.life.lunch["minutes"] if self.pack.life.lunch else 20, max(0, self.s["world"]["awake_deadline"] - self.now))
        self.record_offer("meal_lunch")
        self.s["contacts"] = []
        for actor in self.s["actors"].values():
            actor["location"], actor["posture"] = "living_room", "seated"
        self.s["distance"] = "normal"
        before = self.now
        self.advance(minutes)
        self.auto_minutes += self.now - before
        if text:
            self.emit("life.lunch.holiday")
