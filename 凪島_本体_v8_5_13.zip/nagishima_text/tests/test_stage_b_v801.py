"""Public-path checks for the Opus v8.0.1 corrections."""
import unittest

from tools.run_stage_b_routes import Route, quick_hold
from tools.build_stage_b_jobs import validate_jobs
from tools.check_stage_b_job_coverage import run as check_job_coverage


class StageB801Corrections(unittest.TestCase):
    def test_f1_invite_emits_only_begin_from_both_rooms(self):
        from tools.run_stage_b_routes import DAYTIME, to_evening, listen_for_invite
        for start in ("player_room", "living_room"):
            route = Route(42, **DAYTIME)  # B2：夜に終えると翌朝になるので、休日の昼に二度終えてから夜を待つ
            try:
                quick_hold(route)
                quick_hold(route)
                to_evening(route)
                if route.engine.snapshot()["actors"]["player"]["location"] != start:
                    # v8.2.29：昼に終えると二人とも居間へ移る（寄り添って過ごしてから身支度）。自分の部屋へは二人で移る選択肢がないので、
                    # 準備として二人の居場所を自分の部屋にする（確かめるのは、そこで誘いを受けたときの本文と入口）
                    for actor in route.engine._state["actors"].values():
                        actor["location"] = start
                    route.engine._install_choices()
                self.assertEqual(route.engine.snapshot()["actors"]["player"]["location"], start)
                listen_for_invite(route)
                self.assertEqual(route.engine.snapshot()["offer"]["kind"], "intimacy_invite")
                route.choose("offer.accept")
                state = route.engine.snapshot()
                self.assertEqual([block["meaning"] for block in route.engine.get_view()["blocks"]], ["h.begin.invite"])
                self.assertEqual(state["actors"]["player"]["location"], "maho_room")
                self.assertEqual((state["intimacy"]["entry"], state["intimacy"]["origin"]), ("invite", "maho"))
            finally:
                route.close()

    def test_f2_presence_has_sentences_for_each_clothing_label(self):
        route = Route(42)
        try:
            route.begin()
            self.assertEqual(route.engine.get_view()["status"]["presence"],
                             "ベッドの縁に並んで座り、寄り添っている。上は着たまま。下は履いたまま。")
        finally:
            route.close()

    def test_f3_setting_labels_are_japanese_and_ids_stable(self):
        route = Route(42)
        try:
            route.choose("menu.settings")
            rows = {choice["id"]: choice["label"] for choice in route.engine.get_view()["choices"]}
            # v8.2.29（ユーザー 2026-09-30）：ひな形は例の語を添える。台詞の多さは選ばない。1つずつ選ぶのは別のページ
            self.assertEqual(rows["settings.preset.mild"], "性器などの呼び方：控えめ（秘部・ペニス・蜜 など）")
            self.assertFalse(any(key.startswith("settings.density.") for key in rows))  # v8.2.2：濃さは高まりで決まり、選ばない
            self.assertFalse(any(key.startswith("settings.speech.") for key in rows))
            self.assertEqual(rows["settings.gauges.hidden"], "真帆の数値：隠す")  # B2：既定は表示する
            route.choose("menu.settings_terms")
            terms = {choice["id"]: choice["label"] for choice in route.engine.get_view()["choices"]}
            self.assertTrue(terms["settings.term.penis.2"].startswith("男性器の呼び方："))
            rows.update(terms)
            for label in rows.values():
                self.assertFalse(any(word in label for word in ("penis", "explicit", "few", "shown", "hidden")), label)
        finally:
            route.close()

    def test_f4_settings_work_in_private_before_intimacy_without_time(self):
        route = Route(42)
        try:
            route.choose("private.begin")
            now = route.engine.snapshot()["world"]["now"]
            route.choose("menu.settings")
            route.choose("settings.preset.mild")
            self.assertEqual(route.engine.snapshot()["world"]["now"], now)
            self.assertEqual(route.engine.snapshot()["settings"]["terms"], route.engine.pack.intimacy.settings["term_presets"]["mild"])
            route.choose("menu.main")
            route.choose("menu.touch")
            route.choose("touch.h_kiss_deep")
            self.assertNotIn("menu.settings", {choice["id"] for choice in route.engine.get_view()["choices"]})
        finally:
            route.close()

    def test_d1_both_deflections_are_reachable(self):
        route = Route(42)
        try:
            route.begin()
            for key in ("h_strip_lower", "h_shift_under", "h_pos_lying_face"):
                route.action(key)
            self.assertEqual(route.engine.snapshot()["intimacy"]["maho"]["band"], "low")
            route.action("h_touch_direct")
            self.assertEqual(route.status()["blocks"][-1], "h.deflect.hand")
            choice = next(c for c in route.engine.get_view()["choices"] if c["id"] == "touch.h_touch_direct")
            self.assertEqual(choice["reason"], "h_ready")
            for key in ("h_strip_self", "h_pos_player_above"):
                route.action(key)
            route.action("h_insert")
            self.assertEqual(route.status()["blocks"][-1], "h.deflect.insert")
            choice = next(c for c in route.engine.get_view()["choices"] if c["id"] == "touch.h_insert")
            self.assertEqual(choice["reason"], "h_ready")
            while route.engine.snapshot()["intimacy"]["maho"]["arousal"] < 40:
                route.action("h_kiss_deep")
            route.action("h_touch_direct")
            route.action("h_insert")
            self.assertTrue(route.engine.snapshot()["intimacy"]["inserted"])
        finally:
            route.close()

    def test_jobs_are_opus_source_and_validate(self):
        self.assertEqual(validate_jobs(), {1: 118, 2: 150, 3: 95})

    def test_jobs_do_not_fall_back_on_eighteen_routes_and_deflections(self):
        result = check_job_coverage()
        self.assertEqual(len(result["routes"]), 19)
        self.assertTrue(all(row["success"] for row in result["routes"]), result["routes"])
        self.assertFalse(result["fallback_mismatches"], result["fallback_mismatches"])


if __name__ == "__main__":
    unittest.main()
