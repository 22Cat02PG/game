# 操作APIと保存

追記（v8.0.5）：009 のいつもの時間の話す・触れる・続ける・`listen`（表示「真帆の様子を見る」。真帆と同じ場所で起きているときだけ出す）は時刻を進め、選択肢の `duration` に分が出る。仕事の時間の中では `work_time` で選べない。慣れのチート（`intimacy_tier`）は関係段階3以上で、問いがないときだけ使え、使った保存は `test_cheats` 付きになる。intimacy.json のない版（003〜008）の保存に段階Bの項目があれば `state_fields` で拒否する（v7.1.2 と同じ）。保存の形（schema 4）は変えていない。v8.0.4 までの 009 の保存は、原稿の版が変わったため読めない。

追記（v8.0.4。v8.0.1 から変更なし）：`interaction_009`はルール版`nagishima-2.4`、保存schema 4。エッチの進行状態、余力、履歴、服、表現設定を保存する。設定は通常時とエッチの前の二人の時間に変更できる。009のエッチ中（挿入中・引き留めや提案の問いの間を含む）にも保存・読込でき、読込後は同じ選択肢に戻る。schema 3の007・008保存は元の原稿版で読み込める。008から009への切替は、通常時で問い・保留した話・二人の時間がないときに許し、段階Bの状態を中立値で足す。009の保存は旧本体では読めない。新規開始の既定版は008のまま。

これは本体骨組みv2.1のEngine API資料です。現在のCLI・JSON Linesは`テキスト版API.md`を参照してください。現在はquitにも応答し、最後に終了理由を含むsummaryを返します。

画面は本体の状態を直接変更せず、表示された選択肢を送る。Pythonから直接呼び出す方法と、標準入出力のJSON Linesを用意した。どちらも同じEngineを使う。ローカルファイルのAPIであり、外部からアクセスするHTTPサーバーは含めない。

## Pythonの入口

```python
from nagishima.engine import Engine

game = Engine(data_dir="userdata")
view = game.get_view()
choice = next(c for c in view["choices"] if c["id"] == "menu.talk")
view = game.choose(choice["id"], view["revision"], view["session"])
game.save("slot01")
game.load("slot01")
```

`get_view()` は状態を進めない。画面内には `blocks`（確定済み本文）、`choices`（操作ID・表示名・可否・理由コード・所要時間）、`question_owner`、`status`、`warnings` がある。説明文は `explanations`。描画、再表示、文字送り、読み上げで本文を選び直さない。

`choose(id, revision, session)` には最新の表示が返した値を渡す。古い表示・二重送信・読込前のセッションは拒否される。画面移動でもrevisionは進むが、時間・経験・乱数は進まない。

`GameError` は `code` と `message` を持つ。操作失敗なら現在の表示を保持する。自動保存だけが失敗したときは、選択後の画面を保持してwarningsで伝える。保存成功と選択成功を同じものとして扱わない。

## JSON Lines

```bash
python3 -m nagishima --json --data-dir userdata
```

1行に一つのJSONリクエストを送り、1行の応答を読む。`quit`にも応答し、終了理由を含む最後のsummaryを返す。

| command | 追加する項目 | 内容 |
| --- | --- | --- |
| view | なし | 現在の表示 |
| choose | id / revision / session | 表示中の操作を選ぶ |
| save | slot（省略時slot01） | 手動保存 |
| load | slot / backup（省略時false） | 保存またはバックアップから復元 |
| slots | なし | 保存枠の有無 |
| collection | kind / id（回想のみ） | 思い出などの読取専用一覧 |
| adopt | release | 新しい原稿版を採用 |
| diagnostics | なし | 再現条件、直近の候補数、不可理由、保存予算 |
| quit | なし | 終了 |

例：`{"command":"view"}`、`{"command":"save","slot":"slot01"}`。成功は `{"ok":true,"result":...}`、失敗は `{"ok":false,"error":{"code":"...","message":"..."}}`。標準出力にその他の説明は混ぜない。

collectionのkindは `memories`、`gallery`、`replay`、`promises`、`promise_history`、`orders`、`order_history`、`items`、`project`、`inbox`。回想はgalleryのidをreplayのidへ渡す。表示側のログ・文字サイズ・音量・オート・既読管理は、本編のstateとは別に持たせる。オートやスキップは問いへの返事を選ばない。

## 保存の形

`userdata/saves/slot01.json`〜`slot10.json` が手動枠、`auto1.json`〜`auto3.json` が新しい順の自動保存。各枠の `.bak` が前の有効な保存。破損した主ファイルを読み直して、有効なバックアップを上書きすることはしない。

保存は一時ファイルへ書込みと同期を行い、置換して確定する。読込ではサイズ、JSON、checksum、保存版、公開版のhash、状態の型と相互関係、表示した問いと選択肢の一致を順に確認する。全部成功するまで進行中のゲームを置き換えない。checksumは破損を検知するためのもので、作者や編集者の本人証明ではない。

ルール版 `nagishima-2.1`、保存schema `1`。旧v0.7/v0.8の保存データは変換しない。新しい型や動作を含む本体更新では、明示的な移行器と確認を別途実装する。対応しないセーブを項目名の類似だけで推測して読むことはしない。

追記（v7.0）：現在はルール版 `nagishima-2.3`、保存schema `3`。schema 2（2.2）とschema 1（2.1）の保存は、段階Aの項目（`affinity`、`desire`、`maho_sleep`）を中立値で補い、テストチートの記録名 `intimacy` を `contact_unlock` に改めて読む。原稿版は保存時のまま。`interaction_003`〜`interaction_006` から `interaction_007` への切替は、問い・保留中の場面・二人の時間がないときだけ許し、親密度を関係段階の下限に置く（仕様書第12節）。

## 原稿の更新

公開版は `content/releases/<版名>/` または `userdata/releases/<版名>/`。各版はcatalog、actions、scenes、meanings、textsと、それらのhashを持つrelease.jsonで固定する。同じ版名の内容を変えると保存との一致検査で止まる。

本文や場面だけを追加した版は、問いを区切った状態で `game.adopt_release("prose_002")`、または `{"command":"adopt","release":"prose_002"}` で採用する。採用後に保存する。進行中の問いがあれば先に回答・終了・保留する。`interaction_003`は動作・資源・経験登録を追加した構造版なので旧セーブには採用できず、新規開始時に指定する。

保留中の場面は開始時の版を使い続け、新しく開始する場面は採用した版を使う。したがって以前の公開版を削除しない。catalog/actionsのhashが違う版は、この追加手順では採用できない。

## 回想と容量

回想の全文は `userdata/collection/<sha256>.json` に保存する。本編セーブは参照と一覧を持つ。回想ファイルが失われた場合でも生活のセーブは読めるが、その回想の全文は復元できない。途中の場面記録が欠けた場合は、その後の記録に不足の印を付ける。

回想一覧は128件、一つの場面記録は直近256ブロック。古いセーブから参照されるファイルを守るため、自動的な回想ファイル削除は実装していない。プレイ時間に応じてcollection全体は増える。保管・移動はuserdata全体で行い、公開版と回想を保存JSONから切り離さない。

登録された型と記録件数の上限から、保存量の保守的な上限を公開前に求める。24MiBを超える構成を拒否し、実際の保存ファイルは32MiBを上限にする。この上限は本編セーブ一件に対するもので、全セーブ・全回想・全公開版の合計容量の保証ではない。
