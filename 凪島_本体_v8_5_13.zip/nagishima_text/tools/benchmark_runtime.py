"""Synthetic scale measurement through Engine.choose, not a mock selector."""
from pathlib import Path
from tempfile import TemporaryDirectory
import argparse
import math
import platform
import statistics
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from nagishima.authoring import publish
from nagishima.codec import write_json
from nagishima.content import Pack
from nagishima.engine import Engine
from tests.support import activity, do, stage_two


def press(engine, identity):
    frame = engine.get_view()
    return engine.choose(identity, frame["revision"], frame["session"])


def measure(engine, autosave, count):
    engine.autosave_enabled = autosave
    samples = []
    for _ in range(count):
        start = time.perf_counter_ns()
        press(engine, "touch.talk")
        samples.append((time.perf_counter_ns() - start) / 1_000_000)
    ordered = sorted(samples)
    candidates = engine.get_diagnostics()["last_selection"]["candidates"]
    assert candidates[-1]["meaning"] == "talk.start" and candidates[-1]["count"] >= 10000
    return {"autosave": autosave, "samples": count, "median_ms": statistics.median(samples),
            "p95_ms": ordered[math.ceil(count * .95) - 1], "maximum_ms": max(samples),
            "raw_ms": samples, "last_selection": candidates}


def measure_release(release, repetitions=20):
    """Measure identical public operations on fresh games, excluding startup."""
    commands = ("menu.talk", "touch.talk", "menu.main", "wait.30")
    samples = {command: [] for command in commands}
    with TemporaryDirectory(prefix="benchmark-release-") as directory:
        for index in range(repetitions):
            engine = Engine(Path(directory) / str(index), seed=11, release=release, autosave=False)
            for command in commands:
                start = time.perf_counter_ns()
                press(engine, command)
                samples[command].append((time.perf_counter_ns() - start) / 1_000_000)
    result = {"release": release, "python": platform.python_version(), "platform": platform.platform(),
              "seed": 11, "repetitions": repetitions, "commands": list(commands),
              "measurement": "Engine.choose including view update; fresh game for each sequence; startup excluded",
              "operations": {command: {"median_ms": statistics.median(values),
                                       "p95_ms": sorted(values)[math.ceil(len(values) * .95) - 1]}
                             for command, values in samples.items()}}
    target = ROOT / "verification" / f"benchmark_release_{release}.json"
    write_json(target, result)
    print(target)
    for command, value in result["operations"].items():
        print(f"{command}: median {value['median_ms']:.2f} ms, p95 {value['p95_ms']:.2f} ms")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--release", choices=("interaction_006", "interaction_007"))
    args = parser.parse_args()
    if args.release:
        measure_release(args.release)
        return
    source = Pack(ROOT / "content/releases/base")
    meanings = ["talk.start"] + [m for m in sorted(source.meanings) if m != "talk.start"][:9]
    texts = [{"id": f"benchmark.text{i}", "meaning": meanings[i // 10000],
              "when": {"all": []}, "slots": [], "group": f"benchmark.group{i % 31}",
              "body": "応答時間を測るための合成原稿。製品用の文章ではない。", "fallback": False}
             for i in range(100000)]
    with TemporaryDirectory(prefix="benchmark-", dir=ROOT) as directory:
        directory = Path(directory)
        start = time.perf_counter()
        publish(source, directory / "releases", "benchmark", [], base_texts=texts)
        publish_seconds = time.perf_counter() - start
        start = time.perf_counter()
        engine = Engine(directory, release="benchmark", autosave=False)
        load_seconds = time.perf_counter() - start
        press(engine, "menu.touch")
        for _ in range(3): press(engine, "touch.talk")
        reports = [{"state": "fresh", **measure(engine, False, 40)}, {"state": "fresh", **measure(engine, True, 20)}]
        engine.autosave_enabled = False
        stage_two(engine)
        for i in range(260):
            if i % 10 == 0: do(engine, "main", "sleep")
            activity(engine, "tea")
        for scene in ("two_cups", "shared_place", "remember_tea"):
            do(engine, "talk", "begin." + scene)
            press(engine, "scene.pause")
        do(engine, "touch", "touch.talk")
        state = engine.snapshot()
        assert len(state["memories"]["recent"]) == 256 and len(state["suspended"]) == 3
        reports += [{"state": "256_memories_3_suspended", **measure(engine, False, 40)},
                    {"state": "256_memories_3_suspended", **measure(engine, True, 20)}]
        result = {"python": platform.python_version(), "platform": platform.platform(),
                  "source_release_sha256": source.hash, "total_texts": len(engine.pack.texts),
                  "added_texts": len(texts), "publication_seconds": publish_seconds,
                  "load_seconds": load_seconds, "measurements": reports,
                  "save_bytes": engine.save()["bytes"],
                  "scope": "Engine.get_view + Engine.choose, 10000 candidates, fresh and 256 memories/3 suspended scenes, outside active scene; Linux measurement only; not Windows qualification."}
    target = ROOT / "verification/benchmark.json"
    target.parent.mkdir(exist_ok=True)
    write_json(target, result)
    print(f"原稿 {result['total_texts']} 件、起動 {load_seconds:.3f} 秒")
    for report in reports: print(f"{report['state']}, 自動保存 {report['autosave']}: p95 {report['p95_ms']:.2f} ms")
    print(target)


if __name__ == "__main__": main()
