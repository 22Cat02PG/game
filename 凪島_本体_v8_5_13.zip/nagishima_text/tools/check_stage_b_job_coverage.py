"""Try every Opus job as authored prose during public Stage B routes."""
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from nagishima.conditions import evaluate
from tools.build_stage_b_jobs import validate_jobs
from tools.run_stage_b_routes import Route, route_for, satisfied, quick_hold, deadline, stamina_zero, invite, maho_lead_together

ROUTES = (("first_satisfied", satisfied), ("first_hold_back_decline", quick_hold),
          ("workday_deadline", deadline), ("stamina_zero_hold_back", stamina_zero),
          ("maho_invite", invite), ("maho_lead_together", maho_lead_together))


def rows():
    for wave in (1, 2, 3):
        yield from json.loads((ROOT / f"authoring/b_jobs/grok_wave_{wave}.json").read_text(encoding="utf-8"))


def attach(route, records, failures):
    pack = route.engine.pack
    authored = {}
    for job in rows():
        record = {"id": job["id"] + ".v1", "meaning": job["_meaning"], "when": job["when"],
                  "slots": [], "group": job["group"], "body": "試験用の仮本文。", "fallback": False}
        authored.setdefault(record["meaning"], []).append(record)
        pack.by_meaning[record["meaning"]].append(record)
        pack.by_text[record["id"]] = record
    original = pack.select

    def selected(meaning, state, bindings, values=None):
        result = original(meaning, state, bindings, values)
        if meaning in authored:
            candidates = [item for item in authored[meaning] if evaluate(item["when"], values if values is not None else pack.registry.values(state)) is True]
            records.append((meaning, result[0]["variant"], len(candidates)))
            # 採用本文（v8.0.2 以降）も試験用の本文も、書かれた本文なら可。fallback に落ちたときだけ不一致にする。
            if not candidates or pack.by_text[result[0]["variant"]]["fallback"]:
                failures.append({"meaning": meaning, "variant": result[0]["variant"], "eligible": len(candidates),
                                 "seed": route.seed, "commands": list(route.commands)})
        return result

    pack.select = selected


def run():
    validate_jobs()
    outcomes, selected, failures = [], [], []
    for name, runner in ROUTES:
        for seed in (0, 42, 20380407):
            route = route_for(name, seed)
            try:
                attach(route, selected, failures)
                runner(route)
                outcomes.append({"route": name, "seed": seed, "success": True})
            except Exception as error:
                outcomes.append({"route": name, "seed": seed, "success": False, "error": repr(error), "commands": route.commands})
            finally:
                route.close()
    route = Route(42)
    try:
        attach(route, selected, failures)
        before = len(selected)
        route.begin()
        for key in ("h_strip_lower", "h_shift_under", "h_pos_lying_face", "h_touch_direct", "h_strip_self", "h_pos_player_above", "h_insert"):
            route.action(key)
        outcomes.append({"route": "d1_both_deflections", "seed": 42, "success": {"h.deflect.hand", "h.deflect.insert"} <= {item[0] for item in selected[before:]}})
    finally:
        route.close()
    result = {"routes": outcomes, "authored_selections": len(selected), "meanings_reached": sorted({item[0] for item in selected}), "fallback_mismatches": failures}
    return result


def main():
    result = run()
    target = ROOT / "verification/stage_b_job_coverage.json"
    target.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print("routes", len(result["routes"]), "selected", result["authored_selections"], "meanings", len(result["meanings_reached"]), "mismatches", len(result["fallback_mismatches"]))
    return 0 if all(row["success"] for row in result["routes"]) and not result["fallback_mismatches"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
