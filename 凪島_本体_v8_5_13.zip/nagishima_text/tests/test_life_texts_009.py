"""009 の生活の本文：Opus が書いた本文（仕様 9.6 と眠り・目覚めの一言）と、008 から受け継いだ下書きの書き直し。"""
import json
import unittest
from pathlib import Path

from nagishima.content import Pack
from tools.build_intimacy_release import text_fix_conditions

ROOT = Path(__file__).resolve().parents[1]


class LifeTexts009(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.p8 = Pack(ROOT / "content/releases/interaction_008")
        cls.p9 = Pack(ROOT / "content/releases/interaction_009")
        cls.added = json.loads((ROOT / "tools/stage_b/life_texts.json").read_text(encoding="utf-8"))
        cls.edits = json.loads((ROOT / "tools/stage_b/life_edits.json").read_text(encoding="utf-8"))

    def test_added_texts_are_in_009_only(self):
        for row in self.added:
            text = self.p9.by_text[row["id"]]
            self.assertEqual((text["meaning"], text["when"], text["group"], text["body"], text["fallback"], text["slots"]),
                             (row["meaning"], row["when"], row["group"], row["body"], False, []), row["id"])
            self.assertNotIn(row["id"], self.p8.by_text)

    def test_edits_change_009_and_leave_008(self):
        fix_when, _, _ = text_fix_conditions()  # v8.2.26：精査の直しで 009 だけに足した条件（朝の「今日のことを話す」など）
        for identity, edit in self.edits.items():
            self.assertEqual(self.p8.by_text[identity]["body"], edit["orig"], identity)
            self.assertEqual(self.p9.by_text[identity]["body"], edit["body"], identity)
            for key in ("meaning", "when", "group", "slots", "fallback"):
                expected = self.p8.by_text[identity][key]
                if key == "when" and identity in fix_when:
                    base = expected["all"] if set(expected) == {"all"} else [expected]
                    expected = {"all": base + [c for c in fix_when[identity] if c not in base]}
                self.assertEqual(self.p9.by_text[identity][key], expected, (identity, key))

    def test_spec_96_counts(self):
        for meaning, speech in (("back.continue", True), ("back.settled", True), ("hair.continue", True), ("hair.settled", True),
                                ("waist.continue", True), ("waist.settled", True), ("head.continue", False), ("head.settled", False)):
            rows = [r for r in self.added if r["meaning"] == meaning]
            self.assertEqual(len(rows), 3, meaning)
            self.assertTrue(all(("「" in r["body"]) == speech for r in rows), meaning)

    def test_sleep_lines_have_several_texts_and_room_variant(self):
        for meaning in ("maho.dozed_off", "maho.woke", "maho.woken", "maho.went_to_bed"):
            authored = [t for t in self.p9.by_meaning[meaning] if not t["fallback"]]
            self.assertGreaterEqual(len(authored), 4, meaning)
        room = {"all": [{"field": "actor.maho.location", "op": "eq", "value": "maho_room"}]}
        other = {"all": [{"field": "actor.maho.location", "op": "ne", "value": "maho_room"}]}
        whens = [t["when"] for t in self.p9.by_meaning["maho.went_to_bed"] if not t["fallback"]]
        self.assertIn(room, whens)
        self.assertIn(other, whens)
        self.assertTrue(all(w in (room, other) for w in whens))


if __name__ == "__main__":
    unittest.main()


class BedtimeInMahoRoom(unittest.TestCase):
    """休日前夜に真帆の部屋で就寝の時刻を過ぎても、「終える」を選べ、主人公は自分の部屋へ戻る（v8.0.4 の修正）。"""

    def test_end_after_bedtime_in_maho_room(self):
        import tempfile
        from nagishima import clock
        from nagishima.engine import Engine
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        engine = Engine(temp.name, seed=11, release="interaction_009", autosave=False, test_cheats=True)
        engine.enable_test_cheat("all")
        engine.enable_test_cheat("intimacy_tier:few")  # v8.2.30：初めての回は締め切りまで60分ないと始めないので、数回の回で確かめる
        # 準備だけ内部状態を使う：金曜の夜の 1:00、二人とも真帆の部屋。
        day = engine._state["world"]["now"] // 1440
        while clock.date_time(day * 1440).weekday() != 4:
            day += 1
        engine._state["world"]["now"] = day * 1440 + 25 * 60
        engine._state["world"]["processed_until"] = engine._state["world"]["now"]
        engine._state["world"]["awake_deadline"] = max(engine._state["world"]["awake_deadline"], engine._state["world"]["now"] + 600)
        for actor in ("player", "maho"):
            engine._state["actors"][actor]["location"] = "maho_room"
        engine._install_choices()

        def choose(identity):
            view = engine.get_view()
            option = next((c for c in view["choices"] if c["id"] == identity), None)
            if option is None or not option["available"]:
                return None
            return engine.choose(identity, view["revision"], view["session"])

        snapshot = engine._state
        saved = __import__("copy").deepcopy(snapshot)
        self.assertIsNotNone(choose("private.begin"))
        self.assertIsNotNone(choose("menu.touch"))
        while choose("touch.h_kiss_deep") is not None:
            pass
        if engine.get_view()["page"] != "main":
            choose("menu.main")
        view = choose("h.end")
        self.assertIsNotNone(view, "「終える」が選べない")
        while engine.snapshot()["offer"] is not None:
            self.assertIsNotNone(choose("offer.decline"))
        state = engine.snapshot()
        self.assertIsNone(state["intimacy"])
        # B2：夜にエッチを終えたら、そのまま一緒に眠って翌朝へ（真帆の就寝の一言は出ない）
        self.assertEqual(state["maho_sleep"]["state"], "awake")
        meanings = [b["meaning"] for b in engine.get_view()["blocks"]]
        self.assertTrue({"h.sleep_together.satisfied", "h.sleep_together.unsatisfied"} & set(meanings), meanings)
        # エッチをしない二人の時間は、これまでどおり就寝の時刻に真帆が眠り、主人公は自分の部屋へ戻る
        engine._state = saved
        engine._install_choices()
        self.assertIsNotNone(choose("private.begin"))
        self.assertIsNotNone(choose("private.end"))
        state = engine.snapshot()
        self.assertEqual(state["maho_sleep"]["state"], "asleep")
        self.assertEqual(state["actors"]["player"]["location"], "player_room")
        variants = [b["variant"] for b in engine.get_view()["blocks"]]
        self.assertTrue(any(v.startswith("maho.went_to_bed.o1.") and v.endswith((".4", ".5")) for v in variants), variants)
