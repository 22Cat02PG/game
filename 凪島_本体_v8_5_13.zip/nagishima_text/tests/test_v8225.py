"""v8.2.25（ユーザー 2026-09-30「gptからの指摘だよ。判断して」「他にもこのレベルの破綻がないか一回精査して自己レビューして」）：
直前の出来事と本文・自動の出来事の食い違いの直し。指摘票 R1・R2 と、精査（A エッチの流れ・B 暮らし・C 本文の前提・D v8.2.23〜24 の変更のレビュー）のうち、直し方がはっきりしているもの。
公開の選択肢（Engine.choose／get_view）から確かめる（時刻・慣れ・高まり・欲求・経験回数の準備だけ内部で行う）。"""
import json
import tempfile
import unittest
from pathlib import Path

from nagishima.engine import Engine
from nagishima.progression import life_day
from tools.run_stage_b_routes import Route, dinner_done

ROOT = Path(__file__).resolve().parents[1]
PAGES = ["main", "talk", "touch", "activities", "move", "plans", "resume", "memories"]


def meanings(engine):
    return [b["meaning"] for b in engine.get_view()["blocks"]]


def text_ids(engine):
    return [b["variant"] for b in engine.get_view()["blocks"]]


class Life:
    """公開の選択肢だけで暮らしを進める（ページを探して選ぶ）。"""

    def __init__(self, seed, cheats=False):
        self.temp = tempfile.TemporaryDirectory(prefix="nagishima-v8225-")
        self.engine = Engine(self.temp.name, seed=seed, release="interaction_009", autosave=False, test_cheats=True)
        if cheats:
            self.engine.enable_test_cheat("all")

    def close(self):
        self.temp.cleanup()

    def find(self, identity):
        view = self.engine.get_view()
        if any(c["id"] == identity for c in view["choices"]):
            return view
        for page in PAGES:
            view = self.engine.get_view()
            if view["page"] != "main" and any(c["id"] == "menu.main" for c in view["choices"]):
                self.engine.choose("menu.main", view["revision"], view["session"])
                view = self.engine.get_view()
            if page != "main":
                if not any(c["id"] == "menu." + page for c in view["choices"]):
                    continue
                self.engine.choose("menu." + page, view["revision"], view["session"])
                view = self.engine.get_view()
            if any(c["id"] == identity for c in view["choices"]):
                return view
        return None

    def choice(self, identity):
        view = self.find(identity)
        return None if view is None else next(c for c in view["choices"] if c["id"] == identity)

    def go(self, identity):
        view = self.find(identity)
        assert view is not None, (identity, [c["id"] for c in self.engine.get_view()["choices"]])
        choice = next(c for c in view["choices"] if c["id"] == identity)
        assert choice["available"], (identity, choice.get("reason"), view.get("explanations", {}).get(identity))
        return self.engine.choose(identity, view["revision"], view["session"])

    def decline_offers(self):
        while self.engine.snapshot()["offer"]:
            self.go("offer.decline")

    def clock(self):
        return self.engine.snapshot()["world"]["now"] % 1440


class V8225Intimacy(unittest.TestCase):
    def route(self, seed, setup=(), tier="few", **kw):
        route = Route(seed, tier=tier, **({"day_offset": 3, "hour": 13} | kw))
        self.addCleanup(route.close)
        route.begin()
        for key in setup:
            route.action(key)
        return route

    def hold(self, route, maho, player=10):
        intimate = route.engine._state["intimacy"]
        intimate["maho"].update(arousal=maho, band=route.engine.pack.intimacy.band(maho))
        intimate["player"]["arousal"] = player
        route.engine._install_choices()

    def lead_offer(self, route, kind, steps=12):
        """深い口づけを続けて、真帆の申し出（kind）を待つ（ほかの申し出は断る）。"""
        for _ in range(steps):
            offer = route.engine.snapshot()["offer"]
            if offer and offer["kind"] == kind:
                return True
            if offer:
                route.choose("offer.decline")
            self.hold(route, 55)
            view = route.engine.get_view()
            if view["page"] != "main": route.choose("menu.main")
            route.choose("menu.h_touch")
            route.choose("touch.h_kiss_deep")
        offer = route.engine.snapshot()["offer"]
        return bool(offer and offer["kind"] == kind)

    # ---- 指摘 R1：申し出を受けた回の「真帆に動いてもらう」初回 ----
    def test_r1_led_first_move_keeps_her_offer(self):
        seen = 0
        for seed in range(2501, 2531):
            route = self.route(seed, ("h_strip_lower", "h_shift_under", "h_strip_self"), tier="few")
            if not self.lead_offer(route, "h_lead_straddle"):
                continue
            route.choose("offer.accept")
            self.assertEqual(route.engine.snapshot()["intimacy"]["position"], "maho_above")
            self.hold(route, 60)
            route.action("h_insert")
            route.action("h_maho_move")
            ids = [i for i, m in zip(text_ids(route.engine), meanings(route.engine)) if m == "h_maho_move.first"]
            self.assertEqual(len(ids), 1, route.status())
            self.assertTrue(ids[0].startswith("o34.h_maho_move.first.led."), ids)
            seen += 1
            if seen >= 3:
                break
        self.assertGreaterEqual(seen, 3)

    def test_r1_requested_first_move_is_still_a_request(self):
        route = self.route(2551, ("h_strip_lower", "h_shift_under", "h_strip_self", "h_pos_maho_above"), tier="few")
        while route.engine.snapshot()["offer"]:
            route.choose("offer.decline")
        self.hold(route, 60)
        route.action("h_insert")
        route.action("h_maho_move")
        ids = [i for i, m in zip(text_ids(route.engine), meanings(route.engine)) if m == "h_maho_move.first"]
        self.assertEqual(len(ids), 1)
        self.assertFalse(ids[0].startswith("o34."), ids)

    def test_a1_on_top_is_one_experience(self):
        """真帆が申し出て上に乗った回に、あとで「上になってもらう」は初めての本文にしない（逆も同じ）。"""
        pack = Route(2560).engine.pack
        self.assertEqual(pack.intimacy.same_first["h_pos_maho_above"], ("h_lead_straddle",))
        for seed in range(2561, 2591):
            route = self.route(seed, ("h_strip_lower", "h_shift_under", "h_strip_self"), tier="few")
            if not self.lead_offer(route, "h_lead_straddle"):
                continue
            route.choose("offer.accept")
            route.action("h_pos_lying_face")
            route.action("h_pos_maho_above")
            self.assertIn("h_pos_maho_above.start", meanings(route.engine))
            return
        self.fail("申し出が出なかった")

    # ---- 精査 A-2：ねだったあとの「一気に奥まで入れる」 ----
    def test_a2_no_deflect_right_after_begging(self):
        route = self.route(2601, ("h_strip_lower", "h_shift_under", "h_strip_self", "h_pos_player_above"), tier="familiar")
        route.engine._state["intimacy_history"]["lewdness"] = 70  # 準備：大胆（ねだる高まりが「高い」より下がる）
        for _ in range(8):
            while route.engine.snapshot()["offer"]:
                route.choose("offer.decline")
            self.hold(route, 72)
            route.action("h_tease")
            if "h.sign.beg" in meanings(route.engine):
                break
        self.assertTrue(route.engine.snapshot()["intimacy"]["begged"])
        self.hold(route, 74)  # 準備：ねだる高さ（大胆 70）以上、「高い」（80）の手前
        route.action("h_insert_deep")
        self.assertNotIn("h.deflect.deep", meanings(route.engine))
        self.assertTrue(route.engine.snapshot()["intimacy"]["inserted"])

    # ---- 精査 A-3・A-4：胸・足の申し出 ----
    def test_a3_a4_breasts_offer_not_while_kissing_nor_after_done(self):
        kinds = []
        for seed in range(2621, 2641):
            route = self.route(seed, ("h_lift_upper", "h_strip_self", "h_pos_lying_face"), tier="familiar")
            before = route.engine._state["intimacy"]["started_at"] - 1440
            route.engine._state["experience"]["h_maho_breasts"].update(count=5, first_at=before, last_at=before)  # 準備：前の回までに何度も頼んだ
            route.engine._state["experience"]["h_maho_breasts"]["by_origin"]["player"] = 5
            route.engine._state["intimacy_history"]["lewdness"] = 70
            for _ in range(6):
                while route.engine.snapshot()["offer"]:
                    kinds.append(("kiss", route.engine.snapshot()["offer"]["kind"]))
                    route.choose("offer.decline")
                self.hold(route, 50, 40)
                route.action("h_kiss_deep")
            offer = route.engine.snapshot()["offer"]
            if offer:
                kinds.append(("kiss", offer["kind"]))
                route.choose("offer.decline")
            route.action("h_maho_breasts")
            route.choose("menu.main")
            route.choose("menu.h_service")
            route.choose("end.h_maho_breasts")
            for _ in range(4):
                self.hold(route, 50, 40)
                route.action("h_chest_skin")
                offer = route.engine.snapshot()["offer"]
                if offer:
                    kinds.append(("after", offer["kind"]))
                    route.choose("offer.decline")
        self.assertNotIn(("kiss", "h_help_breasts"), kinds)
        self.assertNotIn(("after", "h_help_breasts"), kinds)

    # ---- 精査 A-6：引き留めの前に向き合う形へ ----
    def test_a6_hold_back_from_face_sit_faces_again(self):
        route = self.route(2661, ("h_strip_lower", "h_shift_under", "h_strip_self", "h_pos_face_sit", "h_face_lick"), tier="few")
        while route.engine.snapshot()["offer"]:
            route.choose("offer.decline")
        route.choose("menu.main")
        route.choose("h.end")
        state = route.engine.snapshot()
        self.assertEqual(state["offer"]["kind"], "hold_back")
        self.assertEqual(state["intimacy"]["position"], "lying_face")
        self.assertFalse(any(c["action_id"] == "h_face_lick" for c in state["contacts"]))

    def test_end_while_service_can_be_chosen(self):
        """確かめ役 A N-2（v8.2.25 の直しの退行）：手・口でしてもらっている最中も「終える」が選べ、引き留めのあと続けられる。"""
        for key, tier in (("h_maho_hand", "few"), ("h_maho_mouth", "few")):
            route = self.route(2681, ("h_strip_self", "h_pos_lying_face", key, key), tier=tier)
            while route.engine.snapshot()["offer"]:
                route.choose("offer.decline")
            route.choose("menu.main")
            route.choose("h.end")
            state = route.engine.snapshot()
            self.assertEqual(state["offer"]["kind"], "hold_back", key)
            self.assertEqual(state["intimacy"]["paces"], {}, key)
            route.choose("offer.accept")
            route.action("h_kiss_deep")

    def test_hold_back_while_kissing_is_quiet(self):
        """確かめ役 A N-3：深い口づけを続けたまま終えると、口づけしたままの引き留め（台詞なし）。余力があるときも。"""
        for seed in range(2691, 2697):
            route = self.route(seed, (), tier="few")
            if route.engine.get_view()["page"] != "main": route.choose("menu.main")
            route.choose("h.end")
            texts = [b for b in route.engine.get_view()["blocks"] if b["meaning"] == "h.hold_back"]
            self.assertEqual(len(texts), 1)
            self.assertNotIn("「", texts[0]["body"], texts[0]["variant"])

    # ---- 精査 A-7・D-1・D-4・D-8：物足りない合図 ----
    def test_d1_sixty_nine_signs_are_spaced(self):
        route = self.route(2701, ("h_strip_lower", "h_shift_under", "h_strip_self", "h_pos_sixty_nine", "h_sixty_nine"), tier="few")
        route.choose("pace.h_sixty_nine.slow")
        self.hold(route, 82)
        steps = []
        for step in range(12):
            route.engine._state["intimacy"]["player"]["arousal"] = 10
            route.engine._install_choices()
            while route.engine.snapshot()["offer"]:
                route.choose("offer.decline")
            route.action("h_sixty_nine")
            if any(m.startswith("h.sign.wants_more") for m in meanings(route.engine)):
                steps.append(step)
            if route.engine.snapshot()["intimacy"]["maho"]["climaxes"]:
                break
        gaps = [b - a for a, b in zip(steps, steps[1:])]
        self.assertTrue(all(gap >= 4 for gap in gaps), steps)

    def test_d4_climax_resets_the_count(self):
        route = self.route(2721, ("h_lift_upper", "h_strip_lower", "h_shift_under", "h_strip_self", "h_pos_player_above"), tier="familiar")
        self.hold(route, 60, 20)
        route.action("h_insert")
        route.action("h_move_slow")
        self.hold(route, 80, 20)
        seen = []
        for step in range(30):
            route.engine._state["intimacy"]["player"]["arousal"] = 20
            route.engine._install_choices()
            while route.engine.snapshot()["offer"]:
                route.choose("offer.decline")
            route.action("h_move_slow")
            for m in meanings(route.engine):
                if m.startswith(("h.sign.wants_more", "h.climax.")):
                    seen.append(m)
        # 達したあとの最初の合図は、ふつうの合図（焦れた合図ではない）
        for index, m in enumerate(seen):
            if m.startswith("h.climax.") and index + 1 < len(seen):
                self.assertEqual(seen[index + 1].split(".")[2], "wants_more", seen)

    def test_d8_no_sign_on_pace_step(self):
        route = self.route(2741, ("h_lift_upper", "h_pos_lying_face", "h_chest_mouth"), tier="familiar")
        self.hold(route, 86)
        for step in range(8):
            route.engine._state["intimacy"]["player"]["arousal"] = 10
            route.engine._install_choices()
            while route.engine.snapshot()["offer"]:
                route.choose("offer.decline")
            if step == 6:
                route.choose("pace.h_chest_mouth.fast")
                self.assertFalse(any(m.startswith("h.sign.wants_more") for m in meanings(route.engine)), meanings(route.engine))
            else:
                route.action("h_chest_mouth")

    # ---- 精査 A U-1・B-06：夜の誘い ----
    def test_no_night_invite_inside_her_room(self):
        route = Route(2801, tier="few", hour=19, minute=30)
        self.addCleanup(route.close)
        state = route.engine._state
        state["desire"] = 70
        rules = route.engine.pack.intimacy
        self.assertTrue(rules.invite_ready(state, route.engine.pack.progression, route.engine.pack.life))
        for actor in ("player", "maho"):
            state["actors"][actor]["location"] = "maho_room"
        self.assertFalse(rules.invite_ready(state, route.engine.pack.progression, route.engine.pack.life))

    # ---- 精査 B-05：「仕事の前だから」と止めたあと、部屋で始めようとすると断る ----
    def test_b05_entry_after_work_deflect_is_declined(self):
        route = Route(2811, tier="few", day_offset=0, hour=7, minute=36)
        self.addCleanup(route.close)
        route.choose("menu.touch")
        route.choose("near")
        for _ in range(3):
            route.choose("menu.touch") if route.engine.get_view()["page"] != "touch" else None
            route.choose("touch.kiss")
            while route.engine.snapshot()["offer"]:
                route.choose("offer.decline")
        route.choose("menu.main")
        route.choose("menu.touch")
        route.choose("touch.deep_kiss")
        self.assertIn("gate.react.deflect_time", meanings(route.engine))
        route.choose("menu.main")
        route.choose("private.begin")
        route.choose("menu.touch")
        route.choose("touch.h_kiss_deep")
        self.assertIn("h.decline.work", meanings(route.engine))
        self.assertIsNone(route.engine.snapshot()["intimacy"])

    # ---- 本文の条件 ----
    def test_texts_conditions(self):
        pack = Route(2900).engine.pack
        texts = {t["id"]: t for t in pack.texts}
        fixes = json.loads((ROOT / "tools/stage_b/text_fixes_v8225.json").read_text(encoding="utf-8"))
        dropped = {(identity, json.dumps(cond, ensure_ascii=False)) for patch in fixes.get("drop", []) for identity in patch["ids"] for cond in patch["remove"]}  # v8.2.35：あとの版で外した条件
        for patch in fixes["when"]:
            for identity in patch["ids"]:
                for cond in patch["add"]:
                    if (identity, json.dumps(cond, ensure_ascii=False)) in dropped:
                        continue
                    self.assertIn(json.dumps(cond, ensure_ascii=False), json.dumps(texts[identity]["when"], ensure_ascii=False), identity)
        for edit in fixes["body"]:
            self.assertEqual(texts[edit["id"]]["body"], edit["body"])
        firsts = [t for t in pack.texts if t["meaning"] == "h_maho_move.first" and not t["fallback"]]
        led = [t for t in firsts if '"intimacy.maho_led", "op": "eq", "value": true' in json.dumps(t["when"])]
        self.assertGreaterEqual(len(led), 13)
        for text in led:
            self.assertNotRegex(text["body"], r"頼|お願い|促|えっ|動いてほしい", text["id"])
        ordinary = '"intimacy.maho_led_fresh", "op": "eq", "value": false'  # v8.2.35：ふつうの本文は「申し出のあとの最初の1回でないとき」
        for text in firsts:
            if text not in led:
                self.assertIn(ordinary, json.dumps(text["when"]), text["id"])
        # 2回目以降（h_maho_move.start）も、申し出を受けた回は o34 の本文だけ（確かめ役 A）
        starts = [t for t in pack.texts if t["meaning"] == "h_maho_move.start" and not t["fallback"]]
        led_starts = [t for t in starts if t["id"].startswith("o34.")]
        self.assertGreaterEqual(len(led_starts), 11)
        for text in starts:
            self.assertIn('"intimacy.maho_led", "op": "eq", "value": true' if text in led_starts else ordinary, json.dumps(text["when"]), text["id"])
            if text in led_starts:
                self.assertNotRegex(text["body"], r"頼|お願い|促|えっ|動いてほしい", text["id"])
        for meaning in ("hands.maho", "kiss.maho", "hug.maho"):
            rows = [t for t in pack.texts if t["meaning"] == meaning and not t["fallback"]]
            self.assertGreaterEqual(len(rows), 4, meaning)
            for text in rows:
                self.assertNotRegex(text["body"], r"差し出され|抱きしめられ|抱き寄せられ", text["id"])
        for text in pack.texts:
            if text["id"].startswith(("q.h_maho_hand_fast.", "q.h_maho_move_fast.")):
                self.assertNotRegex(text["body"], r"頼ま|頼んだ|お願いされ|って言われ", text["id"])


class V8225Life(unittest.TestCase):
    def life(self, seed, cheats=False):
        life = Life(seed, cheats)
        self.addCleanup(life.close)
        return life

    def to_evening(self, life):
        for _ in range(3):
            life.decline_offers()
            life.go("work.go")
        life.decline_offers()

    # ---- 指摘 R2・精査 B-01：手動の食事と自動の夕食 ----
    def test_r2_manual_meal_counts_as_dinner(self):
        life = self.life(29)
        self.to_evening(life)
        life.go("move.joint.kitchen")
        while life.clock() < 17 * 60 + 35:
            life.decline_offers()
            life.go("listen")
        life.decline_offers()
        life.go("activity.meal")
        life.go("scene.finish")
        self.assertNotIn("life.dinner", meanings(life.engine))
        finished = life.clock()
        self.assertGreaterEqual(finished, 17 * 60 + 30)
        life.decline_offers()
        life.go("wait.30")
        self.assertNotIn("life.dinner", meanings(life.engine))
        self.assertLess(life.clock() - finished, 40, "待った30分だけ進む（夕食の40分が足されない）")
        life.decline_offers()
        choice = life.choice("activity.meal")
        self.assertIsNotNone(choice)
        self.assertFalse(choice["available"])

    def test_b01_resumed_meal_after_dinner_is_blocked(self):
        life = self.life(29)
        self.to_evening(life)
        life.go("move.joint.kitchen")
        while life.clock() < 18 * 60:
            life.decline_offers()
            life.go("listen")
        life.decline_offers()
        life.go("activity.meal")
        life.go("scene.pause")
        for _ in range(12):
            life.decline_offers()
            life.go("listen")
            if "life.dinner" in meanings(life.engine):
                break
        self.assertIn("life.dinner", meanings(life.engine))
        life.decline_offers()
        if life.engine.snapshot()["actors"]["player"]["location"] != "kitchen":
            life.go("move.joint.kitchen")
        parked = life.engine.snapshot()["suspended"][0]["id"]
        choice = life.choice("resume." + parked)
        self.assertFalse(choice["available"])

    # ---- 精査 B-02：約束の直後に果たそうと誘わない ----
    def test_b02_promise_not_offered_the_same_day(self):
        life = self.life(29)
        self.to_evening(life)
        life.go("begin.promise_tea")
        life.go("scene.yes")
        for _ in range(4):
            life.go("listen")
            offer = life.engine.snapshot()["offer"]
            self.assertFalse(offer and offer["kind"] == "promise", offer)
            life.decline_offers()

    # ---- 確かめ役 B N1：終えたばかりの活動に誘わない（care の誘いも） ----
    def test_no_care_offer_right_after_quiet(self):
        life = self.life(31, cheats=True)
        self.to_evening(life)
        life.go("activity.quiet")
        life.go("scene.finish")
        life.decline_offers()
        life.engine._state["mood"]["shy"] = 2  # 準備：愛情の触れ合いを重ねたときと同じ気分（care の誘いの条件）
        life.engine._install_choices()
        for _ in range(4):
            life.go("listen")
            offer = life.engine.snapshot()["offer"]
            self.assertFalse(offer and offer["kind"] == "care", offer)
            life.decline_offers()

    # ---- 精査 B-11：二人で待っても真帆は動かない ----
    def test_b11_waiting_together_keeps_her_here(self):
        life = self.life(29)
        self.to_evening(life)
        life.go("move.joint.coast")
        life.decline_offers()
        life.go("wait.30")
        state = life.engine.snapshot()
        self.assertEqual(state["actors"]["maho"]["location"], state["actors"]["player"]["location"])

    # ---- 精査 B-12：お茶の思い出はその日のうちに話さない ----
    def test_b12_tea_memory_waits_a_day(self):
        life = self.life(29)
        life.go("activity.tea")
        life.go("scene.finish")
        life.decline_offers()
        choice = life.choice("begin.remember_tea")
        self.assertIsNotNone(choice)
        self.assertFalse(choice["available"])

    # ---- 精査 B-09：真帆から誘った触れ合い ----
    def test_b09_maho_origin_touch_texts(self):
        """真帆の「手をつなぐの、どうかな」を受けると、真帆のほうから手を取る本文（hands.maho）。"""
        for seed in range(40, 70):
            life = self.life(seed, cheats=True)
            self.to_evening(life)
            life.go("near")
            for _ in range(8):
                offer = life.engine.snapshot()["offer"]
                if offer and offer["kind"] == "closeness":
                    life.go("offer.accept")
                    self.assertIn("hands.maho", meanings(life.engine))
                    self.assertFalse(any(m in ("hands.first", "hands.start") for m in meanings(life.engine)))
                    return
                life.decline_offers()
                if life.engine.snapshot()["distance"] != "near":
                    life.go("near")
                life.go("listen")
        self.fail("手をつなぐ誘いが出なかった")

if __name__ == "__main__":
    unittest.main()
