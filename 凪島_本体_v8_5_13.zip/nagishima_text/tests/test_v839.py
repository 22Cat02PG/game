"""v8.3.9（ユーザー 2026-10-06）：010 だけ。「直しが不適切ならブラッシュアップして。文の削除などをしてもかまわない」。
v8.3.8（全文の読み直し）の書き換え 421本・条件 124本を読み直し、言い回し・新しく出た食い違い・満たせない条件・服の前提などを整えた。
2 回目（ユーザー「不自然なものは消していい。無理に使いまわすと不自然なままになる」）：無理な言い換えをやめて、句・文・本文ごと消した（fixes.remove）。"""
import json
import re
import unittest
from pathlib import Path

from nagishima.content import Pack

ROOT = Path(__file__).resolve().parents[1]
P009 = Pack(ROOT / "content/releases/interaction_009")
P010 = Pack(ROOT / "content/releases/interaction_010")
LAYER = json.loads((ROOT / "tools/stage_b/release_010.json").read_text(encoding="utf-8"))
NOTE = "v8.3.9"
CONTACT = re.compile(r"contact\.(h_[a-z_]+)\.active")
FINGER_IDS = [
    "x5.h.climax.maho.first.not_inserted.n.v1", "x5.h.climax.maho.few.not_inserted.s.v2", "x5.h.climax.maho.familiar.not_inserted.s.v5",
    "x5.h.climax.maho.few.not_inserted.n.v2", "x5.h.climax.maho.familiar.not_inserted.n.v2",
]


def holds(cond, state):
    """本文の条件（all / any / field）を、決めた状態で確かめる（この試験で使う演算だけ）。"""
    if "all" in cond:
        return all(holds(c, state) for c in cond["all"])
    if "any" in cond:
        return any(holds(c, state) for c in cond["any"])
    value = state.get(cond["field"], False if cond["field"].startswith("contact.") else None)  # v8.4.1：決めていない触れ合いは、続いていない
    if cond["op"] == "eq":
        return value == cond["value"]
    if cond["op"] == "ne":
        return value != cond["value"]
    if cond["op"] == "in":
        return value in cond["value"]
    raise AssertionError(cond)


class V839(unittest.TestCase):
    def test_layer_entries(self):
        body = [f for f in LAYER["fixes"]["body"] if NOTE in f["_note"]]
        self.assertGreaterEqual(len(body), 60)
        removed = {i for p in LAYER["fixes"]["remove"] for i in p["ids"]}
        for fix in body:
            if fix["id"] not in removed:
                self.assertEqual(P010.by_text[fix["id"]]["body"], fix["body"], fix["id"])
            self.assertLessEqual(set(re.findall(r"\{[a-z_]+\}", fix["body"])), set(re.findall(r"\{[a-z_]+\}", fix["orig"])), fix["id"])

    def test_no_condition_that_can_never_hold(self):
        """010 で足した条件が、その本文の行為の最中に決して満たせない（同じ手・同じ部位を使う行為どうし）ことがない。
        例：胸に口づけている最中の「胸に手で触れている」、秘所に触れている最中の「太ももを撫でている」。"""
        actions = P010.intimacy.actions
        raw = {a["id"]: a for a in json.loads((ROOT / "content/releases/interaction_010/actions.json").read_text(encoding="utf-8"))}
        for patch in LAYER["fixes"]["when"]:
            needed = {name for c in patch["add"] if c.get("value") is not False for name in CONTACT.findall(json.dumps(c))}  # v8.4.1：「続いていないとき」の条件は満たせる
            if not needed:
                continue
            for identity in patch["ids"]:
                if identity not in P010.by_text:
                    continue  # v8.4.7 で消した本文（中に出す本文で、どの結果にも合わないもの）
                meaning = P010.by_text[identity]["meaning"]
                base = re.match(r"^(h_[a-z_]+?)(?:_slow|_fast)?(?:\.|$)", meaning)
                if not base or base.group(1) not in actions:
                    continue
                own = base.group(1)
                clash = {n for n in needed if n in raw[own].get("replaces", []) or own in raw[n].get("replaces", [])}
                self.assertNotEqual(clash, needed, (identity, meaning, sorted(needed)))

    def test_unsatisfiable_removed(self):
        for identity in ("x5.h_chest_mouth.start.few.n.v3", "x5.h_chest_mouth.start.few.s.v3", "q.h_chest_mouth.familiar.all.h2.v17"):
            when, body = str(P010.by_text[identity]["when"]), P010.by_text[identity]["body"]
            self.assertNotIn("contact.h_chest_skin.active", when, identity)
            self.assertNotRegex(body, r"手で|片手で|つまむ", identity)
        self.assertNotIn("contact.h_thigh.active", str(P010.by_text["q.h_touch_direct_slow.familiar.all.h1.v10"]["when"]))
        self.assertNotIn("空いた手", P010.by_text["q.h_touch_direct_slow.familiar.all.h1.v10"]["body"])

    def test_direct_touch_climax(self):
        """入れていない絶頂で直に触れている書き方の本文は、下着の上から触れているときには出ない。それでも下着の上からの絶頂に出る本文は残る。"""
        for identity in FINGER_IDS:
            state = {"contact.h_touch_under.active": True, "intimacy.inserted": False, "actor.maho.clothing.lower": "underwear",
                     "intimacy.tier": identity.split(".")[4]}
            self.assertFalse(holds(P010.by_text[identity]["when"], state), identity)
            state.update({"contact.h_touch_under.active": False, "contact.h_touch_direct.active": True})
            for facing in ("face", "back"):
                state["intimacy.facing"] = facing
                if holds(P010.by_text[identity]["when"], state):
                    break
            else:
                self.fail(identity)
        for tier in ("few", "familiar"):
            for facing, position in (("face", "lying_face"), ("back", "standing_back"), ("back", "side_lying")):
                state = {"contact.h_touch_under.active": True, "intimacy.inserted": False, "actor.maho.clothing.lower": "underwear",
                         "intimacy.tier": tier, "intimacy.facing": facing, "intimacy.position": position, "intimacy.maho.climax_source": "finger"}
                left = [t["id"] for t in P010.texts if t["meaning"] == "h.climax.maho" and holds(t["when"], state)]
                self.assertGreaterEqual(len(left), 3, (tier, facing, position, left))

    def test_short_lines_follow_parent(self):
        """親の本文に胸の条件が付いた短い一行（胸に触れている前提の台詞）。"""
        for identity in ("sh.x3.h_move_normal.continue.familiar.standing_back.s.v4", "sh.x2.h_move_slow.continue.familiar.side_lying.s.v5"):
            self.assertNotIn("contact.h_chest_skin.active", str(P009.by_text[identity]["when"]), identity)
            self.assertIn("contact.h_chest_skin.active", str(P010.by_text[identity]["when"]), identity)
        identity = "sh2.x2.h_move_normal.continue.familiar.side_lying.s.v3"  # 親は真帆が自分の胸を抱える書き方に直してある
        self.assertNotIn("contact.h_chest_skin.active", str(P010.by_text[identity]["when"]))
        self.assertIn("真帆が自分の腕で", P010.by_text[identity]["body"])

    def test_clothing_premise(self):
        """入れている最中の本文で、服をめくった・ずれた前提の書き方は、めくり上げた状態（raised）の条件があるときだけ（脱いだ状態でも出るため）。"""
        moves = ("h_insert", "h_move_", "h_finish_", "h_overflow")
        for text in P010.texts:
            if text["meaning"].startswith(moves) and re.search(r"めくった|めくれた|ずれた上の服|ずれた服|はだけた布|胸元に残った布", text["body"]):
                self.assertIn('"value": "raised"', json.dumps(text["when"]), text["id"])

    def test_samples(self):
        legs = ("x3.h_move_normal.settled.familiar.legs_shoulder.n.v4", "x3.h_move_slow.settled.familiar.legs_shoulder.n.v2",
                "x3.h_move_slow.start.familiar.legs_shoulder.n.v2", "sh2.x3.h_move_slow.continue.familiar.legs_shoulder.n.v2")
        for identity in legs:  # 脚を肩に掛けた体位では胸どうしは触れない
            self.assertNotIn("こちらの胸に", P010.by_text[identity]["body"], identity)
        samples = {
            "x2.h_finish_outside.start.few.maho_above.n.v4": "乳輪の高さまで腰を引き",
            "x2.h_overflow.inside.few.maho_above.n.v4": "出すと決めたわけでもなく",
            "x2.h_overflow.inside.few.maho_above.s.v5": "止めようとして",
            "x9.h_overflow.sixty_nine.few_familiar.s.v5": "こらえようと",
            "k1.h.player.recovered.familiar.n.v3": "熱が静かに戻ってきた",
            "q.h_maho_hand.few.all.h2.v18": "緩んだ掌",
        }
        for identity, phrase in samples.items():
            self.assertNotIn(phrase, P010.by_text[identity]["body"], identity)

    def test_removed_texts(self):
        """v8.3.9b：言い換えでは台詞と地の文がかみ合わない短い本文は、010 から消した（009 にはある）。同じ組の本文は残っている。"""
        removed = [i for p in LAYER["fixes"]["remove"] if p["_note"].startswith("v8.3.9") for i in p["ids"]]  # v8.4.7 で消した本文は test_v847
        self.assertEqual(len(removed), 14)  # v8.3.9b の 12本と v8.3.9c の 2本
        for identity in removed:
            self.assertIn(identity, P009.by_text, identity)
            self.assertNotIn(identity, P010.by_text, identity)
            group = identity.rsplit(".", 1)[0] + "."
            self.assertGreaterEqual(sum(1 for t in P010.texts if t["id"].startswith(group)), 3, identity)

    def test_cut_samples(self):
        """v8.3.9b：言い換えをやめて消した部分。"""
        cuts = {
            "p1.h_overflow.inside.few.player_above.n.v2": "残ってしまう",
            "p3.h_move_fast.continue.familiar.reverse_ride.n.v1": "シーツをたぐり寄せる",
            "x3.h_move_normal.settled.familiar.legs_shoulder.n.v4": "{nipple}",
            "b2.h.ended.read_air.few_familiar.workday_eve.s.v2": "離した指",
        }
        for identity, phrase in cuts.items():
            self.assertNotIn(phrase, P010.by_text[identity]["body"], identity)

    def test_clitoris_contact_has_mechanism(self):
        """v8.3.9c（ユーザー「抜き差しだけでこすれるものなん？」）：入れている最中に陰核が擦れる・当たる文には、何で擦れるか（根元・恥骨・下腹・シーツ・太もも・真帆の指・真帆が押しつける など）を書く。
        後ろからの体位で「空気に触れる」や、こちらに押しつけられる、は書かない。"""
        mech = re.compile(r"根元|恥骨|下腹|腹|こちら|密着|シーツ|布|太もも|腿|脚|指|結合|際|骨盤|押しつ|押し付|擦りつ|擦り付|押し当|擦り寄|亀頭|竿|先端|下を|下が|自分")
        allowed = {  # 体勢から仕組みが分かるもの（真帆が押し潰すように腰を落とす・沈めきる・入れる瞬間・抜ける瞬間）
            "x2.h_move_fast.start.few.maho_above.s.v3", "x2.h_insert.start.few.maho_above.n.v5", "x2.h_finish_inside.start.few.maho_above.n.v5",
            "x3.h_finish_outside.start.familiar.legs_shoulder.s.v4", "x6.h_overflow.insert.familiar.face.n.v3"}
        back = ("from_behind", "standing_back", "side_lying", "prone_back", "reverse_ride")
        missing = []
        for text in P010.texts:
            when = json.dumps(text["when"], ensure_ascii=False)
            inserted = ('"intimacy.inserted", "op": "eq", "value": true' in when or re.match(r"h_(move|maho_move|thrust|insert|finish|overflow|limit|withdraw|pos_)", text["meaning"])
                        or ("inserted" in text["id"] and "not_inserted" not in text["id"]))
            if "{clitoris}" not in text["body"] or not inserted:
                continue
            for sentence in re.split(r"(?<=[。」])", text["body"]):
                if "{clitoris}" not in sentence:
                    continue
                self.assertNotIn("空気に", sentence, text["id"])
                if any(f'"{b}"' in when for b in back) or "inserted_back" in text["id"]:
                    self.assertNotRegex(sentence, r"\{clitoris\}がこちらに押しつけ", text["id"])
                if re.search(r"擦|こす|当た|潰|押さ", sentence) and not mech.search(sentence):
                    missing.append(text["id"])
        self.assertEqual(sorted(set(missing) - allowed), [])
        self.assertIn("根元に擦れるたび", P010.by_text["sh2.x4.h_move_slow.continue.first.player_above.n.v5"]["body"])  # ユーザーの指摘の一行


if __name__ == "__main__":
    unittest.main()
