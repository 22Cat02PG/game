"""v8.4.7（ユーザー 2026-10-06 20:47「始めて」）：010 だけ。
中に出す手で、真帆がどうなったか（climax：いっしょに達した／near：あと一歩／high：かなり高まった／rest：それ以下）を本文の条件 intimacy.finish_outcome にする。
- 中に出す本文は、読む係が読み分けた結果に合うときだけ出る（「すごく幸せかも」と落ち着いた直後に、いっしょに達する本文が続かない など）
- 達しなかった手では高まりの合図を出さず、果てる本文の中で真帆の高まりを書く（near は「あと少しだったのに」と取り残される本文を先に出す）"""
import unittest
from copy import deepcopy
from pathlib import Path

from nagishima.conditions import evaluate
from nagishima.content import Pack
from tools.run_stage_b_routes import Route

ROOT = Path(__file__).resolve().parents[1]
P009 = Pack(ROOT / "content/releases/interaction_009")
P010 = Pack(ROOT / "content/releases/interaction_010")
FINISH = ["h_finish_inside.start", "h_finish_inside.first", "h_overflow.inside", "h_overflow.insert", "h_overflow.insert_deep"]
POSITIONS = ["player_above", "lying_face", "maho_above", "sitting_face", "leg_up", "legs_shoulder", "from_behind", "prone_back", "side_lying", "standing_back", "reverse_ride"]


def act(route, key):
    while route.engine.snapshot()["offer"]:
        route.choose("offer.decline")
    route.action(key)


def without_outcome(when):
    """結果の条件を外した when（v8.4.7 の前にも本文があった組かを見る）。"""
    if isinstance(when, dict):
        if when.get("field") == "intimacy.finish_outcome":
            return {"all": []}
        return {key: ([without_outcome(v) for v in value] if key in ("all", "any") else without_outcome(value) if key == "not" else value) for key, value in when.items()}
    return when


def outcome_values(text):
    """本文の when にある結果の条件の値（なければ 4つとも）。"""
    for cond in text["when"].get("all", []):
        if cond.get("field") == "intimacy.finish_outcome":
            return set(cond["value"])
    return {"climax", "near", "high", "rest"}


class V847(unittest.TestCase):
    def finish(self, before, tier="few"):
        """入れたまま、真帆の高まりを before にして中に出す。出た本文の (意味, id) と、そのあとの状態。"""
        route = Route(8471, tier=tier, release="interaction_010", hour=21, day_offset=2)
        self.addCleanup(route.close)
        route.begin()
        for key in ("h_kiss_deep", "h_strip_upper", "h_strip_lower", "h_strip_under", "h_strip_self", "h_pos_player_above"):
            act(route, key)
        route.engine._state["intimacy"]["maho"]["arousal"] = 75  # 入れるのを断られないように
        act(route, "h_insert")
        state = route.engine._state
        self.assertTrue(state["intimacy"]["inserted"])
        state["intimacy"]["maho"]["arousal"] = before
        state["intimacy"]["maho"]["band"] = P010.intimacy.band(before)
        state["intimacy"]["player"]["arousal"] = P010.intimacy.raw["player"]["arousal_max"]
        route.engine._install_choices()
        act(route, "h_finish_inside")
        blocks = [(b["meaning"], b["variant"]) for b in route.engine.get_view()["blocks"]]
        return blocks, route.engine.snapshot()["intimacy"]

    def test_009_unchanged(self):
        self.assertIsNone(P009.intimacy.finish_outcome)
        self.assertNotIn("intimacy.finish_outcome", P009.registry.fields)
        self.assertFalse(any(t["id"].startswith("v847.") for t in P009.by_text.values()))
        self.assertIsNotNone(P010.intimacy.finish_outcome)
        self.assertIn("intimacy.finish_outcome", P010.registry.fields)

    def test_outcomes(self):
        for before, outcome, band in ((30, "rest", "mid"), (60, "high", "high"), (70, "near", "near"), (80, "climax", "mid")):
            blocks, intimate = self.finish(before)
            meanings = [m for m, _ in blocks]
            self.assertFalse(any(m.startswith("h.sign.") for m in meanings), (before, blocks))  # 中に出した手では合図を出さない
            self.assertNotIn("finish_outcome", intimate)  # その手の本文を選ぶときだけ持つ
            self.assertEqual(intimate["maho"]["band"], band)
            text = P010.by_text[next(v for m, v in blocks if m.startswith("h_finish_inside."))]
            self.assertIn(outcome, outcome_values(text), (before, text["id"]))
            self.assertEqual("h.climax.together" in meanings, outcome == "climax", (before, blocks))
            if outcome == "near":
                self.assertIn(text["id"], P010.intimacy.finish_outcome["prefer"]["near"])  # 取り残される本文を先に出す

    def test_conditions_from_reading(self):
        # 真帆が達したと書いた本文は消した。段（high・near）の古い条件は結果の条件に置きかえた
        self.assertNotIn("x2.h_finish_inside.start.familiar.from_behind.s.v5", P010.by_text)
        self.assertNotIn("p3.h_overflow.inside.familiar.legs_shoulder.s.v2", P010.by_text)
        for meaning in FINISH:
            for text in P010.by_meaning[meaning]:
                self.assertNotIn({"field": "intimacy.maho.band", "op": "in", "value": ["high", "near"]}, text["when"].get("all", []), text["id"])
        for ids in P010.intimacy.finish_outcome["prefer"].values():
            self.assertTrue(set(ids) <= set(P010.by_text))

    def test_every_outcome_has_texts(self):
        for tier in ("first", "few", "familiar"):
            route = Route(8472, tier=tier, release="interaction_010", hour=21, day_offset=2)
            self.addCleanup(route.close)
            route.begin()
            for key in ("h_kiss_deep", "h_strip_upper", "h_strip_lower", "h_strip_under", "h_strip_self"):
                act(route, key)
            base = route.engine.snapshot()
            for position in POSITIONS:
                for outcome in ("climax", "near", "high", "rest"):
                    state = deepcopy(base)
                    state["intimacy"].update(position=position, inserted=True, finish_outcome=outcome)
                    values = P010.registry.values(state)
                    for meaning in ("h_finish_inside.start", "h_overflow.inside"):
                        authored = [t for t in P010.by_meaning[meaning] if not t["fallback"]]
                        if not any(evaluate(without_outcome(t["when"]), values) is True for t in authored if not t["id"].startswith("v847.")):
                            continue  # 前からこの組の本文がない（この慣れでは選べない体位など）
                        self.assertTrue(any(evaluate(t["when"], values) is True for t in authored), (tier, position, outcome, meaning))


if __name__ == "__main__":
    unittest.main()
