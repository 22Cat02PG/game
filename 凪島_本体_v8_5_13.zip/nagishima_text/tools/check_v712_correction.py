"""Verify the v7.1.2 identifier correction against the two source ZIPs."""
import hashlib
import argparse
import json
import re
import sys
from pathlib import Path
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from nagishima.codec import identifier
from nagishima.errors import GameError

DOWNLOADS = Path.home() / "Downloads"
PARSER = argparse.ArgumentParser()
PARSER.add_argument("--base-zip", type=Path, default=DOWNLOADS / "凪島_本体修正版_v7_1_0.zip")
PARSER.add_argument("--previous-zip", type=Path, default=DOWNLOADS / "凪島_本体修正版_v7_1_1.zip")
ARGS = PARSER.parse_args()
CURRENT = ROOT / "content/releases/interaction_008/texts.json"
ARC = "nagishima_text/"


def sha(data):
    return hashlib.sha256(data).hexdigest()


with ZipFile(ARGS.base_zip) as baseline, ZipFile(ARGS.previous_zip) as previous:
    restored = {}
    for name in ("nagishima/codec.py", "nagishima/state.schema.json"):
        expected = baseline.read(ARC + name)
        actual = (ROOT / name).read_bytes()
        assert actual == expected, name
        restored[name] = sha(actual)

    before = json.loads(previous.read(ARC + "content/releases/interaction_008/texts.json"))
    after = json.loads(CURRENT.read_text(encoding="utf-8"))
    assert len(before) == len(after) == 1043
    assert all(re.fullmatch(r"[a-z][a-z0-9_.-]*", item["id"]) for item in after)
    normalize = lambda rows: sorted(({key: value for key, value in row.items() if key != "id"} for row in rows),
                                    key=lambda row: json.dumps(row, ensure_ascii=False, sort_keys=True))
    assert normalize(before) == normalize(after)
    changed_ids = sum(left["id"] != right["id"] for left, right in zip(before, after))
    assert changed_ids == 155, changed_ids

    old_releases = {}
    for name in baseline.namelist():
        if name.startswith(ARC + "content/releases/interaction_00") and not name.startswith(ARC + "content/releases/interaction_008/") and not name.endswith("/"):
            relative = name[len(ARC):]
            assert (ROOT / relative).read_bytes() == baseline.read(name), relative
            old_releases[relative] = sha(baseline.read(name))

    invalid = ("interaction_ABC", "touch.Hands", "arm.start.a2.J2.1")
    for value in invalid:
        try:
            identifier(value)
        except GameError as error:
            assert error.code == "invalid_id", (value, error.code)
        else:
            raise AssertionError(value)

result = {"restored": restored, "text_count": len(after), "changed_ids": changed_ids,
          "non_id_fields_identical": True, "old_release_files_identical": len(old_releases),
          "invalid_ids_rejected": list(invalid)}
output = ROOT / "verification/v712_correction.json"
output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps(result, ensure_ascii=False))
