"""直し（edits_*.json）の機械点検。使い方：python3 lint_edits.py edits.json [--face]
点検：台詞の数が元と同じ／記号が台詞にない／部位の語と記号が地の文で2つまで（元が3つ以上なら元以下）／地の文の文の数3〜6／10字未満の文が1つまで／
字数が元の8割〜job の上限＋20／「真帆」2回まで／「彼女」なし／閉じかぎの直後に「。」なし／地の文で使わない語なし／熱の語1回まで／--face のとき振り返りなしの顔の語が残っていないか。"""
import json, re, sys
sys.path.insert(0, "/home/claude/work/b2import")
from face_scan import FACE, OK, MINE, split
texts = {t["id"]: t for t in json.load(open("/home/claude/work/b2import/b2_texts.json", encoding="utf-8"))}
PARTS = re.compile(r"\{(penis|vagina|semen|breasts|nipple|clitoris|love_juice)\}|亀頭|先端|カリ|裏筋|竿|根元|陰唇|入り口|内壁|乳輪")
BANNED = re.compile(r"拒む|拒ん|避ける|避け|抵抗|満たされ|欲しい|熱が戻|跡|彼女|慣れ|数回|余力|高まり|初めて")
HEAT = re.compile(r"熱")
def narration(body):
    return re.sub(r"「[^」]*」", "", body)
def dialogues(body):
    return re.findall(r"「[^」]*」", body)
def lint(tid, body, face=False):
    orig = texts[tid]["body"]
    issues = []
    if len(dialogues(body)) != len(dialogues(orig)):
        issues.append(f"台詞の数 {len(dialogues(orig))}→{len(dialogues(body))}")
    if any("{" in d for d in dialogues(body)):
        issues.append("記号が台詞に")
    n_new, n_old = len(PARTS.findall(narration(body))), len(PARTS.findall(narration(orig)))
    if n_new > max(2, n_old):
        issues.append(f"部位の語 {n_old}→{n_new}")
    sents = [s for s in re.split(r"(?<=[。！？])", narration(body)) if s.strip()]
    if not 3 <= len(sents) <= 6:
        issues.append(f"文の数 {len(sents)}")
    if sum(1 for s in sents if len(s) < 10) > 1:
        issues.append("10字未満の文が2つ以上")
    if len(body) < min(len(orig), 100) * 0.8 or len(body) > max(len(orig), 160) + 20:
        issues.append(f"字数 {len(orig)}→{len(body)}")
    if body.count("真帆") > 2:
        issues.append("真帆が3回以上")
    if "」。" in body:
        issues.append("」。")
    new_banned = set(BANNED.findall(narration(body))) - set(BANNED.findall(narration(orig)))
    if new_banned:
        issues.append("使わない語 " + ",".join(new_banned))
    if len(HEAT.findall(narration(body))) > max(1, len(HEAT.findall(narration(orig)))):
        issues.append("熱が2回以上")
    if face and not OK.search(body):
        left = [s for s in split(body) if FACE.search(MINE.sub("", s))]
        if left:
            issues.append("顔の語が残る：" + " / ".join(left))
    return issues
if __name__ == "__main__":
    edits = json.load(open(sys.argv[1], encoding="utf-8"))
    face = "--face" in sys.argv
    bad = 0
    for tid, e in edits.items():
        if tid not in texts:
            print(tid, "id がない"); bad += 1; continue
        if e.get("body") is None:
            continue
        issues = lint(tid, e["body"], face)
        if issues:
            bad += 1
            print(tid, "｜", "；".join(issues))
    print("edits", len(edits), "issues", bad)
