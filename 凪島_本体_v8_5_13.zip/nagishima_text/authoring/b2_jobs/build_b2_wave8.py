"""v8.2.8（ユーザー了承 2026-09-28 09:46〜09:49「費用は気にしなくていい」）の grok への依頼（Opus）。

- 第8陣（p8.、標準）：
  - 入り口をこすって焦らす（h_tease.first／start／continue／settled）× 数回・慣れ × 向き。
  - 焦らされた真帆がねだる（h.sign.beg）× 数回・慣れ × 向き。
  - 限界のまま体位を変える（h_limit_move.start）× 体位 × 慣れ。v8.2.8 で、入れていない限界でも体位を変えられるようにした。
- 濃い版（x7.）：焦らす（start／continue／settled）とねだる × 数回・慣れ × 向き。

どの場面にも Opus の本文（opus_texts_009.json の o16・o17）がすでにある。
出力：grok_b2_wave_8.json・grok_b2_wave_x7.json、grok依頼_B2_第8陣/、第8陣_一覧.json
"""
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent.parent
PROMPT = (OUT / "grokプロンプト_v3_0.txt").read_text(encoding="utf-8")
RULES = json.loads((ROOT / "tools/stage_b/intimacy_009.json").read_text(encoding="utf-8"))
BED = "二人の個室のどちらか（どちらの部屋か、ベッドの上かどうかは書かない）"
TIER = {"first": "初回（1回目のエッチ）", "few": "数回（2〜5回目）", "familiar": "慣れ（6回目以降）", "few_familiar": "数回か慣れ（2回目以降）"}
TIER_WHEN = {"first": ("eq", "first"), "few": ("eq", "few"), "familiar": ("eq", "familiar"), "few_familiar": ("in", ["few", "familiar"])}
LOWER_OPEN = "真帆の下は、下着をずらしてあるか脱いでいる（下着について書かない）。こちらは下を脱いでいる"
FACING = {"face": ("向かい合っている（寝ているか座っているか、どちらが上かは書かない）", None),
          "back": ("真帆がこちらに背を向けている（寝ているか立っているか、どちらが上かは書かない）", "真帆の顔は見えない（肩越しに振り返るときだけ、横顔を書いてよい）")}
DENSE = "濃い：性器・体液・触れ合う音と感触・体の反応を具体的に、露骨に書く（記号 {penis} {vagina} {love_juice} {clitoris} {nipple} {breasts} を積極的に使う。擬音も使ってよい）"
TEASE_MEANING = "入れずに、こちらの先端で真帆の入り口をこすって焦らす（入れそうで入れない）"
TEASE_MUST = ("入れる（先端がわずかに沈みかけるところまではよい。それ以上は入れない）。真帆が自分から腰を沈めて入れる。達する。こちらが出す。体位を変える。痛がる・嫌がる。"
              "真帆が台詞で「入れて」とはっきりねだる（ねだる一言は別の本文）")
TEASE_MAHO = {"first": "こちらに焦らされるのは初めて。高まってきている", "start": "高まってきている", "continue": "焦らされて、もどかしくなっている",
              "settled": "焦らされ続けて、入れてほしくてたまらない（まだ言葉でねだってはいない）"}
BEG_MEANING = "こちらに焦らされた真帆が、こらえきれずに、入れてほしいとねだる（真帆の反応だけを書く。焦らされた長さは書かない）"
BEG_MUST = "こちらが入れる・真帆が自分から腰を沈めて入れる（この本文ではまだ入れない）。こちらの行動を書く（前の本文で書いた）。達する。体位を変える"
LIMIT_MUST = "体位を変える前の姿勢を書く（押し倒す・起き上がるなど）。真帆の秘所に直接触れる・当てる（真帆の服は脱げていないこともある）。入れる。出す・果てる。こらえると言う・決める（「こらえる」は別の行動）。真帆が止める・嫌がる。真帆の手や口で続ける"

std, dense = [], []


def add(rows, prefix, wave, meaning, tier, s, meaning_text, state, *, other=None, must_not=None, when=None, length="100〜160字", style=None):
    identity = ".".join([prefix, meaning, tier] + ([other] if other else []) + [s])
    op, value = TIER_WHEN[tier]
    conditions = [{"field": "intimacy.tier", "op": op, "value": value}] + list(when or [])
    row = {"id": identity, "meaning": meaning_text, "speech": s == "s", "length": length, "origin": "主人公", "candidates": 5,
           "state": state, "_wave": wave, "_meaning": meaning, "_split": {"tier": tier, "position": None, "other": other},
           "when": {"all": conditions}, "group": "b." + meaning}
    if must_not:
        row["must_not"] = must_not
    if style:
        row["style"] = style
    assert not any(r["id"] == identity for r in std + dense), identity
    rows.append(row)


CLOSE_FACE = "（両脚を肩にかけた体位でも出るので）口づけ・首に腕を回す・耳もとでささやく"


def must_for(base, tier, facing):
    return base + ("。" + CLOSE_FACE if tier == "familiar" and facing == "face" else "")


def facing_when(facing):
    return [{"field": "intimacy.facing", "op": "eq", "value": facing}]


# ---- 焦らす（標準） ----
for phase in ("first", "start", "continue", "settled"):
    tiers = ("few_familiar",) if phase == "first" else ("few", "familiar")
    speeches = ("n",) if phase == "settled" else ("s", "n")
    for tier in tiers:
        for facing, (pose, face) in FACING.items():
            for s in speeches:
                state = {"場所": BED, "慣れ": TIER[tier], "体位": pose, **({"顔": face} if face else {}), "服": LOWER_OPEN,
                         "挿入": "していない（この本文でも入れない）", "真帆": TEASE_MAHO[phase]}
                if phase in ("continue", "settled"):
                    state["続いている動作"] = "前の本文から、こちらが先端で真帆の入り口をこすって焦らしている"
                add(std, "p8", "B2-8", "h_tease." + phase, tier, s, TEASE_MEANING, state, other=facing, must_not=must_for(TEASE_MUST, tier, facing), when=facing_when(facing))
# ---- ねだる（標準） ----
for tier in ("few", "familiar"):
    for facing, (pose, face) in FACING.items():
        state = {"場所": BED, "慣れ": TIER[tier], "体位": pose, **({"顔": face} if face else {}), "服": LOWER_OPEN,
                 "挿入": "していない（こちらが先端で入り口をこすって焦らしていた）", "真帆": "焦らされて、高まりきっている（まだ達していない）"}
        add(std, "p8", "B2-8", "h.sign.beg", tier, "s", BEG_MEANING, state, other=facing, must_not=must_for(BEG_MUST, tier, facing), when=facing_when(facing), length="60〜120字")
# ---- 限界のまま体位を変える（標準） ----
for position, row in RULES["positions"].items():
    label = RULES["actions"]["h_pos_" + position]["label"]
    tiers = ("first", "few_familiar") if row["tier_from"] == "first" else ("few_familiar",) if row["tier_from"] == "few" else ("familiar",)
    face = "真帆の顔は見えない（肩越しに振り返るときだけ、横顔を書いてよい）" if row["facing"] == "back" else None
    for tier in tiers:
        for s in ("s", "n"):
            state = {"場所": "二人の個室のどちらか（どちらの部屋かは書かない）", "慣れ": TIER[tier], "体位": f"この本文で「{label}」にする（体位が変わったあと：{row['presence']}）",
                     **({"顔": face} if face else {}), "服": "こちらは下を脱いでいる（真帆の服は書かない）", "挿入": "していない（この本文でも入れない）",
                     "主人公": "もう少しで出てしまう、限界ぎりぎり（どうしてそうなったかは書かない）。こらえながら体位を変える"}
            add(std, "p8", "B2-8", "h_limit_move.start", tier, s, f"限界ぎりぎりのこちらが、こらえながら体位を「{label}」に変える", state,
                other=position, must_not=LIMIT_MUST, when=[{"field": "intimacy.position", "op": "eq", "value": position}], length="80〜140字")
# ---- 濃い版（x7.）：焦らす・ねだる ----
for phase in ("start", "continue", "settled"):
    speeches = ("n",) if phase == "settled" else ("s", "n")
    for tier in ("few", "familiar"):
        for facing, (pose, face) in FACING.items():
            for s in speeches:
                state = {"場所": BED, "慣れ": TIER[tier], "体位": pose, **({"顔": face} if face else {}), "服": LOWER_OPEN,
                         "挿入": "していない（この本文でも入れない）", "真帆": TEASE_MAHO[phase], "描写": DENSE}
                if phase in ("continue", "settled"):
                    state["続いている動作"] = "前の本文から、こちらが先端で真帆の入り口をこすって焦らしている"
                add(dense, "x7", "B2-x7", "h_tease." + phase, tier, s, TEASE_MEANING, state, other=facing, must_not=must_for(TEASE_MUST, tier, facing),
                    when=facing_when(facing), length="120〜200字", style="explicit")
for tier in ("few", "familiar"):
    for facing, (pose, face) in FACING.items():
        state = {"場所": BED, "慣れ": TIER[tier], "体位": pose, **({"顔": face} if face else {}), "服": LOWER_OPEN,
                 "挿入": "していない（こちらが先端で入り口をこすって焦らしていた）", "真帆": "焦らされて、高まりきっている（まだ達していない）", "描写": DENSE}
        add(dense, "x7", "B2-x7", "h.sign.beg", tier, "s", BEG_MEANING, state, other=facing, must_not=must_for(BEG_MUST, tier, facing), when=facing_when(facing),
            length="80〜150字", style="explicit")

(OUT / "grok_b2_wave_8.json").write_text(json.dumps(std, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
(OUT / "grok_b2_wave_x7.json").write_text(json.dumps(dense, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")

NOTE_TEASE = ("\n\nこの依頼は、新しく足した行動「入り口をこすって焦らす」と、焦らされた真帆がねだる一言の本文です（同じ場面の短い本文はすでにあります）。"
              "こちらは入れずに、先端で真帆の入り口をこすったり、なぞったり、入りそうなところで止めたりして焦らします。先端がわずかに沈みかけるところまではよいですが、入れてはいけません。"
              "真帆は、数回なら戸惑いともどかしさ、慣れなら分かっていて求める・からかう反応を書いてください。"
              "「ねだる」の本文（h.sign.beg）は、こちらの行動の本文のすぐあとに続けて出る短い本文なので、真帆の反応（ねだる台詞と体の動き）だけを書き、こちらの行動は書かないでください。"
              "state に「顔」があるときは、そのとおりにしてください（真帆の表情を正面から見たようには書かない）。")
NOTE_LIMIT = ("\n\nこの依頼は「限界のまま体位を変える」本文です。こちらはもう少しで出てしまう限界ぎりぎりまで高まっていて、こらえながら体位を変えます"
              "（このあと、限界のまま入れて入れた途端に果てることも、こらえることも、出すこともあります。この本文ではどれも書かない）。"
              "state の「体位」に書いた体位に、この本文で変えてください。体位の名前をそのまま書かなくてよいですが、変わったあとの姿勢と合うように書いてください。"
              "張りつめて崩れそうなこちらの様子と、それに気づく真帆の反応（初回は戸惑い、数回は驚き・照れ、慣れはからかう・受け止める）を書いてください。")
DENSE_NOTE = ("\nこの依頼は高まりが強い場面で出る「濃い本文」です。標準より露骨に、性器・体液・触れ合う音と感触・体の反応を具体的に書いてください（state の「描写」のとおり）。"
              "この依頼に限り、プロンプトの「部位の語と記号は地の文で1本に2つまで」は「4つまで（同じ語・記号は2回まで）」に読み替えてください。擬音も使ってよいです。")
TAIL = "\nそれ以外の規則（台詞の数、慣れの段階の語、地の文で器官を名前で呼ばず記号を使う、記号を台詞に書かない、妊娠・避妊に触れない、must_not）は同じです。"

folder = OUT / "grok依頼_B2_第8陣"
folder.mkdir(exist_ok=True)
for old in folder.glob("*.txt"):
    old.unlink()
files = {}


def write(rows, label, note):
    per_file = 13
    count = -(-len(rows) // per_file)
    size = -(-len(rows) // count)
    for index in range(0, len(rows), size):
        chunk = rows[index:index + size]
        number = len(list(folder.glob("*.txt"))) + 1
        lines = [json.dumps({"id": r["id"], "meaning": r["meaning"], "speech": r["speech"], "length": r["length"], "origin": r["origin"], "本数": r["candidates"],
                             "must_not": r["must_not"], "state": r["state"]}, ensure_ascii=False) for r in chunk]
        body = ("指示\n"
                f"次の{len(chunk)}件の job を書いてください（段階Bの2版目・第8陣・{label}）。本数は各 job の「本数」のとおりです（合わせて{sum(r['candidates'] for r in chunk)}本）。"
                "speech が true の job は真帆の台詞がちょうど1つ、false の job は台詞なしです。途中で切れそうなら、job の区切りで止めてください。「続けて」と言われたら、止めた job の次から出してください。"
                + note + TAIL + "\n\n[\n  " + ",\n  ".join(lines) + "\n]\n\n" "プロンプト\n" + PROMPT)
        name = f"B2_第8陣_{number:02d}.txt"
        (folder / name).write_text(body, encoding="utf-8")
        files.setdefault(label, []).append(name)


write([r for r in std if r["_meaning"].startswith(("h_tease", "h.sign.beg"))], "入り口をこすって焦らす・ねだる", NOTE_TEASE)
write([r for r in std if r["_meaning"] == "h_limit_move.start"], "限界のまま体位を変える", NOTE_LIMIT)
write(dense, "濃い本文・入り口をこすって焦らす・ねだる", NOTE_TEASE + DENSE_NOTE)
listing = {label: {"files": names} for label, names in files.items()}
listing["jobs"] = {"標準": len(std), "濃い版": len(dense), "本数": 5 * (len(std) + len(dense))}
(OUT / "第8陣_一覧.json").write_text(json.dumps(listing, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
print(json.dumps(listing, ensure_ascii=False))
