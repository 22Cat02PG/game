"""v8.2.19：試遊（GPT とユーザー、v8.2.18）の小さい直し。009 だけに効く。
公開の選択肢（Engine.choose／get_view）とテキスト版の表示から確かめる（時刻・慣れ・欲求などの準備だけ内部で行う）。
開始日 2038-04-07 は水曜。day_offset=1 は木曜（勤務日）、2 は金曜、3 は土曜（休み）。"""
import contextlib
import io
import tempfile
import unittest
from unittest import mock

from nagishima.__main__ import CHEAT_ALL_NOTE, main, show
from nagishima.engine import Engine
from nagishima.progression import day_time
from nagishima.session import Session
from tools.run_stage_b_routes import Route


def meanings(engine):
    return [b["meaning"] for b in engine.get_view()["blocks"]]


def choices(engine):
    return {c["id"]: c for c in engine.get_view()["choices"]}


def screen(engine):
    """テキスト版の画面（show）の出力。"""
    buffer = io.StringIO()
    with contextlib.redirect_stdout(buffer):
        show(Session(engine, 200, test_cheats=True))
    return buffer.getvalue()


def evening_008(test, seed):
    """008 の新規ゲームを、夜（21:00）にする。準備だけ内部で行う（test_v805_fixes の Play.at と同じ）。"""
    temp = tempfile.TemporaryDirectory(prefix="nagishima-v8219-")
    test.addCleanup(temp.cleanup)
    engine = Engine(temp.name, seed=seed, release="interaction_008", autosave=False, test_cheats=True)
    world = engine._state["world"]
    new = world["now"] // 1440 * 1440 + 21 * 60
    world.update(now=new, processed_until=new)
    world["awake_deadline"] = ((new - 300) // 1440 + 1) * 1440 + 300
    engine._install_choices()
    return engine


def choice_line(output, identity):
    return next(line for line in output.splitlines() if "[" + identity + "]" in line)


class V8219(unittest.TestCase):
    def route(self, *args, **kwargs):
        route = Route(*args, **kwargs)
        self.addCleanup(route.close)
        return route

    def page(self, route, name):
        while route.engine.snapshot()["offer"]:
            route.choose("offer.decline")  # 途中の真帆の誘いは断る
        if route.engine.get_view()["page"] != "main":
            route.choose("menu.main")
        if name != "main":
            route.choose("menu." + name)

    def meal(self, route):
        self.page(route, "activities")
        return choices(route.engine)["activity.meal"], route.engine.get_view()["explanations"].get("activity.meal")

    def minute(self, route):
        return day_time(route.engine.snapshot()["world"]["now"])

    # ---- 1. 自動の食事のあとに、もう一度「食事をする」ができる ----
    def test_no_second_dinner_after_auto_dinner(self):
        # 試遊の再現：木曜 18:25 に海岸から台所へ移ると、途中で自動の夕食が入って居間に着く。その5分後に台所へ行く。
        route = self.route(1901, hour=18, minute=15, day_offset=1, dinner=True)
        self.page(route, "move")
        route.choose("move.joint.coast")
        self.assertEqual(self.minute(route), 18 * 60 + 25)
        self.page(route, "move")
        route.choose("move.joint.kitchen")
        self.assertIn("life.dinner", meanings(route.engine))
        self.assertEqual(route.engine.snapshot()["actors"]["player"]["location"], "living_room")
        self.page(route, "move")
        route.choose("move.joint.kitchen")
        choice, reason = self.meal(route)
        self.assertFalse(choice["available"])
        self.assertEqual(choice["reason"], "meal_recent")
        self.assertEqual(reason, "今夜はもう夕食をとった。")  # v8.2.26：夕食を済ませた夜は、もう食事をしない
        # v8.2.25 までは夕食の時間帯（〜20:30）を過ぎれば、また選べた。v8.2.26 からはその夜は選べない
        self.page(route, "main")
        route.choose("wait.30")
        self.page(route, "main")
        route.choose("wait.30")  # 20:20（v8.2.25 精査 B-11：二人で待つあいだ、真帆は台所に残る）
        self.assertEqual(route.engine.snapshot()["actors"]["maho"]["location"], "kitchen")
        self.page(route, "main")
        route.choose("wait.30")
        self.assertGreaterEqual(self.minute(route), 20 * 60 + 30)
        choice, reason = self.meal(route)
        self.assertFalse(choice["available"])
        self.assertEqual(reason, "今夜はもう夕食をとった。")

    def test_no_meal_right_after_breakfast(self):
        route = self.route(1902, hour=22, day_offset=2)  # 金曜の夜（夕食・風呂は済んだ準備）
        self.page(route, "main")
        route.choose("sleep")
        self.assertIn("life.breakfast", meanings(route.engine))
        self.page(route, "move")
        route.choose("move.joint.kitchen")
        choice, reason = self.meal(route)
        self.assertFalse(choice["available"])
        self.assertEqual(reason, "さっき朝食をとったばかり。")
        # v8.2.26（ユーザー了承 2026-09-30）：どの食事のあとも2時間半は食事をしない（朝食は 7:30〜7:50 なので 10:20 から選べる）
        while self.minute(route) < 8 * 60 + 30:
            self.page(route, "main")
            route.choose("wait.30")
        choice, reason = self.meal(route)
        self.assertFalse(choice["available"])
        self.assertEqual(reason, "さっき朝食をとったばかり。")
        while self.minute(route) < 10 * 60 + 20:
            self.page(route, "main")
            route.choose("wait.30")
        state = route.engine.snapshot()
        if state["actors"]["maho"]["location"] != "kitchen":
            self.page(route, "move")
            route.choose("move.solo.living_room")
            self.page(route, "move")
            route.choose("move.joint.kitchen")
        choice, _ = self.meal(route)
        self.assertTrue(choice["available"])

    def test_no_meal_right_after_work_lunch(self):
        route = self.route(1903, hour=8, minute=25, day_offset=1)  # 木曜の朝
        self.page(route, "main")
        route.choose("work.go")
        self.assertEqual(meanings(route.engine)[-1], "work.lunch")
        self.assertEqual(route.engine.snapshot()["actors"]["player"]["location"], "kitchen")
        choice, reason = self.meal(route)
        self.assertFalse(choice["available"])
        self.assertEqual(reason, "さっき昼食をとったばかり。")

    # ---- 2. 風呂のあとの本文と、状態欄の髪型 ----
    def test_auto_bath_lets_hair_down_and_morning_ties_it(self):
        route = self.route(1911, hour=19, minute=50, day_offset=0, bath=True)  # v8.2.30：翌朝が仕事の日（休日の朝は普段着）。風呂は 20:00 から
        self.assertIn("仕事着に結んだ髪", route.engine.get_view()["status"]["presence"])
        self.page(route, "main")
        route.choose("wait.30")
        self.assertIn("life.bath", meanings(route.engine))
        actors = route.engine.snapshot()["actors"]
        self.assertEqual((actors["maho"]["outfit"], actors["maho"]["hair"]), ("room", "down"))
        self.assertEqual(actors["player"]["outfit"], "room")
        self.assertIn("部屋着に下ろした髪", route.engine.get_view()["status"]["presence"])
        self.page(route, "main")
        route.choose("sleep")
        self.assertIn("life.breakfast", meanings(route.engine))
        actors = route.engine.snapshot()["actors"]
        self.assertEqual((actors["maho"]["outfit"], actors["maho"]["hair"]), ("work", "tied"))  # 朝食のあとの身支度
        self.assertEqual(actors["player"]["outfit"], "work")
        self.assertIn("仕事着に結んだ髪", route.engine.get_view()["status"]["presence"])

    def test_bath_together_lets_hair_down(self):
        route = self.route(1912, hour=21, minute=10, day_offset=2, tier="familiar", bath=True)
        self.page(route, "main")
        route.choose("bath.invite")
        self.assertEqual(meanings(route.engine), ["life.bath.together"])
        actors = route.engine.snapshot()["actors"]
        self.assertEqual((actors["maho"]["outfit"], actors["maho"]["hair"]), ("room", "down"))

    def test_008_morning_keeps_chosen_outfit(self):
        # 008 には風呂・朝食の自動がなく、朝の身支度も入らない（振る舞いを変えない）
        engine = evening_008(self, 1913)

        def choose(identity):
            view = engine.get_view()
            if not any(c["id"] == identity for c in view["choices"]) and view["page"] != "main":
                engine.choose("menu.main", view["revision"], view["session"])
                view = engine.get_view()
            self.assertTrue(choices(engine)[identity]["available"], (identity, view["explanations"].get(identity)))
            engine.choose(identity, view["revision"], view["session"])

        choose("menu.move")
        choose("move.solo.player_room")
        choose("menu.appearance")
        choose("prepare.player.casual.short")
        choose("sleep")
        self.assertEqual(engine.snapshot()["actors"]["player"]["outfit"], "casual")
        self.assertEqual(engine.snapshot()["actors"]["maho"]["hair"], "tied")

    # ---- 3. 「真帆が上に乗る」は、真帆が下を着たままでは出ない ----
    def lead(self, seed, strip_lower):
        route = self.route(seed, tier="few", day_offset=2)
        route.begin()
        if strip_lower:
            route.action("h_strip_lower")
        route.action("h_strip_self")
        kinds = []
        for _ in range(16):
            offer = route.engine.snapshot()["offer"]
            if offer:
                kinds.append(offer["kind"])
                if offer["kind"] == "h_lead_straddle":
                    break
                route.choose("offer.decline")
                continue
            self.page(route, "h_touch")
            route.choose("touch.h_kiss_deep")
        return route, kinds

    def test_no_straddle_offer_while_lower_worn(self):
        for seed in range(1921, 1926):
            route, kinds = self.lead(seed, False)
            self.assertNotIn("h_lead_straddle", kinds, seed)
            self.assertEqual(route.engine.snapshot()["actors"]["maho"]["clothing"]["lower"], "worn")
            self.assertEqual(route.engine.snapshot()["intimacy"]["maho"]["band"], "mid")  # 高まりなど、ほかの条件はそろっている

    def test_straddle_after_undressing_can_go_on(self):
        route, kinds = self.lead(1921, True)
        self.assertEqual(kinds[-1], "h_lead_straddle")
        route.choose("offer.accept")
        self.assertEqual(route.engine.snapshot()["intimacy"]["position"], "maho_above")
        self.page(route, "h_clothes")
        self.assertTrue(choices(route.engine)["touch.h_shift_under"]["available"])

    # ---- 4. 慣れで開く行為の、選べない理由 ----
    def test_tier_reasons_say_count_or_familiarity(self):
        route = self.route(1931, tier="first", day_offset=2)
        route.begin()
        self.page(route, "h_position")
        found = choices(route.engine)
        # v8.2.19（ユーザー 07:03）：回数で開く行為は、開くまで一覧に出さない
        self.assertNotIn("touch.h_pos_maho_above", found)
        self.assertNotIn("touch.h_pos_prone_back", found)
        route = self.route(1932, tier="few", day_offset=2)
        route.begin()
        self.page(route, "h_position")
        found = choices(route.engine)
        self.assertIn("touch.h_pos_maho_above", found)  # 数回になれば出る
        self.assertNotIn("touch.h_pos_prone_back", found)  # 慣れから

    # ---- 5. テキスト版の画面で、体位と服の一文が2回出る ----
    def test_screen_shows_pose_and_maho_clothing_once(self):
        route = self.route(1941, hour=21, tier="few")  # v8.2.30：初めての回は締め切りまで60分ないと始めない
        route.begin()
        route.action("h_strip_lower")
        route.action("h_strip_self")
        status = route.engine.get_view()["status"]
        pose = status["intimacy"]["position"]
        self.assertIn("下着だけになっている", status["intimacy"]["clothing"])  # view の中身は変えない
        self.assertIn("自分は下を脱いでいる", status["intimacy"]["clothing"])
        output = screen(route.engine)
        self.assertEqual(output.count(pose), 1)
        self.assertEqual(output.count("下着だけになっている"), 1)
        self.assertIn("\n自分は下を脱いでいる。\n", output)

    # ---- 6. 眠って翌朝になる選択肢の表示 ----
    def test_sleeping_choices_say_next_morning(self):
        route = self.route(1951, hour=21, tier="few")
        self.assertIn("(眠って翌朝)", choice_line(screen(route.engine), "sleep"))  # いつもの「休んで翌朝を迎える」
        route.begin()
        self.page(route, "main")
        route.choose("h.end")
        self.assertEqual(route.engine.snapshot()["offer"]["kind"], "hold_back")
        self.assertGreater(choices(route.engine)["offer.decline"]["duration"], 600)  # view の所要分はそのまま
        line = choice_line(screen(route.engine), "offer.decline")
        self.assertIn("今日はここまで (眠って翌朝)", line)
        self.assertNotIn("分)", line)
        route.choose("offer.decline")
        self.assertIn("life.breakfast", meanings(route.engine))  # 選ぶと、眠って翌朝になる
        # 昼に「今日はここまで」を選んでも眠らないので、「眠って翌朝」とは出さない
        day = self.route(1952, hour=13, day_offset=3)
        day.begin()
        self.page(day, "main")
        day.choose("h.end")
        self.assertEqual(day.engine.snapshot()["offer"]["kind"], "hold_back")
        self.assertNotIn("眠って翌朝", choice_line(screen(day.engine), "offer.decline"))

    def test_008_sleep_keeps_minutes(self):
        engine = evening_008(self, 1953)
        line = choice_line(screen(engine), "sleep")
        self.assertRegex(line, r"\(\d+分\)")

    # ---- 7. テストチート「全開放」の説明 ----
    def play(self, release, lines):
        temp = tempfile.TemporaryDirectory(prefix="nagishima-v8219-")
        self.addCleanup(temp.cleanup)
        buffer = io.StringIO()
        with mock.patch("builtins.input", side_effect=[*lines, EOFError]), contextlib.redirect_stdout(buffer):
            main(["--release", release, "--test-cheats", "--no-autosave", "--data-dir", temp.name + "/data", "--log", temp.name + "/run.jsonl"])
        return buffer.getvalue()

    def test_cheat_all_explains_what_changes(self):
        output = self.play("interaction_009", ["チート 全開放", "help"])
        self.assertIn("全開放チートを適用しました。", output)
        self.assertEqual(output.count(CHEAT_ALL_NOTE), 3)  # 起動時・結果・ヘルプ
        for words in ("エッチの回数（慣れ）", "行為ごとの経験", "チート intimacy_tier:familiar"):
            self.assertIn(words, CHEAT_ALL_NOTE)
        self.assertNotIn(CHEAT_ALL_NOTE, self.play("interaction_008", ["チート 全開放", "help"]))  # 008 の画面は変えない


if __name__ == "__main__":
    unittest.main()
