"""Stage B authored texts: machine checks of spec 9.5 (B-51) and per-job coverage (B-50).

使い方: python tools/check_stage_b_texts.py [--complete-waves 1,2]
--complete-waves に書いた陣は、全 job に採用本文が3本以上あることを求める（足りなければ終了コード1）。
結果は verification/stage_b_text_checks.json に書く。
"""
import argparse
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from tools.build_intimacy_release import b2_conditions, text_fix_conditions
from nagishima.content import Pack

ORGANS = ["ペニス", "膣", "精液", "乳房", "おっぱい", "乳首", "クリトリス", "愛液"]
PREGNANCY = ["妊娠", "避妊", "ゴム", "ピル", "安全日", "危ない日"]
ELASTIC = re.compile(r"(下着|ウエスト|腰)の?ゴム")
TIER_WORDS = {  # 台詞で使えない語。「中」「そこ」は別の語の一部になりやすいので Opus の判定に任せる
    "first": ["奥", "いきそう", "いってる", "おっぱい", "乳首", "精液"],
    "few": ["奥", "いってる", "おっぱい", "乳首", "精液"],
}


# 9.5「同じ job の台詞」：同じ2字以上の語（漢字・カタカナの連なり）が、同じ job の3本以上の台詞に出たら落とす。
# 場面の意味そのものの語（誘う先の部屋、翌日の仕事、今夜・今日）は数えない（v8.0.5、監査 C-05・E-10）。
WORD = re.compile(r"[一-龥々ァ-ヴー]{2,}")
MEANING_WORDS = {"部屋", "明日", "今夜", "今日"}
# 9.5「服」：job の state と食い違う語。検出したものは警告として出し、Opus が確かめる（v8.0.5）。
CLOTHES = {
    "書かない": ["服", "下着", "ブラ", "スカート", "ショーツ", "ズボン", "裸", "脱"],
    "真帆は下着がずらされている。こちらは下を脱いでいる": ["脱がせ", "全裸", "一糸"],
    "真帆は下着がずらされている": ["脱がせ", "全裸", "一糸"],
    "真帆は上の服を着ている": ["めくれ", "素肌の胸", "むき出しの胸", "裸の胸"],
}


def split(body):
    return re.findall(r"「[^」]*」", body), re.sub(r"「[^」]*」", "", body)


def job_tier(job):
    tier = job["state"].get("慣れ", "")
    return "first" if tier.startswith("初回") else "few" if tier.startswith("数回") else None


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--complete-waves", default="")
    args = parser.parse_args()
    complete = {int(x) for x in args.complete_waves.split(",") if x}
    jobs = {}
    for wave in (1, 2, 3):
        for job in json.loads((ROOT / f"authoring/b_jobs/grok_wave_{wave}.json").read_text(encoding="utf-8")):
            jobs[job["id"]] = job
    pack = Pack(ROOT / "content/releases/interaction_009")
    # v8.0.5：生成が grok の本文の when に足した条件（tools/stage_b/opus_texts_009.json の when_patches）を job の when に足して比べる。
    patches = {}
    opus_path = ROOT / "tools/stage_b/opus_texts_009.json"
    if opus_path.exists():
        for patch in json.loads(opus_path.read_text(encoding="utf-8"))["when_patches"]:
            patches.setdefault(patch["meaning"], []).extend(patch["add"])
    authored = [t for t in pack.texts if not t["fallback"] and t["id"].rsplit(".v", 1)[0] in jobs]
    failures, counts, warnings = [], {job_id: 0 for job_id in jobs}, []
    job_dialogues = {}
    for text in authored:
        job = jobs[text["id"].rsplit(".v", 1)[0]]
        counts[job["id"]] += 1
        dialogues, narration = split(text["body"])
        problems = []
        expected_when = {"all": job["when"]["all"] + patches[job["_meaning"]]} if job["_meaning"] in patches else job["when"]
        # B2：生成が本文の語から足す条件（向き・立った体位・下着・めくれ。tools/build_intimacy_release.py の b2_conditions）
        extra = [c for c in b2_conditions({"meaning": job["_meaning"], "when": expected_when, "body": text["body"]}) if c not in expected_when.get("all", [])]  # 生成と同じく二重に足さない（v8.2.7）
        if extra:
            expected_when = {"all": expected_when["all"] + extra}
        fixed = [c for c in text_fix_conditions()[0].get(text["id"], []) if c not in expected_when.get("all", [])]  # v8.2.25：精査の直しで足した条件
        if fixed:
            expected_when = {"all": (expected_when["all"] if set(expected_when) == {"all"} else [expected_when]) + fixed}
        dropped = text_fix_conditions()[2].get(text["id"], [])  # v8.2.25：精査の直しで外した条件
        if dropped:
            expected_when = {"all": [c for c in (expected_when["all"] if set(expected_when) == {"all"} else [expected_when]) if c not in dropped]}
        if text["meaning"] != job["_meaning"] or text["when"] != expected_when or text["group"] != job["group"]:
            problems.append("job と meaning・when・group が違う")
        if len(dialogues) != (1 if job["speech"] else 0):
            problems.append(f"台詞の数 {len(dialogues)}")
        problems += [f"地の文に器官の語：{w}" for w in ORGANS if w in narration]
        body_wo_elastic = ELASTIC.sub("", text["body"])
        problems += [f"妊娠・避妊の語：{w}" for w in PREGNANCY if w in body_wo_elastic]
        if "あなた" in narration:
            problems.append("地の文に「あなた」")
        tier = job_tier(job)
        if tier:
            problems += [f"台詞に慣れの段階で使えない語：{w}" for d in dialogues for w in TIER_WORDS[tier] if w in d]
        if problems:
            failures.append({"id": text["id"], "problems": problems})
        job_dialogues.setdefault(job["id"], []).append({w for d in dialogues for w in WORD.findall(d)} - MEANING_WORDS)
        clothes = [w for w in CLOTHES.get(job["state"].get("服"), []) if w in text["body"]]
        if clothes:
            warnings.append({"id": text["id"], "state": job["state"]["服"], "words": clothes})
    # v8.0.5：Opus が書いた段階Bの本文（opus_texts_009.json）にも同じ項目を当てる（検査役H H-24）。
    opus_ids = set()
    if opus_path.exists():
        opus_ids = {row["id"] for row in json.loads(opus_path.read_text(encoding="utf-8"))["texts"]}
    b2_path = ROOT / "tools/stage_b/b2_opus_texts.json"  # B2：Opus が書いた本文も同じ項目で確かめる
    if b2_path.exists():
        opus_ids |= {row["id"] for row in json.loads(b2_path.read_text(encoding="utf-8"))["texts"]}
    for text in (t for t in pack.texts if t["id"] in opus_ids):
        dialogues, narration = split(text["body"])
        problems = [f"地の文に器官の語：{w}" for w in ORGANS if w in narration]
        problems += [f"妊娠・避妊の語：{w}" for w in PREGNANCY if w in ELASTIC.sub("", text["body"])]
        if "あなた" in narration:
            problems.append("地の文に「あなた」")
        if len(dialogues) > 1:
            problems.append(f"台詞の数 {len(dialogues)}")
        conditions = text["when"]["all"] if "all" in text["when"] else [text["when"]]
        tiers = [c["value"] for c in conditions if c.get("field") == "intimacy.tier" and c["op"] == "eq"]
        for tier in tiers:
            problems += [f"台詞に慣れの段階で使えない語：{w}" for d in dialogues for w in TIER_WORDS.get(tier, []) if w in d]
        if problems:
            failures.append({"id": text["id"], "problems": problems})
    for job_id, sets in job_dialogues.items():
        repeated = sorted(w for w in set().union(*sets) if sum(w in s for s in sets) >= 3)
        if repeated:
            failures.append({"id": job_id, "problems": ["同じ job の台詞に同じ語が3本以上：" + "・".join(repeated)]})
    by_wave = {}
    for job_id, n in counts.items():
        wave = jobs[job_id]["_wave"]
        row = by_wave.setdefault(wave, {"jobs": 0, "texts": 0, "jobs_with_3_or_more": 0, "short": {}})
        row["jobs"] += 1
        row["texts"] += n
        if n >= 3:
            row["jobs_with_3_or_more"] += 1
        else:
            row["short"][job_id] = n
    incomplete = [w for w in sorted(complete) if by_wave[w]["short"]]
    b2 = check_b2(pack)
    failures += b2["failures"]
    result = {"authored_texts": len(authored), "machine_check_failures": failures, "clothes_warnings_for_review": warnings,
              "coverage_by_wave": {str(k): v for k, v in sorted(by_wave.items())},
              "complete_waves_required": sorted(complete), "incomplete_required_waves": incomplete,
              "b2": {k: v for k, v in b2.items() if k != "failures"}}
    (ROOT / "verification/stage_b_text_checks.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print("authored", len(authored), "opus", len(opus_ids), "failures", len(failures), "clothes_warnings", len(warnings),
          {w: f"{v['jobs_with_3_or_more']}/{v['jobs']} jobs, {v['texts']} texts" for w, v in sorted(by_wave.items())})
    print("b2 authored", b2["authored_texts"], "failures", len(b2["failures"]), "jobs", b2["jobs"], "jobs_with_3_or_more", b2["jobs_with_3_or_more"],
          "jobs_without_text", len(b2["jobs_without_text"]), "short", len(b2["short"]), "supplement_waiting", len(b2["supplement_waiting"]))
    return 0 if not failures and not incomplete and not b2["jobs_without_text"] else 1


B2_REQUIRED = {"B2-1", "B2-2", "B2-3", "B2-4", "B2-5", "B2-6", "B2-7", "B2-8", "B2-9", "B2-10", "B2-11", "B2-12", "B2-13"}  # v8.2.15：第10陣（補充で0本の job が埋まった）・第11陣・第12陣もそろった  # 本文がそろっている陣（v8.2.7：第7陣、v8.2.10：第8陣、v8.2.11：第9陣がそろった。第10陣は1 job が0本で待ち）。濃い版（x1〜x6）は「待ち」の扱い
B2_TOKENS = {"penis", "vagina", "semen", "breasts", "nipple", "clitoris", "love_juice"}
B2_TIER_WORDS = {"first": ["奥", "いきそう", "いってる", "おっぱい", "乳首", "精液", "中"],
                 "few": ["奥", "いってる", "おっぱい", "乳首", "精液"]}


def b2_job_tier(job):
    """B2 の job の慣れ：慣れの欄か、関係の欄（まだエッチはしていない＝初回、したことがある＝数回）。"""
    tier = job["state"].get("慣れ", "")
    if tier:
        return "first" if tier.startswith("初回") else "few" if tier.startswith("数回（") else None
    relation = job["state"].get("関係", "")
    return "first" if "まだエッチはしていない" in relation else "few" if "エッチをしたことがある" in relation else None


def check_b2(pack):
    """B2（v8.1.1）：grok の B2 本文（authoring/b2_jobs、tools/stage_b/b2_texts.json）の機械検査と、job ごとの本数。

    段階Bの項目に、B2 の取り込みで使った項目（「彼女」、地の文の「初めて」、「真帆」は2回まで、記号の名前）を足す。
    when は job の when に、生成が足す条件（b2_authored_conditions）を足したものと同じであること。
    """
    from tools.build_intimacy_release import b2_authored_conditions, b2_when_patches
    patches = b2_when_patches()
    fix_when, _, fix_drop = text_fix_conditions()
    jobs = {}
    for path in sorted((ROOT / "authoring/b2_jobs").glob("grok_b2_wave_*.json")):  # 第1〜3陣と補充（第4）
        for job in json.loads(path.read_text(encoding="utf-8")):
            jobs[job["id"]] = job
    positions = json.loads((ROOT / "tools/stage_b/intimacy_009.json").read_text(encoding="utf-8"))["positions"]
    back = {name for name, p in positions.items() if p["facing"] == "back"}
    failures, counts, dialogues_by_job = [], {job_id: 0 for job_id in jobs}, {}
    for text in pack.texts:
        job_id = text["id"].rsplit(".v", 1)[0]
        if text["fallback"] or job_id not in jobs:
            continue
        job = jobs[job_id]
        counts[job_id] += 1
        dialogues, narration = split(text["body"])
        problems = []
        when = job["when"]
        extra = b2_authored_conditions(job["_meaning"], when, text["body"], back, job.get("style"))
        extra += [c for c in patches.get(text["id"], []) if c not in extra]  # 生成と同じく二重に足さない（v8.2.7）
        if extra:
            when = {"all": (when["all"] if set(when) == {"all"} else [when]) + extra}
        fixed = [c for c in fix_when.get(text["id"], []) if c not in when.get("all", [])]  # v8.2.25：精査の直しで足した条件
        if fixed:
            when = {"all": (when["all"] if set(when) == {"all"} else [when]) + fixed}
        if text["id"] in fix_drop:  # v8.2.25：精査の直しで外した条件
            when = {"all": [c for c in (when["all"] if set(when) == {"all"} else [when]) if c not in fix_drop[text["id"]]]}
        if text["meaning"] != job["_meaning"] or text["when"] != when or text["group"] != job["group"]:
            problems.append("job と meaning・when・group が違う")
        if len(dialogues) != (1 if job["speech"] else 0):
            problems.append(f"台詞の数 {len(dialogues)}")
        problems += [f"地の文に器官の語：{w}" for w in ORGANS if w in narration]
        problems += [f"妊娠・避妊の語：{w}" for w in PREGNANCY if w in ELASTIC.sub("", text["body"])]
        for word, where in (("あなた", narration), ("初めて", narration), ("彼女", text["body"])):
            if word in where:
                problems.append(f"「{word}」")
        if text["body"].count("真帆") > 2:
            problems.append("「真帆」が3回以上")
        if job["_meaning"].startswith("h_touch_direct.") and "{vagina}" in text["body"]:
            problems.append("外側に触れる本文で {vagina}（既定の語「膣」）")
        problems += [f"未登録の記号 {t}" for t in TOKEN_NAME.findall(text["body"]) if t not in B2_TOKENS]
        if any(TOKEN_NAME.search(d) for d in dialogues):
            problems.append("台詞の中に記号")
        tier = b2_job_tier(job)
        if tier:
            for d in dialogues:
                plain = d.replace("夢中", "").replace("背中", "").replace("途中", "").replace("中身", "")
                problems += [f"台詞に慣れの段階で使えない語：{w}" for w in B2_TIER_WORDS[tier] if w in (plain if w == "中" else d)]
        if problems:
            failures.append({"id": text["id"], "problems": problems})
        dialogues_by_job.setdefault(job_id, []).append({w for d in dialogues for w in WORD.findall(d)} - MEANING_WORDS)
    for job_id, sets in dialogues_by_job.items():
        repeated = sorted(w for w in set().union(*sets) if sum(w in s for s in sets) >= 3)
        if repeated:
            failures.append({"id": job_id, "problems": ["同じ job の台詞に同じ語が3本以上：" + "・".join(repeated)]})
    return {"authored_texts": sum(counts.values()), "jobs": len(jobs), "jobs_with_3_or_more": sum(1 for j, n in counts.items() if n >= 3 and jobs[j]["_wave"] in B2_REQUIRED),
            "jobs_without_text": sorted(j for j, n in counts.items() if n == 0 and jobs[j]["_wave"] in B2_REQUIRED),
            "supplement_waiting": sorted(j for j, n in counts.items() if n == 0 and jobs[j]["_wave"] not in B2_REQUIRED),
            "short": {j: n for j, n in sorted(counts.items()) if 0 < n < 3 and jobs[j]["_wave"] in B2_REQUIRED}, "failures": failures}


TOKEN_NAME = re.compile(r"\{([a-z_]+)\}")


if __name__ == "__main__":
    raise SystemExit(main())
