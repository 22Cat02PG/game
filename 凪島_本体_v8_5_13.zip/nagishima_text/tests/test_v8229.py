"""v8.2.29（ユーザー 2026-09-30 19:09 の試遊の指摘と問い → Opus の判断 → 19:35「おけ、それでいいよ。がーって進めて」）：
限界の案内と限界の口づけ・愛撫、1回の行為の長さ、締め切りでもうすぐ達しそうなら延ばす（昼は仕事の始まりも締め切り）、胸に触れる左右、設定の整理、昼に終えたあとの時間。
公開の選択肢（Engine.choose／get_view）から確かめる（時刻・慣れ・高まりの準備だけ内部で行う）。"""
import json
import unittest
from copy import deepcopy
from pathlib import Path

from nagishima.progression import day_time
from nagishima.stage_b_state import validate as validate_intimacy_state
from tools.run_stage_b_routes import Route

ROOT = Path(__file__).resolve().parents[1]


def meanings(engine):
    return [b["meaning"] for b in engine.get_view()["blocks"]]


class Helpers:
    def route(self, seed, tier="familiar", **kw):
        route = Route(seed, tier=tier, **({"day_offset": 3, "hour": 13} | kw))
        self.addCleanup(route.close)
        return route

    def page(self, route, name):
        if route.engine.get_view()["page"] != "main":
            route.choose("menu.main")
        if name != "main":
            route.choose("menu." + name)

    def choice(self, route, identity):
        view = route.engine.get_view()
        return next((c for c in view["choices"] if c["id"] == identity), None), view

    def hold(self, route, maho=None, player=None):
        intimate = route.engine._state["intimacy"]
        if maho is not None:
            intimate["maho"].update(arousal=maho, band=route.engine.pack.intimacy.band(maho))
        if player is not None:
            intimate["player"]["arousal"] = player
        route.engine._install_choices()

    def connect(self, route):
        route.begin()
        for key in ("h_lift_upper", "h_strip_lower", "h_shift_under", "h_strip_self", "h_pos_player_above"):
            route.action(key)
        self.hold(route, maho=60, player=50)
        route.action("h_insert")
        return route

    def lunch(self, seed, near):
        route = self.route(seed, day_offset=2, hour=12, minute=20)
        route.begin()
        for key in ("h_strip_lower", "h_shift_under", "h_strip_self", "h_pos_player_above"):
            route.action(key)
        self.hold(route, maho=50, player=30)
        route.action("h_insert")
        while day_time(route.engine.snapshot()["world"]["now"]) < 12 * 60 + 57:
            self.hold(route, maho=60, player=40)
            route.action("h_move_slow")
        self.hold(route, maho=92 if near else 60, player=40)
        route.action("h_move_slow")
        return route


class V8229(Helpers, unittest.TestCase):
    # ---- 1. 限界の案内は、今できる出し方だけ ----
    def test_limit_message_names_only_available_ways(self):
        route = self.route(2901, tier="first")
        route.begin()
        route.action("h_strip_self")
        route.action("h_maho_hand")
        self.hold(route, player=100)
        self.page(route, "h_clothes")
        choice, view = self.choice(route, "touch.h_lift_upper")
        reason = view["explanations"]["touch.h_lift_upper"]
        self.assertIn("このまま真帆の手で出す", reason)
        self.assertNotIn("口", reason.replace("口づけ", ""))
        self.assertIn("口づけや愛撫はできる", reason)

    # ---- 2. 限界でも口づけ・愛撫はできる ----
    def test_caress_at_limit_with_her_hand_spills_over(self):
        route = self.route(2902, tier="first")
        route.begin()
        route.action("h_strip_self")
        route.action("h_maho_hand")
        self.hold(route, player=100)
        self.page(route, "h_touch")
        choice, _ = self.choice(route, "touch.h_kiss_deep")
        self.assertTrue(choice["available"])
        self.assertIn("（もうこらえきれない）", choice["label"])
        route.choose("touch.h_kiss_deep")
        self.assertIn("h_overflow.hand", meanings(route.engine))
        self.assertEqual(route.engine.snapshot()["intimacy"]["player"]["finishes"], 1)

    def test_caress_at_limit_after_mouth_calms_a_little(self):
        route = self.route(2903)
        route.begin()
        route.action("h_strip_self")
        route.action("h_maho_mouth")
        self.hold(route, player=100)
        self.page(route, "h_touch")
        route.choose("touch.h_kiss_deep")
        state = route.engine.snapshot()
        self.assertIn("h_kiss_deep.start", meanings(route.engine))
        self.assertEqual(state["intimacy"]["player"]["arousal"], 95)
        self.assertNotIn("h_maho_mouth", [c["action_id"] for c in state["contacts"]])

    def test_caress_at_limit_while_inside_stops_moving(self):
        route = self.connect(self.route(2904))
        route.action("h_move_normal")
        self.hold(route, player=100)
        self.page(route, "h_touch")
        route.choose("touch.h_chest_skin")
        state = route.engine.snapshot()
        self.assertEqual(state["intimacy"]["player"]["arousal"], 100)
        self.assertEqual(state["intimacy"]["player"]["finishes"], 0)
        self.assertNotIn("h_move_normal", [c["action_id"] for c in state["contacts"]])

    # ---- 3. 入れてから果てるまでが短すぎない ----
    def test_insertion_to_limit_takes_several_moves(self):
        for tier in ("first", "few", "familiar"):
            with self.subTest(tier=tier):
                route = self.connect(self.route(2905, tier=tier))
                moves = 0
                while route.engine.snapshot()["intimacy"]["player"]["arousal"] < 100 and moves < 20:
                    while route.engine.snapshot()["offer"]:
                        route.choose("offer.decline")
                    route.action("h_move_normal")
                    moves += 1
                self.assertGreaterEqual(moves, 8)
                self.assertLessEqual(moves, 10)

    # ---- 4. 締め切り：昼は仕事の始まり。もうすぐ達しそうなら延ばす ----
    def test_work_start_is_a_deadline_with_her_words(self):
        route = self.lunch(2906, near=False)
        self.assertIn("h.deadline.work", meanings(route.engine))
        self.assertEqual(route.engine.snapshot()["intimacy"]["wrap_up"], 1)
        route.action("h_move_slow")  # 残りの1手
        self.page(route, "h_connect")
        choice, view = self.choice(route, "touch.h_move_slow")
        self.assertFalse(choice["available"])
        self.assertEqual(view["explanations"]["touch.h_move_slow"], "もう仕事に戻る時間だ。")
        self.page(route, "main")
        route.choose("h.end")
        self.assertIn("h.ended.work", meanings(route.engine))
        self.assertNotIn("h.after_time", meanings(route.engine))  # 仕事の時刻を過ぎて終えたときは進めない

    def test_near_climax_at_work_start_gets_a_little_longer(self):
        route = self.lunch(2907, near=True)
        found = meanings(route.engine)
        if "h.climax.maho" in found:
            self.skipTest("締め切りの手で達した")
        self.assertIn("h.deadline.work_close", found)
        self.assertEqual(route.engine.snapshot()["intimacy"]["wrap_up"], 3)
        for _ in range(3):
            route.action("h_move_normal")
            if "h.climax.maho" in meanings(route.engine):
                break
        self.assertIn("h.climax.maho", meanings(route.engine))  # 延ばした手のうちに達する
        self.assertEqual(route.engine.snapshot()["intimacy"]["wrap_up"], 0)  # 達したら、残りは終わり

    def test_near_climax_at_night_deadline_gets_a_little_longer(self):
        route = self.route(2908, day_offset=1, hour=21, minute=25)  # 翌日が仕事の夜（22:00 で切り上げ）
        route.begin()
        for key in ("h_strip_lower", "h_shift_under", "h_strip_self", "h_pos_player_above"):
            route.action(key)
        self.hold(route, maho=50, player=30)
        route.action("h_insert")
        found = []
        for _ in range(12):
            self.hold(route, maho=92, player=40)
            route.action("h_move_slow")
            found = meanings(route.engine)
            if route.engine.snapshot()["intimacy"]["wrap_up"] is not None:
                break
        if "h.climax.maho" in found:
            self.skipTest("締め切りの手で達した")
        self.assertIn("h.deadline.close", found)
        self.assertEqual(route.engine.snapshot()["intimacy"]["wrap_up"], 3)

    # ---- 5. 胸に触れる左右 ----
    def test_breast_side_choices(self):
        route = self.route(2909)
        route.begin()
        self.page(route, "h_touch")
        labels = {c["id"]: c["label"] for c in route.engine.get_view()["choices"]}
        self.assertEqual(labels["touch.h_chest_over"], "服の上から両胸に触れる")
        self.assertEqual(labels["side.h_chest_over.right"], "服の上から右の胸に触れる")
        self.assertEqual(labels["side.h_chest_over.left"], "服の上から左の胸に触れる")
        self.assertEqual(labels["touch.h_chest_mouth"], "右の胸に口づける")
        self.assertEqual(labels["side.h_chest_mouth.left"], "左の胸に口づける")
        self.assertNotIn("side.h_chest_mouth.right", labels)
        route.choose("side.h_chest_over.right")
        self.assertEqual(route.engine.snapshot()["intimacy"]["sides"], {"h_chest_over": "right"})
        validate_intimacy_state(route.engine.snapshot(), route.engine.pack)
        self.page(route, "main")
        labels = {c["id"]: c["label"] for c in route.engine.get_view()["choices"]}
        self.assertEqual(labels["side.h_chest_over.right"], "服の上から右の胸に触れ続ける")
        self.assertEqual(labels["side.h_chest_over.left"], "左の胸に手を移す")
        self.assertEqual(labels["touch.h_chest_over"], "左の胸にも触れる")
        route.choose("side.h_chest_over.left")
        self.assertIn("h_chest_over.side_left", meanings(route.engine))
        self.page(route, "main")
        route.choose("touch.h_chest_over")
        self.assertIn("h_chest_over.side_both", meanings(route.engine))
        self.assertEqual(route.engine.snapshot()["intimacy"]["sides"], {})
        self.page(route, "main")
        labels = {c["id"]: c["label"] for c in route.engine.get_view()["choices"]}
        self.assertEqual(labels["side.h_chest_over.right"], "右の胸だけに触れる")

    def test_mouth_moves_between_sides(self):
        route = self.route(2910)
        route.begin()
        route.action("h_lift_upper")
        route.action("h_chest_mouth")
        self.page(route, "main")
        labels = {c["id"]: c["label"] for c in route.engine.get_view()["choices"]}
        self.assertEqual(labels["touch.h_chest_mouth"], "右の胸に口づけ続ける")
        self.assertEqual(labels["side.h_chest_mouth.left"], "左の胸に口を移す")
        route.choose("side.h_chest_mouth.left")
        self.assertIn("h_chest_mouth.side_left", meanings(route.engine))
        self.page(route, "main")
        route.choose("touch.h_chest_mouth")
        self.assertIn("h_chest_mouth.side_right", meanings(route.engine))

    def test_both_breast_texts_only_when_touching_both(self):
        route = self.route(2911)
        pack = route.engine.pack
        both = {"field": "intimacy.side.h_chest_skin", "op": "eq", "value": "both"}
        rows = [t for t in pack.texts if both in t["when"].get("all", [])]
        self.assertGreaterEqual(len(rows), 50)
        self.assertTrue(all(t["meaning"].startswith("h_chest_skin") for t in rows))
        # 片方だけのときに、両方の胸の本文を出さない
        route.begin()
        route.action("h_lift_upper")
        for _ in range(8):
            self.page(route, "h_touch")
            route.choose("side.h_chest_skin.right")
            for block in route.engine.get_view()["blocks"]:
                self.assertNotIn(both, pack.by_text[block["variant"]]["when"].get("all", []), block)

    # ---- 6. 設定 ----
    def test_settings_page(self):
        route = self.route(2912)
        route.choose("menu.settings")
        choices = {c["id"]: c["label"] for c in route.engine.get_view()["choices"]}
        self.assertFalse([key for key in choices if key.startswith(("settings.speech.", "settings.continue_text.", "settings.term."))], choices)
        self.assertEqual(choices["settings.preset.mild"], "性器などの呼び方：控えめ（秘部・ペニス・蜜 など）")
        self.assertEqual(choices["settings.preset.explicit"], "性器などの呼び方：あけすけ（おまんこ・ちんぽ・マン汁 など）")
        route.choose("menu.settings_terms")
        choices = {c["id"]: c["label"] for c in route.engine.get_view()["choices"]}
        self.assertIn("settings.term.vagina.4", choices)
        self.assertIn("menu.settings", choices)
        route.choose("settings.term.vagina.4")
        self.assertEqual(route.engine.snapshot()["settings"]["terms"]["vagina"], "おまんこ")

    def test_old_long_setting_still_gives_short_lines(self):
        route = self.route(2913)
        route.engine._state["settings"]["continue_text"] = "long"  # 準備：v8.2.28 までの保存で「毎回長く」にしていた
        route.engine._install_choices()
        self.connect(route)
        found = []
        for _ in range(3):
            self.hold(route, maho=30, player=10)
            route.action("h_move_normal")
            found.append(meanings(route.engine)[0])
        self.assertEqual(found[1:], ["h_move_normal.continue_short"] * 2)

    # ---- 7. 昼に終えたあとの時間 ----
    def test_daytime_end_takes_after_time(self):
        route = self.route(2914, hour=14)
        route.begin()
        route.action("h_chest_over")
        before = route.engine.snapshot()["world"]["now"]
        self.page(route, "main")
        route.choose("h.end")
        while route.engine.snapshot()["offer"]:
            route.choose("offer.decline")
        state = route.engine.snapshot()
        self.assertIn("h.after_time", meanings(route.engine))
        self.assertGreaterEqual(state["world"]["now"] - before, 30)
        self.assertEqual(state["actors"]["player"]["location"], "living_room")
        self.assertEqual(state["actors"]["maho"]["location"], "living_room")

    def test_night_end_sleeps_instead(self):
        route = self.route(2915, hour=23)
        route.begin()
        route.action("h_chest_over")
        self.page(route, "main")
        route.choose("h.end")
        while route.engine.snapshot()["offer"]:
            route.choose("offer.decline")
        self.assertNotIn("h.after_time", meanings(route.engine))

    def test_new_texts(self):
        pack = self.route(2916).engine.pack
        for meaning, count in (("h_chest_over.side_both", 6), ("h_chest_skin.side_right", 6), ("h_chest_mouth.side_left", 6), ("h.deadline.close", 8),
                               ("h.deadline.work", 6), ("h.deadline.work_close", 7), ("h.after_time", 11), ("h.ended.work", 6)):
            authored = [t for t in pack.by_meaning[meaning] if not t["fallback"] and not t["id"].startswith(("o38.", "o39.", "o40.", "o41.", "o42.", "k1."))]  # v8.2.31〜35 の足し（o38〜o42）と v8.2.36 の確かめ役の足し（k1）は数えない
            self.assertEqual(len(authored), count, meaning)
        for meaning in ("h.deadline.work", "h.deadline.work_close", "h.ended.work", "h.after_time"):
            for text in pack.by_meaning[meaning]:
                self.assertNotRegex(text["body"], r"今夜|寝る|明日", text["id"])


class V8229Checker(Helpers, unittest.TestCase):
    """確かめ役（別の Opus）の指摘 F-1〜F-11 の直し。"""

    def test_f1_stop_touching_one_side(self):
        route = self.route(2921)
        route.begin()
        self.page(route, "h_touch")
        route.choose("side.h_chest_over.right")
        self.page(route, "main")
        choice, view = self.choice(route, "end.h_chest_over")
        self.assertTrue(choice["available"], view["explanations"].get("end.h_chest_over"))
        route.choose("end.h_chest_over")
        self.assertEqual(route.engine.snapshot()["intimacy"].get("sides", {}), {})
        validate_intimacy_state(route.engine.snapshot(), route.engine.pack)

    def test_f9_pace_keeps_side(self):
        route = self.route(2922)
        route.begin()
        route.action("h_lift_upper")
        self.page(route, "h_touch")
        route.choose("side.h_chest_mouth.left")
        self.page(route, "main")
        route.choose("pace.h_chest_mouth.slow")
        self.assertEqual(route.engine.snapshot()["intimacy"]["sides"], {"h_chest_mouth": "left"})
        self.assertNotIn("h_chest_mouth.side_right", meanings(route.engine))

    def test_f2_stroke_at_limit_while_she_uses_mouth(self):
        route = self.route(2923)
        route.begin()
        route.action("h_strip_self")
        route.action("h_maho_mouth")
        self.hold(route, player=100)
        self.page(route, "main")
        choice, _ = self.choice(route, "touch.h_stroke_head")
        self.assertIn("（もうこらえきれない）", choice["label"])
        route.choose("touch.h_stroke_head")
        found = meanings(route.engine)
        self.assertTrue(any(m.startswith("h_overflow.mouth") for m in found), found)
        self.assertEqual(route.engine.snapshot()["intimacy"]["player"]["finishes"], 1)

    def test_f8_limit_in_sixty_nine(self):
        route = self.route(2924)
        route.begin()
        for key in ("h_strip_lower", "h_shift_under", "h_strip_self", "h_pos_sixty_nine", "h_sixty_nine"):
            route.action(key)
        self.hold(route, player=100)
        self.page(route, "h_clothes")
        view = route.engine.get_view()
        reason = next(view["explanations"][c["id"]] for c in view["choices"] if not c["available"] and c["id"] in view["explanations"])
        self.assertIn("このまま真帆の口で出す", reason)
        self.assertNotIn("口づけや愛撫はできる", reason)

    def test_f11_reason_during_close_grace(self):
        route = self.lunch(2925, near=True)
        if "h.deadline.work_close" not in meanings(route.engine):
            self.skipTest("締め切りの手で達した")
        self.page(route, "h_position")
        view = route.engine.get_view()
        reasons = {view["explanations"][c["id"]] for c in view["choices"] if not c["available"] and c["id"] in view["explanations"]}
        self.assertIn("最後まで、と真帆は言った。今は体位や服を変えない。", reasons)

    def test_f10_morning_says_go(self):
        route = self.route(2926, day_offset=2, hour=7, minute=40)
        route.begin()
        for _ in range(30):
            if route.engine.snapshot()["intimacy"]["wrap_up"] is not None:
                break
            self.hold(route, maho=30, player=10)
            route.action("h_kiss_deep")
        self.assertIn("h.deadline.work", [b["meaning"] for b in route.engine.get_view()["blocks"]])
        route.action("h_kiss_deep")  # 残りの1手
        self.page(route, "h_touch")
        choice, view = self.choice(route, "touch.h_chest_over")
        self.assertEqual(view["explanations"]["touch.h_chest_over"], "もう仕事に行く時間だ。")

    def test_f4_lunch_session_can_still_finish(self):
        """入れてから動く手は、長くなった分だけ1手の分を短くした（昼休みの締め切りで、ほぼ毎回果てる前に切れていた）。"""
        route = self.route(2927, day_offset=2, hour=12, minute=25)
        route.begin()
        for key in ("h_strip_lower", "h_shift_under", "h_strip_self", "h_pos_player_above"):
            route.action(key)
        while day_time(route.engine.snapshot()["world"]["now"]) < 12 * 60 + 47:
            self.hold(route, maho=40, player=20)
            route.action("h_kiss_deep")
        self.hold(route, maho=60, player=50)  # 準備：入れる前の高まり（前戯のふつうの上限）
        route.action("h_insert")
        for _ in range(12):
            state = route.engine.snapshot()["intimacy"]
            if state["player"]["finishes"] or state["wrap_up"] == 0:
                break
            if state["player"]["arousal"] >= 70 and state["wrap_up"] is not None:
                route.action("h_finish_inside")
                break
            route.action("h_move_normal")
        self.assertEqual(route.engine.snapshot()["intimacy"]["player"]["finishes"], 1)

    def test_f5_after_time_without_undressing(self):
        route = self.route(2928, hour=14)
        route.begin()
        route.action("h_chest_over")
        self.page(route, "main")
        route.choose("h.end")
        while route.engine.snapshot()["offer"]:
            route.choose("offer.decline")
        block = next(b for b in route.engine.get_view()["blocks"] if b["meaning"] == "h.after_time")
        self.assertNotRegex(block["body"], r"服を着|脱いだ服|袖を通|着替え|服を拾|ボタンを留")

    def test_f5_no_after_time_right_before_work(self):
        route = self.route(2929, day_offset=2, hour=12, minute=20)
        route.begin()
        while day_time(route.engine.snapshot()["world"]["now"]) < 12 * 60 + 50:
            self.hold(route, maho=20, player=10)
            route.action("h_kiss_deep")
        self.page(route, "main")
        route.choose("h.end")
        while route.engine.snapshot()["offer"]:
            route.choose("offer.decline")
        self.assertNotIn("h.after_time", meanings(route.engine))


if __name__ == "__main__":
    unittest.main()
