"""段階C（010、v8.5.0）：眠っている真帆に触れる（寝込み）・夜這いの決まり。intimacy.json の sleep_play 節。
仕様は docs/凪島_段階C_仕様_2026-10-08.md の第2・3・5.1節、足し方は第16節。数値は最初の目安で、試遊で直す。

土台（エンジンを触らずに、データだけで足せる）：
- ゲージ：目覚め（wake）・不快（discomfort）・快感（pleasure）、0〜100。行動の数値 × 関係の深さの倍率（うたた寝は目覚めを強める、慣れた触れ方は不快を弱める）。
- 行動（actions）：名前・ゲージの数値・ページ・使える条件（when）・段階（level）・夜の印を立てる／消す（sets／clears）・かかる分（minutes）。
- 夜の印（flags）：寝込みの間だけの印。状態の欄に出す一言を持てる。条件 sleep.flag.<名前>（翌朝は sleep.night.flag.<名前>）。
- 目覚めの反応（reactions）：上から順に条件（when）を見て、最初に当たった反応。各反応の結果（受け入れて起きているエッチへ・怒らせた日数・親密度・欲求・翌朝の一言）。
- 翌朝の一言（morning）：前の夜に目覚めなかったとき、上から順に条件を見て最初に当たったもの。
本文は意味 sp.<行動の id から sp_ を除いた名前>、sp.wake.<反応>、sp.morning.<翌朝> に書く（どれも意味の登録が要る。読み込みで確かめる）。"""
import re

from .errors import ensure
from .intimacy_rules import check, number, time

GAUGES = ("wake", "discomfort", "pleasure")
KINDS = ("doze", "asleep")
OPTIONAL_KINDS = ("cosleep",)  # v8.5.6：添い寝で隣に眠る真帆（co_sleep 節があるときだけ使う）
DEPTHS = (-2, -1, 0, 1, 2, 3)
LEVEL_MAX = 9
FORCED = ("fake_crumble", "fake_stop")  # 寝たふりが崩れたとき（エンジンが選ぶ）：快感が不快以上なら fake_crumble、ほかは fake_stop
ALWAYS = {"all": []}
NAME = re.compile(r"[a-z][a-z0-9_]{0,39}")
EFFECT_KEYS = ("accepted", "cooling", "affinity_loss", "desire")


def _name(value, label):
    ensure(type(value) is str and NAME.fullmatch(value), "intimacy_data", f"寝込みの{label}の名前が不正。")
    return value


class SleepRules:
    def __init__(self, raw, catalog):
        check(raw, ["_note", "kinds", "depth", "multipliers", "start", "minutes", "dawn", "bands", "habit_factor", "fake", "sleeptalk",
                    "cooling", "awake_minutes", "pages", "flags", "actions", "reactions", "morning"])
        self.raw = raw
        check(raw["kinds"], list(KINDS), list(OPTIONAL_KINDS))
        self.kind_factor = {}
        for kind in [k for k in KINDS + OPTIONAL_KINDS if k in raw["kinds"]]:
            check(raw["kinds"][kind], ["wake_factor"])
            factor = raw["kinds"][kind]["wake_factor"]
            ensure(type(factor) in (int, float) and 0.5 <= factor <= 3, "intimacy_data", "寝込みの目覚めの倍率が不正。")
            self.kind_factor[kind] = float(factor)
        depth = raw["depth"]
        check(depth, ["below", "top", "accept_bonus"])
        # below：[[親密度の上限（未満）, 深さ], ...]。どれにも当たらなければ top
        ensure(type(depth["below"]) is list and depth["below"] and all(type(row) is list and len(row) == 2 for row in depth["below"]), "intimacy_data", "寝込みの深さの表が不正。")
        self.depth_below = [(number(limit, 0, 101), number(value + 2, 0, 5) - 2) for limit, value in depth["below"]]
        ensure([limit for limit, _ in self.depth_below] == sorted({limit for limit, _ in self.depth_below}), "intimacy_data", "寝込みの深さの表の順が不正。")
        self.depth_top = number(depth["top"] + 2, 0, 5) - 2
        check(depth["accept_bonus"], ["from", "plus"])
        self.accept_from, self.accept_plus = number(depth["accept_bonus"]["from"], 1, 100), number(depth["accept_bonus"]["plus"], 0, 3)
        self.multipliers = {}
        check(raw["multipliers"], [str(d) for d in DEPTHS])
        for d in DEPTHS:
            row = raw["multipliers"][str(d)]
            check(row, list(GAUGES))
            ensure(all(type(row[g]) in (int, float) and 0 < row[g] <= 5 for g in GAUGES), "intimacy_data", "寝込みの倍率が不正。")
            self.multipliers[d] = {g: float(row[g]) for g in GAUGES}
        check(raw["start"], ["pleasure", "pleasure_from_desire"])
        self.start_pleasure, self.start_desire = number(raw["start"]["pleasure"], 0, 100), number(raw["start"]["pleasure_from_desire"], 0, 100)
        check(raw["minutes"], ["action", "wait"])
        self.action_minutes, self.wait_minutes = number(raw["minutes"]["action"], 1, 30), number(raw["minutes"]["wait"], 1, 60)
        check(raw["dawn"], ["from", "wake_plus"])
        self.dawn_from, self.dawn_plus = time(raw["dawn"]["from"]), number(raw["dawn"]["wake_plus"], 0, 100)  # 夜明け（目覚める時刻 5:00）の前から
        ensure(type(raw["bands"]) is list and len(raw["bands"]) == 2 and 0 < raw["bands"][0] < raw["bands"][1] < 100, "intimacy_data", "寝込みの段の境目が不正。")
        self.bands = tuple(raw["bands"])
        ensure(type(raw["habit_factor"]) in (int, float) and 0 < raw["habit_factor"] <= 1, "intimacy_data", "寝込みの慣れの倍率が不正。")
        self.habit_factor = float(raw["habit_factor"])
        fake = raw["fake"]
        check(fake, ["percent", "lover_depth", "lover_desire", "hold_at", "limit_base", "limit_per_depth", "pleasure_at", "pleasure_plus", "warn_ratio"])
        self.fake = {key: (number(value, -2, 1000) if key != "warn_ratio" else value) for key, value in fake.items()}
        ensure(type(fake["warn_ratio"]) in (int, float) and 0 < fake["warn_ratio"] < 1, "intimacy_data", "寝たふりの割合が不正。")
        check(raw["sleeptalk"], ["at"])
        self.sleeptalk_at = number(raw["sleeptalk"]["at"], 1, 100)
        # cooling：怒らせた・警戒の日数。guard（警戒：部屋に鍵・距離をとる・うたた寝しない）は要る。ほかの名前はデータで足せる
        ensure(type(raw["cooling"]) is dict and "guard" in raw["cooling"], "intimacy_data", "寝込みの警戒の日数がない。")
        self.cooling_days = {_name(key, "警戒"): number(value, 1, 30) for key, value in raw["cooling"].items()}
        self.awake_minutes = number(raw["awake_minutes"], 10, 240)
        # pages：寝込みの選択肢のページ（最初は main）
        pages = raw["pages"]
        ensure(type(pages) is dict and pages and next(iter(pages)) == "main" and all(type(v) is str and 1 <= len(v) <= 20 for v in pages.values()), "intimacy_data", "寝込みのページが不正。")
        self.pages = {_name(key, "ページ"): label for key, label in pages.items()}
        # flags：寝込みの間だけの印。{"名前": {"status": 状態の欄に出す一言（空なら出さない）}}
        ensure(type(raw["flags"]) is dict, "intimacy_data", "寝込みの印が不正。")
        self.flags = {}
        for key, row in raw["flags"].items():
            if key == "_note":
                continue
            check(row, ["status"])
            ensure(type(row["status"]) is str and len(row["status"]) <= 40, "intimacy_data", "寝込みの印の一言が不正。")
            self.flags[_name(key, "印")] = row
        self.actions = {}
        for key, row in raw["actions"].items():
            if key == "_note":
                continue
            ensure(key.startswith("sp_") and NAME.fullmatch(key), "intimacy_data", "寝込みの行動の id は sp_ で始める。")
            check(row, ["label"] + list(GAUGES), ["page", "level", "when", "sets", "clears", "minutes"])
            ensure(type(row["label"]) is str and 1 <= len(row["label"]) <= 40, "intimacy_data", "寝込みの行動の名前が不正。")
            for g in GAUGES:
                ensure(type(row[g]) is int and -100 <= row[g] <= 100, "intimacy_data", "寝込みの数値が範囲外。")
            ensure(row.get("page", "main") in self.pages, "intimacy_data", "寝込みの行動のページが未登録。")
            number(row.get("level", 0), 0, LEVEL_MAX)
            for field in ("sets", "clears"):
                value = row.get(field, [])
                ensure(type(value) is list and len(set(value)) == len(value) and set(value) <= self.flags.keys(), "intimacy_data", "寝込みの行動の印が未登録。")
            ensure(not set(row.get("sets", [])) & set(row.get("clears", [])), "intimacy_data", "同じ印を立てて消している。")
            if "minutes" in row:
                number(row["minutes"], 1, 60)
            self.actions[key] = row
        ensure(self.actions and "sp_wait" in self.actions and "sp_leave" in self.actions, "intimacy_data", "寝込みには、待つ・離れるが要る。")
        for key in ("sp_wait", "sp_leave"):
            ensure(not ({"when", "sets", "clears", "level", "page"} & self.actions[key].keys()), "intimacy_data", "待つ・離れるに条件や印はつけない。")
        self._reactions(raw["reactions"])
        self._morning(raw["morning"])

    def _effects(self, row, label):
        if "accepted" in row:
            ensure(type(row["accepted"]) is bool, "intimacy_data", f"{label}の受け入れの札が不正。")
        ensure(row.get("cooling") is None or row["cooling"] in self.cooling_days, "intimacy_data", f"{label}の警戒が未登録。")
        number(row.get("affinity_loss", 0), 0, 100)
        number(row.get("desire", 0), -100, 100)

    def _order(self, rows, known, label):
        """上から順に条件を見る表。最後は必ず当たる（{"all": []}）。"""
        ensure(type(rows) is list and rows, "intimacy_data", f"{label}の表が不正。")
        for row in rows:
            ensure(type(row) is dict and row.get("id") in known and type(row.get("when")) is dict, "intimacy_data", f"{label}の表の行が不正。")
        ensure(rows[-1]["when"] == ALWAYS, "intimacy_data", f"{label}の表の最後は、いつも当たる行にする。")

    def _reactions(self, raw):
        """目覚めの反応。effects：反応ごとの結果、order：選ぶ順、accept_when：起きているエッチへ移れる条件、fallback：移れないときの反応。"""
        check(raw, ["_note", "effects", "order", "accept_when", "fallback"])
        ensure(type(raw["effects"]) is dict and set(FORCED) <= raw["effects"].keys(), "intimacy_data", "寝たふりが崩れたときの反応がない。")
        self.reactions = {}
        for key, row in raw["effects"].items():
            check(row, ["accept"], ["accepted", "cooling", "affinity_loss", "desire", "morning", "cosleep"])
            # v8.5.6：cosleep＝添い寝の夜に目を覚ましたとき、stay（そのまま並んで眠る）か leave（自分の部屋へ戻る。書かなければこちら）
            ensure(row.get("cosleep", "leave") in ("stay", "leave") and not (row["accept"] and "cosleep" in row), "intimacy_data", "反応の cosleep が不正。")
            ensure(type(row["accept"]) is bool and not (row["accept"] and ({"cooling", "affinity_loss"} & row.keys())), "intimacy_data", "反応の受け入れの札が不正。")
            self._effects(row, "反応")
            self.reactions[_name(key, "反応")] = row
        self.accept = frozenset(key for key, row in self.reactions.items() if row["accept"])
        ensure(self.reactions["fake_crumble"]["accept"] and not self.reactions["fake_stop"]["accept"], "intimacy_data", "寝たふりの反応の札が不正。")
        self._order(raw["order"], self.reactions, "目覚めの反応")
        ensure(type(raw["accept_when"]) is dict, "intimacy_data", "起きているエッチへ移れる条件が不正。")
        self._order(raw["fallback"], self.reactions.keys() - self.accept, "移れないときの反応")
        self.reaction_order, self.accept_when, self.reaction_fallback = raw["order"], raw["accept_when"], raw["fallback"]

    def _morning(self, raw):
        """翌朝の一言。ids：一言の名前（sp.morning.<名前>）、order：目覚めなかった夜の翌朝に選ぶ順（id は重ねてよい：同じ一言で結果を変える。
        id が null の行は何も言わない＝気づかないふり）。"""
        check(raw, ["_note", "ids", "order"])
        ensure(type(raw["ids"]) is list and raw["ids"] and len(set(raw["ids"])) == len(raw["ids"]), "intimacy_data", "翌朝の一言の一覧が不正。")
        self.morning_ids = [_name(key, "翌朝") for key in raw["ids"]]
        for row in self.reactions.values():
            ensure(row.get("morning") is None or row["morning"] in self.morning_ids, "intimacy_data", "反応の翌朝が未登録。")
        self._order(raw["order"], self.morning_ids + [None], "翌朝")
        for row in raw["order"]:
            check(row, ["id", "when"], list(EFFECT_KEYS))
            self._effects(row, "翌朝")
        self.morning_order = raw["order"]

    def check_content(self, fields, meanings, validate_condition):
        """条件の項目と本文の意味を確かめる（条件の項目は寝込みの決まりを読んでから作るので、ここで後から確かめる）。"""
        for row in self.actions.values():
            if "when" in row:
                validate_condition(row["when"], fields)
        for row in self.reaction_order + self.reaction_fallback + self.morning_order:
            validate_condition(row["when"], fields)
        validate_condition(self.accept_when, fields)
        needed = ["sp." + key[3:] for key in self.actions if key != "sp_leave"] + ["sp.wake." + key for key in self.reactions] + ["sp.morning." + key for key in self.morning_ids]
        needed += ["sp.begin." + kind for kind in self.kind_factor] + ["sp.leave." + kind for kind in self.kind_factor]  # v8.5.6：種類ごとの始まりと離れる
        missing = [key for key in needed if key not in meanings]
        ensure(not missing, "meaning", "寝込みの本文の意味が未登録：" + "、".join(missing[:5]))

    def depth(self, affinity, accepted):
        """関係の深さ（-2〜3）。親密度で決め、受け入れた回数が accept_from 以上なら +accept_plus（top まで）。"""
        value = next((d for limit, d in self.depth_below if affinity < limit), self.depth_top)
        if accepted >= self.accept_from:
            value = min(self.depth_top, value + self.accept_plus)
        return value

    def band(self, value):
        return "low" if value < self.bands[0] else "mid" if value < self.bands[1] else "high"

    def fake_limit(self, depth):
        return self.fake["limit_base"] + self.fake["limit_per_depth"] * max(0, depth)
