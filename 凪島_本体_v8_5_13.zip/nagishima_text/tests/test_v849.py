"""v8.4.9（ユーザー 2026-10-07 04:47「進めて」）：010 だけ。
- 同じ回に2回目からの深い口づけは h_kiss_deep.again（初めて口づけるような書き出しを出さない）。
- 入れているとき・果てたあとの初めての抱きしめるに「こわばった体を少しずつ」を出さない。体位と合わない口づけの本文に条件。
- 主語・助詞・前にない「〜たまま」・横向きで後ろからの「吐息が耳にかかる」などの直し。"""
import unittest
from pathlib import Path

from nagishima.content import Pack
from tools.run_stage_b_routes import Route

ROOT = Path(__file__).resolve().parents[1]
P009 = Pack(ROOT / "content/releases/interaction_009")
P010 = Pack(ROOT / "content/releases/interaction_010")


def act(route, key):
    while route.engine.snapshot()["offer"]:
        route.choose("offer.decline")
    route.action(key)


def meanings(route):
    return [b["meaning"] for b in route.engine.get_view()["blocks"]]


class V849(unittest.TestCase):
    def test_009_unchanged(self):
        self.assertEqual(P009.intimacy.again_actions, ())
        self.assertNotIn("h_kiss_deep.again", P009.meanings)
        self.assertEqual(P010.intimacy.again_actions, ("h_kiss_deep",))

    def test_kiss_again(self):
        route = Route(8491, tier="few", release="interaction_010", hour=21, day_offset=2)
        self.addCleanup(route.close)
        route.begin()  # 1回目の深い口づけ
        self.assertIn("h_kiss_deep.start", meanings(route))
        act(route, "h_strip_upper")
        act(route, "h_kiss_deep")  # 服を脱がせて口づけが途切れたあと、もう一度
        self.assertIn("h_kiss_deep.again", meanings(route))
        variant = [b["variant"] for b in route.engine.get_view()["blocks"] if b["meaning"] == "h_kiss_deep.again"][0]
        self.assertTrue(variant.startswith(("v849.h_kiss_deep.again.", "cmp.h_kiss_deep.again.")), variant)  # v8.4.14：組み合わせた本文も

    def test_conditions(self):
        when = P010.by_text["v840.h_hug.first.first.all.n.v1"]["when"]["all"]
        self.assertIn({"field": "intimacy.inserted", "op": "eq", "value": False}, when)
        self.assertIn({"field": "intimacy.player.finishes", "op": "eq", "value": 0}, when)
        self.assertIn({"not": {"field": "intimacy.position", "op": "in", "value": ["player_above", "leg_up", "legs_shoulder"]}},
                      P010.by_text["b1.h_kiss_deep.start.first.n.v4"]["when"]["all"])

    def test_fixed_texts(self):
        self.assertNotIn("吐息が耳にかかる", P010.by_text["p1.h_insert.start.familiar.side_lying.s.v5"]["body"])
        self.assertNotIn("{penis}を{vagina}に押し開き", P010.by_text["x2.h_insert.start.familiar.maho_above.s.v2"]["body"])
        self.assertTrue(P010.by_text["o33.h.sign.wants_more.few.face.s.v2"]["body"].startswith("真帆は"))


if __name__ == "__main__":
    unittest.main()
