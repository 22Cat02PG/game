from pathlib import Path
import argparse
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from nagishima.authoring import publish
from nagishima.codec import read_json
from nagishima.content import Pack

if __name__ == "__main__":
    p = argparse.ArgumentParser(description="検品済みの本文を新しい公開版に追加する。")
    p.add_argument("--source", default="content/releases/base")
    p.add_argument("--output", default="userdata/releases")
    p.add_argument("--release", required=True)
    p.add_argument("bundles", nargs="+")
    a = p.parse_args()
    result = publish(Pack(a.source), a.output, a.release, [read_json(path) for path in a.bundles])
    print(result)
