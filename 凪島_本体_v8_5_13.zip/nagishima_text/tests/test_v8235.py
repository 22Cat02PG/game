"""v8.2.35（ユーザー 2026-10-01 15:50「進めて」）：別の Claude の 報告_v8234エッチ.md の 1〜4 と、返信の注意点（速さ・追加・組み合わせ・申し出）。"""
import json
import re
import unittest
from pathlib import Path

from nagishima.content import Pack
from tools.run_stage_b_routes import Route

ROOT = Path(__file__).resolve().parents[1]
PACK = Pack(ROOT / "content/releases/interaction_009")
HARD = r"先走り|硬[いくさ]|張りつめ|跳ね|脈打|膨ら|反り"


def meanings(engine):
    return [b["meaning"] for b in engine.get_view()["blocks"]]


class V8235(unittest.TestCase):
    def route(self, seed, tier="familiar", **kw):
        route = Route(seed, tier=tier, **({"day_offset": 3, "hour": 13} | kw))
        self.addCleanup(route.close)
        return route

    def finished_by_hand(self, seed, tier="familiar"):
        route = self.route(seed, tier=tier)
        route.begin()
        route.action("h_strip_self")
        route.engine._state["intimacy"]["maho"].update(arousal=50, band="mid")
        route.action("h_maho_hand")
        route.engine._state["intimacy"]["player"]["arousal"] = 100
        route.engine._install_choices()
        route.action("h_finish_hand")
        self.assertEqual(route.engine.snapshot()["intimacy"]["player"]["refractory"], 2)
        route.engine._state["intimacy"]["maho"].update(arousal=50, band="mid")
        route.engine._install_choices()
        return route

    # ---- 1：申し出を受けた回の2回目以降も、ふつうの「真帆に動いてもらう」の本文が出る ----
    def test_maho_move_after_led(self):
        count = 0
        for text in PACK.texts:
            when = json.dumps(text["when"])
            if text["meaning"] in ("h_maho_move.start", "h_maho_move.first") and not text["fallback"] and ".led." not in text["id"]:
                self.assertNotIn('"intimacy.maho_led", "op": "eq", "value": false', when, text["id"])
                self.assertIn('"intimacy.maho_led_fresh", "op": "eq", "value": false', when, text["id"])
                count += 1
        self.assertEqual(count, 82)

    # ---- 2：回復を待つあいだの手は、柔らかいままの専用の本文（速さを変えても） ----
    def test_revive_hand(self):
        route = self.finished_by_hand(8001)
        route.action("h_maho_hand")
        blocks = route.engine.get_view()["blocks"]
        self.assertEqual(blocks[0]["meaning"], "h_maho_hand.revive_start")
        self.assertNotRegex(blocks[0]["body"], HARD)
        route.engine._state["intimacy"]["paces"]["h_maho_hand"] = "fast"
        route.engine._install_choices()
        route.action("h_maho_hand")
        found = meanings(route.engine)
        self.assertIn("h_maho_hand.revive", found)
        self.assertIn("h.player.recovered.hand", found)

    def test_revive_mouth_and_first_tier(self):
        route = self.finished_by_hand(8002)
        route.action("h_maho_mouth")
        self.assertEqual(meanings(route.engine)[:2], ["h_maho_mouth.revive_start", "h.player.recovered.mouth"])
        route = self.finished_by_hand(8003, tier="first")
        route.action("h_maho_hand")
        block = route.engine.get_view()["blocks"][0]
        self.assertEqual(block["meaning"], "h_maho_hand.revive_start")
        self.assertIn(".first.", block["variant"])

    # ---- 2（返信の注意点）：回復を待つあいだは、追加（玉を揉む・先端を舐める）を新しく選べない。申し出も出ない ----
    def test_no_extra_or_offer_while_reviving(self):
        route = self.finished_by_hand(8004)
        route.action("h_maho_hand")
        self.assertGreater(route.engine.snapshot()["intimacy"]["player"]["refractory"], 0)
        self.assertIsNone(route.engine.snapshot()["offer"])
        if route.engine.get_view()["page"] != "main":
            route.choose("menu.main")
        route.choose("menu.h_service")
        view = route.engine.get_view()
        extra = next((c for c in view["choices"] if c["id"] == "touch.h_extra_balls"), None)
        if extra is not None:
            self.assertFalse(extra["available"])

    def test_revive_texts_are_soft(self):
        for meaning in ("h_maho_hand.revive_start", "h_maho_hand.revive", "h_maho_mouth.revive_start", "h_maho_mouth.revive", "h_sixty_nine.revive_start", "h_sixty_nine.revive"):
            texts = PACK.by_meaning[meaning]
            self.assertTrue([t for t in texts if not t["fallback"]], meaning)
            for text in texts:
                self.assertNotRegex(text["body"], HARD, text["id"])

    # ---- 3：回復の一言 ----
    def test_recovered_lines(self):
        self.assertNotIn("腕の中", PACK.by_text["o41.h.player.recovered.n.v1"]["body"])
        self.assertIn('"intimacy.tier", "op": "in"', json.dumps(PACK.by_text["o41.h.player.recovered.hand.s.v1"]["when"]))

    def test_texts(self):
        data = json.loads((ROOT / "tools/stage_b/opus_texts_v8235.json").read_text(encoding="utf-8"))
        self.assertEqual(len(data["texts"]), 38)
        for row in data["texts"]:
            self.assertEqual(PACK.by_text[row["id"]]["body"], row["body"])


if __name__ == "__main__":
    unittest.main()
