"""Conservative UTF-8 JSON bound for the accepted state, not a sample save."""
from copy import deepcopy

from .codec import canonical
from .errors import ensure
from .state import SCHEMA

PUBLICATION_BUDGET = 24 * 1024 * 1024


def value_schema(spec):
    kind = spec["type"]
    schema = {"bool": {"type": "boolean"}, "int": {"type": "integer", "minimum": spec.get("min", -2147483648), "maximum": spec.get("max", 2147483647)}, "string": {"type": "string", "maxLength": spec.get("max_length", 200)}, "enum": {"enum": spec.get("values", [])}}[kind]
    return {"anyOf": [schema, {"type": "null"}]} if spec.get("nullable") else schema


def json_bound(schema, root):
    if "$ref" in schema: return json_bound(root["$defs"][schema["$ref"].split("/")[-1]], root)
    if "anyOf" in schema: return max(json_bound(part, root) for part in schema["anyOf"])
    if "enum" in schema: return max(len(canonical(x)) for x in schema["enum"])
    kind = schema.get("type", "string" if "pattern" in schema else None)
    if kind == "null": return 4
    if kind == "boolean": return 5
    if kind == "integer": return max(len(str(schema["minimum"])), len(str(schema["maximum"])))
    if kind == "string":
        # JSON control-character escapes take six bytes per code point; IDs are ASCII.
        ascii_id = schema.get("pattern", "").startswith("^[a-z]") or schema.get("pattern") == "^[a-f0-9]{64}$"
        length = schema.get("maxLength", 64 if schema.get("pattern") == "^[a-f0-9]{64}$" else 100)
        return 2 + length * (1 if ascii_id else 6)
    if kind == "array":
        n = schema["maxItems"]
        return 2 + n * (json_bound(schema["items"], root) + 1)
    if kind == "object":
        size = 2 + sum(len(canonical(key)) + 2 + json_bound(value, root) for key, value in schema.get("properties", {}).items())
        additional = schema.get("additionalProperties", False)
        if type(additional) is dict:
            size += schema["maxProperties"] * (json_bound(schema.get("propertyNames", {"type": "string", "maxLength": 100}), root) + 2 + json_bound(additional, root))
        return size
    raise ValueError("Unbounded schema in save budget")


def estimate(catalog, actions):
    schema = deepcopy(SCHEMA)
    p, d = schema["properties"], schema["$defs"]
    p["facts"]["maxProperties"] = len(catalog["facts"])
    for who in p["knowledge"]["properties"].values(): who["maxProperties"] = len(catalog["facts"])
    p["experience"]["maxProperties"] = len(actions)
    p["habits"]["maxProperties"] = len(catalog["habits"])
    p["memories"]["properties"]["summaries"]["maxProperties"] = len(catalog["memory_kinds"])
    p["items"]["maxItems"] = sum(item["capacity"] for item in catalog["items"].values())
    d["fact_snapshot"]["properties"]["value"] = {"anyOf": [value_schema(f["spec"]) for f in catalog["facts"].values()]}
    memory = d["memory"]["properties"]
    memory["facts"]["maxItems"] = max(len(spec["facts"]) for spec in catalog["memory_specs"].values())
    memory["choice_summary"]["maxProperties"] = max(len(spec["summary"]) for spec in catalog["memory_specs"].values())
    summary_specs = [value_schema(value) for spec in catalog["memory_specs"].values() for value in spec["summary"].values()]
    memory["choice_summary"]["additionalProperties"] = {"anyOf": summary_specs or [{"type": "null"}]}
    # Scene locals only allow scalar declared values, bounded to 200 characters.
    d["scene"]["properties"]["locals"]["additionalProperties"] = {"anyOf": [{"type": "null"}, {"type": "boolean"}, {"type": "integer", "minimum": -2147483648, "maximum": 2147483647}, {"type": "string", "maxLength": 200}]}
    state_bytes = json_bound(schema, schema)
    frame_bytes = json_bound(d["frame"], schema)
    # Envelope, page, checksums, up to 64 pinned release IDs and four trace refs.
    metadata_bytes = 64 * 1024
    total = state_bytes + frame_bytes + metadata_bytes
    ensure(total <= PUBLICATION_BUDGET, "save_budget", "保存データの最大見積もりが24MiBを超えるため公開できない。記録の種類・上限を整理する。")
    return {"state_bytes_upper_bound": state_bytes, "frame_bytes_upper_bound": frame_bytes, "metadata_bytes_allowance": metadata_bytes, "save_bytes_upper_bound": total, "publication_limit_bytes": PUBLICATION_BUDGET, "assumption": "canonical UTF-8 JSON; six bytes per unrestricted character; all bounded containers full simultaneously"}
