"""Compile the immutable runtime schema once, then validate every value fully."""
import re
from .errors import GameError, ensure

KEYWORDS = {"$schema", "title", "$defs", "$ref", "type", "enum", "properties", "required", "additionalProperties", "items", "maxItems", "maxProperties", "propertyNames", "minimum", "maximum", "minLength", "maxLength", "pattern", "anyOf"}
TYPES = {"null": type(None), "integer": int, "boolean": bool, "string": str, "array": list, "object": dict}
_COMPILED = {}


def _compile(schema, root, memo):
    identity = id(schema)
    if identity in memo: return memo[identity]
    ensure(set(schema) <= KEYWORDS, "schema_definition", "未対応のSchema項目。")
    if "$ref" in schema:
        ref = schema["$ref"]
        ensure(ref.startswith("#/$defs/"), "schema_definition", "外部参照は使えない。")
        return _compile(root["$defs"][ref.split("/")[-1]], root, memo)
    if "anyOf" in schema:
        alternatives = [_compile(item, root, memo) for item in schema["anyOf"]]
        def union(value, path):
            for check in alternatives:
                try:
                    check(value, path)
                    return
                except GameError:
                    pass
            raise GameError("state_type", path + " の型が違う。")
        memo[identity] = union
        return union
    kind = schema.get("type")
    ensure(not kind or kind in TYPES, "schema_definition", "未対応の型。")
    expected = TYPES.get(kind)
    enum = tuple((type(v), v) for v in schema["enum"]) if "enum" in schema else None
    minimum, maximum = schema.get("minimum"), schema.get("maximum")
    min_length, max_length = schema.get("minLength", 0), schema.get("maxLength")
    pattern = re.compile(schema["pattern"]) if "pattern" in schema else None
    max_items, max_properties = schema.get("maxItems"), schema.get("maxProperties")
    required = frozenset(schema.get("required", []))
    properties = {k: _compile(v, root, memo) for k, v in schema.get("properties", {}).items()}
    item_check = _compile(schema["items"], root, memo) if "items" in schema else None
    name_check = _compile(schema["propertyNames"], root, memo) if "propertyNames" in schema else None
    additional = schema.get("additionalProperties", True)
    extra_check = _compile(additional, root, memo) if type(additional) is dict else None

    def check(value, path):
        actual = type(value)
        if expected is not None and actual is not expected:
            raise GameError("state_type", path + " の型が違う。")
        if enum is not None and not any(actual is t and value == v for t, v in enum):
            raise GameError("state_enum", path + " の値が未登録。")
        if actual is int:
            if (minimum is not None and value < minimum) or (maximum is not None and value > maximum):
                raise GameError("state_range", path + " が範囲外。")
        elif actual is str:
            if len(value) < min_length or (max_length is not None and len(value) > max_length):
                raise GameError("state_range", path + " の長さが範囲外。")
            if pattern is not None and pattern.search(value) is None:
                raise GameError("state_pattern", path + " の形式が違う。")
        elif actual is list:
            if max_items is not None and len(value) > max_items:
                raise GameError("state_limit", path + " の件数が上限を超えている。")
            if item_check:
                for index, item in enumerate(value): item_check(item, f"{path}[{index}]")
        elif actual is dict:
            if not required <= value.keys(): raise GameError("state_fields", path + " の項目が不足。")
            if max_properties is not None and len(value) > max_properties:
                raise GameError("state_limit", path + " の項目が多すぎる。")
            for key, item in value.items():
                if name_check: name_check(key, path)
                if key in properties: properties[key](item, path + "." + key)
                elif additional is False: raise GameError("state_fields", path + " に未登録の項目 " + key)
                elif extra_check: extra_check(item, path + "." + key)
    memo[identity] = check
    return check


def validate(value, schema, root=None, path="state"):
    root = schema if root is None else root
    key = (id(schema), id(root))
    if key not in _COMPILED:
        # Keep both declarations alive: Python cannot recycle their IDs here.
        _COMPILED[key] = (schema, root, _compile(schema, root, {}))
    _COMPILED[key][2](value, path)
