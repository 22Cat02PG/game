@echo off
chcp 65001 >nul
cd /d "%~dp0"
call "%~dp0start.bat" --test-cheats %*
exit /b %errorlevel%
