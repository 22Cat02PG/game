"""v8.2.7：6係の精査（2026-09-28）の直しの試験。公開の選択肢から確かめる（時刻・高まりなどの準備だけ内部で行う）。"""
import contextlib
import io
import tempfile
import unittest
from unittest import mock

from nagishima.engine import Engine
from tests.support import do, page, press
from tools.build_intimacy_release import ENTRANCE, MOVE_ACTIVE, back_face_seen
from tools.run_stage_b_routes import Route


def choices(engine):
    return {c["id"]: c for c in engine.get_view()["choices"]}


def meanings(engine):
    return [b["meaning"] for b in engine.get_view()["blocks"]]


def variants(engine):
    return [b["variant"] for b in engine.get_view()["blocks"]]


def explain(engine, identity):
    return engine.get_view()["explanations"].get(identity)


class V827(unittest.TestCase):
    def route(self, *args, **kwargs):
        route = Route(*args, **kwargs)
        self.addCleanup(route.close)
        return route

    def engine(self, seed=7):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        return Engine(temp.name, seed=seed, release="interaction_009", autosave=False)

    def ready(self, seed, tier, position="h_pos_player_above", arousal=None, band=None, **kwargs):
        route = self.route(seed, tier=tier, day_offset=2, **kwargs)
        route.begin()
        for key in ("h_strip_lower", "h_shift_under", "h_strip_self", position):
            route.action(key)
        if arousal is not None:
            route.engine._state["intimacy"]["maho"].update(arousal=arousal, band=band)  # 準備：真帆の高まり
            route.engine._install_choices()
        return route

    def to_limit(self, route, service):
        for _ in range(20):
            route.action(service)
            if route.engine.snapshot()["intimacy"]["player"]["arousal"] >= 100:
                break
        self.assertEqual(route.engine.snapshot()["intimacy"]["player"]["arousal"], 100)

    # ---- A-01・F-1：入れていない限界で手・口を止めてもらうのは、こらえること ----
    def test_stopping_her_hand_at_the_limit_is_enduring(self):
        route = self.ready(101, "few", position="h_pos_lying_face")
        self.to_limit(route, "h_maho_hand")
        route.choose("menu.main")
        stop = choices(route.engine)["end.h_maho_hand"]
        self.assertEqual(stop["label"], "手を止めてもらう（こらえる）")
        route.choose("end.h_maho_hand")
        self.assertEqual(meanings(route.engine), ["h_endure.hand"])
        state = route.engine.snapshot()
        self.assertEqual(state["intimacy"]["player"]["arousal"], 60)
        self.assertNotIn("h_maho_hand", [c["action_id"] for c in state["contacts"]])

    # ---- F-15・D-6：入れられない体位の限界では、入れる行動に「（もうこらえきれない）」を添えず、理由も今できることだけ ----
    def test_limit_in_a_position_without_insertion(self):
        route = self.route(11, hour=19, tier="few", day_offset=2)
        route.begin()
        self.assertEqual(route.engine.snapshot()["intimacy"]["position"], "sitting_close")
        for key in ("h_strip_lower", "h_shift_under", "h_strip_self"):
            route.action(key)
        self.to_limit(route, "h_maho_hand")
        route.choose("menu.main")
        route.choose("menu.h_connect")
        found = choices(route.engine)
        for key in ("touch.h_insert", "touch.h_insert_deep"):
            self.assertFalse(found[key]["available"])
            self.assertNotIn("こらえきれない", found[key]["label"])
            # v8.2.8：限界のあいだも体位は変えられるので、体位を変えれば入れられる（入れた途端に出る）ことを言う
            self.assertTrue(explain(route.engine, key).startswith("先に体位を"), explain(route.engine, key))
            self.assertTrue(explain(route.engine, key).endswith("（入れた途端に、こらえきれない）。"), explain(route.engine, key))
        # v8.2.29（ユーザー 2026-09-30）：手でしてもらっている最中は「このまま真帆の手で出す」。限界でも口づけ・愛撫はできる
        self.assertEqual(explain(route.engine, "touch.h_move_slow"), "もう限界だ。「こらえる」か、このまま真帆の手で出す。口づけや愛撫はできる。")
        self.assertTrue(found["touch.h_endure"]["available"])

    # ---- F-9・F-2：限界のまま一気に奥まで入れると、奥まで沈めた本文で果てる。真帆が一緒に達したら、その後に書く ----
    def test_deep_insert_at_the_limit_uses_deep_texts_in_order(self):
        seen = set()
        for seed in range(111, 117):
            route = self.ready(seed, "few", arousal=85, band="high")
            route.engine._state["intimacy"]["player"]["arousal"] = 100  # 準備：限界
            route.engine._install_choices()
            route.action("h_insert_deep")
            state = route.engine.snapshot()["intimacy"]
            self.assertEqual((state["inserted"], state["player"]["finishes"], state["mess"]), (True, 1, "inside"))
            found, blocks = meanings(route.engine), route.engine.get_view()["blocks"]
            self.assertEqual(found[0], "h_overflow.insert_deep", found)
            self.assertNotIn("h_overflow.insert", found)
            self.assertFalse(any(m.startswith(("h_insert_deep.", "h.sign.", "h.deadline")) for m in found), found)
            self.assertTrue(blocks[0]["variant"].startswith(("x12.h_overflow.insert_deep.", "p13.h_overflow.insert_deep.")), blocks[0]["variant"])  # v8.2.18：専用の本文
            self.assertIsNone(ENTRANCE.search(blocks[0]["body"]), blocks[0]["body"])  # 入り口で果てた本文は使わない
            climax = [i for i, m in enumerate(found) if m.startswith("h.climax.")]
            if climax:
                self.assertEqual(found[climax[0]], "h.climax.together")
                self.assertGreater(climax[0], 0)  # 果てた本文の後
                self.assertTrue(state["maho"]["sensitive"])
            seen.add(bool(climax))
        self.assertIn(True, seen)

    # ---- F-5：真帆が達したあとに一気に奥までを止める本文は、達したあとの本文 ----
    def test_deep_deflect_after_her_climax(self):
        for tier in ("few", "familiar"):
            route = self.ready(121, tier, arousal=60, band="mid")
            route.engine._state["intimacy"]["maho"].update(climaxes=1, climax_source="finger")  # 準備：真帆は一度（指で）達した
            route.engine._install_choices()
            route.action("h_insert_deep")
            found = meanings(route.engine)
            self.assertIn("h.deflect.deep", found)
            self.assertIn("after_climax", variants(route.engine)[found.index("h.deflect.deep")])
            before = self.ready(122, tier, arousal=60, band="mid")
            before.action("h_insert_deep")
            found = meanings(before.engine)
            self.assertNotIn("after_climax", variants(before.engine)[found.index("h.deflect.deep")])

    # ---- A-08：入れたまま、脚を抱えた体位から上に重なる体位へ戻る本文 ----
    def test_back_to_player_above_while_inserted(self):
        route = self.ready(131, "few", arousal=60, band="mid")
        route.action("h_insert")
        route.action("h_pos_leg_up")
        self.assertTrue(route.engine.snapshot()["intimacy"]["inserted"])
        route.action("h_pos_player_above")
        state = route.engine.snapshot()["intimacy"]
        self.assertEqual((state["position"], state["inserted"]), ("player_above", True))
        self.assertTrue(variants(route.engine)[0].startswith("o13.h_pos_player_above."), variants(route.engine))

    # ---- F-4・F-7：背を向けた体位で拭く・敏感さの本文は、顔を書かない ----
    def test_back_facing_wipe_after_her_hand(self):
        pack_texts = None
        bodies = set()
        for seed in range(141, 147):
            route = self.ready(seed, "few", position="h_pos_lying_face")
            self.to_limit(route, "h_maho_hand")
            route.action("h_finish_hand")
            route.action("h_pos_from_behind")
            self.assertEqual(route.engine.snapshot()["intimacy"]["mess"], "hand")
            route.action("h_wipe")
            block = route.engine.get_view()["blocks"][0]
            self.assertEqual(block["meaning"], "h_wipe.start")
            self.assertFalse(back_face_seen(block["body"]), block)
            self.assertFalse(block["variant"].endswith(".base"), block)
            bodies.add(block["variant"])
            pack_texts = route.engine.pack
        back = [t for t in pack_texts.by_meaning["h_wipe.start"] if t["id"].startswith("o14.")]
        self.assertEqual(len(back), 10)
        sensitive = [t for t in pack_texts.by_meaning["h.sign.sensitive"] if t["id"].startswith("o14.")]
        self.assertEqual(len(sensitive), 6)
        for t in back + sensitive:
            self.assertIn({"field": "intimacy.facing", "op": "eq", "value": "back"}, t["when"]["all"], t["id"])

    # ---- C-12：こちらが動いていないときの「様子を聞く」は、動いている本文を出さない ----
    def test_check_without_moving(self):
        for tier in ("first", "few", "familiar"):
            route = self.ready(151, tier, arousal=50, band="mid")
            route.action("h_check")  # 初めて聞くとき（h_check.first）
            route.action("h_check")
            block = route.engine.get_view()["blocks"][0]
            text = route.engine.pack.by_text[block["variant"]]
            self.assertEqual(block["meaning"], "h_check.start")
            self.assertNotIn(MOVE_ACTIVE, text["when"].get("all", []), block)
            self.assertFalse(block["variant"].endswith(".base"), block)

    # ---- C-01：抜く・拭くのあとも、余韻（抱きしめて休む）は続く ----
    def test_after_hold_survives_withdraw_and_wipe(self):
        route = self.ready(161, "familiar", arousal=60, band="mid")
        route.action("h_insert")
        route.engine._state["intimacy"]["player"]["arousal"] = 80  # 準備：出せるところまで
        route.engine._install_choices()
        route.action("h_finish_inside")
        route.action("h_withdraw")
        route.action("h_wipe")
        self.assertTrue(route.engine.snapshot()["intimacy"]["after"])
        route.action("h_after_hold")
        self.assertEqual(meanings(route.engine)[0].split(".")[0], "h_after_hold")
        again = self.ready(162, "familiar", arousal=60, band="mid")
        again.action("h_insert")
        again.engine._state["intimacy"]["player"]["arousal"] = 80
        again.engine._install_choices()
        again.action("h_finish_inside")
        again.action("h_kiss_deep")  # 別の触れ合いを始めたら、余韻は終わる
        self.assertFalse(again.engine.snapshot()["intimacy"]["after"])

    # ---- D-3：締め切りのあと（真帆が切り上げると言った後）は、入れる・体位を変えるの理由が締め切りを言う ----
    def test_after_the_deadline_the_reason_is_the_deadline(self):
        route = self.ready(171, "few")
        route.engine._state["intimacy"]["wrap_up"] = 2  # 準備：真帆が切り上げると言った後
        route.engine._install_choices()
        route.choose("menu.main")
        route.choose("menu.h_connect")
        self.assertEqual(explain(route.engine, "touch.h_insert"), "真帆はもう、今夜は切り上げると言った。")
        self.assertEqual(explain(route.engine, "touch.h_endure"), "限界が来たときに選べる。")
        route.choose("menu.main")
        route.choose("menu.h_position")
        self.assertEqual(explain(route.engine, "touch.h_pos_lying_face"), "真帆はもう、今夜は切り上げると言った。")

    # ---- B-01・F-8：話の理由、保留した約束の話、同じ種類の約束の自動の紐づけ、断る選択肢 ----
    def test_scene_reasons_say_what_to_do(self):
        engine = self.engine()
        page(engine, "talk")
        self.assertEqual(explain(engine, "begin.workbench_half"), "二人の関係がもう少し進んでから話せる。")
        self.assertEqual(explain(engine, "begin.remember_tea"), "一緒にお茶をした思い出ができてから話せる。")
        self.assertEqual(explain(engine, "begin.room_conversation"), "二人で部屋へ行ってから話せる。")

    def test_suspended_promise_talk_is_resumed_not_restarted(self):
        engine = self.engine()
        do(engine, "plans", "begin.promise_tea")
        press(engine, "scene.pause")
        page(engine, "plans")
        self.assertFalse(choices(engine)["begin.promise_tea"]["available"])
        self.assertEqual(explain(engine, "begin.promise_tea"), "この話は保留してある。「保留した話」から続ける。")

    def test_activity_of_the_same_kind_keeps_the_promise(self):
        engine = self.engine()
        do(engine, "plans", "begin.promise_tea")
        press(engine, "scene.yes")
        self.assertEqual(len(engine.snapshot()["promises"]), 1)
        do(engine, "activities", "activity.tea")  # 約束の場所（居間）で同じことをすれば、約束を果たしたことになる
        self.assertEqual(engine.snapshot()["activities"][-1]["promise_id"], engine.snapshot()["promises"][0]["id"])
        press(engine, "scene.finish")
        self.assertEqual(engine.snapshot()["promises"], [])

    def test_promise_later_is_the_player_backing_out(self):
        engine = self.engine()
        do(engine, "plans", "begin.promise_walk")
        self.assertEqual(choices(engine)["scene.later"]["label"], "やっぱり今度にする")
        press(engine, "scene.later")
        block = engine.get_view()["blocks"][-1]
        self.assertEqual(block["meaning"], "promise.walk.later")
        self.assertIn("今度", block["body"])
        self.assertEqual(engine.snapshot()["promises"], [])

    # ---- 画面：空の入力は同じ本文を繰り返さない。分からない入力は誤りを返して続ける ----
    def test_cli_blank_and_unknown_input(self):
        from nagishima import __main__ as cli
        with tempfile.TemporaryDirectory() as temp:
            opening = Engine(temp, seed=20380407, release="interaction_009", autosave=False).get_view()["blocks"][-1]["body"]
        with tempfile.TemporaryDirectory() as data, tempfile.TemporaryDirectory() as logs:
            out = io.StringIO()
            with mock.patch("builtins.input", side_effect=["", "でたらめ な入力", "", "終了"]), contextlib.redirect_stdout(out):
                cli.main(["--release", "interaction_009", "--data-dir", data, "--no-autosave", "--log", logs + "/run.jsonl"])
        text = out.getvalue()
        self.assertEqual(text.count(opening), 1, text[-1500:])
        self.assertIn("エラー: 現在表示している操作から選ぶ。", text)
        self.assertIn("終了コマンド", text)

    # ---- grok の第7陣 07・08（一気に奥まで入れる）----
    def test_wave7_deep_insert_texts(self):
        pack = self.engine().pack
        texts = pack.by_meaning["h_insert_deep.start"]
        for prefix in ("p7.", "x6."):
            found = [t for t in texts if t["id"].startswith(prefix)]
            self.assertEqual(len(found), 40, prefix)
        explicit = [t for t in texts if t["id"].startswith("x6.")]
        self.assertTrue(all(t.get("style") == "explicit" for t in explicit))
        maho_above = {"field": "intimacy.position", "op": "ne", "value": "maho_above"}
        self.assertIn(maho_above, pack.by_text["p7.h_insert_deep.start.few.face.s.v1"]["when"]["all"])  # こちらの背に手を回す
        lean = {"not": {"field": "intimacy.position", "op": "in", "value": ["from_behind", "prone_back"]}}
        self.assertIn(lean, pack.by_text["x6.h_insert_deep.start.familiar.back.s.v2"]["when"]["all"])  # 背中を預ける
        # 背を向けた「後ろから」（数回）でも、grok の本文が出る
        route = self.ready(191, "few", position="h_pos_from_behind", arousal=85, band="high")
        route.action("h_insert_deep")
        self.assertTrue(route.engine.snapshot()["intimacy"]["inserted"])
        self.assertEqual(meanings(route.engine)[0], "h_insert_deep.start")

    # ---- 本文の直し（精査 C-02・C-19・F-11〜F-14）----
    def test_text_fixes(self):
        pack = self.engine().pack
        texts = pack.by_text
        mouth = [t for t in pack.texts if t["meaning"].startswith("h_player_mouth.") and t["id"].startswith("p2.")]
        self.assertGreater(len(mouth), 16)
        self.assertFalse([t["id"] for t in mouth if "{vagina}" in t["body"]])
        self.assertIn("おとなしく拭かれている", texts["o10.h_wipe.mouth.s.v1"]["body"])
        for tid in ("x6.h_overflow.insert.few.back.s.v5", "x6.h_overflow.insert.familiar.back.s.v3"):
            self.assertNotIn("責めない", texts[tid]["body"])
        self.assertNotIn("どくどくする", texts["x6.h_overflow.insert.first.face.s.v2"]["body"])
        for t in pack.texts:
            if t["id"].startswith(("p7.", "x6.")):
                self.assertNotIn("前より", t["body"], t["id"])
                self.assertNotIn("手順が分かって", t["body"], t["id"])


if __name__ == "__main__":
    unittest.main()
