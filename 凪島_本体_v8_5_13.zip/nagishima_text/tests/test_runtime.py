from copy import deepcopy
from pathlib import Path
from tempfile import TemporaryDirectory
import json
import subprocess
import sys
import unittest
from unittest.mock import patch

from nagishima import clock
from nagishima.authoring import publish, compile_text, CHECKS
from nagishima.codec import canonical, decode, digest, write_json, bytes_digest
from nagishima.conditions import evaluate, validate, latest_memory
from nagishima.content import Pack, FILES, validate_scene
from nagishima.engine import Engine
from nagishima.errors import GameError
from tests.support import press, page, do, dismiss, activity, promise, milestone, stage_one, stage_two, stage_three, stage_four

ROOT = Path(__file__).resolve().parents[1]


class RuntimeCase(unittest.TestCase):
    def setUp(self):
        self.temporary = TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.directory = Path(self.temporary.name)
        self.e = Engine(self.directory, seed=37, autosave=False)

    def unavailable(self, identity, reason=None):
        before, view = self.e.snapshot(), self.e.get_view()
        with self.assertRaises(GameError) as caught: press(self.e, identity)
        if reason: self.assertEqual(caught.exception.code, reason)
        self.assertEqual(self.e.snapshot(), before)
        self.assertEqual(self.e.get_view(), view)

    def wait_minutes(self, count):
        self.assertEqual(count % 30, 0)
        while count:
            step = 120 if count >= 120 else 30
            do(self.e, "main", "wait." + str(step))
            count -= step


class InteractionTests(RuntimeCase):
    def test_query_and_navigation_never_change_simulation(self):
        before = self.e.snapshot()
        for _ in range(5): self.e.get_view(); self.e.get_collection()
        page(self.e, "talk"); page(self.e, "main")
        self.assertEqual(before, self.e.snapshot())

    def test_stale_revision_rejects_double_click(self):
        page(self.e, "touch")
        view = self.e.get_view()
        press(self.e, "touch.talk")
        after = self.e.snapshot()
        with self.assertRaises(GameError): self.e.choose("touch.talk", view["revision"], view["session"])
        self.assertEqual(after, self.e.snapshot())

    def test_snapshot_is_not_a_mutable_backdoor(self):
        copy = self.e.snapshot(); copy["relation"]["stage"] = 4
        self.assertEqual(self.e.snapshot()["relation"]["stage"], 0)

    def test_shared_stage_gate(self):
        page(self.e, "touch")
        self.unavailable("touch.head", "relationship")
        self.unavailable("touch.kiss", "relationship")

    def test_compatible_contacts_survive_conversation(self):
        stage_two(self.e)
        do(self.e, "touch", "near")
        press(self.e, "touch.head"); press(self.e, "touch.hands")
        original = self.e.snapshot()["contacts"]
        press(self.e, "touch.talk")
        self.assertEqual(original, self.e.snapshot()["contacts"])
        self.assertEqual({"head", "hands"}, {c["action_id"] for c in original})

    def test_first_continue_settled_restart(self):
        stage_two(self.e); do(self.e, "touch", "near")
        self.assertEqual(press(self.e, "touch.head")["blocks"][-1]["meaning"], "head.first")
        for meaning in ["head.continue", "head.continue", "head.settled"]:
            self.assertEqual(press(self.e, "touch.head")["blocks"][-1]["meaning"], meaning)
        self.assertEqual(self.e.snapshot()["experience"]["head"]["count"], 1)
        press(self.e, "end.head")
        self.assertEqual(press(self.e, "touch.head")["blocks"][-1]["meaning"], "head.start")
        self.assertEqual(self.e.snapshot()["experience"]["head"]["count"], 2)

    def test_explicit_replacement_uses_actual_resources(self):
        stage_three(self.e)
        do(self.e, "touch", "touch.head")
        press(self.e, "touch.hug")
        self.assertEqual(["hug"], [c["action_id"] for c in self.e.snapshot()["contacts"]])
        self.unavailable("touch.hands", "resources")
        press(self.e, "touch.kiss")
        self.assertEqual(["hug"], [c["action_id"] for c in self.e.snapshot()["contacts"]])

    def test_maho_origin_shares_experience(self):
        stage_two(self.e)
        do(self.e, "main", "near")
        # Complete one activity to release earlier declined goal groups.
        activity(self.e, "tea")
        do(self.e, "main", "listen")
        # The closeness goal can be offered immediately after the activity; the
        # helper declines it. A new completed activity removes that cooldown.
        if not self.e.snapshot()["offer"]:
            do(self.e, "activities", "activity.tea"); press(self.e, "scene.finish")
        offer = self.e.snapshot()["offer"]
        self.assertIsNotNone(offer)
        if offer["kind"] != "closeness":
            press(self.e, "offer.decline")
            do(self.e, "activities", "activity.tea"); press(self.e, "scene.finish")
        self.assertEqual(self.e.snapshot()["offer"]["kind"], "closeness")
        press(self.e, "offer.accept")
        experience = self.e.snapshot()["experience"]["hands"]
        self.assertEqual(experience["by_origin"], {"player": 0, "maho": 1})
        do(self.e, "touch", "end.hands")
        self.assertEqual(press(self.e, "touch.hands")["blocks"][-1]["meaning"], "hands.start")

    def test_text_failure_rolls_back_state_rng_and_screen(self):
        page(self.e, "touch")
        before, view = self.e.snapshot(), self.e.get_view()
        with patch.object(self.e.pack, "select", side_effect=GameError("test_failure", "本文を読めない。")):
            with self.assertRaises(GameError): press(self.e, "touch.talk")
        self.assertEqual(self.e.snapshot(), before)
        self.assertEqual(self.e.get_view(), view)

    def test_natural_and_direct_private_share_transition(self):
        stage_three(self.e); self.e.save()
        do(self.e, "talk", "touch.affection")
        self.assertEqual(self.e.snapshot()["mode"], "normal")
        self.assertEqual(self.e.snapshot()["offer"]["kind"], "private")
        press(self.e, "offer.accept")
        natural = self.e.snapshot()
        self.e.load(); do(self.e, "main", "private.begin")
        direct = self.e.snapshot()
        for field in ("mode", "actors", "distance"):
            self.assertEqual(natural[field], direct[field])
        self.assertEqual(natural["activities"][0]["remaining_minutes"], direct["activities"][0]["remaining_minutes"])
        self.assertEqual(natural["world"]["now"], direct["world"]["now"])

    def test_decline_keeps_touch_and_does_not_repeat_on_clicks(self):
        stage_three(self.e)
        do(self.e, "talk", "touch.affection")
        contacts = self.e.snapshot()["contacts"]
        press(self.e, "offer.decline")
        for _ in range(4): do(self.e, "talk", "touch.affection")
        self.assertIsNone(self.e.snapshot()["offer"])
        self.assertEqual(contacts, self.e.snapshot()["contacts"])

    def test_private_owned_contact_closes_but_persistent_remains(self):
        stage_three(self.e)
        do(self.e, "touch", "end.hands")
        do(self.e, "main", "private.begin")
        do(self.e, "touch", "touch.head")
        do(self.e, "main", "room.talk")
        press(self.e, "scene.hand")
        self.assertEqual({c["action_id"]: c["lifetime"] for c in self.e.snapshot()["contacts"]}, {"head": "persistent", "hands": "private"})
        press(self.e, "scene.finish")
        self.assertEqual(["head"], [c["action_id"] for c in self.e.snapshot()["contacts"]])
        self.assertEqual(self.e.snapshot()["mode"], "normal")

    def test_joint_movement_keeps_hands_and_stops_head(self):
        stage_two(self.e)
        do(self.e, "touch", "near"); press(self.e, "touch.hands"); press(self.e, "touch.head")
        do(self.e, "move", "move.joint.kitchen")
        self.assertEqual(["hands"], [c["action_id"] for c in self.e.snapshot()["contacts"]])
        do(self.e, "move", "move.solo.living_room")
        self.assertFalse(self.e.snapshot()["contacts"])


class SceneTests(RuntimeCase):
    def test_both_branches_merge_without_losing_selected_place(self):
        stage_two(self.e); self.e.save()
        for branch in ("window", "table"):
            self.e.load()
            do(self.e, "talk", "begin.shared_place")
            press(self.e, "scene." + branch)
            self.assertEqual(self.e.snapshot()["scene"]["locals"]["place"], branch)
            press(self.e, "scene.confirm")
            self.assertEqual(self.e.snapshot()["facts"]["shared.place"]["value"], branch)
            self.assertEqual(self.e.get_collection("memories")["recent"][-1]["choice_summary"], {"place": branch})

    def test_pause_restore_keeps_question_without_replaying_enter(self):
        stage_two(self.e)
        do(self.e, "talk", "begin.shared_place"); press(self.e, "scene.table")
        original = self.e.get_view()["blocks"][-1]
        press(self.e, "touch.talk")
        self.assertEqual(self.e.get_view()["blocks"][-1], original)
        press(self.e, "scene.pause")
        parked = self.e.snapshot()["suspended"][0]
        self.e.save(); self.e.load()
        do(self.e, "move", "move.joint.kitchen")
        page(self.e, "resume"); self.unavailable("resume." + parked["id"], "resume_conditions")
        do(self.e, "move", "move.joint.living_room")
        do(self.e, "resume", "resume." + parked["id"])
        self.assertEqual(self.e.get_view()["blocks"], [original])
        self.assertEqual(self.e.snapshot()["scene"]["visit"], parked["visit"])
        self.assertEqual(self.e.snapshot()["scene"]["locals"], parked["locals"])

    def test_three_parked_still_leave_cancel_and_drop(self):
        for _ in range(3): do(self.e, "talk", "begin.two_cups"); press(self.e, "scene.pause")
        do(self.e, "talk", "begin.two_cups")
        self.unavailable("scene.pause", "suspended_full")
        question = self.e.get_view()["blocks"]
        identity = self.e.snapshot()["suspended"][0]["id"]
        press(self.e, "drop." + identity)
        self.assertEqual(self.e.get_view()["blocks"], question)
        press(self.e, "scene.pause")
        self.assertEqual(len(self.e.snapshot()["suspended"]), 3)

    def test_question_blocks_unrelated_scene_and_offer(self):
        do(self.e, "talk", "begin.two_cups")
        for identity in ("listen", "begin.workbench_half", "menu.activities"):
            self.unavailable(identity, "choice")
        press(self.e, "touch.talk")
        self.assertIsNone(self.e.snapshot()["offer"])

    def test_private_transition_can_park_an_activity(self):
        stage_three(self.e)
        do(self.e, "activities", "activity.tea")
        press(self.e, "private.begin")
        state = self.e.snapshot()
        self.assertEqual(state["mode"], "private")
        self.assertEqual(len(state["suspended"]), 1)
        self.assertEqual(sorted(a["status"] for a in state["activities"]), ["running", "suspended"])
        do(self.e, "main", "private.end")
        do(self.e, "move", "move.joint.living_room")
        do(self.e, "resume", "resume." + state["suspended"][0]["id"])
        before = self.e.snapshot()["progress"]["completed_activities"]
        press(self.e, "scene.finish")
        self.assertEqual(self.e.snapshot()["progress"]["completed_activities"], before + 1)

    def test_retained_memory_is_a_snapshot(self):
        activity(self.e, "tea")
        do(self.e, "talk", "begin.remember_tea")
        original = deepcopy(self.e.snapshot()["scene"]["memories"])
        press(self.e, "scene.pause")
        do(self.e, "move", "move.joint.kitchen")
        activity(self.e, "tea")
        identity = self.e.snapshot()["suspended"][0]["id"]
        do(self.e, "resume", "resume." + identity)
        self.assertEqual(self.e.snapshot()["scene"]["memories"], original)
        self.assertEqual(latest_memory(self.e.snapshot(), "tea")["location"], "kitchen")


class LifeTests(RuntimeCase):
    def test_full_public_route_to_stage_four_and_life_continues(self):
        stage_four(self.e)
        self.assertEqual(self.e.snapshot()["relation"]["stage"], 4)
        self.assertEqual([m["stage"] for m in self.e.snapshot()["relation"]["milestones"]], [1, 2, 3, 4])
        before = self.e.snapshot()["progress"]["completed_activities"]
        do(self.e, "main", "sleep"); activity(self.e, "tea")
        self.assertEqual(self.e.snapshot()["progress"]["completed_activities"], before + 1)

    def test_no_automatic_relationship_and_can_postpone(self):
        do(self.e, "talk", "begin.two_cups"); press(self.e, "scene.tea"); press(self.e, "scene.remember")
        activity(self.e, "tea")
        self.assertEqual(self.e.snapshot()["relation"]["stage"], 0)
        do(self.e, "talk", "begin.milestone_1"); press(self.e, "scene.later")
        do(self.e, "main", "sleep"); milestone(self.e, 1)
        self.assertEqual(self.e.snapshot()["relation"]["stage"], 1)

    def test_habit_counts_distinct_days_and_completion_once(self):
        activity(self.e, "tea"); activity(self.e, "tea")
        self.assertEqual(self.e.snapshot()["habits"]["tea"]["count_days"], 1)
        self.unavailable("scene.finish", "choice")
        for _ in range(2): do(self.e, "main", "sleep"); activity(self.e, "tea")
        self.assertEqual(self.e.snapshot()["habits"]["tea"]["count_days"], 3)
        self.assertIsNotNone(self.e.snapshot()["habits"]["tea"]["established_at"])

    def test_sleep_after_midnight_and_fixed_deadline(self):
        first = self.e.snapshot()["world"]
        self.wait_minutes(1020)
        self.assertEqual(clock.format_time(self.e.snapshot()["world"]["now"]), "2038-04-08 00:30")
        self.assertEqual(first["awake_deadline"], self.e.snapshot()["world"]["awake_deadline"])
        do(self.e, "main", "sleep")
        self.assertEqual(clock.format_time(self.e.snapshot()["world"]["now"]), "2038-04-08 07:30")

    def test_cancel_suspended_activity_at_deadline(self):
        do(self.e, "activities", "activity.tea"); press(self.e, "scene.pause")
        identity = self.e.snapshot()["suspended"][0]["id"]
        self.wait_minutes(1290)
        do(self.e, "resume", "drop." + identity)
        self.assertFalse(self.e.snapshot()["activities"])
        do(self.e, "main", "sleep")
        self.assertEqual(clock.format_time(self.e.snapshot()["world"]["now"]), "2038-04-08 07:30")

    def test_promises_full_overdue_postpone_cancel(self):
        for kind in ("tea", "walk"):
            do(self.e, "plans", "begin.promise_" + kind); press(self.e, "scene.yes")
        page(self.e, "plans"); self.unavailable("begin.promise_tea", "scene_conditions")
        for _ in range(3): do(self.e, "main", "sleep")
        ids = [p["id"] for p in self.e.snapshot()["promises"]]
        do(self.e, "plans", "postpone." + ids[0])
        self.assertGreater(self.e.snapshot()["promises"][0]["due_at"], self.e.snapshot()["world"]["now"])
        do(self.e, "plans", "cancel." + ids[1])
        self.assertEqual(self.e.snapshot()["promise_history"][-1]["status"], "cancelled")

    def test_fulfilled_promise_cannot_be_counted_twice(self):
        identity = promise(self.e)
        self.assertEqual(self.e.snapshot()["progress"]["fulfilled_promises"], 1)
        activity(self.e, "tea")
        self.assertEqual(self.e.snapshot()["progress"]["fulfilled_promises"], 1)
        self.assertEqual(self.e.snapshot()["promise_history"][-1]["id"], identity)

    def test_delivery_while_activity_does_not_move_actors(self):
        do(self.e, "orders", "buy.mug")
        do(self.e, "main", "sleep")
        self.wait_minutes(120)
        do(self.e, "move", "move.solo.workshop")
        do(self.e, "move", "move.joint.living_room")
        do(self.e, "activities", "activity.tea")
        press(self.e, "scene.finish")
        self.assertEqual(self.e.snapshot()["orders"][0]["status"], "delivered")
        self.assertEqual(self.e.snapshot()["actors"]["maho"]["location"], "living_room")
        self.assertTrue(self.e.snapshot()["world"]["pending_notices"])
        self.assertTrue(self.e.snapshot()["inbox"])

    def test_weekly_message_is_not_repeated_by_load(self):
        do(self.e, "main", "sleep"); self.wait_minutes(120)
        self.e.save(); before = self.e.get_collection("inbox"); self.e.load()
        self.assertEqual(before, self.e.get_collection("inbox"))
        message = before[0]
        do(self.e, "inbox", "read." + message["id"])
        self.assertEqual(self.e.get_view()["blocks"][-1]["body"], message["body"])
        self.assertIsNotNone(self.e.get_collection("inbox")[0]["read_at"])

    def test_order_reservation_and_gift_ownership(self):
        do(self.e, "orders", "buy.mug")
        order = self.e.snapshot()["orders"][0]["id"]
        self.unavailable("receive." + order, "order")
        do(self.e, "main", "sleep"); self.wait_minutes(150)
        do(self.e, "orders", "receive." + order)
        self.unavailable("receive." + order, "choice")
        item = self.e.snapshot()["items"][0]["id"]
        do(self.e, "touch", "touch.hold_mug")
        do(self.e, "move", "move.solo.workshop")
        page(self.e, "inventory")
        self.unavailable("give." + item, "resources")
        do(self.e, "touch", "end.hold_mug")
        do(self.e, "inventory", "give." + item)
        self.assertEqual(self.e.snapshot()["items"][0]["owner"], "maho")
        self.unavailable("give." + item, "choice")

    def test_held_item_survives_solo_move_and_blocks_gift(self):
        do(self.e, "orders", "buy.mug"); order = self.e.snapshot()["orders"][0]["id"]
        do(self.e, "main", "sleep"); self.wait_minutes(150); do(self.e, "orders", "receive." + order)
        item = self.e.snapshot()["items"][0]["id"]
        do(self.e, "touch", "touch.hold_mug")
        page(self.e, "inventory"); self.unavailable("give." + item, "gift")
        do(self.e, "move", "move.solo.workshop")
        self.assertEqual(["hold_mug"], [c["action_id"] for c in self.e.snapshot()["contacts"]])
        do(self.e, "touch", "end.hold_mug")
        do(self.e, "inventory", "give." + item)
        self.assertEqual(self.e.snapshot()["items"][0]["owner"], "maho")

    def test_order_slots_and_reserved_inventory_capacity(self):
        for _ in range(8): do(self.e, "orders", "buy.mug")
        self.unavailable("buy.tea", "order_full")
        identity = self.e.snapshot()["orders"][0]["id"]
        press(self.e, "cancel." + identity)
        press(self.e, "buy.tea")
        self.assertEqual(len(self.e.snapshot()["orders"]), 8)

    def test_project_lifecycle_and_one_time_finish(self):
        do(self.e, "plans", "project.plan"); press(self.e, "project.order")
        do(self.e, "main", "sleep"); self.wait_minutes(150)
        do(self.e, "move", "move.solo.workshop"); do(self.e, "move", "move.joint.living_room")
        order = self.e.snapshot()["orders"][0]["id"]
        do(self.e, "orders", "receive." + order)
        do(self.e, "plans", "project.install"); press(self.e, "project.finish")
        self.assertEqual(self.e.snapshot()["project"]["status"], "completed")
        self.assertEqual(self.e.snapshot()["progress"]["completed_projects"], 1)
        self.unavailable("project.finish", "project")

    def test_project_cancel_after_delivery_preserves_item(self):
        do(self.e, "plans", "project.plan"); press(self.e, "project.order")
        do(self.e, "main", "sleep"); self.wait_minutes(150)
        do(self.e, "plans", "project.cancel")
        order = self.e.snapshot()["orders"][0]["id"]
        do(self.e, "orders", "receive." + order)
        self.assertEqual(self.e.snapshot()["items"][0]["catalog_id"], "shelf")
        self.assertEqual(self.e.snapshot()["project"]["status"], "cancelled")

    def test_town_trip_cancellation_returns_at_21(self):
        for _ in range(3): do(self.e, "main", "sleep")
        do(self.e, "activities", "trip.begin")
        self.assertEqual(self.e.snapshot()["actors"]["player"]["location"], "town")
        self.unavailable("scene.pause", "choice")
        press(self.e, "scene.cancel")
        self.assertEqual(clock.format_time(self.e.snapshot()["world"]["now"]), "2038-04-10 21:00")
        self.assertEqual(self.e.snapshot()["actors"]["player"]["location"], "living_room")

    def test_town_trip_full_route_completes_once(self):
        for _ in range(3): do(self.e, "main", "sleep")
        do(self.e, "activities", "trip.begin"); press(self.e, "scene.walk"); press(self.e, "scene.home")
        self.assertEqual(clock.format_time(self.e.snapshot()["world"]["now"]), "2038-04-10 21:00")
        self.assertEqual(self.e.snapshot()["progress"]["completed_activities"], 1)


class KnowledgeTests(RuntimeCase):
    def test_only_participants_learn_and_idempotent_fact(self):
        do(self.e, "talk", "begin.two_cups"); press(self.e, "scene.coffee"); press(self.e, "scene.remember")
        state = self.e.snapshot(); revision = state["facts"]["player.drink"]["revision"]
        for who in ("kayo", "shuichi", "yuki", "chinatsu"):
            self.assertNotIn("player.drink", state["knowledge"][who])
        do(self.e, "talk", "begin.two_cups"); press(self.e, "scene.coffee"); press(self.e, "scene.remember")
        self.assertEqual(self.e.snapshot()["facts"]["player.drink"]["revision"], revision)

    def test_three_valued_conditions_cannot_invent_knowledge(self):
        expression = {"not": {"field": "fact.player.drink.value", "op": "eq", "value": "tea"}}
        validate(expression, self.e.pack.registry.fields)
        self.assertIsNone(evaluate(expression, self.e.pack.registry.values(self.e.snapshot())))
        page(self.e, "talk"); self.unavailable("memory.tea", "memory")

    def test_memory_pin_and_replay_are_separate_from_progress(self):
        activity(self.e, "tea")
        memory = self.e.snapshot()["memories"]["recent"][-1]
        do(self.e, "memories", "pin." + memory["id"])
        self.assertEqual(self.e.snapshot()["memories"]["pinned"], [memory])
        gallery = self.e.get_collection("gallery")
        before = self.e.snapshot()
        replay = self.e.get_collection("replay", gallery[0]["id"])
        self.assertGreater(len(replay["records"]), 0)
        self.assertEqual(before, self.e.snapshot())


class SaveTests(RuntimeCase):
    def test_roundtrip_exact_text_state_and_new_session(self):
        do(self.e, "talk", "begin.two_cups"); press(self.e, "scene.water")
        state, view = self.e.snapshot(), self.e.get_view()
        self.e.save(); press(self.e, "scene.remember"); self.e.load()
        self.assertEqual(state, self.e.snapshot())
        self.assertEqual(view["blocks"], self.e.get_view()["blocks"])
        self.assertNotEqual(view["session"], self.e.get_view()["session"])
        with self.assertRaises(GameError): self.e.choose("scene.remember", view["revision"], view["session"])

    def test_invalid_save_does_not_partially_apply(self):
        self.e.save(); path = self.e.storage.slot_path("slot01")
        envelope = decode(path.read_bytes()); envelope["payload"]["state"]["relation"]["stage"] = True
        envelope["sha256"] = digest(envelope["payload"]); write_json(path, envelope)
        before, view = self.e.snapshot(), self.e.get_view()
        with self.assertRaises(GameError): self.e.load()
        self.assertEqual(before, self.e.snapshot()); self.assertEqual(view, self.e.get_view())

    def test_checksum_and_missing_archive_do_not_erase_game(self):
        activity(self.e, "tea"); self.e.save()
        for path in (self.directory / "collection").glob("*.json"): path.unlink()
        self.e.load()
        record = self.e.get_collection("gallery")[0]
        with self.assertRaises(GameError): self.e.get_collection("replay", record["id"])
        before = self.e.snapshot()
        path = self.e.storage.slot_path("slot01"); envelope = decode(path.read_bytes()); envelope["payload"]["state"]["world"]["seed"] += 1
        write_json(path, envelope)
        with self.assertRaises(GameError): self.e.load()
        self.assertEqual(before, self.e.snapshot())

    def test_failed_atomic_replace_preserves_previous_save(self):
        self.e.save(); path = self.e.storage.slot_path("slot01"); original = path.read_bytes()
        do(self.e, "touch", "touch.talk")
        with patch("nagishima.codec.os.replace", side_effect=OSError("test disk failure")):
            with self.assertRaises(OSError): self.e.save()
        self.assertEqual(original, path.read_bytes())

    def test_corrupt_primary_does_not_replace_good_backup(self):
        self.e.save(); do(self.e, "touch", "touch.talk"); self.e.save()
        backup = self.e.storage.slot_path("slot01").with_suffix(".bak"); original = backup.read_bytes()
        self.e.storage.slot_path("slot01").write_text("broken")
        self.e.save()
        self.assertEqual(original, backup.read_bytes())
        self.e.load(backup=True)
        self.assertEqual(self.e.snapshot()["experience"]["talk"]["count"], 0)

    def test_autosave_three_generations(self):
        self.e.autosave_enabled = True
        for _ in range(4): do(self.e, "touch", "touch.talk")
        self.e.load("auto3")
        self.assertEqual(self.e.snapshot()["experience"]["talk"]["count"], 2)

    def test_old_save_version_and_path_traversal_rejected(self):
        with self.assertRaises(GameError): self.e.storage.slot_path("../../bad")
        self.e.save(); path = self.e.storage.slot_path("slot01"); value = decode(path.read_bytes()); value["schema"] = 6; write_json(path, value)
        with self.assertRaises(GameError): self.e.load()


class FormatAndReleaseTests(RuntimeCase):
    def bundle(self):
        job = {"id": "job.talk.001", "source_release": self.e.pack.id, "source_sha256": self.e.pack.hash, "meaning": "talk.start", "when": {"all": []}, "slots": [], "group": "talk.new", "required": ["真帆の主観"], "forbidden": ["状態を変える命令"], "reviewers": ["editor"], "min_chars": 10, "max_chars": 200}
        draft = {"id": "talk.start.new", "job_id": job["id"], "job_sha256": digest(job), "body": "真帆は、一緒に話せるのがうれしくて、今日の気持ちをゆっくり言葉にした。"}
        reviews = [{"job_sha256": digest(job), "draft_sha256": digest(draft), "reviewer": "editor", "verdict": "accept", "checks": dict.fromkeys(CHECKS, True), "notes": "登録された会話の意味に一致し、未経験の出来事を追加していない。"}]
        return {"job": job, "draft": draft, "reviews": reviews}

    def test_reviewer_hashes_bind_exact_draft_and_job(self):
        bundle = self.bundle()
        text = compile_text(**bundle, source=self.e.pack)
        self.assertEqual(set(text), {"id", "meaning", "when", "slots", "group", "body", "fallback"})
        for change in ("draft", "job", "reviewer", "effect"):
            b = deepcopy(bundle)
            if change == "draft": b["draft"]["body"] += "追記。"
            elif change == "job": b["job"]["max_chars"] += 1
            elif change == "reviewer": b["reviews"][0]["reviewer"] = "someone_else"
            else: b["draft"]["effects"] = [{"op": "relation.commit", "stage": 4}]
            with self.assertRaises(GameError): compile_text(**b, source=self.e.pack)

    def test_publish_adds_prose_and_rejects_overwrite(self):
        output = self.directory / "releases"
        path = publish(self.e.pack, output, "expanded", [self.bundle()])
        self.assertEqual(len(Pack(path).texts), len(self.e.pack.texts) + 1)
        self.e.adopt_release("expanded")
        do(self.e, "touch", "touch.talk"); press(self.e, "touch.talk")
        self.assertEqual(self.e.get_view()["blocks"][-1]["release"], "expanded")
        with self.assertRaises(GameError): publish(self.e.pack, output, "expanded", [])

    def test_old_scene_pins_definition_and_new_scene_uses_new_release(self):
        do(self.e, "talk", "begin.two_cups"); press(self.e, "scene.pause")
        identity = self.e.snapshot()["suspended"][0]["id"]
        scene = deepcopy(self.e.pack.scenes["two_cups"]); scene["revision"] += 1; scene["label"] = "好きな飲み物の新しい話"
        publish(self.e.pack, self.directory / "releases", "expanded", [self.bundle()], scenes=[scene])
        self.e.adopt_release("expanded"); self.e.save(); self.e.load()
        do(self.e, "resume", "resume." + identity)
        self.assertEqual(self.e.snapshot()["scene"]["release"], "base")
        press(self.e, "scene.tea"); press(self.e, "scene.remember")
        do(self.e, "talk", "begin.two_cups")
        self.assertEqual(self.e.snapshot()["scene"]["release"], "expanded")
        self.assertEqual(self.e.snapshot()["scene"]["scene_revision"], 2)

    def test_changed_published_files_are_rejected(self):
        path = publish(self.e.pack, self.directory / "releases", "expanded", [self.bundle()])
        with (path / "texts.json").open("ab") as stream: stream.write(b" ")
        with self.assertRaises(GameError): Pack(path)

    def test_unknown_condition_wrong_type_and_duplicate_json(self):
        for raw in ['{"a":1,"a":2}', '{"a":NaN}', '{"a":Infinity}']:
            with self.assertRaises(GameError): decode(raw)
        for expression in [{"field": "unknown", "op": "eq", "value": True}, {"field": "relation.stage", "op": "eq", "value": True}, {"field": "relation.stage", "op": "eval", "value": 1}]:
            with self.assertRaises(GameError): validate(expression, self.e.pack.registry.fields)

    def test_scene_missing_target_unreachable_and_automatic_cycle(self):
        for kind in ("target", "unreachable", "cycle"):
            scene = deepcopy(self.e.pack.scenes["two_cups"])
            if kind == "target": scene["nodes"][0]["choices"][0]["next"] = "absent"
            elif kind == "unreachable":
                extra = deepcopy(scene["nodes"][-1]); extra["id"] = "unreachable"; scene["nodes"].append(extra)
            else:
                scene["nodes"][0]["choices"] = []; scene["nodes"][0]["auto"] = scene["nodes"][0]["id"]
            with self.assertRaises(GameError): validate_scene(scene, self.e.pack.registry, self.e.pack.meanings)

    def test_cli_json_view_navigation_save_load(self):
        process = subprocess.Popen([sys.executable, "-m", "nagishima", "--json", "--no-autosave", "--data-dir", str(self.directory / "cli"), "--log", str(self.directory / "cli.jsonl")], cwd=ROOT, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding="utf-8")
        def request(value):
            process.stdin.write(json.dumps(value) + "\n"); process.stdin.flush()
            return json.loads(process.stdout.readline())
        try:
            view = request({"command": "view"})["result"]
            result = request({"command": "choose", "id": "menu.talk", "revision": view["revision"], "session": view["session"]})
            self.assertTrue(result["ok"])
            self.assertEqual(result["result"]["page"], "talk")
            self.assertTrue(request({"command": "save"})["ok"])
            self.assertTrue(request({"command": "load"})["ok"])
            process.stdin.write('{"command":"quit"}\n'); process.stdin.flush()
            self.assertEqual(json.loads(process.stdout.readline())["run"]["reason"], "quit")
            self.assertEqual(json.loads(process.stdout.readline())["type"], "summary")
            self.assertEqual(process.wait(timeout=10), 0)
        finally:
            if process.poll() is None: process.kill(); process.wait(timeout=10)
            process.stdin.close(); process.stdout.close(); process.stderr.close()


if __name__ == "__main__": unittest.main()
