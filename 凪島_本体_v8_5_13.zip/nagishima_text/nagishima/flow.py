"""v8.4.4（010）：前後の本文の流れ。

直前に出た本文の仕草（目をそらす・目を細める・頬が赤くなる など、型は版の設定 settings.flow.tags）と
同じ仕草を書いた本文、前の本文の終わりの状態と食い違う「〜たまま」（目をそらして終わった直後の「見つめたまま」など、settings.flow.keep）、
前の本文の調子から飛ぶ本文（せがんだ直後に照れて戸惑う・笑う など、settings.flow.moods と follow）を、ほかに本文がある限り後回しにする。本文を選ぶ順（content.Pack.select の rank）に点を足すだけで、本文を消したり条件を変えたりはしない。"""
import re

from .codec import exact
from .errors import GameError, ensure


def _receives(when, negated=False):
    """v8.4.10：when に、否定されていない条件 flow.prev.<名前> eq true があるか。"""
    if isinstance(when, dict):
        if "field" in when:
            return not negated and when["field"].startswith("flow.prev.") and when.get("op") == "eq" and when.get("value") is True
        return any(_receives(value, negated or key == "not") for key, value in when.items())
    if isinstance(when, list):
        return any(_receives(value, negated) for value in when)
    return False


def _check(value, keys):
    try:
        exact(value, keys)
    except (GameError, TypeError) as error:
        raise GameError("intimacy_data", "intimacy.json の流れの設定（settings.flow）の項目が不足または未登録。") from error


class Flow:
    def __init__(self, setting):
        _check(setting, ["_note", "tags", "keep", "moods", "follow", "window", "weights"])
        ensure(type(setting["tags"]) is dict and setting["tags"] and all(type(v) is str and v for v in setting["tags"].values()), "intimacy_data", "流れの仕草の型が不正。")
        ensure(type(setting["keep"]) is dict and all(type(v) is list and len(v) == 3 and type(v[0]) is str and v[1] in setting["tags"] and v[2] in setting["tags"]
                                                    for v in setting["keep"].values()), "intimacy_data", "流れの「〜たまま」の型が不正。")
        ensure(type(setting["moods"]) is dict and all(type(v) is str and v for v in setting["moods"].values()) and not set(setting["moods"]) & set(setting["tags"]),
               "intimacy_data", "流れの調子の型が不正。")
        names = set(setting["tags"]) | set(setting["moods"])
        ensure(type(setting["follow"]) is list and all(type(v) is list and len(v) == 2 and set(v) <= names for v in setting["follow"]), "intimacy_data", "流れの続かない組が不正。")
        ensure(type(setting["window"]) is int and 1 <= setting["window"] <= 4, "intimacy_data", "流れの見る本数が不正。")
        weights = setting["weights"]
        _check(weights, ["last", "earlier", "contradict", "follow"])
        ensure(all(type(v) is int and 0 <= v <= 10 for v in weights.values()), "intimacy_data", "流れの重みが不正。")
        try:
            self.tags = {key: re.compile(value) for key, value in setting["tags"].items()}
            # 「〜たまま」の型 → (型、前の本文がこの仕草で終わっていたら食い違う、前の本文がこの仕草で終わっていれば続きとして合う)
            self.keep = {key: (re.compile(value[0]), value[1], value[2]) for key, value in setting["keep"].items()}
            # 調子の型（重なりには数えない。follow の組だけに使う）
            self.moods = {key: re.compile(value) for key, value in setting["moods"].items()}
        except re.error as error:
            raise GameError("intimacy_data", "流れの型の正規表現が不正：" + str(error)) from error
        # 前の本文に前者があるとき、後者のある本文は調子が飛ぶ（[前, 次]）
        self.follow = [tuple(pair) for pair in setting["follow"]]
        self.window = setting["window"]
        self.weights = dict(weights)
        self._cache = {}
        self._receivers = {}
        self.lookup = None  # 本文の id → 本文（content.Pack が本文を読んだあとに置く）

    def names(self):
        """条件 flow.prev.<名前> に使える仕草と調子の型の名前。"""
        if not hasattr(self, "_names"):
            self._names = tuple(sorted(set(self.tags) | set(self.moods)))
        return self._names

    def prev_moods(self, state):
        """v8.4.6（010）：直前に出た本文の仕草と調子の型（条件 flow.prev.<名前>）。"""
        if self.lookup is None:
            return frozenset()
        for item in reversed(state.get("recent_text") or ()):
            text = self.lookup(item["id"])
            if text is None or self.transparent(text):
                continue  # ほどく一言は飛ばして、その前の本文を見る
            return self.info(text)[3]
        return frozenset()

    def prev_has(self, state, name):
        """v8.4.6（010）：直前に出た本文に、その仕草・調子の型があるか（条件 flow.prev.<名前>）。"""
        return name in self.prev_moods(state)

    def prev_values(self, state):
        """v8.4.6（010）：条件 flow.prev.<名前> の値を、本文を選ぶ時点の最近の本文で。"""
        moods = self.prev_moods(state)
        return {"flow.prev." + name: name in moods for name in self.names()}

    @staticmethod
    def transparent(text):
        """前後の流れで数えない本文（触れ合いをほどく一言。v8.4.5）。"""
        return text["meaning"].startswith("system.contact_released")

    def receiver(self, text):
        """v8.4.6（010）：前の本文の気持ちを受けて書いた本文か（when に条件 flow.prev.<名前> がある）。合うときは、最近出ていない限り先に出す。
        v8.4.10：数えるのは「直前の本文にその型がある」（eq true、not の下でない）条件だけ。「せがんだ直後には出さない」（eq false）の本文は受ける本文ではない。"""
        found = self._receivers.get(text["id"])
        if found is None:
            found = self._receivers[text["id"]] = _receives(text["when"])
        return found

    def info(self, text):
        """本文の仕草の型の集合、型ごとの最後に出る位置、「〜たまま」の型の集合、仕草と調子の型の集合（本文の id ごとに覚える）。"""
        found = self._cache.get(text["id"])
        if found is None:
            body = text["body"]
            last = {}
            for key, rx in self.tags.items():
                for match in rx.finditer(body):
                    last[key] = match.start()
            keeps = frozenset(key for key, (rx, _, _) in self.keep.items() if rx.search(body))
            moods = frozenset(last) | frozenset(key for key, rx in self.moods.items() if rx.search(body))
            found = self._cache[text["id"]] = (frozenset(last), last, keeps, moods)
        return found

    def score(self, previous, text):
        """previous：直前に出た本文（新しい順）。点が小さいほど流れに合う。"""
        if not previous:
            return 0
        tags, _, keeps, moods = self.info(text)
        points = 0
        for index, prev in enumerate(previous):
            points += len(tags & self.info(prev)[0]) * (self.weights["last"] if index == 0 else self.weights["earlier"])
        _, last, _, before = self.info(previous[0])
        for key in keeps:
            _, against, along = self.keep[key]
            if against in last and last[against] > last.get(along, -1):
                points += self.weights["contradict"]
        points += sum(self.weights["follow"] for first, then in self.follow if first in before and then in moods)
        return points
