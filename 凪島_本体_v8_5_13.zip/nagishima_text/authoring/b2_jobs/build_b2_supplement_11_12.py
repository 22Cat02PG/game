"""第11陣・第12陣の補充（2026-09-28、v8.2.15）：採用が3本に届かなかった job を、元の job の state のまま書き足してもらう。

- 対象：grok_b2_wave_11・x10・12・x11 の job のうち、tools/stage_b/b2_texts.json の採用が 0〜2本の job（同じ job id のまま。返事は b2import の parse で続けて番号を振る）。
- 第9・10陣の job で2本のまま残ったもの（補充を2回頼んでも写しが多かった）は頼まない（Opus の本文がある）。
- 不採用の多くは写し（同じ番号の台詞あり・なし、速さの4つの job のあいだ）だったので、採用済みの本文を「すでにある本文」として見せ、重ねないよう頼む。
出力：grok依頼_B2_第11・12陣_補充/B2_補充11_12_XX.txt、第11・12陣_補充_一覧.json
"""
import collections
import json
import sys
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path(sys.argv[1]) if len(sys.argv) > 1 else OUT.parents[1]  # 本体の木（既定は authoring/b2_jobs の2つ上）
JOBS = ROOT / "authoring/b2_jobs"
PROMPT = (JOBS / "grokプロンプト_v3_0.txt").read_text(encoding="utf-8")
jobs = {}
for name in ("11", "x10", "12", "x11"):
    for row in json.loads((JOBS / f"grok_b2_wave_{name}.json").read_text(encoding="utf-8")):
        jobs[row["id"]] = row
adopted = collections.defaultdict(list)
for text in json.loads((ROOT / "tools/stage_b/b2_texts.json").read_text(encoding="utf-8")):
    if text["job_id"] in jobs:
        adopted[text["job_id"]].append(text["body"])
short = [j for j in jobs if len(adopted[j]) < 3]
NOTE = ("\n\nこの依頼は、前に書いてもらった job の書き足し（補充）です。どの job も、採用できた本文が少なかったものです。"
        "不採用の多くは次のどれかでした：台詞なしの本文が、台詞ありの本文から台詞を抜いただけになっている／"
        "速さの4つの job（….pace_fast・….pace_slow・…_fast.continue・…_slow.continue）で同じ文の並びを使い回している／"
        "前の速さを決める書き方（「激しかった腰を」「緩やかだったリズムを」）／限界の本文で、真帆がすでに動いていたと決める書き方／"
        "背を向けた体位で真帆の顔・唇・目が見える／こちらが腰を使ったと読める（真帆に動いてもらう本文で動くのは真帆だけ）。"
        "各 job の「すでにある本文」は採用済みの本文です。書き出し・結び・台詞・文の並びを、これとも、同じファイルのほかの本文とも重ねないでください。"
        "濃い本文（id が x10. x11. で始まる job）は、標準より露骨に書いてください。この job に限り、部位の語と記号は地の文で1本に4つまで（同じ語・記号は2回まで）、擬音も使ってよいです。"
        "\nそれ以外の規則（台詞の数、慣れの段階の語、地の文で器官を名前で呼ばず記号を使う、記号を台詞に書かない、妊娠・避妊に触れない、must_not）は同じです。")
folder = OUT / "grok依頼_B2_第11・12陣_補充"
folder.mkdir(exist_ok=True)
for old in folder.glob("*.txt"):
    old.unlink()
rows = [dict(jobs[j], candidates=4 if len(adopted[j]) else 5) for j in short]
names, size = [], 11
for number, index in enumerate(range(0, len(rows), size), 1):
    chunk = rows[index:index + size]
    lines = [json.dumps({"id": r["id"], "meaning": r["meaning"], "speech": r["speech"], "length": r["length"], "origin": r["origin"], "本数": r["candidates"],
                         "must_not": r["must_not"], "state": r["state"], "すでにある本文": adopted[r["id"]]}, ensure_ascii=False) for r in chunk]
    body = ("指示\n"
            f"次の{len(chunk)}件の job を書いてください（段階Bの2版目・第11陣と第12陣の補充）。本数は各 job の「本数」のとおりです（合わせて{sum(r['candidates'] for r in chunk)}本）。"
            "speech が true の job は真帆の台詞がちょうど1つ、false の job は台詞なしです。出力の id は job の id のあとに .v1 から番号を振ってください（取り込むときに振り直します）。"
            "途中で切れそうなら、job の区切りで止めてください。「続けて」と言われたら、止めた job の次から出してください。"
            + NOTE + "\n\n[\n  " + ",\n  ".join(lines) + "\n]\n\n" "プロンプト\n" + PROMPT)
    name = f"B2_補充11_12_{number:02d}.txt"
    (folder / name).write_text(body, encoding="utf-8")
    names.append(name)
listing = {"files": names, "jobs": {r["id"]: {"採用済み": len(adopted[r["id"]]), "本数": r["candidates"]} for r in rows},
           "本数": sum(r["candidates"] for r in rows)}
(OUT / "第11・12陣_補充_一覧.json").write_text(json.dumps(listing, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
print(len(rows), "jobs", listing["本数"], "texts", names)
