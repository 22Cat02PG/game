"""Validated, optional Stage A2 life rules."""

from .codec import exact
from .errors import GameError, ensure
from .progression import parse_time


def _exact(value, keys, optional=()):
    try:
        exact(value, keys, list(optional))
    except GameError as error:
        raise GameError("life_data", "life.json の項目が不足または未登録。") from error


def _time(value):
    try:
        return parse_time(value)
    except GameError as error:
        raise GameError("life_data", "life.json の時刻が不正。") from error


def _integer(value, low, high):
    ensure(type(value) is int and low <= value <= high, "life_data", "life.json の整数が範囲外。")
    return value


def bath_after(state, life):
    """009（v8.2.0）：湯上がりの間か。"""
    bath = state.get("bath")
    return bool(life is not None and life.bath and bath and bath["after_until"] is not None and state["world"]["now"] < bath["after_until"])


def bath_level_bonus(state, life):
    """湯上がりの間、真帆の誘いと深める触れ合いの反応で、欲求の水準を見るときに足す値。"""
    return life.bath["level_bonus"] if bath_after(state, life) else 0


class LifeRules:
    def __init__(self, raw, catalog, meanings, progression):
        ensure(progression is not None, "life_data", "life.json には progression.json が必要。")
        _exact(raw, ["format", "offers", "drinks", "speech", "familiarity", "work"], ["actions", "lunch", "meals", "bath", "town", "fishing", "holiday_lunch"])
        ensure(raw["format"] == "nagishima.life/1", "life_data", "life.json の形式名が不正。")
        offers = raw["offers"]
        _exact(offers, ["once_per_day", "shared_by_time"], ["not_in_rain"])
        groups = {goal["group"] for goal in catalog["goals"].values()}
        once = offers["once_per_day"]
        ensure(type(once) is list and all(type(x) is str for x in once) and len(set(once)) == len(once) and set(once) <= groups, "life_data", "誘いの group が不正。")
        self.once_per_day = frozenset(once)
        # v8.2.26（ユーザー了承 2026-09-30、精査 B-08）：雨の日には誘わない活動（散歩。誘いの本文は「今の海、きれい」）
        rain = offers.get("not_in_rain", [])
        ensure(type(rain) is list and all(type(x) is str for x in rain) and set(rain) <= set(catalog["activities"]), "life_data", "雨の日に誘わない活動が不正。")
        self.not_in_rain = frozenset(rain)
        activities = set(catalog["activities"]) - {"private_time", "town_trip", "install"}
        rows = offers["shared_by_time"]
        ensure(type(rows) is list and rows, "life_data", "誘いの時間帯がない。")
        self.shared_by_time = []
        for row in rows:
            _exact(row, ["from", "to", "activities"])
            start, end = _time(row["from"]), _time(row["to"])
            names = row["activities"]
            ensure(start <= end and type(names) is list and names and all(type(x) is str for x in names) and len(set(names)) == len(names) and set(names) <= activities, "life_data", "誘いの時間帯または活動が不正。")
            self.shared_by_time.append((start, end, tuple(names)))
        intervals = sorted((start, end) for start, end, _ in self.shared_by_time)
        cursor = 301
        for start, end in intervals:
            ensure(start == cursor, "life_data", "誘いの時間帯に重複または空白がある。")
            cursor = end + 1
        ensure(cursor == 1741, "life_data", "誘いの時間帯が生活日を覆わない。")
        drinks = raw["drinks"]
        _exact(drinks, ["activities", "per_day", "min_interval_minutes"])
        names = drinks["activities"]
        ensure(type(names) is list and all(type(x) is str for x in names) and len(set(names)) == len(names) and set(names) <= activities, "life_data", "飲み物の活動が不正。")
        self.drink_activities = frozenset(names)
        self.drinks_per_day = _integer(drinks["per_day"], 1, 20)
        self.drink_interval = _integer(drinks["min_interval_minutes"], 0, 720)
        speech = raw["speech"]
        _exact(speech, ["spacing"])
        spacing = speech["spacing"]
        ensure(type(spacing) is dict and set(spacing) <= {"start", "repeat", "heated", "continue", "settled"}, "life_data", "台詞間隔の種類が不正。")
        self.spacing = {name: _integer(value, 0, 10) for name, value in spacing.items()}
        familiarity = raw["familiarity"]
        _exact(familiarity, ["few_from", "familiar_from"])
        self.few_from = _integer(familiarity["few_from"], 2, 1000)
        self.familiar_from = _integer(familiarity["familiar_from"], self.few_from, 1000)
        actions = raw.get("actions", {"minutes": {}, "hands_free": []})
        _exact(actions, ["minutes", "hands_free"], ["contact_stops"])
        minutes = actions["minutes"]
        ensure(type(minutes) is dict and set(minutes) <= {"talk", "touch", "continue", "listen"}, "life_data", "行動の所要分の種類が不正。")
        self.action_minutes = {name: _integer(value, 0, 30) for name, value in minutes.items()}
        hands_free = actions["hands_free"]
        ensure(type(hands_free) is list and all(type(x) is str for x in hands_free) and set(hands_free) <= activities, "life_data", "触れ合いを止める活動が不正。")
        self.hands_free_activities = frozenset(hands_free)
        # v8.4.3（010）：始めるときに、決めた触れ合いだけを終える活動（散歩：両手をつないだままでは歩けない）。ない版は終えない（009）
        stops = actions.get("contact_stops", {})
        ensure(type(stops) is dict and set(stops) <= activities and all(type(v) is list and v and all(type(x) is str for x in v) for v in stops.values()),
               "life_data", "始めるときに終える触れ合いが不正。")
        self.contact_stops = {name: frozenset(keys) for name, keys in stops.items()}
        lunch = raw.get("lunch")
        self.lunch = None
        if lunch is not None:
            _exact(lunch, ["after_block", "minutes"])
            ensure(type(lunch["after_block"]) is str, "life_data", "昼食の勤務ブロックが不正。")
            self.lunch = {"after_block": lunch["after_block"], "minutes": _integer(lunch["minutes"], 1, 60)}
        meals = raw.get("meals")
        self.meals = None
        if meals is not None:
            # 009（v8.1.0）：朝食は目覚めた後、夕食は決まった時間帯の最初の空いた時に、二人で自動で取る（3回目の試運転の指摘4）
            _exact(meals, ["breakfast", "dinner"], ["manual_before_minutes", "gap_minutes"])
            _exact(meals["breakfast"], ["minutes", "after"])
            _exact(meals["dinner"], ["from", "until", "minutes", "after"])
            for row in (meals["breakfast"], meals["dinner"]):
                ensure(row["after"] in catalog["locations"] and row["after"] != "town", "life_data", "食後の場所が不正。")
            dinner_from, dinner_until = _time(meals["dinner"]["from"]), _time(meals["dinner"]["until"])
            ensure(dinner_from < dinner_until, "life_data", "夕食の時間帯が不正。")
            ensure({"life.breakfast", "life.dinner"} <= meanings, "life_data", "食事の本文がない。")
            self.meals = {"breakfast": {"minutes": _integer(meals["breakfast"]["minutes"], 1, 60), "after": meals["breakfast"]["after"]},
                          "dinner": {"from": dinner_from, "until": dinner_until, "minutes": _integer(meals["dinner"]["minutes"], 1, 90), "after": meals["dinner"]["after"]},
                          # v8.2.25（指摘 R2）：時間帯の何分前から、手動の「食事をする」をその食事として数えるか
                          "manual_before": _integer(meals.get("manual_before_minutes", 0), 0, 180),
                          # v8.2.26：どの食事のあとも、何分は「食事をする」を選べないか（0 なら v8.2.25 までと同じく食事の時間帯で見る）
                          "gap": _integer(meals.get("gap_minutes", 0), 0, 360)}
        self.bath = self._bath(raw.get("bath"), catalog, meanings)
        # 段階C（010、v8.5.11）：島の町（喫茶店・売店）・釣り・休日の昼の支度。009 にはない（仕様 第21節）
        self.town = self._town(raw.get("town"), catalog, meanings)
        self.fishing = self._fishing(raw.get("fishing"), catalog, meanings)
        self.holiday_lunch = None
        if raw.get("holiday_lunch") is not None:
            row = raw["holiday_lunch"]
            _exact(row, ["from", "until"])
            start, until = _time(row["from"]), _time(row["until"])
            ensure(start < until and self.meals is not None, "life_data", "休日の昼の支度の時間帯が不正。")
            ensure("life.lunch.holiday" in meanings, "life_data", "休日の昼食の本文がない。")
            self.holiday_lunch = {"from": start, "until": until}
        work = raw["work"]
        _exact(work, ["weekdays", "go_ahead_minutes", "blocks", "events"])
        weekdays = work["weekdays"]
        ensure(type(weekdays) is list and all(type(x) is int and 0 <= x <= 6 for x in weekdays) and weekdays == sorted(set(weekdays)), "life_data", "勤務日が不正。")
        self.weekdays = frozenset(weekdays)
        self.go_ahead = _integer(work["go_ahead_minutes"], 0, 180)
        blocks = work["blocks"]
        ensure(type(blocks) is list and blocks, "life_data", "勤務ブロックがない。")
        self.blocks = []
        end_previous = -1
        for block in blocks:
            _exact(block, ["id", "start", "end", "after"])
            start, end = _time(block["start"]), _time(block["end"])
            ensure(type(block["id"]) is str and block["id"] and start < end and start >= end_previous and type(block["after"]) is str and block["after"] in catalog["locations"] and block["after"] != "town", "life_data", "勤務ブロックが不正。")
            self.blocks.append({**block, "start_minute": start, "end_minute": end})
            end_previous = end
        ensure(len({x["id"] for x in self.blocks}) == len(self.blocks), "life_data", "勤務ブロックIDが重複。")
        ensure(self.lunch is None or self.lunch["after_block"] in {x["id"] for x in self.blocks}, "life_data", "昼食の勤務ブロックが未登録。")
        events = work["events"]
        _exact(events, ["fixed", "random"])
        fixed = events["fixed"]
        ensure(type(fixed) is list, "life_data", "固定イベントが不正。")
        self.fixed = {}
        for event in fixed:
            _exact(event, ["id", "weekday", "block"])
            ensure(type(event["weekday"]) is int and event["weekday"] in self.weekdays and type(event["block"]) is str and event["block"] in {x["id"] for x in self.blocks} and type(event["id"]) is str, "life_data", "固定イベントが不正。")
            key = (event["weekday"], event["block"])
            ensure(key not in self.fixed, "life_data", "固定イベントが不正。")
            self.fixed[key] = event["id"]
        random = events["random"]
        _exact(random, ["ids", "chance_percent", "max_per_day"])
        ids = random["ids"]
        ensure(type(ids) is list and ids and all(type(x) is str for x in ids) and len(set(ids)) == len(ids), "life_data", "ランダムイベントIDが不正。")
        self.event_ids = tuple(ids)
        self.event_chance = _integer(random["chance_percent"], 0, 100)
        self.event_max = _integer(random["max_per_day"], 0, 3)
        ensure(all(type(x) is str and "work.event." + x in meanings for x in (*ids, *self.fixed.values())), "life_data", "仕事イベントの本文がない。")
        ensure(all("work.block." + x["id"] in meanings for x in self.blocks), "life_data", "勤務ブロックの本文がない。")

    @staticmethod
    def _bath(bath, catalog, meanings):
        """009（v8.2.0）：風呂。夜の決まった時間帯の最初の空いた時に自動で入り、湯上がりの間は真帆の欲求が上がりやすい（3回目の試運転の指摘4）。"""
        if bath is None:
            return None
        _exact(bath, ["from", "until", "invite_from", "minutes", "together_minutes", "after_minutes", "after", "desire_percent", "level_bonus", "together_desire", "invite"])
        start, until, invite_from = _time(bath["from"]), _time(bath["until"]), _time(bath["invite_from"])
        ensure(invite_from <= start < until, "life_data", "風呂の時間帯が不正。")
        ensure(bath["after"] in catalog["locations"] and bath["after"] != "town", "life_data", "風呂の後の場所が不正。")
        invite = bath["invite"]
        _exact(invite, ["show_stage", "accept_stage", "accept_history", "accept_level"])
        ensure(invite["accept_level"] in ("low", "invite", "press"), "life_data", "風呂の誘いの欲求の水準が不正。")
        ensure({"life.bath", "life.bath.together", "life.bath.invite.refuse", "life.bath.invite.shy", "life.bath.invite.deflect"} <= meanings, "life_data", "風呂の本文がない。")
        return {"from": start, "until": until, "invite_from": invite_from, "minutes": _integer(bath["minutes"], 5, 90),
                "together_minutes": _integer(bath["together_minutes"], 5, 120), "after_minutes": _integer(bath["after_minutes"], 0, 240),
                "after": bath["after"], "desire_percent": _integer(bath["desire_percent"], 100, 400), "level_bonus": _integer(bath["level_bonus"], 0, 100),
                "together_desire": _integer(bath["together_desire"], 0, 100),
                "invite": {"show_stage": _integer(invite["show_stage"], 0, 4), "accept_stage": _integer(invite["accept_stage"], 0, 4),
                           "accept_history": _integer(invite["accept_history"], 0, 1000), "accept_level": invite["accept_level"]}}

    @staticmethod
    def _town(town, catalog, meanings):
        """v8.5.11：島の町の店。places：店ごとの開く・閉まる時刻（時計の時刻）と、閉まったら戻る場所・分。
        order：取り寄せを頼める店・品・分（今ある注文の仕組みで、次の便で届く。お金ができたら、その場で買えるようにする）。regular_from：店の人に覚えられる、二人で来た回数。"""
        if town is None:
            return None
        _exact(town, ["places", "order", "regular_from"])
        places = {}
        ensure(type(town["places"]) is dict and town["places"], "life_data", "島の町の店がない。")
        for key, row in town["places"].items():
            _exact(row, ["open", "close", "home", "minutes"])
            ensure(key in catalog["locations"] and catalog["locations"][key]["group"] == "island", "life_data", "島の町の店の場所が未登録。")
            ensure(row["home"] in catalog["locations"] and catalog["locations"][row["home"]]["group"] == "residence", "life_data", "閉まったら戻る場所が不正。")
            opening, closing = _time(row["open"]), _time(row["close"])
            ensure(opening < closing, "life_data", "店の時刻が不正。")
            ensure("town.close." + key in meanings, "life_data", "店が閉まるときの本文がない。")
            places[key] = {"open": opening, "close": closing, "home": row["home"], "minutes": _integer(row["minutes"], 0, 60)}
        order = town["order"]
        _exact(order, ["place", "items", "minutes"])
        ensure(order["place"] in places and type(order["items"]) is list and order["items"] and set(order["items"]) <= set(catalog["items"]), "life_data", "取り寄せを頼める品が不正。")
        ensure(all("town.order." + k in meanings for k in order["items"]), "life_data", "取り寄せを頼む本文がない。")
        return {"places": places, "order": {"place": order["place"], "items": list(order["items"]), "minutes": _integer(order["minutes"], 0, 30)},
                "regular_from": _integer(town["regular_from"], 1, 100)}

    @staticmethod
    def _fishing(fishing, catalog, meanings):
        """v8.5.11：釣り。activity（活動の名前）、from・until（できる時刻。暮らしの日の分。until までに終わる釣りだけ始められる）、none（何も釣れない重み）、rarity（めずらしさの重み）、
        season_percent（その季節の種の重みの割合）、species（種：名前・めずらしさ・時間帯・季節・夕食に出るか）。"""
        if fishing is None:
            return None
        _exact(fishing, ["activity", "from", "until", "none", "rarity", "season_percent", "species"])
        ensure(fishing["activity"] in catalog["activities"], "life_data", "釣りの活動が未登録。")
        start, until = _time(fishing["from"]), _time(fishing["until"])
        ensure(start < until, "life_data", "釣りの時刻が不正。")
        rarity = fishing["rarity"]
        ensure(type(rarity) is dict and rarity and all(type(v) is int and 1 <= v <= 1000 for v in rarity.values()), "life_data", "釣りのめずらしさの重みが不正。")
        species = {}
        ensure(type(fishing["species"]) is dict and 1 <= len(fishing["species"]) <= 40, "life_data", "釣りの種が不正。")
        slots, seasons = {"morning", "noon", "evening", "night"}, {"spring", "summer", "autumn", "winter"}
        for key, row in fishing["species"].items():
            _exact(row, ["label", "rarity", "slots", "seasons", "dinner"], ["weathers"])
            ensure(type(key) is str and key.isascii() and key.replace("_", "").isalnum() and type(row["label"]) is str and 1 <= len(row["label"]) <= 12, "life_data", "釣りの種の名前が不正。")
            ensure(row["rarity"] in rarity and type(row["slots"]) is list and row["slots"] and set(row["slots"]) <= slots
                   and type(row["seasons"]) is list and set(row["seasons"]) <= seasons and type(row["dinner"]) is bool, "life_data", "釣りの種の決まりが不正。")
            ensure(not row["dinner"] or "fish.dinner." + key in meanings, "life_data", "釣った魚の夕食の本文がない。")
            weathers = row.get("weathers", ["clear", "cloudy", "rain"])  # 釣れる天気（書かなければいつでも）
            ensure(type(weathers) is list and weathers and set(weathers) <= {"clear", "cloudy", "rain"}, "life_data", "釣れる天気が不正。")
            species[key] = {"label": row["label"], "rarity": row["rarity"], "slots": tuple(row["slots"]), "seasons": tuple(row["seasons"]), "dinner": row["dinner"], "weathers": tuple(weathers)}
        # 釣果の本文は、釣りの場面の終わり（activity.<活動>.end）を fish.last・fish.new の条件で書き分ける（場面の効果の中で出した本文は、場面の終わりの本文に置き換わるため）
        ensure({"fish.book", "activity." + fishing["activity"] + ".end"} <= meanings, "life_data", "釣りの本文がない。")
        return {"activity": fishing["activity"], "from": start, "until": until, "none": _integer(fishing["none"], 0, 1000), "rarity": dict(rarity),
                "season_percent": _integer(fishing["season_percent"], 100, 1000), "species": species}

