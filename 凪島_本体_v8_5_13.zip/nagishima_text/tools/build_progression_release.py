"""Build interaction_007 (stage A: progression rules) from interaction_006.

The source release is read only.  The target is written once; rebuilding an
unpublished target needs --replace-unpublished.
"""
import argparse
import json
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from nagishima import RULES_VERSION  # noqa: E402
from nagishima.codec import bytes_digest, digest  # noqa: E402
from nagishima.content import FILES, PROGRESSION, Pack  # noqa: E402

SOURCE, TARGET = "interaction_006", "interaction_007"
RELEASES = ROOT / "content" / "releases"
PUBLISHED = {f"interaction_{n:03d}" for n in range(3, 9)}  # 公開済み（v8.0.5、監査 A-03）

PROGRESSION_DATA = {
    "format": "nagishima.progression/1",
    "affinity": {
        "max": 100,
        "daily_cap": 10,
        "display": False,
        "talk_actions": ["talk", "check_mood", "share_day", "gratitude", "compliment", "together_words", "reassurance", "affection"],
        "touch_actions": ["head", "hands", "hair", "cheek", "shoulder", "arm", "back", "forehead", "hug", "waist", "kiss"],
        "sources": {
            "activity_completed": {"amount": 3, "per_day": 2},
            "promise_fulfilled": {"amount": 2, "per_day": 1},
            "story_completed": {"amount": 3, "per_day": 1},
            "talk": {"amount": 1, "per_day": 3},
            "touch": {"amount": 1, "per_day": 3},
            "offer_accepted": {"amount": 1, "per_day": 2},
            "private_completed": {"amount": 2, "per_day": 1},
        },
    },
    "milestones": [
        {"stage": 1, "min_affinity": 5, "min_days": 0},
        {"stage": 2, "min_affinity": 15, "min_days": 1},
        {"stage": 3, "min_affinity": 35, "min_days": 2},
        {"stage": 4, "min_affinity": 60, "min_days": 3},
    ],
    "desire": {
        "max": 100,
        "min_stage": 3,
        "invite": 60,
        "press": 90,
        "touch_start": {"head": 2, "hands": 2, "hair": 2, "cheek": 2, "shoulder": 2, "arm": 2, "back": 2, "forehead": 3, "hug": 5, "waist": 5, "kiss": 5},
        "touch_continue": 1,
        "talk": {"affection": 2, "compliment": 2},
        "sleep_change": -20,
        "set_after_private": 0,
    },
    "maho_sleep": {
        "bedtime": "23:30",
        "doze": {"chance_percent": 40, "start_from": "21:00", "start_to": "22:30", "step_minutes": 15, "duration_minutes": [30, 45, 60]},
    },
    "life_after_stage4": True,
}

# Provisional prose written by Claude Opus 5.5 (spec section 14).  No review record exists.
PROVISIONAL_TEXTS = {
    "maho.dozed_off": "真帆のまぶたが、ゆっくり下りていく。しばらくすると、静かな寝息が聞こえはじめた。",
    "maho.woke": "真帆が小さく身じろぎして、目を開けた。少しのあいだ、ぼんやりとあたりを見ている。",
    "maho.woken": "声をかけると、真帆はまばたきをして目を覚ました。",
    "maho.went_to_bed": "真帆は小さくあくびをすると、軽く会釈して自分の部屋へ引き上げていった。",
    "system.life_continues": "二人で決めたこれからの暮らしが、明日からも続いていく。",
}


def dump(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--replace-unpublished", action="store_true", help="作り直す（未公開の007に限る）")
    args = parser.parse_args()
    source, target = RELEASES / SOURCE, RELEASES / TARGET
    Pack(source)  # verify the source before copying
    if target.exists() and (target / "release.json").is_file() and TARGET in PUBLISHED:
        raise SystemExit(f"{TARGET} は公開済み。作り直さない（v8.0.5、監査 A-03）。")
    if target.exists():
        if not args.replace_unpublished:
            raise SystemExit(f"{TARGET} は既にある。公開済みなら上書きしない。未公開の作り直しは --replace-unpublished を付ける。")
        shutil.rmtree(target)
    target.mkdir()
    for name in ("catalog.json", "actions.json", "scenes.json", "revision_provenance.json"):
        shutil.copyfile(source / name, target / name)
    meanings = json.loads((source / "meanings.json").read_text(encoding="utf-8"))
    texts = json.loads((source / "texts.json").read_text(encoding="utf-8"))
    for meaning, body in PROVISIONAL_TEXTS.items():
        assert meaning not in meanings, meaning
        meanings.append(meaning)
        texts.append({"id": meaning + ".base", "meaning": meaning, "when": {"all": []}, "slots": [], "group": meaning + ".base", "body": body, "fallback": True})
    dump(target / "meanings.json", sorted(meanings))
    dump(target / "texts.json", texts)
    dump(target / PROGRESSION, PROGRESSION_DATA)
    catalog = json.loads((target / "catalog.json").read_text(encoding="utf-8"))
    actions = json.loads((target / "actions.json").read_text(encoding="utf-8"))
    names = FILES + (PROGRESSION,)
    dump(target / "release.json", {
        "id": TARGET, "rules_version": RULES_VERSION,
        "files": {name: bytes_digest((target / name).read_bytes()) for name in names},
        "control_sha256": digest({"catalog": catalog, "actions": actions, "progression": PROGRESSION_DATA}),
    })
    dump(target / "rules_provenance.json", {
        "source_release": SOURCE, "rules_version": RULES_VERSION,
        "change": "段階A：progression.json（親密度・欲求・真帆の眠り・日数による進行・段階4の後の継続）を追加。",
        "text_content": "interaction_006 の本文871本と同一。新しい meaning 5件に仮本文を1本ずつ追加。",
        "provisional_texts": {"author": "Claude Opus 5.5", "reviewed": False, "note": "仮本文。検品記録なし。原稿 job で差し替え予定。", "text_ids": [m + ".base" for m in PROVISIONAL_TEXTS]},
    })
    pack = Pack(target)
    print(f"{TARGET}: meanings {len(pack.meanings)}, texts {len(pack.texts)}, control {pack.control_hash[:12]}")


if __name__ == "__main__":
    main()
