"""段階C（010、v8.5.7）：主人公のうたた寝と、真帆の「襲い返し」（仕様 docs/凪島_段階C_仕様_2026-10-08.md の第5.3節）。決まりは intimacy.json の nap 節。
- 夕方〜夜、居間で真帆と一緒のとき「少し眠る」（minutes 分。暮らしの日に1回）。そのあいだに真帆がしたことを、目を覚ましたときの本文で知る（反応の表：上から、最後はいつも当たる）。
  恋人なら、欲求・親密度に応じて唇に口づける・肩にもたれる・頬に口づける。そうでなければ毛布をかけてくれる。
- pull にある反応のあとは、そのすぐあと（時間が進む前）だけ「真帆を引き寄せる」「気づかないふりをする」を選べる（state の nap に、目を覚ました時刻と反応を残す）。
  引き寄せると欲求が pull_desire だけ上がる（いつもの時間の誘いにつながる）。"""
from .conditions import evaluate
from .errors import GameError, ensure
from .intimacy_rules import check, number, time
from .progression import change_desire, day_time, life_day

ALWAYS = {"all": []}


class NapRules:
    def __init__(self, raw):
        check(raw, ["_note", "label", "from", "until", "minutes", "places", "order", "pull", "pull_desire", "labels"])
        ensure(type(raw["label"]) is str and 1 <= len(raw["label"]) <= 40, "intimacy_data", "うたた寝の選択肢の名前が不正。")
        self.label = raw["label"]
        self.start, self.until = time(raw["from"]), time(raw["until"])
        ensure(self.start < self.until, "intimacy_data", "うたた寝の時間帯が不正。")
        self.minutes = number(raw["minutes"], 5, 60)
        ensure(type(raw["places"]) is list and raw["places"] and all(type(v) is str for v in raw["places"]), "intimacy_data", "うたた寝の場所が不正。")
        self.places = raw["places"]
        ensure(type(raw["order"]) is list and raw["order"] and all(type(r) is dict and set(r) == {"id", "when"} and type(r["id"]) is str for r in raw["order"]),
               "intimacy_data", "うたた寝の反応の表が不正。")
        ensure(raw["order"][-1]["when"] == ALWAYS, "intimacy_data", "うたた寝の反応の表の最後は、いつも当たる行にする。")
        self.order = raw["order"]
        self.reactions = list(dict.fromkeys(r["id"] for r in self.order))
        ensure(type(raw["pull"]) is list and set(raw["pull"]) <= set(self.reactions), "intimacy_data", "引き寄せられる反応が未登録。")
        self.pull = frozenset(raw["pull"])
        self.pull_desire = number(raw["pull_desire"], 0, 100)
        check(raw["labels"], ["pull", "ignore"])
        ensure(all(type(v) is str and 1 <= len(v) <= 40 for v in raw["labels"].values()), "intimacy_data", "うたた寝の選択肢の名前が不正。")
        self.labels = raw["labels"]

    def meanings(self):
        return ["nap." + r for r in self.reactions] + ["nap.pull." + r for r in self.reactions if r in self.pull] + ["nap.ignore." + r for r in self.reactions if r in self.pull]

    def check_content(self, fields, meanings, validate_condition):
        for when in [r["when"] for r in self.order] + [{"field": "actor.player.location", "op": "in", "value": self.places}]:
            validate_condition(when, fields)
        missing = [m for m in self.meanings() if m not in meanings]
        ensure(not missing, "meaning", "うたた寝の本文の意味が未登録：" + "、".join(missing[:5]))


def nap_blocked(state, pack):
    """少し眠れない理由（code, 文）。眠れるなら None。メニューと操作で同じ判定を使う。"""
    rules = pack.intimacy.nap
    player, maho = state["actors"]["player"], state["actors"]["maho"]
    if state["mode"] != "normal" or state.get("co_sleep") or state.get("sleep_play") or state.get("event_play") or state["maho_sleep"]["state"] != "awake":
        return "nap", "今は眠れない。"
    if player["location"] not in rules.places or maho["location"] != player["location"]:
        return "location", "居間で、真帆と一緒のときに。"
    if not rules.start <= day_time(state["world"]["now"]) < rules.until:
        return "event_time", "今は眠る時間ではない。"
    if any(x["group"] == "event_nap" and x["day"] == life_day(state["world"]["now"]) for x in state["cooldowns"]):
        return "event_time", "今日はもう少し眠った。"
    return None


def pull_open(state, pack):
    """目を覚ました直後（時間が進む前）で、真帆がまだ一緒にいて起きているときだけ、引き寄せる・気づかないふりを選べる。"""
    nap = state.get("nap")
    return bool(nap and nap["at"] == state["world"]["now"] and nap["id"] in pack.intimacy.nap.pull and state["maho_sleep"]["state"] == "awake"
                and state["actors"]["maho"]["location"] == state["actors"]["player"]["location"] and state["mode"] == "normal" and not state["offer"] and not state["scene"])


class Nap:
    @property
    def napr(self):
        rules = self.pack.intimacy.nap if self.pack.intimacy else None
        ensure(rules is not None, "nap", "この原稿版にうたた寝は登録されていない。")
        return rules

    def nap(self):
        rules = self.napr
        self.free()
        self.require_awake()
        blocked = nap_blocked(self.s, self.pack)
        if blocked:
            raise GameError(*blocked)
        self.record_offer("event_nap")
        reaction = next(r["id"] for r in rules.order if evaluate(r["when"], self.pack.registry.values(self.s)) is True)  # 眠る前の様子で決める
        self.s["contacts"] = []
        self.s["interaction_streak"] = None
        self.require_time(rules.minutes)
        self.advance(rules.minutes)
        self.emit("nap." + reaction)
        self.s["nap"] = {"at": self.now, "id": reaction}

    def nap_answer(self, pull):
        rules = self.napr
        ensure(pull_open(self.s, self.pack), "nap", "今は選べない。")
        reaction = self.s["nap"]["id"]
        self.s["nap"] = None
        if pull:
            self.emit("nap.pull." + reaction)
            if self.pack.progression and rules.pull_desire:
                change_desire(self.s, self.pack.progression, rules.pull_desire)
        else:
            self.emit("nap.ignore." + reaction)
