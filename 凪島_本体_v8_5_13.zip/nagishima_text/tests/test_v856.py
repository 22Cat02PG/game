"""v8.5.6（ユーザー 2026-10-08「進めろ。次があるだろ」）：010 だけ。段階C 七歩目：添い寝（仕様 第6.1節）。"""
import unittest
from pathlib import Path

from nagishima.content import Pack
from nagishima.progression import life_day
from tools.run_stage_b_routes import Route

ROOT = Path(__file__).resolve().parents[1]
P009 = Pack(ROOT / "content/releases/interaction_009")
P010 = Pack(ROOT / "content/releases/interaction_010")


def night_route(affinity=80, desire=30, hour=21, minute=30, day_offset=2):
    """21:30 の居間（day_offset=2 は金曜＝休日前の夜、0 は水曜＝翌日は仕事）。"""
    route = Route(8, hour=hour, minute=minute, tier="familiar", release="interaction_010", day_offset=day_offset)
    state = route.engine._state
    state["affinity"]["value"], state["desire"] = affinity, desire
    route.engine._install_choices()
    return route


def meanings(view):
    return [b["meaning"] for b in view["blocks"]]


def ids(view):
    return [c["id"] for c in view["choices"]]


class V856(unittest.TestCase):
    def test_rules(self):
        self.assertIsNone(P009.intimacy.co_sleep)
        rules = P010.intimacy.co_sleep
        self.assertEqual((rules.start, rules.min_stage), (1260, 3))
        self.assertEqual(rules.accept, {"accept_sweet", "accept_shy"})
        sleep = P010.intimacy.sleep_play
        self.assertAlmostEqual(sleep.kind_factor["cosleep"], sleep.kind_factor["asleep"] * 1.2)
        self.assertEqual({k for k, row in sleep.reactions.items() if row.get("cosleep") == "stay"}, {"flustered", "soft_decline", "stop"})
        for meaning in rules.meanings() + ["sp.begin.cosleep", "sp.leave.cosleep"]:
            self.assertIn(meaning, P010.meanings)
        self.assertIn("cosleep.phase", P010.registry.fields)

    def test_invite_window(self):
        """21:00 から（真帆が起きていて、一緒のとき）。それより前は出ない。"""
        route = night_route(hour=20, minute=30)
        self.assertNotIn("cosleep.invite", ids(route.engine.get_view()))
        route.close()
        route = night_route()
        self.assertIn("cosleep.invite", ids(route.engine.get_view()))
        route.close()

    def test_accept_talk_sleep(self):
        """受け入れる → 真帆の部屋で並んで横になる → 話す → 真帆が眠る → 寝顔を見る → このまま眠る（添い寝した朝の一言）。"""
        route = night_route()
        view = route.choose("cosleep.invite")
        self.assertEqual(meanings(view)[-1], "cs.accept.accept_shy")
        self.assertEqual(view["page_title"], "真帆の部屋（添い寝）")
        state = route.engine.snapshot()
        self.assertEqual(state["co_sleep"]["phase"], "talk")
        self.assertEqual((state["actors"]["player"]["location"], state["actors"]["maho"]["location"]), ("maho_room", "maho_room"))
        self.assertEqual(ids(view), ["cosleep.talk", "cosleep.close_eyes"])
        view = route.choose("cosleep.talk")
        self.assertEqual(meanings(view)[-2:], ["cs.talk", "cs.asleep"])  # 受け入れて10分＋話して5分＝15分で眠る
        self.assertEqual(route.engine.snapshot()["maho_sleep"]["state"], "asleep")
        self.assertEqual(ids(view), ["sleep", "cosleep.look", "sleep.begin"])
        self.assertIn("cs.look", meanings(route.choose("cosleep.look")))
        view = route.choose("sleep")
        got = meanings(view)
        self.assertIn("cs.morning", got)
        self.assertNotIn("system.slept", got)
        state = route.engine.snapshot()
        self.assertIsNone(state["co_sleep"])
        self.assertGreaterEqual(state["world"]["now"] % 1440, 450)
        route.close()

    def test_close_eyes_and_sweet(self):
        """欲求が高ければ甘えて受け入れる。目を閉じると、すぐ真帆が眠るまで待つ。"""
        route = night_route(desire=95)
        self.assertEqual(meanings(route.choose("cosleep.invite"))[-1], "cs.accept.accept_sweet")
        view = route.choose("cosleep.close_eyes")
        self.assertEqual(meanings(view)[-1], "cs.asleep")
        self.assertEqual(route.engine.snapshot()["co_sleep"]["phase"], "asleep")
        route.close()

    def test_declines(self):
        """断る：警戒の間（このあいだのこと）／翌日が仕事（明日早い）／それ以外（今夜はひとりで）。その夜はもう誘えない。"""
        route = night_route(affinity=40, desire=0, day_offset=0)
        view = route.choose("cosleep.invite")
        self.assertIn("cs.decline.decline_tired", meanings(view))
        self.assertNotIn("co_sleep", {k for k, v in route.engine.snapshot().items() if v})
        self.assertNotIn("cosleep.invite", ids(view))
        route.close()
        route = night_route(affinity=40, desire=0)
        self.assertIn("cs.decline.decline", meanings(route.choose("cosleep.invite")))
        route.close()
        route = night_route()
        state = route.engine._state
        state.setdefault("sleep_record", {"accepted": 0, "habits": {}, "cooling": None, "night": None, "apologized_day": None})
        state["sleep_record"]["cooling"] = {"kind": "angry", "until": life_day(state["world"]["now"]) + 2}
        route.engine._install_choices()
        self.assertIn("cs.decline.decline_upset", meanings(route.choose("cosleep.invite")))
        route.close()

    def test_touch_in_cosleep(self):
        """眠っている真帆に触れる（種類 cosleep）。離れたら添い寝に戻る。目を覚ましたら、反応の cosleep で並んで眠るか自分の部屋へ戻る。"""
        route = night_route()
        route.choose("cosleep.invite")
        route.choose("cosleep.close_eyes")
        view = route.choose("sleep.begin")
        self.assertEqual(meanings(view)[-1], "sp.begin.cosleep")
        self.assertEqual(route.engine.snapshot()["sleep_play"]["kind"], "cosleep")
        view = route.choose("sleep.sp_leave")
        self.assertEqual(meanings(view)[-1], "sp.leave.cosleep")
        state = route.engine.snapshot()
        self.assertEqual((state["co_sleep"]["phase"], state["actors"]["player"]["location"]), ("asleep", "maho_room"))
        route.choose("sleep.begin")
        route.engine._state["sleep_play"]["gauges"]["wake"] = 99
        route.engine._install_choices()
        view = route.choose("sleep.sp_cheek")
        state = route.engine.snapshot()
        reaction = state["sleep_record"]["night"]["reaction"] if state["sleep_record"]["night"] else None
        if state["intimacy"] is not None or reaction is None:
            self.assertIsNone(state.get("co_sleep"))  # 受け入れて起きているエッチへ
        else:
            stay = P010.intimacy.sleep_play.reactions[reaction].get("cosleep") == "stay"
            self.assertEqual(bool(state.get("co_sleep")), stay, reaction)
            self.assertEqual(state["actors"]["player"]["location"], "maho_room" if stay else "player_room")
        route.close()

    def test_no_touch_on_drink_night(self):
        """お酒を飲んだ夜は、添い寝でも眠っている真帆に触れる手を出さない。"""
        route = night_route()
        route.choose("cosleep.invite")
        route.engine._state["drink_night"] = {"day": life_day(route.engine._state["world"]["now"]), "drunk": 1}
        route.engine._install_choices()
        view = route.choose("cosleep.close_eyes")
        self.assertEqual(ids(view), ["sleep", "cosleep.look"])
        route.close()


if __name__ == "__main__":
    unittest.main()
