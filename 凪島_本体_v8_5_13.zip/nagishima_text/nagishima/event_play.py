"""段階C（010、v8.5.1・v8.5.2）：たまに起きるイベントのエッチ（イベントの型）。浴室（一緒に風呂に入ったとき）と台所（夕食の支度の間）。
仕様は docs/凪島_段階C_仕様_2026-10-08.md の第7節と第17節。決まりは intimacy.json の events 節（nagishima/event_rules.py）。
- 普段のエッチ（state の intimacy）とは別の、薄い決まった流れ（state の event_play）。場所は「浴室」として出し、二人の居場所は終えてから湯上がりの場所へ。
- 高まりの数は普段のエッチと同じ決まりを使う：真帆は慣れの割合と速さの割合（maho_gain）、達する値・達したあとの値、こちらは速さの割合・入れる前の上限・果てられる値・限界・余力。
- エッチまで進んだら、普段のエッチと同じく回数・淫乱度・達した回数・果てた回数・最後の結果・欲求を記録する（始まり方の回数は event）。"""
from .conditions import evaluate
from .errors import GameError, ensure
from .event_rules import PACES
from .clock import slot as clock_slot
from .progression import day_time, life_day

PHASES = ("pre", "offer", "position", "foreplay", "main", "warn")  # warn：人目（野外）で足音・灯りが近づいた（v8.5.4）


def drank_tonight(state):
    """お酒を飲んだ夜か（晩酌で真帆がほろ酔い以上になった暮らしの日。v8.5.3）。その夜は、眠っている真帆に触れる（寝込み）に入らない。"""
    night = state.get("drink_night")
    return bool(night) and night["day"] == life_day(state["world"]["now"])


def entry_blocked(state, pack, kind, define):
    """こちらから誘うイベント（晩酌・野外）を今は誘えない理由（code, 文）。誘えるなら None。メニューと操作で同じ判定を使う。"""
    now, entry = state["world"]["now"], define.entry
    today = life_day(now)
    player, maho = state["actors"]["player"], state["actors"]["maho"]
    if player["location"] not in entry["places"] or maho["location"] != player["location"]:
        return "location", "誘える場所で、真帆と一緒のときに誘う。"
    if state["relation"]["stage"] < entry["min_stage"]:
        return "relationship", "まだ、そこまで誘える間柄ではない。"
    if not entry["from"] <= day_time(now) < entry["until"]:
        return "event_time", "誘える時間帯ではない。"
    if any(x["group"] == "event_" + kind and x["day"] == today for x in state["cooldowns"]):
        return "event_time", "今日はもう誘った。"
    meal = pack.life.meals.get(entry["after"]) if entry["after"] and pack.life and pack.life.meals else None
    if meal and day_time(now) < meal["until"] and not any(x["group"] == "meal_" + entry["after"] and x["day"] == today for x in state["cooldowns"]):
        return "event_time", "夕食を済ませてから誘う。"
    if entry["when"] and evaluate(entry["when"], pack.registry.values(state)) is not True:
        return "event_when", "今は誘えない。"
    if define.exposure and clock_slot(now) not in define.exposure["start"][player["location"]]:
        return "event_time", "今は誘えない。"
    return None


def place_label(state, pack, define):
    """イベントの場所の名前。label の {place} は、二人のいる場所の名前に置き換える（野外：「海岸の物陰」など。v8.5.4）。"""
    location = state["actors"]["player"]["location"]
    return define.label.replace("{place}", pack.catalog["locations"][location]["label"])


class EventPlay:
    @property
    def er(self):
        rules = self.pack.intimacy.events if self.pack.intimacy else None
        ensure(rules is not None, "event_play", "この原稿版にイベントのエッチは登録されていない。")
        return rules

    def _ev(self, phases=None):
        play = self.s.get("event_play")
        ensure(play, "event_play", "イベントの最中ではない。")
        ensure(phases is None or play["phase"] in phases, "event_phase", "今は選べない。")
        return play, self.er.events[play["kind"]]

    def event_open(self, row, values=None):
        """行の条件（when）に当たるか（メニューと操作の両方で使う）。"""
        return "when" not in row or evaluate(row["when"], values if values is not None else self.pack.registry.values(self.s)) is True

    # ---- 始める（浴室：一緒に入る誘いを受けたとき。life.bath_invite から） ----
    def event_begin(self, kind, meal=None):
        """meal：台所の支度の食事（dinner＝夕食、lunch＝休日の昼。v8.5.11）。台所だけが持つ。"""
        self.er.events[kind]
        self.s["contacts"] = []
        self.s["distance"] = "near"
        define = self.er.events[kind]
        exposure = define.exposure["start"][self.s["actors"]["player"]["location"]][clock_slot(self.now)] if define.exposure else 0
        self.s["event_play"] = {"id": self.new_id("event"), "kind": kind, "started_at": self.now, "phase": "pre", "position": None, "step": 0,
                                "inserted": False, "maho": 0, "player": 0, "climaxes": 0, "finishes": 0, "used": [], "last": None, "noticed": False, "h": False, "h_at": None, "drunk": 0,
                                "exposure": exposure, "warned": False, "resume": None, "acts": 0,
                                **({"meal": meal or "dinner"} if kind == "kitchen" else {})}
        self.s["interaction_streak"] = None
        self.emit("ev." + kind + ".begin")

    # ---- 始める（晩酌：こちらから誘う。v8.5.3） ----
    def event_invite(self, kind):
        """こちらから誘って始めるイベント（晩酌・野外）。入口の場所で真帆と二人、時間帯の中、その暮らしの日にまだ誘っていないとき。"""
        define = self.er.events.get(kind)
        ensure(define is not None and define.entry is not None, "event_play", "このイベントは誘って始めるものではない。")
        self.free()
        self.require_awake()
        ensure(self.s["mode"] == "normal" and not self.s.get("sleep_play") and not self.s.get("event_play"), "event_play", "今は誘えない。")
        blocked = entry_blocked(self.s, self.pack, kind, define)
        if blocked:
            raise GameError(*blocked)
        self.record_offer("event_" + kind)
        self.s["contacts"] = []
        for actor in self.s["actors"].values():
            actor["location"], actor["posture"] = define.entry["at"] or actor["location"], define.entry["posture"]
        self.event_begin(kind)

    # ---- 1手 ----
    def _event_time(self, h):
        """1手の時間（目覚める時刻の手前まで）。限りの時間を過ぎたら True（のぼせる・時間切れ）。"""
        play, define = self._ev()
        minutes = min(define.h_minutes if h else define.pre_minutes, max(0, self.s["world"]["awake_deadline"] - self.now))
        if minutes:
            self.advance(minutes)
        return self.now >= self._event_limit_at() or self.now >= self.s["world"]["awake_deadline"]

    def _event_limit_at(self):
        """いられる時刻（エッチへ移ってからは h_limit があればその分）。"""
        play, define = self._ev()
        if play["h"] and define.h_limit:
            return play["h_at"] + define.h_limit
        return play["started_at"] + define.limit

    def _event_gain(self, row, pace="none"):
        """真帆とこちらの高まりを動かす。真帆が達する値に届いたら、達する本文（達したあとの値へ戻る）。"""
        play, define = self._ev()
        rules = self.ir
        tier = rules.tier(self.s["intimacy_history"]["count"], self.pack.life)
        maho = row["maho"]
        if maho > 0:
            maho = rules.maho_gain(maho, tier, rules.band(play["maho"]), pace)[0]
        player = row["player"]
        if player > 0 and pace != "none" and rules.pace:
            player = player * rules.pace["player_percent"][pace] // 100
        cap = rules.raw["player"]["arousal_max"] if play["inserted"] else rules.raw["player"]["cap_not_inserted"]
        # 真帆は、触れ合い（pre）のうちは段 high の手前まで、入れる前は達する手前まで（達するのは入れてから）
        maho_cap = rules.raw["maho"]["climax_at"] if play["inserted"] else rules.raw["maho"]["climax_at"] - 1 if play["h"] else rules.raw["maho"]["arousal_bands"]["high_from"] - 1
        value = play["maho"] + maho
        play["maho"] = max(0, min(max(maho_cap, play["maho"]), value) if maho > 0 else value)
        value = play["player"] + player
        play["player"] = max(0, min(max(cap, play["player"]), value) if player > 0 else value)
        if play["maho"] >= rules.raw["maho"]["climax_at"]:
            play["climaxes"] += 1
            play["maho"] = rules.raw["maho"]["after_climax"]
            self.emit("ev." + play["kind"] + ".climax")

    def _event_after(self, timed_out, row=None):
        """1手のあと：時間切れなら終える。そうでなければ人目（野外）を動かす。終えたか、足音で手が止まったら True。"""
        play, _ = self._ev()
        if timed_out:
            self.emit("ev." + play["kind"] + ".timeout")
            self._event_close()
            return True
        return self._event_exposure(row) if row is not None else False

    # ---- 人目（野外。v8.5.4） ----
    def _event_exposure(self, row):
        """手の人目を足す。max に届いたら、急いで服を直して離れて終える。warn_at を超えたら（一度ごとに）足音・灯りが近づく（warn の段へ）。"""
        play, define = self._ev()
        rule = define.exposure
        if not rule:
            return False
        play["exposure"] = max(0, min(rule["max"], play["exposure"] + row.get("exposure", 0)))
        if play["exposure"] >= rule["max"]:
            self.emit("ev." + play["kind"] + ".caught")
            self._event_close()
            return True
        if play["exposure"] >= rule["warn_at"] and not play["warned"]:
            play.update(warned=True, resume=play["phase"], phase="warn")
            self.emit("ev." + play["kind"] + ".warn")
            return True
        if play["exposure"] < rule["calm"]:
            play["warned"] = False  # calm より下がったら、次に超えたときにまた近づく
        return False

    def event_hush(self):
        """息を殺す：人目が hush だけ下がり、元の段へ戻る（真帆が声を抑える本文）。"""
        play, define = self._ev(("warn",))
        play["last"] = "hush"
        self.emit("ev." + play["kind"] + ".hush")
        timed_out = self._event_time(play["h"])
        play["exposure"] = max(0, play["exposure"] + define.exposure["hush"])
        play.update(phase=play["resume"], resume=None)
        if play["exposure"] < define.exposure["calm"]:
            play["warned"] = False
        self._event_after(timed_out)

    def event_night_visit(self):
        """夜中に真帆が来る（v8.5.5）：主人公が眠るときに呼ぶ。night のあるイベントで、when に当たり、その夜の割合に当たれば、
        from〜until の時刻まで眠ってから、主人公の部屋で真帆が来るイベントを始めて True。当たらなければ何もしない。"""
        rules = self.pack.intimacy.events if self.pack.intimacy else None
        if not rules:
            return False
        from .codec import digest
        day = life_day(self.now)
        for kind, define in rules.events.items():
            night = define.night
            if not night or evaluate(night["when"], self.pack.registry.values(self.s)) is not True:
                continue
            value = int(digest([self.s["world"]["seed"], "night_visit", kind, day])[:12], 16)
            if value % 100 >= night["percent"]:
                continue
            at = night["from"] + (value // 100) % (night["until"] - night["from"])
            target = self.now - day_time(self.now) + at
            if target <= self.now:
                continue  # その時刻を過ぎてから眠った夜は来ない
            self.s["contacts"] = []
            self.advance(target - self.now, sleeping=True)
            player, maho = self.s["actors"]["player"], self.s["actors"]["maho"]
            player["location"], player["posture"] = "player_room", "reclined"
            maho["location"], maho["posture"] = "player_room", "standing"
            self.s["maho_sleep"].update(state="awake", since=None)
            self.event_begin(kind)
            return True
        return False

    def event_rumor(self):
        """翌日の噂（野外。v8.5.4）：前の暮らしの日にそのイベントのエッチをして、今日はじめての仕事なら、percent の割合で島の人に遠回しに言われる。"""
        rules = self.pack.intimacy.events if self.pack.intimacy else None
        if not rules:
            return
        today = life_day(self.now)
        if any(h["choice"] == "work.go" and life_day(h["at"]) == today for h in self.s["history"]):
            return  # その日の二度目からの仕事では出さない
        from .codec import digest
        for kind, define in rules.events.items():
            record = (self.s.get("event_record") or {}).get(kind)
            if define.rumor and record and record["last_day"] == today - 1 \
                    and int(digest([self.s["world"]["seed"], "event_rumor", kind, today])[:12], 16) % 100 < define.rumor["percent"]:
                self.emit("ev." + kind + ".rumor")

    def event_hide(self, how):
        """急いで服を直す（fix）・やめる（stop）：その場を離れて終える。"""
        play, _ = self._ev(("warn",))
        ensure(how in ("fix", "stop"), "event_action", "今は選べない。")
        self.emit("ev." + play["kind"] + "." + how)
        self._event_close()

    # ---- その場の触れ合い（pre） ----
    def event_act(self, key):
        play, define = self._ev(("pre",))
        ensure(key in define.pre and self.event_open(define.pre[key]), "event_action", "今は選べない。")
        row = define.pre[key]
        if key not in play["used"]:
            play["used"].append(key)
        play["acts"] += 1  # v8.5.5：その場の手の数（真帆が来る：寝たふりの回数で真帆の進み方を書き分ける）
        play["last"] = "pre." + key
        self.emit("ev." + play["kind"] + ".pre." + key)
        timed_out = self._event_time(False)
        self._event_gain(row)
        if define.drunk:
            play["drunk"] = max(0, min(1000, play["drunk"] + row.get("drunk", 0)))
            if define.drunk_level(play["drunk"]) >= len(define.drunk["levels"]):
                self.emit("ev." + play["kind"] + ".asleep")  # 酔いつぶれて眠る（v8.5.3）
                self._event_close(asleep=True)
                return
        if not timed_out and self._event_exposure(row):
            return  # 人目（野外）：見つかりかけて離れた、または足音で手が止まった（v8.5.4）
        noticed = (evaluate(define.notice_when, self.pack.registry.values(self.s)) is True) if define.notice_when else play["player"] >= define.notice_at
        if not timed_out and not play["noticed"] and noticed:
            play["noticed"] = True
            notice = next(r["id"] for r in define.notice_order if evaluate(r["when"], self.pack.registry.values(self.s)) is True)
            self.emit("ev." + play["kind"] + ".notice." + notice)
            if notice in define.offer:
                play["phase"] = "offer"
            elif notice in define.notice_close:
                self._event_close()  # 野外：「部屋に戻ろ」（v8.5.4）
                return
        self._event_after(timed_out)

    def event_leave(self):
        """上がる（浴室）・居間で待つ（台所：支度が終わるまで進めて夕食へ）。エッチの前ならいつでも。"""
        play, define = self._ev(("pre", "offer"))
        self.emit("ev." + play["kind"] + ".leave")
        if play["kind"] == "kitchen":
            minutes = min(max(0, play["started_at"] + define.limit - self.now), max(0, self.s["world"]["awake_deadline"] - self.now))
            if minutes:
                before = self.now
                self.advance(minutes)
                self.auto_minutes += self.now - before
        self._event_close()

    def event_offer(self, accept):
        play, _ = self._ev(("offer",))
        if accept:
            ensure(self.s["stamina"]["value"] > 0, "h_player", "余力が尽きた。")
            define = self.er.events[play["kind"]]
            ensure(define.accept_when is None or self.event_open({"when": define.accept_when}), "event_action", "今は選べない。")
            play["phase"] = "position"
            self.emit("ev." + play["kind"] + ".offer.accept")
            return
        self.emit("ev." + play["kind"] + ".offer.decline")
        play["phase"] = "pre"
        if self.er.events[play["kind"]].decline_close:
            self._event_close()  # 野外：家へ戻る（v8.5.4）

    # ---- エッチ（体位・前戯・入れる・動く・触れる・果てる） ----
    def event_position(self, key):
        play, define = self._ev(("position",))
        ensure(key in define.positions and self.event_open(define.positions[key]), "event_action", "今は選べない。")
        play.update(position=key, phase="foreplay", h=True, h_at=self.now, last="pos." + key)
        self.emit("ev." + play["kind"] + ".pos." + key)
        self._event_after(self._event_time(True))

    def event_next(self):
        """前戯を一つ進める（決まった順）。最後まで進んだら、入れるのを待つ。"""
        play, define = self._ev(("foreplay",))
        ensure(play["step"] < len(define.foreplay), "event_action", "前戯はもう終わった。")
        row = define.foreplay[play["step"]]
        play["step"] += 1
        play["last"] = "fore." + row["id"]
        self.emit("ev." + play["kind"] + ".fore." + row["id"])
        timed_out = self._event_time(True)
        self._event_gain(row)
        self._event_after(timed_out, row)

    def event_insert(self):
        play, define = self._ev(("foreplay", "main"))
        ensure(not play["inserted"] and (play["phase"] == "main" or play["step"] >= 1), "event_action", "今は選べない。")
        play.update(inserted=True, phase="main", last="insert")
        self.emit("ev." + play["kind"] + ".insert")
        timed_out = self._event_time(True)
        self._event_gain(define.insert)
        self._event_after(timed_out, define.insert)

    def event_move(self, pace):
        play, define = self._ev(("main",))
        ensure(pace in PACES and play["inserted"] and not self._event_must_finish(), "event_action", "今は選べない。")
        play["last"] = "move." + pace
        self.emit("ev." + play["kind"] + ".move." + pace)
        timed_out = self._event_time(True)
        self._event_gain(define.moves[pace], pace)
        self._event_after(timed_out, define.moves[pace])

    def event_touch(self, key):
        play, define = self._ev(("main",))
        ensure(key in define.touches and self.event_open(define.touches[key]) and not self._event_must_finish(), "event_action", "今は選べない。")
        play["last"] = "touch." + key
        self.emit("ev." + play["kind"] + ".touch." + key)
        timed_out = self._event_time(True)
        self._event_gain(define.touches[key])
        self._event_after(timed_out, define.touches[key])

    def event_can_finish(self):
        play = self.s.get("event_play")
        return bool(play and play["phase"] == "main" and play["inserted"] and play["player"] >= self.ir.raw["player"]["finish_from"] and self.s["stamina"]["value"] > 0)

    def _event_must_finish(self):
        play = self.s["event_play"]
        return play["inserted"] and play["player"] >= self.ir.raw["player"]["arousal_max"] and self.s["stamina"]["value"] > 0

    def event_finish(self, where):
        play, _ = self._ev(("main",))
        ensure(where in ("inside", "outside") and self.event_can_finish(), "event_action", "今は選べない。")
        play["finishes"] += 1
        self.s["stamina"]["value"] -= 1
        play["last"] = "finish." + where
        self.emit("ev." + play["kind"] + ".finish." + where)
        self._event_time(True)
        self.emit("ev." + play["kind"] + ".end." + ("satisfied" if play["climaxes"] else "unsatisfied"))
        self._event_close()

    # ---- 終える ----
    def _event_close(self, asleep=False):
        """イベントを終える。エッチまで進んでいれば記録し、浴室なら湯上がりへ（居間で、部屋着に）、台所なら夕食へ。
        晩酌で酔いつぶれたら（asleep）、またはほろ酔い以上でお開き・時間切れになったら、真帆は自分の部屋で眠る（その夜はもう起きない）。
        晩酌でほろ酔い以上になった夜は drink_night に覚え、その夜は寝込みに入らない（v8.5.3）。"""
        play = self.s["event_play"]
        define = self.er.events[play["kind"]]
        if define.morning_order:
            # v8.5.9：翌朝の一言を、終える前の様子（event.*）で決めて覚える（null の行なら、前に覚えた一言をそのまま残す）
            morning = self._first_morning(define)
            if morning:
                self.s["event_morning"] = {"kind": play["kind"], "id": morning, "h": play["h"], "at": self.now}
        self.s["event_play"] = None
        level = define.drunk_level(play["drunk"]) if define.drunk else 0
        if level:
            # お酒を飲んだ夜（ほろ酔い以上）を覚える。その夜は寝込みに入らない（drank_tonight）。翌朝の本文にも使える（event.drink_night.*）
            self.s["drink_night"] = {"day": life_day(play["started_at"]), "drunk": level}
        if asleep or (level and not play["h"]):
            # 酔いつぶれた、または酔ってお開き（部屋まで送る）：真帆は自分の部屋で眠る（その夜はもう起きない）
            maho = self.s["actors"]["maho"]
            maho["location"], maho["posture"] = "maho_room", "reclined"
            self.s["maho_sleep"].update(state="asleep", since=self.now)
            self.s["contacts"], self.s["distance"] = [], "normal"
            self.s["interaction_streak"] = None
        if play["h"]:
            self._event_record(play)
        if play["kind"] == "kitchen" and play.get("meal") == "lunch":
            self.eat_lunch(text=not play["h"])  # v8.5.11：休日の昼の支度が終われば昼食
        elif play["kind"] == "kitchen":
            self.eat_dinner(text=not play["h"])  # 台所：支度が終われば夕食（エッチのあとは、終わりの一言が冷めた夕食まで書く）
        if define.return_to:
            # 野外：二人で家へ戻る（そのまま眠る流れにはしない。v8.5.4）
            target = define.return_to
            self.s["contacts"], self.s["distance"] = [], "normal"
            for actor in self.s["actors"].values():
                actor["location"], actor["posture"] = target["location"], target["posture"]
            minutes = min(target["minutes"], max(0, self.s["world"]["awake_deadline"] - self.now))
            if minutes:
                self.advance(minutes)
        if define.sleep_after:
            # 真帆が来る（v8.5.5）：終えたら翌朝へ。エッチまで進めば同じベッドで眠り（一緒に眠った朝の一言）、そうでなければ真帆は部屋へ戻って眠る
            if play["h"]:
                self.s["intimacy_history"]["slept_together"] = True
                self.sleep(together=True)
            else:
                maho = self.s["actors"]["maho"]
                maho["location"], maho["posture"] = "maho_room", "reclined"
                self.s["maho_sleep"].update(state="asleep", since=self.now)
                self.s["distance"] = "normal"
                self.sleep()
            return
        if play["kind"] == "bath":
            rules = self.bath_rules()
            self.s["contacts"] = []
            for actor in self.s["actors"].values():
                actor["location"], actor["posture"] = rules["after"], "seated"  # 風呂の後は居間で過ごす（一人で入ったときと同じ）
            self.s["distance"] = "normal"
            self.bath_done(life_day(play["started_at"]), together=True, desire=not play["h"])

    def _first_morning(self, define):
        values = self.pack.registry.values(self.s)
        return next(r["id"] for r in define.morning_order if evaluate(r["when"], values) is True)

    def event_morning_take(self):
        """v8.5.9：目覚めたときに呼ぶ。前の暮らしの日に終えたイベントの翌朝の一言の記録を返して消す（もっと前の記録は、出さずに消す）。なければ None。"""
        record = self.s.get("event_morning")
        if not record:
            return None
        self.s["event_morning"] = None
        return record if life_day(record["at"]) == life_day(self.now) - 1 else None

    def _event_record(self, play):
        """普段のエッチと同じ記録（回数・淫乱度・達した回数・果てた回数・結果・欲求）。始まり方の回数は event。"""
        rules = self.ir
        hist = self.s["intimacy_history"]
        result = "satisfied" if play["climaxes"] else "unsatisfied"
        hist["count"] += 1
        hist["by_entry"]["event"] = hist["by_entry"].get("event", 0) + 1
        hist["first_at"] = hist["first_at"] if hist["first_at"] is not None else self.now
        hist["last_at"], hist["last_result"] = self.now, result
        lewd = rules.lewd
        if lewd and (play["climaxes"] or play["finishes"]):
            gain = lewd["per_session"] + (lewd["satisfied"] if result == "satisfied" else 0) + lewd["per_climax"] * min(lewd["climax_max"], play["climaxes"])
            hist["lewdness"] = min(lewd["max"], hist["lewdness"] + gain)
        hist["maho_climaxes"] += play["climaxes"]
        record = self.s.setdefault("event_record", {})
        record[play["kind"]] = {"count": record.get(play["kind"], {}).get("count", 0) + 1, "last_day": life_day(self.now)}  # イベントごとの回数と最後の日（台所は週に一度まで）
        hist["finishes"] += play["finishes"]
        self.remember("intimacy", summary={"result": result})
        self.s["desire"] = rules.raw["desire_after"]["satisfied"] if result == "satisfied" else min(100, self.s["desire"] + rules.raw["desire_after"]["unsatisfied_add"])  # 普段のエッチの終わりと同じ
