"""v8.5.3（ユーザー 2026-10-08「君はイベントエッチのほう進めて」）：010 だけ。段階C の四歩目：晩酌（お酒。イベントの型）。
仕様 docs/凪島_段階C_仕様_2026-10-08.md の第4節・第17節。"""
import unittest
from pathlib import Path

from nagishima.content import Pack
from tools.run_stage_b_routes import Route

ROOT = Path(__file__).resolve().parents[1]
P009 = Pack(ROOT / "content/releases/interaction_009")
P010 = Pack(ROOT / "content/releases/interaction_010")


def drink_route(affinity=80, desire=95, tier="familiar", seed=8, hour=20, minute=0, release="interaction_010", dinner=False):
    """夕食・風呂を済ませた夜（既定 20:00）。dinner=True なら夕食はまだ。"""
    route = Route(seed, hour=hour, minute=minute, tier=tier, release=release, dinner=dinner)
    state = route.engine._state
    state["affinity"]["value"], state["desire"] = affinity, desire
    route.engine._install_choices()
    return route


def meanings(view):
    return [b["meaning"] for b in view["blocks"]]


def ids(view):
    return [c["id"] for c in view["choices"]]


def drunk(route):
    return route.engine.snapshot()["event_play"]["drunk"]


def until_notice(route, limit=10):
    for _ in range(limit):
        view = route.choose("event.pre.drink")
        if any(m.startswith("ev.drink.notice.") for m in meanings(view)):
            return view
    raise AssertionError("反応しない")


class V853(unittest.TestCase):
    def test_009_has_no_drink(self):
        """009 には晩酌の誘いが出ない。"""
        route = drink_route(release="interaction_009")
        self.assertNotIn("event.invite.drink", ids(route.engine.get_view()))
        route.close()

    def test_rules(self):
        drink = P010.intimacy.events.events["drink"]
        self.assertEqual((drink.limit, drink.h_limit), (120, 40))
        self.assertEqual(drink.entry["min_stage"], 1)
        self.assertEqual(list(drink.positions), ["sofa_lap", "sofa_lie"])
        self.assertEqual([drink.drunk_level(v) for v in (0, 19, 20, 44, 45, 74, 75)], [0, 0, 1, 1, 2, 2, 3])
        for meaning in drink.meanings():
            self.assertIn(meaning, P010.meanings)
        self.assertIn("ev.drink.asleep", drink.meanings())
        for key in ("event.drunk", "event.drink.count", "event.drink.days"):
            self.assertIn(key, P010.registry.fields)

    def test_invite_window_and_once_a_day(self):
        """誘えるのは 19:00〜23:00 の夕食のあと、暮らしの日に1回。しらふのうちにお開きにすると、真帆は起きたまま。その夜はもう誘いが出ない。"""
        for hour, minute, dinner in ((18, 30, False), (23, 0, False), (19, 30, True)):
            route = drink_route(hour=hour, minute=minute, dinner=dinner)
            self.assertNotIn("event.invite.drink", ids(route.engine.get_view()), (hour, minute, dinner))
            route.close()
        route = drink_route(hour=20, minute=30, dinner=True)  # 夕食の時間帯が過ぎていれば、食べていなくても誘える
        self.assertIn("event.invite.drink", ids(route.engine.get_view()))
        route.close()
        route = drink_route()
        view = route.choose("event.invite.drink")
        self.assertIn("ev.drink.begin", meanings(view))
        self.assertEqual(view["page_title"], "居間（晩酌）")
        self.assertEqual(drunk(route), 0)
        view = route.choose("event.leave")
        self.assertEqual(meanings(view)[-1], "ev.drink.leave")
        state = route.engine.snapshot()
        self.assertIsNone(state["event_play"])
        self.assertNotIn("event.invite.drink", ids(view))
        self.assertNotIn("drink", state.get("event_record", {}))  # エッチまで進んでいないので記録しない
        self.assertNotIn("drink_night", state)  # しらふ
        self.assertEqual((state["maho_sleep"]["state"], state["actors"]["maho"]["location"]), ("awake", "living_room"))
        route.close()

    def test_tipsy_leave_goes_to_bed(self):
        """ほろ酔いでお開きにすると、真帆を部屋まで送り、真帆はそのまま眠る。お酒を飲んだ夜なので、寝込み（部屋へそっと行く）は出ない。翌日には出る。"""
        route = drink_route(desire=0)
        route.choose("event.invite.drink")
        until_notice(route)
        view = route.choose("event.leave")
        self.assertEqual(meanings(view)[-1], "ev.drink.leave")
        state = route.engine.snapshot()
        self.assertEqual((state["maho_sleep"]["state"], state["actors"]["maho"]["location"]), ("asleep", "maho_room"))
        self.assertEqual(state["drink_night"]["drunk"], 1)
        values = route.engine.pack.registry.values(state)
        self.assertEqual((values["event.drink_night.days"], values["event.drink_night.drunk"]), (0, 1))
        self.assertNotIn("sleep.visit", ids(view))
        state["world"]["now"] += 1440
        self.assertEqual(route.engine.pack.registry.values(state)["event.drink_night.days"], 1)  # 翌日（翌朝の本文に使える）
        route.close()

    def test_drunk_and_water(self):
        """飲むと酔いが進み、水で戻る。ほろ酔いで一度だけ反応する。"""
        route = drink_route(desire=0)
        route.choose("event.invite.drink")
        route.choose("event.pre.drink")
        self.assertEqual(drunk(route), 12)
        route.choose("event.pre.water")
        self.assertEqual(drunk(route), 6)
        view = until_notice(route)
        self.assertTrue(20 <= drunk(route) < 45)  # ほろ酔いになったところ
        self.assertIn("ev.drink.notice.affection", meanings(view))  # 恋人でも欲求が低ければ、甘えるだけ
        self.assertNotIn("event.accept", ids(view))
        route.close()

    def test_tipsy_invite_and_h(self):
        """恋人で慣れ・欲求が高ければ、ほろ酔いの真帆から求める → 応える → ソファのエッチ → 記録。"""
        route = drink_route()
        route.choose("event.invite.drink")
        view = until_notice(route)
        self.assertIn("ev.drink.notice.invite", meanings(view))
        self.assertEqual(route.engine.pack.registry.values(route.engine.snapshot())["event.drunk"], 1)
        route.choose("event.accept")
        view = route.choose("event.pos.sofa_lap")
        self.assertIn("ev.drink.pos.sofa_lap", meanings(view))
        route.choose("event.next")
        route.choose("event.insert")
        for _ in range(20):
            if "event.finish.inside" in ids(route.engine.get_view()):
                break
            route.choose("event.move.normal")
        view = route.choose("event.finish.inside")
        self.assertTrue(meanings(view)[-1].startswith("ev.drink.end."))
        state = route.engine.snapshot()
        self.assertIsNone(state["event_play"])
        self.assertEqual(state["event_record"]["drink"]["count"], 1)
        self.assertEqual(state["intimacy_history"]["by_entry"]["event"], 1)
        self.assertNotIn("event.invite.drink", ids(view))
        self.assertEqual(state["drink_night"]["drunk"], 1)  # エッチのあとは居間で起きたまま。この夜も寝込みには入らない
        self.assertEqual(state["maho_sleep"]["state"], "awake")
        route.close()

    def test_no_h_when_deeper(self):
        """応えられるのは、ほろ酔いのうちだけ（酔いが深い段ではエッチに移らない）。"""
        route = drink_route()
        route.choose("event.invite.drink")
        until_notice(route)
        self.assertTrue(next(c for c in route.engine.get_view()["choices"] if c["id"] == "event.accept")["available"])
        route.engine._state["event_play"]["drunk"] = 50  # 酔っている段
        route.engine._install_choices()
        self.assertFalse(next(c for c in route.engine.get_view()["choices"] if c["id"] == "event.accept")["available"])
        route.close()

    def test_asleep(self):
        """飲み続けると酔いつぶれて眠る。真帆は自分の部屋で眠り、エッチにはならない。"""
        route = drink_route(desire=0)
        route.choose("event.invite.drink")
        view = None
        for _ in range(12):
            if not route.engine.snapshot()["event_play"]:
                break
            view = route.choose("event.pre.drink")
        self.assertEqual(meanings(view)[-1], "ev.drink.asleep")
        state = route.engine.snapshot()
        self.assertEqual(state["maho_sleep"]["state"], "asleep")
        self.assertEqual(state["actors"]["maho"]["location"], "maho_room")
        self.assertNotIn("drink", state.get("event_record", {}))
        self.assertNotIn("event.invite.drink", ids(view))
        self.assertNotIn("sleep.visit", ids(view))  # 酔いつぶれた真帆には触れない
        self.assertEqual(state["drink_night"]["drunk"], 3)
        with self.assertRaises(Exception):
            route.engine.choose("sleep.visit", view["revision"], view["session"])
        route.close()

    def test_stage0_cannot_invite(self):
        """同居を始めたばかり（段階0）は、晩酌に誘えない。"""
        import tempfile
        from nagishima.engine import Engine
        with tempfile.TemporaryDirectory(prefix="nagishima-v853-") as temp:
            engine = Engine(temp, seed=8, release="interaction_010", autosave=False)
            state = engine._state
            self.assertEqual(state["relation"]["stage"], 0)
            now = state["world"]["now"] // 1440 * 1440 + 20 * 60
            state["world"].update(now=now, processed_until=now)
            engine._install_choices()
            self.assertNotIn("event.invite.drink", ids(engine.get_view()))


if __name__ == "__main__":
    unittest.main()
