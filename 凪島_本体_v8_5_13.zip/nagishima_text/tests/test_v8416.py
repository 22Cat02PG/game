"""v8.4.16（ユーザー 2026-10-07 13:41「進めろ。次があるだろ」）：010 だけ。
本文の再会を減らす 三束目（口で胸・耳もと首すじ・太もも・頬に口づける・頬に触れる・時間切れのひと言、胸に直に・もう一度口づける・並んで座る・向かい合って横になるの反応）。"""
import unittest
from pathlib import Path

from nagishima.conditions import evaluate
from nagishima.content import Pack

ROOT = Path(__file__).resolve().parents[1]
P009 = Pack(ROOT / "content/releases/interaction_009")
P010 = Pack(ROOT / "content/releases/interaction_010")
PREV = lambda name: {"field": f"flow.prev.{name}", "op": "eq", "value": False}  # noqa: E731
OFF = lambda action: {"field": f"contact.{action}.active", "op": "eq", "value": False}  # noqa: E731
NEW = [t for t in P010.texts if t["id"].startswith("cmp.") and any(f".x{n}" in t["id"] for n in range(1, 5))]


class V8416(unittest.TestCase):
    def test_009_unchanged(self):
        self.assertFalse(any(t["id"].startswith("cmp.") for t in P009.texts))

    def test_new_scenes(self):
        meanings = {t["meaning"] for t in NEW}
        for meaning in ("h_chest_mouth.start", "h_ear_neck.start", "h_thigh.start", "h_cheek_kiss.start", "h_cheek.start", "h.deadline",
                        "h_chest_skin.start", "h_kiss_deep.again", "h_pos_sitting_close.start", "h_pos_lying_face.start"):
            self.assertIn(meaning, meanings)
        self.assertGreater(len(NEW), 1400)
        for text in NEW:
            self.assertIn({"field": "intimacy.tier", "op": "in", "value": ["few", "familiar"]}, text["when"]["all"])

    def test_one_sentence_cheek(self):
        # 頬に口づける・頬に触れるは一文（前半「〜と、」＋後半）
        for text in NEW:
            if text["meaning"] in ("h_cheek_kiss.start", "h_cheek.start"):
                self.assertEqual(text["body"].count("。"), 1, text["id"])
                self.assertIn("と、真帆", text["body"])

    def test_deadline_night_kind(self):
        work = [t for t in NEW if t["meaning"] == "h.deadline" and ".x1dlbwork01" in t["id"]]
        holiday = [t for t in NEW if t["meaning"] == "h.deadline" and ".x1dlbholiday01" in t["id"]]
        self.assertTrue(work and holiday)
        state = {"intimacy.tier": "familiar", "night.kind": "workday_eve", "intimacy.facing": "face", "intimacy.maho.band": "low"}
        self.assertTrue(any(evaluate({"all": [c for c in t["when"]["all"] if c["field"] in state]}, state) for t in work))
        self.assertFalse(any(evaluate({"all": [c for c in t["when"]["all"] if c["field"] in state]}, state) for t in holiday))
        # 深く口づけている・口で胸に触れているあいだの、向かい合う仕草の前半は出さない
        for text in NEW:
            if text["meaning"] == "h.deadline" and "dlaface" in text["id"]:
                self.assertIn(OFF("h_kiss_deep"), text["when"]["all"])

    def test_flow_and_kiss_conditions(self):
        for text in NEW:
            b = text["id"].rsplit(".", 1)[1]
            if not b.startswith("x"):
                continue  # 後半が五束目（v8.4.18）の部品の本文は test_v8418 で見る
            if "bcalm" in b or "dlb" in b:
                self.assertIn(PREV("urgent"), text["when"]["all"], text["id"])
            if "bhot" in b:
                self.assertIn(PREV("end"), text["when"]["all"], text["id"])
            if "cma" in text["id"].rsplit(".", 2)[1]:
                self.assertIn(PREV("service"), text["when"]["all"])
            # 胸に直に・太ももの台詞は、深く口づけているあいだは出さない
            if text["meaning"] in ("h_chest_skin.start", "h_thigh.start") and "「" in text["body"]:
                self.assertIn(OFF("h_kiss_deep"), text["when"]["all"], text["id"])

    def test_own_contact_not_blocked(self):
        # その場面の触れ合いを「ない」とする条件（その場面では出ない本文）は残っていない
        for text in P010.texts:
            if text["id"].startswith("cmp."):
                self.assertNotIn(OFF(text["meaning"].split(".")[0]), text["when"]["all"], text["id"])
        self.assertIn("cmp.h_chest_skin.start.w7csaback01.w5csbcalm04", P010.by_text)

    def test_pairs(self):
        self.assertNotIn("cmp.h_cheek.start.x2chaface01.x4chbcalm02", P010.by_text)  # 手の甲で触れたのに「触れた指」
        self.assertIn("cmp.h_cheek.start.x1chaface01.x4chbcalm02", P010.by_text)
        self.assertNotIn("cmp.h_ear_neck.start.x2enaface02.x1enbhot01", P010.by_text)
        self.assertNotIn("cmp.h_pos_lying_face.start.w5mlaplayerabove01.x4mlbcalm01", P010.by_text)
        self.assertNotIn("cmp.h_thigh.start.x4tha02.x2thbcalm01", P010.by_text)

    def test_review_fixes(self):
        flow = P010.intimacy.flow
        self.assertIn("end", flow.info({"id": "x", "meaning": "h.deadline", "body": "「朝、起きられなくなっちゃう。今夜はこれで終わり」"})[3])
        self.assertIn("service", flow.info({"id": "y", "meaning": "h_maho_breasts.pace_slow", "body": "竿が谷間に残ったまま進みが遅く"})[3])
        self.assertIn("breath_match", flow.info({"id": "z", "meaning": "h_feel.start", "body": "真帆はこちらの息づかいに自分の息を合わせた。"})[0])
        # 移る前が横向きで後ろからのときは、もう横になっているので「隣に横向きで寝ころぶ」前半は出さない
        when = P010.by_text["cmp.h_pos_lying_face.start.w6mlaback01.x3mlbcalm01"]["when"]["all"]
        self.assertIn({"field": "intimacy.position_from", "op": "in", "value": ["from_behind", "prone_back"]}, when)
        # 真帆が上で体を起こしているときは、耳もと・首すじの前半は出さない
        for text in NEW:
            if "enaface" in text["id"]:
                self.assertIn({"field": "intimacy.position", "op": "ne", "value": "maho_above"}, text["when"]["all"])


if __name__ == "__main__":
    unittest.main()
