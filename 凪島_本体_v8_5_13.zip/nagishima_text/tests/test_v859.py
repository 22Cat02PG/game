"""v8.5.9（ユーザー 2026-10-08「進めろ。次があるだろ」）：010 だけ。段階C 十歩目：イベントの夜の翌朝の一言（仕様 第6.3節「酔って眠った」「真帆が来た」）。"""
import unittest
from pathlib import Path

from nagishima.content import Pack
from tools.run_stage_b_routes import Route

ROOT = Path(__file__).resolve().parents[1]
P009 = Pack(ROOT / "content/releases/interaction_009")
P010 = Pack(ROOT / "content/releases/interaction_010")


def meanings(view):
    return [b["meaning"] for b in view["blocks"]]


def drink_route(desire=0, tier="familiar"):
    route = Route(8, hour=20, tier=tier, release="interaction_010")
    state = route.engine._state
    state["affinity"]["value"], state["desire"] = 80, desire
    route.engine._install_choices()
    route.choose("event.invite.drink")
    return route


def drink_until(route, level):
    """level の段（1 ほろ酔い・2 酔っている）になるまで飲む。"""
    for _ in range(12):
        if route.engine.pack.registry.values(route.engine.snapshot())["event.drunk"] >= level:
            return
        route.choose("event.pre.drink")
    raise AssertionError("酔いが進まない")


def to_morning(route):
    """お開きのあと、眠って翌朝へ。眠った view を返す。"""
    return route.choose("sleep")


class V859(unittest.TestCase):
    def test_rules(self):
        self.assertIsNone(P009.intimacy.events)
        events = P010.intimacy.events.events
        self.assertEqual(events["drink"].mornings, ["h", "passed_out", "drunk", "tipsy"])
        self.assertEqual(events["visit"].mornings, ["h", "went_back"])
        for kind in ("bath", "kitchen", "outdoor"):
            self.assertEqual(events[kind].mornings, [])
        for kind in ("drink", "visit"):
            for key in events[kind].mornings:
                meaning = f"ev.{kind}.morning.{key}"
                self.assertIn(meaning, P010.meanings)
                self.assertTrue(any(t["meaning"] == meaning and not t["fallback"] for t in P010.by_text.values()), meaning)

    def test_tipsy_and_drunk(self):
        """ほろ酔い・酔っていた夜の翌朝は、それぞれの一言（一度だけ。次の朝には出ない）。"""
        for level, key in ((1, "tipsy"), (2, "drunk")):
            route = drink_route()
            drink_until(route, level)
            route.choose("event.leave")
            state = route.engine.snapshot()
            self.assertEqual((state["event_morning"]["kind"], state["event_morning"]["id"], state["event_morning"]["h"]), ("drink", key, False))
            got = meanings(to_morning(route))
            self.assertIn("ev.drink.morning." + key, got)
            self.assertLess(got.index("ev.drink.morning." + key), got.index("life.breakfast"))
            self.assertIsNone(route.engine.snapshot()["event_morning"])
            route.close()

    def test_sober_says_nothing(self):
        """しらふでお開きにした夜は、翌朝の一言を覚えない。"""
        route = drink_route()
        route.choose("event.leave")
        self.assertNotIn("event_morning", route.engine.snapshot())
        self.assertFalse(any(m.startswith("ev.drink.morning.") for m in meanings(to_morning(route))))
        route.close()

    def test_passed_out(self):
        """酔いつぶれた夜の翌朝は「部屋まで運んでくれた」の一言。"""
        route = drink_route()
        for _ in range(12):
            if not route.engine.snapshot()["event_play"]:
                break
            route.choose("event.pre.drink")
        self.assertEqual(route.engine.snapshot()["event_morning"]["id"], "passed_out")
        self.assertIn("ev.drink.morning.passed_out", meanings(to_morning(route)))
        route.close()

    def test_tipsy_h_replaces_generic_morning(self):
        """ほろ酔いの真帆から求めてエッチまで進んだ夜は、いつもの翌朝の一言（h.morning）の代わりに、晩酌の翌朝の一言。"""
        route = drink_route(desire=95)
        drink_until(route, 1)
        route.choose("event.accept")
        route.choose("event.pos.sofa_lap")
        route.choose("event.next")
        route.choose("event.insert")
        for _ in range(20):
            if "event.finish.inside" in [c["id"] for c in route.engine.get_view()["choices"]]:
                break
            route.choose("event.move.normal")
        route.choose("event.finish.inside")
        state = route.engine.snapshot()
        self.assertEqual((state["event_morning"]["id"], state["event_morning"]["h"]), ("h", True))
        self.assertEqual(state["event_morning"]["at"], state["intimacy_history"]["last_at"])
        got = meanings(to_morning(route))
        self.assertIn("ev.drink.morning.h", got)
        self.assertFalse(any(m.startswith("h.morning") for m in got), got)
        route.close()

    def test_stale_record_is_dropped(self):
        """二晩より前の記録は、出さずに消す（保存の形も確かめる）。"""
        route = drink_route()
        drink_until(route, 1)
        route.choose("event.leave")
        state = route.engine._state
        state["event_morning"]["at"] -= 1440
        route.engine._install_choices()
        got = meanings(to_morning(route))
        self.assertFalse(any(m.startswith("ev.drink.morning.") for m in got))
        self.assertIsNone(route.engine.snapshot()["event_morning"])
        route.close()

    def test_no_offer_during_event(self):
        """イベントの最中は、真帆の誘い（director の boundary）を出さない。場面を終えた手で台所の支度が始まった直後に、誘いが重なって止まっていた（いつもの通し）。
        同じ状態でイベントがなければ誘いが出ることも確かめる（この試験が意味を持つように）。"""
        from nagishima.codec import clone_state
        from nagishima.context import Context
        route = drink_route()
        engine = route.engine
        for active in (True, False):
            state = clone_state(engine._state)
            if not active:
                state["event_play"] = None
            context = Context(state, engine.pack, engine.repository, engine._frame)
            context.allow_offer = True
            context.boundary()
            self.assertEqual(state["offer"] is None, active, active)
        route.close()

    def test_visit_went_back(self):
        """真帆が来た夜に断ると、翌朝は「寝ぼけてたことにして」の一言。"""
        route = Route(8, hour=22, minute=30, tier="familiar", release="interaction_010", day_offset=2)
        night = route.engine.pack.intimacy.events.events["visit"].night
        saved, night["percent"] = night["percent"], 100
        try:
            route.engine._state["desire"] = 95
            route.engine._install_choices()
            view = route.choose("sleep")
            self.assertEqual(meanings(view)[-1], "ev.visit.begin")
            got = meanings(route.choose("event.leave"))
            self.assertIn("ev.visit.morning.went_back", got)
            self.assertLess(got.index("system.slept"), got.index("ev.visit.morning.went_back"))
        finally:
            night["percent"] = saved
            route.close()


if __name__ == "__main__":
    unittest.main()
