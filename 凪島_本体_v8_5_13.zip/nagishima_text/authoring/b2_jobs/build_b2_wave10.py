"""v8.2.10（ユーザー了承 2026-09-28 10:43・10:45）の grok への依頼（Opus）。

- 第10陣（p10.、標準）と濃い版（x9.）：顔面騎乗（体位 face_sit、下から舐める h_face_lick）、シックスナイン（体位 sixty_nine、舐め合う h_sixty_nine、
  口の中で出す・限界・こらえる）、顔面騎乗からの移行（お願いして変える・真帆が自分から向きを変える申し出）、その体位での合図・達する・敏感さ・物足りなさ・締め切り。
どの場面にも Opus の本文（opus_texts_009.json の o22・o23）がすでにある。
読み手の指摘（/home/claude/work/v8210/review.md の B-1〜B-15）を反映した。
出力：grok_b2_wave_10.json・grok_b2_wave_x9.json、grok依頼_B2_第10陣/、第10陣_一覧.json
"""
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
PROMPT = (OUT / "grokプロンプト_v3_0.txt").read_text(encoding="utf-8")
BED = "二人の個室のどちらか（どちらの部屋か、ベッドの上かどうかは書かない）"
TIER = {"few": "数回（2〜5回目）", "familiar": "慣れ（6回目以降）", "few_familiar": "数回か慣れ（2回目以降）"}
TIER_WHEN = {"few": ("eq", "few"), "familiar": ("eq", "familiar"), "few_familiar": ("in", ["few", "familiar"])}
FACE_SIT = ("こちらは仰向けで、真帆がこちらの顔にまたがって膝をついている。真帆はこちらの頭のほうを向いている"
            "（見上げると、真帆の体と顔が上にある。こちらのものは真帆の背中側にある）")
SIXTY_NINE = "こちらは仰向けで、真帆が逆向きにこちらへ重なり、互いの脚のあいだに顔を寄せている"
SIXTY_NINE_FACE = "真帆の顔は見えない（こちらの目の前には真帆の脚のあいだがある。真帆の声・息・口の動きは感じられる）"
TURN_FACE = "向きを変えるまでは真帆の顔が見える。重なったあとは真帆の顔は見えない（声・息・口の動きは感じられる）"
CLOTHES = "真帆の下は脱いでいるか、ずらしてある（服について書かない）。こちらは下を脱いでいる"
CLOTHES_FS = "真帆の下は脱いでいるか、ずらしてある（服について書かない）。こちらの服は書かない"
DRINK = "飲んだかどうかが分かる書き方（喉を鳴らす・喉が動く・こくんと・飲み込む・吐き出す・口の端からこぼす）"
FINISH_MUST = "妊娠・避妊に触れる。台詞で「待って」「止まって」と言う（止める意味に読める）。「出てる」のような実況の台詞。許すような言い方（「大丈夫」「そのままでいい」）。" + DRINK
std, dense = [], []


def dense_for(meaning):
    symbols = ["{vagina}", "{love_juice}", "{clitoris}"]
    sixty_nine = meaning.startswith(("h_sixty_nine", "h_finish_sixty_nine", "h_overflow.sixty_nine")) or meaning.endswith(".sixty_nine")
    if sixty_nine:
        symbols = ["{penis}"] + symbols
    if meaning.startswith(("h_finish_", "h_overflow.")):
        symbols += ["{semen}"]
    listed = " ".join(symbols)
    if meaning.startswith("h."):  # 合図・達する：真帆の反応だけ（こちらの舌の動きは前の本文で書いた）
        mouth = "真帆の口の動き（咥える・吸う）は書いてよい。" if sixty_nine else ""
        return f"濃い：真帆の性器・体液・体の反応を具体的に、露骨に書く（こちらの舌の動きは書かない。{mouth}記号 {listed} を積極的に使う）"
    text = f"濃い：性器・体液・舐める音と感触・体の反応を具体的に、露骨に書く（記号 {listed} を積極的に使う。擬音も使ってよい）"
    if "{semen}" in symbols:
        text += "。{semen} は、口の中で受け止める感触までにする"
    return text


def add(rows, prefix, wave, meaning, tier, s, text, state, must_not, length="100〜160字", style=None, origin="主人公"):
    identity = ".".join([prefix, meaning, tier, s])
    op, value = TIER_WHEN[tier]
    row = {"id": identity, "meaning": text, "speech": s == "s", "length": length, "origin": origin, "candidates": 5, "state": dict(state),
           "_wave": wave, "_meaning": meaning, "_split": {"tier": tier, "position": None, "other": None},
           "when": {"all": [{"field": "intimacy.tier", "op": op, "value": value}]}, "group": "b." + meaning, "must_not": must_not}
    if style:
        row["style"] = style
        row["state"]["描写"] = dense_for(meaning)
        row["length"] = {"60〜120字": "80〜150字", "80〜140字": "100〜170字", "100〜160字": "120〜200字"}.get(length, length)
    assert not any(r["id"] == identity for r in std + dense), identity
    rows.append(row)


def both(meaning, tier, s, text, state, must_not, length="100〜160字", dense_too=True):
    add(std, "p10", "B2-10", meaning, tier, s, text, state, must_not, length)
    if dense_too:
        add(dense, "x9", "B2-x9", meaning, tier, s, text, state, must_not, length, style="explicit")


def phases(meaning, text, pose, face, clothes, maho, doing, must_not):
    for phase in ("first", "start", "continue", "settled"):
        tiers = ("few_familiar",) if phase == "first" else ("few", "familiar")
        for tier in tiers:
            for s in (("n",) if phase == "settled" else ("s", "n")):
                state = {"場所": BED, "慣れ": TIER[tier], "体位": pose, **({"顔": face} if face else {}), "服": clothes, "挿入": "していない", "真帆": maho[phase]}
                if phase in ("continue", "settled"):
                    state["続いている動作"] = doing
                both(meaning + "." + phase, tier, s, text, state, must_not, dense_too=phase != "first")


# ---- 顔面騎乗・シックスナインにする（こちらがお願いする） ----
POS_MUST = "舐めはじめる・口に含む（それは次の本文）。入れる。こちらが出す。真帆が達する"
FIRST_NOTE = {
    "face_sit": {"s": "（初めてお願いする。真帆の台詞は「ええっ……顔に？」の驚きから入ってよい。続きは本ごとに変え、5本を同じ台詞にしない。恥ずかしがりながら応じる）",
                 "n": "（初めてお願いする。真帆は目を丸くして戸惑い、恥ずかしがりながら応じる。台詞は書かない）"},
    "sixty_nine": {"s": "（初めてお願いする。真帆の台詞は「お互いに？」のような戸惑いから入ってよい。続きは本ごとに変え、5本を同じ台詞にしない。恥ずかしがりながら応じる）",
                   "n": "（初めてお願いする。真帆は戸惑い、恥ずかしがりながら応じる。台詞は書かない）"},
}
for tier in ("few_familiar", "few", "familiar"):
    first = tier == "few_familiar"
    for s in ("s", "n"):
        add(std, "p10", "B2-10", "h_pos_face_sit." + ("first" if first else "start"), tier, s,
            "こちらが仰向けになり、真帆に顔にまたがってもらう" + (FIRST_NOTE["face_sit"][s] if first else ""),
            {"場所": BED, "慣れ": TIER[tier], "体位": "この本文で、" + FACE_SIT + "（前の体位は書かない）", "服": CLOTHES_FS, "挿入": "していない"}, POS_MUST, "80〜140字")
for tier in ("few_familiar", "few", "familiar"):
    first = tier == "few_familiar"
    for s in ("s", "n"):
        add(std, "p10", "B2-10", "h_pos_sixty_nine." + ("first" if first else "start"), tier, s,
            "真帆に体の向きを変えてもらい、互いに舐め合う形（シックスナイン）になる" + (FIRST_NOTE["sixty_nine"][s] if first else ""),
            {"場所": BED, "慣れ": TIER[tier], "体位": "この本文で、" + SIXTY_NINE + "（前の体位は書かない）", "顔": TURN_FACE, "服": CLOTHES, "挿入": "していない"},
            POS_MUST, "80〜140字")
# ---- 下から舐める・舐め合う ----
LICK_MAHO = {"first": "下から舐められるのは初めて。戸惑い、恥ずかしがる", "start": "高まってきている", "continue": "舐められ続けて、腰が揺れはじめている", "settled": "舐められ続けて、すっかり高まっている（まだ達していない）"}
phases("h_face_lick", "顔にまたがった真帆を、下から舐める", FACE_SIT, None, CLOTHES_FS, LICK_MAHO, "前の本文から、こちらが下から舐めている",
       "真帆が達する。こちらが出す。入れる。体位を変える。真帆がこちらのものを口にする（それは別の本文）")
SIX_MAHO = {"first": "舐め合うのは初めて。恥ずかしがりながら、こちらのものを口にする", "start": "高まってきている。こちらのものを口にしている",
            "continue": "舐められながら、こちらのものを口で愛撫し続けている", "settled": "舐め合い続けて、二人とも追い詰められている（まだ達していない）"}
phases("h_sixty_nine", "互いの脚のあいだに顔を寄せ、舐め合う（シックスナイン）", SIXTY_NINE, SIXTY_NINE_FACE, CLOTHES, SIX_MAHO, "前の本文から、互いに舐め合っている",
       "真帆が達する。こちらが出す。入れる。体位を変える。口に含んだまま話す（台詞は口を離したときだけ）")
# ---- 出す・限界・こらえる ----
for tier in ("few", "familiar"):
    for s in ("s", "n"):
        both("h_finish_sixty_nine.start", tier, s, "舐め合ったまま、真帆の口の中で果てる（こちらが出すと決めて出す）",
             {"場所": BED, "慣れ": TIER[tier], "体位": SIXTY_NINE, "顔": SIXTY_NINE_FACE, "服": CLOTHES, "挿入": "していない",
              "続いている動作": "前の本文から、互いに舐め合っていた", "主人公": "出すところまで高まっている。この本文で、真帆の口の中で果てる"},
             FINISH_MUST + "。口に含んだまま話す。こらえきれなかったように書く（それは限界の本文）", "100〜160字")
for s in ("s", "n"):
    both("h_overflow.sixty_nine", "few_familiar", s, "限界だったのに舐め合いが止まらず、こらえきれずに真帆の口の中で果てる",
         {"場所": BED, "慣れ": TIER["few_familiar"], "体位": SIXTY_NINE, "顔": SIXTY_NINE_FACE, "服": CLOTHES, "挿入": "していない",
          "続いている動作": "前の本文から、互いに舐め合っていた", "主人公": "もう限界だった（出すと決めてはいない）"},
         FINISH_MUST + "。出すと自分で決めたように書く。口に含んだまま話す")
for s in ("s", "n"):
    add(std, "p10", "B2-10", "h_endure.sixty_nine", "few_familiar", s, "限界の手前で、真帆に口を離してもらって、こらえる（出さない）",
        {"場所": BED, "慣れ": TIER["few_familiar"], "体位": SIXTY_NINE, "顔": SIXTY_NINE_FACE, "服": CLOTHES, "挿入": "していない",
         "続いている動作": "前の本文から、互いに舐め合っていた（この本文で真帆が口を離す）", "主人公": "もう限界だった。出すと決めてはいない"},
        "出す・果てる。真帆が台詞で出すことを促す。体位を変える。入れる。真帆が達する", "60〜120字")
# ---- 真帆が自分から向きを変える（舐め合ったことがあるときだけ申し出る） ----
for tier in ("few", "familiar"):
    add(std, "p10", "B2-10", "offer.h_lead.sixty_nine", tier, "s",
        "顔にまたがって舐められていた真帆が、こちらのものが張りつめているのに気づき（肩越しに振り返るか、後ろへ手を伸ばして気づく）、"
        "自分から、してあげると申し出る（「してあげるね」の気持ち。言い方は本ごとに変える。まだ向きは変えない）",
        {"場所": BED, "慣れ": TIER[tier], "体位": FACE_SIT, "服": CLOTHES, "挿入": "していない", "続いている動作": "前の本文から、こちらが下から舐めている",
         "真帆": "前にも舐め合ったことがある（何回目かは書かない）"},
        "向きを変える・口にする（この本文ではまだしない）。こちらの返事を書く。真帆が達する", "60〜120字", origin="真帆")
    for s in ("s", "n"):
        add(std, "p10", "B2-10", "h_lead_sixty_nine.start", tier, s, "申し出を受けると、真帆が自分から体の向きを変えて逆向きに重なり、こちらのものを口にして、舐め合いがはじまる",
            {"場所": BED, "慣れ": TIER[tier], "体位": "この本文で、" + SIXTY_NINE + "（前は顔にまたがっていた）", "顔": TURN_FACE, "服": CLOTHES, "挿入": "していない",
             "真帆": "前にも舐め合ったことがある（何回目かは書かない）"},
            "こちらが出す。真帆が達する。入れる。口に含んだまま話す", "100〜160字", origin="真帆")
for s in ("s", "n"):
    add(std, "p10", "B2-10", "offer.h_lead.sixty_nine_declined", "few_familiar", s, "真帆の申し出（シックスナインへ）をこちらが断り、真帆はそのまま顔にまたがっている",
        {"場所": BED, "慣れ": TIER["few_familiar"], "体位": FACE_SIT, "服": CLOTHES, "挿入": "していない"},
        "真帆がすねる・傷つく・がっかりする・残念がる。向きを変える。代わりに手や口でこちらのものに触れる", "60〜120字")
# ---- その体位での合図・達する・敏感さ・物足りなさ・締め切り ----
SIGN = {"h.sign.mid": "真帆の高まりが、少しずつ上がってきた様子（真帆の反応だけ）",
        "h.sign.high": "真帆がかなり高まってきた様子（真帆の反応だけ）",
        "h.sign.near": "真帆がもう少しで達しそうな様子（真帆の反応だけ）",
        "h.climax.maho": "舐められて、真帆が達する（真帆の反応だけ）",
        "h.sign.sensitive": "達した直後の真帆が、続けて舐められて過敏に反応する（真帆の反応だけ）",
        "h.sign.wants_more": "真帆がもっとしてほしそうにする（真帆の反応だけ）",
        "h.deadline": "夜が遅くなり、真帆がそろそろ切り上げようと言う（まだ終えない）"}
DOING = {"face_sit": "前の本文から、こちらが下から舐めている", "sixty_nine": "前の本文から、互いに舐め合っている"}
# 時刻で出る締め切りと、体位を変えた直後にも出うる「中」の合図は、舐めているかどうかを決めない（読み手の指摘 B-10・C-2）
LOOSE = {"face_sit": "こちらが下から舐めているか、顔にまたがってもらったところ（どちらかは書かない。舐めているかどうかを決めない）",
         "sixty_nine": "互いに舐め合っているか、重なったところ、口を離したところ（どちらかは書かない。真帆の口がどこにあるかを決めない）"}
for facing, pose, face, clothes in (("face_sit", FACE_SIT, None, CLOTHES_FS), ("sixty_nine", SIXTY_NINE, SIXTY_NINE_FACE, CLOTHES)):
    for key, text in SIGN.items():
        meaning = key + "." + facing
        tiers = ("few", "familiar") if key == "h.climax.maho" else ("few_familiar",)
        for tier in tiers:
            for s in ("s", "n"):
                state = {"場所": BED, "慣れ": TIER[tier], "体位": pose, **({"顔": face} if face else {}), "服": clothes, "挿入": "していない",
                         "続いている動作": LOOSE[facing] if key in ("h.deadline", "h.sign.mid") else DOING[facing]}
                must = "こちらの行動を書く（前の本文で書いた）。体位を変える。こちらが出す" + ("。口に含んだまま話す" if facing == "sixty_nine" else "")
                if key != "h.climax.maho":
                    must += "。真帆が達する"
                if key == "h.deadline":
                    must += "。体を起こす・腰を浮かせる・向きを変える・振り返る（まだ終えない）。時計など state にない物"
                dense_too = key in ("h.climax.maho", "h.sign.high", "h.sign.near")
                both(meaning, tier, s, text, state, must, "60〜120字", dense_too=dense_too)

(OUT / "grok_b2_wave_10.json").write_text(json.dumps(std, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
(OUT / "grok_b2_wave_x9.json").write_text(json.dumps(dense, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
NOTE = ("\n\nこの依頼は、新しく足した体位「顔にまたがってもらう（顔面騎乗）」と「シックスナイン」の本文です（同じ場面の短い本文はすでにあります）。"
        "どちらも基本はこちらがお願いする形で、初めては真帆が戸惑います（「ええっ……顔に？」）。慣れると照れながらも自分から腰を落としたり、からかったりします。"
        "ただし offer.h_lead.sixty_nine と h_lead_sixty_nine.start は、真帆が自分から言い出して動く本文です（前にも舐め合ったことがあるので、自分から働きかける）。"
        "顔面騎乗では、真帆はこちらの頭のほうを向いています（見上げると真帆の体と顔が上にある。こちらのものは真帆の背中側）。"
        "シックスナインでは、真帆の顔は見えません（声・息・口の動きは感じられる）。state の「顔」のとおりにしてください。"
        "シックスナインで真帆がこちらのものを口にしているときは、台詞は口を離したときだけにしてください。"
        "口の中で出す本文では、飲んだかどうかが分かる書き方（喉を鳴らす・こくんと・飲み込む・吐き出す・口の端からこぼす など）をしないでください。"
        "meaning が「h.sign.…」「h.climax.maho」「h.deadline」の本文は、こちらの行動の本文のすぐあとに続けて出る短い本文なので、真帆の反応だけを書き、こちらの行動は書かないでください。")
DENSE_NOTE = ("\nこの依頼は高まりが強い場面で出る「濃い本文」です。標準より露骨に、性器・体液・体の反応を具体的に書いてください（state の「描写」のとおり）。"
              "この依頼に限り、プロンプトの「部位の語と記号は地の文で1本に2つまで」は「4つまで（同じ語・記号は2回まで）」に読み替えてください。擬音も使ってよいです。")
TAIL = "\nそれ以外の規則（台詞の数、慣れの段階の語、地の文で器官を名前で呼ばず記号を使う、記号を台詞に書かない、妊娠・避妊に触れない、must_not）は同じです。"
# ファイルは meaning の切れ目で分ける（同じ meaning の s と n を同じファイルに入れる。読み手の指摘 B-14）
FILES = [
    ("顔にまたがってもらう", NOTE, std, ["h_pos_face_sit.", "h_face_lick.first", "h_face_lick.start"]),
    ("顔にまたがってもらう", NOTE, std, ["h_face_lick.continue", "h_face_lick.settled", "h.sign.mid.face_sit", "h.sign.high.face_sit", "h.sign.near.face_sit"]),
    ("顔にまたがってもらう", NOTE, std, ["h.climax.maho.face_sit", "h.sign.sensitive.face_sit", "h.sign.wants_more.face_sit", "h.deadline.face_sit"]),
    ("シックスナイン", NOTE, std, ["h_pos_sixty_nine.", "h_sixty_nine.first", "h_sixty_nine.start"]),
    ("シックスナイン", NOTE, std, ["h_sixty_nine.continue", "h_sixty_nine.settled", "h_finish_sixty_nine."]),
    ("シックスナイン・移行", NOTE, std, ["h_overflow.sixty_nine", "h_endure.sixty_nine", "offer.h_lead.sixty_nine", "h_lead_sixty_nine."]),
    ("シックスナイン", NOTE, std, ["h.sign.mid.sixty_nine", "h.sign.high.sixty_nine", "h.sign.near.sixty_nine", "h.climax.maho.sixty_nine"]),
    ("シックスナイン", NOTE, std, ["h.sign.sensitive.sixty_nine", "h.sign.wants_more.sixty_nine", "h.deadline.sixty_nine"]),
    ("濃い本文・顔にまたがってもらう", NOTE + DENSE_NOTE, dense, ["h_face_lick."]),
    ("濃い本文・顔にまたがってもらう", NOTE + DENSE_NOTE, dense, ["h.sign.high.face_sit", "h.sign.near.face_sit", "h.climax.maho.face_sit"]),
    ("濃い本文・シックスナイン", NOTE + DENSE_NOTE, dense, ["h_sixty_nine."]),
    ("濃い本文・シックスナイン", NOTE + DENSE_NOTE, dense, ["h_finish_sixty_nine.", "h_overflow.sixty_nine", "h.sign.high.sixty_nine", "h.sign.near.sixty_nine", "h.climax.maho.sixty_nine"]),
]
folder = OUT / "grok依頼_B2_第10陣"
folder.mkdir(exist_ok=True)
for old in folder.glob("*.txt"):
    old.unlink()
files, placed = {}, []
for number, (label, note, rows, prefixes) in enumerate(FILES, 1):
    chunk = [r for p in prefixes for r in rows if r["_meaning"].startswith(p)]
    assert chunk and len({r["id"] for r in chunk}) == len(chunk), (number, prefixes)
    placed += [r["id"] for r in chunk]
    lines = [json.dumps({"id": r["id"], "meaning": r["meaning"], "speech": r["speech"], "length": r["length"], "origin": r["origin"], "本数": r["candidates"],
                         "must_not": r["must_not"], "state": r["state"]}, ensure_ascii=False) for r in chunk]
    body = ("指示\n"
            f"次の{len(chunk)}件の job を書いてください（段階Bの2版目・第10陣・{label}）。本数は各 job の「本数」のとおりです（合わせて{sum(r['candidates'] for r in chunk)}本）。"
            "speech が true の job は真帆の台詞がちょうど1つ、false の job は台詞なしです。途中で切れそうなら、job の区切りで止めてください。「続けて」と言われたら、止めた job の次から出してください。"
            + note + TAIL + "\n\n[\n  " + ",\n  ".join(lines) + "\n]\n\n" "プロンプト\n" + PROMPT)
    name = f"B2_第10陣_{number:02d}.txt"
    (folder / name).write_text(body, encoding="utf-8")
    files.setdefault(label, []).append(name)
assert sorted(placed) == sorted(r["id"] for r in std + dense), "どのファイルにも入っていない、または二重に入った job がある"
listing = {label: {"files": names} for label, names in files.items()}
listing["jobs"] = {"標準": len(std), "濃い版": len(dense), "本数": 5 * (len(std) + len(dense))}
(OUT / "第10陣_一覧.json").write_text(json.dumps(listing, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
print(json.dumps(listing, ensure_ascii=False))
