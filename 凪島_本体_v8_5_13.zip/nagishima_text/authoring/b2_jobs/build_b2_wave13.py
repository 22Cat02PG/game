"""v8.2.17（ユーザー 2026-09-29 03:09「足りてない部分の依頼投げて」）の grok への依頼（Opus）。

- 第13陣（p13.、標準）と濃い版（x12.）：限界のまま「一気に奥まで入れる」で、奥まで届いた途端にこらえきれずに果てる本文（h_overflow.insert_deep）。
- これまでは専用の本文がなく、「ゆっくり入れる」で果てる本文（h_overflow.insert の x6・o11）のうち入り口で果てたと書いていないものを写して使っていた（v8.2.7、tools/build_intimacy_release.py の deep_overflow_texts）。
- 一気に奥まで入れるのは数回から、真帆の高まりが「高い」以上のとき（低いと止められる）。入れた途端に真帆も達したときは、この本文のあとに h.climax.together が出る。
出力：grok_b2_wave_13.json・grok_b2_wave_x12.json、grok依頼_B2_第13陣/、第13陣_一覧.json
"""
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
PROMPT = (OUT / "grokプロンプト_v3_0.txt").read_text(encoding="utf-8")
BED = "二人の個室のどちらか（どちらの部屋か、ベッドの上かどうかは書かない）"
TIER = {"few": "数回（2〜5回目）", "familiar": "慣れ（6回目以降）", "few_familiar": "数回か慣れ（2回目以降）"}
TIER_WHEN = {"few": [{"field": "intimacy.tier", "op": "eq", "value": "few"}], "familiar": [{"field": "intimacy.tier", "op": "eq", "value": "familiar"}],
             "few_familiar": [{"field": "intimacy.tier", "op": "in", "value": ["few", "familiar"]}]}
FACING = {"face": ({"体位": "向かい合っている（寝ているか座っているか、どちらが上かは書かない）"}, ["{penis}", "{vagina}", "{semen}", "{love_juice}", "{clitoris}", "{nipple}", "{breasts}"]),
          "back": ({"体位": "真帆がこちらに背を向けている（寝ているか立っているか、どちらが上かは書かない）",
                    "顔": "真帆の顔は見えない（肩越しに振り返るときだけ、横顔を書いてよい）"}, ["{penis}", "{vagina}", "{semen}", "{love_juice}"])}
MEANING = "限界まで高まっていたこちらが、真帆の奥まで一気に入れた途端、こらえきれずに奥で果てる"
MAHO = {"few": "かなり高まっていて、奥まで受け入れられるほど濡れている（まだ達していない）。一気に奥まで来られるのには、まだ慣れていない",
        "familiar": "かなり高まっていて、奥まで受け入れられるほど濡れている（まだ達していない）。一気に奥まで来られるのを待っていた",
        "few_familiar": "かなり高まっていて、奥まで受け入れられるほど濡れている（まだ達していない）"}
MUST = ("妊娠・避妊に触れる。真帆が止める。台詞で「待って」「止まって」と言う（止める意味に読める）。中・外に触れる台詞。「入った」「出てる」のような実況の台詞。"
        "出すと自分で決めたように書く。入り口・浅いところで果てる（根元まで一気に入ってから果てる）。ゆっくり入れる。入れたあと動き始める（奥に届いた直後に果てる）。"
        "真帆が達する（達したときは次の本文で書く）。体位を変える。上下を決める語（突き上げる・押し倒す・覆いかぶさる・腰を落とさせる）")
std, dense = [], []


def add(rows, prefix, tier, facing, s):
    extra, symbols = FACING[facing]
    identity = ".".join([prefix, "h_overflow.insert_deep", tier, facing, s])
    state = {"場所": BED, "慣れ": TIER[tier], **extra, "服": "真帆の下は、下着をずらしてあるか脱いでいる（下着について書かない）。こちらは下を脱いでいる",
             "挿入": "この本文で、一気に根元まで入れる（奥に届いた途端に果てる）", "真帆": MAHO[tier],
             "主人公": "もう限界だった。こらえずに、一気に奥まで入れた（出すと決めてはいない）"}
    row = {"id": identity, "meaning": MEANING, "speech": s == "s", "length": "100〜160字", "origin": "主人公", "candidates": 5, "state": state,
           "_wave": "B2-13" if prefix == "p13" else "B2-x12", "_meaning": "h_overflow.insert_deep", "_split": {"tier": tier, "position": None, "other": facing},
           "when": {"all": TIER_WHEN[tier] + [{"field": "intimacy.facing", "op": "eq", "value": facing}]}, "group": "b.h_overflow.insert_deep", "must_not": MUST}
    if prefix == "x12":
        row["style"] = "explicit"
        row["length"] = "120〜200字"
        row["state"]["描写"] = "濃い：性器・体液・結合部の音と感触・体の反応を具体的に、露骨に書く（記号 " + " ".join(symbols) + " を積極的に使う。擬音も使ってよい）"
        if "{nipple}" in symbols:
            row["state"]["服"] += "。真帆の上の服は、着ているかめくれているか決まっていない（{nipple}・乳輪・胸の肌を直接書くのは、5本のうち2本まで）"
    assert not any(r["id"] == identity for r in std + dense), identity
    rows.append(row)


for facing in ("face", "back"):
    for s in ("s", "n"):
        add(std, "p13", "few_familiar", facing, s)
        for tier in ("few", "familiar"):
            add(dense, "x12", tier, facing, s)

(OUT / "grok_b2_wave_13.json").write_text(json.dumps(std, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
(OUT / "grok_b2_wave_x12.json").write_text(json.dumps(dense, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
NOTE = ("\n\nこの依頼は、限界のまま「一気に奥まで入れる」を選んだときの本文です（今は「ゆっくり入れる」で果てる本文を写して使っています）。"
        "こちらはもう限界で、こらえずに、真帆の奥まで一息に入れます。根元まで入って奥に届いたその瞬間に、こらえきれずに奥で果てます。"
        "入り口や浅いところで果てるのではなく、一気に奥まで届いた勢いと、その直後に崩れる流れを書いてください。入れたあとに動く描写は書きません。"
        "真帆はかなり高まっていて、一気に奥まで来られた衝撃と、こちらがすぐに果てたことの両方に反応します（驚き・照れ・からかい・受け止める、など。慣れの段階で変える）。"
        "真帆が達したかどうかは書かないでください（達したときは、次に別の本文が出ます）。"
        "体位は、どちらが上かを決めない書き方にしてください（「腰を引き寄せる」「一息に沈める」「根元まで押し込む」など。突き上げる・押し倒すは使わない）。"
        "背を向けた体位では、真帆の顔は見えません（state の「顔」のとおり）。中で果てる本文なので、妊娠・避妊に触れないでください。")
DENSE_NOTE = ("\nid が x12. で始まる job は、高まりが強い場面で出る「濃い本文」です。標準より露骨に、性器・体液・結合部・体の反応を具体的に書いてください（state の「描写」のとおり）。"
              "この job に限り、プロンプトの「部位の語と記号は地の文で1本に2つまで」は「4つまで（同じ語・記号は2回まで）」に読み替えてください。擬音も使ってよいです。")
TAIL = "\nそれ以外の規則（台詞の数、慣れの段階の語、地の文で器官を名前で呼ばず記号を使う、記号を台詞に書かない、妊娠・避妊に触れない、must_not）は同じです。"
folder = OUT / "grok依頼_B2_第13陣"
folder.mkdir(exist_ok=True)
for old in folder.glob("*.txt"):
    old.unlink()
files = []
for number, (label, rows, note) in enumerate((("一気に奥まで入れて果てる", std, NOTE), ("濃い本文・一気に奥まで入れて果てる", dense, NOTE + DENSE_NOTE)), 1):
    lines = [json.dumps({"id": r["id"], "meaning": r["meaning"], "speech": r["speech"], "length": r["length"], "origin": r["origin"], "本数": r["candidates"],
                         "must_not": r["must_not"], "state": r["state"]}, ensure_ascii=False) for r in rows]
    body = ("指示\n"
            f"次の{len(rows)}件の job を書いてください（段階Bの2版目・第13陣・{label}）。本数は各 job の「本数」のとおりです（合わせて{sum(r['candidates'] for r in rows)}本）。"
            "speech が true の job は真帆の台詞がちょうど1つ、false の job は台詞なしです。途中で切れそうなら、job の区切りで止めてください。「続けて」と言われたら、止めた job の次から出してください。"
            + note + TAIL + "\n\n[\n  " + ",\n  ".join(lines) + "\n]\n\n" "プロンプト\n" + PROMPT)
    name = f"B2_第13陣_{number:02d}.txt"
    (folder / name).write_text(body, encoding="utf-8")
    files.append({"file": name, "label": label, "jobs": len(rows), "本数": sum(r["candidates"] for r in rows)})
listing = {"files": files, "jobs": {"標準": len(std), "濃い版": len(dense), "本数": sum(r["candidates"] for r in std + dense)}}
(OUT / "第13陣_一覧.json").write_text(json.dumps(listing, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
print(json.dumps(listing, ensure_ascii=False))
