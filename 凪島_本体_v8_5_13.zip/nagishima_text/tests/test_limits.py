from copy import deepcopy
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from nagishima import clock
from nagishima.authoring import publish
from nagishima.budget import estimate, PUBLICATION_BUDGET
from nagishima.codec import digest, read_json, write_json, bytes_digest
from nagishima.conditions import latest_memory
from nagishima.content import FILES, Pack
from nagishima.engine import Engine
from nagishima.errors import GameError
from tests.test_runtime import RuntimeCase
from tests.support import press, do, page, dismiss, activity, stage_two, stage_three, stage_four


def edited_pack(source, destination, change):
    documents = {name: read_json(source.path / name, 512 * 1024 * 1024) for name in FILES}
    change(documents)
    destination.mkdir(parents=True, exist_ok=True)
    for name, value in documents.items(): write_json(destination / name, value)
    manifest = deepcopy(source.manifest)
    manifest["files"] = {name: bytes_digest((destination / name).read_bytes()) for name in FILES}
    manifest["control_sha256"] = digest({"catalog": documents["catalog.json"], "actions": documents["actions.json"]})
    write_json(destination / "release.json", manifest)
    return destination


class BoundaryTests(RuntimeCase):
    def test_start_condition_does_not_cancel_ongoing_action(self):
        def change(data):
            head = next(a for a in data["actions.json"] if a["id"] == "head")
            head["when"] = {"all": [head["when"], {"field": "experience.head.count", "op": "eq", "value": 0}]}
        builtin = self.directory / "fixture"
        edited_pack(self.e.pack, builtin / "base", change)
        self.e = Engine(self.directory / "separate", builtin=builtin, autosave=False)
        stage_two(self.e); do(self.e, "touch", "near")
        press(self.e, "touch.head"); press(self.e, "touch.head")
        self.assertEqual(self.e.snapshot()["contacts"][0]["continues"], 1)
        press(self.e, "end.head"); self.unavailable("touch.head", "action_conditions")

    def test_join_failure_leaves_choice_and_effects_unchanged(self):
        scene = deepcopy(self.e.pack.scenes["shared_place"]); scene["revision"] += 1
        scene["nodes"][1]["join"] = {"field": "local.place", "op": "eq", "value": "table"}
        publish(self.e.pack, self.directory / "releases", "join_guard", [], scenes=[scene])
        self.e.adopt_release("join_guard")
        stage_two(self.e); do(self.e, "talk", "begin.shared_place")
        self.unavailable("scene.window", "join")
        self.assertEqual(self.e.snapshot()["scene"]["locals"], {"place": "unset", "visits": 0})
        press(self.e, "scene.table"); press(self.e, "scene.confirm")

    def test_exact_automatic_transition_budget(self):
        for count in (32, 33):
            scene = deepcopy(self.e.pack.scenes["two_cups"])
            scene["id"], scene["start"] = "automatic_" + str(count), "step0"
            auto = []
            for i in range(count):
                n = deepcopy(scene["nodes"][0]); n.update(id="step" + str(i), choices=[], auto="step" + str(i + 1) if i + 1 < count else "ask")
                auto.append(n)
            scene["nodes"] = auto + scene["nodes"]
            publish(self.e.pack, self.directory / "releases", "automatic_pack" + str(count), [], scenes=[scene])
            self.e.adopt_release("automatic_pack" + str(count))
            page(self.e, "talk")
            if count == 32:
                press(self.e, "begin." + scene["id"])
                self.assertEqual(self.e.snapshot()["scene"]["visit"], 33)
                press(self.e, "scene.cancel")
            else: self.unavailable("begin." + scene["id"], "auto_limit")

    def test_terminal_scene_uses_common_private_entry(self):
        scene = deepcopy(self.e.pack.scenes["two_cups"])
        scene["id"] = "quiet_invitation"
        scene["requires"] = {"all": [{"field": "together", "op": "eq", "value": True}, {"field": "relation.stage", "op": "ge", "value": 3}, {"field": "mode", "op": "eq", "value": "normal"}]}
        scene["resume"] = scene["requires"]
        scene["nodes"][-1]["enter"] = [{"op": "private.begin"}]
        publish(self.e.pack, self.directory / "releases", "invitation", [], scenes=[scene])
        self.e.adopt_release("invitation"); stage_three(self.e)
        do(self.e, "talk", "begin.quiet_invitation"); press(self.e, "scene.tea"); press(self.e, "scene.remember")
        self.assertEqual(self.e.snapshot()["mode"], "private")
        self.assertEqual(len(self.e.snapshot()["activities"]), 1)
        self.assertIsNone(self.e.snapshot()["scene"])

    def test_scene_owned_cleanup_does_not_end_persistent_contact(self):
        scene = deepcopy(self.e.pack.scenes["shared_place"]); scene["revision"] += 1
        scene["nodes"][0]["enter"] = [{"op": "action", "id": "head", "lifetime": "scene"}]
        publish(self.e.pack, self.directory / "releases", "owned", [], scenes=[scene])
        self.e.adopt_release("owned"); stage_two(self.e)
        do(self.e, "touch", "near"); press(self.e, "touch.hands")
        do(self.e, "talk", "begin.shared_place"); press(self.e, "scene.cancel")
        self.assertEqual(["hands"], [c["action_id"] for c in self.e.snapshot()["contacts"]])

    def test_declared_save_budget_and_oversized_registry_rejected(self):
        self.assertLess(self.e.pack.save_budget["save_bytes_upper_bound"], PUBLICATION_BUDGET)
        huge = deepcopy(self.e.pack.catalog)
        for i in range(128):
            huge["memory_specs"]["wide" + str(i)] = {"facts": list(huge["facts"]), "summary": {"field" + str(j): {"type": "string", "max_length": 200} for j in range(16)}}
            huge["memory_kinds"].append("wide" + str(i))
        with self.assertRaises(GameError): estimate(huge, self.e.pack.actions)

    def test_invalid_catalog_and_nested_reference_rejected_before_play(self):
        def invalid_catalog(data): data["catalog.json"]["goals"]["care"]["when"] = {"field": "unregistered", "op": "eq", "value": True}
        bad = edited_pack(self.e.pack, self.directory / "bad_catalog", invalid_catalog)
        with self.assertRaises(GameError): Pack(bad)
        def invalid_ref(data):
            scene = next(s for s in data["scenes.json"] if s["id"] == "shared_place")
            scene["nodes"][1]["choices"][0]["effects"][-1]["summary"] = {"place": {"ref": "unregistered"}}
        bad = edited_pack(self.e.pack, self.directory / "bad_reference", invalid_ref)
        with self.assertRaises(GameError): Pack(bad)

    def test_memory_summary_and_parked_owner_tampering_rejected(self):
        activity(self.e, "tea"); do(self.e, "talk", "begin.two_cups"); press(self.e, "scene.pause"); self.e.save()
        path = self.e.storage.slot_path("slot01"); original = read_json(path)
        for kind in ("summary", "owner", "page", "offer"):
            value = deepcopy(original); s = value["payload"]["state"]
            if kind == "summary": s["memories"]["recent"][0]["choice_summary"]["invented"] = "invented"
            elif kind == "owner": s["suspended"][0]["saved_frame"]["question_owner"] = "scene.wrong"
            elif kind == "page": value["payload"]["page"] = [{}, 0]
            else:
                s["offer"] = {"id": "offer.fake", "kind": "unregistered", "cooldown_group": "fake", "source_goal": None, "started_at": s["world"]["now"], "accept_action": "offer.accept", "decline_action": "offer.decline"}
            value["sha256"] = digest(value["payload"]); write_json(path, value)
            before = self.e.snapshot()
            with self.assertRaises(GameError): self.e.load()
            self.assertEqual(before, self.e.snapshot())

    def test_larger_text_pool_does_not_change_gameplay(self):
        base = self.e.pack
        added = [{"id": "bulk.text" + str(i), "meaning": "talk.start", "when": {"all": []}, "slots": [], "group": "bulk.group" + str(i % 17), "body": "真帆は、同じ時間に話せることがうれしくて、落ち着いて言葉を返した。", "fallback": False} for i in range(2000)]
        publish(base, self.directory / "releases", "bulk", [], base_texts=added)
        other = Engine(self.directory, seed=37, release="bulk", autosave=False)
        for _ in range(10):
            do(self.e, "touch", "touch.talk"); do(other, "touch", "touch.talk")
        stage_three(self.e); stage_three(other)
        for key in ("world", "actors", "relation", "contacts", "experience", "facts", "knowledge", "habits", "progress", "promises", "intention", "cooldowns", "last_goal", "history"):
            self.assertEqual(self.e.snapshot()[key], other.snapshot()[key], key)

    def test_same_minute_memory_uses_numeric_order(self):
        activity(self.e, "tea")
        state = self.e.snapshot(); first = deepcopy(state["memories"]["recent"][0]); last = deepcopy(first)
        first["id"], last["id"] = "memory.99", "memory.100"
        state["memories"] = {"recent": [first, last], "pinned": [], "summaries": {}}
        self.assertEqual(latest_memory(state, "tea")["id"], "memory.100")

    def test_compiled_schema_still_rejects_malformed_saves(self):
        activity(self.e, "tea")
        self.e.save()
        path = self.e.storage.slot_path("slot01")
        original = read_json(path)
        for case in ("bool_as_int", "range", "name_length", "extra", "property_name", "array_limit", "nullable", "pattern"):
            with self.subTest(case=case):
                value = deepcopy(original)
                state = value["payload"]["state"]
                if case == "bool_as_int": state["world"]["seed"] = True
                elif case == "range": state["relation"]["stage"] = 5
                elif case == "name_length": state["actors"]["player"]["name"] = "名" * 21
                elif case == "extra": state["world"]["unregistered"] = 1
                elif case == "property_name": state["facts"]["INVALID"] = state["facts"]["player.drink"]
                elif case == "array_limit": state["memories"]["recent"] = state["memories"]["recent"][:1] * 257
                elif case == "nullable": state["scene"] = []
                else: value["payload"]["frame"]["id"] = "INVALID"
                value["sha256"] = digest(value["payload"])
                write_json(path, value)
                before = self.e.snapshot()
                with self.assertRaises(GameError): self.e.load()
                self.assertEqual(before, self.e.snapshot())

    def test_leap_day_and_year_crossing_anniversary_windows(self):
        original = clock.minutes("2040-02-29T12:00")
        self.assertEqual(clock.format_time(clock.anniversary_day(original, 2041)), "2041-02-28 00:00")
        state = self.e.snapshot(); state["relation"]["dating_since"] = clock.minutes("2038-12-31T12:00"); state["world"]["now"] = clock.minutes("2040-01-07T07:30")
        self.assertEqual(clock.anniversary_window(state, "dating"), {"year": 2039, "late_days": 7, "available": True})
        state["world"]["now"] += 1440
        self.assertIsNone(clock.anniversary_window(state, "dating"))


class LongPlayTests(RuntimeCase):
    def test_memory_limits_and_anniversary_through_public_play(self):
        stage_four(self.e)
        day0 = self.e.snapshot()["relation"]["dating_since"]
        first = self.e.snapshot()["memories"]["recent"][0]
        do(self.e, "memories", "pin." + first["id"])
        do(self.e, "talk", "begin.remember_tea"); press(self.e, "scene.pause")
        parked = self.e.snapshot()["suspended"][0]
        for i in range(260):
            if i % 10 == 0: do(self.e, "main", "sleep")
            activity(self.e, "tea")
        state = self.e.snapshot()
        self.assertEqual(len(state["memories"]["recent"]), 256)
        self.assertEqual(state["memories"]["pinned"][0], first)
        self.assertEqual(state["suspended"][0]["memories"], parked["memories"])
        self.assertGreaterEqual(state["memories"]["summaries"]["tea"]["count"], 260)
        self.assertLessEqual(len(state["gallery"]), 128)
        self.assertLessEqual(len(state["history"]), 1024)
        self.e.save(); before = self.e.snapshot(); self.e.load(); self.assertEqual(before, self.e.snapshot())
        anniversary = clock.anniversary_day(day0, clock.date_time(day0).year + 1)
        while self.e.snapshot()["world"]["now"] // 1440 < anniversary // 1440: do(self.e, "main", "sleep")
        do(self.e, "talk", "begin.anniversary_dating"); press(self.e, "scene.celebrate")
        self.assertEqual(self.e.snapshot()["memories"]["summaries"]["anniversary_dating"]["count"], 1)
        page(self.e, "talk"); self.unavailable("begin.anniversary_dating", "scene_conditions")


if __name__ == "__main__": unittest.main()
