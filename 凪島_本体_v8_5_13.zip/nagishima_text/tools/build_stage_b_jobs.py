"""Validate the Opus-authored Stage B jobs without rewriting their source files."""
import json
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from nagishima.content import Pack, validate_text

COUNTS = {1: 118, 2: 150, 3: 95}
IDENTIFIER = re.compile(r"[a-z][a-z0-9_.-]*\Z", re.ASCII)


def validate_jobs(root=ROOT):
    root = Path(root)
    pack = Pack(root / "content/releases/interaction_009")
    seen = set()
    counts = {}
    for wave, expected in COUNTS.items():
        path = root / "authoring/b_jobs" / f"grok_wave_{wave}.json"
        rows = json.loads(path.read_text(encoding="utf-8"))
        assert type(rows) is list and len(rows) == expected, (path, len(rows))
        counts[wave] = len(rows)
        for row in rows:
            identity = row["id"]
            meaning = row["_meaning"]
            assert IDENTIFIER.fullmatch(identity) and identity not in seen, identity
            seen.add(identity)
            assert identity.startswith(f"b{wave}."), identity
            assert row["_wave"] == wave and meaning in pack.meanings, identity
            assert row["group"] == "b." + meaning, identity
            assert row["candidates"] in (5, 7), identity
            assert type(row["must_not"]) is str and row["must_not"].strip(), identity
            sample = {"id": identity + ".v1", "meaning": meaning, "when": row["when"],
                      "slots": [], "group": row["group"], "body": "試験用の仮本文。", "fallback": False}
            validate_text(sample, pack.registry, pack.meanings, pack.intimacy)
    assert len(seen) == 363
    return counts


if __name__ == "__main__":
    print("grok jobs validated:", validate_jobs())
