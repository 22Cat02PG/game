"""v8.5.1（ユーザー 2026-10-08「君はイベントエッチのほう進めて」）：010 だけ。段階C の二歩目：浴室のイベント（イベントの型）。
仕様 docs/凪島_段階C_仕様_2026-10-08.md の第7節・第17節。"""
import copy
import json
import unittest
from pathlib import Path

from nagishima.content import Pack
from nagishima.errors import GameError
from nagishima.event_rules import EventRules
from tools.run_stage_b_routes import Route

ROOT = Path(__file__).resolve().parents[1]
P009 = Pack(ROOT / "content/releases/interaction_009")
P010 = Pack(ROOT / "content/releases/interaction_010")


def bath_route(affinity=80, desire=70, tier="familiar", hour=20, minute=0, seed=8):
    route = Route(seed, hour=hour, minute=minute, tier=tier, release="interaction_010", dinner=False, bath=True)  # 夕食は済ませておく（v8.5.2 から、夕食の時間帯は台所のイベントになる）
    state = route.engine._state
    state["affinity"]["value"], state["desire"] = affinity, desire
    route.engine._install_choices()
    return route


def meanings(view):
    return [b["meaning"] for b in view["blocks"]]


def ids(view):
    return [c["id"] for c in view["choices"]]


def until_notice(route, key="event.pre.washed_body", limit=10):
    for _ in range(limit):
        view = route.choose(key)
        if any(m.startswith("ev.bath.notice.") for m in meanings(view)):
            return view
    raise AssertionError("気づかない")


class V851(unittest.TestCase):
    def test_009_unchanged(self):
        self.assertIsNone(P009.intimacy.events)
        self.assertFalse(any(m.startswith("ev.") for m in P009.meanings))

    def test_rules(self):
        bath = P010.intimacy.events.events["bath"]
        self.assertEqual(list(bath.positions), ["stand_face", "stand_back", "tub_lap"])
        self.assertEqual([r["id"] for r in bath.foreplay], ["soap", "maho_hand", "chest"])
        self.assertEqual(bath.offer, frozenset({"invite", "tease"}))
        for meaning in bath.meanings():
            self.assertIn(meaning, P010.meanings)
        for key in ("event.active", "event.kind", "event.phase", "event.position", "event.inserted", "event.step", "event.last", "event.maho.band", "event.player.band", "event.count"):
            self.assertIn(key, P010.registry.fields)

    def test_rules_reject_bad_data(self):
        raw = json.loads((ROOT / "content/releases/interaction_010/intimacy.json").read_text(encoding="utf-8"))["events"]
        EventRules(copy.deepcopy(raw))
        bad = copy.deepcopy(raw)
        bad["bath"]["pre"]["notice"]["order"].pop()
        with self.assertRaises(GameError):
            EventRules(bad)
        bad = copy.deepcopy(raw)
        bad["unknown_place"] = copy.deepcopy(raw["bath"])  # 入口のないイベント
        with self.assertRaises(GameError):
            EventRules(bad)
        bad = copy.deepcopy(raw)
        bad["bath"]["pre"]["notice"]["offer"] = ["unknown"]
        with self.assertRaises(GameError):
            EventRules(bad)

    def test_bath_full_flow(self):
        """一緒に入る → 洗い合う → 真帆が気づく（誘う）→ まかせる → 体位 → 前戯（自動の順）→ 入れる → 動く → 果てる → 湯上がり。記録は普段のエッチと同じ。"""
        route = bath_route()
        before = copy.deepcopy(route.engine.snapshot()["intimacy_history"])
        view = route.choose("bath.invite")
        self.assertIn("ev.bath.begin", meanings(view))
        self.assertEqual(view["page_title"], "浴室")
        self.assertEqual(view["status"]["player_location"], "浴室")
        self.assertIn("event.leave", ids(view))
        self.assertNotIn("sleep", ids(view))
        view = until_notice(route)
        self.assertIn("ev.bath.notice.invite", meanings(view))
        self.assertEqual(ids(view), ["event.accept", "event.decline"])
        view = route.choose("event.accept")
        self.assertIn("ev.bath.offer.accept", meanings(view))
        self.assertEqual(ids(view), ["event.pos.stand_face", "event.pos.stand_back", "event.pos.tub_lap"])
        view = route.choose("event.pos.tub_lap")
        self.assertEqual(ids(view), ["event.next"])  # 前戯を一つ進めるまでは入れられない
        view = route.choose("event.next")
        self.assertIn("ev.bath.fore.soap", meanings(view))
        self.assertEqual(ids(view), ["event.next", "event.insert"])
        route.choose("event.next")
        view = route.choose("event.next")
        self.assertIn("ev.bath.fore.chest", meanings(view))
        self.assertEqual(ids(view), ["event.insert"])
        view = route.choose("event.insert")
        self.assertIn("event.move.slow", ids(view))
        self.assertNotIn("event.insert", ids(view))
        for _ in range(20):
            state = route.engine.snapshot()
            if state["event_play"]["climaxes"] and "event.finish.inside" in ids(route.engine.get_view()):
                break
            view = route.choose("event.touch.kiss" if state["event_play"]["player"] >= 80 else "event.move.slow")
        view = route.choose("event.finish.inside")
        self.assertEqual(meanings(view)[-2:], ["ev.bath.finish.inside", "ev.bath.end.satisfied"])
        state = route.engine.snapshot()
        self.assertIsNone(state["event_play"])
        hist = state["intimacy_history"]
        self.assertEqual(hist["count"], before["count"] + 1)
        self.assertEqual(hist["by_entry"]["event"], 1)
        self.assertEqual(hist["last_result"], "satisfied")
        self.assertEqual(hist["finishes"], before["finishes"] + 1)
        self.assertGreater(hist["lewdness"], before["lewdness"])
        self.assertEqual(state["stamina"]["value"], 2)
        self.assertEqual(state["actors"]["player"]["location"], "living_room")
        self.assertTrue(state["bath"]["together"])
        self.assertEqual(state["bath"]["together_count"], 1)
        self.assertEqual(state["actors"]["maho"]["outfit"], "room")
        route.engine.save("slot03")
        route.engine.load("slot03")  # by_entry に event を持つ保存を読める
        route.close()

    def test_shy_and_leave(self):
        """慣れの浅いうち（数回）で親密度が低く、欲求が press に届かないと、気づいても気まずく笑って背中に戻る（エッチへは移らない）。上がれば湯上がり。
        （欲求が invite に届かないと、数回のうちは一緒に入る誘いそのものを断られる）"""
        route = bath_route(affinity=50, desire=70, tier="few")
        route.choose("bath.invite")
        view = until_notice(route)
        self.assertIn("ev.bath.notice.shy", meanings(view))
        self.assertIn("event.leave", ids(view))
        self.assertNotIn("event.accept", ids(view))
        desire = route.engine.snapshot()["desire"]
        view = route.choose("event.leave")
        self.assertIn("ev.bath.leave", meanings(view))
        state = route.engine.snapshot()
        self.assertIsNone(state["event_play"])
        self.assertEqual(state["intimacy_history"]["by_entry"].get("event", 0), 0)
        self.assertGreater(state["desire"], desire)  # 一緒に入った欲求の上がり（エッチまで進まなかった回）
        self.assertEqual(state["bath"]["together_count"], 1)
        route.close()

    def test_decline_then_no_more_notice(self):
        route = bath_route()
        route.choose("bath.invite")
        until_notice(route)
        view = route.choose("event.decline")
        self.assertIn("ev.bath.offer.decline", meanings(view))
        view = route.choose("event.pre.hug")
        self.assertFalse(any(m.startswith("ev.bath.notice.") for m in meanings(view)))  # 気づくのは一度だけ
        self.assertIn("event.leave", ids(view))
        route.close()

    def test_timeout(self):
        """浴室は45分まで。エッチの途中で過ぎたら「のぼせちゃう」で上がり、回は数える（達していなければ満たされない回）。"""
        route = bath_route()
        route.choose("bath.invite")
        until_notice(route)
        route.choose("event.accept")
        route.choose("event.pos.stand_face")
        route.choose("event.next")
        route.choose("event.insert")
        view = None
        for _ in range(30):
            if not route.engine.snapshot()["event_play"]:
                break
            view = route.choose("event.touch.hug")
        self.assertIn("ev.bath.timeout", meanings(view))
        state = route.engine.snapshot()
        self.assertIsNone(state["event_play"])
        self.assertEqual(state["intimacy_history"]["by_entry"]["event"], 1)
        self.assertEqual(state["actors"]["player"]["location"], "living_room")
        route.close()

    def test_save_load_during_event(self):
        route = bath_route()
        route.choose("bath.invite")
        until_notice(route)
        route.choose("event.accept")
        route.choose("event.pos.stand_back")
        route.engine.save("slot02")
        route.engine.load("slot02")
        play = route.engine.snapshot()["event_play"]
        self.assertEqual((play["phase"], play["position"]), ("foreplay", "stand_back"))
        route.choose("event.next")
        route.close()


if __name__ == "__main__":
    unittest.main()
