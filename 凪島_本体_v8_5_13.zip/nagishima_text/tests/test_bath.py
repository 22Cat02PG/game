"""風呂（v8.2.0、3回目の試運転の指摘4）の試験。公開の選択肢から確かめる（時刻・関係・欲求などの準備だけ内部で行う）。"""
import unittest

from tools.run_stage_b_routes import Route


def meanings(route):
    return [b["meaning"] for b in route.engine.get_view()["blocks"]]


def choices(route):
    return {c["id"]: c for c in route.engine.get_view()["choices"]}


def prepare(route, **values):
    """準備：関係の段階・欲求などを内部で合わせる（判定する操作は公開の選択肢）。"""
    state = route.engine._state
    for key, value in values.items():
        if key == "stage":
            relation = state["relation"]
            relation["stage"], relation["milestones"] = value, relation["milestones"][:value]
            if value < 3: relation["dating_since"] = None
            if value < 4: relation["life_since"] = None
        else:
            state[key] = value
    route.engine._install_choices()


class BathTests(unittest.TestCase):
    def route(self, *args, **kwargs):
        kwargs.setdefault("bath", True)  # 風呂を済ませた準備をしない
        route = Route(*args, **kwargs)
        self.addCleanup(route.close)
        return route

    def test_auto_bath_once_a_day_with_status_and_after_glow(self):
        route = self.route(3, hour=19, minute=50, day_offset=2)  # v8.2.30：風呂は 20:00 から（21:00 から早めた）
        self.assertEqual(route.engine.get_view()["status"]["bath"], "20:00ごろ（手が空いたら入る）")
        route.choose("wait.30")
        self.assertEqual(meanings(route), ["system.waited", "life.bath"])
        state = route.engine.snapshot()
        self.assertTrue(state["actors"]["player"]["location"] == state["actors"]["maho"]["location"] == "living_room")
        self.assertTrue(route.engine.get_view()["status"]["bath"].startswith("湯上がり（"))
        route.choose("wait.120")
        self.assertNotIn("life.bath", meanings(route))  # 1日1回
        self.assertEqual(route.engine.get_view()["status"].get("bath"), "済み")

    def test_invite_refused_before_lovers(self):
        route = self.route(3, hour=19, minute=40, day_offset=2)
        prepare(route, stage=2, desire=0)
        route.choose("bath.invite")
        self.assertEqual(meanings(route), ["life.bath.invite.refuse"])
        self.assertNotIn("bath.invite", choices(route))  # その日は一度だけ
        route.choose("wait.30")
        self.assertIn("life.bath", meanings(route))  # 断られても、時間になったら一人で入る

    def test_invite_shy_before_first_time(self):
        route = self.route(3, hour=20, minute=5, day_offset=2, tier="first")
        route.choose("bath.invite")
        self.assertEqual(meanings(route), ["life.bath.invite.shy", "life.bath"])  # 20時を過ぎていれば、続けて一人で入る

    def test_invite_deflected_with_low_desire_then_accepted_when_she_wants(self):
        route = self.route(3, hour=19, minute=40, day_offset=2, tier="few")
        prepare(route, desire=10)
        route.choose("bath.invite")
        self.assertEqual(meanings(route), ["life.bath.invite.deflect"])
        route = self.route(4, hour=19, minute=40, day_offset=2, tier="few")
        prepare(route, desire=70)
        route.choose("bath.invite")
        self.assertEqual(meanings(route), ["life.bath.together"])
        state = route.engine.snapshot()
        self.assertEqual(state["bath"]["together_count"], 1)
        self.assertEqual(state["desire"], 85)  # 一緒に入ると欲求が上がる（together_desire 15）
        self.assertTrue(route.engine.get_view()["status"]["bath"].startswith("二人で入った。湯上がり（"))
        variant = route.engine.get_view()["blocks"][0]["variant"]
        self.assertIn('"eq", "value": 1', str(route.engine.pack.by_text[variant]["when"]).replace("'", '"'))  # 1回目の本文

    def test_familiar_accepts_even_with_low_desire(self):
        route = self.route(5, hour=20, minute=10, day_offset=2, tier="familiar")
        prepare(route, desire=0)
        route.choose("bath.invite")
        self.assertEqual(meanings(route), ["life.bath.together"])

    def test_after_bath_desire_grows_faster_and_invite_is_easier(self):
        plain = self.route(6, hour=19, minute=0, day_offset=2, tier="few")
        prepare(plain, desire=50)
        plain.choose("near")
        plain.choose("menu.talk")
        plain.choose("touch.affection")
        gained_plain = plain.engine.snapshot()["desire"] - 50
        glow = self.route(6, hour=20, minute=0, day_offset=2, tier="few")
        prepare(glow, desire=50)
        glow.choose("near")  # 20:00 を過ぎているので、この選択の後に風呂に入る
        self.assertIn("life.bath", meanings(glow))
        glow.choose("near")
        glow.choose("menu.talk")
        glow.choose("touch.affection")
        gained_glow = glow.engine.snapshot()["desire"] - 50
        self.assertEqual((gained_plain, gained_glow), (2, 3))  # 150%
        values = glow.engine.pack.registry.values(glow.engine._state)
        self.assertTrue(values["bath.after"])
        self.assertTrue(values["intimacy.invite_ready"])  # 欲求 53 でも、湯上がりは誘える水準（+15）で見る
        values_plain = plain.engine.pack.registry.values(plain.engine._state)
        self.assertFalse(values_plain["intimacy.invite_ready"])

    def test_sleeping_before_the_bath_takes_it_first(self):
        route = self.route(7, hour=19, minute=40, day_offset=2)
        route.choose("sleep")
        found = meanings(route)
        self.assertLess(found.index("life.bath"), found.index("system.slept"))

    def test_no_bath_after_dinner_in_the_same_step_so_she_can_be_invited(self):
        route = self.route(8, hour=19, minute=20, day_offset=2, dinner=True)
        route.choose("near")  # この選択の後に夕食（40分）。20時を過ぎても、同じ手では風呂に入らない
        found = meanings(route)
        self.assertIn("life.dinner", found)
        self.assertNotIn("life.bath", found)
        self.assertIn("bath.invite", choices(route))
        route.choose("wait.30")
        self.assertIn("life.bath", meanings(route))

    def test_no_bath_on_a_night_they_sleep_together(self):
        from tools.run_stage_b_routes import satisfied
        route = self.route(9, hour=20, minute=0, day_offset=2)
        try:
            satisfied(route)
        except AssertionError:
            pass  # 夜に終えると翌朝になる
        self.assertNotIn("life.bath", meanings(route))
        self.assertIn("h.sleep_together.satisfied", meanings(route))

    def test_hidden_in_private_time_and_after_bath(self):
        route = self.route(10, hour=19, minute=40, day_offset=2, tier="few")
        route.choose("private.begin")
        self.assertNotIn("bath.invite", choices(route))

    def test_save_and_load_keep_bath_state(self):
        route = self.route(11, hour=19, minute=40, day_offset=2, tier="few")
        prepare(route, desire=70)
        route.choose("bath.invite")
        before = route.engine.snapshot()
        route.engine.save("slot03")
        route.engine.load("slot03")
        self.assertEqual(route.engine.snapshot(), before)


if __name__ == "__main__":
    unittest.main()
