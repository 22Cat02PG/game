class GameError(ValueError):
    def __init__(self, code, message):
        super().__init__(message)
        self.code = code
        self.message = message


def ensure(condition, code, message):
    if not condition:
        raise GameError(code, message)
