"""v8.2.9（ユーザー了承 2026-09-28 10:06〜10:31）の grok への依頼（Opus）。

- 第9陣（p9.、標準）と濃い版（x8.）：
  - 素股（h_sumata、こちらからする）・股のあいだで出す・限界で続けて果てる・こらえる。数回・慣れ × 向き。
  - 胸でしてもらう（h_maho_breasts、パイずり）・胸で出す・限界・こらえる。数回・慣れ。
  - 足でしてもらう（h_maho_feet、足コキ、慣れから）・足で出す・限界・こらえる。
  - 追加：先端も舐めてもらう（パイずりの最中）・玉も揉んでもらう（手・口の最中）。お願いする本文と、真帆が自分から始める本文、追加しながら続ける本文。
  - 真帆が自分から申し出る（何回かお願いされたあと）：胸・足。
どの場面にも Opus の本文（opus_texts_009.json の o18〜o21）がすでにある。
出力：grok_b2_wave_9.json・grok_b2_wave_x8.json、grok依頼_B2_第9陣/、第9陣_一覧.json
"""
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
PROMPT = (OUT / "grokプロンプト_v3_0.txt").read_text(encoding="utf-8")
BED = "二人の個室のどちらか（どちらの部屋か、ベッドの上かどうかは書かない）"
TIER = {"few": "数回（2〜5回目）", "familiar": "慣れ（6回目以降）", "few_familiar": "数回か慣れ（2回目以降）"}
TIER_WHEN = {"few": ("eq", "few"), "familiar": ("eq", "familiar"), "few_familiar": ("in", ["few", "familiar"])}
LOWER_OPEN = "真帆の下は、下着をずらしてあるか脱いでいる（下着について書かない）。こちらは下を脱いでいる"
FACING = {"face": ("向かい合っている（寝ているか座っているか、どちらが上かは書かない）", None),
          "back": ("真帆がこちらに背を向けている（寝ているか立っているか、どちらが上かは書かない）", "真帆の顔は見えない（肩越しに振り返るときだけ、横顔を書いてよい）")}
CLOSE_FACE = "（両脚を肩にかけた体位でも出るので）口づけ・首に腕を回す・耳もとでささやく"
DENSE = "濃い：性器・体液・擦れ合う音と感触・体の反応を具体的に、露骨に書く（記号 {penis} {vagina} {semen} {love_juice} {clitoris} {nipple} {breasts} を積極的に使う。擬音も使ってよい）"
FINISH_MUST = "妊娠・避妊に触れる。台詞で「待って」「止まって」と言う（止める意味に読める）。「出てる」のような実況の台詞。中に出したことを許すような言い方（「大丈夫」「そのままでいい」）"
SERVICE_POSE = "こちらは仰向けか座っていて、真帆はこちらの脚のあいだにいる（どちらかは書かない）"
FEET_POSE = "こちらは仰向けか座っていて、真帆はこちらの向かいに座り、足をこちらへ伸ばしている（どちらかは書かない）"
BREASTS_CLOTHES = "真帆の上は脱いでいるか、めくり上げてある（服について書かない）。こちらは下を脱いでいる"
MAHO_BODY = "真帆は健康的でグラマラスな体型（胸は豊か）"
std, dense = [], []


def add(rows, prefix, wave, meaning, tier, s, meaning_text, state, *, other=None, must_not="", when=None, length="100〜160字", style=None, facing=None):
    identity = ".".join([prefix, meaning, tier] + ([other] if other else []) + [s])
    op, value = TIER_WHEN[tier]
    conditions = [{"field": "intimacy.tier", "op": op, "value": value}] + list(when or [])
    if tier in ("familiar", "few_familiar") and facing == "face":
        must_not = must_not + "。" + CLOSE_FACE
    row = {"id": identity, "meaning": meaning_text, "speech": s == "s", "length": length, "origin": "主人公", "candidates": 5, "state": dict(state),
           "_wave": wave, "_meaning": meaning, "_split": {"tier": tier, "position": None, "other": other}, "when": {"all": conditions},
           "group": "b." + meaning, "must_not": must_not}
    if style:
        row["style"] = style
        row["state"]["描写"] = dense_for(meaning)
        row["length"] = {"60〜120字": "80〜150字", "80〜140字": "100〜170字", "100〜160字": "120〜200字"}.get(length, length)
    assert not any(r["id"] == identity for r in std + dense), identity
    rows.append(row)


def dense_for(meaning):
    """濃い本文の描写の指定。その場面に出てこない記号は勧めない（素股は出すまで {semen} を使わない、胸を出していない場面では {breasts} {nipple} を使わない）。"""
    symbols = ["{penis}"]
    if meaning.startswith(("h_sumata", "h_finish_sumata", "h_overflow.sumata")):
        symbols += ["{vagina}", "{love_juice}", "{clitoris}"]
    if meaning.startswith(("h_maho_breasts", "h_finish_breasts", "h_overflow.breasts")):
        symbols += ["{breasts}", "{nipple}"]
    if meaning.startswith(("h_finish_", "h_overflow.")):
        symbols += ["{semen}"]
    return "濃い：性器・体液・擦れ合う音と感触・体の反応を具体的に、露骨に書く（記号 " + " ".join(symbols) + " を積極的に使う。擬音も使ってよい）"


def facing_when(facing):
    return [{"field": "intimacy.facing", "op": "eq", "value": facing}]


def both(meaning, tier, s, text, state, **kwargs):
    """標準（p9.）と濃い版（x8.）の両方に足す。dense=False なら標準だけ。"""
    dense_too = kwargs.pop("dense", True)
    add(std, "p9", "B2-9", meaning, tier, s, text, state, **kwargs)
    if dense_too:
        add(dense, "x8", "B2-x8", meaning, tier, s, text, state, style="explicit", **kwargs)


# ---- 素股 ----
SUMATA = "入れずに、こちらのものを真帆の割れ目に沿わせて、こすりつける（素股）"
SUMATA_MUST = "入れる・入れかける（先端が中へ沈みかける）。真帆が脚や腿を閉じて挟む（真帆がまたがる体位・片脚を抱える体位・背を向けて乗る体位でも出る）。真帆が自分から腰を沈めて入れる。真帆が達する。こちらが出す。体位を変える。痛がる・嫌がる"
SUMATA_MAHO = {"first": "こちらに素股をされるのは初めて。戸惑いながら、擦れる感触に反応する", "start": "高まってきている",
               "continue": "擦れる感触に、もどかしく高まっている", "settled": "擦れ続けて、すっかり濡れて高まっている（まだ達していない）"}
for phase in ("first", "start", "continue", "settled"):
    tiers = ("few_familiar",) if phase == "first" else ("few", "familiar")
    speeches = ("n",) if phase == "settled" else ("s", "n")
    for tier in tiers:
        for facing, (pose, face) in FACING.items():
            for s in speeches:
                state = {"場所": BED, "慣れ": TIER[tier], "体位": pose, **({"顔": face} if face else {}), "服": LOWER_OPEN,
                         "挿入": "していない（この本文でも入れない）", "真帆": SUMATA_MAHO[phase]}
                if phase in ("continue", "settled"):
                    state["続いている動作"] = "前の本文から、こちらが真帆の脚のあいだにこすりつけている"
                both("h_sumata." + phase, tier, s, SUMATA, state, other=facing, must_not=SUMATA_MUST, when=facing_when(facing), facing=facing, dense=phase != "first")
for tier in ("few", "familiar"):
    for facing, (pose, face) in FACING.items():
        for s in ("s", "n"):
            state = {"場所": BED, "慣れ": TIER[tier], "体位": pose, **({"顔": face} if face else {}), "服": LOWER_OPEN, "挿入": "していない",
                     "続いている動作": "前の本文から、こちらが真帆の脚のあいだにこすりつけていた", "主人公": "出すところまで高まっている。この本文で、真帆の脚のあいだで果てる",
                     "出した場所": "真帆の肌（向き合うときは腹や腿、背を向けるときは腰や腿のあたり）"}
            both("h_finish_sumata.start", tier, s, "素股をしたまま、真帆の脚のあいだで果てる", state, other=facing,
                 must_not=FINISH_MUST + "。入れる。真帆が達する", when=facing_when(facing), facing=facing)
for facing, (pose, face) in FACING.items():
    for s in ("s", "n"):
        state = {"場所": BED, "慣れ": TIER["few_familiar"], "体位": pose, **({"顔": face} if face else {}), "服": LOWER_OPEN, "挿入": "していない",
                 "続いている動作": "前の本文から、こちらが真帆の脚のあいだにこすりつけていた", "主人公": "もう限界だったのに、素股を続けてしまった（出すと決めてはいない）"}
        both("h_overflow.sumata", "few_familiar", s, "限界だったのに素股を続けてしまい、こらえきれずに真帆の脚のあいだで果てる", state, other=facing,
             must_not=FINISH_MUST + "。出すと自分で決めたように書く。入れる", when=facing_when(facing), facing=facing)
for s in ("s", "n"):
    add(std, "p9", "B2-9", "h_endure.sumata", "few_familiar", s, "限界の手前で、素股の腰を止めて、こらえる（出さない）",
        {"場所": BED, "慣れ": TIER["few_familiar"], "体位": "書かない（向きも書かない）", "服": LOWER_OPEN, "挿入": "していない",
         "続いている動作": "前の本文から、こちらが真帆の脚のあいだにこすりつけていた（この本文で止める）", "主人公": "もう限界だった。出すと決めてはいない"},
        must_not="出す・果てる。入れる。体位を変える。真帆が台詞で出すことを促す", length="60〜120字")

# ---- 胸でしてもらう（パイずり） ----
BREASTS = "真帆に、胸でこちらのものを挟んで擦ってもらう（パイずり）"
BREASTS_MUST = "先端を舐める・口に含む・唇や舌を寄せる・息を吹きかける（それは別の本文）。こちらが出す。真帆が達する。入れる。体位を変える"
BREASTS_MAHO = {"first": "胸でしてほしいとこちらにお願いされて、初めてする。戸惑い、照れながら応じる",
                "start": "胸でするのは初めてではない（お願いされたのか、自分から申し出たのかは書かない）",
                "continue": "こちらの反応を見ながら、胸で擦り続けている", "settled": "胸で擦り続けて、こちらを追い詰めている"}
for phase in ("first", "start", "continue", "settled"):
    tiers = ("few_familiar",) if phase == "first" else ("few", "familiar")
    speeches = ("n",) if phase == "settled" else ("s", "n")
    for tier in tiers:
        for s in speeches:
            state = {"場所": BED, "慣れ": TIER[tier], "体位": SERVICE_POSE, "服": BREASTS_CLOTHES, "挿入": "していない", "真帆": BREASTS_MAHO[phase] + "。" + MAHO_BODY}
            if phase in ("continue", "settled"):
                state["続いている動作"] = "前の本文から、真帆が胸で挟んで擦っている"
            both("h_maho_breasts." + phase, tier, s, BREASTS, state, must_not=BREASTS_MUST, dense=phase != "first")
for tier in ("few", "familiar"):
    for s in ("s", "n"):
        both("h_finish_breasts.start", tier, s, "真帆の胸に挟まれたまま、胸のあいだで果てる",
             {"場所": BED, "慣れ": TIER[tier], "体位": SERVICE_POSE, "服": BREASTS_CLOTHES, "挿入": "していない",
              "続いている動作": "前の本文から、真帆が胸で挟んで擦っていた", "主人公": "出すところまで高まっている。この本文で果てる", "出した場所": "真帆の胸元"},
             must_not=FINISH_MUST + "。口に含む")
for s in ("s", "n"):
    both("h_overflow.breasts", "few_familiar", s, "限界だったのに真帆の胸の動きが止まらず、こらえきれずに胸のあいだで果てる",
         {"場所": BED, "慣れ": TIER["few_familiar"], "体位": SERVICE_POSE, "服": BREASTS_CLOTHES, "挿入": "していない",
          "続いている動作": "前の本文から、真帆が胸で挟んで擦っていた", "主人公": "もう限界だった（出すと決めてはいない）"},
         must_not=FINISH_MUST + "。出すと自分で決めたように書く。口に含む")
    add(std, "p9", "B2-9", "h_endure.breasts", "few_familiar", s, "限界の手前で、真帆に胸の動きを止めてもらって、こらえる（出さない）",
        {"場所": BED, "慣れ": TIER["few_familiar"], "体位": SERVICE_POSE, "服": BREASTS_CLOTHES, "挿入": "していない",
         "続いている動作": "前の本文から、真帆が胸で挟んで擦っていた（この本文で止まる）", "主人公": "もう限界だった。出すと決めてはいない"},
        must_not="出す・果てる。入れる。真帆が台詞で出すことを促す", length="60〜120字")

# ---- 足でしてもらう（足コキ、慣れから） ----
FEET = "真帆に、足の裏でこちらのものを挟んだり撫でたりしてもらう（足コキ）"
FEET_MUST = "足以外（手・口・胸）でする。踏む。こちらが出す。真帆が達する。入れる。真帆が見下す・罵る（からかうのはよい）"
FEET_MAHO = {"first": "足でしてほしいとこちらにお願いされて、初めてする。「足で？」と戸惑い、申し訳なさそうに、おそるおそる応じる",
             "start": "足でするのは初めてではない（お願いされたのか、自分から申し出たのかは書かない）。少しからかうように",
             "continue": "こちらの反応を面白がりながら、足で続けている", "settled": "足で続けて、こちらを追い詰めている"}
for phase in ("first", "start", "continue", "settled"):
    for s in (("n",) if phase == "settled" else ("s", "n")):
        state = {"場所": BED, "慣れ": TIER["familiar"], "体位": FEET_POSE, "服": "こちらは下を脱いでいる（真帆の服は書かない）", "挿入": "していない", "真帆": FEET_MAHO[phase]}
        if phase in ("continue", "settled"):
            state["続いている動作"] = "前の本文から、真帆が足でしている"
        both("h_maho_feet." + phase, "familiar", s, FEET, state, must_not=FEET_MUST, dense=phase != "first")
for s in ("s", "n"):
    both("h_finish_feet.start", "familiar", s, "真帆の足にされたまま果てる",
         {"場所": BED, "慣れ": TIER["familiar"], "体位": FEET_POSE, "服": "こちらは下を脱いでいる", "挿入": "していない",
          "続いている動作": "前の本文から、真帆が足でしていた", "主人公": "出すところまで高まっている。この本文で果てる", "出した場所": "真帆の足やこちらの腹のあたり"},
         must_not=FINISH_MUST)
    both("h_overflow.feet", "familiar", s, "限界だったのに真帆の足の動きが止まらず、こらえきれずに果てる",
         {"場所": BED, "慣れ": TIER["familiar"], "体位": FEET_POSE, "服": "こちらは下を脱いでいる", "挿入": "していない",
          "続いている動作": "前の本文から、真帆が足でしていた", "主人公": "もう限界だった（出すと決めてはいない）", "出した場所": "真帆の足やこちらの腹のあたり"},
         must_not=FINISH_MUST + "。出すと自分で決めたように書く。踏む")
    add(std, "p9", "B2-9", "h_endure.feet", "familiar", s, "限界の手前で、真帆に足を止めてもらって、こらえる（出さない）",
        {"場所": BED, "慣れ": TIER["familiar"], "体位": FEET_POSE, "服": "こちらは下を脱いでいる", "挿入": "していない",
         "続いている動作": "前の本文から、真帆が足でしていた（この本文で止まる）", "主人公": "もう限界だった。出すと決めてはいない"},
        must_not="出す・果てる。真帆が台詞で出すことを促す", length="60〜120字")

# ---- 追加：先端も舐める・玉も揉む ----
EXTRA_MUST = "こちらが出す。真帆が達する。入れる。体位を変える"
for tier in ("few", "familiar"):
    for s in ("s", "n"):
        add(std, "p9", "B2-9", "h_extra_lick.start", tier, s, "パイずりの最中に、先端も舐めてほしいとお願いし、真帆が胸で挟んだまま先端を舐めはじめる",
            {"場所": BED, "慣れ": TIER[tier], "体位": SERVICE_POSE, "服": BREASTS_CLOTHES, "挿入": "していない", "続いている動作": "前の本文から、真帆が胸で挟んで擦っている",
             "真帆": MAHO_BODY}, must_not=EXTRA_MUST + "。口に含んだまま話す", length="80〜140字")
        add(std, "p9", "B2-9", "h_extra_balls.start", tier, s, "真帆に手か口でしてもらっている最中に、玉も揉んでほしいとお願いし、真帆が空いている手で揉みはじめる",
            {"場所": BED, "慣れ": TIER[tier], "体位": "書かない（向きも書かない）", "服": "こちらは下を脱いでいる（真帆の服は書かない）", "挿入": "していない",
             "続いている動作": "前の本文から、真帆が手か口でしている（どちらかは書かない。「空いている手」で揉む）"}, must_not=EXTRA_MUST + "。手か口かを決める書き方", length="80〜140字")
    add(std, "p9", "B2-9", "h_extra_lick.maho", tier, "s", "お願いされる前に、真帆が自分から、胸で挟んだまま先端を舐めはじめる（前に何度もお願いされたのを覚えている）",
        {"場所": BED, "慣れ": TIER[tier], "体位": SERVICE_POSE, "服": BREASTS_CLOTHES, "挿入": "していない", "続いている動作": "前の本文から、真帆が胸で挟んで擦っている",
         "真帆": MAHO_BODY}, must_not=EXTRA_MUST + "。口に含んだまま話す", length="60〜120字")
    add(std, "p9", "B2-9", "h_extra_balls.maho", tier, "s", "お願いされる前に、真帆が自分から、空いている手で玉を揉みはじめる（前に何度もお願いされたのを覚えている）",
        {"場所": BED, "慣れ": TIER[tier], "体位": "書かない（向きも書かない）", "服": "こちらは下を脱いでいる（真帆の服は書かない）", "挿入": "していない",
         "続いている動作": "前の本文から、真帆が手か口でしている（どちらかは書かない）"}, must_not=EXTRA_MUST + "。手か口かを決める書き方", length="60〜120字")
VARIANTS = {
    "h_maho_breasts_lick.continue": ("真帆が胸で挟んで擦りながら、先端を舐め続ける", SERVICE_POSE, BREASTS_CLOTHES, "前の本文から、真帆が胸で挟んで擦りながら、先端を舐めている", "。口に含んだまま話す"),
    "h_maho_hand_balls.continue": ("真帆が片手で扱きながら、もう片方の手で玉を揉み続ける", "書かない（向きも書かない）", "こちらは下を脱いでいる（真帆の服は書かない）", "前の本文から、真帆が手で扱きながら、玉を揉んでいる", ""),
    "h_maho_mouth_balls.continue": ("真帆が口で愛撫しながら、手で玉を揉み続ける", SERVICE_POSE, "こちらは下を脱いでいる（真帆の服は書かない）", "前の本文から、真帆が口で愛撫しながら、玉を揉んでいる", "。口に含んだまま話す（台詞は口を離したときだけ）"),
}
for meaning, (text, pose, clothes, doing, extra_must) in VARIANTS.items():
    for tier in ("few", "familiar"):
        for s in ("s", "n"):
            both(meaning, tier, s, text, {"場所": BED, "慣れ": TIER[tier], "体位": pose, "服": clothes, "挿入": "していない", "続いている動作": doing},
                 must_not=EXTRA_MUST + extra_must)

# ---- 真帆が自分から申し出る（何回かお願いされたあと） ----
for kind, tiers, text in (("breasts", ("few", "familiar"), "真帆が自分から、胸でしてあげようかと申し出る（前に何度もお願いされたのを覚えている。まだ始めない）"),
                          ("feet", ("familiar",), "真帆が自分から、足でしてあげようかと申し出る（前に何度もお願いされたのを覚えている。まだ始めない）")):
    for tier in tiers:
        add(std, "p9", "B2-9", "offer.h_help." + kind, tier, "s", text,
            {"場所": BED, "慣れ": TIER[tier], "体位": "書かない（向きも書かない）", "服": "こちらは下を脱いでいる（真帆の服は書かない）", "挿入": "していない",
             "真帆": "こちらのものが張りつめているのに気づいている" + ("。" + MAHO_BODY if kind == "breasts" else "")},
            must_not="始める（この本文ではまだ始めない）。こちらの返事を書く。出す", length="60〜120字")

(OUT / "grok_b2_wave_9.json").write_text(json.dumps(std, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
(OUT / "grok_b2_wave_x8.json").write_text(json.dumps(dense, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")

NOTE = ("\n\nこの依頼は、新しく足した行為（素股・胸でしてもらう＝パイずり・足でしてもらう＝足コキ）と、今している行為に足す「追加」（先端も舐める・玉も揉む）の本文です（同じ場面の短い本文はすでにあります）。"
        "胸・足・追加は、こちらがお願いして真帆がする行為です。初めては戸惑い（足は「足で？」と申し訳なさそうに）、回を重ねると慣れて、からかったり自分から申し出たりします。"
        "素股では入れません（割れ目に沿わせてこするだけ）。胸でしてもらう本文では、先端を舐めたり唇を寄せたりしません（それは「追加」の本文です）。"
        "胸で挟む行為を書くときは、地の文で「胸」「谷間」と書いてもかまいません（{breasts} と両方使ってよい。1本に同じ語は2回まで）。"
        "state に「顔」があるときは、そのとおりにしてください（真帆の表情を正面から見たようには書かない）。出す・果てる本文の決まり（台詞で「待って」「止まって」と言わない、実況しない、許す言い方をしない）は、これまでと同じです。")
DENSE_NOTE = ("\nこの依頼は高まりが強い場面で出る「濃い本文」です。標準より露骨に、性器・体液・擦れ合う音と感触・体の反応を具体的に書いてください（state の「描写」のとおり）。"
              "この依頼に限り、プロンプトの「部位の語と記号は地の文で1本に2つまで」は「4つまで（同じ語・記号は2回まで）」に読み替えてください。擬音も使ってよいです。")
TAIL = "\nそれ以外の規則（台詞の数、慣れの段階の語、地の文で器官を名前で呼ばず記号を使う、記号を台詞に書かない、妊娠・避妊に触れない、must_not）は同じです。"
folder = OUT / "grok依頼_B2_第9陣"
folder.mkdir(exist_ok=True)
for old in folder.glob("*.txt"):
    old.unlink()
files = {}


def write(rows, label, note):
    count = -(-len(rows) // 13)
    size = -(-len(rows) // count)
    for index in range(0, len(rows), size):
        chunk = rows[index:index + size]
        number = len(list(folder.glob("*.txt"))) + 1
        lines = [json.dumps({"id": r["id"], "meaning": r["meaning"], "speech": r["speech"], "length": r["length"], "origin": r["origin"], "本数": r["candidates"],
                             "must_not": r["must_not"], "state": r["state"]}, ensure_ascii=False) for r in chunk]
        body = ("指示\n"
                f"次の{len(chunk)}件の job を書いてください（段階Bの2版目・第9陣・{label}）。本数は各 job の「本数」のとおりです（合わせて{sum(r['candidates'] for r in chunk)}本）。"
                "speech が true の job は真帆の台詞がちょうど1つ、false の job は台詞なしです。途中で切れそうなら、job の区切りで止めてください。「続けて」と言われたら、止めた job の次から出してください。"
                + note + TAIL + "\n\n[\n  " + ",\n  ".join(lines) + "\n]\n\n" "プロンプト\n" + PROMPT)
        name = f"B2_第9陣_{number:02d}.txt"
        (folder / name).write_text(body, encoding="utf-8")
        files.setdefault(label, []).append(name)


groups = (("素股", ("h_sumata", "h_finish_sumata", "h_overflow.sumata", "h_endure.sumata")),
          ("胸でしてもらう・先端も舐める", ("h_maho_breasts", "h_finish_breasts", "h_overflow.breasts", "h_endure.breasts", "h_extra_lick", "offer.h_help.breasts")),
          ("足でしてもらう・玉も揉む・追加しながら続ける", ("h_maho_feet", "h_finish_feet", "h_overflow.feet", "h_endure.feet", "offer.h_help.feet", "h_extra_balls", "h_maho_hand_balls", "h_maho_mouth_balls")))
for label, prefixes in groups:
    write([r for r in std if r["_meaning"].startswith(prefixes)], label, NOTE)
for label, prefixes in groups:
    write([r for r in dense if r["_meaning"].startswith(prefixes)], "濃い本文・" + label, NOTE + DENSE_NOTE)
assert sum(len(v) for v in files.values()) == len(list(folder.glob("*.txt")))
listing = {label: {"files": names} for label, names in files.items()}
listing["jobs"] = {"標準": len(std), "濃い版": len(dense), "本数": 5 * (len(std) + len(dense))}
(OUT / "第9陣_一覧.json").write_text(json.dumps(listing, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
print(json.dumps(listing, ensure_ascii=False))
