"""v8.5.8（ユーザー 2026-10-08「進めろ。次があるだろ」）：010 だけ。段階C 九歩目：起きている真帆の前で自分で高める（二人の時間、エッチの前。仕様 第10節）。"""
import unittest
from pathlib import Path

from nagishima.content import Pack
from tools.run_stage_b_routes import Route

ROOT = Path(__file__).resolve().parents[1]
P009 = Pack(ROOT / "content/releases/interaction_009")
P010 = Pack(ROOT / "content/releases/interaction_010")


def private_route(affinity=80, desire=30, tier="familiar", release="interaction_010"):
    route = Route(8, hour=20, tier=tier, release=release)
    state = route.engine._state
    state["affinity"]["value"], state["desire"] = affinity, desire
    route.engine._install_choices()
    route.choose("private.begin")
    route.choose("menu.touch")
    return route


def meanings(view):
    return [b["meaning"] for b in view["blocks"]]


def ids(view):
    return [c["id"] for c in view["choices"]]


class V858(unittest.TestCase):
    def test_rules_and_009(self):
        self.assertIsNone(P009.intimacy.self_entry)
        entry = P010.intimacy.self_entry
        self.assertEqual(entry["decline_desire"], -10)
        for meaning in ("h.self_entry.begin", "h.self_entry.decline"):
            self.assertIn(meaning, P010.meanings)
        route = private_route(release="interaction_009")
        self.assertNotIn("touch.h_self_entry", ids(route.engine.get_view()))
        route.close()

    def test_begin(self):
        """二人の時間の「触れ合う」に出る。選ぶとエッチが始まり、自分で高めている（真帆の様子の一言まで）。"""
        route = private_route()
        self.assertIn("touch.h_self_entry", ids(route.engine.get_view()))
        view = route.choose("touch.h_self_entry")
        got = meanings(view)
        self.assertEqual(got[0], "h.self_entry.begin")
        self.assertTrue(any(m.startswith("h_self.") for m in got), got)
        self.assertTrue(any(m.startswith("h.self.react.") for m in got), got)
        state = route.engine.snapshot()
        self.assertIsNotNone(state["intimacy"])
        self.assertIn("h_self", [c["action_id"] for c in state["contacts"]])
        self.assertEqual(state["actors"]["player"]["clothing"]["lower"], "off")
        route.close()

    def test_decline(self):
        """欲求が低く親密度 60 未満なら、真帆は困って話をそらす（欲求 −10、エッチは始まらない）。"""
        route = private_route(affinity=40, desire=20)
        view = route.choose("touch.h_self_entry")
        self.assertEqual(meanings(view)[-1], "h.self_entry.decline")
        state = route.engine.snapshot()
        self.assertIsNone(state["intimacy"])
        self.assertEqual(state["desire"], 10)
        self.assertIsNotNone(state["intimacy_history"]["declined_at"])
        route.close()


if __name__ == "__main__":
    unittest.main()
