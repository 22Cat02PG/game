"""v8.4.19（ユーザー 2026-10-07 13:41「進めろ。次があるだろ」）：010 だけ。
本文の再会を減らす 六束目（その回はじめて深く口づける、手をつなぐの反応、高まりが高いときの反応をもう少し）。"""
import unittest
from pathlib import Path

from nagishima.content import Pack

ROOT = Path(__file__).resolve().parents[1]
P009 = Pack(ROOT / "content/releases/interaction_009")
P010 = Pack(ROOT / "content/releases/interaction_010")
NEW = [t for t in P010.texts if t["id"].startswith("cmp.") and any(f".v{n}" in t["id"] for n in range(1, 5))]
PREV = lambda name: {"field": f"flow.prev.{name}", "op": "eq", "value": False}  # noqa: E731


class V8419(unittest.TestCase):
    def test_009_unchanged(self):
        self.assertFalse(any(t["id"].startswith("cmp.") for t in P009.texts))

    def test_new_scenes(self):
        meanings = {t["meaning"] for t in NEW}
        for meaning in ("h_kiss_deep.start", "h_hands.start", "h.sign.wants_more", "h_ear_neck.start", "h_chest_over.start",
                        "h_chest_skin.side_left", "h_chest_skin.side_right", "h_chest_skin.side_both"):
            self.assertIn(meaning, meanings)
        for text in NEW:
            b = text["id"].rsplit(".", 1)[1]
            if "bcalm" in b:
                self.assertIn(PREV("urgent"), text["when"]["all"], text["id"])
            if "bhot" in b:
                self.assertIn(PREV("end"), text["when"]["all"], text["id"])
            if text["meaning"] == "h_kiss_deep.start":
                self.assertIn(PREV("service"), text["when"]["all"])
                self.assertIn({"field": "intimacy.facing", "op": "eq", "value": "face"}, text["when"]["all"])

    def test_wants_more_is_begging(self):
        flow = P010.intimacy.flow
        for text in NEW:
            if text["meaning"] == "h.sign.wants_more":
                self.assertIn("begging", flow.info(text)[3], text["id"])

    def test_hands_use_v8411_parts(self):
        hands = [t for t in NEW if t["meaning"] == "h_hands.start" and t["id"].split(".")[3].startswith("a0")]
        self.assertTrue(hands)
        self.assertTrue(all(t["id"].split(".")[3].startswith(("a0", "op")) for t in NEW if t["meaning"] == "h_hands.start"))
        # v8.4.15 で手をつなぐ前半に足した条件（両手でつないでいる・真帆の手がこちらに触れているときは出さない）
        self.assertIn({"field": "contact.h_maho_hand.active", "op": "eq", "value": False}, hands[0]["when"]["all"])

    def test_hands_again(self):
        """読む係の指摘（v8419/read 12・13・17・28）：直前の本文でもう手をつないでいたときの、つなぎ直す前半（前の本文を受ける本文）。"""
        again = [t for t in P010.texts if t["id"].startswith("cmp.h_hands.start.op")]
        self.assertEqual({t["id"].split(".")[3] for t in again}, {"op1hnaagain", "op2hnaagain", "op3hnaagain"})
        self.assertTrue(any(t["id"].rsplit(".", 1)[1].startswith("b") for t in again))  # v8.4.11 の後半ともつなぐ
        flow = P010.intimacy.flow
        for text in again:
            self.assertIn({"field": "flow.prev.holding", "op": "eq", "value": True}, text["when"]["all"])
            self.assertTrue(flow.receiver(text), text["id"])
            self.assertNotIn(text["id"].rsplit(".", 1)[1], ("v2hnbcalm03", "v2hnbcalm04", "v3hnbcalm03"))
        held = {"id": "x", "meaning": "h_feel.start", "body": "こちらの手を探しあてて指を組んだ。"}
        self.assertIn("holding", flow.info(held)[3])
        self.assertNotIn("holding", flow.info({"id": "y", "meaning": "h_feel.start", "body": "真帆は両手の指をぎゅっと組み合わせた。"})[3])
        self.assertIn("end", flow.info({"id": "z", "meaning": "h.deadline", "body": "「もうこんな時間。明日に残るから、ここまでね」"})[3])

    def test_review_fixes(self):
        """読む係の指摘（v8419/read）での直し。"""
        ids = {t["id"]: t for t in NEW}
        kiss_off = {"field": "contact.h_kiss_deep.active", "op": "eq", "value": False}
        for text in NEW:
            b = text["id"].rsplit(".", 1)[1]
            if text["meaning"] == "h_hands.start" and ("「" in text["body"].split("。", 1)[1] or b in ("v2hnbcalm05", "v3hnbcalm04", "v1hnbhot02")):
                self.assertIn(kiss_off, text["when"]["all"], text["id"])  # 深く口づけているときに台詞・声・口もとの仕草を出さない
            if b == "v2clbhot01":
                self.assertEqual(text["meaning"], "h_chest_skin.side_right")  # 「決まったほうへ一票」は右だけ
            if text["meaning"] == "h.sign.wants_more":
                a = text["id"].rsplit(".", 2)[1]
                self.assertFalse(b in ("v1wmbhot03", "v4wmbhot02") and a in ("w6wmaface03", "w5wmaback01", "w7wmaface02"), text["id"])
            self.assertFalse(text["body"].count("ひと呼吸") > 1, text["id"])
        self.assertFalse(any(t["id"].endswith((".v4wmbhot03", ".v2ksbcalm04")) for t in NEW))
        self.assertTrue(any("息を継ぐあいだだけ唇が離れると、すぐに" in t["body"] for t in NEW))

    def test_review_fixes_2(self):
        """読む係の 2回目の指摘（v8419/read/result2_*）での直し。"""
        pairs = {(t["id"].rsplit(".", 2)[1], t["id"].rsplit(".", 1)[1]) for t in P010.texts if t["id"].startswith("cmp.")}
        for a, b in (("w7wmaface01", "v1wmbhot01"), ("w7wmaface01", "v2wmbhot02"), ("w6wmaface02", "v2wmbhot02"), ("y3coaback01", "v2cobhot02"),
                     ("x4enaback01", "v2enbhot01")):
            self.assertNotIn((a, b), pairs)
        for text in P010.texts:
            a = text["id"].rsplit(".", 2)[1] if text["id"].startswith("cmp.") else ""
            if a == "w8wmaback01":
                self.assertIn({"field": "contact.h_ear_neck.active", "op": "eq", "value": False}, text["when"]["all"], text["id"])
            if a == "w7wmaface02":
                self.assertIn({"field": "actor.maho.clothing.upper", "op": "ne", "value": "worn"}, text["when"]["all"], text["id"])
            if a.startswith("op") and text["meaning"] == "h_hands.start":
                self.assertEqual(text["body"].count("絡"), text["body"].split("。", 1)[0].count("絡"), text["id"])  # 後半に「絡め」を書かない
            if text["id"].endswith(".v2cobhot01"):
                self.assertIn({"field": "intimacy.position", "op": "in", "value": ["player_above", "leg_up", "legs_shoulder"]}, text["when"]["all"])
            if text["meaning"] == "h_hands.start" and (text["id"].rsplit(".", 1)[1] in ("b06", "b07", "b08", "b11", "b14")
                                                        or text["id"] == "v840.h_hands.start.few_familiar.face_out.s.v2"):
                self.assertIn({"field": "contact.h_kiss_deep.active", "op": "eq", "value": False}, text["when"]["all"], text["id"])
        flow = P010.intimacy.flow
        self.assertNotIn("holding", flow.info({"id": "w", "meaning": "h_check.start", "body": "言葉のかわりにこちらの腕へ指を絡めてくる。"})[3])


if __name__ == "__main__":
    unittest.main()
