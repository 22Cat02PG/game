"""v8.5.2（ユーザー 2026-10-08「君はイベントエッチのほう進めて」）：010 だけ。段階C の三歩目：台所（夕食の支度とイベントの型）。
仕様 docs/凪島_段階C_仕様_2026-10-08.md の第8節・第17節。"""
import unittest
from pathlib import Path

from nagishima.content import Pack
from tools.run_stage_b_routes import Route

ROOT = Path(__file__).resolve().parents[1]
P009 = Pack(ROOT / "content/releases/interaction_009")
P010 = Pack(ROOT / "content/releases/interaction_010")


def kitchen_route(affinity=80, desire=95, tier="familiar", seed=8, day_offset=0):
    """夕食の時間帯の少し前（18:20）から 30分待つと、真帆が台所で支度を始める。"""
    route = Route(seed, hour=18, minute=20, tier=tier, release="interaction_010", dinner=True, bath=True, day_offset=day_offset)
    state = route.engine._state
    state["affinity"]["value"], state["desire"] = affinity, desire
    route.engine._install_choices()
    return route


def meanings(view):
    return [b["meaning"] for b in view["blocks"]]


def ids(view):
    return [c["id"] for c in view["choices"]]


def until_notice(route, keys=("event.pre.hug", "event.pre.neck"), limit=10):
    for i in range(limit):
        view = route.choose(keys[i % len(keys)])
        if any(m.startswith("ev.kitchen.notice.") for m in meanings(view)):
            return view
    raise AssertionError("振り向かない")


class V852(unittest.TestCase):
    def test_009_dinner_unchanged(self):
        """009 は台所のイベントを持たず、夕食の時間帯はこれまでどおりすぐ食べ終える。"""
        self.assertIsNone(P009.intimacy.events)
        route = Route(8, hour=18, minute=20, tier="familiar", release="interaction_009", dinner=True, bath=True)
        view = route.choose("wait.30")
        self.assertIn("life.dinner", meanings(view))
        self.assertNotIn("event_play", route.engine.snapshot())
        route.close()

    def test_rules(self):
        kitchen = P010.intimacy.events.events["kitchen"]
        self.assertEqual((kitchen.limit, kitchen.h_limit), (30, 40))
        self.assertEqual(list(kitchen.positions), ["sink_face", "counter_back"])
        for meaning in kitchen.meanings():
            self.assertIn(meaning, P010.meanings)
        for key in ("event.kitchen.count", "event.kitchen.days", "event.bath.count", "event.bath.days"):
            self.assertIn(key, P010.registry.fields)

    def test_wait_in_living_room(self):
        """夕食の時間帯になると台所のイベント。居間で待てば、支度が終わるまで進めて夕食（すぐ）。"""
        route = kitchen_route()
        view = route.choose("wait.30")
        self.assertIn("ev.kitchen.begin", meanings(view))
        self.assertEqual(view["page_title"], "台所")
        self.assertIn("event.leave", ids(view))
        started = route.engine.snapshot()["event_play"]["started_at"]
        view = route.choose("event.leave")
        self.assertEqual(meanings(view)[-2:], ["ev.kitchen.leave", "life.dinner"])
        state = route.engine.snapshot()
        self.assertIsNone(state["event_play"])
        self.assertEqual(state["world"]["now"], started + 30 + 40)  # 支度の残り＋夕食
        self.assertEqual(state["actors"]["player"]["location"], "living_room")
        route.close()

    def test_prep_ends(self):
        """見ているだけなら、支度が終わったところで夕食。"""
        route = kitchen_route()
        route.choose("wait.30")
        view = None
        for _ in range(10):
            if not route.engine.snapshot()["event_play"]:
                break
            view = route.choose("event.pre.watch")
        self.assertEqual(meanings(view)[-2:], ["ev.kitchen.timeout", "life.dinner"])
        route.close()

    def test_deflect(self):
        """慣れの浅いうちは、後ろから抱きつくを続けても「危ないから、あとでね」でかわされる（エッチへは移らない）。"""
        route = kitchen_route(tier="few", desire=70)
        route.choose("wait.30")
        view = until_notice(route)
        self.assertIn("ev.kitchen.notice.deflect", meanings(view))
        self.assertNotIn("event.accept", ids(view))
        route.close()

    def test_kitchen_h_and_week(self):
        """恋人で慣れ・欲求 press なら、火を止めて振り向く → 台所のエッチ → 冷めた夕食。次の台所のエッチは1週間あける。"""
        route = kitchen_route()
        route.choose("wait.30")
        view = until_notice(route)
        self.assertIn("ev.kitchen.notice.invite", meanings(view))
        route.choose("event.accept")
        view = route.choose("event.pos.sink_face")
        self.assertIn("ev.kitchen.pos.sink_face", meanings(view))
        route.choose("event.next")
        route.choose("event.insert")
        for _ in range(20):
            if "event.finish.inside" in ids(route.engine.get_view()):
                break
            route.choose("event.move.normal")
        view = route.choose("event.finish.inside")
        self.assertTrue(meanings(view)[-1].startswith("ev.kitchen.end."))
        self.assertNotIn("life.dinner", meanings(view))  # 終わりの一言が、冷めた夕食まで書く
        state = route.engine.snapshot()
        self.assertEqual(state["event_record"]["kitchen"]["count"], 1)
        self.assertEqual(state["intimacy_history"]["by_entry"]["event"], 1)
        self.assertFalse(route.engine.pack.registry.values(state)["event.kitchen.days"])  # 0日
        # 翌日の夕食：まだ1週間たっていないので、かわされる
        state = route.engine._state
        state["world"]["now"] += 1440
        state["world"]["processed_until"] = state["world"]["now"]
        state["world"]["awake_deadline"] += 1440
        state["desire"] = 95
        state["stamina"]["value"] = 3
        route.engine._install_choices()
        view = route.choose("wait.30")
        if "ev.kitchen.begin" not in meanings(view):
            view = route.choose("wait.30")
        self.assertIn("ev.kitchen.begin", meanings(view))
        view = until_notice(route)
        self.assertIn("ev.kitchen.notice.deflect", meanings(view))
        route.close()

    def test_low_stage_cannot_hug(self):
        """同居を始めたばかり（段階0）は、後ろから抱きつく・首すじに口づけるを出さない（見ている・手伝う・声をかける・つまみ食いだけ）。"""
        import tempfile
        from nagishima.engine import Engine
        with tempfile.TemporaryDirectory(prefix="nagishima-v852-") as temp:
            engine = Engine(temp, seed=8, release="interaction_010", autosave=False)
            state = engine._state
            self.assertEqual(state["relation"]["stage"], 0)
            now = state["world"]["now"] // 1440 * 1440 + 18 * 60 + 20
            state["world"].update(now=now, processed_until=now)
            engine._install_choices()
            view = engine.get_view()
            view = engine.choose("wait.30", view["revision"], view["session"])
            self.assertIn("ev.kitchen.begin", meanings(view))
            self.assertEqual([i for i in ids(view) if i.startswith("event.pre.")], ["event.pre.watch", "event.pre.help", "event.pre.talk", "event.pre.taste"])

if __name__ == "__main__":
    unittest.main()
