"""Declarations accepted by this runtime; additions never silently create rules."""
from .codec import exact, identifier
from .conditions import typed, validate as condition
from .errors import ensure
from . import clock


def short_id(value):
    identifier(value)
    ensure(len(value) <= 70, "id_length", "画面の操作IDに使う登録名は70文字まで。")


def declaration(spec, default=False):
    ensure(type(spec) is dict and spec.get("type") in ("int", "bool", "string", "enum"), "declaration", "登録できる値は整数・真偽・文字列・列挙。")
    common = {"nullable"} | ({"default"} if default else set())
    kind = spec["type"]
    optional = {"int": {"min", "max"}, "bool": set(), "string": {"max_length"}, "enum": {"max_length"}}[kind]
    exact(spec, {"type"} | ({"values"} if kind == "enum" else set()) | ({"default"} if default else set()), common | optional)
    ensure(type(spec.get("nullable", False)) is bool, "declaration", "nullableは真偽値で指定する。")
    if kind == "int":
        low, high = spec.get("min", -2147483648), spec.get("max", 2147483647)
        ensure(type(low) is int and type(high) is int and -2147483648 <= low <= high <= 2147483647, "declaration", "整数の登録範囲が不正。")
    if kind in ("string", "enum"):
        limit = spec.get("max_length", 200)
        ensure(type(limit) is int and 0 <= limit <= 200, "declaration", "保存する文字列は200文字まで。")
        if kind == "enum":
            ensure(type(spec["values"]) is list and 0 < len(spec["values"]) <= 256 and all(type(x) is str for x in spec["values"]) and len(set(spec["values"])) == len(spec["values"]), "declaration", "列挙値が不足・重複・型違い。")
            for value in spec["values"]: typed(value, spec)
    if default: typed(spec["default"], spec)


def catalog_structure(c, intimacy=False):
    exact(c, ["start_at", "actors", "locations", "postures", "outfits", "hair", "facts", "resources", "habits", "activities", "promise_kinds", "items", "memory_kinds", "stories", "slots", "milestones", "goals", "offers", "messages", "memory_specs"])
    ensure(type(c["start_at"]) is str and 0 <= clock.minutes(c["start_at"]) <= 2147483647, "catalog", "初期日時が範囲外。")
    for key, cap in [("actors", 6), ("locations", 64), ("facts", 128), ("resources", 16 if intimacy else 32), ("activities", 128), ("items", 128), ("stories", 128), ("slots", 12 if intimacy else 5), ("goals", 8 if intimacy else 7), ("offers", 32 if intimacy else 16), ("memory_specs", 128)]:
        ensure(type(c[key]) is dict and len(c[key]) <= cap, "catalog", "登録表の型または件数が違う。")
        for identity in c[key]: short_id(identity)
    ensure(set(c["actors"]) == {"player", "maho", "kayo", "shuichi", "yuki", "chinatsu"}, "catalog", "人物の登録が本体と一致しない。")
    ensure({"living_room", "kitchen", "player_room", "maho_room", "workshop", "town"} <= c["locations"].keys(), "catalog", "生活に必要な場所が不足している。")
    for definition in c["actors"].values():
        exact(definition, ["name", "age_at_start", "role"])
        ensure(type(definition["name"]) is str and 1 <= len(definition["name"]) <= 20 and type(definition["age_at_start"]) is int and definition["age_at_start"] >= 18 and type(definition["role"]) is str, "catalog", "人物の登録が不正。")
    for definition in c["locations"].values():
        exact(definition, ["label", "group"])
        ensure(type(definition["label"]) is str and 1 <= len(definition["label"]) <= 40 and definition["group"] in ("residence", "island", "town"), "catalog", "場所の登録が不正。")
    for key in ("postures", "outfits", "habits", "promise_kinds", "memory_kinds"):
        ensure(type(c[key]) is list and 0 < len(c[key]) <= 128 and len(set(c[key])) == len(c[key]), "catalog", "登録一覧が不足または重複している。")
        for value in c[key]: short_id(value)
    ensure("seated" in c["postures"] and "work" in c["outfits"], "catalog", "初期の身支度が未登録。")
    ensure(set(c["hair"]) == {"player", "maho"} and "short" in c["hair"]["player"] and "tied" in c["hair"]["maho"], "catalog", "髪形の初期値が未登録。")
    for values in c["hair"].values():
        ensure(type(values) is list and len(set(values)) == len(values) <= 16, "catalog", "髪形の登録が不正。")
        for value in values: short_id(value)
    for definition in c["facts"].values():
        exact(definition, ["spec", "initial", "known_by"])
        declaration(definition["spec"]); typed(definition["initial"], definition["spec"])
        ensure(type(definition["known_by"]) is list and len(set(definition["known_by"])) == len(definition["known_by"]) and set(definition["known_by"]) <= c["actors"].keys(), "catalog", "初期知識の持ち主が違う。")
        ensure(not definition["known_by"] or definition["initial"] is not None, "catalog", "未確定の事実を初期知識にできない。")
    ensure({"maho.drink", "player.drink", "shared.place", "story.workbench.shared", "relation.future_home"} <= c["facts"].keys(), "catalog", "標準生活の事実が不足している。")
    ensure(all(type(n) is int and n == 1 for n in c["resources"].values()), "catalog", "この版の身体資源は各1枠。")
    for definition in c["activities"].values():
        exact(definition, ["label", "minutes", "locations"])
        ensure(type(definition["label"]) is str and 1 <= len(definition["label"]) <= 60 and type(definition["minutes"]) is int and 1 <= definition["minutes"] <= 1440 and type(definition["locations"]) is list and definition["locations"] and set(definition["locations"]) <= c["locations"].keys(), "catalog", "活動の登録が不正。")
    ensure({"tea", "quiet", "private_time", "town_trip", "install"} <= c["activities"].keys() and set(c["promise_kinds"]) <= c["activities"].keys(), "catalog", "標準活動または約束の活動が不足。")
    for definition in c["items"].values():
        exact(definition, ["label", "large", "capacity"])
        ensure(type(definition["label"]) is str and 1 <= len(definition["label"]) <= 40 and type(definition["large"]) is bool and type(definition["capacity"]) is int and 1 <= definition["capacity"] <= 99, "catalog", "品物の登録が不正。")
    ensure({"tea", "mug", "shelf"} <= c["items"].keys() and c["items"]["shelf"]["capacity"] == 1 and c["items"]["shelf"]["large"], "catalog", "標準の共同作業品が違う。")
    ensure(set(c["memory_specs"]) == set(c["memory_kinds"]), "catalog", "記憶の種類と内容の宣言が不一致。")
    for definition in c["memory_specs"].values():
        exact(definition, ["facts", "summary"])
        ensure(type(definition["facts"]) is list and len(definition["facts"]) <= 16 and len(set(definition["facts"])) == len(definition["facts"]) and set(definition["facts"]) <= c["facts"].keys(), "catalog", "記憶に残す事実が不正。")
        ensure(type(definition["summary"]) is dict and len(definition["summary"]) <= 16, "catalog", "記憶の要約の宣言が不正。")
        for key, spec in definition["summary"].items(): short_id(key); declaration(spec)
    for story in c["stories"].values():
        exact(story, ["fact"]); ensure(story["fact"] in c["facts"], "catalog", "個人的な話の記録先が未登録。")
    slots = {"player_name", "location", "memory_place", "chosen_place", "scene_memory_place"}
    goals = {"promise", "project", "care", "preference", "closeness", "receive", "shared"}
    if intimacy:
        slots |= {"penis", "vagina", "semen", "breasts", "nipple", "clitoris", "love_juice"}
        goals.add("intimacy")
    ensure(set(c["slots"]) == slots, "catalog", "差し込みの種類が本体と一致しない。")
    required_offers = (goals - {"intimacy"}) | {"private"} | ({"intimacy_invite", "hold_back", "h_lead_straddle", "h_lead_takein"} if intimacy else set())
    ensure(set(c["goals"]) == goals and required_offers <= set(c["offers"]), "catalog", "希望と誘いの処理が本体と一致しない。")
    ensure(type(c["milestones"]) is list and len(c["milestones"]) == 4, "catalog", "関係の節目は四段階。")
    for goal in c["goals"].values():
        exact(goal, ["priority", "when", "offer", "group", "reason"])
        ensure(type(goal["priority"]) is int and 0 <= goal["priority"] <= 1000 and goal["offer"] in c["offers"], "catalog", "希望の優先または誘いが不正。")
        short_id(goal["group"]); short_id(goal["reason"])
    for offer in c["offers"].values(): exact(offer, ["plan"])
    for milestone in c["milestones"]: exact(milestone, ["id", "when"]); short_id(milestone["id"])
    ensure(type(c["messages"]) is list and len(c["messages"]) <= 64, "catalog", "定例連絡は64種類まで。")
    seen = set()
    for message in c["messages"]:
        exact(message, ["id", "sender", "weekday", "minute", "body"])
        short_id(message["id"])
        ensure(message["id"] not in seen and message["sender"] in c["actors"] and type(message["weekday"]) is int and 0 <= message["weekday"] <= 6 and type(message["minute"]) is int and 0 <= message["minute"] < 1440 and type(message["body"]) is str and 1 <= len(message["body"]) <= 16000, "catalog", "定例連絡の登録が不正。")
        seen.add(message["id"])


def catalog_conditions(c, registry, scenes):
    for value in [*c["goals"].values(), *c["milestones"]]: condition(value["when"], registry.fields)
    for offer in c["offers"].values():
        p = offer["plan"]
        ensure(type(p) is dict and p.get("op") in ("idle", "private.begin", "activity.begin", "scene.begin", "action"), "catalog", "誘いの操作が未登録。")
        if p["op"] in ("idle", "private.begin"): exact(p, ["op"])
        elif p["op"] == "activity.begin": exact(p, ["op", "kind"]); ensure(p["kind"] in c["activities"], "catalog", "誘う活動が未登録。")
        elif p["op"] == "scene.begin": exact(p, ["op", "id"]); ensure(p["id"] in scenes, "catalog", "誘う話題が未登録。")
        else:
            exact(p, ["op", "id"], ["origin", "lifetime"])
            ensure(p["id"] in registry.actions and p.get("origin", "player") in ("player", "maho") and p.get("lifetime", "persistent") in ("persistent", "private"), "catalog", "誘いの動作が不正。")
