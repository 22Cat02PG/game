from pathlib import Path
import re

from . import RULES_VERSION, SAVE_SCHEMA
from .codec import canonical, decode, digest, exact, read_json, write_atomic, MAX_SAVE_BYTES
from .errors import ensure, GameError
from .progression import neutral_affinity, neutral_sleep


class Storage:
    def __init__(self, root):
        self.root = Path(root)

    def slot_path(self, slot):
        ensure(type(slot) is str and re.fullmatch(r"(?:slot(?:0[1-9]|10)|auto[1-3])", slot), "save_slot", "保存先はslot01〜slot10、auto1〜auto3で指定する。")
        return self.root / "saves" / (slot + ".json")

    def encode(self, payload):
        value = {"schema": SAVE_SCHEMA, "rules_version": RULES_VERSION, "payload": payload, "sha256": digest(payload)}
        raw = canonical(value)
        ensure(len(raw) <= MAX_SAVE_BYTES, "save_size", "保存データが32MiBを超えている。現在のデータを保持して保存を中止した。")
        return raw

    def decode(self, raw):
        ensure(len(raw) <= MAX_SAVE_BYTES, "save_size", "保存データが32MiBを超えている。")
        value = decode(raw)
        exact(value, ["schema", "rules_version", "payload", "sha256"])
        schema = value["schema"] if type(value["schema"]) is int else None
        current = schema == SAVE_SCHEMA and value["rules_version"] == RULES_VERSION
        v3 = schema == 3 and value["rules_version"] == "nagishima-2.3"
        v2 = schema == 2 and value["rules_version"] == "nagishima-2.2"
        legacy = schema == 1 and value["rules_version"] == "nagishima-2.1"
        ensure(current or v3 or v2 or legacy, "save_version", "この保存は別の本体用。元の本体で開く。")
        ensure(digest(value["payload"]) == value["sha256"], "save_hash", "保存内容の検査値が一致しない。")
        payload = value["payload"]
        ensure(type(payload) is dict and "_legacy_rules_migrated" not in payload, "save_format", "保存の移行情報が不正。")
        if current:
            return payload
        if v3:
            payload["_legacy_rules_migrated"] = True
            return payload
        # Older rules: fill the fields they never had with neutral values.
        state = payload.get("state")
        ensure(type(state) is dict and not {"affinity", "desire", "maho_sleep"} & state.keys(), "save_format", "旧保存の状態が不正。")
        if legacy:
            ensure("interaction_streak" not in state, "save_format", "旧保存の状態が不正。")
            state["interaction_streak"] = None
        state["affinity"], state["desire"], state["maho_sleep"] = neutral_affinity(), 0, neutral_sleep()
        cheats = payload.get("test_cheats")
        if type(cheats) is dict and "intimacy" in cheats:
            ensure("contact_unlock" not in cheats, "save_format", "テストチート情報の型が不正。")
            cheats["contact_unlock"] = cheats.pop("intimacy")
        payload["_legacy_rules_migrated"] = True
        return payload

    def write(self, slot, payload, validate_existing=None):
        path, raw = self.slot_path(slot), self.encode(payload)
        if path.exists():
            try:
                old = path.read_bytes()
                prior = self.decode(old)
                if validate_existing: validate_existing(prior)
            except (GameError, OSError, KeyError, TypeError, ValueError):
                pass  # Never replace a good backup with a broken primary.
            else:
                write_atomic(path.with_suffix(".bak"), old)
        write_atomic(path, raw)

    def read(self, slot, backup=False):
        path = self.slot_path(slot)
        if backup: path = path.with_suffix(".bak")
        ensure(path.is_file(), "missing_save", "この保存データはまだない。")
        ensure(path.stat().st_size <= MAX_SAVE_BYTES, "save_size", "保存データが上限を超えている。")
        return self.decode(path.read_bytes())

    def autosave(self, payload, validate_existing):
        # Copy valid generations before replacing auto1. Each replacement is atomic.
        for old, new in [("auto2", "auto3"), ("auto1", "auto2")]:
            path = self.slot_path(old)
            if path.exists():
                try:
                    data = path.read_bytes()
                    validate_existing(self.decode(data))
                except (GameError, OSError, KeyError, TypeError, ValueError):
                    continue
                write_atomic(self.slot_path(new), data)
        self.write("auto1", payload, validate_existing)

    def archive(self, value):
        identity = digest(value)
        path = self.root / "collection" / (identity + ".json")
        if not path.exists(): write_atomic(path, canonical(value))
        else: ensure(digest(read_json(path)) == identity, "archive_hash", "回想ファイルが書き換わっている。")
        return identity

    def read_archive(self, identity):
        ensure(type(identity) is str and re.fullmatch(r"[a-f0-9]{64}", identity), "archive_id", "回想IDの形式が違う。")
        path = self.root / "collection" / (identity + ".json")
        ensure(path.is_file(), "missing_archive", "回想本文が見つからない。生活の保存データは引き続き使える。")
        value = read_json(path)
        ensure(digest(value) == identity, "archive_hash", "回想本文の検査値が一致しない。")
        exact(value, ["scene_id", "release", "records", "truncated", "incomplete"])
        from .codec import identifier
        from .schema import validate
        from .state import SCHEMA
        identifier(value["scene_id"]); identifier(value["release"])
        ensure(type(value["records"]) is list and 1 <= len(value["records"]) <= 256 and type(value["truncated"]) is bool and type(value["incomplete"]) is bool, "archive", "回想の形式が不正。")
        for record in value["records"]:
            exact(record, ["choice", "at", "block"])
            identifier(record["choice"])
            ensure(type(record["at"]) is int and 0 <= record["at"] <= 2147483647, "archive", "回想の日時が不正。")
            validate(record["block"], SCHEMA["$defs"]["block"], SCHEMA)
        return value

    def slots(self):
        return [{"id": s, "exists": self.slot_path(s).is_file(), "backup": self.slot_path(s).with_suffix(".bak").is_file()} for s in [*[f"slot{i:02d}" for i in range(1, 11)], "auto1", "auto2", "auto3"]]
