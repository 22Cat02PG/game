"""Publish the individually authored, independently reviewed prose_001 batch."""
from pathlib import Path
import argparse
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from nagishima.authoring import publish
from nagishima.codec import digest, read_json, write_json
from nagishima.content import Pack
from nagishima.errors import ensure


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--release', default='prose_001')
    args = parser.parse_args()
    source = Pack(ROOT / 'content/releases/base')
    folder = ROOT / 'authoring/prose_001'
    bundles = []
    groups = {}
    for category in ('story', 'life', 'reaction'):
        entries = read_json(folder / (category + '.jobs.json'))
        jobs = {entry['draft_id']: entry['job'] for entry in entries}
        drafts = read_json(folder / (category + '.drafts.json'))
        reviews = read_json(folder / (category + '.reviews.json'))
        reviewed = {review['draft_id']: review for review in reviews}
        ensure(len(drafts) == len(jobs) == len(reviews), 'prose_count', '依頼・原稿・検品の件数が違う。')
        ensure({draft['id'] for draft in drafts} == jobs.keys() == reviewed.keys(), 'prose_ids', '原稿と検品のIDが一致しない。')
        for draft in drafts:
            review = dict(reviewed[draft['id']])
            review.pop('draft_id')
            bundles.append({'job': jobs[draft['id']], 'draft': draft, 'reviews': [review]})
        groups[category] = {'texts': len(drafts), 'characters': sum(len(draft['body']) for draft in drafts)}
    ensure(len({b['draft']['body'] for b in bundles}) == len(bundles), 'prose_duplicate', '本文が完全重複している。')
    path = publish(source, ROOT / 'content/releases', args.release, bundles)
    pack = Pack(path)
    report = {'release': pack.id, 'sha256': pack.hash, 'source_release': source.id,
              'source_sha256': source.hash, 'groups': groups, 'added_texts': len(bundles),
              'total_texts': len(pack.texts), 'added_characters': sum(g['characters'] for g in groups.values()),
              'meanings': len(pack.meanings), 'scenes': len(pack.scenes),
              'same_game_rules': pack.control_hash == source.control_hash and pack.scenes == source.scenes,
              'reviewed_drafts_sha256': digest([b['draft'] for b in bundles])}
    write_json(ROOT / 'verification/prose_inventory.json', report)
    print(report)


if __name__ == '__main__':
    main()
