"""Rebuild ONLY the bundled starter pack during development, never a user release."""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from nagishima import RULES_VERSION
from nagishima.codec import write_json, digest, bytes_digest
from nagishima.content import FILES, Pack

ROOT = Path(__file__).resolve().parents[1]
TRUE = {"all": []}
def test(field, value=True, op="eq"): return {"field": field, "op": op, "value": value}
def all_(*conditions): return {"all": list(conditions)}
TOGETHER = test("together")
HOME = all_(TOGETHER, test("actor.player.location", "living_room"))
NORMAL = test("mode", "normal")


def build():
    catalog = {
        "start_at": "2038-04-07T07:30", "actors": {
            "player": {"name": "悠", "age_at_start": 27, "role": "島の記録整理と保守を担う"},
            "maho": {"name": "真帆", "age_at_start": 26, "role": "観測所と工房の管理を担う"},
            "kayo": {"name": "佳代", "age_at_start": 46, "role": "観測所責任者"},
            "shuichi": {"name": "修一", "age_at_start": 54, "role": "補給船と連絡便の船長"},
            "yuki": {"name": "由紀", "age_at_start": 38, "role": "生活雑貨店主"},
            "chinatsu": {"name": "千夏", "age_at_start": 22, "role": "真帆の妹、印刷物の制作補助"}},
        "locations": {k: {"label": label, "group": group} for k, label, group in [
            ("living_room", "居間", "residence"), ("kitchen", "台所", "residence"), ("player_room", "主人公の部屋", "residence"), ("maho_room", "真帆の部屋", "residence"),
            ("observatory", "観測所", "island"), ("workshop", "工房", "island"), ("garden", "庭", "island"), ("pier", "桟橋", "island"), ("coast", "海岸", "island"), ("town", "町", "town")]},
        "postures": ["standing", "seated", "reclined"], "outfits": ["work", "casual", "room"], "hair": {"player": ["short"], "maho": ["tied", "down"]},
        "facts": {
            "maho.drink": {"spec": {"type": "enum", "values": ["weak_tea"]}, "initial": "weak_tea", "known_by": ["maho", "chinatsu"]},
            "player.drink": {"spec": {"type": "enum", "values": ["tea", "coffee", "water"], "nullable": True}, "initial": None, "known_by": []},
            "shared.place": {"spec": {"type": "enum", "values": ["window", "table"], "nullable": True}, "initial": None, "known_by": []},
            "story.workbench.shared": {"spec": {"type": "bool"}, "initial": False, "known_by": []},
            "relation.future_home": {"spec": {"type": "bool", "nullable": True}, "initial": None, "known_by": []}},
        "resources": {key: 1 for key in ["player.left_hand", "player.right_hand", "player.posture", "player.speech", "maho.left_hand", "maho.right_hand", "maho.posture", "maho.speech", "maho.head_contact"]},
        "habits": ["tea", "meal", "walk", "quiet"],
        "activities": {k: {"label": label, "minutes": duration, "locations": places} for k, label, duration, places in [
            ("tea", "お茶を飲む", 30, ["living_room", "kitchen"]), ("meal", "食事をする", 45, ["kitchen"]), ("reading", "本を読む", 30, ["living_room"]),
            ("quiet", "静かに休む", 30, ["living_room"]), ("walk", "散歩する", 45, ["coast", "garden"]), ("help", "仕事を手伝う", 45, ["workshop"]),
            ("repair", "道具を手入れする", 45, ["workshop"]), ("private_time", "二人の時間を過ごす", 30, ["player_room", "maho_room"]), ("install", "棚を設置する", 60, ["living_room"]), ("town_trip", "町へ出かける", 540, ["town"])]},
        "promise_kinds": ["tea", "walk"],
        "items": {"tea": {"label": "茶葉", "large": False, "capacity": 99}, "mug": {"label": "カップ", "large": False, "capacity": 8}, "shelf": {"label": "小さな棚", "large": True, "capacity": 1}},
        "memory_kinds": ["tea", "meal", "reading", "quiet", "walk", "help", "repair", "private_time", "town_trip", "install", "story", "place_choice", "milestone", "gift", "project", "anniversary_dating", "anniversary_life"],
        "stories": {"workbench": {"fact": "story.workbench.shared"}},
        "slots": {"scene_memory_place": {"source": "scene.memories.tea.location.label"}, "player_name": {"source": "actors.player.name"}, "location": {"source": "actors.player.location.label"}, "memory_place": {"source": "memories.tea.location.label"}, "chosen_place": {"source": "facts.shared.place.label"}},
        "milestones": [
            {"id": "acquainted", "when": all_(TOGETHER, test("known.player.maho.drink.current"), test("known.maho.player.drink.current"), test("progress.shared_activities", 1, "ge"))},
            {"id": "comfortable", "when": all_(TOGETHER, test("progress.fulfilled_promises", 1, "ge"), test("progress.personal_stories", 1, "ge"))},
            {"id": "dating", "when": all_(TOGETHER, test("progress.shared_activities", 3, "ge"), test("progress.personal_stories", 1, "ge"), test("experience.hands.count", 1, "ge"))},
            {"id": "shared_life", "when": all_(TOGETHER, test("progress.shared_activities", 5, "ge"), test("progress.fulfilled_promises", 2, "ge"), test("habits.established_count", 2, "ge"))}],
        "goals": {}, "offers": {},
        "messages": [
            {"id": "weekly_kayo", "sender": "kayo", "weekday": 0, "minute": 540, "body": "佳代は、買い忘れがあると不便だと思い、今週の生活便で必要な物があるか尋ねた。"},
            {"id": "weekly_shuichi", "sender": "shuichi", "weekday": 3, "minute": 540, "body": "修一は、荷物を安全に受け取ってほしくて、今日の大型便の予定を知らせた。"},
            {"id": "weekly_chinatsu", "sender": "chinatsu", "weekday": 6, "minute": 1080, "body": "千夏は、久しぶりに真帆の近況を聞きたくなり、工房の仕事は順調かと便りを寄せた。"}]
    }
    catalog["memory_specs"] = {kind: {"facts": [], "summary": {}} for kind in catalog["memory_kinds"]}
    catalog["memory_specs"]["story"]["facts"] = ["story.workbench.shared"]
    catalog["memory_specs"]["place_choice"] = {"facts": ["shared.place"], "summary": {"place": {"type": "enum", "values": ["window", "table"]}}}
    catalog["memory_specs"]["milestone"]["summary"] = {"stage": {"type": "int", "min": 1, "max": 4}}
    for kind in ("gift", "project"): catalog["memory_specs"][kind]["summary"] = {"item": {"type": "enum", "values": list(catalog["items"])}}
    for kind in ("dating", "life"): catalog["memory_specs"]["anniversary_" + kind]["summary"] = {"year": {"type": "int", "min": 2001, "max": 9999}}
    goals = [
        ("promise", 100, TRUE, "promise", "keep_promise"), ("project", 80, TRUE, "project", "finish_together"),
        ("care", 70, test("mood.shy", 2), "care", "rest_together"),
        ("preference", 60, test("known.maho.player.drink.current", False), "preference", "learn_preference"),
        ("closeness", 40, all_(test("relation.stage", 2, "ge"), test("experience.hands.count", 0)), "closeness", "hold_hands"),
        ("receive", 40, TRUE, "receive", "receive_delivery"), ("shared", 30, TRUE, "shared", "spend_time")]
    for kind, priority, when, offer, reason in goals:
        catalog["goals"][kind] = {"priority": priority, "when": when, "offer": offer, "group": kind, "reason": reason}
    for kind, plan in {
        "promise": {"op": "idle"}, "project": {"op": "idle"}, "receive": {"op": "idle"},
        "care": {"op": "activity.begin", "kind": "quiet"}, "preference": {"op": "scene.begin", "id": "two_cups"},
        "closeness": {"op": "action", "id": "hands", "origin": "maho"}, "shared": {"op": "activity.begin", "kind": "tea"}, "private": {"op": "private.begin"}
    }.items(): catalog["offers"][kind] = {"plan": plan}
    actions = []
    for identity, label, ongoing, stage, near, resources, replaces, joint, when in [
        ("talk", "話しかける", False, 0, False, ["player.speech", "maho.speech"], [], False, TOGETHER),
        ("head", "頭を撫でる", True, 2, True, ["player.right_hand", "maho.head_contact"], [], False, TOGETHER),
        ("hands", "手をつなぐ", True, 2, True, ["player.left_hand", "maho.right_hand"], [], True, TOGETHER),
        ("hug", "抱きしめる", True, 3, True, ["player.left_hand", "player.right_hand", "maho.left_hand", "maho.right_hand", "player.posture", "maho.posture"], ["head", "hands"], False, TOGETHER),
        ("kiss", "キスする", False, 3, True, ["player.speech", "maho.speech"], [], False, TOGETHER),
        ("affection", "好きと伝える", False, 3, False, ["player.speech", "maho.speech"], [], False, TOGETHER),
        ("hold_mug", "カップを持つ", True, 0, False, ["player.right_hand"], [], True, test("item.mug.player_count", 1, "ge"))
    ]:
        actions.append({"id": identity, "label": label, "ongoing": ongoing, "min_stage": stage, "near": near, "resources": resources, "replaces": replaces, "keep_on_joint_move": joint, "when": when, "maintain": when, "postures": list(catalog["postures"])})

    scenes, texts, meanings = [], [], set()
    def prose(meaning, body):
        meanings.add(meaning)
        texts.append({"id": meaning + ".base", "meaning": meaning, "when": TRUE, "slots": [], "group": meaning + ".base", "body": body, "fallback": True})
    def choice(identity, label, target, effects=(), when=TRUE):
        return {"id": identity, "label": label, "when": when, "effects": list(effects), "next": target}
    def node(identity, meaning, body, choices=(), enter=(), end=False, join=TRUE, pause=True, interrupt="none", micro=("talk", "head", "hands", "kiss")):
        prose(meaning, body)
        n = {"id": identity, "meaning": meaning, "join": join, "enter": list(enter), "choices": list(choices), "pause": pause, "interrupt": interrupt, "micro": [] if end else list(micro)}
        if end: n["end"] = True
        return n
    def scene(identity, label, nodes, requires=HOME, resume=None, locals_=None, activity=None):
        d = {"id": identity, "revision": 1, "label": label, "requires": requires, "resume": resume or requires, "locals": locals_ or {}, "start": nodes[0]["id"], "nodes": nodes, "replay": True}
        if activity: d["activity_kind"] = activity
        scenes.append(d)
    def op(operation, **fields): return {"op": operation, **fields}

    scene("two_cups", "好きな飲み物を話す", [
        node("ask", "cups.ask", "真帆は、一緒に休む時間を心地よくしたくて、好きな飲み物を尋ねた。", [choice(k, label, "maho", [op("fact.set", id="player.drink", value=k), op("fact.learn", actor="player", id="player.drink"), op("fact.learn", actor="maho", id="player.drink")]) for k, label in [("tea", "お茶が好き"), ("coffee", "コーヒーが好き"), ("water", "水が好き")]]),
        node("maho", "cups.maho", "真帆は、自分の好みも覚えてほしくて、薄めのお茶をゆっくり飲むのが好きだと伝えた。", [choice("remember", "覚えておく", "end")], [op("fact.learn", actor="player", id="maho.drink")]),
        node("end", "cups.end", "好みを言い合えたことが、真帆には小さな安心になった。", end=True)])
    scene("workbench_half", "工房の思い出を聞く", [
        node("ask", "story.ask", "真帆は、仕事の話を聞いてもらえるのがうれしくて、初めて直した作業台の話を始めた。", [choice("listen", "続きを聞く", "end", [op("story.complete", id="workbench")])]),
        node("end", "story.end", "真帆は、うまく直せず悔しかった日もあったと話した。失敗まで聞いてもらえたことが、今はうれしい。", end=True)], all_(HOME, test("relation.stage", 1, "ge")))
    scene("shared_place", "二人のお気に入りを決める", [
        node("choose", "place.ask", "真帆は、二人で落ち着ける場所を一つ決めておきたいと思い、窓辺とテーブルを見比べた。", [choice(k, label, "merge", [op("local.set", name="place", value=k), op("local.inc", name="visits", value=1)]) for k, label in [("window", "窓辺にする"), ("table", "テーブルにする")]]),
        node("merge", "place.merge", "真帆は、選んだ場所で一緒に休む時間を思い浮かべ、ここに決めてよいか尋ねた。", [choice("confirm", "ここに決める", "end", [op("fact.set", id="shared.place", value={"ref": "local.place"}), op("fact.learn", actor="player", id="shared.place"), op("fact.learn", actor="maho", id="shared.place"), op("memory.record", kind="place_choice", facts=["shared.place"], summary={"place": {"ref": "local.place"}})]), choice("change", "もう一度選ぶ", "choose")], join=test("local.place", "unset", "ne")),
        node("end", "place.end", "一緒に選んだ場所ができて、真帆は次の休憩が楽しみになった。", end=True)
    ], all_(HOME, test("relation.stage", 2, "ge")), locals_={"place": {"type": "enum", "values": ["unset", "window", "table"], "default": "unset"}, "visits": {"type": "int", "min": 0, "max": 1000000, "default": 0}})
    scene("remember_tea", "お茶の思い出を話す", [
        node("ask", "remember.ask", "真帆は、一緒にお茶をした時間が心に残っていて、その日のことを話したくなった。", [choice("listen", "その日のことを話す", "end")], [op("memory.capture", kind="tea")]),
        node("end", "remember.end", "真帆は、同じ時間を覚えていてもらえるのがうれしくて、また落ち着いて過ごしたいと思った。", end=True)
    ], all_(TOGETHER, test("memory.tea.available")), resume=TOGETHER)
    texts.append({"id": "remember.ask.place", "meaning": "remember.ask", "when": test("snapshot.tea.available"), "slots": ["scene_memory_place"], "group": "remember.place", "body": "真帆は、{scene_memory_place}でお茶をした時間を思い出した。一緒に落ち着いて話せたことがうれしくて、その日を振り返りたくなった。", "fallback": False})
    for kind in ("dating", "life"):
        scene("anniversary_" + kind, "交際の記念日" if kind == "dating" else "暮らしの記念日", [
            node("ask", "anniversary." + kind + ".ask", "真帆は、二人で選んだ日のことを思い返し、今日まで一緒に過ごせた喜びを伝えたくなった。", [choice("celebrate", "一緒に記念日を祝う", "end", [op("anniversary.celebrate", kind=kind)])]),
            node("end", "anniversary." + kind + ".end", "二人で記念日を祝った。真帆は、これからの時間も一緒に選んでいきたいと思った。", end=True)
        ], all_(TOGETHER, test("anniversary." + kind + ".available")))
    scene("relation_recall", "二人で選んだ日を振り返る", [
        node("ask", "relation.recall.ask", "真帆は、気持ちを確かめ合った日のことを今も大切に思っている。話せることがうれしくて、ゆっくり振り返りたくなった。", [choice("listen", "一緒に振り返る", "end")]),
        node("end", "relation.recall.end", "真帆は、覚えていてもらえたことに安心し、また普段の時間を一緒に過ごしたいと思った。", end=True)
    ], all_(TOGETHER, test("relation.stage", 3, "ge")))
    for kind, definition in catalog["activities"].items():
        if kind in ("private_time", "town_trip", "install"): continue
        scene("activity_" + kind, definition["label"], [
            node("begin", "activity." + kind + ".begin", "真帆は、同じ時間を過ごせることがうれしくて、落ち着いて一緒に取りかかった。", [choice("finish", "ひと区切りまで過ごす", "end", [op("activity.complete", id={"ref": "scene.activity_id"})])]),
            node("end", "activity." + kind + ".end", "一緒に過ごした時間がひと区切りつき、真帆は満ち足りた気持ちで息をついた。", end=True, interrupt="offer")
        ], all_(TOGETHER, NORMAL, test("actor.player.location", definition["locations"], "in")), activity=kind)
    for stage, label in [(1, "一緒の暮らしに慣れる"), (2, "触れ合える距離へ進む"), (3, "恋人になる"), (4, "これからの暮らしを決める")]:
        scene("milestone_" + str(stage), label, [
            node("ask", f"relation.{stage}.ask", "真帆は、これまで一緒に過ごしたことがうれしくて、これからの距離について気持ちを確かめたくなった。", [choice("yes", "同じ気持ちだと伝える", "end", [op("relation.commit", stage=stage)]), choice("later", "今の距離で過ごす", "later")]),
            node("end", f"relation.{stage}.end", "二人は互いの気持ちを言葉で確かめた。真帆は、同じ先を選べたことに安心して微笑んだ。", end=True),
            node("later", f"relation.{stage}.later", "真帆は、今の気持ちを聞けて安心した。今日までの時間を大切にしながら過ごしたいと思う。", end=True)
        ], all_(TOGETHER, NORMAL, test("relation.stage", stage - 1), catalog["milestones"][stage - 1]["when"]))
    for kind in catalog["promise_kinds"]:
        scene("promise_" + kind, catalog["activities"][kind]["label"] + "約束", [
            node("ask", "promise." + kind + ".ask", "真帆は、次も一緒に過ごしたいと思い、明日の夜までに時間を取れるか尋ねた。", [choice("yes", "約束する", "end", [op("promise.create", kind=kind)]), choice("later", "予定を決めずにおく", "later")]),
            node("end", "promise." + kind + ".end", "次の楽しみができて、真帆はうれしそうにうなずいた。", end=True),
            node("later", "promise." + kind + ".later", "真帆は、予定を詰めずに過ごすのも心地よいと思い、今の時間に気持ちを戻した。", end=True)
        ], all_(TOGETHER, NORMAL, test("promises.pending_count", 2, "lt")))
    scene("room_conversation", "二人でゆっくり話す", [
        node("start", "room.start", "真帆は、落ち着いて向き合えるのがうれしくて、そばで話を聞いていたいと伝えた。", [choice("hand", "手をつなぐ", "settle", [op("action", id="hands", lifetime="private")]), choice("talk", "今日の気持ちを話す", "settle", [op("local.set", name="topic", value="today")])]),
        node("settle", "room.settle", "真帆は、急いで次へ進まずに気持ちを聞けることに安心し、もう少し話していたくなった。", [choice("stay", "もう少し話す", "settle", [op("local.inc", name="turns", value=1)]), choice("finish", "今日はここで休む", "end", [op("private.end")])]),
        node("end", "room.end", "真帆は、一緒に落ち着いて過ごせたことがうれしくて、また話そうと穏やかに伝えた。", end=True)
    ], all_(TOGETHER, test("mode", "private")), locals_={"topic": {"type": "enum", "values": ["unset", "today"], "default": "unset"}, "turns": {"type": "int", "min": 0, "max": 1000000, "default": 0}})
    scene("town_trip", "町への外出", [
        node("arrive", "trip.arrive", "町に着いた。真帆は、普段と違う道を二人で歩けるのがうれしくて、ゆっくり見て回りたいと思った。", [choice("walk", "町で過ごす", "return", [op("trip.advance", phase="town")]), choice("home", "帰りの便まで休んで戻る", "end", [op("trip.advance", phase="return")])], pause=False, micro=["talk"]),
        node("return", "trip.return", "帰りの便の時間になった。真帆は、今日見たものを帰ってからも話していたいと思った。", [choice("home", "島へ戻る", "end", [op("trip.advance", phase="return")])], pause=False, micro=["talk"]),
        node("end", "trip.end", "二人で島の家に戻った。真帆は、楽しかった一日を振り返りながら、いつもの居間にほっとした。", end=True, pause=False)
    ], all_(TOGETHER, test("actor.player.location", "town")))

    system = {
        "system.welcome": "真帆は、一緒に暮らす時間が始まることを楽しみにしている。まずは落ち着いて話をしたいと思った。",
        "system.approach": "近くへ寄ると、真帆は話を聞いてもらえるのがうれしくて、こちらへ顔を向けた。",
        "system.contact_ended": "動作を終えて、手を自由にした。",
        "system.paused": "話をいったん保留した。真帆は、落ち着いて続けられるときに戻りたいと思っている。",
        "system.cancelled": "話をここで区切った。真帆は、今の都合を確かめられて安心した。",
        "system.moved": "移動を終えた。", "system.prepared": "部屋で身支度を整えた。", "system.posture": "楽な姿勢に変えた。",
        "system.slept": "休息を終え、二人は朝の居間へ戻った。真帆は、今日も落ち着いて一緒に過ごしたいと思った。",
        "system.waited": "時間が過ぎた。", "system.listen": "真帆の様子を見ながら、静かに耳を傾けた。",
        "activity.completed": "一緒の活動を終え、真帆は同じ時間を過ごせたことに満足した。",
        "private.began": "二人で部屋に落ち着いた。真帆は、ゆっくり向き合える時間がうれしい。",
        "private.ended": "二人の時間を区切った。真帆は、心地よく一緒に過ごせたことに安心した。",
        "promise.created": "二人で予定を決めた。真帆は、次に一緒に過ごす時間が楽しみになった。",
        "promise.cancelled": "約束を取りやめた。真帆は、曖昧にせず予定を確かめられて安心した。",
        "promise.postponed": "約束の期限を先へ延ばした。真帆は、余裕を持って一緒に過ごせることに安心した。",
        "order.created": "注文を済ませ、到着の予定を記録した。", "order.cancelled": "未発送の注文を取り消した。", "order.received": "届いていた荷物を受け取り、所持品へ加えた。",
        "item.given": "真帆は、渡された物を大切に使いたいと思い、うれしそうに受け取った。",
        "project.planned": "二人で棚を置く計画を立てた。真帆は、一緒に家を整えるのが楽しみになった。",
        "project.installed": "二人で棚を設置した。真帆は、力を合わせて部屋が整ったことをうれしく思った。",
        "project.completed": "設置した棚を二人で確かめ、共同作業を終えた。真帆は、この部屋で過ごす時間がさらに楽しみになった。",
        "project.cancelled": "共同作業の計画を区切った。受け取った物は手元に残した。",
        "message.read": "便りに目を通した。", "memory.pinned": "思い出を大切な記録に残した。", "memory.unpinned": "思い出の固定を外した。",
        "memory.tea": "真帆は、一緒にお茶をした時間を思い出した。ゆっくり話を聞いてもらえたことが、今もうれしい。",
        "offer.declined": "真帆は今の返事を受け止めた。無理に予定を増やさず、心地よい時間を一緒に選びたいと思った。",
        "offer.promise": "真帆は、約束した時間を一緒に過ごしたくて、今から始められるか尋ねた。",
        "offer.project": "真帆は、二人で家を整えるのが楽しみで、棚の計画を次へ進めないかと尋ねた。",
        "offer.receive": "真帆は、届いた物を一緒に使うのが楽しみで、荷物を受け取ろうと声をかけた。",
        "offer.care": "真帆は、気持ちを落ち着けて一緒にいたくて、静かに休まないかと尋ねた。",
        "offer.preference": "真帆は、日々の休憩を心地よくしたくて、好きな飲み物を聞いてもよいか尋ねた。",
        "offer.closeness": "真帆は、近くにいる安心を感じたくて、手をつないでもよいか尋ねた。",
        "offer.shared": "真帆は、一緒にゆっくり過ごしたくて、お茶にしないかと尋ねた。",
        "offer.private": "真帆は、今の気持ちを落ち着いて伝え合いたくて、二人で部屋へ行かないかと尋ねた。"
    }
    for stage in range(1, 5): system[f"relation.{stage}"] = "互いの気持ちを確かめ、二人の関係が一つ進んだ。真帆は、同じ気持ちでいられることに安心した。"
    for key, body in system.items(): prose(key, body)
    action_bodies = {
        "talk": "真帆は、声をかけてもらえたことがうれしくて、今の話を聞いていたいと思った。",
        "head": "頭に触れる手に、真帆は大切にされている安心を感じた。そばにいられるのがうれしい。",
        "hands": "手をつなぐと、真帆は一緒にいる実感がうれしくて、穏やかに手を添えた。",
        "hug": "腕の中で、真帆は近くにいられる安心を感じた。もう少しこのままでいたいと思った。",
        "kiss": "短くキスを交わした。真帆は気持ちが伝わったことがうれしくて、照れながら微笑んだ。",
        "affection": "好きだと伝えると、真帆は同じ気持ちを言葉で返したくなった。聞けたことがうれしい。",
        "hold_mug": "手元のカップを持った。"
    }
    for action in actions:
        for phase in (["first", "start", "continue", "settled"] if action["ongoing"] else ["first", "start"]):
            suffix = {"first": "", "start": "", "continue": "その動作を続けている。", "settled": "新しく始め直さず、落ち着いて動作を続けている。"}[phase]
            prose(action["id"] + "." + phase, action_bodies[action["id"]] + suffix)
    for index, body in enumerate(["真帆は、声を聞けるのがうれしくて、小さな出来事も話していたくなった。", "真帆は、話す速さを合わせてくれることに安心し、考えていたことを言葉にした。", "真帆は、今日の気持ちを聞いてもらいたくて、落ち着いて話を続けた。"]):
        texts.append({"id": f"talk.start.extra{index}", "meaning": "talk.start", "when": TOGETHER, "slots": [], "group": f"talk.group{index}", "body": body, "fallback": False})
    texts.append({"id": "memory.tea.place", "meaning": "memory.tea", "when": test("memory.tea.available"), "slots": ["memory_place"], "group": "memory.tea.place", "body": "真帆は、{memory_place}で一緒にお茶をしたことを思い出した。同じ時間を過ごせたことが、今もうれしい。", "fallback": False})
    directory = ROOT / "content" / "releases" / "base"
    documents = dict(zip(FILES, [catalog, actions, scenes, sorted(meanings), texts]))
    for filename, data in documents.items(): write_json(directory / filename, data)
    manifest = {"id": "base", "rules_version": RULES_VERSION, "files": {name: bytes_digest((directory / name).read_bytes()) for name in FILES}, "control_sha256": digest({"catalog": catalog, "actions": actions})}
    write_json(directory / "release.json", manifest)
    pack = Pack(directory)
    print(f"base: {len(pack.actions)} actions, {len(pack.scenes)} scenes, {sum(len(s['nodes']) for s in pack.scenes.values())} nodes, {len(pack.meanings)} meanings, {len(pack.texts)} texts")


if __name__ == "__main__": build()
