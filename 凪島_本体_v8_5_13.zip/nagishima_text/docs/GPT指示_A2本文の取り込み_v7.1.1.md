# GPT-6 Sol への指示：段階A2 本文の取り込み（v7.1.1）

指示者：Claude Opus 5.5（リーダー）　実施：GPT-6 Sol・高（Codex）
作成：2026-09-25

## 0. 背景

- v7.1.0（段階A2 の本体）は Opus の監査で合格した（`docs/Opus段階A2監査_v7.1.0_2026-09-25.md`）。
- 本文の作業（J1〜J4）が終わり、Opus が判定した。今回は、それを `interaction_008` に取り込み、008 を完成させる。
- 起点：`凪島_本体修正版_v7_1_0.zip`
- 添付：
  - `J1_分類結果.json`（Gemini。既存の触れ合い本文109件の分類。Opus が20件を抜き取って合格）
  - `J2_慣れた反応_採用.json`（Sonnet。42本）
  - `J3_台詞なし_採用.json`（Sonnet。65本）
  - `J4_仕事と誘い_採用.json`（Sonnet。48本）
- J2・J3 は、Opus が不自然な7本を外した採用分。外した job_id の本文は取り込まない（件数の不足は問題ない）。

## 1. 守ること

- 公開済みの release（003〜007）と既存の ZIP を上書きしない。変えるのは 008 だけ（008 は未公開）。
- 008 は `tools/build_life_release.py` で 007 から作り直せる状態を保つ。本文は手で 008 の texts.json を書き換えず、次のデータを置き、生成ツールが読み込む形にする。
  - `authoring/a2_results/`（J1〜J4 の4ファイル）
- 範囲外の改善に気づいたら、実装せずに報告の「提案」に書く。
- 待機のルール：作業が終わったら報告して止まる。

## 2. やること

### 2.1 新しい本文の追加（J2・J3・J4）

- 各本文を、008 の texts に新しい本文として加える。
  - `meaning`：job_id から取る（例：`job.a2.familiar.arm.start.1` → `arm.start`、`job.a2.life.offer.shared.tea.2` → `offer.shared.tea`）
  - `id`：`<meaning>.a2.<J2|J3|J4>.<番号>`（例：`arm.start.a2.J2.1`）。ASCII のみ。重複させない。
  - `fallback`：**false**（必須。台詞の間隔は、fallback ではない本文だけを候補にする）
  - `slots`：空。`group`：job の group（`a2.familiar.arm.start` など）を使う。
  - `when`：
    - J2：`{"field": "experience.<行動>.tier", "op": "eq", "value": "familiar"}`
    - J3・J4：`{"all": []}`
- J4 の本文で、閉じかぎの直後に付いている「。」（`」。`）を削除する（既存の本文の書き方に合わせる。16か所）。本文のほかの部分は変えない。
- 各本文の provenance に「Sonnet 5（J2・J3 は高、J4 は中）・Opus 抜き取り判定済み・2026-09-25」を記録する。

### 2.2 既存の本文への慣れの条件（J5）

- J1 で `tone` が `surprise` か `shy` の本文（22件）に、`experience.<行動>.tier` が `familiar` ではないという条件を付ける（`{"field": "experience.<行動>.tier", "op": "ne", "value": "familiar"}`）。既存の `when` があれば、`all` でまとめる。
- **fallback の本文には条件を付けない**（fallback は無条件のまま）。J1 の対象に fallback は含まれていないが、念のため確かめる。
- 007 の本文は変えない。008 の中だけで行う。

### 2.3 既存の本文の書式の不具合を直す（008 の中だけ）

- 007 から写した本文のうち24件（`hair`・`back`・`waist` の `.continue` と `.settled`、id が `.i003.` を含むもの）で、台詞のかぎかっこの中に地の文が入っている。例：`…頭を預けた。「指が通るたび、真帆の肩から力が抜けていく」続いていることを…`
- 次の規則で機械的に直す：かぎかっこの中に「真帆」を含む場合、そのかぎかっこを外して地の文にし、直後に「。」を置く（直後がすでに句点なら置かない）。例：`…頭を預けた。指が通るたび、真帆の肩から力が抜けていく。続いていることを…`
- 直した本文の一覧（id、直す前、直した後）を報告に付ける。

### 2.4 既定の release を 008 にする

- 新規ゲームの既定を `interaction_008` にする（`__main__.py` の既定など）。
- `__version__` を `2.3.3` にする。配布 ZIP の名前は `凪島_本体修正版_v7_1_1.zip`。
- README と引き継ぎの表記を直す。008 の遊び方の変化（仕事ブロック、誘い、お茶の上限）を README に短く書く。

## 3. 受入条件

- C-01 008 の texts に、J2 42本・J3 65本・J4 48本が、2.1 の形で入っている。すべて `fallback: false`。
- C-02 J1 の22件に 2.2 の条件が付き、fallback の本文は無条件のまま。
- C-03 2.3 の24件が直り、かぎかっこの中に「真帆」を含む本文が 008 に0件。
- C-04 008 の全 meaning で、どの慣れの段階（first／few／familiar）でも、候補の本文が1件以上ある（機械で確かめる）。
- C-05 台詞の間隔が効く：008 で、手をつなぎ続ける（`hands` の continue／settled を合わせて30回以上）を2シードで行い、台詞のある本文の割合が50%以下になる（007 では100%）。同じ測定を `hug` と `back` でも行い、結果を報告する。
- C-06 慣れた反応が出る：008 で `kiss` を6回以上経験した後の `kiss.start`・`kiss.repeat` に、J1 で surprise／shy とした本文が選ばれない。
- C-07 003〜007 の出力が v7.1.0 と同じ（B-01 と同じ方法）。
- C-08 全試験が通る。`check_runtime.py`、`verify_text.py`（006・007・008）、`audit_autoplay_immersion.py --release interaction_008 --policy presence --seeds 20`、`check_progression_routes.py --release interaction_008` が通る。
- C-09 008 を `build_life_release.py` で作り直しても差分が出ない。
- C-10 新規ゲーム（既定）が 008 で始まる。`start.bat` で起動できる（Windows）。

## 4. 納品

- `凪島_本体修正版_v7_1_1.zip`
- `docs/段階A2本文取り込み報告_v7.1.1.md`：変更ファイル、C-01〜C-10 の結果（C-05 は行動ごとの台詞の割合の表）、2.3 の修正一覧、独自判断、未解決、提案。
- 納品したら報告して止まる。受入の判定は Opus の監査で行う。
