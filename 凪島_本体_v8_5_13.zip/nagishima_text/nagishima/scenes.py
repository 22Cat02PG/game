from copy import deepcopy

from .codec import digest
from .progression import MILESTONE_SCENES
from .conditions import evaluate, typed
from .errors import GameError, ensure


class Scenes:
    def scene_definition(self, instance=None):
        instance = instance or self.s["scene"]
        ensure(instance is not None, "scene", "進行中の話がない。")
        return self.repo.get(instance["release"]).scenes[instance["scene_id"]]

    def node(self):
        return next(n for n in self.scene_definition()["nodes"] if n["id"] == self.s["scene"]["node"])

    def requires_reason(self, expr):
        """話を始める条件のうち、満たしていない最初のものを、何をすればよいかの文にする（009、v8.2.7、精査 B-01）。"""
        values = self.values()
        labels = self.pack.catalog["locations"]
        def leaves(e):
            if "all" in e:
                for x in e["all"]:
                    yield from leaves(x)
            else:
                yield e
        for leaf in leaves(expr):
            if evaluate(leaf, values) is True:
                continue
            field = leaf.get("field", "")
            if field == "together":
                return "真帆と同じ場所で話す。"
            if field == "actor.player.location":
                places = leaf["value"] if isinstance(leaf["value"], list) else [leaf["value"]]
                return "か".join(labels[x]["label"] for x in places) + "で、二人でいるときに話せる。"
            if field == "relation.stage":
                return "二人の関係がもう少し進んでから話せる。"
            if field in ("memory.tea.age_days", "memory.tea.life_days"):
                return "お茶の思い出は、日を置いてから話せる。"  # v8.2.25（精査 B-12）
            if field.startswith("memory.tea"):
                return "一緒にお茶をした思い出ができてから話せる。"
            if field.startswith("anniversary."):
                return "記念日のころに話せる。"
            if field == "mode":
                return "二人の時間を区切ってから話せる。" if leaf.get("value") == "normal" else "二人で部屋へ行ってから話せる。"
            break
        return "この話を始める条件が整っていない。"

    @staticmethod
    def promise_kinds(definition):
        """この話で作る約束の種類（promise.create の kind）。"""
        return sorted({e["kind"] for n in definition["nodes"] for c in n["choices"] for e in c["effects"] if e["op"] == "promise.create"})

    def begin_scene(self, identity, activity_id=None):
        ensure(not self.s["scene"] and not self.s["offer"], "answer_first", "現在の問いに答えるか、保留・取りやめを選ぶ。")
        ensure(identity in self.pack.scenes, "scene", "話題が未登録。")
        self.require_awake()
        if activity_id is None:
            ensure(not self.at_work(), "work_time", "仕事の時間だ。「仕事に戻る」で仕事へ向かう。")
        if identity in MILESTONE_SCENES and self.pack.intimacy:
            # 009：迎え済みの節目や、前の節目がまだの節目には、日数や親しさではなく段階の理由を出す（v8.0.5、試運転の指摘5）。
            stage = self.s["relation"]["stage"]
            ensure(stage < MILESTONE_SCENES[identity], "scene_conditions", "この節目はもう迎えている。")
            ensure(stage == MILESTONE_SCENES[identity] - 1, "scene_conditions", "先に前の節目を迎える。")
        if identity in MILESTONE_SCENES: self.milestone_check(MILESTONE_SCENES[identity])
        definition = self.pack.scenes[identity]
        if self.pack.intimacy and self.promise_kinds(definition):
            # 009（v8.2.3、5回目の試運転の指摘3）：同じ約束が残っているときは、約束の話を始めない（理由を出す）。
            for kind in self.promise_kinds(definition):
                blocker = self.promise_blocker(kind)
                ensure(blocker is None, "promise_full", blocker)
            # v8.2.7（精査 A-13）：同じ約束の話を保留しているときは、保留した話から続ける
            ensure(not any(x["scene_id"] == identity for x in self.s["suspended"]), "scene_suspended", "この話は保留してある。「保留した話」から続ける。")
        if self.pack.intimacy and evaluate(definition["requires"], self.values()) is not True:
            raise GameError("scene_conditions", self.requires_reason(definition["requires"]))  # 009（v8.2.7、精査 B-01）
        ensure(evaluate(definition["requires"], self.values()) is True, "scene_conditions", "この話を始める条件が整っていない。")
        self.s["scene"] = {"id": self.new_id("scene"), "scene_id": identity, "scene_revision": definition["revision"], "definition_sha256": digest(definition), "release": self.pack.id, "node": definition["start"], "visit": 0, "locals": {k: deepcopy(v["default"]) for k, v in definition["locals"].items()}, "selected": [], "memories": [], "activity_id": activity_id, "saved_frame": None}
        if activity_id:
            self.activity(activity_id)["scene_owner"] = self.s["scene"]["id"]
        self.enter_node(definition["start"])

    def enter_node(self, target):
        automatic = 0
        while True:
            scene = self.s["scene"]
            scene["node"], scene["visit"] = target, scene["visit"] + 1
            node = self.node()
            ensure(evaluate(node["join"], self.values()) is True, "join", "合流先の状態が成立していない。")
            self.effects(node["enter"])
            if node.get("auto"):
                ensure(automatic < 32, "auto_limit", "自動進行が上限を超えている。")
                automatic += 1
                target = node["auto"]
                continue
            source = scene["release"]
            if node.get("end"):
                ensure(scene["activity_id"] is None, "activity_unfinished", "活動を終えずに話だけ終了できない。")
                self.emit(node["meaning"], source)
                self.close_owned("scene", scene["id"])
                if self.scene_definition()["replay"]:
                    self.finished_scenes.append({"id": scene["id"], "scene_id": scene["scene_id"], "release": source, "at": self.now, "choices": list(scene["selected"])})
                self.closed_scene = scene["id"]
                self.s["scene"] = None
                self.allow_offer = node["interrupt"] == "offer"
                rules = self.pack.progression
                if scene["scene_id"] == "milestone_4" and self.s["relation"]["stage"] == 4 and rules and rules.life_after_stage4:
                    self.emit("system.life_continues")  # shown once, right after the fourth milestone's closing text
                return
            ensure(any(evaluate(c["when"], self.values()) is True for c in node["choices"]), "scene_choices", "有効な選択肢がない。")
            self.emit(node["meaning"], source)
            return

    def choose_scene(self, choice_id):
        ensure(self.s["scene"] is not None, "scene", "進行中の話がない。")
        choice = next((x for x in self.node()["choices"] if x["id"] == choice_id), None)
        ensure(choice is not None and evaluate(choice["when"], self.values()) is True, "scene_choice", "現在の問いでは選べない。")
        self.effects(choice["effects"])
        self.s["scene"]["selected"].append(choice_id)
        self.s["scene"]["selected"] = self.s["scene"]["selected"][-256:]
        self.enter_node(choice["next"])

    def pause_scene(self):
        ensure(self.s["scene"] and self.node()["pause"], "cannot_pause", "この区切りは保留できない。")
        ensure(len(self.s["suspended"]) < 3, "suspended_full", "保留した話を一つ終えてから、保留する。")
        scene = self.s["scene"]
        scene["saved_frame"] = deepcopy(self.old_frame)
        scene["saved_frame"]["blocks"] = scene["saved_frame"]["blocks"][-1:]
        if scene["activity_id"]:
            self.activity(scene["activity_id"])["status"] = "suspended"
        self.s["suspended"].append(scene)
        self.s["scene"] = None
        self.emit("system.paused")

    def resume_scene(self, identity):
        ensure(not self.s["scene"] and not self.s["offer"], "answer_first", "現在の問いを先に終える。")
        scene = next((x for x in self.s["suspended"] if x["id"] == identity), None)
        ensure(scene is not None, "scene", "保留した話がない。")
        self.require_awake()
        ensure(not self.at_work(), "work_time", "仕事の時間だ。「仕事に戻る」で仕事へ向かう。")
        if scene["scene_id"] in MILESTONE_SCENES: self.milestone_check(MILESTONE_SCENES[scene["scene_id"]])
        definition = self.scene_definition(scene)
        if self.pack.intimacy:
            # v8.2.7（精査 A-13）：保留しているあいだに同じ約束ができていたら、続けない（区切る）
            for kind in self.promise_kinds(definition):
                if any(x["kind"] == kind for x in self.s["promises"]):
                    raise GameError("promise_full", self.pack.catalog["activities"][kind]["label"] + "約束は、もう交わしている。この話は区切る。")
        ensure(evaluate(definition["resume"], self.values()) is True, "resume_conditions", "この話を続けられる場所や状態へ戻る。")
        if scene["activity_id"]:
            activity = self.activity(scene["activity_id"])
            if self.pack.intimacy and activity["kind"] == "meal":
                # v8.2.25（精査 B-01）：保留した食事のあいだに自動の夕食をとったら、その食事は続けない（同じ夕方に三度食べていた）
                reason = self.meal_block()
                ensure(reason is None, "meal_recent", (reason or "") + "保留した食事は「区切る」で終える。")
            running = [a for a in self.s["activities"] if a["status"] == "running"]
            if running: self.busy(running)
            self.require_time(activity["remaining_minutes"])
            ensure(self.s["actors"]["player"]["location"] == self.s["actors"]["maho"]["location"] == activity["location"], "activity_location", "活動の場所へ二人で戻る。")
            if self.pack.life and activity["kind"] in self.pack.life.hands_free_activities and self.s["contacts"]:
                # 009：食事を再開するときも、続いている触れ合いを終える（v8.0.5、検査役G G-01）。
                ended = [c["action_id"] for c in self.s["contacts"]]
                self.s["contacts"] = []
                self.contact_ended(ended)
            elif self.pack.life and activity["kind"] in self.pack.life.contact_stops:
                self.stop_contacts_for(activity["kind"])  # v8.4.3（010）
            activity["status"] = "running"
        self.s["suspended"].remove(scene)
        self.s["scene"] = scene
        ensure(any(evaluate(c["when"], self.values()) is True for c in self.node()["choices"]), "resume_choices", "今の状態で選べる返事がない。")
        if self.pack.intimacy and self.promise_kinds(definition):
            # v8.2.26（ユーザー了承 2026-09-30、精査 B-13）：約束の話は、続けるときに問いの本文を今の状態で選び直す
            # （日をまたいで続けると、前の日の「明日の夜までに」がそのまま出ていた。期限は「はい」を選んだ時点で決まる）
            self.emit(self.node()["meaning"], scene["release"])
        else:
            self.restore_frame = deepcopy(scene["saved_frame"])
        scene["saved_frame"] = None

    def cancel_scene(self, identity=None):
        identity = identity or (self.s["scene"]["id"] if self.s["scene"] else None)
        active = bool(self.s["scene"] and self.s["scene"]["id"] == identity)
        scene = self.s["scene"] if active else next((x for x in self.s["suspended"] if x["id"] == identity), None)
        ensure(scene is not None, "scene", "取りやめる話が見つからない。")
        if scene["activity_id"]:
            self.cancel_activity(scene["activity_id"])
        self.close_owned("scene", identity)
        if active:
            self.s["scene"] = None
        else:
            self.s["suspended"].remove(scene)
            if self.s["scene"]:
                self.restore_frame = deepcopy(self.old_frame)
        self.closed_scene = identity
        self.emit("system.cancelled")

    def bind(self, value):
        if type(value) is dict and set(value) == {"ref"}:
            name = value["ref"]
            if name == "scene.activity_id":
                return self.s["scene"]["activity_id"] if self.s["scene"] else None
            if name == "scene.instance_id":
                return self.s["scene"]["id"] if self.s["scene"] else None
            return self.values().get(name)
        if type(value) is dict:
            return {key: self.bind(item) for key, item in value.items()}
        if type(value) is list:
            return [self.bind(item) for item in value]
        return value

    def effects(self, effects):
        # Effects define the outcome; the destination node renders it once.
        before = len(self.events)
        for effect in effects:
            if effect["op"] == "private.begin":
                self.pending_private = True
            else:
                self.apply(self.bind(effect))
        del self.events[before:]

    def local_set(self, name, value, increment=False):
        ensure(self.s["scene"] and name in self.s["scene"]["locals"], "local", "局所記録が見つからない。")
        new_value = self.s["scene"]["locals"][name] + value if increment else value
        typed(new_value, self.scene_definition()["locals"][name])
        self.s["scene"]["locals"][name] = new_value
