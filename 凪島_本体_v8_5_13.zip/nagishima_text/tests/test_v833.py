"""v8.3.3（依頼_v833_エッチ場面の直し）：010 だけのエッチ場面の直し A〜F。009 は変えない。
A：自分で高める最中、真帆の手伝いの申し出が開く手は「続ける」の一行を出さない。
B：真帆の申し出（上になる・自分から入れる）で入ったら、真帆に動いてもらうのが自動で始まる。主画面は「任せる」から並ぶ。
C：真帆が上・膝の上・背を向けて乗って動いているあいだは、こちらの「動く」3つの代わりに「下から突き上げる」（膝の上は「下から揺すり上げる」）。
D・E・F：本文の直し（条件の足し・書き換え）。"""
import unittest
from pathlib import Path

from nagishima.content import Pack
from tools.run_stage_b_routes import Route

ROOT = Path(__file__).resolve().parents[1]
P009 = Pack(ROOT / "content/releases/interaction_009")
P010 = Pack(ROOT / "content/releases/interaction_010")
NEW_SETTINGS = ("self_offer_replaces_line", "maho_led_moves", "thrust_up", "action_position_labels")


class V833(unittest.TestCase):
    def route(self, seed, release, tier="familiar"):
        route = Route(seed, day_offset=2, tier=tier, release=release)
        self.addCleanup(route.close)
        return route

    def decline(self, route):
        while route.engine.snapshot()["offer"]:
            route.choose("offer.decline")

    def ids(self, route):
        return [c["id"] for c in route.engine.get_view()["choices"] if c["available"]]

    def labels(self, route):
        return {c["id"]: c["label"] for c in route.engine.get_view()["choices"] if c["available"]}

    def blocks(self, route):
        return [b["meaning"] for b in route.engine.get_view()["blocks"]]

    def contacts(self, route):
        return [c["action_id"] for c in route.engine.snapshot()["contacts"]]

    def to_main(self, route):
        if route.engine.get_view()["page"] != "main":
            route.choose("menu.main")

    def rider(self, release, position, seed=5):
        """プレイヤーが頼んで上（膝の上・背を向けて）になってもらい、入れたところまで。"""
        route = self.route(seed, release)
        route.begin()
        for key in ("h_strip_lower", "h_shift_under", "h_strip_self"):
            route.action(key)
            self.decline(route)
        for _ in range(30):
            intimate = route.engine.snapshot()["intimacy"]
            if intimate["maho"]["arousal"] >= 55 and intimate["player"]["arousal"] >= 45:
                break
            route.action("h_kiss_deep")
            self.decline(route)
        route.action("h_pos_" + position)
        self.decline(route)
        route.action("h_insert")
        self.assertTrue(route.engine.snapshot()["intimacy"]["inserted"])
        return route

    def lead_straddle(self, release, seed=1):
        """真帆の「上になる」申し出を受けて入れる（数回）。"""
        route = self.route(seed, release, tier="few")
        route.engine.enable_test_cheat("lewdness:70")
        route.begin()
        route.action("h_strip_lower")
        route.action("h_strip_self")
        for _ in range(16):
            if route.engine.snapshot()["offer"]:
                break
            route.action("h_kiss_deep")
        self.assertEqual(route.engine.snapshot()["offer"]["kind"], "h_lead_straddle")
        route.choose("offer.accept")
        route.action("h_shift_under")
        route.action("h_insert")
        return route

    # ---- 009 は変えない：新しい設定は 010 だけ ----
    def test_settings_only_010(self):
        for key in NEW_SETTINGS:
            self.assertIn(key, P010.intimacy.settings)
            self.assertNotIn(key, P009.intimacy.settings)
        self.assertIn("h_thrust_up", P010.intimacy.actions)
        self.assertNotIn("h_thrust_up", P009.intimacy.actions)

    # ---- A：申し出が開く手は「続ける」の一行を出さない（009 は出す） ----
    def test_a_self_offer(self):
        for release, continued in (("interaction_009", True), ("interaction_010", False)):
            route = self.route(1, release)
            route.begin()
            route.action("h_strip_self")
            route.action("h_self")
            for _ in range(12):
                if route.engine.snapshot()["offer"]:
                    break
                route.action("h_self")
            offer = route.engine.snapshot()["offer"]
            self.assertTrue(offer and offer["kind"].startswith("h_help_"), release)
            blocks = self.blocks(route)
            self.assertTrue(any(m.startswith("offer.h_help.") for m in blocks), (release, blocks))
            self.assertEqual(any(m.startswith("h_self.") for m in blocks), continued, (release, blocks))

    # ---- B：申し出で上になって入れたら、真帆が動き始める。主画面の並び ----
    def test_b_led_starts(self):
        route = self.lead_straddle("interaction_010")
        self.assertIn("h_maho_move", self.contacts(route))
        self.assertEqual(route.engine.snapshot()["intimacy"]["pace_focus"], "h_maho_move")
        self.assertEqual(self.blocks(route)[-1], "h_maho_move.first")
        self.assertIn(".led.", route.engine.snapshot()["recent_text"][-1]["id"])  # 申し出のあとの本文
        self.to_main(route)
        ids = self.ids(route)
        self.assertEqual(ids[:4], ["touch.h_maho_move", "pace.h_maho_move.slow", "pace.h_maho_move.fast", "end.h_maho_move"])
        self.assertEqual(self.labels(route)["touch.h_maho_move"], "任せる（そのまま動いてもらう）")
        self.assertLess(ids.index("touch.h_thrust_up"), ids.index("h.end"))

    def test_b_led_takein(self):
        """上になったあと、真帆が自分から入れる申し出でも、入ったら動き始める。"""
        route = self.route(1, "interaction_010", tier="few")
        route.engine.enable_test_cheat("lewdness:70")
        route.begin()
        route.action("h_strip_lower")
        route.action("h_strip_self")
        for _ in range(16):
            if route.engine.snapshot()["offer"]:
                break
            route.action("h_kiss_deep")
        route.choose("offer.accept")
        route.action("h_shift_under")
        for _ in range(20):
            if route.engine.snapshot()["offer"]:
                break
            route.action("h_touch_direct")
        self.assertEqual(route.engine.snapshot()["offer"]["kind"], "h_lead_takein")
        route.choose("offer.accept")
        self.assertTrue(route.engine.snapshot()["intimacy"]["inserted"])
        self.assertEqual(self.blocks(route), ["h_lead_takein.first", "h_maho_move.first"])
        self.assertIn("h_maho_move", self.contacts(route))

    def test_b_009_unchanged(self):
        route = self.lead_straddle("interaction_009")
        self.assertNotIn("h_maho_move", self.contacts(route))

    def test_b_player_request_unchanged(self):
        route = self.rider("interaction_010", "maho_above")
        self.assertEqual(self.contacts(route), [])  # 頼んで上になってもらったときは、自動では動き始めない
        route.action("h_maho_move")
        self.to_main(route)
        self.assertEqual(self.ids(route)[:2], ["h.end", "touch.h_maho_move"])  # 並びは今まで通り
        self.assertEqual(self.labels(route)["touch.h_maho_move"], "真帆に動き続けてもらう")

    # ---- C：真帆が動いているあいだは、動く3つの代わりに突き上げる ----
    def test_c_thrust(self):
        route = self.rider("interaction_010", "maho_above")
        route.choose("menu.main")
        route.choose("menu.h_connect")
        self.assertIn("touch.h_move_slow", self.ids(route))  # 真帆が動く前は、今まで通り
        self.assertNotIn("touch.h_thrust_up", self.ids(route))
        route.action("h_maho_move")
        route.choose("menu.main")
        route.choose("menu.h_connect")
        ids = self.ids(route)
        for key in ("h_move_slow", "h_move_normal", "h_move_fast"):
            self.assertNotIn("touch." + key, ids)
        before = route.engine.snapshot()["intimacy"]["maho"]["arousal"]
        route.choose("touch.h_thrust_up")
        self.assertIn("h_maho_move", self.contacts(route))  # 真帆の動きは止まらない
        self.assertEqual(self.blocks(route)[0], "h_thrust_up.start")
        self.assertTrue(any(t["id"].startswith("c3.h_thrust_up.start.") for t in route.engine.snapshot()["recent_text"][-3:]))
        thrust_gain = route.engine.snapshot()["intimacy"]["maho"]["arousal"] - before
        keep = self.rider("interaction_010", "maho_above")
        keep.action("h_maho_move")
        before = keep.engine.snapshot()["intimacy"]["maho"]["arousal"]
        keep.action("h_maho_move")  # 任せる
        self.assertGreater(thrust_gain, keep.engine.snapshot()["intimacy"]["maho"]["arousal"] - before)

    def test_c_sitting_face_label(self):
        route = self.rider("interaction_010", "sitting_face")
        route.action("h_maho_move")
        self.to_main(route)
        self.assertEqual(self.labels(route)["touch.h_thrust_up"], "下から揺すり上げる")

    def test_c_009_unchanged(self):
        route = self.rider("interaction_009", "maho_above")
        route.action("h_maho_move")
        route.choose("menu.main")
        route.choose("menu.h_connect")
        self.assertIn("touch.h_move_slow", self.ids(route))

    def test_c_texts(self):
        texts = [t for t in P010.by_meaning["h_thrust_up.start"] if not t["fallback"]]
        self.assertEqual(len(texts), 30)
        for tier in ("few", "familiar"):
            for position in ("maho_above", "sitting_face", "reverse_ride"):
                self.assertEqual(sum(f".{tier}.{position}." in t["id"] for t in texts), 5, (tier, position))

    # ---- D・E・F：本文の直し（例） ----
    def test_def_samples(self):
        e = "o41.h.player.recovered.n.v2"
        self.assertIn("まだ終わりたくない", P009.by_text[e]["body"])
        self.assertNotIn("まだ終わりたくない", P010.by_text[e]["body"])
        d = "x2.h_insert.start.few.maho_above.s.v5"  # D：胸に触れているときだけ
        self.assertNotIn("h_chest_over", str(P009.by_text[d]["when"]))
        self.assertIn("contact.h_chest_over.active", str(P010.by_text[d]["when"]))
        self.assertIn("contact.h_chest_skin.active", str(P010.by_text[d]["when"]))
        clit = "sh.x3.h_move_fast.settled.familiar.reverse_ride.n.v4"  # D：入れて動いている最中に陰核へ指を伸ばさない
        self.assertIn("{clitoris}", P009.by_text[clit]["body"])
        self.assertNotIn("{clitoris}", P010.by_text[clit]["body"])
        f = "sh.p1.h_move_normal.continue.few.from_behind.n.v5"  # F：主語を書く
        self.assertTrue(P010.by_text[f]["body"].startswith("真帆は"))
        self.assertFalse(P009.by_text[f]["body"].startswith("真帆は"))


if __name__ == "__main__":
    unittest.main()
