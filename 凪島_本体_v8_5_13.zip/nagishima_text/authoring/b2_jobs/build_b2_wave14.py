"""v8.2.19 に向けた grok への依頼（ユーザー 2026-09-29 06:44「エッチシーンの必要分は依頼出してね」）（Opus）。

1. 第14陣（p14.、標準・台詞なし）：深い口づけを続けたまま起きる場面の、台詞のない本文。
   - v8.2.16 から、口づけのあいだは台詞のない本文を先に選ぶ。台詞のある本文しかない場面が 30組（行為×慣れ）あり、そこで仮の本文が出た（GPT の試遊 2026-09-29、「（太ももを撫でる）」）。
   - 対象：口づけを続けたまま選べる行為（指・胸・太もも・動く）の初めての本文と、合図・止める・締め切り・ねだる・引き留める。
   - 元の job の state と must_not を写し、口づけを続けている条件（contact.h_kiss_deep.active）を足す。
2. 続けての補充（同じ job id）：「さらに続けている」本文（…settled）。自動で続ける仕組み（ユーザー了承 2026-09-29 06:42）では、この本文が続けて出る。
   - 1つの体位・慣れで3〜5本しかない組が多いので、自動で回すとすぐ繰り返す。
   - 対象：自動で続ける行為（動く・真帆に動いてもらう・手・口・胸・足・素股・舐め合う・下から舐める・口で愛撫・指を中で）の settled の job すべて（標準と濃い版）。
   - 採用済みの本文を「すでにある本文」として見せ、重ねないよう頼む。
出力：grok_b2_wave_14.json、grok依頼_B2_第14陣/（1）、grok依頼_B2_続けての補充/（2）、第14陣_一覧.json・続けての補充_一覧.json
"""
import collections
import json
import sys
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
PROMPT = (OUT / "grokプロンプト_v3_0.txt").read_text(encoding="utf-8")
jobs = {}
for path in sorted(OUT.glob("grok_b2_wave_*.json")):
    if path.name == "grok_b2_wave_14.json":
        continue
    for row in json.loads(path.read_text(encoding="utf-8")):
        jobs[row["id"]] = row
templates = dict(jobs)  # 口づけの本文の元にする job：段階Bの初めの版（authoring/b_jobs、本文は b_texts.json）も使う
for path in sorted((ROOT / "authoring/b_jobs").glob("grok_wave_*.json")):
    for row in json.loads(path.read_text(encoding="utf-8")):
        templates.setdefault(row["id"], row)
adopted = collections.defaultdict(list)
for text in json.loads((ROOT / "tools/stage_b/b2_texts.json").read_text(encoding="utf-8")):
    adopted[text["job_id"]].append(text["body"])
KISSING = {"field": "contact.h_kiss_deep.active", "op": "eq", "value": True}
NO_KISS = {"field": "contact.h_kiss_deep.active", "op": "eq", "value": False}
TIERS = ("first", "few", "familiar")

# ---- 1. 口づけを続けたままの本文（台詞なし） ----
# 必要な組（tools で数えた。2026-09-29）：meaning と慣れ。動く本文の初めては、体位も
NEED = [("h_chest_over.first", "first", None), ("h_chest_skin.first", "first", None), ("h_thigh.first", "first", None),
        ("h_touch_direct.first", "first", None), ("h_touch_under.first", "first", None), ("h_finger_in.first", "few", None),
        ("h_move_slow.first", "first", "player_above"), ("h_move_normal.first", "first", "player_above"),
        ("h_move_slow.first", "few", "maho_above"), ("h_move_normal.first", "few", "maho_above"), ("h_move_fast.first", "few", "player_above"),
        ("h.sign.wants_more", "first", None), ("h.sign.wants_more", "few", None), ("h.sign.wants_more", "familiar", None),
        ("h.sign.beg", "few", None), ("h.sign.beg", "familiar", None),
        ("h.deflect.hand", "first", None), ("h.deflect.hand", "few", None), ("h.deflect.hand", "familiar", None),
        ("h.deflect.insert", "first", None), ("h.deflect.insert", "few", None), ("h.deflect.insert", "familiar", None),
        ("h.deflect.fast", "few", None), ("h.deflect.fast", "familiar", None),
        ("h.deadline", "first", None), ("h.deadline", "few", None), ("h.deadline", "familiar", None),
        ("h.hold_back", "first", None), ("h.hold_back", "few", None), ("h.hold_back", "familiar", None)]


def tiers_of(job):
    tier = job["_split"]["tier"]
    if tier is None:  # 慣れを _split に持たない job は、when の intimacy.tier から
        cond = next((c for c in job["when"].get("all", []) if isinstance(c, dict) and c.get("field") == "intimacy.tier"), None)
        if cond is None:
            return set(TIERS)
        tier = cond["value"] if cond["op"] == "in" else [cond["value"]]
    tier = tier if isinstance(tier, list) else [tier]
    result = set()
    for t in tier:
        result |= {"few_familiar": {"few", "familiar"}, "any": set(TIERS)}.get(t, {t})
    return result


def template(meaning, tier, position):
    """元の job（標準、背を向けていない、慣れが合う）。台詞ありを先に（state が同じ）。"""
    found = [j for j in templates.values() if j["_meaning"] == meaning and not j.get("style") and tier in tiers_of(j)
             and j["_split"].get("other") != "back" and '"back"' not in json.dumps(j["when"])
             and (position is None or j["_split"].get("position") in (None, position))]
    found.sort(key=lambda j: (j["_split"].get("position") != position, not j["speech"], j["id"]))
    assert found, (meaning, tier, position)
    return found[0]


kiss_rows = []
for meaning, tier, position in NEED:
    base = template(meaning, tier, position)
    state = dict(base["state"])
    state["慣れ"] = {"first": "初回（1回目のエッチ）", "few": "数回（2〜5回目）", "familiar": "慣れ（6回目以降）"}[tier]
    if position is None and "体位" in state and "背を向け" not in state["体位"]:
        state["体位"] = state["体位"]
    if position is None:
        state["体位"] = "向かい合っている（寝ているか座っているか、どちらが上かは書かない）"
    state["口づけ"] = "前の本文から、深く口づけしている。この本文のあいだも唇は離れない（真帆は話せない。声は喉の奥・鼻にかかる息だけ）"
    when = [c for c in base["when"]["all"] if c != NO_KISS and c.get("field") != "intimacy.tier"]
    when = [{"field": "intimacy.tier", "op": "eq", "value": tier}] + when + [KISSING]
    if position:
        if {"field": "intimacy.position", "op": "eq", "value": position} not in when:
            when.append({"field": "intimacy.position", "op": "eq", "value": position})
    else:
        when.append({"field": "intimacy.facing", "op": "eq", "value": "face"})
    when = [c for i, c in enumerate(when) if c not in when[:i]]  # 同じ条件を二重にしない
    identity = ".".join(["p14", meaning, tier] + ([position] if position else []) + ["kissing", "n"])
    kiss_rows.append({"id": identity, "meaning": base["meaning"] + "（深く口づけしたまま。台詞は書かない）", "speech": False, "length": base["length"],
                      "origin": base["origin"], "candidates": 5, "state": state, "_wave": "B2-14", "_meaning": meaning,
                      "_split": {"tier": tier, "position": position, "other": "kissing"}, "when": {"all": when}, "group": "b." + meaning,
                      "must_not": base["must_not"] + "。唇を離す・顔を離す・話す（台詞は書かない）。口づけ以外の口の動き（舐める・咥える）"})
    assert len({r["id"] for r in kiss_rows}) == len(kiss_rows), identity
(OUT / "grok_b2_wave_14.json").write_text(json.dumps(kiss_rows, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")

KISS_NOTE = ("\n\nこの依頼は、深い口づけを続けたまま起きる場面の本文です（台詞なし）。口づけは、指で触れる・胸や太ももを撫でる・動く、などをしても途切れません。"
             "そのあいだ真帆は話せないので、今ある台詞つきの本文が使えず、代わりの本文がありませんでした。"
             "どの job も、唇を重ねたまま起きることとして書いてください。真帆の反応は、唇の震え・鼻にかかった息・喉の奥の声・手や腰の動き・口づけの深さの変化で表します。"
             "止める本文（h.deflect.…）は、口づけを続けたまま、手でそっと押しとどめるなど、言葉を使わずに伝えます。締め切り（h.deadline）は、口づけの合間の仕草で「そろそろ」と伝えます（口づけはまだ終えない）。"
             "ねだる・もっと欲しがる本文（h.sign.…）は、口づけを深めたり、腰や手で引き寄せたりして伝えます。引き留める本文（h.hold_back）は、離れかけたこちらを口づけのまま引き留めます。"
             "\nそれ以外の規則（台詞なし、慣れの段階、地の文で器官を名前で呼ばず記号を使う、妊娠・避妊に触れない、must_not）は同じです。")
# ---- 2. 続けての補充（settled、同じ job id） ----
AUTO = ["h_move_slow", "h_move_normal", "h_move_fast", "h_maho_move", "h_maho_hand", "h_maho_mouth", "h_maho_breasts", "h_maho_feet",
        "h_sumata", "h_sixty_nine", "h_face_lick", "h_player_mouth", "h_finger_in"]
settled = sorted((j for j in jobs.values() if j["_meaning"] in {a + ".settled" for a in AUTO}),
                 key=lambda j: (bool(j.get("style")), j["_meaning"], j["id"]))
sup_rows = [dict(j, candidates=5 if len(adopted[j["id"]]) < 5 else 4) for j in settled]
SUP_NOTE = ("\n\nこの依頼は、前に書いてもらった job の書き足し（補充）です。どれも「さらに続けている」本文（meaning が …settled）で、同じ動きをしばらく続けているときに出ます。"
            "これから、同じ動きを自動で続けられるようにするので、この本文が何度も続けて出ます。1つの体位・慣れで3〜5本しかないと、すぐに同じ文が繰り返されます。"
            "各 job の「すでにある本文」は採用済みの本文です。書き出し・結び・台詞・文の並びを、これとも、同じファイルのほかの本文とも重ねないでください。"
            "同じ動きが続いている中での、小さな変化を書いてください（音、息、汗、手の置き場、表情や声の変わり方、締めつけや濡れ方、こちらの感じ方など）。速さ・体位は変えません。達しません。"
            "台詞なしの本文が、台詞ありの本文から台詞を抜いただけにならないようにしてください。1本の中で、同じ動作を2回書かないでください（「指が背で止まる。…指が背で止まり」のような言い直しをしない）。"
            "濃い本文（id が x で始まる job）は、標準より露骨に書いてください。この job に限り、部位の語と記号は地の文で1本に4つまで（同じ語・記号は2回まで）、擬音も使ってよいです。"
            "\nそれ以外の規則（台詞の数、慣れの段階の語、地の文で器官を名前で呼ばず記号を使う、記号を台詞に書かない、妊娠・避妊に触れない、must_not）は同じです。")


def write(folder_name, prefix, rows, note, label, size, with_existing):
    folder = OUT / folder_name
    folder.mkdir(exist_ok=True)
    for old in folder.glob("*.txt"):
        old.unlink()
    names = []
    for number, index in enumerate(range(0, len(rows), size), 1):
        chunk = rows[index:index + size]
        lines = []
        for r in chunk:
            item = {"id": r["id"], "meaning": r["meaning"], "speech": r["speech"], "length": r["length"], "origin": r["origin"], "本数": r["candidates"],
                    "must_not": r["must_not"], "state": r["state"]}
            if with_existing:
                item["すでにある本文"] = adopted[r["id"]]
            lines.append(json.dumps(item, ensure_ascii=False))
        body = ("指示\n"
                f"次の{len(chunk)}件の job を書いてください（段階Bの2版目・{label}）。本数は各 job の「本数」のとおりです（合わせて{sum(r['candidates'] for r in chunk)}本）。"
                "speech が true の job は真帆の台詞がちょうど1つ、false の job は台詞なしです。"
                + ("出力の id は job の id のあとに .v1 から番号を振ってください（取り込むときに振り直します）。" if with_existing else "")
                + "途中で切れそうなら、job の区切りで止めてください。「続けて」と言われたら、止めた job の次から出してください。"
                + note + "\n\n[\n  " + ",\n  ".join(lines) + "\n]\n\n" "プロンプト\n" + PROMPT)
        name = f"{prefix}_{number:02d}.txt"
        (folder / name).write_text(body, encoding="utf-8")
        names.append({"file": name, "jobs": len(chunk), "本数": sum(r["candidates"] for r in chunk)})
    return names


kiss_files = write("grok依頼_B2_第14陣", "B2_第14陣", kiss_rows, KISS_NOTE, "第14陣・口づけしたまま", 10, False)
sup_files = write("grok依頼_B2_続けての補充", "B2_続けての補充", sup_rows, SUP_NOTE, "さらに続けている本文の補充", 10, True)
(OUT / "第14陣_一覧.json").write_text(json.dumps({"files": kiss_files, "jobs": len(kiss_rows), "本数": sum(r["candidates"] for r in kiss_rows)}, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
(OUT / "続けての補充_一覧.json").write_text(json.dumps({"files": sup_files, "jobs": {r["id"]: {"採用済み": len(adopted[r["id"]]), "本数": r["candidates"]} for r in sup_rows},
                                                   "本数": sum(r["candidates"] for r in sup_rows)}, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
print("kiss", len(kiss_rows), sum(r["candidates"] for r in kiss_rows), kiss_files)
print("settled", len(sup_rows), sum(r["candidates"] for r in sup_rows), len(sup_files), "files")
