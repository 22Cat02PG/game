"""Mood answers selected through the same choices used by players."""

from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from nagishima.engine import Engine
from nagishima.session import Session


def press(engine, identity):
    view = engine.get_view()
    return engine.choose(identity, view["revision"], view["session"])


class MoodReleaseTests(unittest.TestCase):
    def setUp(self):
        temporary = TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)

    def engine(self, name, seed=42, cheats=False):
        return Engine(self.root / name, seed=seed, release="interaction_005", autosave=False, test_cheats=cheats)

    def test_check_mood_answers_the_actual_mood_across_repeat_phases(self):
        engine = self.engine("repeat")
        press(engine, "menu.talk")
        answers = [press(engine, "touch.check_mood") for _ in range(3)]
        self.assertEqual(
            [answer["blocks"][-1]["variant"] for answer in answers],
            ["check_mood.first.i005.joy", "check_mood.repeat.i005.interest", "check_mood.heated.i005.interest"],
        )
        self.assertEqual(answers[0]["status"]["mood_label"], "うれしそう")
        self.assertEqual(answers[1]["status"]["mood_label"], "こちらに気持ちを向けている")
        self.assertIn("今は", answers[-1]["blocks"][-1]["body"])
        press(engine, "menu.main")
        press(engine, "wait.30")
        press(engine, "menu.talk")
        later = press(engine, "touch.check_mood")
        self.assertEqual(later["blocks"][-1]["meaning"], "check_mood.start")
        self.assertTrue(later["blocks"][-1]["variant"].startswith("check_mood.start.i005."))

    def test_prior_affection_and_gentle_contact_select_distinct_answers(self):
        hot = self.engine("hot", cheats=True)
        self.assertTrue(Session(hot, test_cheats=True).execute({"command": "cheat", "action": "contact_unlock"})["ok"])
        press(hot, "menu.talk")
        press(hot, "touch.compliment")
        press(hot, "touch.compliment")
        hot_answer = press(hot, "touch.check_mood")
        self.assertEqual(hot_answer["blocks"][-1]["variant"], "check_mood.first.i005.hot")
        self.assertEqual(hot_answer["status"]["mood_label"], "熱っぽく高揚している")

        ease = self.engine("ease", cheats=True)
        self.assertTrue(Session(ease, test_cheats=True).execute({"command": "cheat", "action": "contact_unlock"})["ok"])
        press(ease, "near")
        press(ease, "menu.touch")
        press(ease, "touch.head")
        press(ease, "touch.head")
        press(ease, "menu.main")
        press(ease, "menu.talk")
        ease_answer = press(ease, "touch.check_mood")
        self.assertEqual(ease_answer["blocks"][-1]["variant"], "check_mood.first.i005.ease")
        self.assertEqual(ease_answer["status"]["mood_label"], "安心して甘えている")


if __name__ == "__main__":
    unittest.main()
