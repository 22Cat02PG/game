"""v8.4.8（ユーザー 2026-10-07 02:44「進めて」）：010 だけ。
- 二人いっしょに達する本文に、成り立たない体位では出ない条件（膝の上で向かい合っているのに「シーツの端を噛む」など）。
- 果てる本文への指摘の直し（「遅い動きのまま果て」は遅く動いているときだけ など）。
- 真帆が達したあと：高まりはじめの本文（「だんだん、気持ちよくなってきた」）はその回で出さず、余韻（intimacy.maho.afterglow）のあいだは余韻に合わせた本文を先に出す。"""
import unittest
from copy import deepcopy
from pathlib import Path

from nagishima.conditions import evaluate
from nagishima.content import Pack
from tools.run_stage_b_routes import Route

ROOT = Path(__file__).resolve().parents[1]
P009 = Pack(ROOT / "content/releases/interaction_009")
P010 = Pack(ROOT / "content/releases/interaction_010")
POSITIONS = {"few": ["player_above", "lying_face", "maho_above", "sitting_face", "leg_up", "legs_shoulder", "from_behind", "prone_back", "side_lying", "standing_back", "reverse_ride"],
             "first": ["player_above", "lying_face"]}


def act(route, key):
    while route.engine.snapshot()["offer"]:
        route.choose("offer.decline")
    route.action(key)


class V848(unittest.TestCase):
    def inside(self, tier="few", position="player_above"):
        route = Route(8481, tier=tier, release="interaction_010", hour=21, day_offset=2)
        self.addCleanup(route.close)
        route.begin()
        for key in ("h_kiss_deep", "h_strip_upper", "h_strip_lower", "h_strip_under", "h_strip_self", "h_pos_" + position):
            act(route, key)
        route.engine._state["intimacy"]["maho"]["arousal"] = 75
        act(route, "h_insert")
        return route

    def finish(self, route, before):
        state = route.engine._state
        state["intimacy"]["maho"]["arousal"] = before
        state["intimacy"]["maho"]["band"] = P010.intimacy.band(before)
        state["intimacy"]["player"]["arousal"] = P010.intimacy.raw["player"]["arousal_max"]
        route.engine._install_choices()
        act(route, "h_finish_inside")

    def test_009_unchanged(self):
        self.assertIsNone(P009.intimacy.afterglow)
        self.assertNotIn("intimacy.maho.afterglow", P009.registry.fields)
        self.assertFalse(any(t["id"].startswith("v848.") for t in P009.by_text.values()))
        self.assertEqual(P010.intimacy.afterglow, {"until_arousal": 60, "min_hands": 3})

    def test_afterglow(self):
        route = self.inside()
        self.finish(route, 80)  # いっしょに達する
        self.assertEqual(route.engine.snapshot()["intimacy"]["afterglow"], 0)
        act(route, "h_check")
        variant = [b["variant"] for b in route.engine.get_view()["blocks"] if b["meaning"] == "h_check.start"][0]
        self.assertTrue(variant.startswith("v848.h_check.start.after."), variant)  # 余韻に合わせた本文を先に出す
        for _ in range(12):  # 高まりが戻ると余韻を出る
            if "afterglow" not in route.engine.snapshot()["intimacy"]:
                break
            act(route, "h_chest_skin")
        self.assertNotIn("afterglow", route.engine.snapshot()["intimacy"])
        self.assertGreaterEqual(route.engine.snapshot()["intimacy"]["maho"]["arousal"], 60)

    def test_gradual_text_not_in_afterglow(self):
        text = P010.by_text["o15.h_check.start.few.mid.s.v1"]
        self.assertIn("だんだん、気持ちよくなってきた", text["body"])
        self.assertIn({"field": "intimacy.maho.climaxes", "op": "eq", "value": 0}, text["when"]["all"])  # その回で真帆が達したら出さない

    def test_together_positions(self):
        # 「シーツの端を噛む」は、膝の上で向かい合う・真帆が上・立って壁に手をつく体位では出ない
        text = P010.by_text["x2.h.climax.together.few.s.v5"]
        self.assertIn("シーツの端を噛", text["body"])
        route = Route(8482, tier="few", release="interaction_010", hour=21, day_offset=2)
        self.addCleanup(route.close)
        route.begin()
        for key in ("h_kiss_deep", "h_strip_upper", "h_strip_lower", "h_strip_under", "h_strip_self"):
            act(route, key)
        base = route.engine.snapshot()
        for tier, positions in POSITIONS.items():
            for position in positions:
                state = deepcopy(base)
                state["intimacy"].update(position=position, inserted=True, afterglow=0)
                state["contacts"] = []
                values = P010.registry.values(state)
                if tier == "first":
                    values["intimacy.tier"] = "first"
                rows = [t for t in P010.by_meaning["h.climax.together"] if not t["fallback"] and evaluate(t["when"], values) is True]
                self.assertGreaterEqual(len(rows), 3, (tier, position))  # どの体位にも本文が残る
                if position in ("sitting_face", "maho_above", "standing_back"):
                    self.assertNotIn(text["id"], [t["id"] for t in rows])

    def test_finish_pace_text(self):
        # 「遅い動きのまま果て」は、速く動いた直後にも出ていた。中に出す手では動く手の触れ合いが先に終わるので、速さの条件にせず、言い方を外した
        self.assertNotIn("遅い動き", P010.by_text["x2.h_finish_inside.start.familiar.side_lying.n.v3"]["body"])


if __name__ == "__main__":
    unittest.main()
