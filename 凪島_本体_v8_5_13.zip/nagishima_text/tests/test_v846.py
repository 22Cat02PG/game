"""v8.4.6（ユーザー 2026-10-06 18:16「おけ、では始めて」）：010 だけ。
前の本文の気持ちを受けて書いた本文（条件 flow.prev.<型>）。直前の本文に型があるときだけ出て、合うときは先に出す。
例：せがんだ直後に抱きしめると「……ぎゅってするだけ？」、「離れないで」の直後の締め切りに「離れたくないけど……」。"""
import unittest
from copy import deepcopy
from pathlib import Path

from nagishima.content import Pack
from tools.run_stage_b_routes import Route

ROOT = Path(__file__).resolve().parents[1]
P009 = Pack(ROOT / "content/releases/interaction_009")
P010 = Pack(ROOT / "content/releases/interaction_010")


def act(route, key):
    while route.engine.snapshot()["offer"]:
        route.choose("offer.decline")
    route.action(key)


class V846(unittest.TestCase):
    def setUp(self):
        self.route = Route(8461, tier="familiar", release="interaction_010", hour=21, day_offset=2)
        self.addCleanup(self.route.close)
        self.route.begin()
        act(self.route, "h_kiss_deep")
        self.state = self.route.engine.snapshot()

    def after(self, prev_id):
        state = deepcopy(self.state)
        state["contacts"] = []
        state["recent_text"] = state["recent_text"][-5:] + [{"id": prev_id, "group": P010.by_text[prev_id]["group"], "release": "interaction_010"}]
        return state

    def pick(self, meaning, prev_id):
        state = self.after(prev_id)
        return P010.select(meaning, state, {}, P010.registry.values(state))[0]["variant"]

    def test_009_unchanged(self):
        self.assertFalse(any(name.startswith("flow.prev.") for name in getattr(P009.registry, "fields", {})))
        self.assertFalse(any(t["id"].startswith("v846.") for t in P009.by_text.values()))
        self.assertIn("flow.prev.begging", P010.registry.fields)

    def test_prev_condition(self):
        urge = next(t for t in P010.by_meaning["h.sign.wants_more"] if "もっと" in t["body"] and not t["fallback"])
        calm = next(t for t in P010.by_meaning["h_kiss_deep.continue_short"] if not t["fallback"])
        flow = P010.intimacy.flow
        self.assertTrue(flow.prev_has(self.after(urge["id"]), "urgent"))
        self.assertTrue(flow.prev_has(self.after(urge["id"]), "begging"))
        self.assertFalse(flow.prev_has(self.after(calm["id"]), "begging"))
        # 受ける本文の型は狭い：こちらが頼む「上に来てほしい」、続きをせがむ「もう少しだけ強く」は拾わない
        ask = next(t for t in P010.by_meaning["h_pos_maho_above.start"] if t["body"].startswith("上に来てほしいと伝えると"))
        self.assertTrue(flow.prev_has(self.after(ask["id"]), "urgent"))
        self.assertFalse(flow.prev_has(self.after(ask["id"]), "begging"))
        more = next(t for t in P010.by_text.values() if not t["fallback"] and "もう少しだけ、強く" in t["body"])
        self.assertTrue(flow.prev_has(self.after(more["id"]), "stay"))
        self.assertFalse(flow.prev_has(self.after(more["id"]), "stay_close"))

    def test_receiver_after_urgent(self):
        urge = next(t for t in P010.by_meaning["h.sign.wants_more"] if "もっと" in t["body"] and not t["fallback"])
        chosen = self.pick("h_hug.start", urge["id"])
        self.assertTrue(chosen.startswith("v846.h_hug.start.urgent."), chosen)
        calm = next(t for t in P010.by_meaning["h_kiss_deep.continue_short"] if not t["fallback"])
        self.assertFalse(self.pick("h_hug.start", calm["id"]).startswith("v846."))

    def test_receiver_skips_release_line(self):
        urge = next(t for t in P010.by_meaning["h.sign.wants_more"] if "もっと" in t["body"] and not t["fallback"])
        release = next(t for t in P010.by_meaning["system.contact_released.hands"] if not t["fallback"])
        state = self.after(urge["id"])
        state["recent_text"].append({"id": release["id"], "group": release["group"], "release": "interaction_010"})
        self.assertTrue(P010.intimacy.flow.prev_has(state, "urgent"))

    def test_deadline_after_stay(self):
        stay = next(t for t in P010.by_text.values() if not t["fallback"] and t["meaning"].startswith("h_") and "離れないで" in t["body"])
        rows = [t for t in P010.by_meaning["h.deadline"] if t["id"].startswith("v846.")]
        self.assertGreaterEqual(len(rows), 3)
        values = P010.registry.values(self.after(stay["id"]))
        self.assertTrue(values["flow.prev.stay_close"])


    def test_same_step_sees_text_just_shown(self):
        # 条件の値は手の前に計られる。同じ手で、手の本文のあとに出る締め切りは、その手の本文（「離れないで」）を受ける
        stay = next(t for t in P010.by_text.values() if not t["fallback"] and t["meaning"].startswith("h_") and "離れないで" in t["body"])
        calm = next(t for t in P010.by_meaning["h_kiss_deep.continue_short"] if not t["fallback"])
        state = self.after(calm["id"])
        stale = P010.registry.values(state)
        self.assertFalse(stale["flow.prev.stay_close"])
        state["recent_text"].append({"id": stay["id"], "group": stay["group"], "release": "interaction_010"})
        chosen = P010.select("h.deadline", state, {}, stale)[0]["variant"]
        self.assertTrue(chosen.startswith("v846.h.deadline.stay"), chosen)

    def test_turned_mood_is_not_carried(self):
        # 「このまま」「離れないで」を受けて言い返す本文が、同じ型をもう一度持たない（次の本文がまた受け直さない）
        flow = P010.intimacy.flow
        for text in P010.by_text.values():
            if not text["id"].startswith("v846."):
                continue
            for name in ("stay_close", "content"):
                if '"flow.prev.' + name + '"' in str(text["when"]).replace("'", '"'):
                    self.assertNotIn(name, flow.info(text)[3], text["id"])

if __name__ == "__main__":
    unittest.main()
