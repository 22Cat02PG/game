from copy import deepcopy

from .codec import exact
from .errors import GameError, ensure
from . import clock


def typed(value, spec, nullable=True):
    if value is None:
        ensure(nullable and spec.get("nullable", False), "type", "未確定値をここには使えない。")
        return
    kind = spec["type"]
    if kind == "int":
        ensure(type(value) is int and spec.get("min", -2147483648) <= value <= spec.get("max", 2147483647), "type", "整数の型または範囲が違う。")
    elif kind == "bool":
        ensure(type(value) is bool, "type", "真偽値が必要。")
    elif kind in ("string", "enum"):
        ensure(type(value) is str and len(value) <= spec.get("max_length", 200), "type", "文字列の型または長さが違う。")
        if kind == "enum":
            ensure(value in spec["values"], "type", "未登録の値。")
    else:
        raise GameError("type", "未対応の型。")


def validate(expr, fields, depth=1, count=None):
    count = [0] if count is None else count
    count[0] += 1
    ensure(depth <= 8 and count[0] <= 128, "condition_limit", "条件式が上限を超えている。")
    ensure(type(expr) is dict, "condition", "条件はJSONの項目で指定する。")
    if set(expr) in ({"all"}, {"any"}):
        values = next(iter(expr.values()))
        ensure(type(values) is list, "condition", "条件の配列が必要。")
        for child in values:
            validate(child, fields, depth + 1, count)
    elif set(expr) == {"not"}:
        validate(expr["not"], fields, depth + 1, count)
    else:
        exact(expr, ["field", "op"], ["value"])
        ensure(expr["field"] in fields, "unknown_field", "条件の項目が未登録。")
        op, spec = expr["op"], fields[expr["field"]]
        ensure(op in ("eq", "ne", "lt", "le", "gt", "ge", "in", "exists", "missing"), "condition", "条件の比較が未登録。")
        if op in ("exists", "missing"):
            ensure("value" not in expr, "condition", "存在確認に比較値は使わない。")
        else:
            ensure("value" in expr, "condition", "比較値が必要。")
            if op == "in":
                ensure(type(expr["value"]) is list and expr["value"], "condition", "候補の配列が必要。")
                for value in expr["value"]:
                    typed(value, spec, False)
            else:
                typed(expr["value"], spec, False)
            if op in ("lt", "le", "gt", "ge"):
                ensure(spec["type"] == "int", "condition", "大小比較は整数だけに使う。")


def evaluate(expr, values):
    if "all" in expr:
        answers = [evaluate(x, values) for x in expr["all"]]
        return False if False in answers else None if None in answers else True
    if "any" in expr:
        answers = [evaluate(x, values) for x in expr["any"]]
        return True if True in answers else None if None in answers else False
    if "not" in expr:
        answer = evaluate(expr["not"], values)
        return None if answer is None else not answer
    value, op = values.get(expr["field"]), expr["op"]
    if op == "exists":
        return value is not None
    if op == "missing":
        return value is None
    if value is None:
        return None
    target = expr["value"]
    return {"eq": lambda: value == target, "ne": lambda: value != target, "lt": lambda: value < target, "le": lambda: value <= target, "gt": lambda: value > target, "ge": lambda: value >= target, "in": lambda: value in target}[op]()


def memory_key(memory):
    serial = memory["id"].rsplit(".", 1)[-1]
    return (memory["at"], int(serial) if serial.isdecimal() else 0, memory["id"])


def memory_index(state):
    choices = {m["id"]: m for m in state["memories"]["recent"] + state["memories"]["pinned"]}
    for summary in state["memories"]["summaries"].values():
        choices[summary["last"]["id"]] = summary["last"]
    result = {}
    for memory in choices.values():
        if {"player", "maho"} <= set(memory["participants"]) and memory["at"] <= state["world"]["now"]:
            kind = memory["kind"]
            if kind not in result or memory_key(memory) > memory_key(result[kind]): result[kind] = memory
    return result


def latest_memory(state, kind):
    return memory_index(state).get(kind)


class Registry:
    def __init__(self, catalog, actions, progression=None, life=None, intimacy=None):
        self.catalog, self.actions, self.progression = catalog, actions, progression
        self.fields = {}
        self.readers = {}

        def add(name, spec, read):
            self.fields[name], self.readers[name] = spec, read

        integer = {"type": "int", "min": 0, "max": 2147483647}
        boolean = {"type": "bool"}
        add("relation.stage", {**integer, "max": 4}, lambda s: s["relation"]["stage"])
        add("together", boolean, lambda s: s["actors"]["player"]["location"] == s["actors"]["maho"]["location"])
        add("distance", {"type": "enum", "values": ["normal", "near"]}, lambda s: s["distance"])
        add("mode", {"type": "enum", "values": ["normal", "private"]}, lambda s: s["mode"])
        from .progression import SLEEP_STATES, life_day, days_since_milestone
        start_at = clock.minutes(catalog["start_at"])
        add("affinity.value", {**integer, "max": 1000}, lambda s: s["affinity"]["value"])
        add("desire.value", {**integer, "max": 1000}, lambda s: s["desire"])
        add("desire.level", {"type": "enum", "values": ["low", "invite", "press"]}, lambda s: progression.desire_level(s["desire"]) if progression else "low")
        add("maho.sleep", {"type": "enum", "values": list(SLEEP_STATES)}, lambda s: s["maho_sleep"]["state"])
        add("progression.life_day", integer, lambda s: max(0, life_day(s["world"]["now"])))
        add("progression.days_since_milestone", integer, lambda s: max(0, days_since_milestone(s, start_at)))
        add("world.day", integer, lambda s: s["world"]["now"] // 1440)
        add("world.minute", {**integer, "max": 1439}, lambda s: s["world"]["now"] % 1440)
        add("world.weekday", {**integer, "max": 6}, lambda s: clock.date_time(s["world"]["now"]).weekday())
        add("world.slot", {"type": "enum", "values": ["morning", "noon", "evening", "night"]}, lambda s: clock.slot(s["world"]["now"]))
        add("world.weather", {"type": "enum", "values": ["clear", "cloudy", "rain"]}, lambda s: clock.weather(s["world"]["seed"], s["world"]["now"] // 1440))
        for actor in ("player", "maho"):
            for key, values in (("location", list(catalog["locations"])), ("posture", catalog["postures"]), ("outfit", catalog["outfits"]), ("hair", catalog["hair"][actor])):
                add(f"actor.{actor}.{key}", {"type": "enum", "values": values}, lambda s, a=actor, k=key: s["actors"][a][k])
        for name, definition in catalog["facts"].items():
            spec = {**definition["spec"], "nullable": True}
            add(f"fact.{name}.value", spec, lambda s, n=name: s["facts"][n]["value"])
            for actor in catalog["actors"]:
                def current(s, a=actor, n=name):
                    known = s["knowledge"][a].get(n)
                    return known is not None and known["snapshot"]["revision"] == s["facts"][n]["revision"]
                add(f"known.{actor}.{name}.current", boolean, current)
                add(f"known.{actor}.{name}.value", spec, lambda s, a=actor, n=name: s["knowledge"][a].get(n, {}).get("snapshot", {}).get("value"))
        for name in actions:
            add(f"contact.{name}.active", boolean, lambda s, n=name: any(c["action_id"] == n for c in s["contacts"]))
            add(f"contact.{name}.continues", {**integer, "nullable": True}, lambda s, n=name: next((c["continues"] for c in s["contacts"] if c["action_id"] == n), None))
            add(f"experience.{name}.count", integer, lambda s, n=name: s["experience"][n]["count"])
            if life:
                add(f"experience.{name}.tier", {"type": "enum", "values": ["first", "few", "familiar"]}, lambda s, n=name, r=life: "first" if s["experience"][n]["count"] < r.few_from else "few" if s["experience"][n]["count"] < r.familiar_from else "familiar")
            add(f"experience.{name}.last_age_days", {**integer, "nullable": True}, lambda s, n=name: None if s["experience"][n]["last_at"] is None else s["world"]["now"] // 1440 - s["experience"][n]["last_at"] // 1440)
        for name in catalog["habits"]:
            add(f"habit.{name}.established", boolean, lambda s, n=name: s["habits"][n]["established_at"] is not None)
        for name in ("shared_activities", "personal_stories", "fulfilled_promises", "completed_activities", "completed_projects"):
            add("progress." + name, integer, lambda s, n=name: s["progress"][n])
        add("habits.established_count", integer, lambda s: sum(h["established_at"] is not None for h in s["habits"].values()))
        add("promises.pending_count", {**integer, "max": 2}, lambda s: len(s["promises"]))
        add("orders.pending_count", {**integer, "max": 8}, lambda s: len(s["orders"]))
        for name in catalog["items"]:
            for actor in ("player", "maho"):
                add(f"item.{name}.{actor}_count", integer, lambda s, n=name, a=actor: sum(i["quantity"] for i in s["items"] if i["catalog_id"] == n and i["owner"] == a))
        add("project.status", {"type": "enum", "nullable": True, "values": ["planned", "ordered", "delivered", "ready", "installed", "completed", "cancelled"]}, lambda s: s["project"]["status"] if s["project"] else None)
        for kind in catalog["memory_kinds"]:
            add(f"memory.{kind}.available", boolean, lambda s, k=kind: latest_memory(s, k) is not None)
            add(f"memory.{kind}.age_days", {**integer, "nullable": True}, lambda s, k=kind: None if not latest_memory(s, k) else s["world"]["now"] // 1440 - latest_memory(s, k)["at"] // 1440)
            add(f"memory.{kind}.place", {"type": "enum", "values": list(catalog["locations"]), "nullable": True}, lambda s, k=kind: latest_memory(s, k)["location"] if latest_memory(s, k) else None)
            # v8.2.25（確かめ役 B N3）：暮らしの日（5:00 区切り）で数えた、いちばん新しい思い出からの日数
            add(f"memory.{kind}.life_days", {**integer, "nullable": True}, lambda s, k=kind: None if not latest_memory(s, k) else life_day(s["world"]["now"]) - life_day(latest_memory(s, k)["at"]))
            def captured(s, k=kind):
                return next((m for m in s["scene"]["memories"] if m["kind"] == k), None) if s["scene"] else None
            add(f"snapshot.{kind}.available", boolean, lambda s, f=captured: f(s) is not None)
            add(f"snapshot.{kind}.place", {"type": "enum", "values": list(catalog["locations"]), "nullable": True}, lambda s, f=captured: f(s)["location"] if f(s) else None)
        for kind in ("dating", "life"):
            add(f"anniversary.{kind}.available", boolean, lambda s, k=kind: (clock.anniversary_window(s, k) or {}).get("available", False))
            add(f"anniversary.{kind}.late_days", {**integer, "nullable": True}, lambda s, k=kind: (clock.anniversary_window(s, k) or {}).get("late_days"))
        for kind in ("joy", "shy", "ease", "interest"):
            add("mood." + kind, {**integer, "max": 2}, lambda s, k=kind: s["mood"][k])
        if intimacy:
            nullable_tier = {"type": "enum", "values": ["private", "invite", "wake"], "nullable": True}
            nullable_origin = {"type": "enum", "values": ["player", "maho"], "nullable": True}
            position = {"type": "enum", "values": list(intimacy.positions), "nullable": True}
            add("intimacy.active", boolean, lambda s: s["intimacy"] is not None)
            add("intimacy.entry", nullable_tier, lambda s: s["intimacy"]["entry"] if s["intimacy"] else None)
            add("intimacy.origin", nullable_origin, lambda s: s["intimacy"]["origin"] if s["intimacy"] else None)
            add("intimacy.tier", {"type": "enum", "values": ["first", "few", "familiar"]}, lambda s: intimacy.tier(s["intimacy_history"]["count"], life))
            add("intimacy.position", position, lambda s: s["intimacy"]["position"] if s["intimacy"] else None)
            add("intimacy.inserted", boolean, lambda s: bool(s["intimacy"] and s["intimacy"]["inserted"]))
            add("intimacy.maho.band", {"type": "enum", "values": ["low", "mid", "high", "near"]}, lambda s: intimacy.band(s["intimacy"]["maho"]["arousal"]) if s["intimacy"] else "low")
            add("intimacy.maho.satisfaction_level", {"type": "enum", "values": ["low", "mid", "high"]}, lambda s: intimacy.satisfaction_level(s["intimacy"]["maho"]["satisfaction"]) if s["intimacy"] else "low")
            add("intimacy.maho.climaxes", integer, lambda s: s["intimacy"]["maho"]["climaxes"] if s["intimacy"] else 0)
            if intimacy.afterglow:  # v8.4.8（010）：真帆が達したあと、高まりがまた上がるまで
                add("intimacy.maho.afterglow", boolean, lambda s: "afterglow" in (s["intimacy"] or {}))
            if intimacy.finish_outcome:  # v8.4.7（010）：中に出す手の真帆の結果（その手の本文を選ぶときだけ値がある）
                add("intimacy.finish_outcome", {"type": "enum", "values": ["climax", "near", "high", "rest"], "nullable": True}, lambda s: (s["intimacy"] or {}).get("finish_outcome"))
            # B2（2026-09-27）：向き、真帆が最後に達したときの行動、前の夜に一緒に眠ったか
            add("intimacy.facing", {"type": "enum", "values": ["face", "back", "player_mouth", "maho_mouth", "maho_breasts", "maho_feet", "face_sit", "sixty_nine"]}, lambda s: intimacy.facing(s))
            add("intimacy.maho.climax_source", {"type": "enum", "values": ["inserted", "finger", "mouth"], "nullable": True}, lambda s: s["intimacy"]["maho"]["climax_source"] if s["intimacy"] else None)
            add("intimacy.slept_together", boolean, lambda s: s["intimacy_history"]["slept_together"])
            add("intimacy.player.arousal_band", {"type": "enum", "values": ["low", "ready", "max"]}, lambda s: "max" if s["intimacy"] and s["intimacy"]["player"]["arousal"] >= intimacy.raw["player"]["arousal_max"] else "ready" if s["intimacy"] and s["intimacy"]["player"]["arousal"] >= intimacy.raw["player"]["finish_from"] else "low")
            add("intimacy.player.finishes", integer, lambda s: s["intimacy"]["player"]["finishes"] if s["intimacy"] else 0)
            add("intimacy.hold_back_used", boolean, lambda s: bool(s["intimacy"] and s["intimacy"]["hold_back_used"]))
            # v8.2.3：最後に出した場所（中・外・手・口）。「拭いてあげる」で消える（5回目の試運転の指摘5）
            add("intimacy.mess", {"type": "enum", "values": ["inside", "outside", "hand", "mouth"], "nullable": True}, lambda s: s["intimacy"]["mess"] if s["intimacy"] else None)
            add("intimacy.history_count", integer, lambda s: s["intimacy_history"]["count"])
            add("intimacy.last_result", {"type": "enum", "values": ["satisfied", "unsatisfied"], "nullable": True}, lambda s: s["intimacy_history"]["last_result"])
            # v8.2.12：淫乱度（下がらない）と、その段
            add("intimacy.lewdness", integer, lambda s: s["intimacy_history"]["lewdness"])
            add("intimacy.lewd_band", {"type": "enum", "values": ["shy", "open", "eager", "bold"]}, lambda s: intimacy.lewd_band(s["intimacy_history"]["lewdness"]))
            # v8.2.13：いま速さを変えられる行為の速さ（なければ normal）
            add("intimacy.pace", {"type": "enum", "values": ["slow", "normal", "fast"]}, lambda s: intimacy.pace_of(s)[1])
            # v8.4.2（010）：速さを変えた直前の動く速さ（none＝動いていなかった）。持たない版・エッチの外は none
            add("intimacy.move_before", {"type": "enum", "values": ["none", "slow", "normal", "fast"]}, lambda s: s["intimacy"].get("move_before", "none") if s["intimacy"] else "none")
            # v8.4.3（010）：体位を移る前の体位とその向き（none＝まだ移っていない）。持たない版・エッチの外は none
            positions_from = ["none"] + list(intimacy.positions)
            add("intimacy.position_from", {"type": "enum", "values": positions_from}, lambda s: s["intimacy"].get("position_from", "none") if s["intimacy"] else "none")
            facings_from = sorted({"none"} | {row["facing"] for row in intimacy.positions.values()})
            add("intimacy.facing_from", {"type": "enum", "values": facings_from},
                lambda s: intimacy.positions[s["intimacy"]["position_from"]]["facing"] if s["intimacy"] and s["intimacy"].get("position_from") else "none")
            # v8.4.6（010）：直前に出た本文の仕草・調子の型（前の本文の気持ちを受けて書いた本文の条件）。流れの設定がない版にはない
            if intimacy.flow:
                for name in intimacy.flow.names():
                    add("flow.prev." + name, boolean, lambda s, n=name: intimacy.flow.prev_has(s, n))
            add("intimacy.invite_ready", boolean, lambda s: intimacy.invite_ready(s, progression, life))
            # v8.2.25（指摘 R1）：この回に真帆の「上になる」「自分から入れる」の申し出を受けたか。精査 C-03：いま終えたら一緒に眠る時刻か
            add("intimacy.maho_led", boolean, lambda s: intimacy.maho_led(s))
            add("intimacy.maho_led_fresh", boolean, lambda s: intimacy.maho_led_fresh(s))  # v8.2.34：申し出のあとの最初の「真帆に動いてもらう」
            # v8.2.30（通し確かめ 4）：この回に始めた行為の数（「今日は〜から」「最初から」の台詞は、回の始めだけ）
            add("intimacy.actions_started", integer, lambda s: len(s["intimacy"]["satisfaction_uses"]) if s["intimacy"] else 0)
            add("night.sleep_after", boolean, lambda s: intimacy.sleep_night(s["world"]["now"]))
            # v8.2.25（精査 C-02）：その行為を、この回より前の回にしたことがあるか（「前より」「今日も」の本文。同じ回の中で始め直しても真にならない）
            for name in intimacy.actions:
                add(f"experience.{name}.before_session", boolean, lambda s, n=name: bool(s["intimacy"] and s["experience"][n]["first_at"] is not None and s["experience"][n]["first_at"] < s["intimacy"]["started_at"]))
            # v8.2.29：胸に触れる左右（続いていなければ既定＝最初の値）
            for name, choices in intimacy.sides.items():
                add(f"intimacy.side.{name}", {"type": "enum", "values": list(choices)}, lambda s, n=name, c=choices: intimacy.side_of(s, n))
            # v8.4.0（010）：暮らしで手をつないでいる側（つないでいなければ null）
            for name, row in intimacy.daily_sides.items():
                add(f"contact.{name}.side", {"type": "enum", "values": list(row["choices"]), "nullable": True},
                    lambda s, n=name, d=row["default"]: next((c.get("side", d) for c in s["contacts"] if c["action_id"] == n), None))
            add("stamina.value", {**integer, "max": intimacy.raw["player"]["stamina_max"]}, lambda s: s["stamina"]["value"])
            if intimacy.sleep_play:
                self._sleep_fields(add, intimacy.sleep_play, integer, boolean)
            if intimacy.events:
                self._event_fields(add, intimacy, integer, boolean)
            if intimacy.co_sleep:
                # v8.5.6：添い寝の間か（none／talk＝並んで横になっている／asleep＝真帆が隣で眠っている）
                add("cosleep.phase", {"type": "enum", "values": ["none", "talk", "asleep"]}, lambda s: s["co_sleep"]["phase"] if s.get("co_sleep") else "none")
            if intimacy.ask:
                # v8.5.10：頼む。ask.place＝今の場所の分類（頼めない場所は none）、ask.kind・ask.band＝してもらっている中身と、こちらの高まりの段（low・mid・high＝出せる）、
                # ask.under・ask.inside＝これまでに下着・中まで見せた回数（見せる本文では、その回を数える前）
                from .ask import ask_band
                ask_rules = intimacy.ask
                add("ask.place", {"type": "enum", "values": ask_rules.places + ["none"]}, lambda s: ask_rules.place_of.get(s["actors"]["player"]["location"], "none"))
                add("ask.kind", {"type": "enum", "values": list(ask_rules.kinds) + ["none"]}, lambda s: s["ask_play"]["kind"] if s.get("ask_play") else "none")
                add("ask.band", {"type": "enum", "values": ["low", "mid", "high"]}, lambda s: ask_band(s, ask_rules))
                add("ask.under", integer, lambda s: (s.get("ask") or {}).get("under", 0))
                add("ask.inside", integer, lambda s: (s.get("ask") or {}).get("inside", 0))
            if life is not None and life.town:
                # v8.5.11：季節（ゲームの中の月。春 3〜5・夏 6〜8・秋 9〜11・冬 12〜2）と、今いる店に二人で来た回数（店でなければ 0）
                from .island import season
                add("world.season", {"type": "enum", "values": ["spring", "summer", "autumn", "winter"]}, lambda s: season(s["world"]["now"]))
                add("town.visits", integer, lambda s: (s.get("town") or {"visits": {}})["visits"].get(s["actors"]["player"]["location"], 0))
            if life is not None and life.fishing:
                # v8.5.11：釣り。fish.last＝最後の釣果（none＝釣れなかった、まだ釣りをしていなければ null）、fish.new＝その釣果が図鑑に初めての種か、
                # fish.dinner＝その日の夕食に出す魚（まだ食べていないとき）、fish.book_count＝図鑑に載った種の数
                from .island import fish_record
                species = list(life.fishing["species"])
                add("fish.last", {"type": "enum", "values": species + ["none"], "nullable": True}, lambda s: (s.get("fish") or {}).get("last"))
                add("fish.new", boolean, lambda s: bool((s.get("fish") or {}).get("new")))
                add("fish.dinner", {"type": "enum", "values": species, "nullable": True}, lambda s: fish_record(s)["dinner"] if s.get("fish") else None)
                add("fish.book_count", integer, lambda s: len((s.get("fish") or {}).get("book", {})))
            add("night.kind", {"type": "enum", "values": ["workday_eve", "holiday_eve"]}, lambda s: intimacy.night_kind(s["world"]["now"], life))
            add("night.minutes_to_deadline", integer, lambda s: max(0, intimacy.deadline(s["world"]["now"], life) - s["world"]["now"]))
            if life is not None and life.bath:
                # v8.2.0：風呂（湯上がりの間か、一緒に入った回数、今日の入浴が一緒だったか）
                from .life_rules import bath_after
                add("bath.after", boolean, lambda s: bath_after(s, life))
                add("bath.together_count", integer, lambda s: s["bath"]["together_count"])
                add("bath.together", boolean, lambda s: bath_after(s, life) and s["bath"]["together"])
            for actor in ("maho", "player"):
                for layer in ("upper", "lower"):
                    choices = intimacy.raw["clothing"][actor][layer]
                    add(f"actor.{actor}.clothing.{layer}", {"type": "enum", "values": choices}, lambda s, a=actor, l=layer: s["actors"][a]["clothing"][l])

    def _sleep_fields(self, add, rules, integer, boolean):
        """段階C（010、v8.5.0）：寝込みの条件（本文・行動の when・反応と翌朝の表で使う）。
        寝込みの外では、ゲージ 0・段 low・段階 0・印なし。深さは今の親密度と受け入れた回数から。sleep.night.* は前の夜の記録（翌朝の一言まで残る）。"""
        from .progression import life_day, day_time
        band = {"type": "enum", "values": ["low", "mid", "high"]}
        gauge = {"type": "int", "min": 0, "max": 100}
        lead = {"type": "enum", "values": ["pleasure", "discomfort", "even"]}
        level = {"type": "int", "min": 0, "max": 9}
        kinds = {"type": "enum", "values": list(rules.kind_factor), "nullable": True}  # v8.5.6：添い寝（cosleep）があれば足す
        play = lambda s: s.get("sleep_play") or None
        record = lambda s: s.get("sleep_record") or {"accepted": 0, "cooling": None, "night": None}
        night = lambda s: record(s)["night"]

        def morning_line(s):
            yesterday = life_day(s["world"]["now"]) - 1
            history, event = s.get("intimacy_history"), s.get("event_morning")
            return bool((history and history["last_at"] is not None and life_day(history["last_at"]) == yesterday)
                        or (event and life_day(event["at"]) == yesterday) or (night(s) and night(s)["day"] == yesterday))
        depth = lambda s: play(s)["depth"] if play(s) else rules.depth(s["affinity"]["value"], record(s)["accepted"])
        lead_of = lambda row: "even" if row is None or row["pleasure"] == row["discomfort"] else "pleasure" if row["pleasure"] > row["discomfort"] else "discomfort"
        add("sleep.active", boolean, lambda s: play(s) is not None)
        add("sleep.kind", kinds, lambda s: play(s)["kind"] if play(s) else None)
        add("sleep.depth", {"type": "int", "min": -2, "max": 3}, depth)
        add("sleep.depth_group", {"type": "enum", "values": ["distant", "middle", "close"]}, lambda s: "distant" if depth(s) <= -1 else "middle" if depth(s) <= 1 else "close")
        for name in ("wake", "discomfort", "pleasure"):
            add(f"sleep.{name}", gauge, lambda s, g=name: play(s)["gauges"][g] if play(s) else 0)
            add(f"sleep.{name}_band", band, lambda s, g=name: rules.band(play(s)["gauges"][g]) if play(s) else "low")
        add("sleep.lead", lead, lambda s: lead_of(play(s)["gauges"] if play(s) else None))  # 快感と不快のどちらが上か
        add("sleep.level", level, lambda s: play(s)["level"] if play(s) else 0)  # この夜に使った行動の段階のいちばん上
        add("sleep.last", {"type": "enum", "values": [k for k in rules.actions if k != "sp_leave"], "nullable": True}, lambda s: play(s)["last"] if play(s) else None)  # 直前の行動（目覚めの本文で、何をしていたかに合わせる）
        add("sleep.day_time", {"type": "int", "min": 301, "max": 1740}, lambda s: day_time(s["world"]["now"]))  # 5:00 を区切りにした時刻（0:00 は 1440）
        add("sleep.accepted", integer, lambda s: record(s)["accepted"])
        add("sleep.accepted_tier", {"type": "enum", "values": ["none", "few", "many"]}, lambda s: "none" if record(s)["accepted"] == 0 else "few" if record(s)["accepted"] < 3 else "many")
        add("sleep.cooling", {"type": "enum", "values": ["none"] + list(rules.cooling_days)},
            lambda s: record(s)["cooling"]["kind"] if record(s)["cooling"] and record(s)["cooling"]["until"] > life_day(s["world"]["now"]) else "none")
        add("sleep.night.has", boolean, lambda s: night(s) is not None)
        # v8.5.13（010）：その朝に出た寝込みの翌朝の一言（sp.morning.<名前>。その暮らしの日のあいだ残る）。朝食の本文を一言に合わせる
        add("sleep.morning", {"type": "enum", "values": ["none"] + list(rules.morning_ids)},
            lambda s: record(s)["morning"]["id"] if record(s).get("morning") and record(s)["morning"]["day"] == life_day(s["world"]["now"]) else "none")
        # v8.5.13（010）：起きた一言（system.slept）のあとに、前の夜の翌朝の一言（エッチの h.morning・イベントの ev.*.morning・寝込みの sp.morning）が
        # 続くか。続く朝は、起きた一言を真帆の様子を書かない本文にする（あいさつが二度出ない・様子が食い違わない）。life.py の目覚めと同じ見方
        add("life.morning_line", boolean, lambda s: morning_line(s))
        add("sleep.night.kind", kinds, lambda s: night(s)["kind"] if night(s) else None)
        add("sleep.night.pleasure", gauge, lambda s: night(s)["pleasure"] if night(s) else 0)
        add("sleep.night.discomfort", gauge, lambda s: night(s)["discomfort"] if night(s) else 0)
        add("sleep.night.lead", lead, lambda s: lead_of(night(s)))
        add("sleep.night.level", level, lambda s: night(s)["level"] if night(s) else 0)
        add("sleep.night.fake_reveal", boolean, lambda s: bool(night(s) and night(s)["fake_reveal"]))
        add("sleep.night.reaction", {"type": "enum", "values": list(rules.reactions), "nullable": True}, lambda s: night(s)["reaction"] if night(s) else None)
        for name in rules.flags:
            add(f"sleep.flag.{name}", boolean, lambda s, n=name: bool(play(s) and n in play(s)["flags"]))
            add(f"sleep.night.flag.{name}", boolean, lambda s, n=name: bool(night(s) and n in night(s)["flags"]))
        for name in rules.actions:
            if name != "sp_leave":
                add(f"sleep.used.{name}", boolean, lambda s, n=name: bool(play(s) and n in play(s)["used"]))
                add(f"sleep.night.used.{name}", boolean, lambda s, n=name: bool(night(s) and n in night(s)["used"]))

    def _event_fields(self, add, intimacy, integer, boolean):
        """段階C（010、v8.5.1）：イベントのエッチの本文の条件。イベントの外では、段は low・入れていない・回数 0。
        慣れ（intimacy.tier）・淫乱度の段（intimacy.lewd_band）は普段のエッチと同じ項目を使う（イベントの最中は、この回を数える前の値）。"""
        from .event_play import PHASES
        rules = intimacy.events
        play = lambda s: s.get("event_play") or None
        nullable = lambda values: {"type": "enum", "values": list(values), "nullable": True}
        add("event.active", boolean, lambda s: play(s) is not None)
        add("event.kind", nullable(rules.events), lambda s: play(s)["kind"] if play(s) else None)
        add("event.phase", nullable(PHASES), lambda s: play(s)["phase"] if play(s) else None)
        add("event.position", nullable(rules.positions()), lambda s: play(s)["position"] if play(s) else None)
        add("event.inserted", boolean, lambda s: bool(play(s) and play(s)["inserted"]))
        add("event.step", integer, lambda s: play(s)["step"] if play(s) else 0)  # 進んだ前戯の数
        add("event.last", nullable(rules.last_keys()), lambda s: play(s)["last"] if play(s) else None)  # 直前の手（pre.<触れ合い>・pos.<体位>・fore.<前戯>・insert・move.<速さ>・touch.<手>）
        add("event.maho.band", {"type": "enum", "values": ["low", "mid", "high", "near"]}, lambda s: intimacy.band(play(s)["maho"]) if play(s) else "low")
        add("event.maho.climaxes", integer, lambda s: play(s)["climaxes"] if play(s) else 0)
        add("event.player.band", {"type": "enum", "values": ["low", "ready", "max"]},
            lambda s: "low" if not play(s) else "max" if play(s)["player"] >= intimacy.raw["player"]["arousal_max"] else "ready" if play(s)["player"] >= intimacy.raw["player"]["finish_from"] else "low")
        add("event.count", integer, lambda s: s["intimacy_history"]["by_entry"].get("event", 0))  # これまでのイベントのエッチの回数
        # v8.5.4：エッチへ移ったか（足音で止まっている間も、元の段で見る）・人目の段（0＝静か。人目の決まりのないイベント・イベントの外は 0）
        add("event.h", boolean, lambda s: bool(play(s) and play(s)["h"]))
        add("event.acts", integer, lambda s: play(s)["acts"] if play(s) else 0)  # v8.5.5：その場の手（pre）を選んだ回数
        add("event.meal", nullable(["dinner", "lunch"]), lambda s: play(s).get("meal") if play(s) else None)  # v8.5.11：台所の支度の食事（夕食・休日の昼）
        add("event.exposure", {"type": "int", "min": 0, "max": 9},
            lambda s: rules.events[play(s)["kind"]].exposure_level(play(s)["exposure"]) if play(s) else 0)
        # v8.5.3：真帆の酔いの段（0＝しらふ。酔いの決まりのないイベント・イベントの外は 0）
        add("event.drunk", {"type": "int", "min": 0, "max": 9},
            lambda s: rules.events[play(s)["kind"]].drunk_level(play(s)["drunk"]) if play(s) else 0)
        from .progression import life_day
        # v8.5.3：最後にお酒を飲んだ夜（晩酌でほろ酔い以上）。days：その夜からの生活日数（0＝今夜、1＝翌朝・翌日。飲んだことがなければ null）、drunk：その夜いちばん酔った段
        add("event.drink_night.days", {**integer, "nullable": True},
            lambda s: None if not s.get("drink_night") else life_day(s["world"]["now"]) - s["drink_night"]["day"])
        add("event.drink_night.drunk", {"type": "int", "min": 0, "max": 9}, lambda s: s["drink_night"]["drunk"] if s.get("drink_night") else 0)
        for kind in rules.events:
            # v8.5.2：イベントごとのエッチの回数と、最後のその回からの生活日数（したことがなければ null）
            add(f"event.{kind}.count", integer, lambda s, k=kind: (s.get("event_record") or {}).get(k, {}).get("count", 0))
            add(f"event.{kind}.days", {**integer, "nullable": True},
                lambda s, k=kind: None if k not in (s.get("event_record") or {}) else life_day(s["world"]["now"]) - s["event_record"][k]["last_day"])

    def values(self, state, locals_=None):
        from .progression import life_day
        result = {key: reader(state) for key, reader in self.readers.items() if not key.startswith("memory.")}
        memories = memory_index(state)
        for kind in self.catalog["memory_kinds"]:
            memory = memories.get(kind)
            result["memory." + kind + ".available"] = memory is not None
            result["memory." + kind + ".age_days"] = None if memory is None else state["world"]["now"] // 1440 - memory["at"] // 1440
            result["memory." + kind + ".place"] = None if memory is None else memory["location"]
            result["memory." + kind + ".life_days"] = None if memory is None else life_day(state["world"]["now"]) - life_day(memory["at"])
        result.update({"local." + key: value for key, value in (locals_ or {}).items()})
        return result

    def local_fields(self, declarations):
        return {**self.fields, **{"local." + key: spec for key, spec in declarations.items()}}
