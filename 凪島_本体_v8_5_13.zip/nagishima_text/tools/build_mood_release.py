"""Build a mood-aware prose release without changing the published source."""

from copy import deepcopy
from pathlib import Path
import os
import shutil
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from nagishima.codec import bytes_digest, read_json, write_json
from nagishima.content import FILES, Pack


SOURCE = "interaction_004"
TARGET = "interaction_005"
BATCH = ROOT / "collaboration" / "batches" / "mood_truth_001" / "final_text.json"
RELEASES = ROOT / "content" / "releases"
PHASES = ("first", "start", "repeat", "heated")
CATEGORIES = ("hot", "ease", "interest", "joy")


def atom(field, op, value):
    return {"field": "mood." + field, "op": op, "value": value}


def condition(category):
    hot = {"all": [atom("joy", "ge", 2), atom("shy", "ge", 2)]}
    if category == "hot":
        return hot
    if category == "ease":
        return {"all": [atom("ease", "ge", 2), atom("joy", "ge", 1), {"not": hot}]}
    if category == "interest":
        return {"all": [atom("interest", "ge", 2), atom("ease", "lt", 2), {"not": hot}]}
    return {"all": [atom("joy", "ge", 1), atom("interest", "lt", 2), atom("ease", "lt", 2), {"not": hot}]}


def main():
    source = Pack(RELEASES / SOURCE)
    target = RELEASES / TARGET
    if target.exists():
        raise SystemExit(f"公開済み版を上書きしない: {target}")
    batch = read_json(BATCH)
    if batch["batch_id"] != "mood_truth_001" or batch["source_release"] != SOURCE:
        raise SystemExit("原稿バッチの出典が一致しない")
    items = batch["items"]
    expected = {f"check_mood.{phase}.i005.{category}" for phase in PHASES for category in CATEGORIES}
    by_id = {item["text_id"]: item for item in items}
    if len(items) != len(expected) or set(by_id) != expected:
        raise SystemExit("気分別本文のIDが不足または重複")

    texts = [deepcopy(t) for t in source.texts if not (t["meaning"].startswith("check_mood.") and not t["fallback"])]
    safe_fallback = {
        "first": "「今は、気にかけてもらえてうれしいよ」真帆は自分の気持ちを確かめ、初めての問いにゆっくり答えた。",
        "start": "「今は、聞いてもらえてうれしいよ」真帆は自分の気持ちを確かめ、落ち着いた声で答えた。",
        "repeat": "「また聞いてくれたね。今は、気にかけてもらえてうれしいよ」真帆は自分の気持ちを確かめて答えた。",
        "heated": "「続けて聞いてくれて、今はうれしいよ」真帆は自分の気持ちを確かめ、言葉を選んで答えた。",
    }
    for text in texts:
        if text["meaning"] in {f"check_mood.{phase}" for phase in PHASES} and text["fallback"]:
            text["body"] = safe_fallback[text["meaning"].split(".")[-1]]

    for phase in PHASES:
        for category in CATEGORIES:
            identity = f"check_mood.{phase}.i005.{category}"
            item = by_id[identity]
            body = item["body"]
            if not isinstance(body, str) or not 35 <= len(body) <= 160 or "今は" not in body:
                raise SystemExit(f"本文の形式が不正: {identity}")
            texts.append({
                "id": identity,
                "meaning": f"check_mood.{phase}",
                "when": condition(category),
                "slots": [],
                "group": identity,
                "body": body,
                "fallback": False,
            })

    temporary = Path(tempfile.mkdtemp(prefix=".building-mood-", dir=RELEASES))
    try:
        for name in FILES:
            write_json(temporary / name, texts if name == "texts.json" else read_json(source.path / name))
        write_json(temporary / "release.json", {
            "id": TARGET,
            "rules_version": source.manifest["rules_version"],
            "files": {name: bytes_digest((temporary / name).read_bytes()) for name in FILES},
            "control_sha256": source.control_hash,
        })
        write_json(temporary / "revision_provenance.json", {
            "source_release": SOURCE,
            "source_sha256": source.hash,
            "batch_id": batch["batch_id"],
            "status": "working_draft",
            "reviewed": False,
            "note": "今の気分を尋ねる行動の本文を、表示時の気分条件に合わせて差し替えた。人間の承認は記録していない。",
            "items": [{"text_id": item["text_id"], "source": item["source"]} for item in items],
        })
        Pack(temporary)
        os.rename(temporary, target)
    finally:
        if temporary.exists():
            shutil.rmtree(temporary)
    print(target)


if __name__ == "__main__":
    main()
