"""v8.4.1（ユーザー 2026-10-06 07:19「提案通りにしていい。進めて」）：010 だけ。
- 後ろから（四つん這い・立って壁に手をつく）で、入れているとき：片腕を引く・両腕を引く・引き寄せて抱きしめる（何度か・慣れた回から）。
  抱きしめるは、その二つの体位では「覆いかぶさって抱きしめる」。
- 手や姿勢がふさがる触れ合いの最中は、食い違う本文（真帆がシーツをつかむ・こちらが両手で腰をつかむ・四つん這い など）を出さない。
- 抜いたら腕を引く・引き寄せて抱きしめる・両手をつなぐは終える。体位を変えたら、手をつなぐ・抱きしめるなどは終える。
- 頁「寄り添う」は「手と体」。"""
import json
import re
import unittest
from pathlib import Path

from nagishima.conditions import evaluate
from nagishima.content import Pack
from nagishima.menus import PAGES
from tools.run_stage_b_routes import Route

ROOT = Path(__file__).resolve().parents[1]
P009 = Pack(ROOT / "content/releases/interaction_009")
P010 = Pack(ROOT / "content/releases/interaction_010")
NEW = ("h_arm_pull_one", "h_arm_pull_both", "h_hug_pull")
LABELS = {"h_arm_pull_one": "片腕を引く", "h_arm_pull_both": "両腕を引く", "h_hug_pull": "引き寄せて抱きしめる"}
DIALOGUE = re.compile(r"「[^」]*」")
# 触れ合いの最中に出てはいけない書き方（試験で見る代表。make の条件はもっと広い）
FORBIDDEN = {
    "h_arm_pull_both": re.compile(r"シーツを(握|つか|掴)|壁を(つか|掴|押)|両手で(腰|尻)|腰を両手|手をつ[いく]|肘をつ"),
    "h_hug_pull": re.compile(r"四つん這い|突き出|シーツを(握|つか|掴)|壁を(つか|掴|押)|壁に手を|両手で(腰|尻)|腰を両手"),
    "h_arm_pull_one": re.compile(r"両手で(腰|尻|シーツ)|腰を両手|両手をつ"),
    "h_hug": re.compile(r"両手で(腰|尻)|腰を両手"),
}


def act(route, key):
    while route.engine.snapshot()["offer"]:
        route.choose("offer.decline")
    route.action(key)


def choices(route):
    return {c["id"]: c for c in route.engine.get_view()["choices"]}


def contacts(route):
    return [c["action_id"] for c in route.engine.snapshot()["contacts"]]


class V841(unittest.TestCase):
    def inside(self, seed, tier, position):
        route = Route(seed, tier=tier, release="interaction_010", hour=21, day_offset=2)
        self.addCleanup(route.close)
        route.begin()
        for _ in range(10):
            if route.engine.snapshot()["intimacy"]["maho"]["arousal"] >= 70:
                break
            act(route, "h_kiss_deep")
        for key in ("h_lift_upper", "h_strip_lower", "h_shift_under", "h_strip_self", "h_pos_" + position):
            act(route, key)
        return route

    def test_009_unchanged_and_rules(self):
        for key in NEW:
            self.assertNotIn(key, P009.intimacy.actions)
            action = P010.intimacy.actions[key]
            self.assertEqual((action["label"], action["positions"], action["needs"]["inserted"], action["needs"]["tier_from"]),
                             (LABELS[key], ["from_behind", "standing_back"], True, "few"))
            self.assertEqual(P010.intimacy.action_pages[key], "h_close")
            self.assertEqual(P010.intimacy.action_facings[key], ("back",))
        self.assertFalse(P009.intimacy.inserted_stops or P009.intimacy.position_stops)
        self.assertEqual(set(P010.intimacy.inserted_stops), set(NEW) | {"h_hands_both"})
        self.assertTrue({"h_hands", "h_hands_both", "h_hug", "h_back"} | set(NEW) <= set(P010.intimacy.position_stops))
        self.assertTrue(set(NEW) <= set(P010.intimacy.after_stops))
        self.assertEqual(PAGES["h_close"], "手と体")

    def test_labels_and_need_inserted(self):
        route = self.inside(8841, "few", "from_behind")
        route.choose("menu.main")
        route.choose("menu.h_close")
        page = choices(route)
        self.assertEqual(page["touch.h_hug"]["label"], "覆いかぶさって抱きしめる")
        for key, label in LABELS.items():
            self.assertEqual(page["touch." + key]["label"], label)
            self.assertFalse(page["touch." + key]["available"], key)  # 入れる前は選べない
        act(route, "h_insert")
        route.choose("menu.main")
        route.choose("menu.h_close")
        page = choices(route)
        for key in NEW:
            self.assertTrue(page["touch." + key]["available"], key)
        # 横向き・うつ伏せ・背を向けて乗るでは出さない（抱きしめるは「後ろから抱きしめる」のまま）
        self.assertEqual(P010.intimacy.settings["action_position_labels"]["h_hug"]["side_lying"], "後ろから抱きしめる")

    def test_exclusive_and_stops(self):
        route = self.inside(8842, "few", "from_behind")
        for key in ("h_insert", "h_move_normal", "h_arm_pull_one"):
            act(route, key)
        self.assertIn("h_arm_pull_one", contacts(route))
        act(route, "h_arm_pull_both")
        self.assertEqual([c for c in contacts(route) if c in NEW], ["h_arm_pull_both"])
        act(route, "h_hug_pull")
        self.assertEqual([c for c in contacts(route) if c in NEW + ("h_hug",)], ["h_hug_pull"])
        act(route, "h_hug")
        self.assertEqual([c for c in contacts(route) if c in NEW + ("h_hug",)], ["h_hug"])
        act(route, "h_arm_pull_one")
        act(route, "h_back")  # 片腕を引きながら、もう片方の手で背中を撫でられる
        self.assertTrue({"h_arm_pull_one", "h_back"} <= set(contacts(route)))
        act(route, "h_hands")  # 同じ手を使う
        self.assertNotIn("h_arm_pull_one", contacts(route))
        act(route, "h_arm_pull_both")
        act(route, "h_withdraw")
        self.assertFalse(set(contacts(route)) & set(NEW))
        act(route, "h_hands")
        act(route, "h_pos_lying_face")
        self.assertNotIn("h_hands", contacts(route))  # 体位を変えたら手を離す

    def test_conflicting_texts_not_offered(self):
        """触れ合いの最中に出うる本文（動く・速さを変える・合図・達する・中で果てる）に、食い違う書き方がない。候補が残っている。"""
        for n, (state, position, tier) in enumerate((("h_arm_pull_both", "from_behind", "few"), ("h_arm_pull_both", "standing_back", "familiar"),
                                                      ("h_hug_pull", "from_behind", "familiar"), ("h_hug_pull", "standing_back", "familiar"),
                                                      ("h_arm_pull_one", "from_behind", "few"), ("h_hug", "from_behind", "familiar"),
                                                      ("h_hug", "standing_back", "familiar"))):
            route = self.inside(8850 + n, tier, position)
            for key in ("h_insert", "h_move_normal", state):
                act(route, key)
            pack, snap = route.engine.pack, route.engine.snapshot()
            move = next(c for c in snap["contacts"] if c["action_id"] == "h_move_normal")
            for pace in ("h_move_slow", "h_move_normal", "h_move_fast"):
                snap["contacts"] = [c for c in snap["contacts"] if not c["action_id"].startswith("h_move_")] + [dict(move, action_id=pace)]
                values = pack.registry.values(snap)
                checks = [(meaning, values) for meaning in (pace + ".start", pace + ".continue_short", "h.sign.high", "h.climax.maho")]
                # v8.4.7（010）：中に出す本文は、真帆の結果（intimacy.finish_outcome）があるときに選ばれる。結果ごとに確かめる
                for outcome in (("climax", "near", "high", "rest") if pack.intimacy.finish_outcome else (None,)):
                    if outcome:
                        snap["intimacy"]["finish_outcome"] = outcome
                    checks.append(("h_finish_inside.start", pack.registry.values(snap)))
                    snap["intimacy"].pop("finish_outcome", None)
                for meaning, values in checks:
                    rows = [t for t in pack.by_meaning[meaning] if not t["fallback"] and evaluate(t["when"], values) is True]
                    self.assertGreaterEqual(len(rows), 3, (state, position, meaning))
                    bad = [t["id"] for t in rows if FORBIDDEN[state].search(t["body"])]
                    self.assertEqual(bad, [], (state, position, meaning))

    def test_new_texts(self):
        groups = {}
        for text in P010.by_text.values():
            if text["id"].startswith("v841.") or text["meaning"].split(".")[0] in NEW:
                if text["fallback"]:
                    continue
                key = (text["meaning"], json.dumps(text["when"], sort_keys=True)) if text["group"].startswith("sh.") else text["group"]
                groups.setdefault(key, []).append(text)
                if re.search(r"突|腰を送|打ちつけ", text["body"]) and text["meaning"].split(".")[0] in NEW:
                    self.assertIn("h_move_normal", json.dumps(text["when"]), text["id"])  # 動いているときだけ
        self.assertGreater(len(groups), 20)
        for key, rows in groups.items():
            if isinstance(key, str):
                self.assertTrue(any(not DIALOGUE.search(t["body"]) for t in rows), key)

    def test_playthrough_has_no_placeholder(self):
        """四つん這い・立って後ろからで、足した触れ合いと速さを変える・続けるを順に選ぶ。仮の本文が出ない。"""
        placeholders, seen = [], set()
        for n, (position, tier) in enumerate((("from_behind", "few"), ("from_behind", "familiar"), ("standing_back", "familiar"))):
            route = self.inside(8860 + n, tier, position)
            act(route, "h_insert")
            for state in NEW + ("h_hug",):
                for key in ("h_move_slow", state, state, "h_move_normal", state, "h_move_fast", state):
                    try:
                        act(route, key)
                    except AssertionError:
                        continue  # 果てたあとの回復待ちなど、そのとき選べない行動は飛ばす
                    for block in route.engine.get_view()["blocks"]:
                        seen.add(block["meaning"].split(".")[0])
                        if route.engine.pack.by_text[block["variant"]]["fallback"]:
                            placeholders.append((position, state, key, block["meaning"]))
        self.assertEqual(placeholders, [])
        self.assertTrue(set(NEW) <= seen)


if __name__ == "__main__":
    unittest.main()
