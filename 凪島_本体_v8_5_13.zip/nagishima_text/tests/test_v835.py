"""v8.3.5（ユーザー 2026-10-02「やっていい」）：v8.3.4 の「続けている行為の一行」（h.with.*）をやめた。
続けている行為は本文に書かず、状態表示の「続いている」で見せる（1手で効くのは選んだ行為だけなので、選んでいない刺激を本文に書かない）。"""
import unittest
from pathlib import Path

from nagishima.content import Pack
from tools.run_stage_b_routes import Route

ROOT = Path(__file__).resolve().parents[1]
P010 = Pack(ROOT / "content/releases/interaction_010")


class V835(unittest.TestCase):
    def test_no_accompany_lines(self):
        self.assertNotIn("accompany", P010.intimacy.settings)
        self.assertFalse([m for m in P010.meanings if m.startswith("h.with.")])

    def test_status_shows_held(self):
        route = Route(7, day_offset=2, tier="familiar", release="interaction_010")
        self.addCleanup(route.close)
        route.begin()
        route.action("h_strip_upper")
        route.action("h_chest_skin")
        route.action("h_kiss_deep")  # 胸に触れたまま口づける
        view = route.engine.get_view()
        # v8.4.9（010）：同じ回に2回目からの深い口づけは h_kiss_deep.again（begin で1回口づけている）
        self.assertIn([b["meaning"] for b in view["blocks"]][0], ("h_kiss_deep.start", "h_kiss_deep.again"))
        self.assertFalse([b for b in view["blocks"] if b["meaning"].startswith("h.with.")])
        self.assertEqual(len(view["status"]["held_actions"]), 2)  # 状態表示：胸に直接触れる・深く口づける


if __name__ == "__main__":
    unittest.main()
