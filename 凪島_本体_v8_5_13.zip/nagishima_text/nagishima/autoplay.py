"""Small deterministic reference player for the base game's complete route.

The policy reads public view/snapshot data and returns one displayed command.
It has no mutable memory, randomness, direct state changes, or engine imports;
the caller executes commands through the same dispatcher as the human CLI.
An external AI can replace this function without changing the game rules.
"""
from .progression import life_day


def _next_command_route(view, state):
    """Return an available ``choose`` command, or None when done/unsupported.

    This deliberately small policy targets a fresh base-release game and saves
    made along its route. It is a reference player, not a general planner for
    every optional scene or third-party content pack.
    """
    available = {item["id"] for item in view["choices"] if item["available"]}

    def choose(identity):
        if identity in available:
            return {"command": "choose", "id": identity}
        return None

    def on_page(page, identity):
        if view["page"] != page:
            return choose("menu." + page if view["page"] == "main" else "menu.main")
        return choose(identity) or choose("menu.next")

    def promise():
        pending = next((p for p in state["promises"] if p["kind"] == "tea"), None)
        identity = "fulfil." + pending["id"] if pending else "begin.promise_tea"
        return on_page("plans", identity)

    # Answer an outstanding question before checking the terminal condition.
    # Declining incidental offers makes the route stable across seeds.
    if state["offer"]:
        return choose("offer.decline")
    if state["scene"]:
        for identity in ("scene.yes", "scene.tea", "scene.remember", "scene.listen", "scene.finish"):
            command = choose(identity)
            if command:
                return command
        return None

    stage = state["relation"]["stage"]
    if stage >= 4:
        return None
    if state["mode"] == "private":
        return on_page("main", "private.end")
    if any(state["actors"][actor]["location"] != "living_room" for actor in ("player", "maho")):
        return on_page("move", "move.joint.living_room")

    progress = state["progress"]
    if stage == 0:
        for actor, fact in (("player", "maho.drink"), ("maho", "player.drink")):
            known = state["knowledge"][actor].get(fact)
            if not known or known["snapshot"]["revision"] != state["facts"][fact]["revision"]:
                return on_page("talk", "begin.two_cups")
        if progress["shared_activities"] < 1:
            return on_page("activities", "activity.tea")
    elif stage == 1:
        if progress["personal_stories"] < 1:
            return on_page("talk", "begin.workbench_half")
        if progress["fulfilled_promises"] < 1:
            return promise()
    elif stage == 2:
        if state["experience"]["hands"]["count"] < 1:
            identity = "near" if state["distance"] != "near" else "touch.hands"
            return on_page("touch", identity)
        if progress["shared_activities"] < 3:
            return on_page("activities", "activity.tea")
    else:
        if progress["fulfilled_promises"] < 2:
            return promise()
        # Habits require activities on three different game days. Sleeping
        # advances game time immediately; this never sleeps the real process.
        today = state["world"]["now"] // 1440
        for kind in ("tea", "quiet"):
            habit = state["habits"][kind]
            if habit["count_days"] < 3 and habit["last_day"] != today:
                return on_page("activities", "activity." + kind)
        if any(state["habits"][kind]["count_days"] < 3 for kind in ("tea", "quiet")):
            return on_page("main", "sleep")
        if progress["shared_activities"] < 5:
            return on_page("activities", "activity.tea")

    return on_page("talk", "begin.milestone_" + str(stage + 1))


def _next_social_command_route(view, state):
    """A deterministic route that lets Maho initiate parts of daily life.

    It reaches the same ending as :func:`next_command`, but deliberately uses
    ``listen`` when the director has a useful intention and accepts the offer.
    This exercises the reciprocal path without hidden state or real-time waits.
    """
    available = {item["id"] for item in view["choices"] if item["available"]}

    def choose(identity):
        if identity in available:
            return {"command": "choose", "id": identity}
        return None

    def on_page(page, identity):
        if view["page"] != page:
            return choose("menu." + page if view["page"] == "main" else "menu.main")
        return choose(identity) or choose("menu.next")

    def listen_for(*kinds):
        intention = state.get("intention")
        if intention and intention["kind"] in kinds:
            return on_page("main", "listen")
        return None

    def promise():
        pending = next((p for p in state["promises"] if p["kind"] == "tea"), None)
        if pending:
            offered = listen_for("promise")
            if offered:
                return offered
            return on_page("plans", "fulfil." + pending["id"])
        return on_page("plans", "begin.promise_tea")

    if state["offer"]:
        kind = state["offer"]["kind"]
        stage = state["relation"]["stage"]
        progress = state["progress"]
        today = state["world"]["now"] // 1440
        useful = (
            kind == "preference"
            or kind == "closeness" and state["experience"]["hands"]["count"] < 1
            or kind == "promise" and progress["fulfilled_promises"] < (2 if stage >= 3 else 1)
            or kind == "shared" and (
                stage == 0 and progress["shared_activities"] < 1
                or stage == 2 and progress["shared_activities"] < 3
                or stage >= 3 and (
                    state["habits"]["tea"]["count_days"] < 3
                    and state["habits"]["tea"]["last_day"] != today
                    or progress["shared_activities"] < 5
                )
            )
            or kind == "care" and stage >= 3 and (
                state["habits"]["quiet"]["count_days"] < 3
                and state["habits"]["quiet"]["last_day"] != today
            )
            or kind in ("project", "receive", "private")
        )
        return choose("offer.accept" if useful else "offer.decline")
    if state["scene"]:
        for identity in ("scene.yes", "scene.tea", "scene.remember", "scene.listen", "scene.finish"):
            command = choose(identity)
            if command:
                return command
        return None

    stage = state["relation"]["stage"]
    if stage >= 4:
        return None
    if state["mode"] == "private":
        return on_page("main", "private.end")
    if any(state["actors"][actor]["location"] != "living_room" for actor in ("player", "maho")):
        return on_page("move", "move.joint.living_room")

    progress = state["progress"]
    if stage == 0:
        missing_preference = any(
            not state["knowledge"][actor].get(fact)
            or state["knowledge"][actor][fact]["snapshot"]["revision"] != state["facts"][fact]["revision"]
            for actor, fact in (("player", "maho.drink"), ("maho", "player.drink"))
        )
        if missing_preference:
            # The first listen also lets the director choose the preference
            # goal, so Maho starts the opening conversation herself.
            if state["world"]["operation_seq"] == 0:
                return on_page("main", "listen")
            offered = listen_for("preference")
            if offered:
                return offered
            return on_page("talk", "begin.two_cups")
        if progress["shared_activities"] < 1:
            offered = listen_for("shared")
            return offered or on_page("activities", "activity.tea")
    elif stage == 1:
        if progress["personal_stories"] < 1:
            return on_page("talk", "begin.workbench_half")
        if progress["fulfilled_promises"] < 1:
            return promise()
    elif stage == 2:
        if state["experience"]["hands"]["count"] < 1:
            if state["distance"] != "near":
                return on_page("touch", "near")
            offered = listen_for("closeness")
            if offered:
                return offered
            return on_page("touch", "touch.hands")
        if progress["shared_activities"] < 3:
            offered = listen_for("shared", "care")
            return offered or on_page("activities", "activity.tea")
    else:
        if progress["fulfilled_promises"] < 2:
            return promise()
        today = state["world"]["now"] // 1440
        for kind in ("tea", "quiet"):
            habit = state["habits"][kind]
            if habit["count_days"] < 3 and habit["last_day"] != today:
                if kind == "tea":
                    offered = listen_for("shared", "care")
                    if offered:
                        return offered
                return on_page("activities", "activity." + kind)
        if any(state["habits"][kind]["count_days"] < 3 for kind in ("tea", "quiet")):
            return on_page("main", "sleep")
        if progress["shared_activities"] < 5:
            offered = listen_for("shared", "care")
            return offered or on_page("activities", "activity.tea")

    return on_page("talk", "begin.milestone_" + str(stage + 1))


def _next_presence_command_route(view, state):
    """Exercise reciprocal dialogue and touch, then finish the reference route."""
    if state["relation"]["stage"] < 3 or state["scene"]:
        return next_command(view, state)
    available = {item["id"] for item in view["choices"] if item["available"]}

    def choose(identity):
        return {"command": "choose", "id": identity} if identity in available else None

    def on_page(page, identity):
        if view["page"] != page:
            return choose("menu." + page if view["page"] == "main" else "menu.main")
        return choose(identity) or choose("menu.next")

    if state["offer"]:
        return choose("offer.accept" if state["offer"]["kind"] in ("reciprocal_hug", "kiss_back") else "offer.decline")
    if state["mode"] == "private":
        return on_page("main", "private.end")
    if state["distance"] != "near":
        return on_page("main", "near")

    exp = state["experience"]
    contacts = {contact["action_id"]: contact for contact in state["contacts"]}
    if exp.get("compliment", {}).get("count", 2) < 2:
        return on_page("talk", "touch.compliment")
    if "hug" in contacts:
        return on_page("touch", "end.hug")
    if exp.get("check_mood", {}).get("count", 1) < 1:
        return on_page("talk", "touch.check_mood")
    if "hair" in contacts:
        return on_page("touch", "touch.hair" if contacts["hair"]["continues"] < 2 else "end.hair")
    if exp.get("hair", {}).get("count", 1) < 1:
        return on_page("touch", "touch.hair")
    if exp.get("cheek", {}).get("count", 2) < 2:
        return on_page("touch", "touch.cheek")
    if exp.get("kiss", {}).get("count", 4) < 2:
        return on_page("touch", "touch.kiss")
    if exp.get("kiss", {}).get("count", 4) < 4:
        return on_page("touch", "touch.kiss")
    if "back" in contacts:
        return on_page("touch", "touch.back" if contacts["back"]["continues"] < 2 else "end.back")
    if exp.get("back", {}).get("count", 1) < 1:
        return on_page("touch", "touch.back")
    if "waist" in contacts:
        return on_page("touch", "touch.waist" if contacts["waist"]["continues"] < 1 else "end.waist")
    if exp.get("waist", {}).get("count", 1) < 1:
        return on_page("touch", "touch.waist")
    return next_command(view, state)


# interaction_007 progression.json: milestone N needs AFFINITY_STEPS[N-1] and
# DAY_STEPS[N-1] life days after the previous milestone.
AFFINITY_STEPS, DAY_STEPS = (5, 15, 35, 60), (0, 1, 2, 3)
DAILY_CAP, TALK_LIMIT, ACTIVITY_LIMIT = 10, 3, 2


def _progression_step(view, state, command):
    """Extra steps for releases with the stage A rules (affinity, days, Maho's sleep).

    Rules 2.2 releases never change affinity or Maho's sleep, so the routes run
    unchanged there.  While the next milestone still lacks affinity or days,
    this spends the day on talks and activities and then sleeps; the limits
    here follow interaction_007 and are checked against progression.json.
    """
    if state["offer"] or state["scene"]:
        return command
    available = {item["id"] for item in view["choices"] if item["available"]}

    def choose(identity):
        return {"command": "choose", "id": identity} if identity in available else None

    def go(page, identity):
        if view["page"] != page:
            return choose("menu." + page if view["page"] == "main" else "menu.main")
        return choose(identity)

    player, maho = state["actors"]["player"]["location"], state["actors"]["maho"]["location"]
    sleep = state["maho_sleep"]["state"]
    if sleep == "dozing":
        return go("main", "maho.wake") if player == maho else go("move", "move.solo." + maho)
    if sleep == "asleep":
        return go("main", "sleep")
    if view.get("release") == "interaction_009" and state["mode"] == "normal" and (player != "living_room" or maho != "living_room"):
        return go("move", "move.joint.living_room")
    affinity, stage, now = state["affinity"], state["relation"]["stage"], state["world"]["now"]
    if affinity["day"] is None or stage >= 4 or state["mode"] != "normal":
        return command
    today = life_day(now)
    milestones = state["relation"]["milestones"]
    days = today - life_day(milestones[-1]["at"]) if milestones else DAY_STEPS[0]
    if affinity["value"] >= AFFINITY_STEPS[stage] and days >= DAY_STEPS[stage]:
        return command
    counts = affinity["counts"] if affinity["day"] == today else {}
    gained = affinity["gained"] if affinity["day"] == today else 0
    if affinity["value"] < AFFINITY_STEPS[stage] and gained < DAILY_CAP and player == maho:
        talks = counts.get("talk", 0)
        if talks < TALK_LIMIT:
            return go("talk", "touch." + ("talk", "gratitude", "check_mood")[talks])
        if counts.get("activity_completed", 0) < ACTIVITY_LIMIT and now + 60 <= state["world"]["awake_deadline"]:
            return go("activities", "activity.tea")
    if player != maho and affinity["value"] < AFFINITY_STEPS[stage] and gained < DAILY_CAP:
        return command  # let the route bring the two together first
    return go("main", "sleep")

def _work_fallback(view, command):
    if view.get("release") not in ("interaction_008", "interaction_009"):
        return command
    available = {item["id"] for item in view["choices"] if item["available"]}
    if "work.go" in available and (command is None or command.get("id") not in available or any(c["reason"] == "work_time" for c in view["choices"])):
        return {"command": "choose", "id": "work.go"}
    if (command is None or command.get("id") not in available) and "menu.main" in available:
        return {"command": "choose", "id": "menu.main"}
    return command


def _stage_b_step(view, state, brief=False):
    """A deterministic, public-choice Stage B path before the final milestone."""
    if view.get("release") != "interaction_009" or state["relation"]["stage"] < 3 or state["intimacy_history"]["count"]:
        return None
    available = {item["id"] for item in view["choices"] if item["available"]}

    def choose(identity):
        return {"command": "choose", "id": identity} if identity in available else None

    def on_page(page, identity):
        if view["page"] != page:
            return choose("menu." + page if view["page"] == "main" else "menu.main")
        return choose(identity)

    if state["offer"]:
        if brief and state["offer"]["kind"] == "hold_back":
            return choose("offer.decline")
        return choose("offer.accept" if state["offer"]["kind"] in {"hold_back", "h_lead_straddle", "h_lead_takein", "intimacy_invite", "private"} else "offer.decline")
    if state["scene"]:
        return None
    if state["mode"] == "normal":
        return on_page("main", "private.begin") or choose("work.go") or on_page("main", "sleep")
    intimate = state["intimacy"]
    if intimate is None:
        return on_page("touch", "touch.h_kiss_deep") or on_page("main", "private.end")  # B2：触れ方を深める行動は「触れ合う」に並ぶ
    if brief:
        return on_page("main", "h.end")
    maho, player = intimate["maho"], intimate["player"]
    if intimate["wrap_up"] == 0 or intimate["hold_back_used"] and maho["satisfaction"] < 60:
        return on_page("main", "h.end")
    if player["arousal"] == 100 and player["endured"] == 0:
        command = on_page("main", "touch.h_endure")
        if command: return command
    if player["arousal"] >= 70 and (maho["climaxes"] > 0 or player["arousal"] == 100):
        command = on_page("main", "touch.h_finish_inside")
        if command: return command
    if intimate["after"] and player["finishes"] > 0:
        if maho["satisfaction"] >= 60:
            # 仕様 第8節：出した後は余韻（抱きしめて休む）を1回通ってから終える（v8.0.5、監査 C-09）。
            if intimate["satisfaction_uses"].get("h_after_hold", 0) == 0:
                command = on_page("main", "touch.h_after_hold") or on_page("h_words", "touch.h_after_hold")
                if command: return command
            return on_page("main", "h.end")
        if intimate["satisfaction_uses"].get("h_after_hold", 0) < 2:
            command = on_page("main", "touch.h_after_hold") or on_page("h_words", "touch.h_after_hold")
            if command: return command
        if intimate["satisfaction_uses"].get("h_feel", 0) < 2:
            command = on_page("h_words", "touch.h_feel")
            if command: return command
        return on_page("main", "h.end")
    if maho["arousal"] < 40:
        return on_page("h_touch", "touch.h_kiss_deep")
    clothing = state["actors"]
    if clothing["maho"]["clothing"]["upper"] == "worn":
        return on_page("h_clothes", "touch.h_lift_upper")
    if clothing["maho"]["clothing"]["lower"] == "worn":
        return on_page("h_clothes", "touch.h_strip_lower")
    if clothing["maho"]["clothing"]["lower"] == "underwear":
        return on_page("h_clothes", "touch.h_shift_under")
    if clothing["player"]["clothing"]["lower"] == "worn":
        return on_page("h_clothes", "touch.h_strip_self")
    if intimate["position"] not in ("player_above", "maho_above"):
        return on_page("h_position", "touch.h_pos_player_above")
    if not intimate["inserted"]:
        return on_page("h_connect", "touch.h_insert")
    if player["refractory"]:
        return on_page("h_words", "touch.h_feel")
    pace = "h_move_fast" if maho["arousal"] >= 80 else "h_move_normal" if maho["arousal"] >= 40 else "h_move_slow"
    return on_page("h_connect", "touch." + pace) or on_page("h_connect", "touch.h_move_normal") or on_page("main", "h.end")


def next_command(view, state):
    """Fixed reference route; see _next_command_route."""
    stage_b = _stage_b_step(view, state)
    if stage_b: return _work_fallback(view, stage_b)
    return _work_fallback(view, _progression_step(view, state, _next_command_route(view, state)))


def next_social_command(view, state):
    """Route that accepts Maho's useful offers; see _next_social_command_route."""
    stage_b = _stage_b_step(view, state)
    if stage_b: return _work_fallback(view, stage_b)
    return _work_fallback(view, _progression_step(view, state, _next_social_command_route(view, state)))


def next_presence_command(view, state):
    """Route through repetition and touch; see _next_presence_command_route."""
    stage_b = _stage_b_step(view, state, brief=True)
    if stage_b: return _work_fallback(view, stage_b)
    return _work_fallback(view, _progression_step(view, state, _next_presence_command_route(view, state)))
