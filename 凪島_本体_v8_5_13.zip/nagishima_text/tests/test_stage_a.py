"""Stage A acceptance tests (docs/凪島_段階A_仕様と受入条件_2026-09-24.md, section 16).

Decisions are exercised through public operations.  Internal state is used
only to prepare time or values, and those places say so.
"""
import json
import shutil
import subprocess
import sys
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory

from nagishima import RULES_VERSION, SAVE_SCHEMA, __version__
from nagishima.autoplay import next_command, AFFINITY_STEPS, DAY_STEPS, DAILY_CAP, TALK_LIMIT, ACTIVITY_LIMIT
from nagishima.codec import clone_state, digest
from nagishima.content import Pack
from nagishima.engine import Engine
from nagishima.errors import GameError
from nagishima.progression import Rules, day_time, life_day, parse_time
from nagishima.session import Session
from nagishima.state import validate_state

ROOT = Path(__file__).resolve().parents[1]
R7 = ROOT / "content" / "releases" / "interaction_007"
RAW7 = json.loads((R7 / "progression.json").read_text(encoding="utf-8"))
BEDTIME = 1410


class Game:
    def __init__(self, directory, seed=11, release="interaction_007", cheats=False):
        self.engine = Engine(directory, seed=seed, release=release, autosave=False, test_cheats=cheats)
        self.session = Session(self.engine, 5000)

    def run(self, command, **arguments):
        return self.session.execute({"command": command, **arguments})

    def ok(self, command, **arguments):
        result = self.run(command, **arguments)
        assert result["ok"], result.get("error")
        return result

    def state(self):
        return self.engine.snapshot()

    def decline(self):
        while self.state()["offer"]:
            self.ok("choose", id="offer.decline")

    def page(self, name):
        view = self.engine.get_view()
        if view["page"] != name:
            if view["page"] != "main": self.ok("choose", id="menu.main")
            if name != "main": self.ok("choose", id="menu." + name)

    def choose(self, page, identity):
        self.decline()
        self.page(page)
        return self.ok("choose", id=identity)

    def choice(self, page, identity):
        self.decline()
        self.page(page)
        return next(c for c in self.engine.get_view()["choices"] if c["id"] == identity)

    def activity(self, kind):
        self.choose("activities", "activity." + kind)
        self.ok("choose", id="scene.finish")
        self.decline()

    def wait_until(self, minute):
        """Pass time in 30-minute steps until the life-day time reaches `minute`."""
        blocks = []
        while day_time(self.state()["world"]["now"]) < minute:
            blocks += [b["meaning"] for b in self.choose("main", "wait.30")["view"]["blocks"]]
        return blocks

    def affinity(self):
        return self.state()["affinity"]


def seed_with_doze(want):
    """A seed whose first life day has (or lacks) a doze, found deterministically."""
    rules = Rules(RAW7, {a["id"]: a for a in json.loads((R7 / "actions.json").read_text(encoding="utf-8"))})
    with TemporaryDirectory() as directory:
        start = Engine(directory, seed=1, release="interaction_007", autosave=False).snapshot()["world"]["now"]
    for seed in range(1, 500):
        plan = rules.doze_plan(seed, life_day(start))
        if (plan is not None) == want:
            return seed, plan
    raise AssertionError("no seed")


def seed_plan(seed):
    rules = Rules(RAW7, {a["id"]: a for a in json.loads((R7 / "actions.json").read_text(encoding="utf-8"))})
    with TemporaryDirectory() as directory:
        start = Engine(directory, seed=seed, release="interaction_007", autosave=False).snapshot()["world"]["now"]
    return rules.doze_plan(seed, life_day(start))


class StageAVersionAndData(unittest.TestCase):
    def test_a01_versions_and_cli_default_release(self):
        self.assertEqual((RULES_VERSION, SAVE_SCHEMA), ("nagishima-2.4", 4))
        with TemporaryDirectory() as directory:
            log = Path(directory) / "run.jsonl"
            subprocess.run([sys.executable, "-m", "nagishima", "--autoplay", "--seed", "3", "--max-turns", "1", "--no-autosave", "--data-dir", str(Path(directory) / "data"), "--log", str(log)],
                           cwd=ROOT, capture_output=True, text=True, encoding="utf-8", timeout=120)
            self.assertIn("interaction_009", log.read_text(encoding="utf-8").splitlines()[0])  # v8.3.0：009 を確定し、既定の版に（それまでは 008）

    def test_a02_release_006_keeps_rules_2_2(self):
        with TemporaryDirectory() as directory:
            game = Game(directory, release="interaction_006")
            self.assertIsNone(game.engine.pack.progression)
            game.choose("talk", "touch.talk")
            game.activity("tea")
            self.assertEqual(game.affinity(), {"value": 0, "day": None, "gained": 0, "counts": {}})
            self.assertEqual(game.state()["maho_sleep"]["state"], "awake")

    def test_a03_tampered_progression_is_rejected_by_release_hash(self):
        with TemporaryDirectory() as directory:
            target = Path(directory) / "interaction_007"
            shutil.copytree(R7, target)
            raw = json.loads((target / "progression.json").read_text(encoding="utf-8"))
            raw["affinity"]["daily_cap"] = 50
            (target / "progression.json").write_text(json.dumps(raw), encoding="utf-8")
            with self.assertRaises(GameError):
                Pack(target)

    def test_a04_invalid_progression_data(self):
        actions = {a["id"]: a for a in json.loads((R7 / "actions.json").read_text(encoding="utf-8"))}
        def broken(change):
            raw = json.loads(json.dumps(RAW7))
            change(raw)
            with self.assertRaises(GameError) as caught:
                Rules(raw, actions)
            return caught.exception.code
        self.assertEqual(broken(lambda r: r["maho_sleep"]["doze"].update(start_to="23:15")), "progression_data")
        self.assertEqual(broken(lambda r: r["milestones"][2].update(min_affinity=10)), "progression_data")
        self.assertEqual(broken(lambda r: r["affinity"]["talk_actions"].append("absent")), "progression_data")
        self.assertEqual(broken(lambda r: r["desire"].update(invite=95)), "progression_data")
        self.assertEqual(broken(lambda r: r["affinity"]["sources"].pop("talk")), "progression_data")
        broken(lambda r: r.update(extra=1))


class StageAAffinity(unittest.TestCase):
    def test_a10_a11_a13_sources_per_day_and_daily_cap(self):
        with TemporaryDirectory() as directory:
            game = Game(directory, cheats=True)
            self.assertEqual(game.affinity()["value"], 0)
            game.ok("cheat", action="contact_unlock")
            for identity in ("talk", "gratitude", "check_mood", "share_day"):
                game.choose("talk", "touch." + identity)
            self.assertEqual((game.affinity()["value"], game.affinity()["counts"]["talk"]), (3, 3))
            game.choose("main", "near")
            game.choose("touch", "touch.hands")
            game.choose("touch", "touch.hands")  # continuing a held contact adds nothing
            self.assertEqual((game.affinity()["value"], game.affinity()["counts"]["touch"]), (4, 1))
            for identity in ("cheek", "shoulder"):
                game.choose("touch", "touch." + identity)
            self.assertEqual(game.affinity()["value"], 6)
            game.activity("tea")
            self.assertEqual(game.affinity()["value"], 9)
            game.activity("quiet")  # +3 would pass the daily cap of 10
            self.assertEqual((game.affinity()["value"], game.affinity()["gained"]), (10, 10))
            game.activity("tea")  # third activity: over per_day
            self.assertEqual(game.affinity()["counts"]["activity_completed"], 2)

    def test_a12_counters_reset_on_the_next_life_day(self):
        with TemporaryDirectory() as directory:
            game = Game(directory)
            for identity in ("talk", "gratitude", "check_mood"):
                game.choose("talk", "touch." + identity)
            day = game.affinity()["day"]
            game.choose("main", "sleep")
            game.choose("talk", "touch.talk")
            self.assertEqual((game.affinity()["day"], game.affinity()["counts"], game.affinity()["value"]), (day + 1, {"talk": 1}, 4))

    def test_a14_menu_and_save_do_not_change_affinity_and_load_restores(self):
        with TemporaryDirectory() as directory:
            game = Game(directory)
            game.choose("talk", "touch.talk")
            before = game.affinity()
            game.page("plans")
            game.page("main")
            game.ok("save", slot="slot01")
            self.assertEqual(game.affinity(), before)
            game.choose("talk", "touch.gratitude")
            game.ok("load", slot="slot01")
            self.assertEqual(game.affinity(), before)


class StageAMilestones(unittest.TestCase):
    def test_a20_a21_milestone_waits_for_affinity(self):
        with TemporaryDirectory() as directory:
            game = Game(directory)
            game.choose("talk", "begin.two_cups")
            game.ok("choose", id="scene.tea")
            game.ok("choose", id="scene.remember")
            game.activity("tea")
            self.assertEqual(game.affinity()["value"], 3)
            blocked = game.choice("talk", "begin.milestone_1")
            self.assertEqual((blocked["available"], blocked["reason"]), (False, "relationship"))
            game.choose("talk", "touch.talk")
            game.choose("talk", "touch.gratitude")
            self.assertTrue(game.choice("talk", "begin.milestone_1")["available"])
            game.choose("talk", "begin.milestone_1")
            game.ok("choose", id="scene.yes")
            self.assertEqual(game.state()["relation"]["stage"], 1)

    def test_a22_milestone_waits_for_days(self):
        with TemporaryDirectory() as directory:
            game = Game(directory)
            game.choose("talk", "begin.two_cups")
            game.ok("choose", id="scene.tea")
            game.ok("choose", id="scene.remember")
            game.activity("tea")
            game.choose("talk", "touch.talk")
            game.choose("talk", "touch.gratitude")
            game.choose("talk", "begin.milestone_1")
            game.ok("choose", id="scene.yes")
            game.choose("talk", "begin.workbench_half")
            game.ok("choose", id="scene.listen")
            game.choose("plans", "begin.promise_tea")
            game.ok("choose", id="scene.yes")
            game.choose("plans", "fulfil." + game.state()["promises"][-1]["id"])
            game.ok("choose", id="scene.finish")
            game.decline()
            # Preparation only: give enough affinity so that days are the one missing condition.
            game.engine._state["affinity"]["value"] = 20
            game.engine._install_choices()
            blocked = game.choice("talk", "begin.milestone_2")
            self.assertEqual((blocked["available"], blocked["reason"]), (False, "relationship"))
            self.assertEqual(game.engine.get_diagnostics()["progression"]["next_milestone"]["missing"], ["days"])
            game.choose("main", "sleep")
            self.assertTrue(game.choice("talk", "begin.milestone_2")["available"])


class StageADesire(unittest.TestCase):
    def test_a30_to_a32_desire(self):
        with TemporaryDirectory() as directory:
            game = Game(directory, cheats=True)
            game.ok("cheat", action="contact_unlock")
            game.choose("main", "near")
            game.choose("touch", "touch.cheek")
            self.assertEqual(game.state()["desire"], 0)  # below stage 3
            game.decline()
            game.page("main")
            game.ok("cheat", action="all")
            if game.state()["distance"] != "near": game.choose("main", "near")
            game.choose("touch", "touch.kiss")
            self.assertEqual(game.state()["desire"], 5)
            game.choose("touch", "touch.hug")
            game.choose("touch", "touch.hug")  # continue: +1
            self.assertEqual(game.state()["desire"], 11)
            game.choose("talk", "touch.affection")
            self.assertEqual(game.state()["desire"], 13)
            game.decline()
            game.choose("main", "sleep")
            self.assertEqual(game.state()["desire"], 0)

    def test_a33_desire_levels(self):
        rules = Rules(RAW7, {a["id"]: a for a in json.loads((R7 / "actions.json").read_text(encoding="utf-8"))})
        self.assertEqual([rules.desire_level(v) for v in (59, 60, 89, 90)], ["low", "invite", "invite", "press"])


class StageASleep(unittest.TestCase):
    def test_a40_doze_plan_is_seed_derived(self):
        seed, plan = seed_with_doze(True)
        again = Rules(RAW7, {a["id"]: a for a in json.loads((R7 / "actions.json").read_text(encoding="utf-8"))})
        with TemporaryDirectory() as directory:
            start = Engine(directory, seed=seed, release="interaction_007", autosave=False).snapshot()["world"]["now"]
        self.assertEqual(again.doze_plan(seed, life_day(start)), plan)

    def test_a41_to_a43_doze_blocks_actions_and_wake(self):
        seed, (start, end) = seed_with_doze(True)
        with TemporaryDirectory() as directory:
            game = Game(directory, seed=seed)
            meanings = game.wait_until(start)
            self.assertEqual(game.state()["maho_sleep"]["state"], "dozing")
            self.assertIn("maho.dozed_off", meanings)
            talk = game.choice("talk", "touch.talk")
            self.assertEqual((talk["available"], talk["reason"]), (False, "maho_sleeping"))
            self.assertFalse(game.choice("activities", "activity.tea")["available"])
            self.assertFalse(game.choice("main", "near")["available"])
            result = game.choose("main", "maho.wake")
            self.assertIn("maho.woken", [b["meaning"] for b in result["view"]["blocks"]])
            self.assertEqual(game.state()["maho_sleep"]["state"], "awake")
            self.assertIsNone(game.state()["interaction_streak"])
            game.choose("main", "wait.30")
            self.assertEqual(game.state()["maho_sleep"]["state"], "awake")  # no second doze that day

    def test_a44_doze_ends_by_itself(self):
        seed, (start, end) = seed_with_doze(True)
        with TemporaryDirectory() as directory:
            game = Game(directory, seed=seed)
            game.wait_until(start)
            meanings = game.wait_until(end)
            self.assertEqual(game.state()["maho_sleep"]["state"], "awake")
            self.assertIn("maho.woke", meanings)

    def test_a45_a47_a48_bedtime_save_load_and_morning(self):
        seed, _ = seed_with_doze(False)
        with TemporaryDirectory() as directory:
            game = Game(directory, seed=seed)
            meanings = game.wait_until(BEDTIME)
            state = game.state()
            self.assertIn("maho.went_to_bed", meanings)
            self.assertEqual((state["maho_sleep"]["state"], state["actors"]["maho"]["location"], state["actors"]["maho"]["posture"], state["distance"]),
                             ("asleep", "maho_room", "reclined", "normal"))
            self.assertEqual(game.engine.get_view()["status"]["maho_sleep"], "asleep")
            self.assertFalse(game.choice("talk", "touch.talk")["available"])
            game.ok("save", slot="slot01")
            game.choose("main", "wait.30")
            game.ok("load", slot="slot01")
            self.assertEqual(game.state(), state)
            broken = clone_state(state)
            broken["actors"]["maho"]["location"] = "living_room"
            with self.assertRaises(GameError) as caught:
                validate_state(broken, game.engine.pack, game.engine.repository)
            self.assertEqual(caught.exception.code, "maho_sleep")
            game.choose("main", "sleep")
            morning = game.state()
            self.assertEqual((morning["maho_sleep"]["state"], morning["actors"]["maho"]["location"]), ("awake", "living_room"))

    def test_a49_full_cheat_needs_maho_awake(self):
        seed, (start, _) = seed_with_doze(True)
        with TemporaryDirectory() as directory:
            game = Game(directory, seed=seed, cheats=True)
            game.wait_until(start)
            game.page("main")
            before = game.state()
            rejected = game.run("cheat", action="all")
            self.assertEqual(rejected["error"]["code"], "maho_sleeping")
            self.assertEqual(game.state(), before)


class StageACheats(unittest.TestCase):
    def test_a60_to_a62_renamed_cheat_and_full_cheat_affinity(self):
        with TemporaryDirectory() as directory:
            game = Game(directory, cheats=True)
            before = game.state()
            for name in ("intimacy", "親密度"):
                self.assertEqual(game.run("cheat", action=name)["error"]["code"], "cheat_renamed")
            self.assertEqual(game.state(), before)
            self.assertEqual(game.ok("cheat", action="接触解放")["result"]["action"], "contact_unlock")
            game.ok("cheat", action="all")
            self.assertEqual(game.affinity()["value"], 35)
            self.assertEqual(game.state()["desire"], 0)


class StageALifeAfterStage4(unittest.TestCase):
    def test_a50_a51_life_continues_after_stage_4(self):
        with TemporaryDirectory() as directory:
            game = Game(directory, seed=37)
            seen = []
            for _ in range(600):
                if game.session.cleared:
                    break
                command = next_command(game.engine.get_view(), game.state())
                self.assertIsNotNone(command)
                seen += [b["meaning"] for b in game.ok("choose", id=command["id"])["view"]["blocks"]]
            self.assertTrue(game.session.cleared)
            self.assertEqual(seen.count("system.life_continues"), 1)
            observed = game.session.observe()
            self.assertEqual((observed["run"]["ended"], observed["run"]["completed"], observed["run"]["cleared"]), (False, False, True))
            for turn in range(200):
                game.decline()
                if game.state()["scene"]:
                    choice = next(c for c in game.engine.get_view()["choices"] if c["available"])
                    game.ok("choose", id=choice["id"])
                elif game.state()["maho_sleep"]["state"] != "awake" or day_time(game.state()["world"]["now"]) >= 1320:
                    game.choose("main", "sleep")
                elif turn % 3 == 0 and game.choice("talk", "touch.gratitude")["available"]:
                    game.choose("talk", "touch.gratitude")
                else:
                    game.choose("main", "wait.30")
            self.assertIsNone(game.session.reason)
            self.assertEqual(game.state()["relation"]["stage"], 4)

    def test_a52_autoplay_stops_with_cleared(self):
        with TemporaryDirectory() as directory:
            process = subprocess.run([sys.executable, "-m", "nagishima", "--autoplay", "--seed", "37", "--max-turns", "1500", "--no-autosave", "--data-dir", str(Path(directory) / "data"), "--log", str(Path(directory) / "run.jsonl")],
                                     cwd=ROOT, capture_output=True, text=True, encoding="utf-8", timeout=300)
            final = json.loads([line for line in process.stdout.splitlines() if line.startswith("{")][-1])
            self.assertEqual((process.returncode, final["run"]["reason"], final["state"]["relation"]["stage"]), (0, "cleared", 4))


class StageAGeminiCounterexamples(unittest.TestCase):
    """Counterexamples proposed by Gemini 3.8 and adopted by Opus (docs/段階A実装報告.md section 7).

    Values follow interaction_007 (affinity max 100, desire min_stage 3)."""

    def invalid(self, game, change, code=None):
        state = clone_state(game.state())
        change(state)
        if code is None:
            validate_state(state, game.engine.pack, game.engine.repository, True)
            return
        with self.assertRaises(GameError) as caught:
            validate_state(state, game.engine.pack, game.engine.repository, True)
        self.assertEqual(caught.exception.code, code)

    def prepare_time(self, game, minute):
        """Preparation only: move the clock to `minute` (life-day time) on the current life day."""
        world = game.engine._state["world"]
        world["now"] = world["processed_until"] = life_day(world["now"]) * 1440 + minute
        game.engine._install_choices()

    def test_g01_day_with_no_gain_yet_is_valid(self):
        with TemporaryDirectory() as directory:
            game = Game(directory)
            day = life_day(game.state()["world"]["now"])
            self.invalid(game, lambda s: s["affinity"].update(value=20, day=day, gained=0, counts={}))
            self.invalid(game, lambda s: s["affinity"].update(value=150, day=day), "affinity")

    def test_g02_old_release_rejects_non_neutral_values_by_field(self):
        with TemporaryDirectory() as directory:
            game = Game(directory, release="interaction_006")
            self.invalid(game, lambda s: s.update(desire=10), "desire")
            self.invalid(game, lambda s: s["affinity"].update(value=1), "affinity")
            self.invalid(game, lambda s: s["maho_sleep"].update(doze_day=1), "maho_sleep")

    def test_g03_desire_below_min_stage_is_invalid(self):
        with TemporaryDirectory() as directory:
            game = Game(directory)
            self.invalid(game, lambda s: s.update(desire=50), "desire")  # stage 0 < min_stage 3

    def test_g04_dozing_does_not_restrict_the_player_location(self):
        with TemporaryDirectory() as directory:
            game = Game(directory)
            now = game.state()["world"]["now"]
            def doze(s):
                s["maho_sleep"].update(state="dozing", since=now, doze_day=life_day(now))
                s["actors"]["player"]["location"] = "kitchen"
            self.invalid(game, doze)

    def test_g05_no_doze_at_the_end_minute(self):
        seed, (start, end) = seed_with_doze(True)
        with TemporaryDirectory() as directory:
            game = Game(directory, seed=seed)
            self.prepare_time(game, end)
            game.choose("main", "listen")
            self.assertEqual(game.state()["maho_sleep"]["state"], "awake")

    def test_g06_bedtime_waits_while_the_player_is_in_maho_room(self):
        with TemporaryDirectory() as directory:
            game = Game(directory)
            # Preparation only: past bedtime, the player alone in Maho's room (the move list offers no way in).
            self.prepare_time(game, BEDTIME + 30)
            game.engine._state["actors"]["player"]["location"] = "maho_room"
            game.engine._install_choices()
            game.choose("main", "wait.30")
            self.assertEqual((game.state()["maho_sleep"]["state"], game.state()["actors"]["maho"]["location"]), ("awake", "living_room"))
            game.choose("move", "move.solo.living_room")
            self.assertEqual((game.state()["maho_sleep"]["state"], game.state()["actors"]["maho"]["location"]), ("asleep", "maho_room"))

    def test_g08_wake_and_bedtime_in_one_operation(self):
        seed = next(s for s in range(1, 400) if (p := seed_plan(s)) and p[0] >= 1290)
        with TemporaryDirectory() as directory:
            game = Game(directory, seed=seed)
            game.wait_until(seed_plan(seed)[0])
            self.assertEqual(game.state()["maho_sleep"]["state"], "dozing")
            meanings = [b["meaning"] for b in game.choose("main", "wait.120")["view"]["blocks"]]
            self.assertEqual([m for m in meanings if m.startswith("maho.")], ["maho.woke", "maho.went_to_bed"])
            self.assertEqual(game.state()["maho_sleep"]["state"], "asleep")

    def test_g09_save_and_inquiries_do_not_run_the_sleep_check(self):
        with TemporaryDirectory() as directory:
            game = Game(directory)
            self.prepare_time(game, BEDTIME + 30)
            game.ok("save", slot="slot01")
            game.ok("state")
            game.ok("diagnostics")
            game.page("talk")
            game.page("main")
            self.assertEqual(game.state()["maho_sleep"]["state"], "awake")
            game.choose("main", "listen")
            self.assertEqual(game.state()["maho_sleep"]["state"], "asleep")

    def test_g12_adopt_is_refused_with_a_suspended_scene(self):
        with TemporaryDirectory() as directory:
            game = Game(directory, release="interaction_006")
            game.choose("talk", "begin.two_cups")
            game.ok("choose", id="scene.pause")
            self.assertTrue(game.state()["suspended"])
            self.assertFalse(game.run("adopt", release="interaction_007")["ok"])
            self.assertEqual(game.engine.active_release, "interaction_006")

    def test_g13_adopt_sets_affinity_from_the_current_stage(self):
        with TemporaryDirectory() as directory:
            game = Game(directory, release="interaction_006", cheats=True)
            game.ok("cheat", action="all")
            game.ok("adopt", release="interaction_007")
            self.assertEqual(game.affinity(), {"value": 35, "day": None, "gained": 0, "counts": {}})


class StageAFixedRoute(unittest.TestCase):
    def test_a81_clear_i007_route_reaches_cleared(self):
        expected = json.loads((ROOT / "examples" / "clear_i007.expected.json").read_text(encoding="utf-8"))
        commands = [json.loads(line) for line in (ROOT / "examples" / "clear_i007.jsonl").read_text(encoding="utf-8").splitlines() if line]
        self.assertEqual(len(commands), expected["choose_commands"])
        with TemporaryDirectory() as directory:
            game = Game(directory, seed=expected["seed"])
            for command in commands:
                self.assertTrue(game.session.execute(command)["ok"])
            self.assertTrue(game.session.cleared)
            self.assertEqual(digest(game.state()), expected["final_state_sha256"])


class StageASaveAndAdopt(unittest.TestCase):
    def old_save(self, directory):
        """A rules 2.2 save at stage 1 on interaction_006, rebuilt as rules 2.2 wrote it."""
        game = Game(directory, release="interaction_006")
        game.choose("talk", "begin.two_cups")
        game.ok("choose", id="scene.tea")
        game.ok("choose", id="scene.remember")
        game.activity("tea")
        game.choose("talk", "begin.milestone_1")
        game.ok("choose", id="scene.yes")
        game.decline()
        game.page("main")
        game.ok("save", slot="slot01")
        path = game.engine.storage.slot_path("slot01")
        old = json.loads(path.read_bytes())
        for key in ("affinity", "desire", "maho_sleep"):
            del old["payload"]["state"][key]
        old["schema"], old["rules_version"] = 2, "nagishima-2.2"
        old["sha256"] = digest(old["payload"])
        path.write_text(json.dumps(old, ensure_ascii=False), encoding="utf-8")
        return path

    def test_a70_a72_schema_2_save_loads_and_adopts_007(self):
        with TemporaryDirectory() as directory:
            path = self.old_save(directory)
            game = Game(directory)
            game.ok("load", slot="slot01")
            self.assertEqual(game.engine.active_release, "interaction_006")
            self.assertEqual((game.affinity()["value"], game.state()["maho_sleep"]["state"]), (0, "awake"))
            game.ok("adopt", release="interaction_007")
            self.assertEqual(game.engine.active_release, "interaction_007")
            self.assertEqual((game.affinity()["value"], game.state()["desire"]), (5, 0))
            game.ok("save", slot="slot01")
            saved = json.loads(path.read_bytes())
            self.assertEqual((saved["schema"], saved["rules_version"]), (4, "nagishima-2.4"))
            self.assertEqual(game.run("adopt", release="interaction_006")["error"]["code"], "control_change")

    def test_a72_adopt_is_refused_inside_a_scene(self):
        with TemporaryDirectory() as directory:
            game = Game(directory, release="interaction_006")
            game.choose("talk", "begin.two_cups")
            self.assertFalse(game.run("adopt", release="interaction_007")["ok"])
            self.assertEqual(game.engine.active_release, "interaction_006")


class StageARepair(unittest.TestCase):
    def assert_source_gain(self, game, source, action, other=0):
        before = game.affinity()
        old_count = before["counts"].get(source, 0)
        action()
        after = game.affinity()
        self.assertEqual(after["value"] - before["value"], RAW7["affinity"]["sources"][source]["amount"] + other)
        self.assertEqual(after["counts"].get(source, 0), old_count + 1)

    def test_a11_all_seven_sources_have_configured_amount(self):
        with TemporaryDirectory() as directory:
            game = Game(directory)
            self.assert_source_gain(game, "talk", lambda: game.choose("talk", "touch.talk"))
        with TemporaryDirectory() as directory:
            game = Game(directory, cheats=True)
            game.ok("cheat", action="contact_unlock")
            game.choose("main", "near")
            self.assert_source_gain(game, "touch", lambda: game.choose("touch", "touch.cheek"))
        with TemporaryDirectory() as directory:
            game = Game(directory)
            self.assert_source_gain(game, "activity_completed", lambda: game.activity("tea"))
        with TemporaryDirectory() as directory:
            game = Game(directory)
            game.choose("talk", "begin.two_cups")
            game.ok("choose", id="scene.tea")
            game.ok("choose", id="scene.remember")
            game.activity("tea")
            game.choose("talk", "touch.talk")
            game.choose("talk", "touch.gratitude")
            game.choose("talk", "begin.milestone_1")
            game.ok("choose", id="scene.yes")
            game.choose("talk", "begin.workbench_half")
            self.assert_source_gain(game, "story_completed", lambda: game.ok("choose", id="scene.listen"))
            before_repeat = game.affinity()["value"]
            game.choose("talk", "begin.workbench_half")
            game.ok("choose", id="scene.listen")
            self.assertEqual(game.affinity()["counts"]["story_completed"], 1)
            self.assertEqual(game.affinity()["value"], before_repeat)
        with TemporaryDirectory() as directory:
            game = Game(directory)
            game.choose("plans", "begin.promise_tea")
            game.ok("choose", id="scene.yes")
            promise = game.state()["promises"][-1]["id"]
            def fulfil():
                game.choose("plans", "fulfil." + promise)
                game.ok("choose", id="scene.finish")
            self.assert_source_gain(game, "promise_fulfilled", fulfil,
                                    RAW7["affinity"]["sources"]["activity_completed"]["amount"])
        with TemporaryDirectory() as directory:
            game = Game(directory, cheats=True)
            game.ok("cheat", action="all")
            game.choose("main", "near")
            game.choose("touch", "touch.kiss")
            game.choose("touch", "touch.kiss")
            self.assertIsNotNone(game.state()["offer"])
            self.assert_source_gain(game, "offer_accepted", lambda: game.ok("choose", id="offer.accept"))
        with TemporaryDirectory() as directory:
            game = Game(directory, cheats=True)
            game.ok("cheat", action="all")
            game.choose("main", "private.begin")
            self.assert_source_gain(game, "private_completed", lambda: game.choose("main", "private.end"))

    def test_a11_repeated_sources_respect_per_day_limits(self):
        with TemporaryDirectory() as directory:
            game = Game(directory, cheats=True)
            game.ok("cheat", action="all")
            for _ in range(3):
                game.choose("main", "private.begin")
                game.choose("main", "private.end")
            self.assertEqual(game.affinity()["counts"]["private_completed"], 1)
            self.assertEqual(game.affinity()["value"], 37)
        with TemporaryDirectory() as directory:
            game = Game(directory)
            for _ in range(2):
                game.choose("plans", "begin.promise_tea")
                game.ok("choose", id="scene.yes")
                promise = game.state()["promises"][-1]["id"]
                game.choose("plans", "fulfil." + promise)
                game.ok("choose", id="scene.finish")
                game.decline()
            self.assertEqual(game.affinity()["counts"]["promise_fulfilled"], 1)
            self.assertEqual(game.affinity()["counts"]["activity_completed"], 2)
            self.assertEqual(game.affinity()["value"], 8)
        with TemporaryDirectory() as directory:
            game = Game(directory, cheats=True)
            game.ok("cheat", action="all")
            game.choose("main", "near")
            game.choose("touch", "touch.kiss")
            game.choose("touch", "touch.kiss")
            game.ok("choose", id="offer.accept")
            game.choose("talk", "touch.affection")
            game.choose("talk", "touch.affection")
            self.assertIsNotNone(game.state()["offer"])
            game.ok("choose", id="offer.accept")
            self.assertEqual(game.affinity()["counts"]["offer_accepted"], 2)
            game.choose("talk", "touch.affection")
            self.assertIsNotNone(game.state()["offer"])
            self.assertEqual(game.state()["offer"]["kind"], "private")
            before = game.affinity()["value"]
            game.ok("choose", id="offer.accept")
            self.assertEqual(game.affinity()["counts"]["offer_accepted"], 2)
            self.assertEqual(game.affinity()["value"], before)

    def test_d1_a_b_c_asleep_can_reach_five_and_save_then_reset_after_sleep(self):
        with TemporaryDirectory() as directory:
            game = Game(directory, seed=11)
            game.choose("talk", "touch.talk")
            original_day = game.affinity()["day"]
            game.wait_until(1710)  # 04:30; public wait.30 operations.
            self.assertEqual(game.state()["maho_sleep"]["state"], "asleep")
            self.assertTrue(game.choice("main", "wait.30")["available"])
            game.choose("main", "wait.30")
            at_five = game.state()
            self.assertEqual(day_time(at_five["world"]["now"]), 1740)
            self.assertEqual((life_day(at_five["world"]["now"]), game.affinity()["day"]), (original_day, original_day))
            validate_state(at_five, game.engine.pack, game.engine.repository)
            game.ok("save", slot="slot01")
            game.choose("main", "sleep")
            game.ok("load", slot="slot01")
            self.assertEqual(game.state(), at_five)
            game.choose("main", "sleep")
            game.choose("talk", "touch.gratitude")
            self.assertEqual(game.affinity()["day"], original_day + 1)
            self.assertEqual(game.affinity()["counts"], {"talk": 1})

    def test_d1_d_only_exact_five_changes_and_doze_days_remain_stable(self):
        actions = {a["id"]: a for a in json.loads((R7 / "actions.json").read_text(encoding="utf-8"))}
        rules = Rules(RAW7, actions)
        for minute in range(5 * 1440):
            if minute % 1440 == 300:
                self.assertEqual((life_day(minute), day_time(minute)), ((minute - 301) // 1440, 1740))
                continue
            old_day, old_time = (minute - 300) // 1440, (minute - 300) % 1440 + 300
            self.assertEqual((life_day(minute), day_time(minute)), (old_day, old_time))
            if minute % 60 == 1:
                for seed in (0, 11, 37):
                    self.assertEqual(rules.doze_plan(seed, life_day(minute)), rules.doze_plan(seed, old_day))
        self.assertEqual((parse_time("05:00"), parse_time("05:01")), (1740, 301))

    def test_d2_human_state_hides_gauges_but_test_and_json_keep_them(self):
        with TemporaryDirectory() as directory:
            for cheats in (False, True):
                with self.subTest(cheats=cheats):
                    args = [sys.executable, "-m", "nagishima", "--seed", "11", "--no-autosave",
                            "--data-dir", str(Path(directory) / ("cheats" if cheats else "normal")),
                            "--log", str(Path(directory) / ("cheats.jsonl" if cheats else "normal.jsonl"))]
                    if cheats: args.append("--test-cheats")
                    process = subprocess.run(args, cwd=ROOT, input="状態\n終了\n", capture_output=True,
                                             text=True, encoding="utf-8", timeout=30)
                    self.assertEqual(process.returncode, 0, process.stderr)
                    self.assertEqual('"affinity"' in process.stdout, cheats)
                    self.assertEqual('"desire"' in process.stdout, cheats)
            machine = subprocess.run([sys.executable, "-m", "nagishima", "--json", "--seed", "11",
                                      "--no-autosave", "--data-dir", str(Path(directory) / "machine"),
                                      "--log", str(Path(directory) / "machine.jsonl")],
                                     cwd=ROOT, input='{"command":"state"}\n{"command":"quit"}\n',
                                     capture_output=True, text=True, encoding="utf-8", timeout=30)
            self.assertEqual(machine.returncode, 0, machine.stderr)
            response = next(json.loads(line) for line in machine.stdout.splitlines()
                            if line.startswith("{") and '"type": "response"' in line)
            self.assertIn("affinity", response["result"])
            self.assertIn("desire", response["result"])

    def test_d3_autoplay_limits_match_progression_json(self):
        def policy_values(raw):
            return (tuple(item["min_affinity"] for item in raw["milestones"]),
                    tuple(item["min_days"] for item in raw["milestones"]),
                    raw["affinity"]["daily_cap"],
                    raw["affinity"]["sources"]["talk"]["per_day"],
                    raw["affinity"]["sources"]["activity_completed"]["per_day"])
        expected = (AFFINITY_STEPS, DAY_STEPS, DAILY_CAP, TALK_LIMIT, ACTIVITY_LIMIT)
        self.assertEqual(__version__, "2.9.13")
        self.assertEqual(policy_values(RAW7), expected)
        for path in ("milestones.0.min_affinity", "milestones.1.min_days", "affinity.daily_cap",
                     "affinity.sources.talk.per_day", "affinity.sources.activity_completed.per_day"):
            with self.subTest(path=path):
                with TemporaryDirectory() as directory:
                    copy = Path(directory) / "progression.json"
                    shutil.copyfile(R7 / "progression.json", copy)
                    changed = json.loads(copy.read_text(encoding="utf-8"))
                    target = changed
                    for part in path.split(".")[:-1]:
                        target = target[int(part)] if part.isdigit() else target[part]
                    target[path.split(".")[-1]] += 1
                    copy.write_text(json.dumps(changed), encoding="utf-8")
                    self.assertNotEqual(policy_values(json.loads(copy.read_text(encoding="utf-8"))), expected)

    def test_a32_private_completion_and_deadline_cancel(self):
        for cancel in (False, True):
            with self.subTest(cancel=cancel), TemporaryDirectory() as directory:
                game = Game(directory, cheats=True)
                game.ok("cheat", action="all")
                game.choose("main", "private.begin")
                game.choose("touch", "touch.kiss")
                before = game.state()["desire"]
                self.assertGreater(before, 0)
                if cancel:
                    # Preparation only: move the clock after the 30-minute activity no longer fits.
                    world = game.engine._state["world"]
                    world["now"] = world["processed_until"] = world["awake_deadline"] - 25
                    game.engine._install_choices()
                game.choose("main", "private.end")
                self.assertEqual(game.state()["desire"], before if cancel else 0)

    def test_a43_wake_and_a49_a62_cheat_leave_unrelated_values(self):
        seed, (start, _) = seed_with_doze(True)
        with TemporaryDirectory() as directory:
            game = Game(directory, seed=seed, cheats=True)
            game.wait_until(start)
            before = game.state()
            for key in ("experience", "mood", "affinity", "desire"):
                self.assertEqual(game.state()[key], before[key])
            game.choose("main", "maho.wake")
            after = game.state()
            for key in ("experience", "mood", "affinity", "desire"):
                self.assertEqual(after[key], before[key], key)
            preserved = {"day": after["affinity"]["day"], "gained": after["affinity"]["gained"],
                         "counts": after["affinity"]["counts"], "desire": after["desire"],
                         "maho_sleep": after["maho_sleep"]}
            game.ok("cheat", action="all")
            now = game.state()
            for key in ("day", "gained", "counts"):
                self.assertEqual(now["affinity"][key], preserved[key])
            self.assertEqual(now["desire"], preserved["desire"])
            self.assertEqual(now["maho_sleep"], preserved["maho_sleep"])
            game.wait_until(BEDTIME)
            self.assertEqual(game.state()["maho_sleep"]["state"], "asleep")
            before_reject = game.state()
            rejected = game.run("cheat", action="all")
            self.assertFalse(rejected["ok"])
            self.assertEqual(game.state(), before_reject)

    def test_a70_real_v62_saves_resume_resave_and_adopt(self):
        for kind in ("normal", "cheat"):
            with self.subTest(kind=kind), TemporaryDirectory() as directory:
                game = Game(directory, cheats=kind == "cheat")
                source = ROOT / "tests" / "fixtures" / f"v62_{kind}.json"
                destination = game.engine.storage.slot_path("slot01")
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(source, destination)
                game.ok("load", slot="slot01")
                self.assertEqual(game.engine.active_release, "interaction_006")
                self.assertEqual(game.state()["relation"]["stage"], 3 if kind == "cheat" else 0)
                game.choose("talk", "touch.gratitude")
                game.ok("save", slot="slot01")
                self.assertEqual(json.loads(destination.read_text(encoding="utf-8"))["schema"], 4)
                game.ok("adopt", release="interaction_007")
                self.assertEqual(game.engine.active_release, "interaction_007")
                game.choose("talk", "touch.talk")

    def test_a73_real_v62_log_reports_rule_mismatch(self):
        old_log = ROOT / "tests" / "fixtures" / "v62_run.jsonl"
        result = subprocess.run([sys.executable, "-m", "nagishima", "--replay", str(old_log)],
                                cwd=ROOT, capture_output=True, text=True, encoding="utf-8", timeout=30)
        self.assertEqual(result.returncode, 3)
        self.assertEqual(json.loads(result.stdout.splitlines()[-1])["error"]["code"], "rules_version_mismatch")

    def test_a13_a31_maho_touch_continuation_and_desire_max(self):
        with TemporaryDirectory() as directory:
            game = Game(directory, cheats=True)
            game.ok("cheat", action="all")
            game.choose("main", "near")
            game.choose("touch", "touch.kiss")
            game.choose("touch", "touch.kiss")
            self.assertEqual(game.state()["offer"]["kind"], "kiss_back")
            before_affinity = game.affinity()["value"]
            before_desire = game.state()["desire"]
            game.ok("choose", id="offer.accept")
            self.assertEqual(game.affinity()["value"] - before_affinity, RAW7["affinity"]["sources"]["offer_accepted"]["amount"])
            self.assertEqual(game.state()["desire"] - before_desire, RAW7["desire"]["touch_start"]["kiss"])
            self.assertEqual(game.state()["experience"]["kiss"]["by_origin"]["maho"], 1)
            game.choose("touch", "touch.hug")
            held_affinity = game.affinity()["value"]
            for continuation in range(1, 5):
                prior = game.state()["desire"]
                response = game.choose("touch", "touch.hug")
                self.assertIn("hug.settled" if continuation >= 3 else "hug.continue",
                              [block["meaning"] for block in response["view"]["blocks"]])
                self.assertEqual(game.affinity()["value"], held_affinity)
                self.assertEqual(game.state()["desire"] - prior, RAW7["desire"]["touch_continue"])
            game.choose("touch", "end.hug")
            # Preparation only: set desire close to max to test public action clamping.
            game.engine._state["desire"] = RAW7["desire"]["max"] - 2
            game.engine._install_choices()
            game.choose("touch", "touch.kiss")
            self.assertEqual(game.state()["desire"], RAW7["desire"]["max"])

    def test_a13_hold_mug_is_not_exposed_in_007(self):
        with TemporaryDirectory() as directory:
            game = Game(directory, cheats=True)
            game.ok("cheat", action="all")
            game.choose("orders", "buy.mug")
            order = game.state()["orders"][0]["id"]
            game.choose("main", "sleep")
            game.wait_until(600)
            game.choose("orders", "receive." + order)
            before_affinity, before_desire = game.affinity()["value"], game.state()["desire"]
            game.page("touch")
            self.assertNotIn("touch.hold_mug", {choice["id"] for choice in game.engine.get_view()["choices"]})
            self.assertFalse(game.run("choose", id="touch.hold_mug")["ok"])
            self.assertEqual((game.affinity()["value"], game.state()["desire"]),
                             (before_affinity, before_desire))

    def test_a41_busy_day_skips_doze_and_a46_private_delays_bedtime(self):
        seed, (start, end) = seed_with_doze(True)
        with TemporaryDirectory() as directory:
            game = Game(directory, seed=seed, cheats=True)
            game.ok("cheat", action="all")
            game.choose("main", "near")
            game.choose("touch", "touch.hands")
            game.wait_until(end)
            self.assertEqual(game.state()["maho_sleep"]["state"], "awake")
            game.choose("touch", "end.hands")
            game.choose("main", "private.begin")
            # Preparation only: private mode intentionally disables wait; set time to bedtime.
            world = game.engine._state["world"]
            world["now"] = world["processed_until"] = life_day(world["now"]) * 1440 + BEDTIME
            game.engine._install_choices()
            game.choose("talk", "touch.talk")
            self.assertEqual(game.state()["maho_sleep"]["state"], "awake")
            game.choose("main", "private.end")
            self.assertEqual(game.state()["maho_sleep"]["state"], "asleep")

    def test_a51_clear_then_400_operations_across_bedtime_two_seeds(self):
        for seed in (11, 37):
            with self.subTest(seed=seed), TemporaryDirectory() as directory:
                game = Game(directory, seed=seed)
                for _ in range(1500):
                    if game.session.cleared:
                        break
                    command = next_command(game.engine.get_view(), game.state())
                    self.assertIsNotNone(command)
                    game.ok("choose", id=command["id"])
                self.assertTrue(game.session.cleared)
                crossed = 0
                for _ in range(400):
                    game.decline()
                    state = game.state()
                    if state["scene"]:
                        game.ok("choose", id=next(c["id"] for c in game.engine.get_view()["choices"] if c["available"]))
                    elif day_time(state["world"]["now"]) == 1740:
                        game.choose("main", "sleep")
                    else:
                        game.choose("main", "wait.30")
                    if game.state()["maho_sleep"]["state"] == "asleep":
                        crossed += 1
                self.assertGreater(crossed, 0)
                self.assertEqual(game.state()["relation"]["stage"], 4)
                self.assertIsNone(game.session.reason)

    def test_a72_adopt_refused_with_offer_or_private(self):
        for pending in ("offer", "private"):
            with self.subTest(pending=pending), TemporaryDirectory() as directory:
                game = Game(directory, release="interaction_006", cheats=True)
                game.ok("cheat", action="all")
                if pending == "offer":
                    game.choose("main", "near")
                    game.choose("touch", "touch.kiss")
                    game.choose("touch", "touch.kiss")
                    self.assertIsNotNone(game.state()["offer"])
                else:
                    game.choose("main", "private.begin")
                    self.assertEqual(game.state()["mode"], "private")
                before = game.state()
                rejected = game.run("adopt", release="interaction_007")
                self.assertFalse(rejected["ok"])
                self.assertEqual(game.state(), before)
                self.assertEqual(game.engine.active_release, "interaction_006")


if __name__ == "__main__":
    unittest.main()
