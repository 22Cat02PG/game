"""段階Bの2版目（B2）の grok の job を作る（Opus、2026-09-27）。

出力：
- grok_b2_wave_1.json〜3.json（job の正本。取り込みで使う when・group・_meaning を持つ）
- grok依頼_B2_第N陣/B2_第N陣_XX.txt（「指示」＋「プロンプト」の貼る文）

id：p<陣>.<meaning>.<慣れ>.<体位>.<そのほか>.<s|n>。本文の id は <job の id>.v<番号>。
"""
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
PROMPT = (OUT / "grokプロンプト_v3_0.txt").read_text(encoding="utf-8")

BED = "二人の個室のどちらかのベッド（どちらの部屋かは書かない）"
WALL = "二人の個室のどちらか（どちらの部屋かは書かない）。ベッドのそばの壁際"
HOME = "二人の家の中（居間・台所・どちらかの個室のどれか。場所の名前は書かない）"
TIER = {"first": "初回（1回目のエッチ）", "few": "数回（2〜5回目）", "familiar": "慣れ（6回目以降）", "few_familiar": "数回か慣れ（2回目以降）"}
TIER_WHEN = {"first": ("eq", "first"), "few": ("eq", "few"), "familiar": ("eq", "familiar"), "few_familiar": ("in", ["few", "familiar"])}
FIRST_TIME = "この行為は今回が最初（この事実を地の文で言葉にしない。戸惑いは動作で表す）"
ANY_POS = "書かない（どの体位でも使う本文）"
LOWER_OPEN = "真帆の下は、下着をずらしてあるか脱いでいる（下着について書かない）。こちらは下を脱いでいる"

POS = {
    "player_above": "仰向けの真帆に、こちらが上から重なっている",
    "maho_above": "仰向けのこちらに、真帆がまたがっている",
    "from_behind": "四つん這いの真帆に、こちらが後ろから腰を寄せている",
    "sitting_face": "座ったこちらの膝に、真帆が向かい合ってまたがっている",
    "side_lying": "二人とも横向きに寝て、こちらが真帆の背中側から寄り添っている",
    "leg_up": "仰向けの真帆に上から重なり、真帆の片脚をこちらが抱え上げている",
    "prone_back": "うつ伏せの真帆に、こちらが後ろから重なっている",
    "standing_back": "壁に手をついて立つ真帆に、こちらが後ろから寄り添って立っている",
    "reverse_ride": "仰向けのこちらに、真帆が背を向けてまたがっている",
    "legs_shoulder": "仰向けの真帆の両脚を、上から重なるこちらの肩にかけている",
}
FEW_POS = ["from_behind", "sitting_face", "side_lying", "leg_up"]
FAMILIAR_POS = ["prone_back", "standing_back", "reverse_ride", "legs_shoulder"]
POS_CHANGE = {
    "from_behind": ("h_pos_from_behind", "こちらが促し、真帆が四つん這いになって、こちらが後ろから腰を寄せる", "体位を変える以外の動作（脱がせる、入れる、など）を足す"),
    "sitting_face": ("h_pos_sitting_face", "こちらが座り、真帆が向かい合ってこちらの膝にまたがる", "体位を変える以外の動作（脱がせる、入れる、など）を足す"),
    "side_lying": ("h_pos_side_lying", "二人で横向きに寝て、こちらが真帆の背中側から寄り添う", "体位を変える以外の動作（脱がせる、入れる、など）を足す"),
    "leg_up": ("h_pos_leg_up", "上から重なったまま、こちらが真帆の片脚を抱え上げる", "脚を抱える以外の動作（脱がせる、入れる、抜く、など）を足す。動きの速さを書く"),
    "prone_back": ("h_pos_prone_back", "こちらが促し、真帆がうつ伏せになって、こちらが後ろから重なる", "体位を変える以外の動作（脱がせる、入れる、など）を足す"),
    "standing_back": ("h_pos_standing_back", "ベッドを降りて、真帆が壁に手をつき、こちらが後ろに立つ", "体位を変える以外の動作（脱がせる、入れる、など）を足す"),
    "reverse_ride": ("h_pos_reverse_ride", "こちらが頼み、真帆がこちらに背を向けて、仰向けのこちらにまたがる", "体位を変える以外の動作（脱がせる、入れる、など）を足す"),
    "legs_shoulder": ("h_pos_legs_shoulder", "上から重なったまま、こちらが真帆の両脚を自分の肩にかける", "脚を肩にかける以外の動作（脱がせる、入れる、抜く、など）を足す。動きの速さを書く"),
}
MOVE = {
    "h_move_slow": ("こちらがゆっくり動く", "こちらがゆっくりした動きを続ける", "こちらがゆっくりした動きをさらに続ける"),
    "h_move_normal": ("こちらが少し速く動く", "こちらが少し速い動きを続ける", "こちらが少し速い動きをさらに続ける"),
    "h_move_fast": ("こちらが激しく動く", "こちらが激しい動きを続ける", "こちらが激しい動きをさらに続ける"),
}
MOVE_MUST = "速さを変える。体位を変える。達する"
FINISH_MUST = "妊娠・避妊に触れる。真帆が止める。台詞で「待って」「止まって」と言う（止める意味に読める）。中・外に触れる台詞。「入った」「出てる」のような実況の台詞"
OVERFLOW_MUST = FINISH_MUST + "。出すと自分で決めたように書く"
jobs = {1: [], 2: [], 3: []}


def job(wave, meaning, tier, key, s, meaning_text, state, *, pos=None, origin="主人公", length="100〜160字", cands=5, must_not=None, when=None, group=None, split_other=None):
    parts = [f"p{wave}", meaning] + ([tier] if tier else []) + ([pos] if pos else []) + ([split_other] if split_other else []) + [s]
    identity = ".".join(parts)
    conditions = list(when or [])
    if tier:
        op, value = TIER_WHEN[tier]
        conditions.insert(0, {"field": "intimacy.tier", "op": op, "value": value})
    if pos and pos not in ("", None) and not any(c["field"] == "intimacy.position" for c in conditions):
        conditions.append({"field": "intimacy.position", "op": "eq", "value": pos})
    row = {"id": identity, "meaning": meaning_text, "speech": s == "s", "length": length, "origin": origin, "candidates": cands,
           "state": state, "_wave": f"B2-{wave}", "_meaning": meaning, "_split": {"tier": tier, "position": pos, "other": split_other},
           "when": {"all": conditions}, "group": group or ("b." + meaning)}
    if must_not:
        row["must_not"] = must_not
    assert not any(j["id"] == identity for w in jobs.values() for j in w), identity
    jobs[wave].append(row)
    return row


def base(tier, **extra):
    state = {"場所": BED, "慣れ": TIER[tier]}
    state.update(extra)
    return state


def position_set(wave, pos, tiers):
    """新しい体位：体位を変える・入れる・抜く・動く・出す・こらえきれずに出る。"""
    change, change_text, change_must = POS_CHANGE[pos]
    place = WALL if pos == "standing_back" else BED
    insert_state = "この本文で入る"
    first_tier = tiers[0]
    # 体位を変える（その体位が初めての回と、それ以降）
    st = {"場所": place, "慣れ": TIER[first_tier], "経験": FIRST_TIME, "体位": "この本文で変わる（変わる前の体位は書かない）", "服": "書かない"}
    if pos in ("leg_up", "legs_shoulder"):
        st["挿入"] = "書かない（しているかどうかは書かない）"
    job(wave, change + ".first", None, None, "s", change_text, st, must_not=change_must, when=[{"field": "intimacy.tier", "op": "in", "value": tiers}])
    tier_set = "few_familiar" if len(tiers) == 2 else "familiar"
    for s in ("s", "n"):
        st = {"場所": place, "慣れ": TIER[tier_set], "体位": "この本文で変わる（変わる前の体位は書かない）", "服": "書かない"}
        if pos in ("leg_up", "legs_shoulder"):
            st["挿入"] = "書かない（しているかどうかは書かない）"
        job(wave, change + ".start", tier_set, None, s, change_text, st, must_not=change_must)
    for tier in tiers:
        common = {"場所": place, "慣れ": TIER[tier], "体位": POS[pos], "服": LOWER_OPEN}
        for s in ("s", "n"):
            job(wave, "h_insert.start", tier, None, s, "こちらがゆっくりと真帆の中に入る", {**common, "挿入": insert_state}, pos=pos, must_not="動き始める。痛みを大げさにする")
        for speed, (m_start, m_cont, m_settled) in MOVE.items():
            for s in ("s", "n"):
                job(wave, speed + ".start", tier, None, s, m_start, {**common, "挿入": "している"}, pos=pos, must_not=MOVE_MUST)
                job(wave, speed + ".continue", tier, None, s, m_cont, {**common, "続いている動作": "前の本文から続いている（" + m_cont + "）", "挿入": "している"}, pos=pos, must_not=MOVE_MUST)
            job(wave, speed + ".settled", tier, None, "n", m_settled, {**common, "続いている動作": "前の本文から続いている（" + m_cont + "）", "挿入": "している"}, pos=pos, must_not=MOVE_MUST)
        for s in ("s", "n"):
            job(wave, "h_finish_inside.start", tier, None, s, "こちらが真帆の中で達する", {**common, "挿入": "している"}, pos=pos, must_not=FINISH_MUST)
            job(wave, "h_finish_outside.start", tier, None, s, "こちらが抜いて、真帆の外で達する", {**common, "挿入": "している（この本文で抜く）"}, pos=pos, must_not=FINISH_MUST)
    for s in ("s", "n"):
        common = {"場所": place, "慣れ": TIER[tier_set], "体位": POS[pos], "服": LOWER_OPEN, "挿入": "している（この本文で抜く）"}
        job(wave, "h_withdraw.start", tier_set, None, s, "こちらが真帆の中から抜く", common, pos=pos, must_not="達する。服を着る")


def overflow(wave, pos, tiers):
    for tier in tiers:
        for s in ("s", "n"):
            place = WALL if pos == "standing_back" else BED
            job(wave, "h_overflow.inside", tier, None, s, "限界まで高まったまま動き続けたこちらが、こらえきれずに真帆の中で果てる",
                {"場所": place, "慣れ": TIER[tier], "体位": POS[pos], "服": LOWER_OPEN, "挿入": "している",
                 "主人公": "もう限界だったのに、そのまま動き続けた（出すと決めてはいない）"}, pos=pos, must_not=OVERFLOW_MUST)


def action_set(wave, meaning, tiers, texts, state_fn, *, first=True, origin="主人公", must_not=None, settled=True, cont=True, when=None):
    """口づけ・愛撫・奉仕などの継続する行動：初めて・始める・続ける・さらに続ける。"""
    t_start, t_cont, t_settled = texts
    if first:
        st = state_fn(tiers[0], "start")
        st = {**st, "経験": FIRST_TIME}
        job(wave, meaning + ".first", None, None, "s", t_start, st, origin=origin, must_not=must_not,
            when=[{"field": "intimacy.tier", "op": "in", "value": ["first"] if tiers[0] == "first" else ["first", "few"]}] + list(when or []))
    for tier in tiers:
        for s in ("s", "n"):
            job(wave, meaning + ".start", tier, None, s, t_start, state_fn(tier, "start"), origin=origin, must_not=must_not, when=when)
            if cont:
                job(wave, meaning + ".continue", tier, None, s, t_cont, {**state_fn(tier, "continue"), "続いている動作": "前の本文から続いている（" + t_cont.split("（")[0] + "）"}, origin=origin, must_not=must_not, when=when)
        if settled:
            job(wave, meaning + ".settled", tier, None, "n", t_settled, {**state_fn(tier, "continue"), "続いている動作": "前の本文から続いている（" + t_cont.split("（")[0] + "）"}, origin=origin, must_not=must_not, when=when)


def simple_set(wave, meaning, tiers, text, state_fn, *, origin="主人公", must_not=None, first=True):
    """服・体位などの一度きりの行動：初めてと、始める。"""
    if first:
        job(wave, meaning + ".first", None, None, "s", text, {**state_fn(tiers[0]), "経験": FIRST_TIME}, origin=origin, must_not=must_not,
            when=[{"field": "intimacy.tier", "op": "in", "value": ["first"]}])
    for tier in tiers:
        for s in ("s", "n"):
            job(wave, meaning + ".start", tier, None, s, text, state_fn(tier), origin=origin, must_not=must_not)


# ---------------- 第1陣：数回から使える新しい体位（4）と、こらえきれずに出る ----------------
for pos in FEW_POS:
    position_set(1, pos, ["few", "familiar"])
overflow(1, "player_above", ["first", "few", "familiar"])
overflow(1, "maho_above", ["few", "familiar"])
for pos in FEW_POS:
    overflow(1, pos, ["few", "familiar"])

# 背を向けた体位（後ろから・横向き・うつ伏せ・立って後ろから・背を向けて乗る）で出る、体位を問わない本文。
# これまでの「どの体位でも」の本文は、向かい合う前提（見つめる、首に腕を回す、シーツ など）のものが多いため。
BACK_PLACE = "ベッドの上か、ベッドのそばの壁際（どちらかは書かない。ベッド・シーツ・枕・壁の語を書かない）"
BACK_POS = "真帆はこちらに背を向けている（どの体位かは書かない。寝ているか立っているかも書かない。真帆の顔は、こちらからは見えない）"
BACK_MUST = "真帆の顔や目を正面から見たように書く（肩越しに振り返るのはよい）。口づける"
FACING_BACK = {"field": "intimacy.facing", "op": "eq", "value": "back"}


def back(tier, **extra):
    st = {"場所": BACK_PLACE, "慣れ": TIER[tier], "体位": BACK_POS}
    st.update(extra)
    return st


SIGNS = {"h.sign.mid": "真帆の息が上がり始める", "h.sign.high": "真帆の余裕がなくなってくる", "h.sign.near": "真帆が今にも達しそうになる"}
WANTS_MORE = ("真帆が、今の触れ方では物足りず、もっと先へ進んでほしいことを、態度と短い台詞で伝える（今している行動を特定しない）",
              "達したことにする。meaning にない動作を足す。今のままを求める台詞（「続けて」「やめないで」「このまま」「離さないで」など）。今している行動を特定する語")
SIGN_MUST = "達したことにする。meaning にない動作を足す"
for tier in ("few", "familiar"):
    for key, text in SIGNS.items():
        job(1, key, tier, None, "n", text, back(tier), origin="真帆", length="30〜70字（地の文1〜2文）", cands=7,
            must_not=SIGN_MUST + "。" + BACK_MUST, split_other="back", when=[FACING_BACK])
    job(1, "h.sign.wants_more", tier, None, "s", WANTS_MORE[0], back(tier), origin="真帆", length="30〜70字（地の文1〜2文）", cands=7,
        must_not=WANTS_MORE[1] + "。" + BACK_MUST, split_other="back", when=[FACING_BACK])
    for s in ("s", "n"):
        job(1, "h.climax.maho", tier, None, s, "真帆が達する", back(tier, 服=LOWER_OPEN, 挿入="している"), origin="真帆", length="80〜140字", cands=7,
            must_not="慣れの段階にない語を台詞に使う。ほかの絶頂の job と同じ台詞・最後の文を使う。" + BACK_MUST, split_other="inserted_back",
            when=[{"field": "intimacy.inserted", "op": "eq", "value": True}, FACING_BACK])
        job(1, "h.climax.together", tier, None, s, "こちらと同時に、真帆も達する", back(tier, 服=LOWER_OPEN, 挿入="こちらが達するのと同じ瞬間（中か外かは書かない）"),
            origin="真帆", length="80〜140字", cands=7, must_not="慣れの段階にない語を台詞に使う。ほかの絶頂の job と同じ台詞・最後の文を使う。" + BACK_MUST,
            split_other="back", when=[FACING_BACK])
for s in ("s", "n"):
    job(1, "h_endure.start", "few_familiar", None, s, "こちらが達しそうになるのをこらえ、動きを止める", back("few_familiar", 服=LOWER_OPEN, 挿入="している"),
        must_not="達したことにする。余力が減ったように書く。" + BACK_MUST, split_other="back", when=[FACING_BACK])
    job(1, "h_feel.start", "few_familiar", None, s, "こちらが、背中越しに真帆の耳元で好きだと伝える", back("few_familiar", 服="書かない"),
        must_not="主人公の心の中の言葉を書く。" + BACK_MUST, split_other="back", when=[FACING_BACK])
    job(1, "h_after_hold.start", "few_familiar", None, s, "こちらが真帆を背中から抱きしめて休む",
        back("few_familiar", 服="書かない", 余韻="こちらか真帆が達した直後（どちらかは書かない）"), must_not="もう一度始める。" + BACK_MUST,
        split_other="back", when=[FACING_BACK])
for band, look, cond in (("low", "まだ落ち着いている", {"field": "intimacy.maho.band", "op": "eq", "value": "low"}),
                         ("mid", "息が浅くなっている", {"field": "intimacy.maho.band", "op": "eq", "value": "mid"}),
                         ("high", "余裕がなくなっている", {"field": "intimacy.maho.band", "op": "in", "value": ["high", "near"]})):
    job(1, "h_check.start", "few_familiar", None, "s", "こちらが背中越しに真帆に様子を尋ね、真帆が答える", back("few_familiar", 服="書かない", 真帆の様子=look),
        must_not="状態のラベル（高まり、中、など）を台詞に出す。挿入しているかを決める語（腰の動き、腰を止める など）。こちらの動きは「動きを緩めて」とだけ書く。" + BACK_MUST,
        split_other="back_band_" + band, when=[cond, FACING_BACK])
for meaning, texts, cloth, must in (
        ("h_ear_neck", ("こちらが、背中側から真帆の耳元や首筋に口づける", "こちらが耳元や首筋への口づけを続ける", "こちらが耳元や首筋への口づけをさらに続ける"), "書かない", "口づけ以外の愛撫を足す。服の状態を書く"),
        ("h_chest_over", ("こちらが後ろから手を回し、服の上から真帆の胸に触れる", "こちらが服の上から胸に触れ続ける", "こちらが服の上から胸に、さらに触れ続ける"), "真帆は上の服を着ている", "服をめくる・脱がせる"),
        ("h_chest_skin", ("こちらが後ろから手を回し、真帆の胸に直接触れる", "こちらが胸に直接触れ続ける", "こちらが胸に、さらに直接触れ続ける"), "真帆は上の服がめくれ上がっているか、脱いでいる（どちらかは書かない）", "服を脱がせる・めくる描写を足す")):
    for s in ("s", "n"):
        job(1, meaning + ".start", "few_familiar", None, s, texts[0], back("few_familiar", 服=cloth), must_not=must + "。" + BACK_MUST, split_other="back", when=[FACING_BACK])
        job(1, meaning + ".continue", "few_familiar", None, s, texts[1], back("few_familiar", 服=cloth, 続いている動作="前の本文から続いている（" + texts[1] + "）"),
            must_not=must + "。" + BACK_MUST, split_other="back", when=[FACING_BACK])
    job(1, meaning + ".settled", "few_familiar", None, "n", texts[2], back("few_familiar", 服=cloth, 続いている動作="前の本文から続いている（" + texts[1] + "）"),
        must_not=must + "。" + BACK_MUST, split_other="back", when=[FACING_BACK])

# ---------------- 第2陣：新しい愛撫・服・奉仕・自分で・眠り ----------------
def anypos(extra_cloth=None):
    def fn(tier, phase):
        st = base(tier, 体位=ANY_POS, 服=extra_cloth or "書かない")
        return st
    return fn

def face_state(tier, phase):
    return base(tier, 体位="向かい合っている（寝ているか座っているかは書かない）", 服="書かない")
action_set(2, "h_ear_neck", ["first", "few", "familiar"],
           ("こちらが真帆の耳元や首筋に口づける", "こちらが耳元や首筋への口づけを続ける", "こちらが耳元や首筋への口づけをさらに続ける"),
           face_state, must_not="口づけ以外の愛撫を足す。服の状態を書く", when=[{"field": "intimacy.facing", "op": "eq", "value": "face"}])
action_set(2, "h_chest_mouth", ["first", "few", "familiar"],
           ("こちらが真帆の胸に口づけ、乳首を唇で含む", "こちらが胸への口づけを続ける", "こちらが胸への口づけをさらに続ける"),
           anypos("真帆の上の服は、めくれ上がっているか脱いでいる（どちらかは書かない）"), must_not="服をめくる・脱がせる描写を足す。下に触れる")
action_set(2, "h_touch_under", ["first", "few", "familiar"],
           ("こちらが下着の上から真帆の秘所に触れる", "こちらが下着の上から触れ続ける", "こちらが下着の上から、さらに触れ続ける"),
           anypos("真帆は下の服を脱いで、下着だけになっている"), must_not="下着をずらす・脱がせる。直接触れる。入れる")
action_set(2, "h_finger_in", ["few", "familiar"],
           ("こちらが真帆の中に指を入れる", "こちらが中に入れた指を動かし続ける", "こちらが中に入れた指を、さらに動かし続ける"),
           anypos(LOWER_OPEN.replace("。こちらは下を脱いでいる", "")), must_not="指以外を入れる。二人の位置関係を書く")

def player_mouth_state(tier, phase):
    return base(tier, 体位="この本文で、こちらが真帆の脚のあいだに顔を寄せる（真帆は横になっている）" if phase == "start" else "横になった真帆の脚のあいだに、こちらが顔を寄せている",
                服=LOWER_OPEN.replace("。こちらは下を脱いでいる", ""), 挿入="していない")
action_set(2, "h_player_mouth", ["few", "familiar"],
           ("こちらが真帆の脚のあいだに顔を寄せ、秘所に口で触れる", "こちらが口での愛撫を続ける", "こちらが口での愛撫をさらに続ける"),
           player_mouth_state, must_not="指を入れる。入れる。こちらの体を書く")
# 口で愛撫している間の真帆の合図（これまでの合図には、向かい合う前提のものが多い）
MOUTH_ST = lambda: base("few_familiar", 体位="横になった真帆の脚のあいだに、こちらが顔を寄せている", 服=LOWER_OPEN.replace("。こちらは下を脱いでいる", ""), 挿入="していない",
                        続いている動作="こちらが口で愛撫している")
MOUTH_MUST = "口づける。こちらの顔を見つめ合う。首に腕を回す"
for key, text in SIGNS.items():
    job(2, key, "few_familiar", None, "n", text, MOUTH_ST(), origin="真帆", length="30〜70字（地の文1〜2文）", cands=7,
        must_not=SIGN_MUST + "。" + MOUTH_MUST, split_other="player_mouth", when=[{"field": "intimacy.facing", "op": "eq", "value": "player_mouth"}])
job(2, "h.sign.wants_more", "few_familiar", None, "s", WANTS_MORE[0], MOUTH_ST(), origin="真帆", length="30〜70字（地の文1〜2文）", cands=7,
    must_not=WANTS_MORE[1] + "。" + MOUTH_MUST, split_other="player_mouth", when=[{"field": "intimacy.facing", "op": "eq", "value": "player_mouth"}])

simple_set(2, "h_strip_upper", ["first", "few_familiar"], "こちらが真帆の上の服を脱がせる",
           lambda tier: base(tier, 体位=ANY_POS, 服="真帆の上の服は、この本文で脱がされる"), must_not="下を脱がせる。胸に触れる以上の愛撫を足す")
simple_set(2, "h_strip_under", ["first", "few_familiar"], "こちらが真帆の下着を脱がせる",
           lambda tier: base(tier, 体位=ANY_POS, 服="真帆の下着は、この本文で脱がされる（下の服はすでに脱いでいる）"), must_not="入れる。指で中に触れる")
simple_set(2, "h_strip_self_upper", ["first", "few_familiar"], "こちらが自分の上の服を脱ぐ",
           lambda tier: base(tier, 体位=ANY_POS, 服="こちらの上の服は、この本文で脱ぐ"), must_not="真帆の服を脱がせる。入れる")

def maho_hand_state(tier, phase):
    return base(tier, 体位=ANY_POS, 服="こちらは下を脱いでいる", 挿入="していない")
action_set(2, "h_maho_hand", ["first", "few", "familiar"],
           ("真帆が、こちらの男性器を手で包んで扱く", "真帆が手での愛撫を続ける", "真帆が手での愛撫をさらに続ける"),
           maho_hand_state, origin="真帆", must_not="口でする。入れる。こちらが達する")

def maho_mouth_state(tier, phase):
    return base(tier, 体位="この本文で、真帆がこちらの脚のあいだに身をかがめる" if phase == "start" else "こちらの脚のあいだに、真帆が身をかがめている",
                服="こちらは下を脱いでいる", 挿入="していない")
action_set(2, "h_maho_mouth", ["few", "familiar"],
           ("真帆が、こちらの男性器を口に含む（台詞は口を離した合間の短い一言）", "真帆が口での愛撫を続ける（台詞は口を離した合間の短い一言）", "真帆が口での愛撫をさらに続ける"),
           maho_mouth_state, origin="真帆", must_not="入れる。こちらが達する。台詞を口に含んだまま言う")

for tier in ("first", "few", "familiar"):
    for s in ("s", "n"):
        job(2, "h_finish_hand.start", tier, None, s, "真帆の手の中で、こちらが達する",
            base(tier, 体位=ANY_POS, 服="こちらは下を脱いでいる", 挿入="していない", 続いている動作="真帆が手で扱いている"), must_not=FINISH_MUST.replace("中・外に触れる台詞。", ""))
        job(2, "h_overflow.hand", tier, None, s, "限界まで高まったまま真帆の手が止まらず、こちらがこらえきれずに真帆の手の中で果てる",
            base(tier, 体位=ANY_POS, 服="こちらは下を脱いでいる", 挿入="していない", 続いている動作="真帆が手で扱いている", 主人公="もう限界だったのに、そのまま続けてもらった（出すと決めてはいない）"),
            origin="真帆", must_not=OVERFLOW_MUST.replace("中・外に触れる台詞。", ""))
for tier in ("few", "familiar"):
    for s in ("s", "n"):
        job(2, "h_finish_mouth.start", tier, None, s, "真帆の口の中で、こちらが達する",
            base(tier, 体位="こちらの脚のあいだに、真帆が身をかがめている", 服="こちらは下を脱いでいる", 挿入="していない", 続いている動作="真帆が口でしている"),
            must_not=FINISH_MUST.replace("中・外に触れる台詞。", "") + "。飲ませるよう求める")
        job(2, "h_overflow.mouth", tier, None, s, "限界まで高まったまま真帆の口での愛撫が続き、こちらがこらえきれずに真帆の口の中で果てる",
            base(tier, 体位="こちらの脚のあいだに、真帆が身をかがめている", 服="こちらは下を脱いでいる", 挿入="していない", 続いている動作="真帆が口でしている", 主人公="もう限界だったのに、そのまま続けてもらった（出すと決めてはいない）"),
            origin="真帆", must_not=OVERFLOW_MUST.replace("中・外に触れる台詞。", "") + "。飲ませるよう求める")

def self_state(tier, phase):
    return base(tier, 体位=ANY_POS, 服="こちらは下を脱いでいる", 挿入="していない", 真帆の様子="すぐそばで、こちらを見ている")
action_set(2, "h_self", ["first", "few", "familiar"],
           ("真帆に見られながら、こちらが自分の男性器を手で扱き、自分で高める", "こちらが自分で扱き続ける", "こちらが自分で扱き、さらに続ける"),
           self_state, must_not="真帆が触れる。こちらが達する。真帆に触るよう頼む", settled=False)
for tier, kinds in (("first", ["look_away"]), ("few", ["look_away", "watch"]), ("familiar", ["watch"])):
    for kind in kinds:
        text = {"look_away": "こちらが自分でしているのを見て、真帆が照れて目をそらしながらも、ちらりと見てしまう",
                "watch": "こちらが自分でしているのを、真帆がじっと見つめ、自分も息を乱す"}[kind]
        for s in ("s", "n"):
            job(2, "h.self.react." + kind, tier, None, s, text, base(tier, 体位=ANY_POS, 服="こちらは下を脱いでいる"), origin="真帆", length="80〜140字", cands=5,
                must_not="真帆が触れる。こちらが達する")
for tier in ("first", "few", "familiar"):
    job(2, "offer.h_help.hand", tier, None, "s", "こちらが自分でしているのを見て、真帆が「手でしようか」と申し出る", base(tier, 服="こちらは下を脱いでいる"),
        origin="真帆", length="60〜120字", must_not="触れ始める。長く説明する")
for tier in ("few", "familiar"):
    job(2, "offer.h_help.mouth", tier, None, "s", "こちらが自分でしているのを見て、真帆が「口でしようか」と申し出る", base(tier, 服="こちらは下を脱いでいる"),
        origin="真帆", length="60〜120字", must_not="触れ始める。長く説明する")
for tier in ("few", "familiar"):
    for s in ("s", "n"):
        job(2, "h.climax.maho", tier, None, s, "こちらの口での愛撫で、真帆が達する",
            {"場所": BED, "慣れ": TIER[tier], "服": LOWER_OPEN.replace("。こちらは下を脱いでいる", ""), "挿入": "していない（こちらが口で触れていた）"},
            origin="真帆", length="80〜140字", cands=7, must_not="慣れの段階にない語を台詞に使う", split_other="mouth",
            when=[{"field": "intimacy.maho.climax_source", "op": "eq", "value": "mouth"}])
for result, label in (("satisfied", "満ち足りている"), ("unsatisfied", "少し物足りなさが残っている")):
    for tier in ("first", "few_familiar"):
        for s in ("s", "n"):
            job(2, "h.sleep_together." + result, tier, None, s,
                "エッチを終えた夜、そのまま二人で同じベッドで眠りにつく",
                {"場所": "エッチをした個室のベッド（どちらの部屋かは書かない）", "慣れ": TIER[tier], "時刻": "夜", "真帆の満足": label},
                origin="真帆", length="80〜140字", must_not="もう一度始める。服を着る。翌朝の出来事を書く")
            job(2, "h.morning_together." + result, tier, None, s,
                "エッチをした夜のまま同じベッドで目を覚まし、真帆が一言かける",
                {"場所": "同じベッド（どちらの部屋かは書かない）", "慣れ": TIER[tier], "時刻": "朝", "真帆の満足": label},
                origin="真帆", length="80〜140字", must_not="行為を具体的に振り返る。もう一度始める",
                when=[{"field": "intimacy.slept_together", "op": "eq", "value": True}])

# ---------------- 第3陣：慣れから使える体位（4）と、いつもの触れ合いから深める ----------------
for pos in FAMILIAR_POS:
    position_set(3, pos, ["familiar"])
    overflow(3, pos, ["familiar"])

BEFORE, AFTER = "before", "after"
REL = {BEFORE: "恋人（まだエッチはしていない）", AFTER: "恋人（エッチをしたことがある）"}
REL_WHEN = {BEFORE: {"field": "intimacy.history_count", "op": "eq", "value": 0}, AFTER: {"field": "intimacy.history_count", "op": "ge", "value": 1}}

def life_state(group, extra=None):
    st = {"場所": HOME, "関係": REL[group], "服": "普段着（服の種類は書かない）", "姿勢": "書かない（立っているか座っているかは書かない）"}
    st.update(extra or {})
    return st

GATE = [
    ("deep_kiss", ("こちらが真帆に深く口づける", "こちらが深い口づけを続ける", "こちらが深い口づけをさらに続ける"), True, "口づけ以外の愛撫を足す。服を脱がせる。部屋へ移る"),
    ("ear_kiss", ("こちらが真帆の耳元や首筋に口づける", "こちらが耳元や首筋への口づけを続ける", "こちらが耳元や首筋への口づけをさらに続ける"), True, "口づけ以外の愛撫を足す。服を脱がせる。部屋へ移る"),
    ("chest_touch", ("こちらが服の上から真帆の胸に触れる", "こちらが服の上から胸に触れ続ける", "こちらが服の上から胸に、さらに触れ続ける"), True, "服をめくる・脱がせる。下に触れる。部屋へ移る"),
    ("thigh_touch", ("こちらが真帆の太ももを撫でる（二人は並んで座っている）", "こちらが太ももを撫で続ける", "こちらが太ももを、さらに撫で続ける"), True, "服の中に手を入れる。秘所に触れる。部屋へ移る"),
    ("under_clothes", ("こちらが真帆の服の裾から手を入れ、背中や脇腹の素肌に触れる", "こちらが服の中で素肌に触れ続ける", "こちらが服の中で、さらに素肌に触れ続ける"), True, "胸や秘所に触れる。服を脱がせる。部屋へ移る"),
    ("push_down", ("こちらが真帆をそっと押し倒す", None, None), False, "服を脱がせる。入れる。部屋へ移る"),
]
for key, texts, ongoing, must in GATE:
    for group in (BEFORE, AFTER):
        tier_label = {BEFORE: "before_h", AFTER: "after_h"}[group]
        for s in ("s", "n"):
            job(3, key + ".start", None, None, s, texts[0], life_state(group, {"姿勢": "並んで座っている" if key == "thigh_touch" else "書かない（立っているか座っているかは書かない）",
                                                                           **({"場所": "居間か、二人の個室のどちらか（場所の名前は書かない）"} if key == "push_down" else {})}),
                must_not=must, split_other=tier_label, when=[REL_WHEN[group]])
            if ongoing:
                job(3, key + ".continue", None, None, s, texts[1], life_state(group, {"続いている動作": "前の本文から続いている（" + texts[1] + "）"}),
                    must_not=must, split_other=tier_label, when=[REL_WHEN[group]])
        if ongoing:
            job(3, key + ".settled", None, None, "n", texts[2], life_state(group, {"続いている動作": "前の本文から続いている（" + texts[1] + "）"}),
                must_not=must, split_other=tier_label, when=[REL_WHEN[group]])
    for group in (BEFORE, AFTER):
        tier_label = {BEFORE: "before_h", AFTER: "after_h"}[group]
        job(3, key + ".first", None, None, "s", texts[0], life_state(group, {"経験": FIRST_TIME, **({"姿勢": "並んで座っている"} if key == "thigh_touch" else {}),
                                                                          **({"場所": "居間か、二人の個室のどちらか（場所の名前は書かない）"} if key == "push_down" else {})}),
            must_not=must, split_other=tier_label, when=[REL_WHEN[group]])
REACT = [
    ("invite", "触れ合いに乗ってきた真帆が、自分から部屋へ行こうと誘う", "移動したことにする。服を脱がせる"),
    ("allow", "真帆が照れながら触れ合いを受け入れる（先へは進まない）", "部屋へ誘う。服を脱がせる"),
    ("deflect_place", "居間や台所なので、真帆が「ここではだめ」とやんわり止める（嫌がってはいない）", "部屋へ誘う。怒る。場所の名前を書く"),
    ("deflect_time", "仕事の前など時間がないので、真帆がやんわり止める（嫌がってはいない）", "部屋へ誘う。怒る。時刻を書く"),
]
for kind, text, must in REACT:
    for group in (BEFORE, AFTER):
        tier_label = {BEFORE: "before_h", AFTER: "after_h"}[group]
        job(3, "gate.react." + kind, None, None, "s", text, life_state(group), origin="真帆", length="60〜120字", cands=5, must_not=must,
            split_other=tier_label, when=[REL_WHEN[group]])

# ---------------- 出力 ----------------
BATCH = 13
for wave, rows in jobs.items():
    (OUT / f"grok_b2_wave_{wave}.json").write_text(json.dumps(rows, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
    folder = OUT / f"grok依頼_B2_第{wave}陣"
    folder.mkdir(exist_ok=True)
    for old in folder.glob("*.txt"):
        old.unlink()
    for speech, label in ((True, "台詞あり"), (False, "台詞なし")):
        part = [r for r in rows if r["speech"] == speech]
        count = -(-len(part) // BATCH)
        size = -(-len(part) // count) if count else 0
        for index in range(0, len(part), size or 1):
            chunk = part[index:index + size]
            total = sum(r["candidates"] for r in chunk)
            number = len(list(folder.glob("*.txt"))) + 1
            lines = [json.dumps({"id": r["id"], "meaning": r["meaning"], "speech": r["speech"], "length": r["length"], "origin": r["origin"], "本数": r["candidates"],
                                 **({"must_not": r["must_not"]} if r.get("must_not") else {}), "state": r["state"]}, ensure_ascii=False) for r in chunk]
            body = ("指示\n"
                    f"次の{len(chunk)}件の job を書いてください（段階Bの2版目・第{wave}陣・{label}）。本数は各 job の「本数」のとおりです（合わせて{total}本）。"
                    "途中で切れそうなら、job の区切りで止めてください。「続けて」と言われたら、止めた job の次から出してください。\n\n[\n  " + ",\n  ".join(lines) + "\n]\n\n"
                    "プロンプト\n" + PROMPT)
            (folder / f"B2_第{wave}陣_{number:02d}.txt").write_text(body, encoding="utf-8")
summary = {f"第{w}陣": {"jobs": len(rows), "candidates": sum(r["candidates"] for r in rows), "files": len(list((OUT / f"grok依頼_B2_第{w}陣").glob("*.txt")))} for w, rows in jobs.items()}
print(json.dumps(summary, ensure_ascii=False))
