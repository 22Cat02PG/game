"""v8.2.26（ユーザー 2026-09-30「関係性や展開として自然かどうかが一番大事」→ Opus の判断を了承「おけ、じゃあ始めていいよ」）：
v8.2.25 の精査で「設計の判断が要る」とした食い違いの直し。公開の選択肢（Engine.choose／get_view）から確かめる（時刻・慣れ・高まり・気分の準備だけ内部で行う）。"""
import json
import unittest
from pathlib import Path

from nagishima.progression import day_time
from tests.test_v8225 import Life, meanings, text_ids
from tools.run_stage_b_routes import Route

ROOT = Path(__file__).resolve().parents[1]


class V8226Intimacy(unittest.TestCase):
    def route(self, seed, setup=(), tier="few", **kw):
        route = Route(seed, tier=tier, **({"day_offset": 3, "hour": 13} | kw))
        self.addCleanup(route.close)
        route.begin()
        for key in setup:
            route.action(key)
        return route

    def hold(self, route, maho, player=10):
        intimate = route.engine._state["intimacy"]
        intimate["maho"].update(arousal=maho, band=route.engine.pack.intimacy.band(maho))
        intimate["player"]["arousal"] = player
        route.engine._install_choices()

    def pace(self, route, identity):
        if route.engine.get_view()["page"] != "main":
            route.choose("menu.main")
        route.choose(identity)

    def decline_all(self, route):
        while route.engine.snapshot()["offer"]:
            route.choose("offer.decline")

    # ---- 1. 「上になる」は「高い」でも出る（止めるのは「もうすぐ」だけ） ----
    def test_straddle_offer_comes_when_high(self):
        kinds = []
        for seed in range(9621, 9641):
            route = self.route(seed, ("h_strip_lower", "h_strip_self"), tier="familiar")
            for _ in range(5):
                self.hold(route, 85)
                route.action("h_kiss_deep")
                offer = route.engine.snapshot()["offer"]
                if offer:
                    kinds.append(offer["kind"])
                    route.choose("offer.decline")
        self.assertIn("h_lead_straddle", kinds)

    # ---- 2. 物足りない合図は、こちらが応えるまで数え続ける ----
    def test_wants_more_counts_across_alternation(self):
        """胸に口づけると深い口づけを行き来しても数え直さず、焦れた合図まで進む（v8.2.25 までは行き来のたびに1回目に戻った）。"""
        route = self.route(9651, ("h_lift_upper", "h_strip_lower", "h_strip_self", "h_pos_lying_face"), tier="few")
        self.hold(route, 85)
        kinds = []
        for step in range(40):
            route.engine._state["intimacy"]["player"]["arousal"] = 10
            route.engine._install_choices()
            self.decline_all(route)
            route.action("h_kiss_deep" if step % 5 == 4 else "h_chest_mouth")
            kinds += [m for m in meanings(route.engine) if m.startswith("h.sign.wants_more")]
        self.assertIn("h.sign.wants_more_urge", kinds, kinds)

    def test_wants_more_resets_after_inserting(self):
        """焦らしたあとに入れたら数え直す（入れた直後に「まだ焦らすんだ」と言わない）。"""
        route = self.route(9661, ("h_lift_upper", "h_strip_lower", "h_shift_under", "h_strip_self", "h_pos_player_above"), tier="familiar")
        self.hold(route, 85)
        before = []
        for step in range(24):
            route.engine._state["intimacy"]["player"]["arousal"] = 10
            route.engine._install_choices()
            self.decline_all(route)
            route.action("h_chest_skin")
            before += [m for m in meanings(route.engine) if m.startswith("h.sign.wants_more")]
        self.assertIn("h.sign.wants_more_urge", before, before)
        route.action("h_insert")
        route.action("h_move_slow")
        seen = []
        for step in range(12):
            route.engine._state["intimacy"]["player"]["arousal"] = 10
            route.engine._install_choices()
            self.decline_all(route)
            route.action("h_move_slow")
            seen += [m for m in meanings(route.engine) if m.startswith(("h.sign.wants_more", "h.climax"))]
            if any(m.startswith("h.climax") for m in seen):
                break
        signs = [m for m in seen if m.startswith("h.sign.wants_more")]
        self.assertTrue(signs, seen)
        self.assertEqual(signs[0], "h.sign.wants_more", seen)

    # ---- 3. ねだったあとは「激しく」も止めない ----
    def test_no_fast_deflect_after_begging(self):
        route = self.route(9671, ("h_strip_lower", "h_shift_under", "h_strip_self", "h_pos_player_above"), tier="familiar")
        route.engine._state["intimacy_history"]["lewdness"] = 70  # 準備：大胆
        for _ in range(8):
            self.decline_all(route)
            self.hold(route, 64)
            route.action("h_tease")
            if route.engine.snapshot()["intimacy"]["begged"]:
                break
        self.assertTrue(route.engine.snapshot()["intimacy"]["begged"])
        self.hold(route, 72)
        route.action("h_insert")
        self.hold(route, 74)
        route.action("h_move_fast")
        self.assertNotIn("h.deflect.fast", meanings(route.engine))
        self.assertIn("h_move_fast", [c["action_id"] for c in route.engine.snapshot()["contacts"]])

    # ---- 4. 真帆が自分で動くときも、「激しく」は同じ高まりを待つ ----
    def test_maho_fast_waits_like_player_fast(self):
        route = self.route(9681, ("h_strip_lower", "h_shift_under", "h_strip_self", "h_pos_maho_above"), tier="few")
        self.decline_all(route)
        self.hold(route, 60)
        route.action("h_insert")
        route.action("h_maho_move")
        self.hold(route, 60)
        self.pace(route, "pace.h_maho_move.fast")
        self.assertIn("h.deflect.maho_fast", meanings(route.engine))
        self.assertNotEqual(route.engine.snapshot()["intimacy"]["paces"].get("h_maho_move"), "fast")
        # 頭をなでても、まだ激しくはならない
        route.action("h_stroke_head")
        self.assertNotEqual(route.engine.snapshot()["intimacy"]["paces"].get("h_maho_move"), "fast")
        # 高まれば激しくできる
        self.hold(route, 84)
        self.pace(route, "pace.h_maho_move.fast")
        self.assertIn("h_maho_move.pace_fast", meanings(route.engine))

    # ---- 本文の条件 ----
    def test_texts(self):
        route = Route(9690)
        self.addCleanup(route.close)
        pack = route.engine.pack
        texts = {t["id"]: t for t in pack.texts}
        # 深める触れ合いを許す本文：「ここでは」と言う本文は部屋の中では出さない
        for identity in ("p3.gate.react.allow.before_h.s.v2", "p3.gate.react.allow.after_h.s.v1"):
            self.assertIn("ここ", texts[identity]["body"])
            self.assertIn('"actor.player.location"', json.dumps(texts[identity]["when"]))
            self.assertNotIn("maho_room", json.dumps(texts[identity]["when"]))
        for text in pack.texts:
            if text["meaning"] == "gate.react.allow" and not text["fallback"]:
                self.assertNotRegex(text["body"], r"先はまだ|今日は、触れてる|続きはしなくて", text["id"])
        self.assertIn('"experience.h_pos_maho_above.count", "op": "eq", "value": 0', json.dumps(texts["b2.offer.h_lead.straddle.few.s.v5"]["when"]))
        morning = [t for t in pack.texts if t["meaning"].startswith("share_day.") and not t["fallback"] and '"world.slot", "op": "eq", "value": "morning"' in json.dumps(t["when"])]
        self.assertGreaterEqual(len(morning), 13)
        for text in morning:
            self.assertNotRegex(text["body"], r"今日あった|一日の話", text["id"])
        deflect = [t for t in pack.texts if t["meaning"] == "h.deflect.maho_fast" and not t["fallback"]]
        self.assertGreaterEqual(len(deflect), 8)
        # 13. 抱き合っている最中は「隣を軽く叩いた」誘いを出さない
        self.assertIn('"contact.hug.active", "op": "eq", "value": false', json.dumps(texts["offer.shared.quiet.a2.j4.3"]["when"]))
        # 12. 前の回を前提にする「続ける」本文・短い1行（精査 C U-5）は、その行為を前の回にもしたときだけ
        fixes = json.loads((ROOT / "tools/stage_b/text_fixes_v8225.json").read_text(encoding="utf-8"))
        ids = [i for entry in fixes["when"] if "C U-5" in entry.get("_note", "") for i in entry["ids"]]
        self.assertGreaterEqual(len(ids), 65)
        for identity in ids:
            self.assertIn(".before_session", json.dumps(texts[identity]["when"]), identity)


class V8226Life(unittest.TestCase):
    def life(self, seed, cheats=False):
        life = Life(seed, cheats)
        self.addCleanup(life.close)
        return life

    def to_evening(self, life):
        for _ in range(3):
            life.decline_offers()
            life.go("work.go")

    # ---- 5. 断った誘いは、その日はもう出さない ----
    def test_declined_offer_not_repeated_the_same_day(self):
        life = self.life(29)
        self.to_evening(life)
        offer = life.engine.snapshot()["offer"]
        self.assertIsNotNone(offer)
        kind = offer["kind"]
        life.go("offer.decline")
        for activity in ("activity.quiet", "activity.reading"):
            choice = life.choice(activity)
            if choice is None or not choice["available"]:
                continue
            life.go(activity)
            life.go("scene.finish")
            offer = life.engine.snapshot()["offer"]
            self.assertFalse(offer and offer["kind"] == kind, (kind, offer))
            life.decline_offers()

    # ---- 9. 食事の間隔 ----
    def test_meal_gap_and_evening(self):
        life = self.life(29)
        self.to_evening(life)
        life.decline_offers()
        life.go("move.joint.kitchen")
        while day_time(life.engine.snapshot()["world"]["now"]) < 16 * 60 + 30:
            life.decline_offers()
            life.go("listen")
        life.decline_offers()
        # 夕食の時間帯（18:30〜）の150分前（16:00）より後に終えた手動の食事は夕食として数える（v8.2.25 は 60分前の 17:30 から）。
        # そのあとは自動の夕食が入らず、その夜はもう食事を選べない
        life.go("activity.meal")
        life.go("scene.finish")
        for _ in range(6):
            life.decline_offers()
            life.go("wait.30")
            self.assertNotIn("life.dinner", meanings(life.engine))
        life.decline_offers()
        if life.engine.snapshot()["actors"]["player"]["location"] != "kitchen":
            life.go("move.joint.kitchen")
        choice = life.choice("activity.meal")
        self.assertFalse(choice["available"])

    # ---- 8. 約束の話を日をまたいで続けると、問いを選び直す ----
    def test_promise_question_reselected_on_resume(self):
        life = self.life(29)
        self.to_evening(life)
        life.decline_offers()
        life.go("begin.promise_tea")
        asked = text_ids(life.engine)[-1]
        life.go("scene.pause")
        parked = life.engine.snapshot()["suspended"][0]["id"]
        for _ in range(8):
            life.decline_offers()
            if life.choice("sleep") and life.choice("sleep")["available"]:
                break
            life.go("wait.120")
        life.decline_offers()
        life.go("sleep")
        for _ in range(3):
            life.decline_offers()
            life.go("work.go")
        life.decline_offers()
        life.go("resume." + parked)
        self.assertEqual(meanings(life.engine), ["promise.tea.ask"])
        self.assertNotEqual(text_ids(life.engine)[-1], asked, "前の日の問いの画面を戻さず、今の状態で選び直す")

    # ---- 10. 雨の日は散歩に誘わない ----
    def test_no_walk_invite_in_rain(self):
        from nagishima import clock
        for seed, weather in ((23, "clear"), (25, "rain")):
            life = self.life(seed)
            self.to_evening(life)
            life.decline_offers()
            life.go("move.joint.garden")
            state = life.engine.snapshot()["world"]
            self.assertEqual(clock.weather(state["seed"], state["now"] // 1440), weather)  # 準備の確かめ
            seen = []
            for _ in range(5):
                seen += [m for m in meanings(life.engine) if m.startswith("offer.")]
                life.decline_offers()
                life.go("listen")
            if weather == "rain":
                self.assertNotIn("offer.shared.walk", seen)
            else:
                self.assertIn("offer.shared.walk", seen)

    # ---- 7. 朝の「今日のことを話す」 ----
    def test_share_day_in_the_morning(self):
        life = self.life(29)
        life.go("touch.share_day")
        ids = [i for i, m in zip(text_ids(life.engine), meanings(life.engine)) if m.startswith("share_day.")]
        self.assertTrue(ids and ids[0].startswith("o35.share_day."), ids)


if __name__ == "__main__":
    unittest.main()
