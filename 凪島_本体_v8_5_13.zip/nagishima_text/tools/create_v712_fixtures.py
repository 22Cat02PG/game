"""Capture real schema-3 saves from the supplied v7.1.2 checkout."""
import argparse
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    args = parser.parse_args()
    fixture_dir = ROOT / "tests/fixtures"
    for release in ("interaction_007", "interaction_008"):
        for cheated in (False, True):
            with tempfile.TemporaryDirectory(prefix="nagishima-v712-save-") as directory:
                code = ("from nagishima.engine import Engine; "
                        f"e=Engine({directory!r},seed=42,release={release!r},autosave=False,test_cheats={cheated!r}); "
                        + ("e.enable_test_cheat('all'); " if cheated else "") + "e.save('slot01')")
                subprocess.run([sys.executable, "-c", code], cwd=args.base, check=True)
                source = Path(directory) / "saves/slot01.json"
                target = fixture_dir / f"v712_{release}_{'cheat' if cheated else 'normal'}.json"
                target.write_bytes(source.read_bytes())
                print(target.name, target.stat().st_size)


if __name__ == "__main__": main()
