# 段階A 実装報告（v7.0）

作成：Claude Opus 5.5（チャット・高。GPT-6 Sol の使用量切れのため、仕様の作成者が実装も担当した）
仕様：`docs/凪島_段階A_仕様と受入条件_2026-09-24.md`
起点：v6.2（`interaction_006`、rules 2.2、schema 2、133試験）
到達点：v7.0.3（v7.0.2 から README の旧チート名2か所と、配布ツールの既定 ZIP 名・パッケージ ID を修正。Windows 実機検証での指摘による）。v7.0.2（試験の文字コード指定のみ v7.0.1 から変更）。v7.0.1（`interaction_007`、rules `nagishima-2.3`、schema 3、165試験）。v7.0（155試験）に、第7節の反例対応を加えた。

仕様の作成者が実装したため、この報告は独立した監査の代わりになりません。受入の判定は、新しいチャットの Claude Opus 5.5・高 による監査で行ってください。

## 1. 変更したファイル

**新規**
- `nagishima/progression.py`：段階Aの規則（progression.json の検証、生活日、親密度・欲求の計算、うたた寝の予定、状態の検査、節目の不足条件）
- `content/releases/interaction_007/`：006 に progression.json、meaning 5件、仮本文5本を加えたもの。`tools/build_progression_release.py` で生成し、再生成しても差分が出ないことを確認済み
- `tools/build_progression_release.py`、`tools/check_progression_routes.py`
- `tests/test_stage_a.py`（32件。うち10件は Gemini の反例から採用）
- `examples/clear_i007.jsonl`、`examples/clear_i007.expected.json`
- `verification/stage_a_routes.json`
- `docs/凪島_段階A_仕様と受入条件_2026-09-24.md`、この報告

**変更**
- 本体：`__init__.py`（版の定数）、`content.py`（progression.json を任意ファイルとして読込・ハッシュ）、`conditions.py`（条件項目6つ）、`state.py`、`state.schema.json`、`storage.py`（2→3・1→3 の移行）、`life.py`、`context.py`、`scenes.py`、`director.py`、`menus.py`、`engine.py`、`session.py`、`__main__.py`、`autoplay.py`
- ツール：`tools/verify_text.py`（`cleared` で止めて比較する）
- 文書：`README.md`、`docs/テキスト版API.md`、`docs/操作APIと保存.md`、`authoring/condition_fields.json`（`stage_a_fields` を追記。既存の項目は変えていない）
- 検証結果：`verification/` の各結果ファイル（007 で作り直した）

## 2. 試験の結果

| 項目 | 結果 |
|---|---|
| 全試験 | 165件成功（既存133＋段階A 32。v7.0 の時点では155件） |
| `tools/verify_text.py --release interaction_006` | 成功 |
| `tools/verify_text.py --release interaction_007` | 成功（5シードすべて `cleared`、再生一致） |
| `tools/audit_autoplay_immersion.py --release interaction_007 --policy presence --seeds 20` | 成功 |
| `tools/check_progression_routes.py`（A-80） | 30シードすべて `cleared`、2回の実行で操作列と最終状態が一致 |

A-80 の内訳：

| 方式 | シード | 操作数 | 節目の日（1〜4） |
|---|---|---|---|
| 基本 | 0, 1, 42, 20380407, 2147483647 | 136 | 1, 2, 4, 9日目 |
| social | 同上 | 134 | 1, 2, 4, 9日目 |
| presence | 0〜19 | 164 | 1, 2, 4, 9日目 |

実行環境は Linux・Python 3.12 です。Windows と Python 3.10 では未確認です。

## 3. 受入条件と試験の対応

`tests/test_stage_a.py` の試験名は、受入条件の番号で始まります（例：`test_a22_milestone_waits_for_days`）。

- A-01〜A-04、A-10〜A-14、A-20〜A-22、A-30〜A-33、A-40〜A-49、A-50〜A-52、A-60〜A-62、A-70〜A-72、A-81：`tests/test_stage_a.py`
- A-80：`tools/check_progression_routes.py`
- A-82：上の表
- A-73（旧ログの `rules_version_mismatch`）：既存の仕組みのままで、今回は新しい試験を足していません。

**公開経路ではなく、内部状態や関数を直接使って確かめた項目**
- A-22：「日数だけが足りない」状態を作るため、親密度を内部で20にした。判定は公開操作と診断で確認。
- A-48：不正な保存の拒否は、`validate_state` を直接呼んで確認。
- A-04、A-33、A-40：`progression.Rules` を直接使った。

## 4. 仕様書第17節の項目

- **`maho_sleeping` で止めた操作**：行動（actions.json の20行動、`touch.*`）、そばへ寄る（`near`）、真帆の様子を聞く（`listen`／op `idle`）、思い出を話す（op `reminisce`）、話の開始（`begin.*`）、保留した話の再開、活動の開始（`activity.*`）、町への外出、二人の時間の開始（`private.begin`）、同行移動（`move.joint.*`）、物を渡す、共同作業の計画・設置・完成、真帆の誘いの発生。一人での移動、待機、就寝、便り、回想、保存・読込、画面移動、注文、共同作業の取りやめ、約束の延期・取消は選べます。
- **既存の試験の変更**（いずれも第15節で想定した種類）
  - チート名の置き換え：5ファイル。
  - 006 の固定経路の試験2件に `--release interaction_006` を指定した。
  - `test_commander_fixes` の旧セーブを作る部分で、新しい3項目を削除し、チートの記録名を旧名に戻した。
- **自動プレイの方策の変更**：3つの方策の外側に `_progression_step` をかぶせた。真帆がうたた寝していれば起こし、就寝していれば休む。次の節目に必要な親密度か日数が足りない間は、話す3回・活動2回で1日を過ごしてから休む。006 では働かない。
- **親密度が増える箇所の関数**
  - 活動の完了・二人の時間の完了：`life.complete_activity`
  - 約束の履行：`life.resolve_promise`
  - 身の上話の完了：`context.story_complete`
  - 話す・触れる：`context.action`
  - 誘いの承諾：`director.accept_offer`
- **節目の判定を共有する関数**：`Life.milestone_check`。`scenes.begin_scene`、`scenes.resume_scene`、`life.commit_relation` から呼ぶ。
- **ベンチマーク**：`tools/benchmark_runtime.py` は base から作った専用の release を使い、段階Aの規則を含まない。そのため、006 と 007 を比べた数値は出せていない（第6節）。

## 5. 独自判断

1. 段階4の一文 `system.life_continues` は、「節目4の場面の終わりの本文の直後」に出した。仕様第9節は「`relation.4` の直後」としているが、確定の処理は場面の途中で動くため、そこで出した本文は画面に表示されない。試験で見つけて直した。
2. 自動プレイの補助は、007 の数値（親密度5/15/35/60、日数0/1/2/3、話す3回、活動2回、1日10）を直接持つ。progression.json を調整したら、`autoplay.py` の定数も合わせる必要がある。
3. 007 の固定経路は seed 42 専用とした。A-80 では、どのシードでも同じ操作数になったが、誘いがシードで変わりうるため。
4. `authoring/condition_fields.json` には、生成ツールが見つからなかったため、別キー `stage_a_fields` で6項目を追記した。
5. ビルドツールは、Windows でも同じバイト列になるよう、改行を LF に固定した。

## 6. 未解決・仕様の不備

1. 人間向けの「状態」コマンドは、以前から state 全体を JSON で出すため、親密度と欲求が常に見える。仕様第6.4節「通常の画面には出さない」と食い違う。直すかどうかは Opus の判断を待つ。
2. 共同作業の完成（`finish_project`）は、完了の処理を通らないため、親密度が増えない（仕様第6.1節に従い、経路は足していない）。
3. 自動プレイの経路では、うたた寝と就寝が起きない（夜になる前に休むため）。眠りの規則は、受入試験 A-41〜A-49 で確認した。
4. ベンチマークに 007 の測定がない。
5. A-73（旧ログの不一致）の新しい試験はない。
6. Windows（GPT による途中結果、Python 3.12.14）：
   - v7.0 の155試験のうち、A-52 が cp932 で UTF-8 の出力を読んで失敗した（`PYTHONUTF8=1` なら全件成功）。v7.0.2 で A-01・A-52 の subprocess に `encoding="utf-8"` を明示した（既存の試験と同じ書き方）。Linux で ASCII ロケールにして再現し、修正後に通ることを確認した。
   - bundle を Git の標準設定（`core.autocrlf`）で clone すると、旧 release の JSON が CRLF になり、ハッシュ検証で止まる。`core.autocrlf=false` なら不一致0件。配布 ZIP の展開では起きない見込み。
   - `start.bat` と Python 3.10 は未確認。
7. Gemini 3.8（強化版の思考モード）への反例の依頼は、最初の2回（仕様書全文と、状態・睡眠・保存の技術的な抜粋）はどちらも断られた。ユーザーが追加で促した後、13件が出た。判定は第7節。
8. 仮本文5本は検品されていない。原稿の job で差し替える。

## 7. Gemini 3.8 の反例（13件）の判定

Gemini の例の数値のうち、007 の固定値と違うもの（親密度150、欲求の min_stage 2、段階2の下限300）は、そのまま通さず、007 の値（上限100、min_stage 3、下限15）に置き換えて判定した。

| 反例 | 判定 | 結果 |
|---|---|---|
| 1 当日未獲得の集計（day あり・gained 0・counts 空）は有効 | 採用 | 実装は正しい。`test_g01` を追加（値20は有効、150は上限超えで `affinity`） |
| 2 旧版に中立でない値が混入 | 採用・**修正** | 拒否はしていたが、エラーコードがすべて `affinity` だった。仕様第5節どおり `affinity`／`desire`／`maho_sleep` に分けた（`progression.check_state`）。`test_g02` |
| 3 段階が足りないのに欲求がある | 採用 | 実装は正しい。`test_g03`（段階0で欲求50 → `desire`） |
| 4 うたた寝中は主人公の場所を制限しない | 採用 | 実装は正しい。`test_g04` |
| 5 うたた寝の終了時刻ちょうどでは始まらない | 採用 | 実装は正しい（開始 ≦ t < 終了）。`test_g05` |
| 6 主人公が真帆の部屋にいる間は就寝を待つ | 採用 | 実装は正しい。`test_g06`。移動の一覧から真帆の部屋に一人で入る方法はないため、主人公の位置だけ内部状態で準備した |
| 7 起こした直後にまたうたた寝する | 既存の試験で確認済み | A-43 |
| 8 目覚めと就寝を1回の操作でまたぐ | 採用 | 実装は正しい（`maho.woke` → `maho.went_to_bed` の順）。`test_g08` |
| 9 保存・照会・画面移動では眠りの判定をしない | 採用 | 実装は正しい。`test_g09`（時刻は内部状態で準備） |
| 10 止めた選択肢 ID の一覧を返す | 不採用 | その一覧は実装報告の項目で、実行時の機能ではない。選べないことは A-42 で確認済み |
| 11 旧セーブの読込で原稿版を保つ | 既存の試験で確認済み | A-70 |
| 12 保留中の場面があるときの版の切替を拒否 | 採用 | 実装は正しい。`test_g12` |
| 13 版の切替で親密度を段階の下限にする | 採用 | 実装は正しい。`test_g13`（段階3 → 35）。下限300は 007 の上限を超えるので不適用 |

本体の変更は反例2の1件（エラーコードの分割）だけ。g05・g06・g09 は、時刻などの準備に内部状態を使った。
