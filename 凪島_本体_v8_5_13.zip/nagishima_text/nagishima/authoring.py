"""Offline authoring gate. Text jobs cannot add executable operations."""
from copy import deepcopy
from pathlib import Path
import os
import shutil
import tempfile

from .codec import exact, digest, bytes_digest, identifier, read_json, write_json
from .conditions import validate as validate_condition
from .content import FILES, Pack, validate_text
from .errors import ensure

CHECKS = {"outcome", "knowledge", "continuity", "voice", "variation"}


def compile_text(job, draft, reviews, source):
    exact(job, ["id", "source_release", "source_sha256", "meaning", "when", "slots", "group", "required", "forbidden", "reviewers", "min_chars", "max_chars"])
    identifier(job["id"])
    ensure(job["source_release"] == source.id and job["source_sha256"] == source.hash, "job_source", "執筆依頼の参照版が変わっている。")
    ensure(job["meaning"] in source.meanings and set(job["slots"]) <= source.catalog["slots"].keys(), "job", "執筆対象が未登録。")
    validate_condition(job["when"], source.registry.fields)
    ensure(type(job["reviewers"]) is list and job["reviewers"] and len(set(job["reviewers"])) == len(job["reviewers"]), "reviewer", "検品担当を重複なく指定する。")
    for reviewer in job["reviewers"]: identifier(reviewer)
    ensure(type(job["min_chars"]) is int and type(job["max_chars"]) is int and 1 <= job["min_chars"] <= job["max_chars"] <= 16000, "job", "執筆文字数が範囲外。")
    ensure(all(type(v) is list and all(type(s) is str for s in v) for v in (job["required"], job["forbidden"])), "job", "執筆の条件は文字列の一覧にする。")
    exact(draft, ["id", "job_id", "job_sha256", "body"])
    identifier(draft["id"])
    ensure(draft["job_id"] == job["id"] and draft["job_sha256"] == digest(job), "draft_job", "執筆後に依頼が変わっている。")
    ensure(type(draft["body"]) is str and job["min_chars"] <= len(draft["body"]) <= job["max_chars"], "draft_length", "本文が指定文字数を外れている。")
    ensure(type(reviews) is list and len(reviews) == len(job["reviewers"]), "review", "必要な検品記録が不足している。")
    seen = set()
    for review in reviews:
        exact(review, ["job_sha256", "draft_sha256", "reviewer", "verdict", "checks", "notes"])
        ensure(review["reviewer"] in job["reviewers"] and review["reviewer"] not in seen, "reviewer", "未指定または重複した検品担当。")
        seen.add(review["reviewer"])
        ensure(review["job_sha256"] == digest(job) and review["draft_sha256"] == digest(draft), "review_hash", "検品後に依頼か本文が変わっている。")
        ensure(review["verdict"] == "accept" and type(review["checks"]) is dict and set(review["checks"]) == CHECKS and all(v is True for v in review["checks"].values()), "review_rejected", "全検品項目の承認が揃っていない。")
        ensure(type(review["notes"]) is str and 1 <= len(review["notes"]) <= 4000, "review", "検品の根拠を記録する。")
    text = {"id": draft["id"], "meaning": job["meaning"], "when": deepcopy(job["when"]), "slots": list(job["slots"]), "group": job["group"], "body": draft["body"], "fallback": False}
    validate_text(text, source.registry, source.meanings)
    return text


def publish(source, output_root, release_id, bundles, scenes=(), new_meanings=(), base_texts=()):
    """Additions only. Control changes and deletion require a separate migration."""
    identifier(release_id)
    ensure(release_id != source.id, "release_id", "公開済みの版に上書きしない。")
    target = Path(output_root) / release_id
    ensure(not target.exists(), "release_exists", "この公開版は既に存在する。新しい版名を使う。")
    texts = deepcopy(source.texts)
    ledger = []
    for bundle in bundles:
        exact(bundle, ["job", "draft", "reviews"])
        text = compile_text(bundle["job"], bundle["draft"], bundle["reviews"], source)
        ensure(text["id"] not in {t["id"] for t in texts}, "text_duplicate", "既存の本文IDは変更せず、新しいIDを使う。")
        texts.append(text)
        ledger.append(deepcopy(bundle))
    # Scene declarations and their base prose are engineering changes. A separate
    # structural test route is required; the prose job cannot inject them.
    merged_scenes = deepcopy(source.scenes)
    for scene in scenes:
        previous = merged_scenes.get(scene["id"])
        ensure(previous is None or scene["revision"] > previous["revision"], "scene_revision", "場面を変更するときはrevisionを増やす。")
        merged_scenes[scene["id"]] = deepcopy(scene)
    texts.extend(deepcopy(list(base_texts)))
    meanings = sorted(source.meanings | set(new_meanings))
    parent = target.parent
    parent.mkdir(parents=True, exist_ok=True)
    temporary = Path(tempfile.mkdtemp(prefix=".building-", dir=parent))
    try:
        values = [source.catalog, list(source.actions.values()), list(merged_scenes.values()), meanings, texts]
        for filename, value in zip(FILES, values): write_json(temporary / filename, value)
        manifest = {"id": release_id, "rules_version": source.manifest["rules_version"], "files": {name: bytes_digest((temporary / name).read_bytes()) for name in FILES}, "control_sha256": source.control_hash}
        write_json(temporary / "release.json", manifest)
        write_json(temporary / "authoring_ledger.json", ledger)
        Pack(temporary)
        # Same filesystem and destination absent: publish the whole directory once.
        ensure(not target.exists(), "release_exists", "公開先の版が作成されたため中止した。")
        os.rename(temporary, target)
    finally:
        if temporary.exists(): shutil.rmtree(temporary)
    return target
