"""v8.2.8（ユーザー了承 2026-09-28）：限界のあいだも体位は変えられる（入れていないとき）、入り口をこすって焦らす（h_tease）と真帆がねだる一言。
公開の選択肢から確かめる（時刻・高まりなどの準備だけ内部で行う）。"""
import unittest

from tools.build_intimacy_release import back_face_seen
from tools.run_stage_b_routes import Route


def choices(engine):
    return {c["id"]: c for c in engine.get_view()["choices"]}


def meanings(engine):
    return [b["meaning"] for b in engine.get_view()["blocks"]]


def variants(engine):
    return [b["variant"] for b in engine.get_view()["blocks"]]


def explain(engine, identity):
    return engine.get_view()["explanations"].get(identity)


class V828(unittest.TestCase):
    def route(self, *args, **kwargs):
        route = Route(*args, **kwargs)
        self.addCleanup(route.close)
        return route

    def undressed(self, seed, tier, position="h_pos_lying_face", **kwargs):
        route = self.route(seed, tier=tier, day_offset=2, **kwargs)
        route.begin()
        for key in ("h_strip_lower", "h_shift_under", "h_strip_self", position):
            route.action(key)
        return route

    def at_limit(self, seed, tier):
        route = self.undressed(seed, tier)
        for _ in range(20):
            route.action("h_maho_hand")
            if route.engine.snapshot()["intimacy"]["player"]["arousal"] >= 100:
                break
        self.assertEqual(route.engine.snapshot()["intimacy"]["player"]["arousal"], 100)
        route.engine._state["intimacy"]["maho"].update(arousal=60, band="mid")  # 準備：入れられるところまで
        route.engine._install_choices()
        return route

    # ---- 限界のあいだも体位は変えられる ----
    def test_limit_then_missionary_then_insert_finishes_on_entry(self):
        route = self.at_limit(201, "few")
        route.choose("menu.main")
        route.choose("menu.h_position")
        self.assertTrue(choices(route.engine)["touch.h_pos_player_above"]["available"])
        route.choose("touch.h_pos_player_above")
        state = route.engine.snapshot()
        self.assertEqual((state["intimacy"]["position"], state["intimacy"]["player"]["arousal"]), ("player_above", 100))
        self.assertNotIn("h_maho_hand", [c["action_id"] for c in state["contacts"]])  # 手は止めてもらう
        self.assertEqual(meanings(route.engine)[0], "h_limit_move.start")
        self.assertRegex(variants(route.engine)[0], r"^(o16\.h_limit_move\.start\.player_above\.|p8\.h_limit_move\.start\.[a-z_]+\.player_above\.)")  # v8.2.10：第8陣も
        route.choose("menu.main")
        route.choose("menu.h_connect")
        insert = choices(route.engine)["touch.h_insert"]
        self.assertEqual(insert["label"], "ゆっくり入れる（もうこらえきれない）")
        self.assertTrue(insert["available"])
        route.choose("touch.h_insert")
        state = route.engine.snapshot()["intimacy"]
        self.assertEqual((state["inserted"], state["player"]["finishes"], state["mess"]), (True, 1, "inside"))
        self.assertIn("h_overflow.insert", meanings(route.engine))

    def test_limit_then_from_behind_uses_back_texts(self):
        seen = set()
        for seed in range(211, 217):
            route = self.at_limit(seed, "few")
            route.action("h_pos_from_behind")
            block = route.engine.get_view()["blocks"][0]
            self.assertEqual(block["meaning"], "h_limit_move.start")
            self.assertFalse(back_face_seen(block["body"]), block)
            route.action("h_insert")
            found = meanings(route.engine)
            self.assertIn("h_overflow.insert", found)
            body = route.engine.get_view()["blocks"][found.index("h_overflow.insert")]
            self.assertFalse(back_face_seen(body["body"]), body)  # 背を向けた体位では、振り返りなしに顔を書かない
            seen.add(body["variant"].split(".")[0])
        self.assertTrue(seen & {"x6", "o11"}, seen)

    def test_limit_while_inserted_still_blocks_position(self):
        route = self.undressed(221, "few", position="h_pos_player_above")
        route.engine._state["intimacy"]["maho"].update(arousal=60, band="mid")
        route.engine._install_choices()
        route.action("h_insert")
        route.engine._state["intimacy"]["player"]["arousal"] = 100  # 準備：入れたまま限界
        route.engine._install_choices()
        route.choose("menu.main")
        route.choose("menu.h_position")
        self.assertFalse(choices(route.engine)["touch.h_pos_from_behind"]["available"])
        self.assertTrue(explain(route.engine, "touch.h_pos_from_behind").startswith("もう限界だ。"))

    def test_limit_in_back_position_says_change_position(self):
        route = self.at_limit(231, "few")
        route.engine._state["actors"]["maho"]["clothing"]["lower"] = "worn"  # 準備：入れられない服（手でしてもらうだけのとき）
        route.engine._install_choices()
        route.action("h_pos_from_behind")
        route.choose("menu.main")
        route.choose("menu.h_clothes")
        # v8.2.29：限界でも口づけ・愛撫は選べる（背を向けた体位で口づけは体位の手順になる）ので、服の行動の理由で確かめる
        self.assertEqual(explain(route.engine, "touch.h_lift_upper"), "もう限界だ。「こらえる」か、体位を変えて出す。口づけや愛撫はできる。")

    # ---- 入り口をこすって焦らす ----
    def test_tease_needs_few_tier_and_no_insertion(self):
        first = self.undressed(241, "first", position="h_pos_player_above")
        first.choose("menu.main")
        first.choose("menu.h_connect")
        self.assertNotIn("touch.h_tease", choices(first.engine))  # v8.2.19（ユーザー）：回数で開く行為は、開くまで一覧に出さない
        low = self.undressed(243, "few", position="h_pos_player_above")
        low.engine._state["intimacy"]["maho"].update(arousal=10, band="low")  # 準備：真帆はまだ高まっていない
        low.engine._install_choices()
        low.choose("menu.main")
        low.choose("menu.h_connect")
        self.assertFalse(choices(low.engine)["touch.h_tease"]["available"])
        self.assertEqual(explain(low.engine, "touch.h_tease"), "真帆の高まりを待つ。")  # 焦らすのは、真帆が少し高まってから（v8.2.8、読み手の指摘）
        inside = self.undressed(242, "few", position="h_pos_player_above")
        inside.engine._state["intimacy"]["maho"].update(arousal=60, band="mid")
        inside.engine._install_choices()
        inside.action("h_insert")
        inside.choose("menu.main")
        inside.choose("menu.h_connect")
        self.assertFalse(choices(inside.engine)["touch.h_tease"]["available"])

    def test_tease_builds_to_begging_then_deep_insert(self):
        for tier, position in (("few", "h_pos_player_above"), ("familiar", "h_pos_from_behind")):
            route = self.undressed(251, tier, position=position)
            route.engine._state["intimacy"]["maho"].update(arousal=40, band="mid")
            route.engine._install_choices()
            route.action("h_tease")
            self.assertEqual(meanings(route.engine)[0], "h_tease.first")  # v8.2.10：第8陣で初めての本文がそろった
            self.assertTrue(variants(route.engine)[0].startswith("p8.h_tease.first."), variants(route.engine))
            self.assertIn("h_tease", [c["action_id"] for c in route.engine.snapshot()["contacts"]])
            route.choose("menu.main")
            self.assertEqual(choices(route.engine)["touch.h_tease"]["label"], "焦らし続ける")
            self.assertEqual(choices(route.engine)["end.h_tease"]["label"], "焦らすのをやめる")
            begs = 0
            for _ in range(8):
                route.action("h_tease")
                found = meanings(route.engine)
                begs += found.count("h.sign.beg")
                self.assertNotIn("h.sign.high", found)  # ねだる一言が高まりの合図の代わり
            state = route.engine.snapshot()["intimacy"]
            self.assertEqual(begs, 1)
            self.assertTrue(state["begged"])
            self.assertEqual(state["maho"]["arousal"], 85)  # 焦らしだけでは達しない
            self.assertEqual(state["maho"]["climaxes"], 0)
            self.assertLessEqual(state["player"]["arousal"], 50)
            route.action("h_insert_deep")  # ねだられたあとは、一気に奥までも止められない
            state = route.engine.snapshot()
            self.assertTrue(state["intimacy"]["inserted"])
            self.assertNotIn("h_tease", [c["action_id"] for c in state["contacts"]])
            self.assertNotIn("h.deflect.deep", meanings(route.engine))

    def test_tease_right_after_her_climax_is_sensitive(self):
        route = self.undressed(261, "few", position="h_pos_player_above")
        route.engine._state["intimacy"]["maho"].update(arousal=50, band="mid", climaxes=1, climax_source="finger", sensitive=True)
        route.engine._install_choices()
        route.action("h_tease")
        self.assertEqual(meanings(route.engine)[:2], ["h_tease.first", "h.sign.sensitive"])  # v8.2.10：第8陣で初めての本文がそろった

    def test_new_texts_exist_for_every_state(self):
        pack = self.route(271).engine.pack
        positions = [p for p, row in pack.intimacy.positions.items() if row["insertion"]]  # 限界のまま移れるのは入れられる体位（v8.2.10）
        limit = [t for t in pack.by_meaning["h_limit_move.start"] if t["id"].startswith("o16.")]
        covered = {c["value"] for t in limit for c in t["when"]["all"] if c.get("field") == "intimacy.position"}
        self.assertLessEqual(set(positions), covered)
        for phase in ("start", "continue", "settled"):
            for tier in ("few", "familiar"):
                for face in ("face", "back"):
                    self.assertTrue([t for t in pack.by_meaning["h_tease." + phase] if t["id"].startswith(f"o17.h_tease.{phase}.{tier}.{face}.")], (phase, tier, face))
        for tier in ("few", "familiar"):
            for face in ("face", "back"):
                self.assertGreaterEqual(len([t for t in pack.by_meaning["h.sign.beg"] if t["id"].startswith(f"o17.h.sign.beg.{tier}.{face}.")]), 2)


if __name__ == "__main__":
    unittest.main()
