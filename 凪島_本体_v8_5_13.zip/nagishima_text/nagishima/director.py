from copy import deepcopy

from . import clock

from .codec import digest
from .progression import gain_affinity
from .conditions import evaluate
from .errors import ensure, GameError
from .progression import life_day, day_time


class Director:
    def _daily(self, group):
        """1日（暮らしの日）に1回の誘い。B2 の深める触れ合いの反応（gate_）と自動の食事（meal_）もここに入る（検査役G2 L-3）。"""
        return bool(self.pack.life) and (group in self.pack.life.once_per_day or bool(self.pack.intimacy) and group.startswith(("gate_", "meal_", "declined_", "event_")))  # event_：こちらから誘うイベント（晩酌、v8.5.3）

    def can_offer(self, group):
        if self.pack.intimacy and self.pack.life and any(x["group"] == "declined_" + group and x["day"] == life_day(self.now) for x in self.s["cooldowns"]):
            return False  # v8.2.26（ユーザー了承 2026-09-30、精査 B-04）：断られた誘いは、その暮らしの日はもう出さない
        if self._daily(group):
            return not any(x["group"] == group and x["day"] == life_day(self.now) for x in self.s["cooldowns"])
        return not any(x["group"] == group and x["day"] == self.now // 1440 and x["completed_activity_count"] == self.s["progress"]["completed_activities"] for x in self.s["cooldowns"])

    def record_offer(self, group):
        self.s["cooldowns"] = [x for x in self.s["cooldowns"] if x["group"] != group]
        day = life_day(self.now) if self._daily(group) else self.now // 1440
        self.s["cooldowns"].append({"group": group, "day": day, "completed_activity_count": self.s["progress"]["completed_activities"]})

    def goal_target(self, kind):
        if kind == "promise":
            choices = sorted(self.s["promises"], key=lambda x: (x["due_at"], x["id"]))
            return choices[0]["id"] if choices else None
        if kind == "project":
            p = self.s["project"]
            return p["id"] if p and p["status"] not in ("completed", "cancelled") else None
        if kind == "receive":
            return next((x["id"] for x in self.s["orders"] if x["status"] == "delivered"), None)
        if kind == "shared":
            return f"completed.{self.s['progress']['completed_activities']}"
        return None

    def goal_alive(self, goal):
        spec = self.pack.catalog["goals"][goal["kind"]]
        if evaluate(spec["when"], self.values()) is not True:
            return False
        if goal["kind"] == "promise":
            promise = next((p for p in self.s["promises"] if p["id"] == goal["target_id"]), None)
            if promise and self.pack.intimacy and life_day(self.now) < life_day(promise["due_at"]):
                return False  # v8.2.25（精査 B-02）：約束の日（期限の日）になってから誘う。「明日の夜までに」と決めた5分後に「楽しみにしてたんだ」と誘っていた
            return promise is not None
        if goal["kind"] == "receive":
            return any(o["id"] == goal["target_id"] and o["status"] == "delivered" for o in self.s["orders"])
        if goal["kind"] in ("project", "shared"):
            return self.goal_target(goal["kind"]) == goal["target_id"] and goal["target_id"] is not None
        return True

    def update_goal(self):
        if self.pack.life:
            self.s["cooldowns"] = [x for x in self.s["cooldowns"] if (self._daily(x["group"]) and x["day"] == life_day(self.now)) or (not self._daily(x["group"]) and x["day"] == self.now // 1440 and x["completed_activity_count"] == self.s["progress"]["completed_activities"])]
        else:
            self.s["cooldowns"] = [x for x in self.s["cooldowns"] if x["day"] == self.now // 1440 and x["completed_activity_count"] == self.s["progress"]["completed_activities"]]
        if self.s["intention"] and self.goal_alive(self.s["intention"]):
            return
        self.s["intention"] = None
        candidates = []
        for kind, spec in self.pack.catalog["goals"].items():
            goal = {"kind": kind, "reason": spec["reason"], "target_id": self.goal_target(kind), "started_at": self.now}
            if self.goal_alive(goal) and self.can_offer(spec["group"]):
                candidates.append(goal)
        if candidates:
            goal = min(candidates, key=lambda g: (-self.pack.catalog["goals"][g["kind"]]["priority"], g["kind"] == self.s["last_goal"], digest([self.s["world"]["seed"], self.s["world"]["rng"]["director"], g["kind"]])))
            self.s["world"]["rng"]["director"] += 1
            self.s["intention"] = goal
            self.s["last_goal"] = goal["kind"]

    def recently_done(self, activity):
        """v8.2.25（精査 B-03、確かめ役 B N1・N2）：同じ活動を少し前（drinks.min_interval_minutes の間、同じ暮らしの日）に終えたか。
        009 では、終えたばかりの活動に誘わない（shared・care・約束の誘い）。"""
        recent = [m["at"] for m in self.s["memories"]["recent"] if m["kind"] == activity and life_day(m["at"]) == life_day(self.now)]
        return bool(recent) and self.now - max(recent) < self.pack.life.drink_interval

    def offer_plan(self, kind):
        if kind == "shared" and self.pack.life:
            row = next((row for row in self.pack.life.shared_by_time if row[0] <= day_time(self.now) <= row[1]), None)
            ensure(row is not None, "offer", "この時間に一緒にできることがない。")
            for activity in row[2]:
                # v8.2.25（精査 B-03）：お茶だけでなく、同じ活動を少し前（drinks.min_interval_minutes の間）に終えたばかりなら誘わない
                # （「本を読む」を終えた直後に「隣で本を読む時間にしない？」と誘っていた）。009 だけ。
                if (activity in self.pack.life.drink_activities or self.pack.intimacy) and self.recently_done(activity):
                    continue
                if activity in self.pack.life.not_in_rain and clock.weather(self.s["world"]["seed"], self.now // 1440) == "rain":
                    continue  # v8.2.26：雨の日は散歩に誘わない（自分で選ぶのはできる）
                plan = {"op": "activity.begin", "kind": activity}
                preview = type(self)(deepcopy(self.s), self.pack, self.repo, self.old_frame, self.test_cheat_intimacy)
                preview.s["offer"] = None
                try:
                    preview.apply(plan)
                    preview.finalize()
                except GameError:
                    continue
                return plan
            raise GameError("offer", "この時間に一緒にできることがない。")
        if kind == "promise":
            goal = self.s["intention"]
            ensure(goal and goal["kind"] == kind, "offer", "誘いの根拠が変わっている。")
            promise = next((x for x in self.s["promises"] if x["id"] == goal["target_id"]), None)
            ensure(promise is not None, "offer", "誘いの約束が残っていない。")
            return {"op": "activity.begin", "kind": promise["kind"], "promise_id": promise["id"]}
        if kind == "project":
            p = self.s["project"]
            ensure(p and p["status"] in ("planned", "ready", "installed"), "offer", "共同作業は荷物の到着を待っている。")
            return {"op": {"planned": "project.order", "ready": "project.install", "installed": "project.finish"}[p["status"]]}
        if kind == "receive":
            identity = self.goal_target("receive")
            ensure(identity is not None, "offer", "受け取る荷物がない。")
            return {"op": "order.receive", "id": identity}
        return deepcopy(self.pack.catalog["offers"][kind]["plan"])

    def open_offer(self, kind, group, accept_action="offer.accept", decline_action="offer.decline"):
        self.require_awake()
        ensure(not self.s["scene"] and not self.s["offer"] and self.values()["together"], "question", "問いがある間や別の場所では誘えない。")
        ensure(kind in self.pack.catalog["offers"] and self.can_offer(group), "offer", "この誘いは今は繰り返さない。")
        meaning = "offer.shared." + self.offer_plan(kind)["kind"] if self.pack.life and kind == "shared" else "offer." + kind
        self.s["offer"] = {"id": self.new_id("offer"), "kind": kind, "cooldown_group": group, "source_goal": self.s["intention"]["kind"] if self.s["intention"] else None, "started_at": self.now, "accept_action": accept_action, "decline_action": decline_action}
        self.s["interaction_streak"] = None
        if self.pack.life and group in self.pack.life.once_per_day:
            self.record_offer(group)
        self.emit(meaning)

    def accept_offer(self):
        offer = self.s["offer"]
        ensure(offer is not None, "offer", "返事を待つ誘いがない。")
        plan = self.offer_plan(offer["kind"])
        gain_affinity(self.s, self.pack.progression, "offer_accepted")
        self.record_offer(offer["cooldown_group"])
        self.s["offer"] = None
        self.s["intention"] = None
        self.apply(plan)

    def decline_offer(self):
        offer = self.s["offer"]
        ensure(offer is not None, "offer", "返事を待つ誘いがない。")
        self.record_offer(offer["cooldown_group"])
        if self.pack.intimacy and self.pack.life:
            # v8.2.26（精査 B-04）：断った誘いを、活動を一つ終えるたびに初めてのように繰り返していた（好きな飲み物の話など）
            self.record_offer("declined_" + offer["cooldown_group"])
        self.s["offer"], self.s["intention"] = None, None
        self.emit("offer.declined")

    def boundary(self):
        if self.s["maho_sleep"]["state"] != "awake":
            return  # A sleeping Maho forms no new wish or offer; an existing wish is kept.
        if self.s.get("sleep_play") or self.s.get("event_play") or self.s.get("co_sleep") or self.s.get("ask_play"):
            # 段階C（010、v8.5.9）：寝込み・イベント・添い寝（v8.5.10：してもらっている）の最中は誘わない（finalize と同じ）。場面を終えた手の finalize で台所の支度（イベント）が
            # 始まった直後に、真帆の誘いが重なって状態の確かめで止まっていた（いつもの通し daily_1 の game 20）
            return
        # An intention persists during a question; it never creates a second one.
        self.update_goal()
        goal = self.s["intention"]
        if not self.allow_offer or not goal or self.s["scene"] or self.s["offer"] or self.s["mode"] != "normal" or not self.values()["together"]:
            return
        if self.at_work():
            return  # 009：仕事の時間の中では、真帆は誘わない（v8.0.5、検査役G G-02）
        if self.pack.intimacy and self.minutes_to_work(self.pack.life.go_ahead) is not None:
            return  # 009：仕事の前（始まりの1時間前から）は、休憩やお茶に誘わない（v8.1.0、3回目の試運転の指摘1）
        if self.pack.intimacy:
            # In 009, a persistent daily goal may be impossible in the current
            # room. Try the next eligible goal so it cannot mask an invitation.
            candidates = []
            for kind, spec in self.pack.catalog["goals"].items():
                candidate = {"kind": kind, "reason": spec["reason"], "target_id": self.goal_target(kind), "started_at": self.now}
                if self.goal_alive(candidate) and self.can_offer(spec["group"]):
                    candidates.append(candidate)
            candidates.sort(key=lambda candidate: (-self.pack.catalog["goals"][candidate["kind"]]["priority"], candidate["kind"] == self.s["last_goal"], digest([self.s["world"]["seed"], self.s["world"]["rng"]["director"], candidate["kind"]])))
            for candidate in candidates:
                spec = self.pack.catalog["goals"][candidate["kind"]]
                preview = type(self)(deepcopy(self.s), self.pack, self.repo, self.old_frame, self.test_cheat_intimacy)
                preview.s["intention"] = candidate
                try:
                    plan = preview.offer_plan(spec["offer"])
                    if plan["op"] == "activity.begin" and self.pack.life and self.recently_done(plan["kind"]):
                        continue  # v8.2.25（確かめ役 B N1・N2）：静かに休むを終えた直後の「少し、静かに休まない？」、お茶の直後の約束のお茶
                    preview.apply(plan)
                    preview.finalize()
                except GameError:
                    continue
                self.s["intention"] = candidate
                self.s["last_goal"] = candidate["kind"]
                self.open_offer(spec["offer"], spec["group"])
                return
            return
        spec = self.pack.catalog["goals"][goal["kind"]]
        if not self.can_offer(spec["group"]):
            return
        # Use the same transaction handler as the player's direct choice.
        preview = type(self)(deepcopy(self.s), self.pack, self.repo, self.old_frame, self.test_cheat_intimacy)
        try:
            preview.apply(preview.offer_plan(spec["offer"]))
            preview.finalize()
        except GameError:
            return
        self.open_offer(spec["offer"], spec["group"])
