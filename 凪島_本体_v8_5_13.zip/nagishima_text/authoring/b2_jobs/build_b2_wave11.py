"""v8.2.14（ユーザー 2026-09-28 13:18「grokに頼みたいのがあれば依頼置いといて」）の grok への依頼（Opus）。

- 第11陣（p11.、標準）と濃い版（x10.）：真帆に動いてもらう（h_maho_move：初めて・始め・続け・さらに続け、限界、こらえる）、
  頭をなでる（h_stroke_head の場面ごと）、撫で返し（h.stroke_back）、いつもの時間の頭を撫でる（head.start・head.continue の恋人の本文）。
- 第12陣（p12.、標準）と濃い版（x11.）：続けている行為の速さ（v8.2.13。<行為>.pace_fast・pace_slow と <行為>_fast.continue・_slow.continue）。
どの場面にも Opus の本文（opus_texts_009.json の o27〜o30）がすでにある。「もとの速さに戻す」（pace_normal）は、出る回数が少ないので頼まない。
出力：grok_b2_wave_11.json・grok_b2_wave_x10.json・grok_b2_wave_12.json・grok_b2_wave_x11.json、grok依頼_B2_第11陣/・grok依頼_B2_第12陣/、第11陣_一覧.json・第12陣_一覧.json
"""
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
PROMPT = (OUT / "grokプロンプト_v3_0.txt").read_text(encoding="utf-8")
BED = "二人の個室のどちらか（どちらの部屋か、ベッドの上かどうかは書かない）"
TIER = {"few": "数回（2〜5回目）", "familiar": "慣れ（6回目以降）", "few_familiar": "数回か慣れ（2回目以降）",
        "any": "何回目かは書かない（初回でも慣れていても読める本文。台詞の語は初回の語だけを使う）"}
TIER_WHEN = {"few": [{"field": "intimacy.tier", "op": "eq", "value": "few"}], "familiar": [{"field": "intimacy.tier", "op": "eq", "value": "familiar"}],
             "few_familiar": [{"field": "intimacy.tier", "op": "in", "value": ["few", "familiar"]}], "any": []}
CLOTHES_IN = "真帆の下は脱いでいるか、ずらしてある（服について書かない）。こちらは下を脱いでいる"
NO_KISS = {"field": "contact.h_kiss_deep.active", "op": "eq", "value": False}
KISSING = {"field": "contact.h_kiss_deep.active", "op": "eq", "value": True}
BAND = {"low": {"field": "intimacy.maho.band", "op": "in", "value": ["low", "mid"]}, "high": {"field": "intimacy.maho.band", "op": "in", "value": ["high", "near"]}}
BAND_STATE = {"low": "高まりはまだ控えめ", "high": "かなり高まっている（まだ達していない）"}
FACING = {k: {"field": "intimacy.facing", "op": "eq", "value": k} for k in ("face", "back")}
INSIDE_MUST = "妊娠・避妊に触れる。台詞で「待って」「止まって」と言う（止める意味に読める）。「出てる」のような実況の台詞。真帆が出すことを促す・許す台詞（「出して」「いいよ」「大丈夫」）"
waves = {"11": ([], []), "12": ([], [])}


def add(wave, meaning, tier, s, text, state, must_not, length="100〜160字", dense=False, origin="主人公", when=(), tag=None, symbols=None, count=5):
    std_prefix, dense_prefix = {"11": ("p11", "x10"), "12": ("p12", "x11")}[wave]
    prefix = dense_prefix if dense else std_prefix
    identity = ".".join([prefix, meaning, tier] + ([tag] if tag else []) + [s])
    row = {"id": identity, "meaning": text, "speech": s == "s", "length": length, "origin": origin, "candidates": count, "state": dict(state),
           "_wave": "B2-" + prefix.lstrip("p") if not dense else "B2-" + prefix, "_meaning": meaning, "_split": {"tier": tier, "position": None, "other": tag},
           "when": {"all": TIER_WHEN[tier] + list(when)}, "group": "b." + meaning, "must_not": must_not}
    if dense:
        row["style"] = "explicit"
        listed = " ".join(symbols)
        row["state"]["描写"] = f"濃い：性器・体液・体の反応を具体的に、露骨に書く（記号 {listed} を積極的に使う。擬音も使ってよい）"
        row["length"] = {"60〜120字": "80〜150字", "80〜140字": "100〜170字", "100〜160字": "120〜200字"}.get(length, length)
        if "{nipple}" in symbols:  # 読み手の指摘 G-10：上の服は決まっていない（これまでの濃い版の NIPPLE_NOTE と同じ）
            row["state"]["服"] += "。真帆の上の服は、着ているかめくれているか決まっていない（{nipple}・乳輪・胸の肌を直接書くのは、5本のうち2本まで）"
    std, rich = waves[wave]
    assert not any(r["id"] == identity for r in std + rich), identity
    (rich if dense else std).append(row)


# ======== 第11陣 ========
# ---- 真帆に動いてもらう（h_maho_move：真帆が上の体位で入れているとき。数回から。背を向けて乗るのは慣れから） ----
FACE_TOP = "真帆がこちらにまたがり、向かい合っている（こちらが仰向けか、座っているかは書かない）"
BACK_TOP = "仰向けのこちらに、真帆が背を向けてまたがっている"
BACK_FACE = "真帆の顔は見えない（背中・腰・お尻・うなじは見える。肩越しに振り返るときだけ、横顔を書いてよい）"
MOVE = {"face": (FACE_TOP, None, ("few", "familiar"), ["{penis}", "{vagina}", "{love_juice}", "{breasts}", "{nipple}"]),
        "back": (BACK_TOP, BACK_FACE, ("familiar",), ["{penis}", "{vagina}", "{love_juice}"])}
MOVE_MUST = "こちらが下から突き上げる・腰を動かす（動くのは真帆だけ）。真帆が達する。こちらが出す。体位を変える。抜く。入れる（もう入っている）。妊娠・避妊に触れる"
SETTLED = "動き続けて、息が上がっている（真帆が達したかどうかは書かない）"  # 読み手の指摘 G-12
MOVE_MAHO = {"first": "自分で動くのは初めて。戸惑い、恥ずかしがりながら、ぎこちなく動く",
             ("start", "few"): "少し照れながら応じる", ("start", "familiar"): "慣れていて、自分から楽しむように動く",
             ("continue", "few"): "照れながらも、動くことに夢中になってきている", ("continue", "familiar"): "こちらの反応を見ながら、自分の好きなように動いている",
             ("settled", "few"): SETTLED, ("settled", "familiar"): SETTLED}
# 背を向けて乗るのは、淫乱度が控えめなうちは照れ、上がってからは大胆（v8.2.14 の設計、Opus の o29 と同じ。読み手の指摘 G-9）
BACK_LEWD = {("start", "shy"): "背を向けて乗って動くのには、まだ照れが残る（見られるのを恥ずかしがる）",
             ("start", "bold"): "慣れていて、自分から楽しむように動く",
             ("continue", "shy"): "照れながらも、動くことに夢中になってきている（見られているのを気にしている）",
             ("continue", "bold"): "こちらの反応を感じながら、自分の好きなように動いている"}
LEWD = {"shy": {"field": "intimacy.lewd_band", "op": "in", "value": ["shy", "open"]}, "bold": {"field": "intimacy.lewd_band", "op": "in", "value": ["eager", "bold"]}}
for facing, (pose, face, tiers, symbols) in MOVE.items():
    base = {"場所": BED, "体位": pose, **({"顔": face} if face else {}), "服": CLOTHES_IN, "挿入": "している"}
    for s in ("s", "n"):
        add("11", "h_maho_move.first", "few_familiar" if facing == "face" else "familiar", s,
            "入れたまま、上になっている真帆に、自分で動いてほしいと頼む。真帆は戸惑いながら、ぎこちなく腰を動かしはじめる"
            + ("（真帆の台詞は驚きや照れから入ってよい。5本を同じ台詞にしない）" if s == "s" else "（台詞は書かない）"),
            {**base, "慣れ": TIER["few_familiar" if facing == "face" else "familiar"], "真帆": MOVE_MAHO["first"]}, MOVE_MUST,
            when=[FACING[facing]] + ([NO_KISS] if s == "s" else []), tag=facing)  # 口づけは真帆に動いてもらっても途切れない（読み手の指摘 G-5）
    for tier in tiers:
        for phase, text in (("start", "上になっている真帆に動いてほしいと頼み、真帆が腰を動かしはじめる"), ("continue", "真帆がこちらの上で、腰を動かし続ける"),
                            ("settled", "真帆がこちらの上で動き続け、二人とも高まっている")):
            splits = [(None, MOVE_MAHO[(phase, tier)], [])]
            if facing == "back" and phase != "settled":
                splits = [(lewd, BACK_LEWD[(phase, lewd)], [LEWD[lewd]]) for lewd in ("shy", "bold")]
            for lewd, maho, lewd_when in splits:
                state = {**base, "慣れ": TIER[tier], "真帆": maho}
                if phase != "start":
                    state["続いている動作"] = "前の本文から、真帆がこちらの上で腰を動かしている"
                tag = facing + ("." + lewd if lewd else "")
                for s in (("n",) if phase == "settled" else ("s", "n")):
                    when = [FACING[facing]] + lewd_when + ([NO_KISS] if s == "s" else [])
                    add("11", "h_maho_move." + phase, tier, s, text, state, MOVE_MUST, when=when, tag=tag)
                    add("11", "h_maho_move." + phase, tier, s, text, state, MOVE_MUST, when=when, tag=tag, dense=True, symbols=symbols)
    tier = "few_familiar" if facing == "face" else "familiar"
    for s in ("s", "n"):
        # 限界でこちらが動いていたあと、はじめて真帆に動いてもらったときにも出る（読み手の指摘 G-4）
        state = {**base, "慣れ": TIER[tier], "続いている動作": "真帆がこちらの上で腰を動かしていたか、この本文で動きはじめる（どちらかは書かない。真帆の動きの慣れ・ぎこちなさは決めない）",
                 "主人公": "もう限界だった（出すと決めてはいない）"}
        overflow_must = INSIDE_MUST + "。出すと自分で決めたように書く。こちらが突き上げる。真帆が達する（達したときは次の本文で書く）"
        overflow_text = "限界だったところへ真帆の腰が動いて、こらえきれずに真帆の中で果てる"
        add("11", "h_overflow.maho_move", tier, s, overflow_text, state, overflow_must, when=[FACING[facing]] + ([NO_KISS] if s == "s" else []), tag=facing)
        add("11", "h_overflow.maho_move", tier, s, overflow_text, state, overflow_must, when=[FACING[facing]] + ([NO_KISS] if s == "s" else []), tag=facing,
            dense=True, symbols=symbols + ["{semen}"])
        add("11", "h_endure.maho_move", tier, s, "限界の手前で、真帆に動きを止めてもらって、こらえる（出さない）",
            {**base, "慣れ": TIER[tier], "続いている動作": "前の本文から、真帆がこちらの上で腰を動かしていた（この本文で真帆が止まる）", "主人公": "もう限界だった。出すと決めてはいない"},
            "出す・果てる。抜く。真帆が台詞で出すことを促す。体位を変える。真帆が達する。妊娠・避妊に触れる", "60〜120字",
            when=[FACING[facing]] + ([NO_KISS] if s == "s" else []), tag=facing)

# ---- 頭をなでる（h_stroke_head：場面は仕組みが決める。真帆の高まりで書き分け） ----
STROKE_NOTE_MUST = "こちらが、真帆の頭を撫でる以外のことをする（キス・ほかの愛撫・こちらが腰を動かす）。体位を変える。真帆が達する。こちらが出す"  # 読み手の指摘 G-3
SCENE_TIER = {"breasts": "few_familiar", "maho_top": "few_familiar", "mouth": "few_familiar"}  # 数回からしか出ない場面（読み手の指摘 G-22）
SCENES = {
    "breasts": ("胸でしてくれている真帆の頭を撫でる。真帆はうれしそうにして、そのあと胸で擦る動きに熱が入る（速く・大きくなる）",
                {"体位": "こちらは仰向けか座っていて、真帆はこちらの脚のあいだにいる（どちらかは書かない）", "服": "真帆の上は脱いでいるか、めくり上げてある（服について書かない）。こちらは下を脱いでいる",
                 "挿入": "していない", "続いている動作": "前の本文から、真帆が胸で挟んで擦っている（この本文でも続く）"},
                "先端を舐める・口に含む。入れる。" + STROKE_NOTE_MUST),
    "hand": ("手でしてくれている真帆の頭を撫でる。真帆はうれしそうにして、そのあと手の動きに熱が入る（速く・強くなる）",
             {"体位": "向かい合っている（寝ているか座っているか、どちらが上かは書かない）", "服": "こちらは下を脱いでいる（真帆の服は書かない）", "挿入": "していない",
              "続いている動作": "前の本文から、真帆が手でしている（この本文でも続く）"},
             "口でする。入れる。" + STROKE_NOTE_MUST),
    "maho_top": ("こちらの上で動いている真帆の頭を撫でる。真帆はうれしそうにして、そのあと腰の動きが激しくなる",
                 {"体位": FACE_TOP, "服": CLOTHES_IN, "挿入": "している", "続いている動作": "前の本文から、真帆がこちらの上で腰を動かしている（この本文でも続く）"},
                 "こちらが突き上げる。抜く。" + STROKE_NOTE_MUST),
    "player_top": ("つながったまま、真帆の頭を撫でる。真帆は安心したり、甘えたりする（真帆が動いている場面ではないので、真帆が激しく動きだすことはない）",
                   {"体位": "向かい合ってつながっている（どちらが上か、寝ているか座っているかは書かない）", "服": CLOTHES_IN, "挿入": "している",
                    "続いている動作": "前の本文から、つながっている（こちらが動いているか、止まっているかは書かない）"},
                   "真帆が自分で腰を動かす・激しくなる。こちらが腰の動きを変える。抜く。" + STROKE_NOTE_MUST),
    "kiss": ("向かい合ったまま、真帆の頭を撫でる。真帆は照れたり、甘えたりする",
             {"体位": "向かい合っている（寝ているか座っているか、どちらが上かは書かない）", "服": "書かない", "挿入": "していない",
              "続いている動作": "口づけはしていない（唇は離れている）。こちらの手が真帆のほかの所に触れているかどうかは決めない"},
             "入れる。こちらのものに触れる・触れられる。" + STROKE_NOTE_MUST),
    # 余韻はこちらが出しただけのときにも立つ（読み手の指摘 G-1）
    "after": ("ひと区切りついたあとの余韻の中で、真帆の頭を撫でる（真帆が達したのか、こちらが出したのかは書かない）",
              {"体位": "向かい合っている（寝ているか座っているか、どちらが上かは書かない）", "服": "書かない", "挿入": "書かない（つながっているかどうかは決めない）"},
              "真帆がまた求める・誘う。真帆が満ち足りたと決める。" + STROKE_NOTE_MUST),
}
AFTER_STATE = {"low": "余韻の中にいる（達したかどうかは書かない）。高まりはまだ控えめ", "high": "体の火照りがまだ強く残っている（達したかどうかは書かない）"}
for scene, (text, extra, must) in SCENES.items():
    for band in ("low", "high"):
        for s in ("s", "n"):
            tier = SCENE_TIER.get(scene, "any")
            state = {"場所": BED, "慣れ": TIER[tier], **extra, "真帆": AFTER_STATE[band] if scene == "after" else BAND_STATE[band]}
            add("11", "h_stroke_head." + scene, tier, s, text, state, must, "80〜140字", when=[BAND[band], NO_KISS], tag=band)
for band in ("low", "high"):
    add("11", "h_stroke_head.kiss", "any", "n", "深く口づけしたまま、真帆の頭を撫でる（口づけは続く。台詞は書かない）",
        {"場所": BED, "慣れ": TIER["any"], "体位": "向かい合っている（寝ているか座っているか、どちらが上かは書かない）", "服": "書かない", "挿入": "書かない（つながっているかどうかは決めない）",
         "続いている動作": "前の本文から、深く口づけしている（この本文でも続く）", "真帆": BAND_STATE[band]},
        "唇を離す・話す。" + STROKE_NOTE_MUST, "80〜140字", when=[BAND[band], KISSING], tag="kissing." + band)
    # 口づけしたまま、つながって撫でる（読み手の指摘 G-18）
    add("11", "h_stroke_head.maho_top", "few_familiar", "n", "深く口づけしたまま、こちらの上で動いている真帆の頭を撫でる。真帆はうれしそうにして、そのあと腰の動きが激しくなる（口づけは続く。台詞は書かない）",
        {"場所": BED, "慣れ": TIER["few_familiar"], "体位": FACE_TOP, "服": CLOTHES_IN, "挿入": "している",
         "続いている動作": "前の本文から、深く口づけしたまま、真帆がこちらの上で腰を動かしている（この本文でも続く）", "真帆": BAND_STATE[band]},
        "唇を離す・話す。こちらが突き上げる。抜く。" + STROKE_NOTE_MUST, "80〜140字", when=[BAND[band], KISSING], tag="kissing." + band)
    add("11", "h_stroke_head.player_top", "any", "n", "深く口づけしたまま、つながった真帆の頭を撫でる。真帆は安心したり、甘えたりする（口づけは続く。台詞は書かない）",
        {"場所": BED, "慣れ": TIER["any"], "体位": "向かい合ってつながっている（どちらが上か、寝ているか座っているかは書かない）", "服": CLOTHES_IN, "挿入": "している",
         "続いている動作": "前の本文から、深く口づけしたまま、つながっている（こちらが動いているか、止まっているかは書かない）", "真帆": BAND_STATE[band]},
        "唇を離す・話す。真帆が自分で腰を動かす・激しくなる。こちらが腰の動きを変える。抜く。" + STROKE_NOTE_MUST, "80〜140字", when=[BAND[band], KISSING], tag="kissing." + band)
    for pace, (text, doing) in {"normal": ("舌で舐めてくれている真帆の頭を撫でる。真帆はうれしそうにして、そのまま口に含みはじめる（台詞は書かない）",
                                            "前の本文から、真帆が舌で舐めている（まだ口に含んでいない）"),
                                 "fast": ("口でしてくれている真帆の頭を撫でる。真帆はうれしそうにして、そのあと、いっそう深く、熱心に咥える（台詞は書かない）",
                                          "前の本文から、真帆が口に含んで愛撫している（この本文でも続く）")}.items():
        add("11", "h_stroke_head.mouth", "few_familiar", "n", text,
            {"場所": BED, "慣れ": TIER["few_familiar"], "体位": "こちらの脚のあいだに、真帆が身をかがめている（真帆の顔と上目づかいは見える）", "服": "こちらは下を脱いでいる（真帆の服は書かない）",
             "挿入": "していない", "続いている動作": doing, "真帆": BAND_STATE[band]},
            "口を離す・話す。飲む。入れる。" + STROKE_NOTE_MUST, "80〜140字", when=[BAND[band], {"field": "intimacy.pace", "op": "eq", "value": pace}],
            tag={"normal": "lick", "fast": "deep"}[pace] + "." + band)
add("11", "h_stroke_head.again", "any", "n", "何度目かに、真帆の頭を撫でる（短い反応だけ。いまの行為はそのまま）",
    {"場所": BED, "慣れ": TIER["any"], "体位": "書かない", "服": "書かない", "挿入": "書かない", "続いている動作": "書かない（いまの行為の様子を書かない）"},
    "真帆の口元・唇・声（口がふさがっていることがある）。行為の速さや動き。体位・服。" + STROKE_NOTE_MUST, "30〜60字（地の文1〜2文）", count=8)

# ---- 撫で返し（抱きしめて休む・こらえるのあと。数回から。向かい合っているとき） ----
for tier in ("few", "familiar"):
    for s in ("s", "n"):
        add("11", "h.stroke_back.after", tier, s, "抱きしめて休んでいると、真帆のほうから、こちらの頭を撫でてくる（いつも撫でてもらうお返し）",
            {"場所": BED, "慣れ": TIER[tier], "体位": "向かい合って抱き合っている（寝ているか座っているかは書かない）", "服": "書かない", "挿入": "書かない（つながっているかどうかは決めない）",
             "真帆": "余韻の中にいる（真帆が達したのか、こちらが出したのかは書かない）", "続いている動作": "前の本文から、こちらが真帆を抱きしめて休んでいる"},
            "こちらの行動（前の本文で書いた）。真帆がまた求める・誘う。体位を変える", "80〜140字")
        add("11", "h.stroke_back.endure", tier, s, "出しそうなのをこらえていると、真帆がこちらの頭を撫でてくる（なだめる・からかう・ほめる）",
            {"場所": BED, "慣れ": TIER[tier], "体位": "向かい合っている（寝ているか座っているか、どちらが上かは書かない）", "服": "書かない", "挿入": "書かない（つながっているかどうかは決めない）",
             "主人公": "限界の手前で、息を詰めてこらえている（前の本文で止めた）"},
            "こちらが出す・果てる。真帆が出すことを促す・許す（「出して」「いいよ」）。行為を再開する。体位を変える。妊娠・避妊に触れる", "80〜140字")

# ---- いつもの時間の頭を撫でる（段階A からある「頭を撫でる」に、エッチをしたことがある恋人の本文） ----
DAILY_MAHO = {"shy": "夜のことを知っている仲だが、撫でられると、ふと思い出して照れる（思い出すのはほのめかしまで。いつの夜かは書かない。昨夜・ゆうべと決めない）",
              "bold": "甘え上手になり、自分から頭を差し出したり、からかったりする（誘いにはしない）"}
DAILY_WHEN = {"shy": ["shy", "open"], "bold": ["eager", "bold"]}
for meaning, text, doing in (("head.start", "真帆の頭を撫でる", None), ("head.continue", "真帆の頭を撫で続ける", "前の本文から、こちらが真帆の頭を撫でている")):
    for band in ("shy", "bold"):
        for s in ("s", "n"):
            state = {"場所": "書かない（どこにいるかは決めない）", "時刻": "書かない（昼でも夜でも読める本文）", "関係": "交際中。エッチをしたことがある（何回かは書かない）", "服": "書かない（いつもの服）", "真帆": DAILY_MAHO[band]}
            if doing:
                state["続いている動作"] = doing
            add("11", meaning, "any", s, text, {k: v for k, v in state.items()},
                "エッチに誘う・夜の約束をする。頭を撫でる以外の触れ合い（キス・抱きしめる）へ進む。夜の行為を具体的に書く。体の部位の語。時刻・部屋・家事を決める",
                "60〜120字", when=[{"field": "intimacy.history_count", "op": "ge", "value": 1}, {"field": "intimacy.lewd_band", "op": "in", "value": DAILY_WHEN[band]}], tag=band)
for rows in waves["11"]:
    for r in rows:
        if r["_meaning"].startswith("head."):
            r["state"].pop("慣れ", None)  # いつもの時間は「関係」で書く（プロンプトの規則）

# ======== 第12陣：速さ ========
# kind：service（真帆にしてもらう。こちらが頼む）・own（こちらがする）・maho_move（真帆に動いてもらう）
FEET_MUST = "足以外（手・口・胸）でする。踏む。真帆が見下す・罵る（からかうのはよい）"
PACE = {
    "h_maho_hand": ("service", "手で扱く", {"体位": "向かい合っている（寝ているか座っているか、どちらが上かは書かない）", "服": "こちらは下を脱いでいる（真帆の服は書かない）", "挿入": "していない"},
                    "真帆が手でしている", "口でする。入れる", ["{penis}"]),
    "h_maho_breasts": ("service", "胸で挟んで擦る", {"体位": "こちらは仰向けか座っていて、真帆はこちらの脚のあいだにいる（どちらかは書かない）",
                                                   "服": "真帆の上は脱いでいるか、めくり上げてある（服について書かない）。こちらは下を脱いでいる", "挿入": "していない",
                                                   "真帆": "真帆は健康的でグラマラスな体型（胸は豊か）"},
                       "真帆が胸で挟んで擦っている", "先端を舐める・口に含む・唇や舌を寄せる。入れる", ["{penis}", "{breasts}", "{nipple}"]),
    "h_maho_feet": ("service", "足でする", {"体位": "こちらは仰向けか座っていて、真帆はこちらの向かいに座り、足をこちらへ伸ばしている（どちらかは書かない）",
                                          "服": "こちらは下を脱いでいる（真帆の服は書かない）", "挿入": "していない"},
                    "真帆が足でしている", FEET_MUST + "。入れる", ["{penis}"]),
    "h_maho_mouth": ("mouth", "口でする", {"体位": "こちらの脚のあいだに、真帆が身をかがめている（真帆の顔と上目づかいは見える）", "服": "こちらは下を脱いでいる（真帆の服は書かない）", "挿入": "していない"},
                     None, "入れる。飲む", ["{penis}"]),
    "h_touch_direct": ("own", "指で直接なぞる・こする", {"体位": "向かい合っている（寝ているか座っているか、どちらが上かは書かない）", "服": "真帆の下は、下着をずらしてあるか脱いでいる（下着について書かない）"},
                       "こちらが指で直接触れている", "指を中に入れる。入れる", ["{vagina}", "{love_juice}", "{clitoris}"]),
    "h_finger_in": ("own", "中に入れた指を動かす", {"体位": "向かい合っている（寝ているか座っているか、どちらが上かは書かない）", "服": "真帆の下は、下着をずらしてあるか脱いでいる（下着について書かない）"},
                    "こちらが中に入れた指を動かしている", "指以外を入れる。指を抜く", ["{vagina}", "{love_juice}", "{clitoris}"]),
    "h_player_mouth": ("own", "舌で舐める", {"体位": "横になった真帆の脚のあいだに、こちらが顔を寄せている", "服": "真帆の下は、下着をずらしてあるか脱いでいる（下着について書かない）", "挿入": "していない"},
                       "こちらが口で愛撫している", "指を入れる。入れる。こちらの体を書く", ["{vagina}", "{love_juice}", "{clitoris}"]),
    "h_face_lick": ("own", "下から舐める", {"体位": "こちらは仰向けで、真帆がこちらの顔にまたがって膝をついている。真帆はこちらの頭のほうを向いている（見上げると、真帆の体と顔が上にある）",
                                         "服": "真帆の下は脱いでいるか、ずらしてある（服について書かない）。こちらの服は書かない", "挿入": "していない"},
                    "こちらが下から舐めている", "真帆がこちらのものを口にする。入れる", ["{vagina}", "{love_juice}", "{clitoris}"]),
    "h_sumata": ("own", "脚のあいだにこすりつける", {"体位": "書かない（向かい合っているか、背を向けているか、どちらが上かは決めない）", "服": CLOTHES_IN, "挿入": "していない（この本文でも入れない）"},
                 "こちらが真帆の脚のあいだにこすりつけている",
                 "入れる・入れかける（先端が中へ沈みかける）。真帆が脚や腿を閉じて挟む。真帆が自分から腰を沈めて入れる。真帆の顔・目・唇を書く（背を向けていることがある）",
                 ["{penis}", "{vagina}", "{love_juice}", "{clitoris}"]),
    "h_sixty_nine": ("sixty_nine", "舐める舌", {"体位": "こちらは仰向けで、真帆が逆向きにこちらへ重なり、互いの脚のあいだに顔を寄せている",
                                            "顔": "真帆の顔は見えない（声・息・口の動きは感じられる）", "服": "真帆の下は脱いでいるか、ずらしてある（服について書かない）。こちらは下を脱いでいる", "挿入": "していない"},
                     "互いに舐め合っている", "入れる。口に含んだまま話す（台詞は口を離したときだけ）", ["{penis}", "{vagina}", "{love_juice}", "{clitoris}"]),
}
COMMON_MUST = "真帆が達する。こちらが出す。体位を変える。行為をやめる。妊娠・避妊に触れる"
SERVICE_TEXT = {"pace_fast": "もっと激しくしてほしいと頼み、真帆が{act}のを速く・強くする", "pace_slow": "もっとゆっくりしてほしいと頼み、真帆が{act}のをゆっくり・やわらかくする",
                "fast": "真帆が、激しい調子で{act}のを続けている", "slow": "真帆が、ゆっくりした調子で{act}のを続けている（焦らされるようなもどかしさ）"}
OWN_TEXT = {"pace_fast": "こちらが{act}のを速く・激しくする。真帆がそれに反応する", "pace_slow": "こちらが{act}のをゆっくり・やさしくする。真帆はもどかしがったり、じっくり感じたりする",
            "fast": "こちらが、激しい調子で{act}のを続けている（真帆の反応）", "slow": "こちらが、ゆっくりした調子で{act}のを続けている（真帆の反応。もどかしさ）"}
MOUTH_TEXT = {"pace_fast": ("深く咥えてほしいと頼む。真帆が喉の近くまで深く咥えて、激しく頭を動かす（台詞は書かない）", ("n",)),
              "pace_slow": ("口に含むのをやめて、舌で舐めてほしいと頼む。真帆が唇を離し、舌だけで舐める", ("s", "n")),
              "fast": ("真帆が深く咥えたまま、激しく頭を動かし続けている（台詞は書かない）", ("n",)),
              "slow": ("真帆が口には含まず、舌だけで舐め続けている", ("s", "n"))}
MOUTH_SPEECH = {"s": "（口を離しているので、台詞は言ってよい）", "n": "（台詞は書かない）"}  # 読み手の指摘 G-7
SIXTY_TEXT = {"pace_fast": "こちらが舐める舌を速く・激しくする。真帆の口の動きも応えて激しくなる", "pace_slow": "こちらが舐める舌をゆっくり・じっくりにする。真帆の口の動きも、それに合わせてゆっくりになる",
              "fast": "互いに、激しい調子で舐め合い続けている", "slow": "互いに、ゆっくり、じっくりと舐め合い続けている"}
MOVE_TEXT = {"pace_fast": "もっと激しく動いてほしいと頼み、真帆が腰の動きを速く・大きくする", "pace_slow": "もっとゆっくり動いてほしいと頼み、真帆が腰の動きをゆっくり・深くする",
             "fast": "真帆が、激しい調子で腰を動かし続けている", "slow": "真帆が、ゆっくりした調子で腰を動かし続けている（深く、じっくり）"}
for key, (kind, act, extra, doing, must, symbols) in PACE.items():
    for part in ("pace_fast", "pace_slow", "fast", "slow"):
        meaning = key + "." + part if part.startswith("pace_") else f"{key}_{part}.continue"
        if kind == "mouth":
            text, speeches = MOUTH_TEXT[part]
            doing_now = {"pace_fast": "前の本文から、真帆が口でしている（この本文で深く咥える）", "pace_slow": "前の本文から、真帆が口でしている（この本文で口を離し、舌で舐める）",
                         "fast": "前の本文から、真帆が深く咥えて頭を動かしている", "slow": "前の本文から、真帆が舌だけで舐めている"}[part]
        else:
            table = {"service": SERVICE_TEXT, "own": OWN_TEXT, "sixty_nine": SIXTY_TEXT}[kind]
            text, speeches = table[part].format(act=act), ("n",) if (kind, part) == ("sixty_nine", "fast") else ("s", "n")  # 激しい舐め合いの最中は話せない（G-6）
            doing_now = "前の本文から、" + doing + ("（この本文で速さが変わる）" if part.startswith("pace_") else "（" + {"fast": "激しい調子", "slow": "ゆっくりした調子"}[part] + "のまま）")
        tier = "familiar" if key == "h_maho_feet" else "few_familiar"  # 足は慣れから（読み手の指摘 G-15）
        state = {"場所": BED, "慣れ": TIER[tier], **extra, "続いている動作": doing_now}
        for s in speeches:
            said = text
            if kind == "mouth" and part in ("pace_slow", "slow"):
                said = text + MOUTH_SPEECH[s]
            if (kind, part, s) == ("sixty_nine", "pace_fast", "s"):
                said = text + "（台詞は、真帆が一度口を離したときの短い一言。そのあとまた口にする）"
            # 口づけは指で触れる・素股では途切れない（読み手の指摘 G-5）
            when = [NO_KISS] if s == "s" and key in ("h_touch_direct", "h_finger_in", "h_sumata") else []
            add("12", meaning, tier, s, said, state, must + "。" + COMMON_MUST, when=when)
            if part == "fast":
                add("12", meaning, tier, s, said, state, must + "。" + COMMON_MUST, when=when, dense=True, symbols=symbols)
for facing, (pose, face, tiers, symbols) in MOVE.items():
    tier = "few_familiar" if facing == "face" else "familiar"
    for part in ("pace_fast", "pace_slow", "fast", "slow"):
        meaning = "h_maho_move." + part if part.startswith("pace_") else f"h_maho_move_{part}.continue"
        state = {"場所": BED, "慣れ": TIER[tier], "体位": pose, **({"顔": face} if face else {}), "服": CLOTHES_IN, "挿入": "している",
                 "続いている動作": "前の本文から、真帆がこちらの上で腰を動かしている" + ("（この本文で速さが変わる）" if part.startswith("pace_") else "")}
        for s in ("s", "n"):
            when = [FACING[facing]] + ([NO_KISS] if s == "s" else [])
            add("12", meaning, tier, s, MOVE_TEXT[part], state, MOVE_MUST, when=when, tag=facing)
            if part == "fast":
                add("12", meaning, tier, s, MOVE_TEXT[part], state, MOVE_MUST, when=when, tag=facing, dense=True, symbols=symbols)

# ======== 書き出し ========
NOTE11 = ("\n\nこの依頼は、新しく足した行動の本文です（同じ場面の短い本文はすでにあります）。"
          "「真帆に動いてもらう」（h_maho_move）は、真帆が上の体位で入れているとき、こちらが頼んで真帆に腰を動かしてもらう本文です。動くのは真帆だけで、こちらは突き上げません。"
          "「頭をなでる」（h_stroke_head）は、こちらが真帆の頭を撫でる本文です。真帆は撫でられるのが好きで、うれしさが顔に出ます。"
          "真帆がしてくれている最中（口・胸・手・上で動く）に撫でると、うれしそうにしたあと、していることに熱が入ります（激しくなる）。"
          "口でしてくれている最中は真帆は話せないので、台詞は書かず、喉の奥の声・目・動きで表してください。口づけの最中も台詞は書きません。"
          "「撫で返し」（h.stroke_back）は、真帆のほうからこちらの頭を撫でてくる本文です。"
          "背を向けて乗っている体位では、真帆の顔は見えません（state の「顔」のとおり）。"
          "中で果てる本文では、妊娠・避妊に触れないでください。")
NOTE12 = ("\n\nこの依頼は、続けている行為の「速さ」を変える本文と、変えた速さのまま続ける本文です（同じ場面の短い本文はすでにあります）。"
          "meaning が「….pace_fast」「….pace_slow」の本文は、この本文で速さが変わる本文です（こちらが速さを変えるか、真帆に頼む）。"
          "「…_fast.continue」「…_slow.continue」の本文は、変えた速さのまま続いている本文です（速さは変えない）。"
          "「口でしてもらう」は、速さの代わりに、舌で舐める（ゆっくり）・口に含む（ふつう）・深く咥える（激しく）の3段です。口に含んでいる・咥えているあいだは、真帆は話せません。"
          "シックスナインでは、真帆の顔は見えず、台詞は口を離したときだけです。背を向けて乗っている体位では、真帆の顔は見えません（state の「顔」のとおり）。"
          "真帆にしてもらう行為と「真帆に動いてもらう」の「激しく」は、頭を撫でられて真帆の熱が入ったときにもなります。…_fast.continue の本文では、頼んだから激しいのか、熱が入ったからなのかは書かないでください。")
NOTE_DAILY = ("\n\nこの依頼は、いつもの暮らしの中で、こちらが真帆の頭を撫でる本文です（エッチの場面ではありません。同じ場面の短い本文はすでにあります）。"
              "二人はエッチをしたことがある恋人同士です。性的なことは書かず、照れや甘え方で二人の仲を表してください。夜のことは、思い出して照れる程度のほのめかしまでにしてください。"
              "頭を撫でるのは、これまでもしてきた、ふだんの触れ合いです。")
DENSE_NOTE = ("\nこの依頼は高まりが強い場面で出る「濃い本文」です。標準より露骨に、性器・体液・体の反応を具体的に書いてください（state の「描写」のとおり）。"
              "この依頼に限り、プロンプトの「部位の語と記号は地の文で1本に2つまで」は「4つまで（同じ語・記号は2回まで）」に読み替えてください。擬音も使ってよいです。")
TAIL = "\nそれ以外の規則（台詞の数、慣れの段階の語、地の文で器官を名前で呼ばず記号を使う、記号を台詞に書かない、妊娠・避妊に触れない、must_not）は同じです。"
# 1ファイル70本まで。meaning の切れ目で分け、いつもの時間の本文は別のファイル（読み手の指摘 G-17）。4つ目は id に含む文字（向きで分けるとき）
FILES = {
    "11": [("真帆に動いてもらう", False, ["h_maho_move.first", "h_maho_move.start"], None),
           ("真帆に動いてもらう", False, ["h_maho_move.continue", "h_maho_move.settled"], None),
           ("真帆に動いてもらう・限界とこらえる", False, ["h_overflow.maho_move", "h_endure.maho_move"], None),
           ("頭をなでる", False, ["h_stroke_head.breasts", "h_stroke_head.hand", "h_stroke_head.mouth"], None),
           ("頭をなでる", False, ["h_stroke_head.maho_top", "h_stroke_head.player_top"], None),
           ("頭をなでる", False, ["h_stroke_head.kiss", "h_stroke_head.after", "h_stroke_head.again"], None),
           ("撫で返し", False, ["h.stroke_back."], None),
           ("いつもの時間の頭を撫でる", False, ["head."], None),
           ("濃い本文・真帆に動いてもらう", True, ["h_maho_move.start"], None),
           ("濃い本文・真帆に動いてもらう", True, ["h_maho_move.continue"], None),
           ("濃い本文・真帆に動いてもらう", True, ["h_maho_move.settled", "h_overflow.maho_move"], None)],
    "12": [("速さ・手でしてもらう", False, ["h_maho_hand"], None),
           ("速さ・胸でしてもらう", False, ["h_maho_breasts"], None),
           ("速さ・足でしてもらう", False, ["h_maho_feet"], None),
           ("速さ・口でしてもらう・シックスナイン", False, ["h_maho_mouth", "h_sixty_nine"], None),
           ("速さ・指で直接触れる", False, ["h_touch_direct"], None),
           ("速さ・指を中で動かす", False, ["h_finger_in"], None),
           ("速さ・口で愛撫する", False, ["h_player_mouth"], None),
           ("速さ・下から舐める", False, ["h_face_lick"], None),
           ("速さ・素股", False, ["h_sumata"], None),
           ("速さ・真帆に動いてもらう（向かい合う）", False, ["h_maho_move"], ".face."),
           ("速さ・真帆に動いてもらう（背を向ける）", False, ["h_maho_move"], ".back."),
           ("濃い本文・速さ", True, ["h_maho_hand", "h_maho_breasts", "h_maho_feet", "h_maho_mouth", "h_touch_direct", "h_finger_in"], None),
           ("濃い本文・速さ", True, ["h_player_mouth", "h_face_lick", "h_sumata", "h_sixty_nine", "h_maho_move"], None)],
}
for wave, (std, rich) in waves.items():
    dense_name = {"11": "x10", "12": "x11"}[wave]
    (OUT / f"grok_b2_wave_{wave}.json").write_text(json.dumps(std, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
    (OUT / f"grok_b2_wave_{dense_name}.json").write_text(json.dumps(rich, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
    folder = OUT / f"grok依頼_B2_第{wave}陣"
    folder.mkdir(exist_ok=True)
    for old in folder.glob("*.txt"):
        old.unlink()
    files, placed = {}, []
    for number, (label, dense, prefixes, contains) in enumerate(FILES[wave], 1):
        rows = rich if dense else std
        chunk = [r for r in rows if r["_meaning"].startswith(tuple(prefixes)) and r["id"] not in placed and (contains is None or contains in r["id"])]
        # 前の束で入れた job は入れない（「h_maho_move」の束が速さの束の残りだけを取るように）
        assert chunk and len({r["id"] for r in chunk}) == len(chunk), (wave, number, prefixes)
        placed += [r["id"] for r in chunk]
        lines = [json.dumps({"id": r["id"], "meaning": r["meaning"], "speech": r["speech"], "length": r["length"], "origin": r["origin"], "本数": r["candidates"],
                             "must_not": r["must_not"], "state": r["state"]}, ensure_ascii=False) for r in chunk]
        note = (NOTE_DAILY if prefixes == ["head."] else {"11": NOTE11, "12": NOTE12}[wave]) + (DENSE_NOTE if dense else "")
        assert sum(r["candidates"] for r in chunk) <= 70, (wave, number, sum(r["candidates"] for r in chunk))
        body = ("指示\n"
                f"次の{len(chunk)}件の job を書いてください（段階Bの2版目・第{wave}陣・{label}）。本数は各 job の「本数」のとおりです（合わせて{sum(r['candidates'] for r in chunk)}本）。"
                "speech が true の job は真帆の台詞がちょうど1つ、false の job は台詞なしです。途中で切れそうなら、job の区切りで止めてください。「続けて」と言われたら、止めた job の次から出してください。"
                + note + TAIL + "\n\n[\n  " + ",\n  ".join(lines) + "\n]\n\n" "プロンプト\n" + PROMPT)
        name = f"B2_第{wave}陣_{number:02d}.txt"
        (folder / name).write_text(body, encoding="utf-8")
        files.setdefault(label, []).append({"file": name, "jobs": len(chunk), "本数": sum(r["candidates"] for r in chunk)})
    assert sorted(placed) == sorted(r["id"] for r in std + rich), "どのファイルにも入っていない、または二重に入った job がある"
    listing = {"files": files, "jobs": {"標準": len(std), "濃い版": len(rich), "本数": sum(r["candidates"] for r in std + rich)}}
    (OUT / f"第{wave}陣_一覧.json").write_text(json.dumps(listing, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
    print(wave, json.dumps(listing, ensure_ascii=False))
