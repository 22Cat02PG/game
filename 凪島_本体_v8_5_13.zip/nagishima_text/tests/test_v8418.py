"""v8.4.18（ユーザー 2026-10-07 13:41「進めろ。次があるだろ」）：010 だけ。
本文の再会を減らす 五束目（高まりが high・near のときの反応、様子を聞くの高い答え、息が上がっている時間切れ、額を寄せる）。"""
import unittest
from pathlib import Path

from nagishima.content import Pack

ROOT = Path(__file__).resolve().parents[1]
P009 = Pack(ROOT / "content/releases/interaction_009")
P010 = Pack(ROOT / "content/releases/interaction_010")
NEW = [t for t in P010.texts if t["id"].startswith("cmp.") and any(f".z{n}" in t["id"] for n in range(1, 5))]
HIGH = {"field": "intimacy.maho.band", "op": "in", "value": ["high", "near"]}
PREV = lambda name: {"field": f"flow.prev.{name}", "op": "eq", "value": False}  # noqa: E731


class V8418(unittest.TestCase):
    def test_009_unchanged(self):
        self.assertFalse(any(t["id"].startswith("cmp.") for t in P009.texts))

    def test_high_reactions(self):
        meanings = {t["meaning"] for t in NEW}
        for meaning in ("h_check.start", "h_feel.start", "h_chest_skin.start", "h_chest_mouth.start", "h_ear_neck.start", "h_thigh.start",
                        "h.sign.wants_more", "h.deadline", "h_forehead.start"):
            self.assertIn(meaning, meanings)
        for text in NEW:
            if text["meaning"] != "h_forehead.start":
                self.assertIn(HIGH, text["when"]["all"], text["id"])
                self.assertIn(PREV("end"), text["when"]["all"], text["id"])

    def test_wants_more_is_begging(self):
        flow = P010.intimacy.flow
        for text in NEW:
            if text["meaning"] == "h.sign.wants_more":
                self.assertIn("begging", flow.info(text)[3], text["id"])

    def test_pairs(self):
        self.assertNotIn("cmp.h_check.start.w1caface02.z4cbhigh02", P010.by_text)  # 「今どんな感じか」に手を振るだけ
        self.assertIn("cmp.h_check.start.w1caface01.z4cbhigh02", P010.by_text)
        self.assertNotIn("cmp.h.deadline.x4dlaface01.z1dlbworkhot01", P010.by_text)  # あくびの前半／息が上がっている後半
        self.assertIn("cmp.h.deadline.x1dlaface02.z1dlbworkhot01", P010.by_text)

    def test_forehead_one_sentence(self):
        for text in NEW:
            if text["meaning"] == "h_forehead.start":
                self.assertEqual(text["body"].count("。"), 1, text["id"])

    def test_late_hot(self):
        # 高まりが高いときに先に出す本文に、高まり high・near だけに出す本文も入れる（010 だけ）
        self.assertTrue(P010.intimacy.text_memory["late_hot"])
        self.assertIsNone(P009.intimacy.text_memory)

    def test_side_parts_share_memory(self):
        # 胸の左・右・両方は後半の部品を共有するので、覚える鍵（後半）も同じ
        left = [t for t in P010.texts if t["id"].startswith("cmp.h_chest_skin.side_left.") and t["id"].endswith(".y1clbcalm01")][0]
        right = [t for t in P010.texts if t["id"].startswith("cmp.h_chest_skin.side_right.") and t["id"].endswith(".y1clbcalm01")][0]
        self.assertEqual(P010._memory_keys(left)[1], P010._memory_keys(right)[1])
        self.assertNotEqual(P010._memory_keys(left)[0], P010._memory_keys(right)[0])

    def test_review_fixes(self):
        flow = P010.intimacy.flow
        self.assertIn("end", flow.info({"id": "x", "meaning": "h.deadline", "body": "「……今夜は、ここで、やめる」"})[3])
        self.assertIn("forehead", flow.info({"id": "y", "meaning": "h_forehead.start", "body": "真帆の額へ自分の額をあずける。"})[0])
        self.assertNotIn("cmp.h_check.start.w1caface03.z1cbhigh01", P010.by_text)  # 「痛いところはないか」に「ここにいる」
        self.assertNotIn("p2.h_strip_upper.first.s.v2", P010.by_text)


if __name__ == "__main__":
    unittest.main()
