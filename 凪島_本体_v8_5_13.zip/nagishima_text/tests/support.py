"""Routes that exercise the public UI. Never set relationship/progress directly."""
from nagishima.errors import GameError


def press(engine, identity):
    view = engine.get_view()
    return engine.choose(identity, view["revision"], view["session"])


def dismiss(engine):
    if engine.snapshot()["offer"]: press(engine, "offer.decline")


def page(engine, name):
    dismiss(engine)
    view = engine.get_view()
    if view["question_owner"]: raise AssertionError("finish the current scene first")
    if view["page"] != name:
        if view["page"] != "main": press(engine, "menu.main")
        if name != "main": press(engine, "menu." + name)


def do(engine, name, identity):
    page(engine, name)
    return press(engine, identity)


def activity(engine, kind):
    do(engine, "activities", "activity." + kind)
    press(engine, "scene.finish")
    dismiss(engine)


def promise(engine):
    do(engine, "plans", "begin.promise_tea")
    press(engine, "scene.yes")
    identity = engine.snapshot()["promises"][-1]["id"]
    do(engine, "plans", "fulfil." + identity)
    press(engine, "scene.finish")
    dismiss(engine)
    return identity


def milestone(engine, stage):
    do(engine, "talk", "begin.milestone_" + str(stage))
    press(engine, "scene.yes")


def stage_one(engine):
    do(engine, "talk", "begin.two_cups")
    press(engine, "scene.tea")
    press(engine, "scene.remember")
    activity(engine, "tea")
    milestone(engine, 1)


def stage_two(engine):
    stage_one(engine)
    do(engine, "talk", "begin.workbench_half")
    press(engine, "scene.listen")
    promise(engine)
    milestone(engine, 2)


def stage_three(engine):
    stage_two(engine)
    do(engine, "touch", "near")
    press(engine, "touch.hands")
    activity(engine, "tea")
    milestone(engine, 3)


def stage_four(engine):
    stage_three(engine)
    activity(engine, "quiet")
    for day in range(2):
        do(engine, "main", "sleep")
        promise(engine)
        activity(engine, "quiet")
    milestone(engine, 4)
