"""v8.4.2（ユーザー 2026-10-06 09:09「直していいよ。何度もプレイして違和感のある文章を直してから渡して。」）：010 だけ。
- 後ろからの体位（四つん這い・横向き・うつ伏せ・立って後ろから・背を向けて乗る）で、向かい合う書き方の本文を出さない。
  頭をこちらへ預ける本文は、四つん這い・うつ伏せ・背を向けて乗るでは出さない。
- 減った場面（入れるのを断られる・速さを断られる・引き留める）に、後ろからの体位の本文を足した。
- こちらの片手がふさがっている（手をつなぐ・片腕を引く）あいだ、胸に触れるのは片手（両方は選べない）。
- 上の服を脱ぐ・脱がせるなら、手をつなぐ・片腕を引くを終える。
- 通しプレイで見つけた不自然な本文を直した。"""
import re
import unittest
from pathlib import Path

from nagishima.conditions import evaluate
from nagishima.content import Pack
from tools.run_stage_b_routes import Route

ROOT = Path(__file__).resolve().parents[1]
P009 = Pack(ROOT / "content/releases/interaction_009")
P010 = Pack(ROOT / "content/releases/interaction_010")
BACK = ("from_behind", "side_lying", "prone_back", "standing_back", "reverse_ride")
HEAD_FAR = ("from_behind", "prone_back", "reverse_ride")
HEAD_LEAN = re.compile(r"後頭部(を|が)[^。」]{0,12}(預け|寄せ|寄りかか|当た|擦り寄|こすりつけ|押し当|押し付|押しつけ|もたせ|乗せ|落ち)|(頭|後頭部)(を|が)[^。」]{0,8}こちらの(肩|胸|顎|鎖骨)|こちらの(肩|胸|胸元|鎖骨|顎)(に|へ)[^。」]{0,4}(預け|もたせ|乗せ|寄せ|あずけ)た(頭|後頭部)")
# 向かい合う書き方で、後ろからの体位では出さない本文（代表）
FACE_ONLY = ("b2.h.sign.wants_more.few.s.v2", "b2.h.deflect.fast.few.s.v4", "o5.h.deflect.fast.few.after_climax.s.v3", "b2.h.deflect.insert.few.s.v3",
             "b3.h.deflect.insert.familiar.s.v6", "b1.h.hold_back.first.stamina_0.s.v5", "o6.h.spent.unsatisfied.n.v4")
# 直した言い回し（もう出ない）
GONE = ("めくれた肌へ", "穴を舌先で突いて", "を迷わず含め", "結合の隙間から濡れ", "指がこちらの手を重ねて", "肘を後ろへ引いて", "中まで手が届く", "頬が壁にゆるみ", "腰、受け取れてる", "耳に微笑み", "声の高さを測った")


def values(position, tier="familiar", inserted=True, **extra):
    base = {"intimacy.position": position, "intimacy.facing": "back" if position in BACK else "face", "intimacy.tier": tier, "intimacy.inserted": inserted,
            "together": True, "intimacy.active": True}
    base.update(extra)
    return base


def act(route, key):
    while route.engine.snapshot()["offer"]:
        route.choose("offer.decline")
    route.action(key)


def contacts(route):
    return [c["action_id"] for c in route.engine.snapshot()["contacts"]]


class V842(unittest.TestCase):
    def start(self, seed, tier, position=None):
        route = Route(seed, tier=tier, release="interaction_010", hour=21, day_offset=2)
        self.addCleanup(route.close)
        route.begin()
        for _ in range(10):
            if route.engine.snapshot()["intimacy"]["maho"]["arousal"] >= 50:
                break
            act(route, "h_kiss_deep")
        act(route, "h_lift_upper")
        if position:
            act(route, "h_pos_" + position)
        return route

    def test_009_unchanged(self):
        self.assertIsNone(P009.intimacy.one_hand)
        self.assertEqual(P009.intimacy.action_stops, {})
        self.assertEqual(P010.intimacy.one_hand["while"], ("h_hands", "h_arm_pull_one"))
        self.assertEqual(set(P010.intimacy.action_stops), {"h_strip_upper", "h_strip_self_upper"})
        self.assertFalse(any(t["id"].startswith("v842.") for t in P009.by_text.values()))

    def test_face_texts_not_in_back(self):
        for identity in FACE_ONLY:
            text = P010.by_text[identity]
            tier = "first" if ".first." in identity else "familiar" if "familiar" in identity else "few"
            for position in BACK:
                self.assertIs(evaluate(text["when"], values(position, tier)), False, (identity, position))
            self.assertIsNot(evaluate(text["when"], values("lying_face", tier)), False, identity)  # 向かい合う体位では、まだ出うる

    def test_head_lean_not_where_head_cannot_reach(self):
        found = 0
        for text in P010.by_text.values():
            part = text["meaning"].split(".")[0]
            if text["fallback"] or not (part == "h" or part.startswith("h_")) or part.startswith("h_pos_") or text["id"].startswith(("v840.", "v841.")):
                continue
            if HEAD_LEAN.search(text["body"]):
                found += 1
                for position in HEAD_FAR:
                    for tier in ("few", "familiar"):
                        for inserted in (True, False):
                            self.assertIs(evaluate(text["when"], values(position, tier, inserted, **{"contact.h_hug_pull.active": False})), False, (text["id"], position))
        self.assertGreater(found, 20)

    def test_back_texts_remain(self):
        """減った場面に、後ろからの体位の本文がある（3本以上）。"""
        for meaning, positions, tier, extra in (("h.deflect.insert", ("from_behind", "side_lying"), "few", {"intimacy.inserted": False}),
                                                ("h.deflect.insert", BACK, "familiar", {"intimacy.inserted": False}),
                                                ("h.deflect.fast", ("from_behind", "side_lying"), "few", {"intimacy.maho.climaxes": 0}),
                                                ("h.hold_back", ("from_behind", "side_lying"), "few", {})):
            for position in positions:
                rows = [t for t in P010.by_meaning[meaning] if not t["fallback"] and evaluate(t["when"], dict(values(position, tier), **extra)) is not False]
                self.assertGreaterEqual(len(rows), 2 if position in ("standing_back", "reverse_ride") else 3, (meaning, position, tier))

    def test_one_hand_chest(self):
        route = self.start(8901, "familiar")
        act(route, "h_hands")
        act(route, "h_chest_skin")
        rules = route.engine.pack.intimacy
        state = route.engine.snapshot()
        self.assertEqual(rules.side_of(state, "h_chest_skin"), "left")  # 向き合っていれば、こちらの右手が届く真帆の左胸
        route.choose("menu.main")
        route.choose("menu.h_touch")
        ids = {c["id"] for c in route.engine.get_view()["choices"]}
        self.assertNotIn("side.h_chest_skin.both", ids)
        self.assertIn("side.h_chest_skin.right", ids)
        # 後ろから（横向き）なら右胸
        route = self.start(8902, "few", "side_lying")
        act(route, "h_hands")
        act(route, "h_chest_skin")
        self.assertEqual(route.engine.pack.intimacy.side_of(route.engine.snapshot(), "h_chest_skin"), "right")
        # 手が空いていれば、両方が既定のまま
        route = self.start(8903, "familiar")
        act(route, "h_chest_skin")
        self.assertEqual(route.engine.pack.intimacy.side_of(route.engine.snapshot(), "h_chest_skin"), "both")

    def test_strip_upper_ends_hands(self):
        route = self.start(8904, "familiar")
        act(route, "h_hands")
        self.assertIn("h_hands", contacts(route))
        act(route, "h_strip_upper")
        self.assertNotIn("h_hands", contacts(route))

    def test_move_before(self):
        """速さを変えた直前の速さ（010 だけ）。「速さを一段上げる」本文は、遅いところから上げたときだけ。"""
        self.assertFalse(P009.intimacy.move_before)
        self.assertTrue(P010.intimacy.move_before)
        route = self.start(8905, "familiar")
        for key in ("h_strip_lower", "h_shift_under", "h_strip_self", "h_pos_side_lying", "h_insert", "h_move_slow", "h_move_slow", "h_move_normal", "h_move_fast"):
            act(route, key)
        self.assertEqual(route.engine.snapshot()["intimacy"]["move_before"], "normal")
        act(route, "h_move_normal")
        self.assertEqual(route.engine.snapshot()["intimacy"]["move_before"], "fast")
        up = re.compile(r"速さを[^。」]{0,8}(上げ|速め)|一段速|段上げ")
        for text in P010.by_meaning["h_move_normal.start"]:
            if not text["fallback"] and up.search(text["body"]):
                self.assertIs(evaluate(text["when"], dict(values("side_lying", "familiar"), **{"intimacy.move_before": "fast"})), False, text["id"])

    def test_endure_without_service(self):
        """入れていない・何もしてもらっていないときにこらえると、手を止める本文ではなく h_endure.none。"""
        self.assertNotIn("h_endure.none", P009.meanings)
        route = self.start(8977, "few")
        for key in ("h_strip_lower", "h_strip_self"):
            act(route, key)
        limit = route.engine.pack.intimacy.raw["player"]["arousal_max"]
        for _ in range(30):
            if route.engine.snapshot()["intimacy"]["player"]["arousal"] >= limit:
                break
            act(route, "h_maho_hand")
        act(route, "h_pos_from_behind")
        self.assertEqual(contacts(route), [])
        act(route, "h_endure")
        meanings = [b["meaning"] for b in route.engine.get_view()["blocks"]]
        self.assertIn("h_endure.none", meanings)

    def test_hands_free_and_mouth_facing(self):
        """お茶・読書を始めたら暮らしの触れ合いを終える（010）。口で胸に触れるのは向かい合うときだけ（010）。"""
        self.assertIn("tea", P010.life.hands_free_activities)
        self.assertIn("reading", P010.life.hands_free_activities)
        self.assertNotIn("tea", P009.life.hands_free_activities)
        self.assertEqual(P010.intimacy.action_facings["h_chest_mouth"], ("face",))
        self.assertNotIn("h_chest_mouth", P009.intimacy.action_facings)

    def test_fixed_wording_gone(self):
        for text in P010.by_text.values():
            for phrase in GONE:
                self.assertNotIn(phrase, text["body"], text["id"])

    def test_new_texts(self):
        rows = [t for t in P010.by_text.values() if t["id"].startswith("v842.")]
        self.assertGreaterEqual(len(rows), 16)
        for text in rows:
            self.assertFalse(text["fallback"])
            fields = str(text["when"])
            if text["meaning"] == "h_check.start":  # 抱きしめているあいだに様子を聞く（向かい合う）
                self.assertIn("contact.h_hug.active", fields, text["id"])
                continue
            if text["meaning"] == "h_endure.none":  # 何もしてもらっていないときにこらえる（体位を問わない本文もある）
                continue
            if "'value': True" in fields:  # 両手をつなぐ・両腕を引くの最中の締め切り
                continue
            self.assertIn("intimacy.position", fields, text["id"])  # 後ろからの体位だけ
            self.assertNotRegex(text["body"], r"胸板|鎖骨|見つめ|唇が触れ", text["id"])


if __name__ == "__main__":
    unittest.main()
