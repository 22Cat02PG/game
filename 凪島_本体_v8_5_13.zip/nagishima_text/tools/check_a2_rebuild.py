"""Check byte-for-byte reproducibility of the unpublished 008 release."""
import hashlib
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TARGET = ROOT / "content/releases/interaction_008"
assert TARGET.resolve().is_relative_to(ROOT.resolve())


def hashes():
    return {path.name: hashlib.sha256(path.read_bytes()).hexdigest()
            for path in sorted(TARGET.iterdir()) if path.is_file()}


before = hashes()
result = subprocess.run([sys.executable, str(ROOT / "tools/build_life_release.py"), "--replace-unpublished"],
                        cwd=ROOT, capture_output=True, text=True, encoding="utf-8")
after = hashes()
same = result.returncode == 0 and before == after
record = {"same": same, "file_count": len(before), "before": before, "after": after,
          "builder_exit": result.returncode, "builder_stdout": result.stdout, "builder_stderr": result.stderr}
(ROOT / "verification/a2_rebuild_check.json").write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(f"same={same} files={len(before)} exit={result.returncode}")
if not same:
    raise SystemExit(1)
