"""v8.4.20（ユーザー 2026-10-07 13:41「進めろ。次があるだろ」）：010 だけ。
組み合わせた本文のまとまり（group）を、場面ごとから前半の部品ごとにした（v8420/make_010_v8420.py）。"""
import unittest
from copy import deepcopy
from pathlib import Path

from nagishima.content import Pack
from tools.run_stage_b_routes import Route

ROOT = Path(__file__).resolve().parents[1]
P009 = Pack(ROOT / "content/releases/interaction_009")
P010 = Pack(ROOT / "content/releases/interaction_010")


class V8420(unittest.TestCase):
    def test_009_unchanged(self):
        self.assertFalse(any(t["id"].startswith("cmp.") for t in P009.texts))

    def test_group_per_front_part(self):
        composed = [t for t in P010.texts if t["id"].startswith("cmp.")]
        self.assertGreater(len(composed), 18000)
        for text in composed:
            meaning, front, _ = text["id"][4:].rsplit(".", 2)
            self.assertEqual(text["group"], f"cmp.{meaning}.{front}", text["id"])
        # 前からある本文のまとまりは変えていない
        self.assertTrue(all(not t["group"].startswith("cmp.") for t in P010.texts if not t["id"].startswith("cmp.")))

    def test_same_front_part_is_spread(self):
        """気持ちを伝えるを続けて選ぶ。直前に出た組み合わせた本文と同じ前半の本文は後回しにし、違う前半の組み合わせた本文から選ぶ
        （場面ごとのまとまりのときは、前からある本文に戻っていた）。"""
        route = Route(8461, tier="familiar", release="interaction_010", hour=21, day_offset=2)
        self.addCleanup(route.close)
        route.begin()
        state = deepcopy(route.engine.snapshot())
        state["contacts"] = []
        picks = []
        for _ in range(6):
            chosen = P010.select("h_feel.start", state, {}, P010.registry.values(state))[0]["variant"]
            text = P010.by_text[chosen]
            picks.append(text)
            state["recent_text"].append({"id": chosen, "group": text["group"], "release": P010.id})
        composed = [t for t in picks if t["id"].startswith("cmp.")]
        self.assertGreaterEqual(len(composed), 4, [t["id"] for t in picks])
        for before, after in zip(picks, picks[1:]):
            self.assertNotEqual(before["group"], after["group"])

    def test_review_fixes(self):
        """読む係の指摘（v8420/read）：頭を撫でる場所の仕草の型、前からある部品の条件、つながない組。"""
        flow = P010.intimacy.flow
        top = {"id": "a", "meaning": "h_stroke_head.again", "body": "つむじのあたりを手のひらでくるりと包む。"}
        head = {"id": "b", "meaning": "h_stroke_head.again", "body": "頭のてっぺんに手のひらをのせて撫でる。"}
        self.assertGreater(flow.score([top], head), 0)
        for text in P010.texts:
            if not text["id"].startswith("cmp."):
                continue
            a, b = text["id"].rsplit(".", 2)[1:]
            self.assertNotEqual((a, b), ("w3faface03", "w7fbhot05"))
            if b in ("w7cbmid09", "w7cblow05"):
                self.assertIn({"field": "intimacy.position", "op": "in", "value": ["lying_face", "side_lying", "player_above"]}, text["when"]["all"])
            if a == "w3faface03":
                self.assertIn({"field": "intimacy.maho.band", "op": "ne", "value": "low"}, text["when"]["all"])


if __name__ == "__main__":
    unittest.main()
