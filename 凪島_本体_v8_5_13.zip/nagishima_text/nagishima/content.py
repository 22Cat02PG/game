from collections import Counter, defaultdict
from copy import deepcopy
from pathlib import Path
import json
import hashlib
import re

from . import RULES_VERSION
from .progression import Rules
from .life_rules import LifeRules
from .codec import bytes_digest, digest, exact, identifier, read_json
from .conditions import Registry, typed, validate as validate_condition, evaluate
from .errors import GameError, ensure
from .contracts import catalog_structure, catalog_conditions, declaration, short_id

TOKEN = re.compile(r"\{([a-z_][a-z0-9_]*)\}")
FILES = ("catalog.json", "actions.json", "scenes.json", "meanings.json", "texts.json")
PROGRESSION = "progression.json"  # optional; enables the stage A rules
LIFE = "life.json"  # optional; enables the stage A2 rules
INTIMACY = "intimacy.json"  # optional; enables Stage B only for its release
EFFECT_ARGUMENTS = {
    "local.set": ({"name", "value"}, set()), "local.inc": ({"name", "value"}, set()),
    "action": ({"id"}, {"origin", "lifetime"}), "approach": (set(), set()),
    "fact.set": ({"id", "value"}, set()), "fact.learn": ({"actor", "id"}, set()),
    "story.complete": ({"id"}, set()), "memory.record": ({"kind"}, {"facts", "summary"}),
    "activity.complete": ({"id"}, set()), "relation.commit": ({"stage"}, set()),
    "private.begin": (set(), set()), "private.end": (set(), set()),
    "promise.create": ({"kind"}, set()), "project.finish": (set(), set()),
    "trip.advance": ({"phase"}, set()),
    "memory.capture": ({"kind"}, set()), "anniversary.celebrate": ({"kind"}, set()),
}


def validate_effect(effect, fields, catalog, actions, locals_):
    ensure(type(effect) is dict and effect.get("op") in EFFECT_ARGUMENTS, "effect", "場面の操作が未登録。")
    required, optional = EFFECT_ARGUMENTS[effect["op"]]
    exact(effect, required | {"op"}, optional)
    def refs(value):
        if type(value) is dict and set(value) == {"ref"}:
            ensure(value["ref"] in fields or value["ref"] in ("scene.activity_id", "scene.instance_id"), "effect_ref", "操作の参照先が未登録。")
        elif type(value) is dict:
            for child in value.values(): refs(child)
        elif type(value) is list:
            for child in value: refs(child)
    refs(effect)
    op = effect["op"]
    if op in ("local.set", "local.inc"):
        ensure(effect["name"] in locals_, "effect", "局所値が未登録。")
        value = effect["value"]
        if op == "local.inc":
            ensure(locals_[effect["name"]]["type"] == "int" and type(value) is int, "effect", "加算する型が違う。")
        elif type(value) is not dict:
            typed(value, locals_[effect["name"]])
        else: exact(value, ["ref"])
    elif op == "action":
        ensure(effect["id"] in actions, "effect", "動作が未登録。")
        ensure(effect.get("origin", "player") in ("player", "maho") and effect.get("lifetime", "persistent") in ("persistent", "scene", "private"), "effect", "動作の所有指定が違う。")
    elif op in ("fact.set", "fact.learn"):
        ensure(effect["id"] in catalog["facts"], "effect", "事実が未登録。")
        if op == "fact.set" and type(effect["value"]) is not dict:
            typed(effect["value"], catalog["facts"][effect["id"]]["spec"])
        elif op == "fact.set": exact(effect["value"], ["ref"])
        if op == "fact.learn":
            ensure(effect["actor"] in catalog["actors"], "effect", "人物が未登録。")
    elif op == "story.complete":
        ensure(effect["id"] in catalog["stories"], "effect", "話題が未登録。")
    elif op == "memory.record":
        ensure(effect["kind"] in catalog["memory_kinds"] and set(effect.get("facts", [])) <= catalog["facts"].keys(), "effect", "思い出の参照が未登録。")
        spec = catalog["memory_specs"][effect["kind"]]
        facts, summary = effect.get("facts", []), effect.get("summary", {})
        ensure(type(facts) is list and len(set(facts)) == len(facts) and set(facts) <= set(spec["facts"]) and type(summary) is dict and summary.keys() <= spec["summary"].keys(), "effect", "思い出の内容が宣言と一致しない。")
        for key, value in summary.items():
            if type(value) is dict: exact(value, ["ref"])
            else: typed(value, spec["summary"][key])
    elif op == "relation.commit":
        ensure(type(effect["stage"]) is int and 1 <= effect["stage"] <= 4, "effect", "関係段階が違う。")
    elif op == "promise.create":
        ensure(effect["kind"] in catalog["promise_kinds"], "effect", "約束の用件が未登録。")
    elif op == "trip.advance":
        ensure(effect["phase"] in ("town", "return"), "effect", "外出の区切りが未登録。")
    elif op == "memory.capture":
        ensure(effect["kind"] in catalog["memory_kinds"], "effect", "記憶の種類が未登録。")
    elif op == "anniversary.celebrate":
        ensure(effect["kind"] in ("dating", "life"), "effect", "記念日の種類が未登録。")


def validate_scene(scene, registry, meanings):
    exact(scene, ["id", "revision", "label", "requires", "resume", "locals", "start", "nodes", "replay"], ["activity_kind"])
    short_id(scene["id"])
    ensure(type(scene["label"]) is str and 1 <= len(scene["label"]) <= 60, "scene", "場面名は1〜60文字で指定する。")
    ensure(type(scene["revision"]) is int and scene["revision"] > 0, "scene", "場面の版が違う。")
    ensure(type(scene["replay"]) is bool and len(scene["locals"]) <= 64, "scene", "場面の形式が違う。")
    fields = registry.local_fields(scene["locals"])
    for key, spec in scene["locals"].items():
        identifier(key)
        declaration(spec, default=True)
    for predicate in (scene["requires"], scene["resume"]):
        validate_condition(predicate, registry.fields)
    nodes = {node["id"]: node for node in scene["nodes"]}
    ensure(0 < len(nodes) == len(scene["nodes"]) <= 256 and scene["start"] in nodes, "scene", "場面の区切りが重複・不足・上限超過。")
    edges = {}
    for node in scene["nodes"]:
        exact(node, ["id", "meaning", "join", "enter", "choices", "pause", "interrupt", "micro"], ["end", "auto"])
        identifier(node["id"])
        ensure(node["meaning"] in meanings, "meaning", "本文の意味が未登録。")
        ensure(type(node["pause"]) is bool and node["interrupt"] in ("none", "ambient", "offer"), "scene", "割り込みの形式が違う。")
        ensure(type(node["micro"]) is list and len(set(node["micro"])) == len(node["micro"]) and set(node["micro"]) <= registry.actions.keys(), "scene", "場面内の動作が未登録または重複。")
        held = min(16, len(registry.catalog["resources"]), sum(a["ongoing"] for a in registry.actions.values()))
        controls = (3 if node["pause"] else 1) + 3 + (1 + held + len(node["micro"]) if node["micro"] else 0)
        ensure(len(node["choices"]) + controls <= 32, "choice_limit", "場面の返事と常設操作の合計が32件を超える。")
        ensure(type(node["enter"]) is list and len(node["enter"]) <= 32, "effects_limit", "到着時の操作は32件まで。")
        if "end" in node: ensure(type(node["end"]) is bool, "scene", "endは真偽値で指定する。")
        validate_condition(node["join"], fields)
        for effect in node["enter"]:
            validate_effect(effect, fields, registry.catalog, registry.actions, scene["locals"])
            ensure(effect["op"] != "private.begin" or node.get("end") is True, "transition", "二人の時間への遷移は終了ノードのenterに置く。")
        ensure(len(node["choices"]) <= 12 and len({c["id"] for c in node["choices"]}) == len(node["choices"]), "scene", "選択肢が重複または多すぎる。")
        ensure(sum(bool(x) for x in (node["choices"], node.get("auto"), node.get("end"))) == 1, "scene", "終了・自動・入力の役割が重複または不足。")
        targets = []
        for choice in node["choices"]:
            exact(choice, ["id", "label", "when", "effects", "next"])
            short_id(choice["id"])
            ensure(type(choice["label"]) is str and 1 <= len(choice["label"]) <= 120 and type(choice["effects"]) is list and len(choice["effects"]) <= 32, "scene", "選択肢の表示または操作数が不正。")
            ensure(choice["id"] not in ("pause", "cancel"), "choice_id", "保留・終了の操作IDは予約済み。")
            validate_condition(choice["when"], fields)
            for effect in choice["effects"]:
                validate_effect(effect, fields, registry.catalog, registry.actions, scene["locals"])
                ensure(effect["op"] != "private.begin", "transition", "二人の時間への遷移は終了ノードへ移す。")
            targets.append(choice["next"])
        if node.get("auto"):
            targets.append(node["auto"])
        ensure(set(targets) <= nodes.keys(), "scene_target", "遷移先が存在しない。")
        edges[node["id"]] = targets
    seen, queue = set(), [scene["start"]]
    while queue:
        key = queue.pop()
        if key not in seen:
            seen.add(key)
            queue.extend(edges[key])
    ensure(seen == nodes.keys(), "scene_unreachable", "到達できない区切りがある。")
    endings = {key for key, node in nodes.items() if node.get("end")}
    while True:
        more = {key for key, targets in edges.items() if set(targets) & endings} | endings
        if more == endings:
            break
        endings = more
    ensure(endings == nodes.keys(), "scene_deadlock", "終了へ至る経路がない。")
    for key in nodes:
        visited = set()
        while nodes[key].get("auto"):
            ensure(key not in visited, "scene_cycle", "自動処理だけの循環がある。")
            visited.add(key)
            key = nodes[key]["auto"]


def validate_text(text, registry, meanings, intimacy=None):
    exact(text, ["id", "meaning", "when", "slots", "group", "body", "fallback"], ["style"] if intimacy else [])
    if "style" in text:
        ensure(text["style"] == "explicit", "text", "本文の描写札が未登録。")
    identifier(text["id"])
    identifier(text["group"])
    ensure(text["meaning"] in meanings, "meaning", "本文の意味が未登録。")
    ensure(type(text["body"]) is str and 0 < len(text["body"].strip()) <= 16000, "text", "本文の長さが不正。")
    ensure(type(text["fallback"]) is bool and type(text["slots"]) is list, "text", "本文の形式が違う。")
    validate_condition(text["when"], registry.fields)
    ensure(set(TOKEN.findall(text["body"])) == set(text["slots"]) <= registry.catalog["slots"].keys(), "slots", "差し込みが未登録または不一致。")
    remainder = TOKEN.sub("", text["body"])
    ensure("{" not in remainder and "}" not in remainder, "slots", "差し込みに式は使えない。")
    slot_lengths = {"player_name": 20, "location": 40, "memory_place": 40, "chosen_place": 10, "scene_memory_place": 40}
    if intimacy:
        slot_lengths.update({key: max(map(len, choices)) for key, choices in intimacy.settings["terms"].items()})
        ensure(not any(TOKEN.search(part) for part in dialogue_parts(text["body"])), "slots", "台詞の中に差し込みを使えない。")
    ensure(len(remainder) + sum(slot_lengths[key] for key in TOKEN.findall(text["body"])) <= 16000, "text_length", "差し込み後の本文が16000文字を超える。")
    if text["fallback"]:
        ensure(text["when"] == {"all": []} and not text["slots"], "fallback", "基本本文は無条件・差し込みなしにする。")


def dialogue_parts(body):
    """「」の中の文字列（入れ子と閉じていない「を含む）。v8.0.5、監査 C-02・E-04。"""
    parts, depth, current = [], 0, []
    for char in body:
        if char == "「":
            depth += 1
        elif char == "」" and depth:
            depth -= 1
            if depth == 0:
                parts.append("".join(current))
                current = []
            continue
        if depth:
            current.append(char)
    if current:
        parts.append("".join(current))
    return parts


class Pack:
    def __init__(self, directory):
        try:
            self._load(directory)
        except (KeyError, TypeError, ValueError, AttributeError, IndexError, RecursionError) as error:
            if isinstance(error, GameError): raise
            raise GameError("content_format", "公開版の型・登録・参照が不正。") from error

    def _load(self, directory):
        self.path = Path(directory)
        self.manifest = read_json(self.path / "release.json")
        exact(self.manifest, ["id", "rules_version", "files", "control_sha256"])
        identifier(self.manifest["id"])
        ensure(self.manifest["rules_version"] in {"nagishima-2.1", "nagishima-2.2", "nagishima-2.3", RULES_VERSION}, "rules_version", "この本体に対応しないルールの版。")
        has_intimacy = INTIMACY in self.manifest["files"]
        names = FILES + ((PROGRESSION,) if PROGRESSION in self.manifest["files"] else ()) + ((LIFE,) if LIFE in self.manifest["files"] else ()) + ((INTIMACY,) if has_intimacy else ())
        ensure(set(self.manifest["files"]) == set(names), "release", "公開版のファイルが不足または未登録。")
        data = {}
        for name in names:
            raw = (self.path / name).read_bytes()
            ensure(bytes_digest(raw) == self.manifest["files"][name], "release_hash", "公開版の内容が変わっている。")
            data[name] = read_json(self.path / name, 512 * 1024 * 1024)
        self.catalog = data["catalog.json"]
        catalog_structure(self.catalog, has_intimacy)
        ensure(type(data["actions.json"]) is list and 1 <= len(data["actions.json"]) <= 128 and type(data["scenes.json"]) is list and 1 <= len(data["scenes.json"]) <= 10000 and type(data["texts.json"]) is list, "release", "登録配列の型または件数が不正。")
        self.actions = {a["id"]: a for a in data["actions.json"]}
        self.scenes = {s["id"]: s for s in data["scenes.json"]}
        self.meanings = set(data["meanings.json"])
        ensure(type(data["meanings.json"]) is list and len(self.meanings) == len(data["meanings.json"]), "meaning", "意味の登録が重複または形式違い。")
        for meaning in self.meanings: identifier(meaning)
        self.texts = data["texts.json"]
        self.id = self.manifest["id"]
        self.hash = digest(self.manifest)
        control = {"catalog": self.catalog, "actions": data["actions.json"]}
        if PROGRESSION in data: control["progression"] = data[PROGRESSION]
        if LIFE in data: control["life"] = data[LIFE]
        if has_intimacy: control["intimacy"] = data[INTIMACY]
        self.control_hash = digest(control)
        ensure(self.control_hash == self.manifest["control_sha256"], "release_hash", "行動・状態の宣言が不一致。")
        ensure(len(self.actions) == len(data["actions.json"]) and len(self.scenes) == len(data["scenes.json"]), "release_id", "登録IDが重複している。")
        if has_intimacy:
            ensure(PROGRESSION in data and LIFE in data, "intimacy_data", "intimacy.json には progression.json と life.json が必要。")  # v8.0.5、監査 A-02
        self.progression = Rules(data[PROGRESSION], self.actions) if PROGRESSION in data else None
        try:
            self.life = LifeRules(data[LIFE], self.catalog, self.meanings, self.progression) if LIFE in data else None
        except (KeyError, TypeError, ValueError, AttributeError) as error:
            if isinstance(error, GameError):
                raise
            raise GameError("life_data", "life.json の形式が不正。") from error
        if has_intimacy:
            ensure(self.progression is not None and self.life is not None, "intimacy_data", "intimacy.json には progression.json と life.json が必要。")
            from .intimacy_rules import IntimacyRules
            try:
                self.intimacy = IntimacyRules(data[INTIMACY], self.catalog, self.actions)
            except (GameError, KeyError, TypeError, ValueError, AttributeError) as error:  # v8.0.5、監査 A-01
                raise GameError("intimacy_data", "intimacy.json の形式・値・参照が不正。") from error
        else:
            self.intimacy = None
        # v8.2.37（009）：同じ本文を避ける記録の長さ。設定のない版（006〜008）は 64 のまま、選び方も変えない
        self.recent_window = (self.intimacy.settings.get("recent_text_window") if self.intimacy else None) or 64
        self.registry = Registry(self.catalog, self.actions, self.progression, self.life, self.intimacy)
        for key, definition in self.catalog["facts"].items():
            identifier(key)
            typed(definition["initial"], definition["spec"])
        for action in self.actions.values():
            exact(action, ["id", "label", "ongoing", "min_stage", "near", "resources", "replaces", "keep_on_joint_move", "when", "maintain", "postures"])
            short_id(action["id"])
            ensure(type(action["min_stage"]) is int and 0 <= action["min_stage"] <= 4 and type(action["ongoing"]) is bool and type(action["near"]) is bool, "action", "動作の型が違う。")
            ensure(type(action["label"]) is str and 1 <= len(action["label"]) <= 60 and type(action["keep_on_joint_move"]) is bool and type(action["postures"]) is list and action["postures"] and set(action["postures"]) <= set(self.catalog["postures"]), "action", "動作の表示・移動・姿勢の指定が不正。")
            ensure(type(action["resources"]) is list and action["resources"] and type(action["replaces"]) is list, "resources", "動作には一つ以上の資源を割り当てる。")
            ensure(len(set(action["resources"])) == len(action["resources"]) and set(action["resources"]) <= self.catalog["resources"].keys() and set(action["replaces"]) <= self.actions.keys(), "resources", "動作の資源が不正。")
            validate_condition(action["when"], self.registry.fields)
            validate_condition(action["maintain"], self.registry.fields)
            for phase in (["first", "start", "continue", "settled"] if action["ongoing"] else ["first", "start"]):
                ensure(action["id"] + "." + phase in self.meanings, "meaning", "動作の本文が未登録。")
        for scene in self.scenes.values():
            validate_scene(scene, self.registry, self.meanings)
        catalog_conditions(self.catalog, self.registry, self.scenes)
        if self.intimacy and self.intimacy.sleep_play:
            self.intimacy.sleep_play.check_content(self.registry.fields, self.meanings, validate_condition)  # 段階C（010）：寝込みの条件と本文の意味
        if self.intimacy and self.intimacy.events:
            ensure(self.life is not None and self.life.bath, "intimacy_data", "浴室のイベントには風呂の決まりが要る。")
            self.intimacy.events.check_content(self.registry.fields, self.meanings, validate_condition)  # 段階C（010、v8.5.1）：イベントの条件と本文の意味
        if self.intimacy and self.intimacy.co_sleep:
            ensure(self.intimacy.sleep_play is not None, "intimacy_data", "添い寝には寝込みの決まりが要る。")
            self.intimacy.co_sleep.check_content(self.registry.fields, self.meanings, validate_condition)  # 段階C（010、v8.5.6）：添い寝の条件と本文の意味
        if self.intimacy and self.intimacy.self_entry:
            validate_condition(self.intimacy.self_entry["decline_when"], self.registry.fields)  # 段階C（010、v8.5.8）：自分で高める入口
            missing = [m for m in ("h.self_entry.begin", "h.self_entry.decline") if m not in self.meanings]
            ensure(not missing, "meaning", "自分で高める入口の本文の意味が未登録：" + "、".join(missing))
        if self.intimacy and self.intimacy.nap:
            self.intimacy.nap.check_content(self.registry.fields, self.meanings, validate_condition)  # 段階C（010、v8.5.7）：うたた寝の条件と本文の意味
        if self.intimacy and self.intimacy.ask:
            self.intimacy.ask.check_content(self.registry.fields, self.meanings, validate_condition, self.catalog)  # 段階C（010、v8.5.10）：頼むの条件と本文の意味
        from .budget import estimate
        self.save_budget = estimate(self.catalog, self.actions)
        self.by_meaning = defaultdict(list)
        self.by_text = {}
        fallback = set()
        for text in self.texts:
            validate_text(text, self.registry, self.meanings, self.intimacy)
            ensure(text["id"] not in self.by_text, "text_duplicate", "本文IDが重複している。")
            self.by_text[text["id"]] = text
            self.by_meaning[text["meaning"]].append(text)
            if text["fallback"]:
                fallback.add(text["meaning"])
        ensure(self.meanings <= fallback, "fallback", "基本本文がない意味がある。")
        if self.intimacy and self.intimacy.flow:
            self.intimacy.flow.lookup = self.by_text.get  # v8.4.6（010）：条件 flow.prev.<名前> が直前の本文を引く

    def has_authored(self, meaning, values):
        """True when a written (non-fallback) passage for the meaning matches the given condition values."""
        return any(not t["fallback"] and evaluate(t["when"], values) is True for t in self.by_meaning.get(meaning, []))

    def intensity(self, meaning, state):
        """v8.2.2（009）：本文の濃さの段階（low／mid／high）。真帆の高まりの段階とこちらの高まりの高いほう。達する・出す場面は high。
        設定に intensity がない版（008 まで）は None（描写の濃さの設定で選ぶ）。"""
        if not self.intimacy or "intensity" not in self.intimacy.settings:
            return None
        config = self.intimacy.settings["intensity"]
        intimate = state.get("intimacy")
        if not intimate:
            return "low"
        if meaning.startswith(tuple(config["peak_meanings"])):
            return "high"
        maho = {"low": 0, "mid": 1, "high": 2, "near": 2}[self.intimacy.band(intimate["maho"]["arousal"])]
        arousal = intimate["player"]["arousal"]
        player = 2 if arousal >= config["player_high_from"] else 1 if arousal >= config["player_mid_from"] else 0
        return ("low", "mid", "high")[max(maho, player)]

    def _late_only(self, text):
        """v8.2.23：高まりの後半だけに出す本文か（when に真帆の高まり high・near、またはこちらの高まり ready・max だけの条件がある）。"""
        cache = getattr(self, "_late_cache", None)
        if cache is None:
            cache = self._late_cache = {}
        result = cache.get(text["id"])
        if result is None:
            result = any(isinstance(c, dict) and ((c.get("field") == "intimacy.maho.band" and c.get("op") == "in" and set(c["value"]) <= {"high", "near"})
                                                  or (c.get("field") == "intimacy.player.arousal_band" and c.get("op") == "in" and set(c["value"]) <= {"ready", "max"}))
                         for c in text["when"].get("all", ()))
            cache[text["id"]] = result
        return result

    def _origin_text_ids(self):
        """v8.4.3（010）：体位を移る本文のうち、移る前の体位に合わせて書いた本文の id
        （when の条件で、移る前の体位を挙げている。または移る前の向きに face を含まない＝背を向けた体位・顔面騎乗などから）。"""
        ids = getattr(self, "_origin_ids", None)
        if ids is None:
            def origin_only(c):
                if not isinstance(c, dict) or c.get("op") != "in":
                    return False
                if c.get("field") == "intimacy.facing_from":
                    return "face" not in c["value"] and "none" not in c["value"]
                return c.get("field") == "intimacy.position_from"
            ids = self._origin_ids = frozenset(t["id"] for t in self.texts if any(origin_only(c) for c in t["when"].get("all", ())))
        return ids

    def _afterglow_text(self, text):
        """v8.4.8（010）：余韻のときだけ出る本文か（when に intimacy.maho.afterglow が真）。"""
        found = getattr(self, "_afterglow_ids", None)
        if found is None:
            cond = '{"field": "intimacy.maho.afterglow", "op": "eq", "value": true}'
            found = self._afterglow_ids = frozenset(t["id"] for t in self.texts if cond in json.dumps(t["when"], ensure_ascii=False))
        return text["id"] in found

    def _memory_keys(self, text):
        """v8.4.11（010）：本文を覚える鍵（短い16進）。切り出した短い1行（sh.・sh2.）は、もとの本文と同じ鍵（もとの本文が出てすぐ同じ行が出ないように）。
        部品を組み合わせた本文（cmp.<場面>.<a>.<b>）は部品ごとの鍵（同じ部品がすぐ戻らないように。選ぶときは新しいほうの部品で比べる）。"""
        keys = self.__dict__.setdefault("_memory_key_cache", {})
        found = keys.get(text["id"])
        if found is None:
            identity = text["id"]
            if identity.startswith("cmp."):
                stem, first, second = identity.rsplit(".", 2)
                # v8.4.18（010）：胸の左・右・両方は、後半の部品を共有する（どれで出ても同じ反応として覚える）
                sources = (stem + "." + first, re.sub(r"\.side_(left|right|both)$", ".side", stem) + "." + second)
            else:
                sources = (identity.split(".", 1)[1] if identity.startswith(("sh.", "sh2.")) else identity,)
            found = keys[identity] = tuple(hashlib.blake2b(source.encode("ascii"), digest_size=5).hexdigest() for source in sources)
        return found

    def _lewd_text_ids(self):
        ids = getattr(self, "_lewd_ids", None)
        if ids is None:
            ids = self._lewd_ids = frozenset(t["id"] for t in self.texts if '"intimacy.lewd_band"' in json.dumps(t["when"], ensure_ascii=False))
        return ids

    def select(self, meaning, state, bindings, values=None):
        values = self.registry.values(state) if values is None else values
        if self.intimacy and self.intimacy.flow:
            # v8.4.6（010）：条件 flow.prev.<名前>（直前に出た本文の型）は、選ぶ時点の最近の本文で見る。値は本文を出すと決めた時点で
            # 計られるので、同じ手で続けて出る本文（手の本文のあとの締め切り・合図など）では、ひとつ前の手の本文を見てしまう
            values = {**values, **self.intimacy.flow.prev_values(state)}
        candidates = [t for t in self.by_meaning.get(meaning, []) if evaluate(t["when"], values) is True and all(x in bindings and bindings[x] is not None for x in t["slots"])]
        ensure(candidates, "missing_text", "この結果に対応する本文がない。")
        # A matching authored passage replaces the short connection-test prose.
        # Keep the fallback available when no authored conditions match.
        authored = [t for t in candidates if not t["fallback"]]
        candidates = authored or candidates
        # v8.2.16（009）：深い口づけが続いているあいだ、真帆は話せない。口づけそのものの本文のほかは、台詞のない本文があれば台詞のある本文を出さない
        # （口づけは指・素股・動く行為などでは途切れない。これまでの本文には、口づけの有無を条件にしていない台詞の本文がある）
        # v8.2.19：仮の本文を外したあとで絞る。台詞のない本文が仮の本文しかないときに、仮の本文が選ばれていた（GPT の試遊 2026-09-29「（太ももを撫でる）」）
        quiet = self.intimacy.settings.get("quiet_contacts") if self.intimacy else None
        if quiet and meaning.partition(".")[0] not in quiet and any(c["action_id"] in quiet for c in state.get("contacts", ())):
            candidates = [t for t in candidates if not ("「" in t["body"] and "」" in t["body"])] or candidates
        # v8.2.30（通し確かめ 11）：締め切りの一言のあとの最後の手（残り0）は、続ける本文の台詞（「もっと」など）を出さない
        intimate = state.get("intimacy") if self.intimacy else None
        if intimate and intimate.get("wrap_up") == 0 and meaning.partition(".")[0] in self.intimacy.actions and meaning.rpartition(".")[2] in ("continue", "settled", "continue_short"):
            candidates = [t for t in candidates if not ("「" in t["body"] and "」" in t["body"])] or candidates
        # v8.2.2（009）：濃い本文（style）は、その時の高まりで出し分ける。低いうちは出さない。
        intensity = self.intensity(meaning, state)
        if intensity == "low":
            candidates = [t for t in candidates if not t.get("style")] or candidates
        history = state["recent_text"][-self.recent_window:]
        last = history[-1]["id"] if history else None
        groups = {x["group"] for x in history[-4:]}
        recent = {x["id"] for x in history}
        # v8.4.18（010）：組み合わせた本文は、後半（真帆の反応）の部品が最近の本文に出ていれば、前半が違っても最近出た本文として扱う
        # （前半だけ違う組み合わせで、同じ反応が同じ回の中にもう一度出ていた。先に出す本文を選ぶとき・並べるとき）。009 は本文を覚えないので変わらない
        text_memory = self.intimacy.text_memory if self.intimacy else None
        recent_parts = {self._memory_keys(self.by_text[x["id"]])[1] for x in history if x["id"].startswith("cmp.") and x["id"] in self.by_text} \
            if text_memory and text_memory["composed"] == "reaction_first" else set()

        def is_recent(t):
            if t["id"] in recent:
                return True
            return bool(recent_parts) and t["id"].startswith("cmp.") and self._memory_keys(t)[1] in recent_parts
        # v8.2.23（009）：同じ長い本文から切り出した短い1行（sh.<もと>・sh2.<もと>）は、どちらかが最近出ていれば、もう片方も最近出たものとして扱う
        cut_source = lambda identity: identity.split(".", 1)[1] if identity.startswith(("sh.", "sh2.")) else None
        recent_sources = {cut_source(i) for i in recent} - {None} if self.intimacy else set()
        # v8.4.3（010）：体位を移る本文は、移る前の体位（背を向けた体位・顔面騎乗・膝に乗る など）に合わせて書いた本文を、最近出ていない限り先に出す
        # （「仰向けに返す」などの本文が、どの体位からでも出る本文に埋もれないように）
        if intimate and self.intimacy.position_from_prefer and (meaning.startswith("h_pos_") or meaning == "h_limit_move.start"):
            origin_ids = self._origin_text_ids()
            candidates = [t for t in candidates if t["id"] in origin_ids and not is_recent(t)] or candidates
        # v8.4.6（010）：前の本文の気持ちを受けて書いた本文（条件 flow.prev.<名前>）が合うときは、最近出ていない限り先に出す
        # （「離れないで」の直後の締め切りに「離れたくないけど……」、「もっと」の直後に抱きしめたら「……ぎゅってするだけ？」）
        if intimate is not None and self.intimacy and self.intimacy.flow:
            candidates = [t for t in candidates if self.intimacy.flow.receiver(t) and not is_recent(t)] or candidates
        # v8.4.7（010）：中に出す手で真帆が達しなかったとき、真帆の高まりを書いた本文（settings.finish_outcome.prefer）を、最近出ていない限り先に出す
        # （この手では高まりの合図を出さないので、果てる本文が真帆の様子を伝える）
        # v8.4.8（010）：真帆が達したあとの余韻（intimacy.maho.afterglow）のあいだは、余韻に合わせて書いた本文（when に afterglow が真）を、最近出ていない限り先に出す
        if self.intimacy and self.intimacy.afterglow and values.get("intimacy.maho.afterglow"):
            candidates = [t for t in candidates if self._afterglow_text(t) and not is_recent(t)] or candidates
        finish = self.intimacy.finish_outcome if self.intimacy else None
        if finish and values.get("intimacy.finish_outcome") in finish["prefer"]:
            prefer = finish["prefer"][values["intimacy.finish_outcome"]]
            candidates = [t for t in candidates if t["id"] in prefer and not is_recent(t)] or candidates
        count = Counter(x["id"] for x in history)
        # v8.2.37（009）：候補がどれも記録に入っているときは、いちばん前に出た本文から（出た回数より先に見る）。まだ出ていない本文は -1
        last_seen = {x["id"]: index for index, x in enumerate(history)} if self.recent_window > 64 else None
        # v8.4.11（010）：保存に覚えた、本文ごとに最後に出た番号（最近の本文の記録より長く覚える）。同じ条件で選べる本文の中では、
        # まだ出ていない本文（覚えていない本文）、次にいちばん長く出ていない本文から。流れの直し・最近出た本文を避ける順はこれより先
        memory = self.intimacy.text_memory if self.intimacy else None
        seen = (state.get("text_seen") or {}).get("last", {}) if memory else None
        # IDs are ASCII and ':' cannot occur in them. Build the fixed part once,
        # instead of JSON-encoding seed and counter for every candidate.
        prefix = f"{state['world']['seed']}:{state['world']['rng']['text']}:".encode("ascii")
        # Exact wording becoming familiar is more noticeable than two nearby
        # passages sharing a style group.  Avoid a recently used variant first,
        # then spread dialogue/reflection groups when several fresh options remain.
        spacing = 0
        if self.life:
            action, _, phase = meaning.partition(".")
            if action in self.progression.touch_actions or (self.intimacy and action in self.intimacy.actions):
                spacing = self.life.spacing.get(phase, 0)
                if self.intimacy:
                    # v8.2.29：「台詞の多さ」を選ばせない版（009）は、既定の多さで出す（前の保存の設定は使わない）
                    speech = self.intimacy.settings["default"]["speech"] if self.intimacy.sides else state["settings"]["speech"]
                    spacing = max(0, min(10, spacing + self.intimacy.settings["speech_offset"][speech]))
        dialogue_recent = False
        if spacing:
            for item in history[-spacing:]:
                source = self.by_text.get(item["id"])
                if source is not None and "「" in source["body"] and "」" in source["body"]:
                    dialogue_recent = True
                    break
        # v8.2.23（009）：続けている手の短い本文では、山場（高まりが高い〜もうすぐ）だけに出す行（熱さの札 late・新しく書いた後半・後半の声だけの行）も
        # 濃い本文と同じく先に出す。濃い本文だけを先にすると、山場で声だけの行やすがる台詞が出なくなっていた（遊び回り 2026-09-29）。
        late_hot = meaning.endswith(".continue_short") or bool(memory and memory.get("late_hot"))  # v8.4.18（010）：settings.text_memory.late_hot
        hot = (lambda t: bool(t.get("style")) or self._late_only(t)) if late_hot else (lambda t: bool(t.get("style")))
        fresh_style = any(hot(t) and not is_recent(t) for t in candidates)
        # v8.2.12（009）：淫乱度の段で書き分けた本文（when に intimacy.lewd_band）が合うときは、まだ最近出ていない限り先に出す。
        # ただし、同じ意味で前に出したのが段の本文なら、今回は優先しない（段の本文と既存の本文を交互に。読み手の指摘 S-1）
        lewd_ids = self._lewd_text_ids()
        fresh_lewd = False
        if lewd_ids and any(t["id"] in lewd_ids and t["id"] not in recent for t in candidates):
            same = next((x["id"] for x in reversed(history) if x["id"] in self.by_text and self.by_text[x["id"]]["meaning"] == meaning), None)
            fresh_lewd = same not in lewd_ids
        # v8.4.4（010）：前後の本文の流れ。直前の本文（新しい順に flow.window 本）の仕草と重なる本文、前の状態と食い違う「〜たまま」の本文を後回しにする
        flow = self.intimacy.flow if self.intimacy else None
        previous = [t for t in (self.by_text.get(x["id"]) for x in reversed(history[-(flow.window + 2):])) if t and not flow.transparent(t)][:flow.window] if flow else []
        def rank(t):
            if intensity == "high":
                # 高いときは濃い本文を先に。濃い本文がどれも最近出ていたら、まだ出ていない本文から（繰り返しを避ける）
                base = ((not hot(t)) if fresh_style else False,)
            elif intensity is not None:
                base = (False,)  # 中くらい（と、低いときに残った本文）は区別しない
            else:
                # v8.2.0：描写の濃さに合う本文を最優先にする（標準の設定では、ほかに本文がある限り濃い本文を出さない）
                base = (bool(t.get("style")) != (state["settings"]["density"] == "explicit"),) if self.intimacy else ()
            base += (t["id"] == last,)
            if self.intimacy:
                base += (is_recent(t) or cut_source(t["id"]) in recent_sources,)  # 009（v8.2.7、精査 C-09）：最近出た本文を避けるほうを、台詞の間隔より先にする
            if self.life:
                base += (dialogue_recent and "「" in t["body"] and "」" in t["body"],)
            base += ((t["id"] not in lewd_ids) if fresh_lewd else False,)  # 段の本文は台詞の間隔の後（読み手の指摘 M-10）
            if flow:
                base += (flow.score(previous, t),)  # 最近出た本文を避ける・台詞の間隔・段の本文の後、同じ組を避ける・出た順の前
            if seen is not None:
                # 部品を組み合わせた本文は、部品の番号を新しい順に並べて比べる（新しいほうの部品が同じなら、もう一方の部品が古い本文から）。
                # 部品のない本文は -1 を足して長さをそろえる
                keys = self._memory_keys(t)
                if len(keys) == 2 and memory["composed"] == "reaction_first":
                    tail = (seen.get(keys[1], -1), seen.get(keys[0], -1))  # v8.4.14（010）：後半（真帆の反応）の部品で比べ、同じなら前半の部品で
                else:
                    tail = tuple(sorted((seen.get(key, -1) for key in keys), reverse=True)) + (-1,) * (2 - len(keys))
            else:
                tail = (last_seen.get(t["id"], -1),) if last_seen is not None else ()
            return base + (is_recent(t), t["group"] in groups) + tail + (count[t["id"]], hashlib.sha256(prefix + t["id"].encode("ascii")).digest())
        text = min(candidates, key=rank)
        body = TOKEN.sub(lambda match: str(bindings[match.group(1)]), text["body"])
        state["recent_text"].append({"id": text["id"], "group": text["group"], "release": self.id})
        state["recent_text"] = state["recent_text"][-self.recent_window:]
        if memory:
            record = state.setdefault("text_seen", {"last": {}})["last"]
            serial = state["world"]["rng"]["text"]
            for key in self._memory_keys(text):
                record[key] = serial
            if len(record) > memory["horizon"] + 256:  # 256 本ごとにまとめて、覚えておく長さより前のものを捨てる
                floor = serial - memory["horizon"]
                for key in [key for key, value in record.items() if value < floor]:
                    del record[key]
        state["world"]["rng"]["text"] += 1
        return {"meaning": meaning, "variant": text["id"], "release": self.id, "body": body}, len(candidates)


class Repository:
    def __init__(self, builtin, extra):
        self.roots = [Path(extra), Path(builtin)]
        self.cache = {}

    def get(self, identity):
        identifier(identity)
        if identity not in self.cache:
            paths = [root / identity for root in self.roots if (root / identity / "release.json").is_file()]
            ensure(paths, "missing_release", "必要な原稿の版が見つからない。")
            packs = [Pack(path) for path in paths]
            ensure(len({p.hash for p in packs}) == 1, "release_conflict", "同じ版名で異なる公開内容が存在する。版名を分ける。")
            pack = packs[0]
            ensure(pack.id == identity, "release_id", "原稿の版の名前が一致しない。")
            self.cache[identity] = pack
        return self.cache[identity]

    def ids(self):
        return sorted({p.name for root in self.roots if root.exists() for p in root.iterdir() if p.is_dir() and (p / "release.json").is_file()})
