"""Deterministically build the unpublished Stage A2 release from 007."""
import argparse
import json
import re
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from nagishima import RULES_VERSION
from nagishima.codec import bytes_digest, digest
from nagishima.content import FILES, PROGRESSION, LIFE, Pack

SOURCE = ROOT / "content" / "releases" / "interaction_007"
TARGET = ROOT / "content" / "releases" / "interaction_008"
RESULTS = ROOT / "authoring" / "a2_results"
JOBS = ROOT / "authoring" / "a2_jobs"
ADOPTED = (
    ("J2", "J2_慣れた反応_採用.json", "j2_sonnet_familiar.json", 42),
    ("J3", "J3_台詞なし_採用.json", "j3_sonnet_narration.json", 65),
    ("J4", "J4_仕事と誘い_採用.json", "j4_sonnet_life.json", 48),
)

LIFE_DATA = {
    "format": "nagishima.life/1",
    "offers": {"once_per_day": ["shared", "care"], "shared_by_time": [
        {"from": "05:01", "to": "15:59", "activities": ["tea"]},
        {"from": "16:00", "to": "18:59", "activities": ["walk", "quiet"]},
        {"from": "19:00", "to": "05:00", "activities": ["reading", "quiet"]},
    ]},
    "drinks": {"activities": ["tea"], "per_day": 3, "min_interval_minutes": 120},
    "speech": {"spacing": {"start": 1, "repeat": 3, "heated": 3, "continue": 3, "settled": 5}},
    "familiarity": {"few_from": 2, "familiar_from": 6},
    "work": {"weekdays": [0, 1, 2, 3, 4], "go_ahead_minutes": 60, "blocks": [
        {"id": "morning", "start": "08:30", "end": "12:00", "after": "kitchen"},
        {"id": "afternoon", "start": "13:00", "end": "15:00", "after": "observatory"},
        {"id": "late", "start": "15:15", "end": "17:30", "after": "living_room"},
    ], "events": {"fixed": [
        {"id": "report", "weekday": 0, "block": "morning"},
        {"id": "supply", "weekday": 3, "block": "afternoon"},
    ], "random": {"ids": ["repair", "rain", "snack"], "chance_percent": 15, "max_per_day": 1}}},
}

PROVISIONAL = {
    "offer.shared.tea": "「そろそろお茶にしない？」真帆は棚のほうを振り返った。",
    "offer.shared.walk": "「少し歩かない？　今の時間の海、きれいだと思う」",
    "offer.shared.reading": "「今夜は、隣で本でも読まない？」",
    "offer.shared.quiet": "「少し、何もしない時間にしようか」",
    "work.block.morning": "午前の点検と記録の整理を片づけるころには、もう昼になっていた。",
    "work.block.afternoon": "午後の点検をひととおり終えて観測棟に戻ると、真帆もちょうど手を止めたところだった。",
    "work.block.late": "残りの記録をまとめて、今日の仕事を終えた。",
    "work.event.report": "月曜の定例で、通信越しに滝沢へ先週の点検結果を報告した。真帆の修理記録も添えると、滝沢は短くうなずいた。",
    "work.event.supply": "木曜の補給便が桟橋に着き、二人で荷を受け取った。修一は船の上から、次の便の予定を告げていった。",
    "work.event.repair": "観測棟の計器が一つ止まり、真帆と並んで配線をたどった。原因の接触不良を見つけたとき、真帆は小さくこぶしを握った。",
    "work.event.rain": "雨で屋外の点検が中止になり、屋内で記録を整理した。手を動かしながら、真帆とぽつぽつ話をした。",
    "work.event.snack": "作業の合間に、真帆が焼き菓子を差し入れてくれた。「根を詰めすぎないでね」とだけ言って、持ち場へ戻っていった。",
}


def dump(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")


def load(path):
    return json.loads(path.read_text(encoding="utf-8"))


def add_condition(original, condition):
    if original == {"all": []}:
        return condition
    if set(original) == {"all"}:
        return {"all": original["all"] + [condition]}
    return {"all": [original, condition]}


def fix_quoted_narration(body):
    def replace(match):
        passage = match.group(1)
        if "真帆" not in passage:
            return match.group(0)
        following = body[match.end():match.end() + 1]
        stop = "" if passage.endswith(("。", "！", "？", "!", "?")) or following == "。" else "。"
        return passage + stop
    return re.sub(r"「([^「」]*)」", replace, body)


def import_a2(texts):
    by_id = {item["id"]: item for item in texts}
    assert len(by_id) == len(texts)
    classified = load(RESULTS / "J1_分類結果.json")
    assert len(classified) == 109 and len({item["text_id"] for item in classified}) == 109
    restricted = []
    for item in classified:
        original = by_id[item["text_id"]]
        assert not original["fallback"] and item["tone"] in {"natural", "shy", "surprise"}
        if item["tone"] in {"shy", "surprise"}:
            action = original["meaning"].split(".")[0]
            original["when"] = add_condition(original["when"], {
                "field": f"experience.{action}.tier", "op": "ne", "value": "familiar"})
            restricted.append(original["id"])
    assert len(restricted) == 22

    fixes = []
    for item in texts:
        if (item["meaning"].split(".")[0] in {"hair", "back", "waist"}
                and item["meaning"].split(".")[-1] in {"continue", "settled"}
                and ".i003." in item["id"]):
            before = item["body"]
            after = fix_quoted_narration(before)
            if after != before:
                item["body"] = after
                fixes.append({"id": item["id"], "before": before, "after": after})
    assert len(fixes) == 24

    punctuation_fixes = 0
    imported = {}
    for label, result_file, job_file, expected_count in ADOPTED:
        results = load(RESULTS / result_file)
        jobs = {job["id"]: job for job in load(JOBS / job_file)}
        assert len(results) == expected_count and len({entry["job_id"] for entry in results}) == expected_count
        identifiers = []
        for entry in results:
            job = jobs[entry["job_id"]]
            meaning = job["meaning"]
            number = entry["job_id"].rsplit(".", 1)[-1]
            assert number.isascii() and number.isdecimal() and isinstance(entry["body"], str)
            assert job["slots"] == [] and meaning in {text["meaning"] for text in texts}
            if label == "J2":
                assert job["when"] == {"field": f"experience.{meaning.split('.')[0]}.tier", "op": "eq", "value": "familiar"}
            else:
                assert job["when"] == {"all": []}
            body = entry["body"]
            if label == "J4":
                punctuation_fixes += body.count("」。")
                body = body.replace("」。", "」")
            text_id = f"{meaning}.a2.{label.lower()}.{number}"
            assert text_id not in by_id
            added = {"id": text_id, "meaning": meaning, "when": job["when"],
                     "slots": [], "group": job["group"], "body": body, "fallback": False}
            texts.append(added)
            by_id[text_id] = added
            identifiers.append(text_id)
        imported[label] = identifiers
    assert punctuation_fixes == 16
    assert not any(re.search(r"「[^「」]*真帆[^「」]*」", item["body"]) for item in texts)
    return {"source": "Sonnet 5（J2・J3 は高、J4 は中）・Opus 抜き取り判定済み・2026-09-25",
            "imported": imported, "j1_restricted": restricted, "quoted_narration_fixes": fixes,
            "j4_punctuation_fixes": punctuation_fixes}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--replace-unpublished", action="store_true")
    args = parser.parse_args()
    raise SystemExit("interaction_008 は公開済み。生成ツールで作り直さない。")
    Pack(SOURCE)
    if TARGET.exists():
        if not args.replace_unpublished:
            raise SystemExit("008 は既にある。未公開版だけ --replace-unpublished で再生成できる。")
        assert TARGET.resolve().is_relative_to(ROOT.resolve())
        shutil.rmtree(TARGET)
    shutil.copytree(SOURCE, TARGET)
    meanings = json.loads((TARGET / "meanings.json").read_text(encoding="utf-8"))
    texts = json.loads((TARGET / "texts.json").read_text(encoding="utf-8"))
    for meaning, body in PROVISIONAL.items():
        assert meaning not in meanings
        meanings.append(meaning)
        texts.append({"id": meaning + ".base", "meaning": meaning, "when": {"all": []}, "slots": [], "group": meaning + ".base", "body": body, "fallback": True})
    a2_provenance = import_a2(texts)
    dump(TARGET / "meanings.json", sorted(meanings))
    dump(TARGET / "texts.json", texts)
    dump(TARGET / LIFE, LIFE_DATA)
    catalog = json.loads((TARGET / "catalog.json").read_text(encoding="utf-8"))
    actions = json.loads((TARGET / "actions.json").read_text(encoding="utf-8"))
    progression = json.loads((TARGET / PROGRESSION).read_text(encoding="utf-8"))
    names = FILES + (PROGRESSION, LIFE)
    dump(TARGET / "release.json", {"id": "interaction_008", "rules_version": RULES_VERSION,
        "files": {name: bytes_digest((TARGET / name).read_bytes()) for name in names},
        "control_sha256": digest({"catalog": catalog, "actions": actions, "progression": progression, "life": LIFE_DATA})})
    dump(TARGET / "rules_provenance.json", {"source_release": "interaction_007", "rules_version": RULES_VERSION,
        "change": "段階A2：生活時間、飲み物、台詞間隔、慣れの段階を追加。",
        "provisional_texts": {"author": "Claude Opus 5.5", "reviewed": False,
            "note": "fallback として維持する仮本文", "text_ids": [m + ".base" for m in PROVISIONAL]},
        "a2_texts": a2_provenance})
    pack = Pack(TARGET)
    print(pack.id, len(pack.texts), pack.control_hash)


if __name__ == "__main__":
    main()
