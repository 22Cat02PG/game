"""v8.2.20（ユーザー 2026-09-29 06:40「続ける系は数秒置きに自動入力」）：テキスト版の「自動で続ける」の判定。

エンジンの状態と画面（view）だけを読み、何も変えない。自動で選ぶ操作は、ふつうの入力と同じく実行ログに残るので、再生はこれまでどおり。
止めるとき：申し出が出た、区切り（締め切り）の後、続けていた行為が終わった・入れ替わった、こちらが限界、真帆がもうすぐ（near）、
行為の本文と keep_meanings 以外の本文（達した・合図・物足りなさ・回復など）が出た、同じ選択肢がもう選べない、設定で「切」にした（v8.2.28）。
"""


def auto_next(pack, state, view, choice_id):
    """直前に選んだ choice_id（"touch.<行為>"）を、自動でもう一度選んでよいか。よければ待つミリ秒、止めるなら None。"""
    rules = pack.intimacy
    config = rules.auto if rules else None
    if not config or not choice_id.startswith("touch."):
        return None
    key = choice_id[len("touch."):]
    intimate = state.get("intimacy")
    if key not in config["actions"] or not intimate or state["offer"] or intimate["wrap_up"] is not None:
        return None
    if not any(contact["action_id"] == key for contact in state["contacts"]):
        return None
    if intimate["player"]["arousal"] >= rules.raw["player"]["arousal_max"] or rules.band(intimate["maho"]["arousal"]) == "near":
        return None
    prefixes = (key + ".", key + "_") + tuple(combo["meaning"] + "." for combo in rules.combos if key in combo["actions"])  # v8.2.21：組み合わせの本文も
    for block in view["blocks"]:
        meaning = block["meaning"]
        own = meaning.startswith(prefixes)  # 行為の本文（速さ・追加・短い本文も）
        kept = meaning in config["keep_meanings"] or meaning.startswith(tuple(k for k in config["keep_meanings"] if k.endswith(".")))  # v8.2.22：「.」で終わる項目は前方一致
        if not own and not kept:
            return None
    choice = next((item for item in view["choices"] if item["id"] == choice_id), None)
    if choice is None or not choice["available"]:
        return None
    speed = auto_speed(pack, state)
    if speed == "off":
        return None
    characters = sum(len(block["body"]) for block in view["blocks"])
    wait = min(config["max_ms"], max(config["min_ms"], config["base_ms"] + config["per_char_ms"] * characters))
    return wait * config["speeds"][speed] // 100 if "speeds" in config else wait


def auto_speed(pack, state):
    """v8.2.28：設定「自動で続ける」の速さ（slow／normal／fast／off）。設定していない保存は既定。速さの設定がないデータは normal。"""
    config = pack.intimacy.auto if pack.intimacy else None
    if not config or "speeds" not in config:
        return "normal"
    return state.get("settings", {}).get("auto_speed", config["default"])
