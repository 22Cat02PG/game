"""v8.4.5（ユーザー 2026-10-06 16:05「始めて」）：010 だけ。
- 刺激のない手（撫でる・頬・手をつなぐ・体位を変える・話す など）では、真帆の高まりの段を上げない（合図も出ない）。
  入れておらず、ほかに刺激も続いていない刺激のない手が 2手続いたら、高まりを一段下げる（「息が浅くなっている」より下へは下げない。体位を変える・話すは数えない）。
- 手をつなぐ・抱きしめる・腕を引くを、別の触れ合いに入れ替えて終えたとき、ほどく一言を出す（同じ仲間どうしでは出さない）。
- 流れ（v8.4.4）に気持ちの型を足した（「離れないで」の直後に終わりを言い出す、など）。"""
import unittest
from pathlib import Path

from nagishima.conditions import evaluate
from nagishima.content import Pack
from tools.run_stage_b_routes import Route

ROOT = Path(__file__).resolve().parents[1]
P009 = Pack(ROOT / "content/releases/interaction_009")
P010 = Pack(ROOT / "content/releases/interaction_010")


def act(route, key):
    while route.engine.snapshot()["offer"]:
        route.choose("offer.decline")
    route.action(key)


def meanings(route):
    return [b["meaning"] for b in route.engine.get_view()["blocks"]]


def fake(identity, body):
    return {"id": identity, "body": body}


class V845(unittest.TestCase):
    def start(self, seed):
        route = Route(seed, tier="familiar", release="interaction_010", hour=21, day_offset=2)
        self.addCleanup(route.close)
        route.begin()
        return route

    def to_arousal(self, route, value):
        for key in ("h_kiss_deep", "h_kiss_deep", "h_kiss_deep", "h_lift_upper", "h_strip_lower", "h_shift_under"):
            act(route, key)
        for _ in range(20):
            if route.engine.snapshot()["intimacy"]["maho"]["arousal"] >= value:
                break
            act(route, "h_touch_direct")

    def test_009_unchanged(self):
        self.assertIsNone(P009.intimacy.calm)
        self.assertIsNone(P009.intimacy.release)
        self.assertNotIn("system.contact_released.hands", P009.meanings)
        self.assertIsNotNone(P010.intimacy.calm)
        self.assertIsNotNone(P010.intimacy.release)

    def test_calm_hand_does_not_raise_band(self):
        route = self.start(8451)
        for key in ("h_kiss_deep", "h_kiss_deep", "h_kiss_deep", "h_lift_upper"):
            act(route, key)
        for _ in range(10):
            if route.engine.snapshot()["intimacy"]["maho"]["arousal"] >= 76:
                break
            act(route, "h_chest_skin")
        self.assertEqual(P010.intimacy.band(route.engine.snapshot()["intimacy"]["maho"]["arousal"]), "mid")
        for _ in range(4):
            act(route, "h_stroke_head")
            self.assertLess(route.engine.snapshot()["intimacy"]["maho"]["arousal"], P010.intimacy.raw["maho"]["arousal_bands"]["high_from"])
            self.assertNotIn("h.sign.high", meanings(route))

    def test_settle_after_calm_hands(self):
        route = self.start(8452)
        self.to_arousal(route, 90)
        self.assertEqual(P010.intimacy.band(route.engine.snapshot()["intimacy"]["maho"]["arousal"]), "near")
        act(route, "h_cheek")  # 指で触れていたのが終わる（頬に触れるは刺激のない手）
        act(route, "h_pos_lying_face")  # 体位を変えるは数えない
        act(route, "h_forehead")
        maho = route.engine.snapshot()["intimacy"]["maho"]
        self.assertEqual(P010.intimacy.band(maho["arousal"]), "high")
        self.assertEqual(maho["band"], "high")
        for key in ("h_stroke_head", "h_cheek", "h_stroke_head", "h_cheek", "h_stroke_head", "h_cheek"):
            act(route, key)
        self.assertEqual(P010.intimacy.band(route.engine.snapshot()["intimacy"]["maho"]["arousal"]), "mid")  # mid より下へは下げない

    def test_position_first_does_not_fail(self):
        route = self.start(8454)
        act(route, "h_pos_lying_face")  # 刺激のない手の数をまだ持っていないときに、数えない手
        act(route, "h_check")
        self.assertIn("calm", route.engine.snapshot()["intimacy"])

    def test_release_lines(self):
        # 暮らし：両手をつなぐ → 頭を撫でる
        route = Route(8434, release="interaction_010", hour=19, minute=30, day_offset=5)
        self.addCleanup(route.close)
        for key in ("near", "touch.hands_both", "touch.head"):
            if route.engine.get_view()["page"] != "touch":
                route.choose("menu.touch")
            route.choose(key)
        self.assertEqual(meanings(route)[0], "system.contact_released.hands_both")
        # エッチ：手をつなぐ → 両手をつなぐ（同じ仲間）は出さない、抱きしめる → 胸は出す、抱きしめる → 背中を撫でるは出さない
        route = self.start(8453)
        act(route, "h_hands")
        act(route, "h_hands_both")
        self.assertFalse(any(m.startswith("system.contact_released") for m in meanings(route)))
        act(route, "h_lift_upper")
        self.assertIn("system.contact_released.hands_both", meanings(route))
        act(route, "h_hug")
        act(route, "h_back")
        self.assertFalse(any(m.startswith("system.contact_released") for m in meanings(route)))
        act(route, "h_hug")
        act(route, "h_chest_skin")
        self.assertIn("system.contact_released.hug", meanings(route))

    def test_flow_moods(self):
        flow = P010.intimacy.flow
        stay = fake("t.stay", "「離れないで。このままでいたい」")
        end = fake("t.end", "「そろそろ、おしまいにしよ」")
        self.assertEqual(flow.score([stay], end), flow.weights["follow"])
        self.assertEqual(flow.score([fake("t.calm", "指先が、手のひらに重なった。")], end), 0)

    def test_fixed_texts(self):
        self.assertNotIn("引っぱっちゃった", P010.by_text["o32.h.pat.heat.first.s.v3"]["body"])
        text = P010.by_text["b2.h.sign.wants_more.few.s.v6"]
        self.assertIs(evaluate(text["when"], {"intimacy.position": "maho_above"}), False)


if __name__ == "__main__":
    unittest.main()
