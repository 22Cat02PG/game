# 段階B の確定（v8.3.0、2026-10-02）

ユーザーの「確定して」（2026-10-02 13:09）で、段階B の原稿版 009 を確定し、新規開始の既定の版にした。版 2.7.0。009 の中身（本文・決まり）は v8.2.38 と同じ。

## 確定とは
- この作りの中で、版を「完成。もう中身を変えない」と固めること（これまでの言い方では「公開」。外に出すことではない）。003〜008 と同じ扱い。
- 確定した版で保存したデータは、あとの直しの影響を受けずに読める（作り直すたびに検査値が変わって読めなくなることがなくなる）。

## 変えたこと
- `tools/build_intimacy_release.py`：確定済み（PUBLISHED）に 009 を足した。009 は作り直さない。同じものが作れるかは `--verify` で、別の場所（`.rebuild_verify/`、終わったら消す）に作って比べる。版の名前（release.json の id）は作る場所の名前から取る（次の版は `--target content/releases/interaction_010`）。
- `tools/check_packaged_009.py`：包んだ本体でも、作り直しを断ることと `--verify` で同じになることを確かめる。
- 新規開始の既定を 009 に（`nagishima/__main__.py` の `--release` の既定）。start.bat・start_test.bat は 009 で始まる。008 は `--release interaction_008`。
- `verification/stage_b_legacy_goldens.json`：009 のファイル 11本の検査値と、自動プレイ6通り（3つの遊び方 × seed 0・42）の出力の検査値を足した（`tools/record_confirmed_release.py`）。`test_stage_b` の test_b01・test_b02 が、009 の中身と動きが変わらないことを確かめる。
- 009 の保存は、通常時（二人の時間の外）に「原稿更新 interaction_010」で 010 へ切り替えられる（`nagishima/engine.py` の `adopt_release`、`into_next`）。決まりが変わった版でも、状態の形が合えば移れる（合わなければ検査で止まる）。

## これからの直し（010）
- 本文や決まりの直しは、tools/stage_b のデータを直し、`python3 tools/build_intimacy_release.py --target content/releases/interaction_010` で 010 を作る（2回目からは `--replace-unpublished`）。
- 本体（nagishima/）を直すときは、009 の動きを変えないようにする（決まりは 010 の intimacy.json などの設定で切り替える。v8.2.37 の recent_text_window、v8.2.38 の keep_after_private と同じ形）。009 の自動プレイの検査値（test_b02）が変わったら、変えてよいかを確かめてから記録し直す。
- 010 を作るときに足すこと：起動の既定（`__main__.py`）・start_*.bat、自動プレイの 009 の名前での分岐（`nagishima/autoplay.py` の 3か所）、009 を名前で指す道具（`check_packaged_009.py` など7本）と試験（18本）のうち 010 の動きを見るもの、010 を確定するときの PUBLISHED と検査値の記録。

## 確かめ
- `tests/test_v830.py`（4件）：009 を作り直さない・`--verify` で同じ、検査値に 009、既定の版が 009、009 の保存から決まりの違う 010 へ切り替え・保存・読込（二人の時間の最中は切り替えない）。
- v8.2.38 で作った保存（エッチの最中のものも）を v8.3.0 で読めることを確かめた（009 の中身が同じため）。
- 試験 644件、全検査通過（`/home/claude/work/v830_checks.sh`。互換・自動プレイの監査・b2 の通し30本と行列80経路）。
