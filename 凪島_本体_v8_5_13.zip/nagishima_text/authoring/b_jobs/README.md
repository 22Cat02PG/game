# 段階Bの執筆job

`grok_wave_1.json`（118件）、`grok_wave_2.json`（150件）、`grok_wave_3.json`（95件）はOpus 5.5が採用した正本。`tools/build_stage_b_jobs.py` はこの3ファイルを検査するだけで、作り直さない。`sonnet_life_8.json` は生活本文の8件。

本文を取り込むときは、各jobの `id` に `.v<番号>` を付けて本文IDにする。本文の `meaning` はjobの `_meaning`、`when` と `group` はjobの値をそのまま使い、`slots` は本文中の差し込みから求め、`fallback` は `false` にする。**`when` を本文IDから組み立て直さない。** 翌朝の一言と行動の `.first` は、ID中の慣れと条件が一致するとは限らない。

取り込みは v8.0.2 から行っている（採用本文は `tools/stage_b/b_texts.json`、判定の記録は `authoring/b_results/`）。v8.0.2 で、第2陣・第3陣の job の meaning・must_not の文面を改訂した（ID・when・group は変えていない）。grok に渡したプロンプトは `grokプロンプト_v2_15.txt`。

v8.0.3 で全 job の採用本文が3本以上になった。v8.0.3 からは Opus が本文を直して採っている（元の本文と直した本文は `authoring/b_results/本文の直し.json`）。
