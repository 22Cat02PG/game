"""Stage A progression: affinity, desire, Maho's sleep and life days.

A release enables these rules by shipping progression.json.  Releases
without it keep every value neutral and behave as rules 2.2 did.
"""
import re

from .codec import digest, exact
from .errors import ensure

FORMAT = "nagishima.progression/1"
SOURCES = ("activity_completed", "promise_fulfilled", "story_completed", "talk", "touch", "offer_accepted", "private_completed")
SLEEP_STATES = ("awake", "dozing", "asleep")
MILESTONE_SCENES = {f"milestone_{n}": n for n in range(1, 5)}
DAY_START = 300  # 5:00 is the last minute of the previous life day.


def neutral_affinity():
    return {"value": 0, "day": None, "gained": 0, "counts": {}}


def neutral_sleep():
    return {"state": "awake", "since": None, "doze_day": None}


def life_day(minute):
    return (minute - DAY_START - 1) // 1440


def day_time(minute):
    """Minutes within the life day: 5:01 = 301 ... next 5:00 = 1740."""
    return (minute - DAY_START - 1) % 1440 + DAY_START + 1


def parse_time(text):
    ensure(type(text) is str and re.fullmatch(r"(?:[01][0-9]|2[0-3]):[0-5][0-9]", text), "progression_data", "時刻はHH:MMで指定する。")
    value = int(text[:2]) * 60 + int(text[3:])
    return value + 1440 if value <= DAY_START else value


def _int(value, low, high, label):
    ensure(type(value) is int and low <= value <= high, "progression_data", f"{label}は{low}〜{high}の整数で指定する。")
    return value


class Rules:
    """Validated progression.json.  `raw` is kept verbatim for hashing."""

    def __init__(self, raw, actions):
        self.raw = raw
        ensure(type(raw) is dict, "progression_data", "progression.jsonの形式が違う。")
        exact(raw, ["format", "affinity", "milestones", "desire", "maho_sleep", "life_after_stage4"])
        ensure(raw["format"] == FORMAT, "progression_data", "progression.jsonの形式名が違う。")
        a = raw["affinity"]
        exact(a, ["max", "daily_cap", "display", "talk_actions", "touch_actions", "sources"])
        self.affinity_max = _int(a["max"], 1, 1000, "親密度の上限")
        self.daily_cap = _int(a["daily_cap"], 1, self.affinity_max, "1日の上限")
        ensure(type(a["display"]) is bool, "progression_data", "displayは真偽値で指定する。")
        self.display = a["display"]
        for key in ("talk_actions", "touch_actions"):
            ensure(type(a[key]) is list and len(set(a[key])) == len(a[key]) and set(a[key]) <= set(actions), "progression_data", key + "に未登録か重複した行動がある。")
        ensure(not set(a["talk_actions"]) & set(a["touch_actions"]), "progression_data", "話す行動と触れる行動が重なっている。")
        self.talk_actions, self.touch_actions = frozenset(a["talk_actions"]), frozenset(a["touch_actions"])
        ensure(type(a["sources"]) is dict and set(a["sources"]) == set(SOURCES), "progression_data", "親密度の発生源が登録と一致しない。")
        self.sources = {}
        for key, spec in a["sources"].items():
            exact(spec, ["amount", "per_day"])
            self.sources[key] = (_int(spec["amount"], 1, self.affinity_max, key + ".amount"), _int(spec["per_day"], 1, 100, key + ".per_day"))
        m = raw["milestones"]
        ensure(type(m) is list and len(m) == 4, "progression_data", "節目の条件は4件で指定する。")
        self.min_affinity, self.min_days = [], []
        for index, spec in enumerate(m):
            exact(spec, ["stage", "min_affinity", "min_days"])
            ensure(spec["stage"] == index + 1, "progression_data", "節目は段階1〜4の順に並べる。")
            self.min_affinity.append(_int(spec["min_affinity"], 0, self.affinity_max, "min_affinity"))
            self.min_days.append(_int(spec["min_days"], 0, 30, "min_days"))
        ensure(self.min_affinity == sorted(self.min_affinity), "progression_data", "節目の親密度が段階の順に減っている。")
        d = raw["desire"]
        exact(d, ["max", "min_stage", "invite", "press", "touch_start", "touch_continue", "talk", "sleep_change", "set_after_private"])
        self.desire_max = _int(d["max"], 1, 1000, "欲求の上限")
        self.desire_min_stage = _int(d["min_stage"], 0, 4, "min_stage")
        self.invite = _int(d["invite"], 0, self.desire_max, "invite")
        self.press = _int(d["press"], self.invite, self.desire_max, "press")
        for key, allowed in (("touch_start", self.touch_actions), ("talk", self.talk_actions)):
            ensure(type(d[key]) is dict and set(d[key]) <= allowed, "progression_data", key + "に対象外の行動がある。")
            for value in d[key].values(): _int(value, 0, self.desire_max, key)
        self.desire_touch_start, self.desire_talk = dict(d["touch_start"]), dict(d["talk"])
        self.desire_touch_continue = _int(d["touch_continue"], 0, self.desire_max, "touch_continue")
        self.desire_sleep_change = _int(d["sleep_change"], -self.desire_max, 0, "sleep_change")
        self.desire_after_private = _int(d["set_after_private"], 0, self.desire_max, "set_after_private")
        s = raw["maho_sleep"]
        exact(s, ["bedtime", "doze"])
        self.bedtime = parse_time(s["bedtime"])
        ensure(1080 <= self.bedtime <= 1710, "progression_data", "就寝時刻は18:00〜翌4:30で指定する。")
        z = s["doze"]
        exact(z, ["chance_percent", "start_from", "start_to", "step_minutes", "duration_minutes"])
        self.doze_chance = _int(z["chance_percent"], 0, 100, "chance_percent")
        self.doze_from, self.doze_to = parse_time(z["start_from"]), parse_time(z["start_to"])
        self.doze_step = _int(z["step_minutes"], 5, 60, "step_minutes")
        ensure(self.doze_from <= self.doze_to and (self.doze_to - self.doze_from) % self.doze_step == 0, "progression_data", "うたた寝の開始範囲が刻みで割り切れない。")
        durations = z["duration_minutes"]
        ensure(type(durations) is list and durations and all(type(x) is int and 5 <= x <= 180 for x in durations) and durations == sorted(set(durations)), "progression_data", "うたた寝の長さは5〜180分の昇順で指定する。")
        self.doze_durations = list(durations)
        ensure(self.doze_to + durations[-1] <= self.bedtime, "progression_data", "うたた寝が就寝時刻を越える。")
        ensure(type(raw["life_after_stage4"]) is bool, "progression_data", "life_after_stage4は真偽値で指定する。")
        self.life_after_stage4 = raw["life_after_stage4"]

    def desire_level(self, value):
        return "press" if value >= self.press else "invite" if value >= self.invite else "low"

    def doze_plan(self, seed, day):
        """(start, end) in life-day minutes, or None.  Stateless and seed-derived."""
        v = int(digest([seed, "doze", day])[:12], 16)
        if v % 100 >= self.doze_chance:
            return None
        slots = (self.doze_to - self.doze_from) // self.doze_step + 1
        start = self.doze_from + ((v // 100) % slots) * self.doze_step
        duration = self.doze_durations[(v // (100 * slots)) % len(self.doze_durations)]
        return start, start + duration


def days_since_milestone(state, start_at):
    milestones = state["relation"]["milestones"]
    base = milestones[-1]["at"] if milestones else start_at
    return life_day(state["world"]["now"]) - life_day(base)


def milestone_missing(state, rules, stage, start_at):
    """Stage A requirements not yet met for committing `stage` (catalog `when` excluded)."""
    if rules is None or not 1 <= stage <= 4:
        return []
    missing = []
    if state["affinity"]["value"] < rules.min_affinity[stage - 1]: missing.append("affinity")
    if days_since_milestone(state, start_at) < rules.min_days[stage - 1]: missing.append("days")
    if state["maho_sleep"]["state"] != "awake": missing.append("awake")
    return missing


def gain_affinity(state, rules, source):
    if rules is None:
        return 0
    affinity, day = state["affinity"], life_day(state["world"]["now"])
    if affinity["day"] != day:
        affinity.update({"day": day, "gained": 0, "counts": {}})
    amount, per_day = rules.sources[source]
    if affinity["counts"].get(source, 0) >= per_day:
        return 0
    affinity["counts"][source] = affinity["counts"].get(source, 0) + 1
    add = max(0, min(amount, rules.daily_cap - affinity["gained"], rules.affinity_max - affinity["value"]))
    affinity["value"] += add
    affinity["gained"] += add
    return add


def change_desire(state, rules, amount=0, set_to=None):
    if rules is None or state["relation"]["stage"] < rules.desire_min_stage:
        return
    value = set_to if set_to is not None else state["desire"] + amount
    state["desire"] = max(0, min(rules.desire_max, value))


def check_state(state, rules, maho_free, catalog_start):
    """Stage A invariants; `maho_free` is evaluated by the caller."""
    now, day = state["world"]["now"], life_day(state["world"]["now"])
    affinity, sleep = state["affinity"], state["maho_sleep"]
    if rules is None:
        ensure(affinity == neutral_affinity(), "affinity", "この版では親密度を使わない。")
        ensure(state["desire"] == 0, "desire", "この版では欲求を使わない。")
        ensure(sleep == neutral_sleep(), "maho_sleep", "この版では真帆の眠りを使わない。")
        return
    ensure(affinity["value"] <= rules.affinity_max and affinity["gained"] <= rules.daily_cap, "affinity", "親密度が上限を超えている。")
    ensure(all(key in rules.sources and count <= rules.sources[key][1] for key, count in affinity["counts"].items()), "affinity", "親密度の集計が不正。")
    if affinity["day"] is None:
        ensure(affinity["gained"] == 0 and not affinity["counts"], "affinity", "集計日のない親密度の集計がある。")
    else:
        ensure(affinity["day"] <= day, "affinity", "親密度の集計日が未来になっている。")
    ensure(state["desire"] <= rules.desire_max, "desire", "欲求が上限を超えている。")
    ensure(state["relation"]["stage"] >= rules.desire_min_stage or state["desire"] == 0, "desire", "段階に合わない欲求が残っている。")
    maho, player = state["actors"]["maho"], state["actors"]["player"]
    ensure(sleep["doze_day"] is None or sleep["doze_day"] <= day, "maho_sleep", "うたた寝の日付が未来になっている。")
    if sleep["state"] == "awake":
        ensure(sleep["since"] is None, "maho_sleep", "起きているのに眠り始めた時刻がある。")
        return
    ensure(sleep["since"] is not None and sleep["since"] <= now and life_day(sleep["since"]) == day and maho_free, "maho_sleep", "眠りの時刻か状態が一致しない。")
    if sleep["state"] == "dozing":
        ensure(maho["location"] == "living_room" and sleep["doze_day"] == day, "maho_sleep", "うたた寝の場所か日付が違う。")
    else:
        # 段階C（010、v8.5.0）：寝込み（夜這い）の最中だけ、主人公は眠っている真帆の部屋にいてよい
        # v8.5.6：添い寝（co_sleep）の間も、主人公は真帆の部屋にいてよい
        ensure(maho["location"] == "maho_room" and maho["posture"] == "reclined" and (player["location"] != "maho_room" or bool(state.get("sleep_play")) or bool(state.get("co_sleep"))), "maho_sleep", "就寝中の場所か姿勢が違う。")
