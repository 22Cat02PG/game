"""段階C（010、v8.5.1）：たまに起きるイベントのエッチ（イベントの型）の決まり。intimacy.json の events 節。
仕様は docs/凪島_段階C_仕様_2026-10-08.md の第7節（浴室）と第17節（イベントの型の足し方）。数値は最初の目安で、試遊で直す。

流れ（どのイベントも同じ）：
  pre（その場の触れ合い。上がる・終えるでいつでも抜けられる）→ こちらの高まりが notice_at に届くと、真帆が気づく（反応の表）
  → offer（受け入れる反応なら、こちらが「このまま」か「やめておく」を選ぶ）→ position（体位を一つ選ぶ。最後までその体位）
  → foreplay（前戯は決まった順に自動で進む。こちらは「続けてもらう」か「入れる」）→ main（入れる・動く（3段）・触れる・果てる）。
高まりの数は普段のエッチと同じ決まり（真帆の段・達する値・達したあとの値・慣れの割合、こちらの果てられる値・限界・余力）を使う。
本文の意味は ev.<イベント>.<場面>（読み込みで、データから決まる意味が全部登録されているか確かめる）。"""
import re

from .errors import ensure
from .intimacy_rules import check, number, time

KINDS = ("bath", "kitchen", "drink", "outdoor", "visit")  # 入口のあるイベント（浴室・台所・晩酌・野外・真帆が来る）
PACES = ("slow", "normal", "fast")
FINISHES = ("inside", "outside")
ALWAYS = {"all": []}
NAME = re.compile(r"[a-z][a-z0-9_]{0,29}")
LABELS = ("leave", "accept", "decline", "next", "insert", "finish_inside", "finish_outside")


def _name(value, label):
    ensure(type(value) is str and NAME.fullmatch(value), "intimacy_data", f"イベントの{label}の名前が不正。")
    return value


def _gain(row, label):
    """1手の高まりの増え方（maho：真帆、player：こちら）。"""
    check(row, ["maho", "player"], ["label", "when", "drunk", "exposure"])
    number(row["maho"], -100, 100)
    number(row["player"], -100, 100)
    number(row.get("drunk", 0), -50, 50)  # v8.5.3：真帆の酔い（晩酌）
    number(row.get("exposure", 0), -50, 50)  # v8.5.4：人目（野外）
    if "label" in row:
        ensure(type(row["label"]) is str and 1 <= len(row["label"]) <= 40, "intimacy_data", f"イベントの{label}の名前が不正。")
    ensure("when" not in row or type(row["when"]) is dict, "intimacy_data", f"イベントの{label}の条件が不正。")
    return row


class EventDef:
    def __init__(self, kind, raw):
        self.kind = kind
        check(raw, ["_note", "label", "minutes", "labels", "pre", "positions", "foreplay", "main"], ["drunk", "entry", "exposure", "return", "rumor", "night", "sleep_after", "morning", "meal_labels"])
        # v8.5.3：こちらから誘って始めるイベント（晩酌）の入口：時間帯と関係の段階
        self.entry = None
        if "entry" in raw:
            entry = raw["entry"]
            check(entry, ["label", "from", "until", "min_stage"], ["after", "places", "at", "posture", "when"])
            ensure(type(entry["label"]) is str and 1 <= len(entry["label"]) <= 40, "intimacy_data", "イベントの入口の名前が不正。")
            # after：その食事を済ませてから（食事の時間帯が過ぎていれば、食べていなくても誘える）。晩酌は夕食のあと
            ensure(entry.get("after") in (None, "dinner"), "intimacy_data", "イベントの入口の after は dinner だけ。")
            # v8.5.4：places（誘える場所。真帆と一緒のとき）・at（始めるときに二人で移る場所。なければその場で）・posture（二人の姿勢）・when（誘える条件）。
            # 書かなければ晩酌と同じ（居間か台所で誘い、居間に座って始める）
            places = entry.get("places", ["living_room", "kitchen"])
            ensure(type(places) is list and places and all(type(v) is str and NAME.fullmatch(v) for v in places), "intimacy_data", "イベントの入口の places が不正。")
            ensure(entry.get("posture", "seated") in ("standing", "seated"), "intimacy_data", "イベントの入口の posture が不正。")
            ensure("when" not in entry or type(entry["when"]) is dict, "intimacy_data", "イベントの入口の条件が不正。")
            self.entry = {"label": entry["label"], "from": time(entry["from"]), "until": time(entry["until"]), "min_stage": number(entry["min_stage"], 0, 4),
                          "after": entry.get("after"), "places": places, "at": entry.get("at", None if "places" in entry else "living_room"),
                          "posture": entry.get("posture", "seated"), "when": entry.get("when")}
            ensure(self.entry["at"] is None or type(self.entry["at"]) is str and NAME.fullmatch(self.entry["at"]), "intimacy_data", "イベントの入口の at が不正。")
        # v8.5.5：夜中に真帆が来る（night）。主人公が眠るとき、when に当たれば percent の割合で、from〜until のあいだに眠りが止まって始まる（主人公の部屋）
        self.night = None
        if "night" in raw:
            n = raw["night"]
            check(n, ["from", "until", "percent", "when"])
            ensure(type(n["when"]) is dict, "intimacy_data", "夜中のイベントの条件が不正。")
            self.night = {"from": time(n["from"]), "until": time(n["until"]), "percent": number(n["percent"], 0, 100), "when": n["when"]}
            ensure(self.night["from"] < self.night["until"], "intimacy_data", "夜中のイベントの時間帯が不正。")
        # v8.5.5：sleep_after＝終えたらそのまま眠って翌朝へ（エッチまで進めば同じベッドで、そうでなければ真帆は自分の部屋へ戻る）
        ensure(type(raw.get("sleep_after", False)) is bool, "intimacy_data", "sleep_after は真偽で書く。")
        self.sleep_after = raw.get("sleep_after", False)
        # v8.5.9：翌朝の一言（仕様 第6.3節）。order を、イベントを終えるとき（event.* の項目が見える間）に上から見て、最初に当たった行の id を覚え、
        # 次の朝に ev.<イベント>.morning.<id> を出す。id が null の行に当たれば何も言わない。最後の行はいつも当たる
        self.morning_order, self.mornings = None, []
        if "morning" in raw:
            check(raw["morning"], ["order"])
            order = raw["morning"]["order"]
            ensure(type(order) is list and order and all(type(r) is dict and set(r) == {"id", "when"} and type(r["when"]) is dict for r in order),
                   "intimacy_data", "翌朝の一言の表が不正。")
            ensure(order[-1]["when"] == ALWAYS, "intimacy_data", "翌朝の一言の表の最後は、いつも当たる行にする。")
            self.morning_order = [dict(r, id=None if r["id"] is None else _name(r["id"], "翌朝の一言")) for r in order]
            self.mornings = list(dict.fromkeys(r["id"] for r in self.morning_order if r["id"] is not None))
            ensure(self.mornings, "intimacy_data", "翌朝の一言がない。")
        # v8.5.4：翌日の噂（野外）。エッチまで進んだ翌日、その日はじめての仕事で percent の割合で、島の人に遠回しに言われる本文（ev.<イベント>.rumor）
        self.rumor = None
        if "rumor" in raw:
            check(raw["rumor"], ["percent"])
            self.rumor = {"percent": number(raw["rumor"]["percent"], 0, 100)}
        # v8.5.4：終えたら二人で移る場所（野外：家へ戻る）。location・posture・minutes（戻るのにかかる分）
        self.return_to = None
        if "return" in raw:
            check(raw["return"], ["location", "posture", "minutes"])
            ensure(type(raw["return"]["location"]) is str and NAME.fullmatch(raw["return"]["location"]) and raw["return"]["posture"] in ("standing", "seated"),
                   "intimacy_data", "イベントの戻り先が不正。")
            self.return_to = {"location": raw["return"]["location"], "posture": raw["return"]["posture"], "minutes": number(raw["return"]["minutes"], 0, 60)}
        ensure(type(raw["label"]) is str and 1 <= len(raw["label"]) <= 20, "intimacy_data", "イベントの場所の名前が不正。")
        self.label = raw["label"]
        check(raw["minutes"], ["pre", "h", "limit"], ["h_limit"])
        self.pre_minutes, self.h_minutes, self.limit = number(raw["minutes"]["pre"], 1, 30), number(raw["minutes"]["h"], 1, 30), number(raw["minutes"]["limit"], 10, 180)
        # limit：始めてからいられる分。h_limit があれば、エッチへ移ってからはその分（台所：支度の時間とは別に）
        self.h_limit = number(raw["minutes"]["h_limit"], 10, 180) if "h_limit" in raw["minutes"] else None
        check(raw["labels"], list(LABELS))
        ensure(all(type(v) is str and 1 <= len(v) <= 40 for v in raw["labels"].values()), "intimacy_data", "イベントの選択肢の名前が不正。")
        self.labels = raw["labels"]
        # v8.5.11：支度の食事ごとに替える選択肢の名前（台所：休日の昼は「お昼のあとにする」）
        meal_labels = raw.get("meal_labels", {})
        ensure(type(meal_labels) is dict and set(meal_labels) <= {"dinner", "lunch"} and all(type(v) is dict and set(v) <= set(LABELS) and all(type(x) is str and 1 <= len(x) <= 40 for x in v.values()) for v in meal_labels.values()),
               "intimacy_data", "支度の食事ごとの選択肢の名前が不正。")
        self.meal_labels = meal_labels
        pre = raw["pre"]
        check(pre, ["_note", "actions", "notice"], ["notice_at", "notice_when"])
        ensure(type(pre["actions"]) is dict and pre["actions"], "intimacy_data", "イベントの触れ合いがない。")
        self.pre = {_name(key, "触れ合い"): _gain(row, "触れ合い") for key, row in pre["actions"].items()}
        ensure(all("label" in row for row in self.pre.values()), "intimacy_data", "イベントの触れ合いに名前がない。")
        # 気づく：notice_when（条件）があればその条件で、なければこちらの高まりが notice_at に届いたとき（一度だけ）
        ensure(("notice_at" in pre) != ("notice_when" in pre), "intimacy_data", "気づく決まりは notice_at か notice_when のどちらか一つ。")
        self.notice_at = number(pre["notice_at"], 1, 100) if "notice_at" in pre else None
        self.notice_when = pre.get("notice_when")
        ensure(self.notice_when is None or type(self.notice_when) is dict, "intimacy_data", "気づく条件が不正。")
        notice = pre["notice"]
        check(notice, ["order", "offer"], ["accept_when", "close", "decline_close"])
        self.accept_when = notice.get("accept_when")  # まかせる（エッチへ移る）を選べる条件（晩酌：ほろ酔いのうちだけ）
        ensure(self.accept_when is None or type(self.accept_when) is dict, "intimacy_data", "エッチへ移れる条件が不正。")
        ensure(type(notice["order"]) is list and notice["order"] and all(type(r) is dict and set(r) == {"id", "when"} for r in notice["order"]), "intimacy_data", "気づいたときの表が不正。")
        self.notice_order = [dict(r, id=_name(r["id"], "気づいたときの反応")) for r in notice["order"]]
        ensure(self.notice_order[-1]["when"] == ALWAYS, "intimacy_data", "気づいたときの表の最後は、いつも当たる行にする。")
        self.notices = list(dict.fromkeys(r["id"] for r in self.notice_order))
        ensure(type(notice["offer"]) is list and set(notice["offer"]) <= set(self.notices), "intimacy_data", "エッチへ移れる反応が未登録。")
        self.offer = frozenset(notice["offer"])
        # v8.5.4：close＝この反応のあとはイベントを終える（野外：「部屋に戻ろ」で家へ戻る）
        ensure(type(notice.get("close", [])) is list and set(notice.get("close", [])) <= set(self.notices) - self.offer, "intimacy_data", "反応のあとに終える表が不正。")
        self.notice_close = frozenset(notice.get("close", []))
        # v8.5.4：decline_close＝「やめておく」を選んだらイベントを終える（野外：「やっぱり家に戻ろう」）。書かなければ触れ合いへ戻る
        ensure(type(notice.get("decline_close", False)) is bool, "intimacy_data", "decline_close は真偽で書く。")
        self.decline_close = notice.get("decline_close", False)
        ensure(type(raw["positions"]) is dict and raw["positions"], "intimacy_data", "イベントの体位がない。")
        self.positions = {}
        for key, row in raw["positions"].items():
            check(row, ["label"], ["when"])
            ensure(type(row["label"]) is str and 1 <= len(row["label"]) <= 40, "intimacy_data", "イベントの体位の名前が不正。")
            self.positions[_name(key, "体位")] = row
        ensure(type(raw["foreplay"]) is list and raw["foreplay"], "intimacy_data", "イベントの前戯がない。")
        self.foreplay = []
        for row in raw["foreplay"]:
            ensure(type(row) is dict and "id" in row, "intimacy_data", "イベントの前戯の行が不正。")
            step = _gain({k: v for k, v in row.items() if k != "id"}, "前戯")
            self.foreplay.append(dict(step, id=_name(row["id"], "前戯")))
        ensure(len({r["id"] for r in self.foreplay}) == len(self.foreplay), "intimacy_data", "イベントの前戯の名前が重なっている。")
        main = raw["main"]
        check(main, ["insert", "moves", "touches"])
        self.insert = _gain(main["insert"], "入れる")
        check(main["moves"], list(PACES))
        self.moves = {pace: _gain(main["moves"][pace], "動く") for pace in PACES}
        ensure(all("label" in row for row in self.moves.values()), "intimacy_data", "イベントの動く手に名前がない。")
        ensure(type(main["touches"]) is dict, "intimacy_data", "イベントの触れる手が不正。")
        self.touches = {_name(key, "触れる手"): _gain(row, "触れる手") for key, row in main["touches"].items()}
        ensure(all("label" in row for row in self.touches.values()), "intimacy_data", "イベントの触れる手に名前がない。")
        # v8.5.3：真帆の酔い（晩酌）。levels＝段の境目（ほろ酔い・酔い・酔いつぶれ）、labels＝しらふからの段の名前。最後の段で真帆は眠る（asleep）
        self.drunk = None
        if "drunk" in raw:
            check(raw["drunk"], ["levels", "labels"])
            levels, labels = raw["drunk"]["levels"], raw["drunk"]["labels"]
            ensure(type(levels) is list and levels and [number(v, 1, 500) for v in levels] == sorted(set(levels)), "intimacy_data", "酔いの段の境目が不正。")
            ensure(type(labels) is list and len(labels) == len(levels) + 1 and all(type(v) is str and v for v in labels), "intimacy_data", "酔いの段の名前が不正。")
            self.drunk = {"levels": levels, "labels": labels}
        else:
            ensure(not any("drunk" in row for group in (self.pre.values(), self.foreplay, [self.insert], self.moves.values(), self.touches.values()) for row in group),
                   "intimacy_data", "酔いの決まりのないイベントに酔いの数値がある。")
        # v8.5.4：人目（野外。隠しの値）。start＝場所と時間帯（world.slot）ごとの始まりの値、各手の "exposure" で上がる（声が出る手・激しい動きで大きく）。
        # warn_at を超えると「足音・灯りが近づく」（息を殺す／急いで服を直す／やめる）。息を殺すと hush だけ下がる。max に届いたら、急いで服を直して離れて終わる（見つかる作りにはしない）。
        # levels・labels：状態の行に出す様子の段（数値は出さない）
        self.exposure = None
        if "exposure" in raw:
            e = raw["exposure"]
            check(e, ["start", "warn_at", "max", "hush", "calm", "levels", "labels", "choices"])
            ensure(type(e["start"]) is dict and e["start"] and all(type(v) is dict and v and set(v) <= {"morning", "noon", "evening", "night"} for v in e["start"].values()),
                   "intimacy_data", "人目の始まりの値が不正。")
            for v in e["start"].values():
                for n in v.values():
                    number(n, 0, 100)
            warn_at, maximum, calm = number(e["warn_at"], 1, 100), number(e["max"], 1, 100), number(e["calm"], 0, 100)
            ensure(calm <= warn_at < maximum, "intimacy_data", "人目は calm ≦ warn_at ＜ max にする。")
            levels, labels = e["levels"], e["labels"]
            ensure(type(levels) is list and levels and [number(v, 1, 100) for v in levels] == sorted(set(levels)), "intimacy_data", "人目の段の境目が不正。")
            ensure(type(labels) is list and len(labels) == len(levels) + 1 and all(type(v) is str and v for v in labels), "intimacy_data", "人目の段の名前が不正。")
            check(e["choices"], ["hush", "fix", "stop"])
            ensure(all(type(v) is str and 1 <= len(v) <= 40 for v in e["choices"].values()), "intimacy_data", "人目の選択肢の名前が不正。")
            # calm：一度足音が近づいたあと、人目がこの値より下がるまでは、次は近づかずに max まで上がる（息を殺しても、続ければ見つかりかける）
            self.exposure = {"start": e["start"], "warn_at": warn_at, "max": maximum, "hush": number(e["hush"], -100, 0), "calm": calm,
                             "levels": levels, "labels": labels, "choices": e["choices"]}
            ensure(self.entry is not None and set(self.entry["places"]) <= set(e["start"]), "intimacy_data", "人目の始まりの値が、入口の場所ごとにない。")
        else:
            ensure(not any("exposure" in row for group in (self.pre.values(), self.foreplay, [self.insert], self.moves.values(), self.touches.values()) for row in group),
                   "intimacy_data", "人目の決まりのないイベントに人目の数値がある。")

    def drunk_level(self, points):
        return sum(points >= v for v in self.drunk["levels"]) if self.drunk else 0

    def exposure_level(self, points):
        return sum(points >= v for v in self.exposure["levels"]) if self.exposure else 0

    def meanings(self):
        """この イベントの本文の意味（どれも登録が要る）。"""
        k = "ev." + self.kind + "."
        return ([k + "begin", k + "leave", k + "offer.accept", k + "offer.decline", k + "climax", k + "timeout", k + "insert", k + "end.satisfied", k + "end.unsatisfied"]
                + [k + "pre." + key for key in self.pre] + [k + "notice." + key for key in self.notices] + [k + "pos." + key for key in self.positions]
                + [k + "fore." + row["id"] for row in self.foreplay] + [k + "move." + pace for pace in PACES] + [k + "touch." + key for key in self.touches]
                + [k + "finish." + key for key in FINISHES] + ([k + "asleep"] if self.drunk else [])
                + ([k + "warn", k + "hush", k + "fix", k + "stop", k + "caught"] if self.exposure else []) + ([k + "rumor"] if self.rumor else [])
                + [k + "morning." + key for key in self.mornings])

    def conditions(self):
        rows = [r["when"] for r in self.notice_order] + [w for w in (self.notice_when, self.accept_when) if w] + ([self.night["when"]] if self.night else [])
        rows += [r["when"] for r in self.morning_order or []]
        if self.entry:
            # 入口の場所は player.location の値として確かめる（v8.5.4）
            rows.append({"field": "actor.player.location", "op": "in", "value": self.entry["places"] + ([self.entry["at"]] if self.entry["at"] else [])})
            if self.entry["when"]:
                rows.append(self.entry["when"])
        if self.return_to:
            rows.append({"field": "actor.player.location", "op": "eq", "value": self.return_to["location"]})
        if self.exposure:
            rows.append({"field": "actor.player.location", "op": "in", "value": list(self.exposure["start"])})
        for group in (self.pre.values(), self.positions.values(), self.foreplay, [self.insert], self.moves.values(), self.touches.values()):
            rows += [r["when"] for r in group if "when" in r]
        return rows

    def last_keys(self):
        """直前の手（event.last）の値。"""
        return (["pre." + k for k in self.pre] + ["pos." + k for k in self.positions] + ["fore." + r["id"] for r in self.foreplay]
                + ["insert"] + ["move." + p for p in PACES] + ["touch." + k for k in self.touches] + (["hush"] if self.exposure else []))


class EventRules:
    def __init__(self, raw):
        ensure(type(raw) is dict, "intimacy_data", "イベントの節が不正。")
        self.events = {}
        for key, row in raw.items():
            if key == "_note":
                continue
            ensure(key in KINDS, "intimacy_data", "イベントの種類が未登録（入口のないイベント）。")
            self.events[key] = EventDef(key, row)
        ensure(self.events, "intimacy_data", "イベントがない。")

    def positions(self):
        return sorted({key for event in self.events.values() for key in event.positions})

    def last_keys(self):
        return sorted({key for event in self.events.values() for key in event.last_keys()})

    def check_content(self, fields, meanings, validate_condition):
        for event in self.events.values():
            for when in event.conditions():
                validate_condition(when, fields)
            missing = [m for m in event.meanings() if m not in meanings]
            ensure(not missing, "meaning", "イベントの本文の意味が未登録：" + "、".join(missing[:5]))
