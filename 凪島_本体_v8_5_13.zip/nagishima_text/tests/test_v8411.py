"""v8.4.11（ユーザー 2026-10-07 07:16「進めて」）：010 だけ。
本文ごとに最後に出た番号を保存（text_seen）に覚え、同じ条件で選べる本文の中では、いちばん長く出ていない本文から出す（settings.text_memory）。
最近の本文の記録（256本）より前に出た本文も覚えているので、エッチの回をまたいでも同じ本文がくじ引きで戻ってこない。
部品を組み合わせて作る本文（cmp.<場面>.<a>.<b>、試作は手をつなぐ）：部品ごとに覚え、同じ部品がすぐ戻らない。"""
import re
import unittest
from copy import deepcopy
from pathlib import Path

from nagishima.content import Pack
from nagishima.errors import GameError
from nagishima.state import validate_state
from tools.run_stage_b_routes import Route

ROOT = Path(__file__).resolve().parents[1]
P009 = Pack(ROOT / "content/releases/interaction_009")
P010 = Pack(ROOT / "content/releases/interaction_010")


def act(route, key):
    while route.engine.snapshot()["offer"]:
        route.choose("offer.decline")
    route.action(key)


class V8411(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        route = Route(8461, tier="familiar", release="interaction_010", hour=21, day_offset=2)
        try:
            route.begin()
            act(route, "h_kiss_deep")
            cls.state = route.engine.snapshot()
            cls.repository = route.engine.repository
        finally:
            route.close()

    def test_009_unchanged(self):
        self.assertIsNone(P009.intimacy.text_memory)
        route = Route(8461, tier="familiar", release="interaction_009", hour=21, day_offset=2)
        self.addCleanup(route.close)
        route.begin()
        self.assertNotIn("text_seen", route.engine.snapshot())

    def test_memory_recorded_and_valid(self):
        self.assertEqual(P010.intimacy.text_memory["horizon"], 4000)  # v8.4.14：composed（組み合わせた本文の比べ方）も持つ
        last = self.state["text_seen"]["last"]
        self.assertTrue(last)
        self.assertTrue(all(0 <= value < self.state["world"]["rng"]["text"] for value in last.values()))
        validate_state(deepcopy(self.state), P010, self.repository)

    def test_rotates_beyond_recent_window(self):
        """最近の本文の記録を毎回消しても（エッチの回をまたいだのと同じ）、同じ本文に戻らずに回る。"""
        state = deepcopy(self.state)
        state["contacts"] = []
        picks = []
        for _ in range(8):
            state["recent_text"] = []
            picks.append(P010.select("h_hug.start", state, {}, P010.registry.values(state))[0]["variant"])
        # 出せる本文が一巡するまで同じ本文は出ず、一巡したら同じ順で回る（この状態で出せる本文は 3本しかない）
        size = len(set(picks))
        self.assertGreaterEqual(size, 3)
        self.assertEqual(len(set(picks[:size])), size, picks)
        self.assertEqual(picks[size:2 * size], picks[:size][:len(picks[size:2 * size])], picks)
        # 覚えていなければ（009 と同じ選び方）、同じ状態からは毎回同じ本文に戻りうる
        self.assertIn(P010._memory_keys(P010.by_text[picks[0]])[0], state["text_seen"]["last"])

    def test_oldest_first(self):
        state = deepcopy(self.state)
        state["contacts"] = []
        state["recent_text"] = []
        first = P010.select("h_hug.start", deepcopy(state), {}, P010.registry.values(state))[0]["variant"]
        # いま選ばれた本文を「ずっと前に出た」、ほかの候補をすべて「そのあとに出た」ことにすると、いちばん前の本文に戻る
        serial = state["world"]["rng"]["text"]
        last = state["text_seen"]["last"]
        for text in P010.by_meaning["h_hug.start"]:
            for key in P010._memory_keys(text):  # v8.4.14：組み合わせた本文（抱きしめる）は部品の鍵が二つ
                last[key] = serial - 10
        for key in P010._memory_keys(P010.by_text[first]):
            last[key] = serial - 3000
        self.assertEqual(P010.select("h_hug.start", deepcopy(state), {}, P010.registry.values(state))[0]["variant"], first)

    def test_short_line_shares_key(self):
        short = next(t for t in P010.by_text.values() if t["id"].startswith("sh.") and t["id"][3:] in P010.by_text)
        self.assertEqual(P010._memory_keys(short), P010._memory_keys(P010.by_text[short["id"][3:]]))

    def test_old_entries_dropped(self):
        state = deepcopy(self.state)
        serial = state["world"]["rng"]["text"] = 10000
        last = state["text_seen"]["last"] = {format(n, "010x"): 100 + n for n in range(4300)}
        P010.select("h_hug.start", state, {}, P010.registry.values(state))
        self.assertLess(len(last), 4000)
        self.assertTrue(all(value >= serial - 4000 for value in last.values()))

    def test_bad_record_rejected(self):
        for bad in ({"last": {"XYZ": 1}}, {"last": {"0123456789": 10 ** 9}}, {"last": {}, "extra": 1}):
            state = deepcopy(self.state)
            state["text_seen"] = bad
            with self.assertRaises(GameError):
                validate_state(state, P010, self.repository)

    def test_composed_hands(self):
        # v8.4.19 で六束目の後半とつなぎ直す前半を足したので、v8.4.11 の部品どうし（a01〜a09 × b01〜b14）だけを数える
        rows = [t for t in P010.by_meaning["h_hands.start"] if re.fullmatch(r"cmp\.h_hands\.start\.a0\d\.b\d\d", t["id"])]
        self.assertEqual(len(rows), 108)
        self.assertFalse(any(t["id"].startswith("cmp.") for t in P009.by_text.values()))
        for text in rows:
            when = text["when"]["all"]
            self.assertIn({"field": "intimacy.tier", "op": "in", "value": ["few", "familiar"]}, when)
            self.assertEqual(len(P010._memory_keys(text)), 2)
            if "唇" in text["body"] or "こちらを見て" in text["body"]:
                self.assertIn({"field": "contact.h_kiss_deep.active", "op": "eq", "value": False}, when)
            if re.search("真帆の中|中も|つながったところ", text["body"]):
                self.assertIn({"field": "intimacy.inserted", "op": "eq", "value": True}, when)

    def test_composed_parts_do_not_return_soon(self):
        """手をつなぐを何度も（回をまたいで）選んでも、真帆の反応の部品は一巡するまで戻らない。"""
        state = deepcopy(self.state)
        state["contacts"] = []
        reactions = []
        for _ in range(16):
            state["recent_text"] = []
            chosen = P010.select("h_hands.start", state, {}, P010.registry.values(state))[0]["variant"]
            if chosen.startswith("cmp."):
                reactions.append(chosen.rsplit(".", 1)[1])
        self.assertGreaterEqual(len(reactions), 8)
        self.assertEqual(len(set(reactions[:8])), 8, reactions)


if __name__ == "__main__":
    unittest.main()
