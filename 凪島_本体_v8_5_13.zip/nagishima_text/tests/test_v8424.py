"""v8.4.24（ユーザー 2026-10-07 13:41「進めろ。次があるだろ」）：010 だけ。
本文の再会を減らす 十束目（不足の一覧で本数が足りなかった場面に、一本で完結する本文を足す）。"""
import unittest
from pathlib import Path

from nagishima.content import Pack

ROOT = Path(__file__).resolve().parents[1]
P009 = Pack(ROOT / "content/releases/interaction_009")
P010 = Pack(ROOT / "content/releases/interaction_010")
NEW = [t for t in P010.texts if t["id"].startswith("v8424.")]
KISS_OFF = {"field": "contact.h_kiss_deep.active", "op": "eq", "value": False}
FF = {"field": "intimacy.tier", "op": "in", "value": ["few", "familiar"]}


def has(text, field, op, value):
    return {"field": field, "op": op, "value": value} in text["when"]["all"]


class V8424(unittest.TestCase):
    def test_009_unchanged(self):
        self.assertFalse(any(t["id"].startswith("v8424.") for t in P009.texts))

    def test_new_texts(self):
        self.assertEqual({t["meaning"] for t in NEW}, {"h_pos_sitting_face.start", "h_hands_both.start", "h_chest_over.side_left", "h_chest_over.side_right",
                                                      "h.ended.deadline", "offer.h_lead.takein", "h.sign.wants_more"})
        self.assertGreaterEqual(len(NEW), 45)
        for text in NEW:
            self.assertTrue(text["group"].startswith(f"v8424.{text['meaning']}."), text["id"])
            if text["meaning"] != "offer.h_lead.takein":
                self.assertIn(FF, text["when"]["all"], text["id"])  # 何度か・慣れただけ（初めての回は前からある本文）
            if "「" in text["body"]:
                self.assertIn(KISS_OFF, text["when"]["all"], text["id"])  # 深く口づけているあいだは台詞を出さない
            for word in ("確かめるように", "肩をすくめ", "睫毛を伏せ", "目を細め"):
                self.assertNotIn(word, text["body"], text["id"])
            if text["meaning"] == "h_pos_sitting_face.start":  # 移る前の体位ごとの本文（前からある本文と同じく先に出す）
                self.assertTrue(any(c.get("field") == "intimacy.position_from" and c.get("op") == "in" for c in text["when"]["all"]), text["id"])
            if text["meaning"] == "h.sign.wants_more":  # 入れているときの合図
                self.assertTrue(has(text, "intimacy.inserted", "eq", True), text["id"])
                for word in ("先へ", "中まで", "入れて"):
                    self.assertNotIn(word, text["body"], text["id"])
            if text["meaning"] == "h_hands_both.start" and text["group"].endswith(".close"):
                self.assertTrue(has(text, "intimacy.inserted", "eq", False), text["id"])
            if text["meaning"] != "h.ended.deadline":
                for word in ("おしまい", "ここまで", "寝よう"):
                    self.assertNotIn(word, text["body"], text["id"])

    def test_own_contact_not_blocked(self):
        """その手の本文を出すときには、その手の触れ合い（両手をつなぐ など）はもう始まっている。「その触れ合いでないとき」の条件がつくと一度も出ない
        （v8.4.24 の通しで、両手をつなぐの新しい本文 10本が出なかった。前からある本文 2本も同じだった）。"""
        for text in P010.texts:
            own = {"field": f"contact.{text['meaning'].split('.')[0]}.active", "op": "eq", "value": False}
            self.assertNotIn(own, text["when"].get("all", []), text["id"])

    def test_review_fixes(self):
        """読む係の指摘（v8424/read）：真帆が両手を使う本文は腕を引かれているあいだは出さない、背を向けているときに顔へ触れない、ゲームが知らないことを決めない。"""
        by_id = {t["id"].rsplit(".", 1)[1]: t for t in NEW}
        for name in ("j2sfonme02", "j2sfonme03", "j4sfstand02", "j1tkfam02", "j4tkfam01", "j2wiface01", "j3wiface03"):
            self.assertTrue(has(by_id[name], "contact.h_arm_pull_one.active", "eq", False), name)
        for name in ("j2edwork02", "j3edwork01", "j4tkfam01", "j1coleft02"):
            self.assertTrue(has(by_id[name], "intimacy.facing", "eq", "face"), name)
        # 2回目（通しの 33 場面）：真帆が上では背中に腕を回せない、止まっているのに「速く」をせがまない、胸に口をつけているあいだは申し出の仕草をしない
        self.assertTrue(has(by_id["j2wiface01"], "intimacy.position", "ne", "maho_above"))
        self.assertTrue(any("any" in c and {"field": "contact.h_move_fast.active", "op": "eq", "value": True} in c["any"] for c in by_id["j3wiface03"]["when"]["all"]))
        for text in NEW:
            if text["meaning"] == "offer.h_lead.takein":
                self.assertTrue(has(text, "contact.h_chest_mouth.active", "eq", False), text["id"])
            if text["meaning"] == "h.ended.deadline":
                self.assertFalse(text["body"].startswith("「うん、"), text["id"])  # 直前に真帆が言い出していても、応じる形にしない
        self.assertTrue(has(by_id["j2coright02"], "intimacy.position", "ne", "prone_back"))
        for name in ("j3sfedge01", "j4sfbed03", "j1hbpa03", "j3hbmaho03", "j4coright02", "j2edholiday02", "j2tkfam01", "j1wiface01", "j2wiback02", "j4wiface03", "j3coleft02"):
            self.assertNotIn(name, by_id)
        for text in NEW:
            for word in ("コーヒー", "巡回", "点検", "二、三歩", "踏みしめ"):
                self.assertNotIn(word, text["body"], text["id"])


if __name__ == "__main__":
    unittest.main()
