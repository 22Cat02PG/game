"""Public Stage B play paths. Setup cheats only establish the relationship."""
import tempfile
import unittest
from pathlib import Path
from copy import deepcopy

from nagishima.engine import Engine


class StageBPublicPaths(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.engine = Engine(self.temp.name, seed=42, release="interaction_009", autosave=False, test_cheats=True)
        self.engine.enable_test_cheat("all")
        # Only the clock is prepared internally; every judged action is public.
        today = self.engine._state["world"]["now"] // 1440
        self.engine._state["world"]["now"] = today * 1440 + 19 * 60
        self.engine._state["world"]["processed_until"] = self.engine._state["world"]["now"]
        self.engine._install_choices()
        from tools.run_stage_b_routes import dinner_done, bath_done
        dinner_done(self.engine)  # v8.1.0：自動の夕食は済んだことにする（準備）
        bath_done(self.engine)  # v8.2.0：自動の風呂も同じ

    def choose(self, identity):
        view = self.engine.get_view()
        option = next((c for c in view["choices"] if c["id"] == identity), None)
        self.assertIsNotNone(option, identity)
        self.assertTrue(option["available"], (identity, option))
        return self.engine.choose(identity, view["revision"], view["session"])

    def test_b11_entry_and_first_full_path(self):
        self.choose("private.begin")
        self.choose("menu.touch")
        self.choose("touch.h_kiss_deep")
        self.assertEqual(self.engine.snapshot()["intimacy"]["position"], "sitting_close")
        for _ in range(9):
            self.choose("touch.h_kiss_deep")
        self.assertGreaterEqual(self.engine.snapshot()["intimacy"]["maho"]["arousal"], 40)
        self.choose("menu.h_clothes")
        self.choose("touch.h_lift_upper")
        self.choose("touch.h_strip_lower")
        self.choose("touch.h_shift_under")
        self.choose("touch.h_strip_self")
        self.choose("menu.main")
        self.choose("menu.h_position")
        self.choose("touch.h_pos_player_above")
        self.choose("menu.main")
        self.choose("menu.h_connect")
        self.choose("touch.h_insert")
        self.choose("touch.h_move_slow")
        for _ in range(5):  # v8.2.29：入れてから果てるまでを長くした（ゆっくり動く6手で出せる高さ）
            self.choose("touch.h_move_slow")
        self.choose("menu.main")
        self.choose("touch.h_finish_inside")
        self.assertEqual(self.engine.snapshot()["stamina"]["value"], 2)
        self.choose("h.end")
        self.assertEqual(self.engine.snapshot()["offer"]["kind"], "hold_back")
        self.choose("offer.decline")
        self.assertIsNone(self.engine.snapshot()["intimacy"])
        self.assertEqual(self.engine.snapshot()["intimacy_history"]["count"], 1)

    def test_b11_three_entries_clear_previous_contact_silently(self):
        from tools.run_stage_b_routes import Route
        for entry in ("h_kiss_deep", "h_chest_over", "h_thigh"):
            route = Route(42)
            try:
                route.choose("private.begin")
                route.choose("menu.touch")
                route.choose("touch.hands")
                route.choose("menu.main")
                route.choose("menu.touch")
                route.choose("touch." + entry)
                self.assertEqual(route.engine.snapshot()["intimacy"]["position"], "sitting_close")
                self.assertFalse(any(c["action_id"] == "hands" for c in route.engine.snapshot()["contacts"]))
                self.assertFalse(any(m.startswith("hands.") for m in route.status()["blocks"]))
            finally: route.close()

    def test_b10_save_load_during_session_and_question(self):
        self.choose("private.begin")
        self.choose("menu.touch")
        self.choose("touch.h_kiss_deep")
        before = self.engine.get_view()["choices"]
        self.engine.save("slot01")
        self.choose("h.end")
        self.engine.load("slot01")
        self.assertEqual(self.engine.get_view()["choices"], before)
        self.choose("h.end")
        self.assertEqual(self.engine.snapshot()["offer"]["kind"], "hold_back")
        before = self.engine.get_view()["choices"]
        self.engine.save("slot02")
        self.choose("offer.accept")
        self.engine.load("slot02")
        self.assertEqual(self.engine.get_view()["choices"], before)

    def test_b10_inserted_and_maho_offer_save_load(self):
        from tools.run_stage_b_routes import Route
        route = Route(43, tier="few", day_offset=2)  # v8.2.30：上になる申し出はその回に一度だけ決める（seed 42 の回は申し出ない）
        try:
            route.begin()
            route.action("h_strip_lower")
            route.action("h_strip_self")
            for _ in range(16):
                if route.engine.snapshot()["offer"]: break
                route.action("h_kiss_deep")
            self.assertEqual(route.engine.snapshot()["offer"]["kind"], "h_lead_straddle")
            before = route.engine.get_view()["choices"]
            route.engine.save("slot03")
            route.choose("offer.accept")
            route.engine.load("slot03")
            self.assertEqual(route.engine.get_view()["choices"], before)
            route.choose("offer.accept")
            route.action("h_shift_under")
            route.action("h_insert")
            self.assertTrue(route.engine.snapshot()["intimacy"]["inserted"])
            before = route.engine.get_view()["choices"]
            route.engine.save("slot04")
            route.action("h_move_normal")
            route.engine.load("slot04")
            self.assertEqual(route.engine.get_view()["choices"], before)
        finally: route.close()

    def test_b12_time_decline_and_quiet(self):
        now = self.engine._state["world"]["now"]
        self.engine._state["world"].update(now=now + 151, processed_until=now + 151)
        self.engine._install_choices()
        self.choose("private.begin")
        self.choose("menu.touch")
        self.choose("touch.h_kiss_deep")
        self.assertEqual(self.engine.get_view()["blocks"][-1]["meaning"], "h.decline.time")
        self.assertIsNone(self.engine.snapshot()["intimacy"])
        self.assertEqual(next(c for c in self.engine.get_view()["choices"] if c["id"] == "touch.h_kiss_deep")["reason"], "h_quiet")

    def test_b12_exact_start_boundaries_both_nights(self):
        from tools.run_stage_b_routes import Route
        for offset, hour, minute, accepted in ((0, 21, 25, True), (0, 21, 26, False),
                                                (3, 0, 55, True), (3, 0, 56, False)):
            route = Route(42, tier="few", day_offset=offset, hour=hour, minute=minute)  # v8.2.30：初めての回は締め切りまで60分ないと始めないので、数回で確かめる
            try:
                route.begin()
                self.assertEqual(route.engine.snapshot()["intimacy"] is not None, accepted)
                if not accepted: self.assertIn("h.decline.time", route.status()["blocks"])
            finally: route.close()

    def test_b15_b20_time_and_repetition_cap(self):
        self.choose("private.begin")
        self.choose("menu.touch")
        before = self.engine.snapshot()["world"]["now"]
        self.choose("touch.h_kiss_deep")
        self.assertEqual(self.engine.snapshot()["world"]["now"] - before, 3)
        for _ in range(29):
            self.choose("touch.h_kiss_deep")
        state = self.engine.snapshot()
        self.assertEqual(state["intimacy"]["maho"]["arousal"], 60)
        self.assertEqual(state["intimacy"]["maho"]["satisfaction"], 4)
        activity = next(a for a in state["activities"] if a["id"] == state["private_instance"])
        self.assertEqual(activity["charged_minutes"], 90)

    def test_b42_menus_bounded_and_status(self):
        self.choose("private.begin")
        self.choose("menu.touch")
        self.choose("touch.h_kiss_deep")
        for page in ("h_touch", "h_clothes", "h_position", "h_connect", "h_words"):
            self.choose("menu." + page)
            view = self.engine.get_view()
            self.assertLessEqual(len(view["choices"]), 32)
            self.assertIn("player_arousal", view["status"]["intimacy"])
            self.choose("menu.main")

    def test_b44_tier_cheat(self):
        for tier, count in (("first", 0), ("few", 1), ("familiar", 5)):
            result = self.engine.enable_test_cheat("intimacy_tier:" + tier)
            self.assertEqual(result["tier"], tier)
            self.assertEqual(self.engine.snapshot()["intimacy_history"]["count"], count)
        self.choose("private.begin")
        self.choose("menu.touch")
        self.choose("touch.h_kiss_deep")
        from nagishima.errors import GameError
        with self.assertRaises(GameError):
            self.engine.enable_test_cheat("intimacy_tier:first")

    def test_b04_schema3_007_008_save_migrates_neutrally(self):
        import json
        import shutil
        for release in ("interaction_007", "interaction_008"):
            for cheated in (False, True):
                with self.subTest(release=release, cheated=cheated), tempfile.TemporaryDirectory() as root:
                    path = Path(root) / "saves" / "slot01.json"
                    path.parent.mkdir()
                    fixture = Path(__file__).resolve().parent / "fixtures" / f"v712_{release}_{'cheat' if cheated else 'normal'}.json"
                    shutil.copyfile(fixture, path)
                    record = json.loads(path.read_text(encoding="utf-8"))
                    self.assertEqual((record["schema"], record["rules_version"]), (3, "nagishima-2.3"))
                    newer = Engine(root, seed=42, release=release, autosave=False, test_cheats=cheated)
                    newer.load("slot01")
                    if release == "interaction_008":
                        newer.adopt_release("interaction_009")
                        state = newer.snapshot()
                        self.assertEqual(state["stamina"]["value"], 3)
                        self.assertEqual(state["intimacy_history"]["count"], 0)
                        self.assertIsNone(state["intimacy"])
                    newer.save("slot02")
                    saved = json.loads((Path(root) / "saves" / "slot02.json").read_text(encoding="utf-8"))
                    self.assertEqual(saved["schema"], 4)

    def test_b06_intimacy_declaration_rejects_invalid_sections(self):
        from nagishima.intimacy_rules import IntimacyRules
        from nagishima.errors import GameError
        source = self.engine.pack.intimacy.raw
        changes = (
            lambda x: x.pop("settings"),
            lambda x: x["session"].update(min_minutes=2000),
            lambda x: x["nights"]["holiday_eve"].update(private_until="25:00"),
            lambda x: x["maho"]["arousal_bands"].update(mid_from=99),
            lambda x: x["positions"]["lying_face"]["postures"].update(maho="flying"),
            lambda x: x["actions"]["h_insert"]["positions"].append("missing"),
            lambda x: x["actions"]["h_touch_direct"]["needs"].update(maho_ready=None),
            lambda x: x["settings"]["term_presets"]["standard"].update(penis="unlisted"),
        )
        for change in changes:
            raw = deepcopy(source)
            change(raw)
            with self.subTest(change=change), self.assertRaises(GameError) as caught:
                IntimacyRules(raw, self.engine.pack.catalog, self.engine.pack.actions)
            self.assertEqual(caught.exception.code, "intimacy_data")

    def test_b09_save_crossfield_invariants(self):
        from nagishima.state import validate_state
        from nagishima.errors import GameError
        self.choose("private.begin")
        self.choose("menu.touch")
        self.choose("touch.h_kiss_deep")
        original = self.engine.snapshot()
        edits = (
            lambda s: s.update(mode="normal"),
            lambda s: s["intimacy"]["maho"].update(arousal=101),
            lambda s: s["stamina"].update(value=4),
            lambda s: s["actors"]["maho"].update(posture="standing"),
            lambda s: s["intimacy"].update(inserted=True),
            lambda s: s["actors"]["maho"]["clothing"].update(lower="invalid"),
            lambda s: s["intimacy"].update(wrap_up=1),
            lambda s: s["intimacy"]["player"].update(refractory=7),  # v8.2.34：不応期の上限は refractory_actions × 余力の最大（2×3）
            lambda s: s["intimacy_history"].update(count=1),
            lambda s: s["settings"].update(density="invalid"),
        )
        for edit in edits:
            state = deepcopy(original)
            edit(state)
            with self.subTest(edit=edit), self.assertRaises(GameError):
                validate_state(state, self.engine.pack, self.engine.repository, True)

    def test_b14_active_menu_excludes_daily_actions(self):
        self.choose("private.begin")
        self.choose("menu.touch")
        self.choose("touch.h_kiss_deep")
        visible = {choice["id"] for choice in self.engine.get_view()["choices"]}
        self.assertIn("h.end", visible)
        self.assertFalse(visible & {"menu.move", "menu.activities", "menu.orders", "private.end", "sleep"})

    def test_b14_maho_waits_past_bedtime_until_end(self):
        from tools.run_stage_b_routes import Route
        route = Route(42, tier="few", day_offset=3, hour=0, minute=50)  # v8.2.30：初めての回は締め切りまで60分ないと始めないので、数回で確かめる
        try:
            route.begin()
            while route.engine.snapshot()["world"]["now"] < route.engine.pack.intimacy.deadline(route.engine.snapshot()["world"]["now"], route.engine.pack.life):
                route.action("h_kiss_deep")
            self.assertEqual(route.engine.snapshot()["maho_sleep"]["state"], "awake")
            if route.engine.get_view()["page"] != "main": route.choose("menu.main")
            route.choose("h.end")
            # B2：夜に終えたら、そのまま一緒に眠って翌朝へ（真帆は目覚めている）
            self.assertTrue({"h.sleep_together.satisfied", "h.sleep_together.unsatisfied"} & set(route.status()["blocks"]))
            self.assertEqual(route.engine.snapshot()["maho_sleep"]["state"], "awake")
        finally: route.close()

    def test_b48_a2_written_tiers_and_public_dialogue_rate(self):
        from nagishima.content import Pack
        from tools.check_a2_text_integration import touch_measure
        pack = Pack(Path(__file__).resolve().parents[1] / "content/releases/interaction_008")
        for tier, meaning in (("first", "cheek.heated"), ("few", "cheek.heated"), ("familiar", "cheek.start")):
            authored = [item for item in pack.by_meaning[meaning] if not item["fallback"] and
                        item["when"] == {"field": "experience.cheek.tier", "op": "eq" if tier == "familiar" else "ne", "value": "familiar"}]
            self.assertGreaterEqual(len(authored), 3, (tier, meaning))
        for seed in (42, 20380407):
            old = touch_measure("interaction_007", seed, "hands", count=30)
            new = touch_measure("interaction_008", seed, "hands", count=30)
            self.assertEqual(old["dialogue"], 30)
            self.assertLessEqual(new["dialogue"], 15)

    def test_b35_no_history_prevents_invitation(self):
        self.choose("near")
        self.choose("menu.touch")
        for _ in range(25):
            if self.engine.snapshot()["offer"]:
                self.choose("offer.decline")
                if self.engine.get_view()["page"] != "touch": self.choose("menu.touch")
            self.choose("touch.kiss")
        state = self.engine.snapshot()
        self.assertGreaterEqual(state["desire"], 60)
        self.assertEqual(state["intimacy_history"]["count"], 0)
        self.assertFalse(self.engine.pack.registry.values(state)["intimacy.invite_ready"])

    def test_b36_settings_save_load_and_public_terms(self):
        self.choose("menu.settings")
        self.choose("settings.preset.mild")
        self.assertFalse(any(c["id"].startswith("settings.density.") for c in self.engine.get_view()["choices"]))  # v8.2.2：009 は濃さを選ばない
        self.choose("settings.gauges.hidden")  # v8.2.29：台詞の多さは選ばない。呼び方を1つずつ選ぶのは別のページ
        self.choose("menu.settings_terms")
        term = next(c["id"] for c in self.engine.get_view()["choices"] if c["id"].startswith("settings.term.penis."))
        self.choose(term)
        expected = self.engine.snapshot()["settings"]
        self.engine.save("slot01")
        self.choose("menu.main")
        self.engine.load("slot01")
        self.assertEqual(self.engine.snapshot()["settings"], expected)

    def test_b37_reject_quoted_slot_and_old_style(self):
        from nagishima.content import validate_text, Pack
        from nagishima.errors import GameError
        term = {"id": "test.quoted", "meaning": "h.feel.first", "when": {"all": []}, "slots": ["penis"],
                "group": "test.quoted", "body": "「{penis}」", "fallback": False}
        with self.assertRaises(GameError):
            validate_text(term, self.engine.pack.registry, self.engine.pack.meanings, self.engine.pack.intimacy)
        old = Pack(Path(__file__).resolve().parents[1] / "content/releases/interaction_008")
        styled = {"id": "test.style", "meaning": "head.start", "when": {"all": []}, "slots": [],
                  "group": "test.style", "body": "試験。", "fallback": False, "style": "explicit"}
        with self.assertRaises(GameError):
            validate_text(styled, old.registry, old.meanings, old.intimacy)

    def test_b38_density_selects_matching_style(self):
        pack = self.engine.pack
        meaning = "h.feel.first"
        plain = {"id": "test.plain", "meaning": meaning, "when": {"all": []}, "slots": [], "group": "test.plain", "body": "標準。", "fallback": False}
        styled = {**plain, "id": "test.explicit", "group": "test.explicit", "body": "露骨。", "style": "explicit"}
        pack.by_meaning[meaning] = [plain, styled]
        pack.by_text.update({plain["id"]: plain, styled["id"]: styled})
        intensity = pack.intimacy.settings.pop("intensity")  # 008 までの形（描写の濃さの設定で選ぶ）を確かめる
        try:
            for density, expected in (("standard", "test.plain"), ("explicit", "test.explicit")):
                state = self.engine.snapshot()
                state["settings"]["density"] = density
                self.assertEqual(pack.select(meaning, state, {})[0]["variant"], expected)
        finally:
            pack.intimacy.settings["intensity"] = intensity
        # v8.2.2（009）：高まりで決まる。エッチの外（低い）は標準、真帆の高まりが高いと濃い本文
        state = self.engine.snapshot()
        self.assertEqual(pack.select(meaning, state, {}, {})[0]["variant"], "test.plain")
        state["intimacy"] = {"maho": {"arousal": 85}, "player": {"arousal": 0}}
        self.assertEqual(pack.select(meaning, state, {}, {})[0]["variant"], "test.explicit")

    def test_b41_fallback_complete_and_ascii_ids(self):
        import re
        pack = self.engine.pack
        self.assertTrue(all(sum(item["fallback"] for item in pack.by_meaning[meaning]) == 1 for meaning in pack.meanings))
        self.assertTrue(all(not item["slots"] for item in pack.texts if item["fallback"]))
        self.assertTrue(all(re.fullmatch(r"[a-z0-9_.-]+", item["id"]) for item in pack.texts))

    def test_b40_hidden_and_shown_gauges_without_cheats(self):
        from nagishima.autoplay import next_command
        with tempfile.TemporaryDirectory() as root:
            engine = Engine(root, seed=42, release="interaction_009", autosave=False)
            for _ in range(150):
                if engine.snapshot()["relation"]["stage"] >= 3: break
                command = next_command(engine.get_view(), engine.snapshot())
                self.assertIsNotNone(command)
                view = engine.get_view()
                engine.choose(command["id"], view["revision"], view["session"])
            self.assertEqual(engine.snapshot()["relation"]["stage"], 3)
            def pick(identity):
                view = engine.get_view()
                choice = next(c for c in view["choices"] if c["id"] == identity)
                self.assertTrue(choice["available"], identity)
                return engine.choose(identity, view["revision"], view["session"])
            # B2：真帆の数値は既定で表示する（棒で）。設定で隠せる。
            self.assertEqual(engine.snapshot()["settings"]["gauges"], "shown")
            pick("menu.settings")
            pick("settings.gauges.hidden")
            pick("menu.main")
            pick("private.begin")
            pick("menu.touch")
            pick("touch.h_kiss_deep")
            self.assertNotIn("maho_arousal", engine.get_view()["status"]["intimacy"])
            self.assertNotIn("maho_arousal_bar", engine.get_view()["status"]["intimacy"])

    def test_b39_speech_spacing_applies_to_intimacy_meaning(self):
        import hashlib
        pack = self.engine.pack
        meaning = "h_kiss_deep.continue"
        state = self.engine.snapshot()
        state["recent_text"] = [{"id": "test.old.dialogue", "group": "test.old.dialogue", "release": pack.id},
                                {"id": "test.old.plain1", "group": "test.old.plain1", "release": pack.id},
                                {"id": "test.old.plain2", "group": "test.old.plain2", "release": pack.id}]
        pack.by_text["test.old.dialogue"] = {"body": "「話す」"}
        pack.by_text["test.old.plain1"] = {"body": "一つ。"}
        pack.by_text["test.old.plain2"] = {"body": "二つ。"}
        plain = {"id": "test.plain", "meaning": meaning, "when": {"all": []}, "slots": [], "group": "test.plain", "body": "地の文。", "fallback": False}
        prefix = f"{state['world']['seed']}:{state['world']['rng']['text']}:".encode("ascii")
        plain_hash = hashlib.sha256(prefix + plain["id"].encode("ascii")).digest()
        index = next(i for i in range(100) if hashlib.sha256(prefix + f"test.dialogue.{i}".encode("ascii")).digest() < plain_hash)
        spoken = {**plain, "id": f"test.dialogue.{index}", "group": "test.spoken", "body": "「話している」"}
        pack.by_meaning[meaning] = [plain, spoken]
        # v8.2.29（ユーザー 2026-09-30）：009 では「台詞の多さ」を選ばせない（前の保存の設定は使わず、既定の多さで間を空ける）
        for speech in ("few", "standard", "many"):
            sample = deepcopy(state)
            sample["settings"]["speech"] = speech
            self.assertEqual(pack.select(meaning, sample, {})[0]["variant"], spoken["id"])  # 既定（ふつう）の間なら、この並びでは台詞を出せる

    def test_b13_rested_boundary(self):
        from tools.run_stage_b_routes import Route, satisfied
        for elapsed, expected_decline in ((180, True), (181, False)):
            route = Route(42, day_offset=3, hour=13)  # B2：夜に終えると翌朝になるので、休日の昼に確かめる
            try:
                satisfied(route)
                last = route.engine.snapshot()["intimacy_history"]["last_at"]
                route.choose("private.begin")  # v8.2.29：終えたあとは居間へ移るので、部屋へ移ってから時刻を合わせる
                route.engine._state["world"].update(now=last + elapsed, processed_until=last + elapsed)
                route.engine._install_choices()
                route.choose("menu.touch")
                route.choose("touch.h_kiss_deep")
                self.assertEqual(route.engine.snapshot()["intimacy"] is None, expected_decline)
                if expected_decline:
                    self.assertEqual(route.status()["blocks"][-1], "h.decline.rested")
            finally: route.close()

    def test_b17_read_air_on_both_nights(self):
        from tools.run_stage_b_routes import Route
        for day_offset, hour, minute in ((0, 21, 24), (3, 0, 55)):
            route = Route(42, tier="few", day_offset=day_offset, hour=hour, minute=minute)  # v8.2.30：初めての回は締め切りまで60分ないと始めないので、数回で確かめる
            try:
                route.begin()
                route.choose("h.end")
                self.assertIn("h.ended.read_air", route.status()["blocks"])
                self.assertIsNone(route.engine.snapshot()["intimacy"])
            finally: route.close()

    def test_b18_holiday_night_and_sunday_kind(self):
        from tools.run_stage_b_routes import Route
        cases = ((2, 22, 0, "holiday_eve"), (3, 0, 30, "holiday_eve"), (4, 19, 0, "workday_eve"))
        for offset, hour, minute, expected in cases:
            route = Route(42, tier="few", day_offset=offset, hour=hour, minute=minute)  # v8.2.30：初めての回は締め切りまで60分ないと始めないので、数回で確かめる
            try:
                rules = route.engine.pack.intimacy
                self.assertEqual(rules.night_kind(route.engine.snapshot()["world"]["now"], route.engine.pack.life), expected)
                route.begin()
                self.assertIsNotNone(route.engine.snapshot()["intimacy"])
            finally: route.close()
        route = Route(42, tier="few", day_offset=3, hour=1, minute=30)  # v8.2.30：初めての回は締め切りまで60分ないと始めないので、数回で確かめる
        try:
            route.choose("listen")
            self.assertEqual(route.engine.snapshot()["maho_sleep"]["state"], "asleep")
        finally: route.close()

    def test_b19_work_block_restricts_action_but_end_remains(self):
        from tools.run_stage_b_routes import Route
        route = Route(42, tier="few", hour=12, minute=24)  # v8.2.30：初めての回は締め切りまで60分ないと始めないので、数回で確かめる
        try:
            route.begin()
            # v8.2.29（ユーザー 2026-09-30）：仕事の始まりは、この回の締め切り（真帆の一言 h.deadline.work と残りの手）。
            # そのあとは口づけを続けられず（h_deadline）、「終える」は選べて、仕事へ戻る一言（h.ended.work）
            seen = []
            for _ in range(20):
                action = next((c for c in route.engine.get_view()["choices"] if c["id"] == "touch.h_kiss_deep"), None)
                if action is None or not action["available"]:
                    break
                route.action("h_kiss_deep")
                seen += route.status()["blocks"]
            self.assertIn("h.deadline.work", seen)
            self.assertEqual(action["reason"], "h_deadline")
            route.choose("h.end")
            if route.engine.snapshot()["offer"]: route.choose("offer.decline")
            self.assertIsNone(route.engine.snapshot()["intimacy"])
            self.assertIn("h.ended.work", route.status()["blocks"])
        finally: route.close()

    def test_b23_deflect_and_ready_reason(self):
        from tools.run_stage_b_routes import Route
        route = Route(42)
        try:
            route.begin()
            route.action("h_strip_lower")
            route.action("h_shift_under")
            route.action("h_pos_lying_face")
            before = route.engine.snapshot()["world"]["now"]
            route.action("h_touch_direct")
            self.assertEqual(route.status()["blocks"][-1], "h.deflect.hand")
            self.assertEqual(route.engine.snapshot()["world"]["now"] - before, 1)
            self.assertIn("h_touch_direct", route.engine.snapshot()["intimacy"]["deflected"])
            choice = next(c for c in route.engine.get_view()["choices"] if c["id"] == "touch.h_touch_direct")
            self.assertEqual(choice["reason"], "h_ready")
            while route.engine.snapshot()["intimacy"]["maho"]["arousal"] < 40:
                route.action("h_kiss_deep")
            route.action("h_touch_direct")
            self.assertNotIn("h_touch_direct", route.engine.snapshot()["intimacy"]["deflected"])
        finally: route.close()

    def test_b24_b25_wants_more_spacing_and_player_cap(self):
        from tools.run_stage_b_routes import Route
        route = Route(42)
        try:
            route.begin()
            sign_turns = []
            for turn in range(29):
                route.action("h_kiss_deep")
                if "h.sign.wants_more" in route.status()["blocks"]:
                    sign_turns.append(turn)
            self.assertTrue(sign_turns)
            self.assertTrue(all(b - a >= 2 for a, b in zip(sign_turns, sign_turns[1:])), sign_turns)
            self.assertEqual(route.engine.snapshot()["intimacy"]["player"]["arousal"], 50)
        finally: route.close()

    def test_b25_noninserted_player_cap(self):
        from tools.run_stage_b_routes import Route
        route = Route(42)
        try:
            route.begin()
            for _ in range(30): route.action("h_kiss_deep")
            self.assertEqual(route.engine.snapshot()["intimacy"]["player"]["arousal"], 50)
            self.assertFalse(route.engine.snapshot()["intimacy"]["inserted"])
        finally: route.close()

    def test_b32_morning_result_after_sleep(self):
        from tools.run_stage_b_routes import Route, quick_hold, DAYTIME
        route = Route(42)
        try:
            quick_hold(route)  # B2：夜に終えたら一緒に眠り、同じベッドで目覚めた一言
            self.assertEqual(route.status()["blocks"][-3:], ["h.sleep_together.unsatisfied", "h.morning_together.unsatisfied", "life.breakfast"])
            self.assertFalse(route.engine.snapshot()["intimacy_history"]["slept_together"])
        finally: route.close()
        route = Route(42, **DAYTIME)
        try:
            quick_hold(route)  # 昼に終えて、あとで休んだ翌朝は、これまでの一言
            self.assertNotIn("h.sleep_together.unsatisfied", route.status()["blocks"])
            route.choose("sleep")
            self.assertEqual(route.status()["blocks"][-2:], ["h.morning.unsatisfied", "life.breakfast"])
        finally: route.close()

    def test_b16_deadline_grace_and_forced_end(self):
        from tools.run_stage_b_routes import Route, deadline
        route = Route(42, tier="few", hour=21, minute=24)  # v8.2.30：初めての回は締め切りまで60分ないと始めないので、数回で確かめる
        try:
            deadline(route)
            self.assertEqual(route.engine.snapshot()["intimacy_history"]["last_result"], "unsatisfied")
        finally: route.close()

    def test_b22_together_climax_by_public_choices(self):
        from tools.run_stage_b_routes import Route, maho_lead_together
        route = Route(42, tier="few", day_offset=2)
        try:
            maho_lead_together(route)
            self.assertGreaterEqual(route.engine.snapshot()["intimacy"]["maho"]["climaxes"], 1)
        finally: route.close()

    def test_b27_b28_zero_stamina_and_sleep_recovery(self):
        from tools.run_stage_b_routes import Route, stamina_zero
        route = Route(42, day_offset=3, hour=10)  # B2：夜に終えると翌朝（余力が戻る）ので、休日の昼に3回
        try:
            stamina_zero(route)
            self.assertEqual(route.engine.snapshot()["stamina"]["value"], 0)
            self.assertEqual(route.engine.get_view()["status"]["stamina"], "○○○")
            route.choose("sleep")
            self.assertEqual(route.engine.snapshot()["stamina"]["value"], 3)
        finally: route.close()

    def test_b28_stamina_status_and_sleep_reset(self):
        from tools.run_stage_b_routes import Route, stamina_zero
        route = Route(42, day_offset=3, hour=10)
        try:
            stamina_zero(route)
            self.assertEqual(route.engine.get_view()["status"]["stamina"], "○○○")
            route.choose("sleep")
            self.assertEqual(route.engine.snapshot()["stamina"]["value"], 3)
        finally: route.close()

    def test_b29_b30_b31_holdback_result_and_memory(self):
        from tools.run_stage_b_routes import Route, quick_hold, DAYTIME
        route = Route(42, **DAYTIME)  # B2：夜に終えると眠って欲求も変わるので、昼に確かめる
        try:
            quick_hold(route)
            state = route.engine.snapshot()
            self.assertEqual(state["intimacy_history"]["count"], 1)
            self.assertEqual(state["intimacy_history"]["by_entry"]["private"], 1)
            self.assertEqual(state["desire"], 50)
            self.assertIsNone(state["intimacy"])
            self.assertEqual(sum(memory["kind"] == "intimacy" for memory in state["memories"]["recent"]), 1)
            self.assertFalse({"private.ended", "activity.completed"} & set(route.status()["blocks"]))
        finally: route.close()

    def test_b30_holdback_continue_is_silent_then_decline_ends(self):
        from tools.run_stage_b_routes import Route
        route = Route(42)
        try:
            route.begin()
            route.choose("h.end")
            self.assertEqual(route.engine.snapshot()["offer"]["kind"], "hold_back")
            count = len(route.engine.get_view()["blocks"])
            route.choose("offer.accept")
            self.assertEqual(len(route.engine.get_view()["blocks"]), count)
            self.assertIsNotNone(route.engine.snapshot()["intimacy"])
            route.choose("h.end")
            blocks = [b["meaning"] for b in route.engine.get_view()["blocks"]]
            self.assertEqual(blocks[0], "h.ended.unsatisfied")
            self.assertIn("h.sleep_together.unsatisfied", blocks)  # B2
        finally: route.close()

    def test_b31_end_updates_history_and_desire(self):
        from tools.run_stage_b_routes import Route, quick_hold, DAYTIME
        route = Route(42, **DAYTIME)
        try:
            quick_hold(route)
            state = route.engine.snapshot()
            self.assertEqual(state["intimacy_history"]["count"], 1)
            self.assertEqual(state["intimacy_history"]["last_result"], "unsatisfied")
            self.assertEqual(state["desire"], 50)
            self.assertIsNone(state["intimacy"])
            self.assertEqual(sum(m["kind"] == "intimacy" for m in state["memories"]["recent"]), 1)
        finally: route.close()

    def test_b33_maho_lead_and_b34_invite(self):
        from tools.run_stage_b_routes import Route, maho_lead_together, invite
        route = Route(42, tier="few", day_offset=2)
        try:
            maho_lead_together(route)
            self.assertTrue(route.engine.snapshot()["intimacy"]["leads"])  # v8.2.3：申し出の記録は種類ごと
        finally: route.close()

    def test_b34_invite_starts_maho_room_session(self):
        from tools.run_stage_b_routes import Route, invite, DAYTIME
        route = Route(42, **DAYTIME)
        try:
            invite(route)
            state = route.engine.snapshot()
            self.assertEqual(state["intimacy"]["entry"], "invite")
            self.assertEqual(state["intimacy"]["origin"], "maho")
            self.assertEqual(state["actors"]["player"]["location"], "maho_room")
        finally: route.close()
        route = Route(42)
        try:
            invite(route)
            self.assertEqual(route.engine.snapshot()["intimacy"]["entry"], "invite")
        finally: route.close()

    def test_b45_all_six_routes_three_seeds(self):
        from tools.run_stage_b_routes import Route, route_for, satisfied, quick_hold, deadline, stamina_zero, invite, maho_lead_together
        routes = (("first_satisfied", satisfied), ("first_hold_back", quick_hold), ("deadline", deadline),
                  ("stamina_zero", stamina_zero), ("invite", invite), ("lead_together", maho_lead_together))
        for name, runner in routes:
            for seed in (0, 42, 20380407):
                route = route_for({"deadline": "workday_deadline", "lead_together": "maho_lead_together", "stamina_zero": "stamina_zero_hold_back", "invite": "maho_invite"}.get(name, name), seed)
                try:
                    with self.subTest(route=name, seed=seed): runner(route)
                finally: route.close()

    def test_b20_tier_pace_band_floor_grid(self):
        rules = self.engine.pack.intimacy
        expected = {
            "first": ((8, 5, 2), (6, 8, 6), (4, 7, 9)),
            "few": ((12, 8, 3), (9, 12, 9), (6, 10, 14)),
            "familiar": ((16, 11, 4), (12, 16, 12), (8, 14, 19)),
        }
        for tier, rows in expected.items():
            for band, row in zip(("low", "mid", "high"), rows):
                for pace, value in zip(("slow", "normal", "fast"), row):
                    self.assertEqual(rules.maho_gain(16, tier, band, pace)[0], value, (tier, band, pace))

    def test_b21_band_sign_only_once_per_band(self):
        from tools.run_stage_b_routes import Route
        route = Route(42)
        try:
            route.begin()
            observed = []
            for _ in range(29):
                route.action("h_kiss_deep")
                observed += [meaning for meaning in route.status()["blocks"] if meaning.startswith("h.sign.")]
            self.assertEqual(observed.count("h.sign.mid"), 1)
            self.assertEqual(route.engine.snapshot()["intimacy"]["maho"]["band"], "mid")
        finally: route.close()

    def test_b26_b27_limit_finish_and_refractory(self):
        from tools.run_stage_b_routes import Route
        route = Route(42, day_offset=2)
        try:
            route.begin()
            while route.engine.snapshot()["intimacy"]["maho"]["arousal"] < 40:
                route.action("h_kiss_deep")
            for key in ("h_strip_lower", "h_shift_under", "h_strip_self", "h_pos_player_above", "h_insert"):
                route.action(key)
            while route.engine.snapshot()["intimacy"]["player"]["arousal"] < 100:
                route.action("h_move_normal")
            route.choose("menu.main")
            self.assertTrue(next(c for c in route.engine.get_view()["choices"] if c["id"] == "touch.h_endure")["available"])
            # B2：限界のまま動きを続けると、こらえきれずに出る（動きは選べ、名前にそのことを添える）。ほかの行動は選べない。
            move = next(c for c in route.engine.get_view()["choices"] if c["id"] == "touch.h_move_normal")
            self.assertTrue(move["available"] and move["label"].endswith("（もうこらえきれない）"), move)
            route.choose("menu.h_clothes")  # v8.2.29：限界でも口づけ・愛撫は選べるので、服の行動で確かめる
            self.assertEqual(next(c for c in route.engine.get_view()["choices"] if c["id"] == "touch.h_lift_upper")["reason"], "h_limit")
            route.choose("menu.main")
            stamina = route.engine.snapshot()["stamina"]["value"]
            route.action("h_move_normal")
            self.assertIn("h_overflow.inside", route.status()["blocks"])
            self.assertEqual(route.engine.snapshot()["stamina"]["value"], stamina - 1)
            self.assertEqual(route.engine.snapshot()["intimacy"]["player"]["refractory"], 2)
            route.choose("menu.h_connect")
            self.assertEqual(next(c for c in route.engine.get_view()["choices"] if c["id"] == "touch.h_move_normal")["reason"], "h_player")
        finally: route.close()

    def test_b43_six_unavailable_reason_codes(self):
        from tools.run_stage_b_routes import Route
        seen = set()
        route = Route(42)
        try:
            route.begin()
            route.choose("menu.h_position")
            # v8.2.19（ユーザー）：回数で開く行為（h_tier）は、開くまで一覧に出さない
            self.assertNotIn("touch.h_pos_maho_above", [c["id"] for c in route.engine.get_view()["choices"]])
            route.choose("menu.main")
            route.action("h_strip_lower")
            route.action("h_shift_under")
            route.action("h_pos_lying_face")
            route.action("h_touch_direct")
            seen.add(next(c for c in route.engine.get_view()["choices"] if c["id"] == "touch.h_touch_direct")["reason"])
        finally: route.close()
        route = Route(42, tier="few", hour=21, minute=24)  # v8.2.30：初めての回は締め切りまで60分ないと始めないので、数回で確かめる
        try:
            route.begin()
            while route.engine.snapshot()["intimacy"]["wrap_up"] is None:
                route.action("h_kiss_deep")
            route.action("h_feel")  # v8.0.5：締め切りの後は様子を聞くを選べない（仕様 6.2 改訂3）
            seen.add(next(c for c in route.engine.get_view()["choices"] if c["id"] == "touch.h_feel")["reason"])
        finally: route.close()
        route = Route(42, hour=21, minute=30)
        try:
            route.choose("private.begin")
            route.choose("menu.touch")
            route.choose("touch.h_kiss_deep")
            seen.add(next(c for c in route.engine.get_view()["choices"] if c["id"] == "touch.h_kiss_deep")["reason"])
        finally: route.close()
        route = Route(42, day_offset=2)
        try:
            route.begin()
            while route.engine.snapshot()["intimacy"]["maho"]["arousal"] < 40: route.action("h_kiss_deep")
            for key in ("h_strip_lower", "h_shift_under", "h_strip_self", "h_pos_player_above", "h_insert"):
                route.action(key)
            while route.engine.snapshot()["intimacy"]["player"]["arousal"] < 100: route.action("h_move_normal")
            route.choose("menu.main")
            route.choose("menu.h_clothes")  # B2：限界で動きは続けられる（こらえきれずに出る）。ほかの行動は h_limit（v8.2.29：口づけ・愛撫は選べる）
            seen.add(next(c for c in route.engine.get_view()["choices"] if c["id"] == "touch.h_lift_upper")["reason"])
            route.action("h_finish_inside")
            route.choose("menu.h_connect")
            seen.add(next(c for c in route.engine.get_view()["choices"] if c["id"] == "touch.h_move_normal")["reason"])
        finally: route.close()
        self.assertEqual(seen, {"h_ready", "h_player", "h_limit", "h_deadline", "h_quiet"})

    def test_b46_three_autoplay_policies_clear_and_reproduce(self):
        from tools.audit_autoplay_immersion import run
        from nagishima.autoplay import next_command, next_social_command, next_presence_command
        for policy in (next_command, next_social_command, next_presence_command):
            with tempfile.TemporaryDirectory() as root:
                first = run(42, "interaction_009", 200, policy, Path(root) / "first")
                again = run(42, "interaction_009", 200, policy, Path(root) / "again")
            self.assertEqual(first["terminal"]["reason"], "cleared", policy.__name__)
            self.assertIn("h.end", first["command_ids"])
            self.assertEqual(first["command_ids"], again["command_ids"])
            self.assertEqual(first["top_repeats"], again["top_repeats"])


class StageBPackageChecks(unittest.TestCase):
    ROOT = Path(__file__).resolve().parents[1]

    def goldens(self):
        import json
        return json.loads((self.ROOT / "verification/stage_b_legacy_goldens.json").read_text(encoding="utf-8"))

    def test_b01_published_release_hashes(self):
        import hashlib
        for relative, expected in self.goldens()["published_files"].items():
            actual = hashlib.sha256((self.ROOT / "content/releases" / relative).read_bytes()).hexdigest()
            self.assertEqual(actual, expected, relative)

    def test_b02_legacy_autoplay_24_outputs(self):
        import hashlib, json
        from tools.check_stage_b_compat import run
        for key, expected in self.goldens()["autoplay"].items():
            release, policy, seed = key.split("/")
            output = run(self.ROOT, release, policy, int(seed))
            digest = hashlib.sha256(json.dumps(output, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()
            self.assertEqual(digest, expected, key)

    def test_b03_no_stage_b_fields_in_008(self):
        from nagishima.content import Pack
        pack = Pack(self.ROOT / "content/releases/interaction_008")
        self.assertIsNone(pack.intimacy)
        self.assertFalse(any(key.startswith("intimacy.") for key in pack.registry.fields))
        with tempfile.TemporaryDirectory() as root:
            engine = Engine(root, seed=42, release="interaction_008", autosave=False)
            self.assertNotIn("settings", engine.get_view()["status"])
            self.assertNotIn("menu.h_entry", {c["id"] for c in engine.get_view()["choices"]})

    def test_b05_rebuild_008_refused(self):
        import subprocess, sys
        for script, extra in (("build_life_release.py", []), ("build_intimacy_release.py", ["--target", "content/releases/interaction_008"]),
                              ("build_intimacy_release.py", []), ("build_intimacy_release.py", ["--target", "content/releases/interaction_009"])):  # v8.3.0：009 も確定
            completed = subprocess.run([sys.executable, str(self.ROOT / "tools" / script), "--replace-unpublished", *extra], cwd=self.ROOT, capture_output=True, text=True)
            self.assertNotEqual(completed.returncode, 0, script)

    def test_b07_missing_dependency_rejected(self):
        import json, shutil
        from nagishima.codec import digest
        from nagishima.content import Pack
        from nagishima.errors import GameError
        for missing in ("progression.json", "life.json"):
            with tempfile.TemporaryDirectory() as root:
                path = Path(root) / "interaction_009"
                shutil.copytree(self.ROOT / "content/releases/interaction_009", path)
                manifest = json.loads((path / "release.json").read_text(encoding="utf-8"))
                del manifest["files"][missing]
                control = {"catalog": json.loads((path / "catalog.json").read_text(encoding="utf-8")),
                           "actions": json.loads((path / "actions.json").read_text(encoding="utf-8"))}
                for name, field in (("progression.json", "progression"), ("life.json", "life"), ("intimacy.json", "intimacy")):
                    if name != missing: control[field] = json.loads((path / name).read_text(encoding="utf-8"))
                manifest["control_sha256"] = digest(control)
                (path / "release.json").write_text(json.dumps(manifest, ensure_ascii=False), encoding="utf-8")
                (path / missing).unlink()
                with self.subTest(missing=missing), self.assertRaises(GameError): Pack(path)

    def test_b08_009_rebuild_is_byte_identical(self):
        import hashlib, subprocess, sys
        path = self.ROOT / "content/releases/interaction_009"
        def hashes(): return {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in path.iterdir() if p.is_file()}
        before = hashes()
        # v8.3.0：009 は確定済み。別の場所に作って同じかを比べる（009 は書き換えない）
        completed = subprocess.run([sys.executable, str(self.ROOT / "tools/build_intimacy_release.py"), "--verify"], cwd=self.ROOT, capture_output=True, text=True)
        self.assertEqual(completed.returncode, 0, completed.stdout + completed.stderr)
        self.assertIn("identical", completed.stdout)
        self.assertEqual(hashes(), before)

    def test_b49_correction_accepts_explicit_zip_paths(self):
        import subprocess, sys
        result = subprocess.run([sys.executable, str(self.ROOT / "tools/check_v712_correction.py"), "--help"], cwd=self.ROOT, capture_output=True, text=True)
        self.assertEqual(result.returncode, 0)
        self.assertIn("--base-zip", result.stdout)
        self.assertIn("--previous-zip", result.stdout)


if __name__ == "__main__":
    unittest.main()
