"""v8.2.22（ユーザー 2026-09-29 11:37）：短い本文をエッチの続ける行為すべてへ、真帆が頭を撫でる（エッチ中の一行と、余韻の胸の本文）、余韻に脚を絡める。
公開の選択肢（Engine.choose／get_view）から確かめる（高まり・慣れなどの準備だけ内部で行う）。"""
import json
import re
import unittest
from pathlib import Path

from nagishima.auto_continue import auto_next
from tools.run_stage_b_routes import Route

ROOT = Path(__file__).resolve().parents[1]
HEAD = re.compile(r"(頭|髪|つむじ|後頭部|襟足)")


def meanings(engine):
    return [b["meaning"] for b in engine.get_view()["blocks"]]


def contacts(engine):
    return [c["action_id"] for c in engine.snapshot()["contacts"]]


class V8222(unittest.TestCase):
    def route(self, seed, setup, tier="familiar"):
        route = Route(seed, tier=tier, day_offset=2)
        self.addCleanup(route.close)
        route.begin()
        for key in setup:
            route.action(key)
        return route

    def act(self, route, key, calm=True):
        while route.engine.snapshot()["offer"]:
            route.choose("offer.decline")  # 途中の真帆の申し出は断る
        if calm:
            intimate = route.engine._state["intimacy"]  # 準備：達する・限界の本文が混ざらないように
            intimate["player"]["arousal"] = min(intimate["player"]["arousal"], 40)
            intimate["maho"].update(arousal=min(intimate["maho"]["arousal"], 30))
            route.engine._install_choices()
        route.action(key)
        return meanings(route.engine)

    # ---- 1. 短い本文をすべての続ける行為へ ----
    def test_every_continue_meaning_has_short_texts(self):
        pack = self.route(7001, ()).engine.pack
        longs = {t["meaning"] for t in pack.texts if not t["fallback"] and t["meaning"].endswith((".continue", ".settled"))
                 and t["meaning"].startswith("h_") and not t["meaning"].startswith("h_after_")}
        self.assertGreater(len(longs), 70)
        # v8.2.23：短い本文の意味は行為ごとに1つ（<行為>.continue_short。しばらく続けた手も同じ）
        self.assertEqual(sorted(m for m in longs if m.rsplit(".", 1)[0] + ".continue_short" not in pack.meanings), [])

    def test_mouth_short_lines_carry_sound_or_touch(self):
        """真帆が話せない場面（口でしてもらう・深い口づけ・シックスナイン）の短い本文は、どれも地の文がある（台詞だけの行はない）。
        v8.2.23：くぐもった声だけの行（v.*）は別。1つの意味で1割ほどまで。"""
        pack = self.route(7003, ()).engine.pack
        counts = {}
        for text in pack.texts:
            if text["fallback"] or not text["meaning"].endswith("_short"):
                continue
            if text["meaning"].startswith(("h_maho_mouth", "h_kiss_deep", "h_sixty_nine")):
                total, voice = counts.get(text["meaning"], (0, 0))
                counts[text["meaning"]] = (total + 1, voice + text["id"].startswith("v."))
                if text["id"].startswith("v."):
                    continue
                narration = re.sub(r"「[^」]*」", "", text["body"])
                self.assertTrue(narration.strip(), text["id"])
        for meaning, (total, voice) in counts.items():
            self.assertLessEqual(voice, total * 0.12, meaning)

    def test_oral_uses_short_lines(self):
        route = self.route(7004, ("h_strip_lower", "h_strip_self"))
        found = [self.act(route, "h_maho_mouth")[0] for _ in range(5)]
        self.assertEqual(found[1:], ["h_maho_mouth.continue_short"] * 4)  # v8.2.23：しばらく続けた手も短い本文

    # ---- 2. エッチ中に胸に口づけていると、ときどき頭を撫でる ----
    def test_pat_line_while_chest_mouth(self):
        seen = []
        for seed in range(7010, 7020):
            route = self.route(seed, ("h_lift_upper", "h_strip_lower", "h_strip_self", "h_pos_lying_face"))
            for _ in range(7):
                found = self.act(route, "h_chest_mouth")
                seen.append(found[0])
                for block in route.engine.get_view()["blocks"]:
                    self.assertFalse(block["variant"].endswith(".base"), block)
                if found[0] == "h.pat.heat":
                    view, state = route.engine.get_view(), route.engine.snapshot()
                    self.assertIsNone(auto_next(route.engine.pack, state, view, "touch.h_chest_mouth"))  # 口づけは自動にしない行為
        self.assertIn("h.pat.heat", seen)
        for a, b in zip(seen, seen[1:]):
            self.assertFalse(a == b == "h.pat.heat", seen)  # 続けて2手は撫でない
        self.assertNotIn("h.pat.heat", [m for m in seen if m.endswith((".start", ".first"))])

    def test_pat_line_keeps_auto_continue_with_hand(self):
        pats = 0
        for seed in range(7030, 7040):
            route = self.route(seed, ("h_lift_upper", "h_strip_lower", "h_strip_self", "h_pos_lying_face"))
            self.act(route, "h_chest_mouth")
            self.act(route, "h_maho_hand")
            for _ in range(5):
                found = self.act(route, "h_maho_hand")
                if found[0] == "h.pat.suckle_hand":
                    pats += 1
                    self.assertIsNotNone(auto_next(route.engine.pack, route.engine.snapshot(), route.engine.get_view(), "touch.h_maho_hand"))
        self.assertGreater(pats, 0)

    # ---- 3. 余韻の胸は、どの本文でも頭を撫でる ----
    def test_after_chest_texts_all_stroke_head(self):
        pack = self.route(7041, ()).engine.pack
        rows = [t for t in pack.texts if not t["fallback"] and t["meaning"].split(".")[0] in ("h_after_bury", "h_after_suckle")]
        self.assertGreater(len(rows), 70)
        for text in rows:
            self.assertRegex(text["body"], HEAD, text["id"])

    # ---- 4. 余韻に脚を絡める ----
    def finished(self, seed, position="h_pos_lying_face"):
        route = self.route(seed, ("h_lift_upper", "h_strip_lower", "h_strip_self") + ((position,) if position else ()))
        route.engine._state["intimacy"]["player"]["arousal"] = 90
        route.engine._install_choices()
        self.act(route, "h_maho_hand", calm=False)
        self.act(route, "h_finish_hand", calm=False)
        self.assertTrue(route.engine.snapshot()["intimacy"]["after"])
        return route

    def test_legs_with_bury_and_hold(self):
        route = self.finished(7051)
        self.assertIn(self.act(route, "h_after_legs")[0], ("h_after_legs.first", "h_after_legs.start"))
        self.act(route, "h_after_bury")
        self.assertEqual(sorted(contacts(route.engine)), ["h_after_bury", "h_after_legs"])  # 同時にできる
        self.assertEqual(self.act(route, "h_after_legs")[0], "h_after_legs.continue")
        self.act(route, "h_after_hold")
        self.assertEqual(contacts(route.engine), ["h_after_legs"])  # 抱きしめて休むと顔を上げる。脚は絡めたまま
        for block in route.engine.get_view()["blocks"]:
            self.assertFalse(block["variant"].endswith(".base"), block)
        self.act(route, "h_wipe")
        self.assertEqual(contacts(route.engine), [])  # 拭くと起き上がる

    def test_legs_end_when_afterglow_ends(self):
        route = self.finished(7052)
        self.act(route, "h_after_legs")
        self.act(route, "h_chest_mouth")
        self.assertFalse(route.engine.snapshot()["intimacy"]["after"])
        self.assertNotIn("h_after_legs", contacts(route.engine))

    def test_legs_only_while_lying(self):
        route = self.finished(7053, position=None)  # 始まりの体位は「寄り添って座る」
        self.assertEqual(route.engine.snapshot()["intimacy"]["position"], "sitting_close")
        choices = {c["id"]: c for c in route.engine.get_view()["choices"]}
        self.assertFalse(choices.get("touch.h_after_legs", {"available": False})["available"])


if __name__ == "__main__":
    unittest.main()
