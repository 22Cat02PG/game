"""v8.2.33（ユーザー 2026-10-01 11:46「進めて」）：別の Claude のエッチ場面の確かめ（報告_v8232エッチ.md）の 1〜4 の直し。"""
import json
import unittest
from pathlib import Path

from nagishima.conditions import evaluate
from nagishima.content import Pack
from tools.run_stage_b_routes import Route

ROOT = Path(__file__).resolve().parents[1]
PACK = Pack(ROOT / "content/releases/interaction_009")


def meanings(engine):
    return [b["meaning"] for b in engine.get_view()["blocks"]]


def candidates(meaning, state):
    values = PACK.registry.values(state)
    return [t for t in PACK.by_meaning[meaning] if not t["fallback"] and evaluate(t["when"], values) is True]


class V8233(unittest.TestCase):
    def route(self, seed, tier="few", **kw):
        route = Route(seed, tier=tier, **({"day_offset": 0, "hour": 12, "minute": 20} | kw))
        self.addCleanup(route.close)
        return route

    def until_deadline(self, route, key, player=80):
        """締め切りまで同じ行為を続ける（こちらの高まりは出せる高さ、真帆は低いまま）。締め切りの手の意味を返す。"""
        for _ in range(40):
            route.engine._state["intimacy"]["maho"].update(arousal=30, band="low")
            route.engine._state["intimacy"]["player"]["arousal"] = player
            route.engine._install_choices()
            route.action(key)
            if route.engine.snapshot()["intimacy"]["wrap_up"] is not None:
                return [m for m in meanings(route.engine) if m.startswith("h.deadline")]
        self.fail("締め切りに届かない")

    # ---- 1：延ばすのは、残りの手で果てる道が続いているときだけ ----
    def test_close_needs_a_way(self):
        route = self.route(6001)
        route.begin()
        self.assertEqual(self.until_deadline(route, "h_kiss_deep"), ["h.deadline.work"])  # 口づけだけでは延ばさない
        route = self.route(6002)
        route.begin()
        route.action("h_strip_self")
        route.action("h_maho_hand")
        self.assertEqual(self.until_deadline(route, "h_maho_hand"), ["h.deadline.work_close"])  # 手でしてもらっていれば延ばす

    # ---- 3：真帆が口でしているときの締めくくりの一言は、口を離して話す本文 ----
    def test_deadline_while_mouth_busy(self):
        route = self.route(6003)
        route.begin()
        route.action("h_strip_self")
        route.engine._state["intimacy"]["maho"].update(arousal=50, band="mid")
        route.engine._install_choices()
        route.action("h_maho_mouth")
        state = route.engine.snapshot()
        values = PACK.registry.values(state)
        self.assertEqual(values["intimacy.facing"], "maho_mouth")
        for meaning in ("h.deadline.work", "h.deadline.work_close", "h.deadline.close", "h.deadline"):
            found = candidates(meaning, state)
            self.assertTrue(found, meaning)
            self.assertFalse([t["id"] for t in found if not t["id"].startswith("o40.")], meaning)

    # ---- 2：胸に口づける本文で「秘所の内壁」にならない ----
    def test_chest_inner_words(self):
        for text in PACK.texts:
            if text["meaning"].split(".")[0] in ("h_chest_mouth", "h_chest_skin", "h_ear_neck", "h_stroke_head"):
                self.assertNotRegex(text["body"], r"\{vagina\}(の(内壁|奥|襞)|が[^。]{0,8}(内壁|奥))", text["id"])

    # ---- 4：止めてもらったときの一言の条件 ----
    def test_stopped_conditions(self):
        self.assertIn('"experience.h_maho_feet.count", "op": "le", "value": 2', json.dumps(PACK.by_text["o39.h.stopped.maho_feet.s.v2"]["when"]))
        self.assertIn('"intimacy.player.arousal_band"', json.dumps(PACK.by_text["o39.h.stopped.maho_hand.s.v2"]["when"]))

    def test_texts(self):
        data = json.loads((ROOT / "tools/stage_b/opus_texts_v8233.json").read_text(encoding="utf-8"))
        self.assertEqual(len(data["texts"]), 12)
        for row in data["texts"]:
            self.assertEqual(PACK.by_text[row["id"]]["body"], row["body"])


if __name__ == "__main__":
    unittest.main()
