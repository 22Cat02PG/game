# AI執筆用の形式と追加手順

文章を増やす単位は、一つの結果を表す `meaning` に対する別表現 `variant`。新しい結果や分岐が必要な場合は先に場面を設計する。執筆AIが本文だけで状態を増やす手順にはしない。

## 渡す資料

執筆AIへ `docs/作品と人物.md`、この文書、`執筆プロンプト.md`、対象のjob、対象meaningの説明と前後の状態を渡す。利用できる条件は `condition_fields.json`、現在のmeaningと基本本文は `meaning_reference.json`。どちらも記載されたsource_sha256の版の控えなので、登録を変えた後は新しいPackから更新する。

`example_job.json`、`example_draft.json`、`example_reviews.json` は一件の短い会話原稿の形式例。三つを束ねたものが `example_bundle.json`。検品コメントは同梱例を確認した記録であり、量産原稿へコピーする承認ではない。

## 依頼 → 原稿 → 検品 → 公開

1. 実装担当が対象meaning、許可する状況、差し込み、文章の目的、禁止事項をjobに固定する。source_releaseとsource_sha256は対象Packのid/hashを使う。
2. 執筆AIはdraftのbodyを執筆する。idは新しいものを採番し、jobのhashをdraftへ入れる。
3. 検品担当がjobとdraftの実物を読み、五項目を確認する。修正するなら先にdraftを直し、修正後のhashに対して検品する。
4. job/draft/reviewsをbundleにまとめ、`tools/publish_text.py` へ渡す。必要な承認が揃わない原稿は公開されない。
5. 新しい公開版を本体で採用し、その条件へ進んで表示を確認する。同じ意味の別原稿を増やしても、時間や経験などの結果は変わらない。

```bash
python3 tools/authoring_hash.py authoring/example_job.json
python3 tools/authoring_hash.py authoring/example_draft.json
python3 tools/publish_text.py --source content/releases/base --release prose_001 authoring/example_bundle.json
```

通常のファイルのSHA-256ではなく、キー順・空白を正規化したJSONのSHA-256を使う。bundle内の値なら `--key job` または `--key draft` を指定できる。hashだけで担当者が本当に検品したことや、文章の矛盾がないことを証明する仕組みではない。

## 項目

| ファイル | 項目 | 決めること |
| --- | --- | --- |
| job | id / source_release / source_sha256 | 依頼と参照版 |
| job | meaning / when | 何が起きた後、どの状況で使う文章か |
| job | slots / group | 許可する差し込み、表現の系列 |
| job | required / forbidden | 必ず表すこと、作ってはいけないこと |
| job | reviewers / min_chars / max_chars | 検品担当ID、Unicode文字数の範囲 |
| draft | id / job_id / job_sha256 / body | 新しい本文ID、参照した依頼、原稿本文 |
| review | job_sha256 / draft_sha256 / reviewer | 確認した依頼と原稿の実物、担当ID |
| review | verdict / checks / notes | acceptかどうか、五項目、判断の根拠 |

checksは `outcome`（結果が一致）、`knowledge`（知識の根拠）、`continuity`（現在状態と接続）、`voice`（人物の主観と口調）、`variation`（既存との差）の五項目。公開には全てtrue、指定担当全員のacceptと根拠が必要。required/forbiddenの自然文の意味は機械が証明できないため、人または別の検品工程で読む。

本文にeffects、script、eval、状態を直接変更するコードは入れない。コンパイル後はid/meaning/when/slots/group/body/fallbackだけがゲームへ入る。原稿例以外の新規本文はfallback=false。全meaningに無条件・差し込みなしの基本本文を残す。

## 条件と差し込み

条件は `{ "field": "relation.stage", "op": "ge", "value": 3 }`、複数なら `all`、いずれかなら `any`、否定は `not`。常に成立は `{ "all": [] }`。opはeq/ne/lt/le/gt/ge/in/exists/missing。大小比較は整数だけ。比較対象が不明ならUNKNOWNで、notでも既知に変わらない。適合として採用するのは明確なtrueだけ。

プロフィールから現在の姿勢・服装・場所を補わない。「昨日」なら該当する記憶のage_days=1とその記憶の存在が必要。「前に教えてくれた好み」なら真帆が知った値を根拠にする。場面が控えた過去を使うときはsnapshotを使い、現在の最新記憶へ勝手に読み替えない。

差し込みは `{player_name}` などの単純な名前だけ。式・添字・関数は不可。許可済みはplayer_name、location、memory_place、chosen_place、scene_memory_place。job.slotsと本文に登場する差し込みを一致させる。slotsの値が存在しない原稿は候補に入らない。差し込み後の一本文は16,000文字まで。

groupには同じ発想・同じ反応の系列をまとめる。全原稿を別groupにして言い換えを新規表現扱いしない。適合する追加原稿（fallback=false）があるときはそちらを使い、該当しないときだけ基本本文へ戻る。選択は適合候補の中で、直前と同じID、直近の系列、直近のID、出現回数を避けてから固定seedで決める。追加原稿同士では、細かい条件を書くだけでは一般原稿より優先されない。

## 分岐を追加するとき

`scene_example.json` は窓側とテーブル側の選択をlocals.placeへ残して合流する実行可能な形の控え。`effect_arguments.json` に場面から呼べる操作の項目を示す。分岐の制作は `分岐追加プロンプト.md` に従う。

場面のlocalsはint/bool/string/enumと必要ならnull。choiceにはwhen/effects/next、nodeにはjoin/enter/choicesと保留・割り込みの方針を指定する。場面を変えるならrevisionを増やす。新しいmeaningには基本本文も用意する。

場面を公開する開発者向けAPIは `nagishima.authoring.publish(..., scenes=..., new_meanings=..., base_texts=...)`。これは規則を扱う実装経路で、本文だけを追加するCLIとは権限の範囲が異なる。この経路を使って文章の検品を省かない。開始・全選択肢・合流・保留・取消・保存読込の経路を本体で確認してから新しい版として渡す。

動作やfactなどcatalog/actionsを変える変更は既存セーブへ単純採用できない。新しい規則の型・保存・終了条件を実装してから扱う。
