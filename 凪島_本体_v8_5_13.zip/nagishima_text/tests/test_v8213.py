"""v8.2.13：続けている行為の速さ（ユーザー 2026-09-28 12:47「もっと激しく、もっと緩やかに」、口の「舌で舐めてもらう」「口に含んでもらう」）。
公開の選択肢から確かめる（高まり・回数などの準備だけ内部で行う）。"""
import unittest

from tools.run_stage_b_routes import Route


def meanings(engine):
    return [b["meaning"] for b in engine.get_view()["blocks"]]


def variants(engine):
    return [b["variant"] for b in engine.get_view()["blocks"]]


def choices(engine):
    return {c["id"]: c for c in engine.get_view()["choices"]}


class V8213(unittest.TestCase):
    def route(self, *args, **kwargs):
        route = Route(*args, **kwargs)
        self.addCleanup(route.close)
        return route

    def ready(self, seed, tier="familiar", position="h_pos_lying_face"):
        route = self.route(seed, tier=tier, day_offset=2)
        route.begin()
        for key in ("h_strip_lower", "h_shift_under", "h_strip_self", position):
            route.action(key)
        return route

    def set_experience(self, route, key, count):
        now = route.engine.snapshot()["world"]["now"]
        route.engine._state["experience"][key] = {"count": count, "first_at": now - 2880, "last_at": now - 1440, "by_origin": {"player": count, "maho": 0}}
        route.engine._install_choices()

    def main(self, route):
        if route.engine.snapshot()["offer"]:
            route.choose("offer.decline")
        if route.engine.get_view()["page"] != "main":
            route.choose("menu.main")

    def intimate(self, route):
        return route.engine.snapshot()["intimacy"]

    def test_hand_pace_up_and_down(self):
        route = self.ready(1001)
        route.action("h_maho_hand")
        self.main(route)
        found = choices(route.engine)
        self.assertEqual(found["pace.h_maho_hand.fast"]["label"], "もっと激しくしてもらう")
        self.assertEqual(found["pace.h_maho_hand.slow"]["label"], "もっとゆっくりしてもらう")
        before = self.intimate(route)["player"]["arousal"]
        route.choose("pace.h_maho_hand.fast")
        state = self.intimate(route)
        self.assertEqual((state["paces"], state["pace_focus"]), ({"h_maho_hand": "fast"}, "h_maho_hand"))
        self.assertEqual(meanings(route.engine)[0], "h_maho_hand.pace_fast")
        self.assertTrue(variants(route.engine)[0].startswith(("o27.h_maho_hand.pace_fast.", "p12.h_maho_hand.pace_fast.")))  # v8.2.15：grok の第12陣も
        self.assertEqual(state["player"]["arousal"] - before, 12 * 140 // 100)  # 激しくは 140%
        self.main(route)
        self.assertNotIn("pace.h_maho_hand.fast", choices(route.engine))  # もう激しい
        route.choose("touch.h_maho_hand")
        self.assertIn(meanings(route.engine)[0], ("h_maho_hand_fast.continue", "h_maho_hand_fast.continue_short"))  # v8.2.22：続けているあいだは短い本文（長い本文は3手に1回）
        self.assertEqual(route.engine.get_view()["status"]["held_actions"], ["手でしてもらう（激しく）"])
        self.main(route)
        route.choose("pace.h_maho_hand.normal")
        self.assertEqual(meanings(route.engine)[0], "h_maho_hand.pace_normal")
        self.assertEqual(self.intimate(route)["paces"], {"h_maho_hand": "normal"})

    def test_mouth_three_levels(self):
        route = self.ready(1011)
        self.set_experience(route, "h_maho_mouth", 3)
        route.action("h_maho_mouth")
        self.main(route)
        found = choices(route.engine)
        self.assertEqual((found["pace.h_maho_mouth.slow"]["label"], found["pace.h_maho_mouth.fast"]["label"]), ("舌で舐めてもらう", "深く咥えてもらう"))
        route.choose("pace.h_maho_mouth.slow")
        self.assertEqual(meanings(route.engine)[0], "h_maho_mouth.pace_slow")
        self.main(route)
        self.assertEqual(choices(route.engine)["pace.h_maho_mouth.normal"]["label"], "口に含んでもらう")
        route.choose("pace.h_maho_mouth.fast")  # 舌だけから一気に深く
        self.assertEqual(meanings(route.engine)[0], "h_maho_mouth.pace_fast")
        self.assertEqual(route.engine.get_view()["status"]["held_actions"], ["口でしてもらう（深く）"])

    def test_pace_text_wins_over_extra(self):
        # 玉も揉んでもらっていても、舌で舐めてもらうあいだは速さの本文（「含んだまま」の本文を出さない。読み手の指摘 R-1）
        route = self.ready(1021)
        self.set_experience(route, "h_maho_mouth", 3)
        route.action("h_maho_mouth")
        self.main(route)
        route.action("h_extra_balls")
        self.main(route)
        route.choose("pace.h_maho_mouth.slow")
        self.main(route)
        route.choose("touch.h_maho_mouth")
        self.assertIn(meanings(route.engine)[0], ("h_maho_mouth_slow.continue", "h_maho_mouth_slow.continue_short"))  # v8.2.22：続けているあいだは短い本文（長い本文は3手に1回）
        self.assertEqual(route.engine.get_view()["status"]["held_actions"], ["口でしてもらう（玉も・舌で）"])

    def test_own_caress_pace_changes_maho_gain(self):
        results = {}
        for pace in ("slow", "fast"):
            route = self.ready(1031)
            route.engine._state["intimacy"]["maho"].update(arousal=60, band="mid")
            route.engine._install_choices()
            route.action("h_touch_direct")
            self.main(route)
            route.engine._state["intimacy"]["maho"].update(arousal=81, band="high")  # 準備：もう高い
            route.engine._install_choices()
            route.choose("pace.h_touch_direct." + pace)
            state = self.intimate(route)
            results[pace] = (100 if state["maho"]["climaxes"] else state["maho"]["arousal"]) - 81
            self.assertEqual(meanings(route.engine)[0], "h_touch_direct.pace_" + pace)
        self.assertGreater(results["fast"], results["slow"])  # 高いときは、激しいほうがよく効く

    def test_pace_cleared_when_act_ends_or_position_changes(self):
        route = self.ready(1041)
        route.action("h_maho_hand")
        self.main(route)
        route.choose("pace.h_maho_hand.fast")
        self.main(route)
        route.choose("end.h_maho_hand")
        self.assertEqual((self.intimate(route)["paces"], self.intimate(route)["pace_focus"]), ({}, None))
        route.action("h_maho_hand")  # また始めたら「ふつう」から
        self.assertEqual(meanings(route.engine)[0].split(".")[0], "h_maho_hand")
        self.assertEqual(self.intimate(route)["paces"], {})
        other = self.ready(1042)
        other.engine._state["intimacy"]["maho"].update(arousal=60, band="mid")
        other.engine._install_choices()
        other.action("h_sumata")
        self.main(other)
        other.choose("pace.h_sumata.fast")
        other.action("h_pos_from_behind")  # 体を組み替えたら、速さは「ふつう」から
        self.assertEqual(self.intimate(other)["paces"], {})

    def test_pace_at_limit_is_marked_and_overflows(self):
        route = self.ready(1051)
        route.action("h_maho_hand")
        route.engine._state["intimacy"]["player"]["arousal"] = 100  # 準備：限界
        route.engine._install_choices()
        self.main(route)
        found = choices(route.engine)
        self.assertEqual(found["pace.h_maho_hand.slow"]["label"], "もっとゆっくりしてもらう（もうこらえきれない）")
        route.choose("pace.h_maho_hand.slow")
        self.assertEqual(meanings(route.engine)[0], "h_overflow.hand")
        self.assertEqual((self.intimate(route)["paces"], self.intimate(route)["pace_focus"]), ({}, None))

    def test_slow_mouth_overflow_text(self):
        route = self.ready(1061)
        self.set_experience(route, "h_maho_mouth", 3)
        route.action("h_maho_mouth")
        self.main(route)
        route.choose("pace.h_maho_mouth.slow")
        route.engine._state["intimacy"]["player"]["arousal"] = 100  # 準備：限界
        route.engine._install_choices()
        self.main(route)
        route.choose("touch.h_maho_mouth")
        self.assertEqual(meanings(route.engine)[0], "h_overflow.mouth_slow")  # 舌だけから、とっさに含む本文
        self.assertEqual(self.intimate(route)["mess"], "mouth")

    def test_pace_choices_on_service_page(self):
        route = self.ready(1071)
        route.action("h_maho_hand")
        if route.engine.snapshot()["offer"]:
            route.choose("offer.decline")
        if route.engine.get_view()["page"] != "h_service":
            route.choose("menu.main")
            route.choose("menu.h_service")
        self.assertIn("pace.h_maho_hand.fast", choices(route.engine))


if __name__ == "__main__":
    unittest.main()
