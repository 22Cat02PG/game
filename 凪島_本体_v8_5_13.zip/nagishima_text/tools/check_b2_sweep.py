"""B2（v8.1.1）：公開の選択肢だけで遊び回り、書かれた本文がない（fallback に落ちる）場面と、一度も出番がない B2 の job を探す。

使い方: python tools/check_b2_sweep.py [--games 60] [--steps 400]
- 始め方（時刻と慣れ）だけ内部で用意し、あとは画面に出ている選べる選択肢から重み付きの乱数で選ぶ。
- 本文を選ぶたびに、その時の状態で条件が成り立つ B2 の job を「出番あり」にする。
- 結果は verification/b2_sweep.json。fallback に落ちた意味（書かれた本文がある意味だけ）が1つでもあれば終了コード1。
"""
import argparse
import json
import random
import sys
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from nagishima.conditions import evaluate
from tools.run_stage_b_routes import Route

REQUIRED = {"B2-1", "B2-2", "B2-3", "B2-4", "B2-5", "B2-6", "B2-7", "B2-8", "B2-9", "B2-10", "B2-11", "B2-12", "B2-13"}  # v8.2.15：第10陣（補充で0本の job が埋まった）・第11陣・第12陣もそろった  # 本文がそろっている陣（濃い版は届くまで「待ち」。v8.2.10：第7陣・第8陣、v8.2.11：第9陣も）
H_PAGES = ("menu.h_touch", "menu.h_clothes", "menu.h_position", "menu.h_connect", "menu.h_words", "menu.h_service")
STARTS = ({"hour": 21, "day_offset": 2}, {"hour": 13, "day_offset": 3}, {"hour": 19, "minute": 30, "day_offset": 5})


def b2_jobs():
    jobs = []
    for path in sorted((ROOT / "authoring/b2_jobs").glob("grok_b2_wave_*.json")):
        jobs += json.loads(path.read_text(encoding="utf-8"))
    return jobs


class Sweep:
    def __init__(self):
        self.jobs = defaultdict(list)
        for job in b2_jobs():
            self.jobs[job["_meaning"]].append(job)
        self.reached = set()
        self.fallbacks = []
        self.selected = Counter()

    def attach(self, route, game):
        pack = route.engine.pack
        original = pack.select
        authored_meanings = {t["meaning"] for t in pack.texts if not t["fallback"]}

        def selected(meaning, state, bindings, values=None):
            result = original(meaning, state, bindings, values)
            values_now = values if values is not None else pack.registry.values(state)
            self.selected[meaning] += 1
            for job in self.jobs.get(meaning, ()):
                if job["id"] not in self.reached and evaluate(job["when"], values_now) is True:
                    self.reached.add(job["id"])
            if meaning in authored_meanings and pack.by_text[result[0]["variant"]]["fallback"]:
                intimate = state.get("intimacy")
                self.fallbacks.append({
                    "meaning": meaning, "game": game, "tier": values_now.get("intimacy.tier"), "history": state["intimacy_history"]["count"],
                    "position": intimate and intimate["position"], "facing": values_now.get("intimacy.facing"),
                    "inserted": intimate and intimate["inserted"], "maho_clothing": dict(state["actors"]["maho"]["clothing"]),
                    "commands": list(route.commands[-8:]), "why": why(pack, meaning, values_now),
                    # 補充（第4、grok に依頼中）の job が受け持つ場面なら「補充待ち」
                    "waiting": any(j["_wave"] not in REQUIRED and evaluate(j["when"], values_now) is True for j in self.jobs.get(meaning, ()))})
            return result

        pack.select = selected


def why(pack, meaning, values):
    """書かれた本文ごとに、成り立たなかった条件（多いものから）。"""
    counts = Counter()
    for text in pack.by_meaning[meaning]:
        if text["fallback"]:
            continue
        conditions = text["when"]["all"] if set(text["when"]) == {"all"} else [text["when"]]
        failed = [json.dumps(c, ensure_ascii=False) for c in conditions if evaluate(c, values) is not True]
        counts[" & ".join(failed) or "(全部成り立つ)"] += 1
    return dict(counts.most_common(8))


def available(route):
    view = route.engine.get_view()
    return view, [c["id"] for c in view["choices"] if c["available"]]


def to_main(route):
    if route.engine.get_view()["page"] != "main" and any(c["id"] == "menu.main" for c in route.engine.get_view()["choices"]):
        route.choose("menu.main")


def intimacy_step(route, rng):
    state = route.engine.snapshot()
    if state["offer"]:
        route.choose("offer.accept" if rng.random() < 0.6 else "offer.decline")
        return
    to_main(route)
    _, main = available(route)
    intimate = state["intimacy"]
    pages = [c for c in main if c in H_PAGES]
    quick = [c for c in main if c.startswith(("touch.", "pace.", "side."))]  # v8.2.13：速さを変える選択肢も。v8.2.29：胸の左右も
    end_weight = 0.6 if state["stamina"]["value"] == 0 or intimate["player"]["finishes"] else 0.03
    groups = pages + (["quick"] if quick else []) + (["h.end"] if "h.end" in main else [])
    weights = [2.5 if g == "menu.h_connect" and intimate["inserted"] else 1.0 for g in pages] + ([1.5] if quick else []) + ([end_weight] if "h.end" in main else [])
    group = rng.choices(groups, weights)[0]
    if group == "h.end":
        route.choose("h.end")
        return
    if group == "quick":
        options = quick
    else:
        route.choose(group)
        options = [c for c in available(route)[1] if c.startswith(("touch.", "side."))]  # v8.2.29：胸の左右も
        if not options:
            route.choose("menu.main")
            return
    weights = []
    for c in options:
        key = c.split(".", 1)[1]
        w = 1.0
        if key.startswith("h_move_") and intimate["inserted"]:
            w = 2.5
        elif key in ("h_insert", "h_insert_deep", "h_lead_takein"):
            w = 3.0
        elif key.startswith("h_pos_"):
            w = 1.5
        weights.append(w)
    route.choose(rng.choices(options, weights)[0])


def normal_step(route, rng):
    state = route.engine.snapshot()
    if state["offer"]:
        route.choose("offer.accept" if rng.random() < 0.7 else "offer.decline")
        return
    to_main(route)
    view, main = available(route)
    if "private.begin" in main and rng.random() < 0.35:
        route.choose("private.begin")
        if "menu.touch" in available(route)[1]:
            route.choose("menu.touch")
            touches = [c for c in available(route)[1] if c.startswith("touch.")]
            if touches:
                route.choose(rng.choice(touches))
        return
    if "menu.touch" in main and rng.random() < 0.5:
        route.choose("menu.touch")
        touches = [c for c in available(route)[1] if c.startswith("touch.")]
        if touches:
            route.choose(rng.choice(touches))
            return
        to_main(route)
        main = available(route)[1]
    plain = [c for c in main if not c.startswith(("menu.", "private.end")) or c in ("menu.touch",)]
    plain = [c for c in plain if c != "menu.touch"] or main
    route.choose(rng.choice(plain))


def play(sweep, game, seed, tier, start, steps):
    route = Route(seed, tier=tier, **start)
    try:
        sweep.attach(route, game)
        rng = random.Random(seed * 7919 + game)
        errors = 0
        for _ in range(steps):
            try:
                if route.engine.snapshot()["intimacy"]:
                    intimacy_step(route, rng)
                else:
                    normal_step(route, rng)
            except AssertionError:
                errors += 1  # 選べない選択肢を選ぼうとした（画面が変わった）。次の手へ。
                if errors > steps // 4:
                    raise
        return {"game": game, "seed": seed, "tier": tier, "start": start, "commands": len(route.commands), "skipped": errors,
                "history": route.engine.snapshot()["intimacy_history"]["count"]}
    finally:
        route.close()


def can(route, key):
    """その行動が今選べるか（画面の選択肢で確かめる。ページを開いて、主画面へ戻る）。"""
    identity = "touch." + key
    while route.engine.snapshot()["offer"]:
        route.choose("offer.decline")
    to_main(route)
    rows = {c["id"]: c for c in route.engine.get_view()["choices"]}
    if identity not in rows:
        category = route.engine.pack.intimacy.actions[key]["category"]
        from tools.run_stage_b_routes import PAGES
        route.choose("menu." + PAGES[category])
        rows = {c["id"]: c for c in route.engine.get_view()["choices"]}
        route.choose("menu.main")
    return identity in rows and rows[identity]["available"]


def move(route, speed):
    for key in (speed, "h_move_normal", "h_move_slow"):
        if can(route, key):
            route.action(key)
            return key
    raise AssertionError(("no move", route.status()))


def matrix_route(sweep, tier, pos, finish, seed):
    """体位×慣れ×終わり方を決めた順に通す（公開の選択肢だけ）。"""
    from tools.run_stage_b_routes import DAYTIME
    route = Route(seed, tier=tier, **DAYTIME)
    game = f"{tier}/{pos}/{finish}"
    try:
        sweep.attach(route, game)
        rules = route.engine.pack.intimacy
        route.begin()
        for _ in range(40):
            if route.engine.snapshot()["intimacy"]["maho"]["arousal"] >= 60:
                break
            route.action("h_kiss_deep")
        for key in ("h_strip_lower", "h_shift_under", "h_strip_self"):
            route.action(key)
        if route.engine.snapshot()["intimacy"]["position"] == pos or can(route, "h_pos_" + pos):
            if route.engine.snapshot()["intimacy"]["position"] != pos:
                route.action("h_pos_" + pos)
            route.action("h_insert")
        else:
            # 入れたままでだけ移れる体位（片脚を抱える・脚を肩に）は、つながる体位から移る
            via = next(p for p, row in rules.positions.items() if pos in row["linked"] and row["insertion"])
            route.action("h_pos_" + via)
            route.action("h_insert")
            route.action("h_pos_" + pos)
        done = False
        for speed in ("h_move_slow", "h_move_normal", "h_move_fast"):
            for _ in range(4):
                while route.engine.snapshot()["offer"]:
                    route.choose("offer.decline")
                player = route.engine.snapshot()["intimacy"]["player"]
                if player["arousal"] >= rules.raw["player"]["arousal_max"]:
                    if finish == "overflow":
                        move(route, speed)
                        done = True
                        break
                    if player["endured"] == 0:
                        route.action("h_endure")
                        continue
                    route.action("h_finish_" + ("inside" if finish == "inside" else "outside"))
                    done = True
                    break
                move(route, speed)
            if done:
                break
        if not done:
            while route.engine.snapshot()["offer"]:
                route.choose("offer.decline")
            if finish == "withdraw":
                route.action("h_withdraw")
            elif finish == "overflow":
                for _ in range(30):
                    player = route.engine.snapshot()["intimacy"]["player"]
                    move(route, "h_move_fast")
                    if player["arousal"] >= rules.raw["player"]["arousal_max"]:
                        break
                    while route.engine.snapshot()["offer"]:
                        route.choose("offer.decline")
            else:
                # v8.2.29 で入れてから果てるまでを長くした（1手の高まりを下げた）ので、出せるようになるまで激しく動く
                for _ in range(30):
                    if can(route, "h_finish_" + ("inside" if finish == "inside" else "outside")):
                        break
                    move(route, "h_move_fast")
                    while route.engine.snapshot()["offer"]:
                        route.choose("offer.decline")
                route.action("h_finish_" + ("inside" if finish == "inside" else "outside"))
        while route.engine.snapshot()["offer"]:
            route.choose("offer.decline")
        if can(route, "h_after_hold"):
            route.action("h_after_hold")
        return {"game": game, "success": True}
    except AssertionError as error:
        return {"game": game, "success": False, "error": repr(error)[:300]}
    finally:
        route.close()


def run_matrix(task):
    tier, pos, finish, seed = task
    sweep = Sweep()
    info = matrix_route(sweep, tier, pos, finish, seed)
    return info, sweep.reached, sweep.fallbacks, sweep.selected


def run_game(task):
    game, seed, tier, start, steps = task
    sweep = Sweep()
    info = play(sweep, game, seed, tier, start, steps)
    return info, sweep.reached, sweep.fallbacks, sweep.selected


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--games", type=int, default=60)
    parser.add_argument("--steps", type=int, default=400)
    parser.add_argument("--workers", type=int, default=2)
    parser.add_argument("--matrix", action="store_true", help="体位×慣れ×終わり方の決めた経路も通す")
    args = parser.parse_args()
    from multiprocessing import Pool
    tiers = ("first", "few", "familiar")
    tasks = [(game, 1000 + game, tiers[game % 3], STARTS[(game // 3) % len(STARTS)], args.steps) for game in range(args.games)]
    sweep = Sweep()
    games = []
    with Pool(args.workers) as pool:
        for info, reached, fallbacks, selected in pool.imap_unordered(run_game, tasks):
            games.append(info)
            sweep.reached |= reached
            sweep.fallbacks += fallbacks
            sweep.selected.update(selected)
            print(info, flush=True)
    games.sort(key=lambda g: g["game"])
    if args.matrix:
        rules_positions = json.loads((ROOT / "tools/stage_b/intimacy_009.json").read_text(encoding="utf-8"))["positions"]
        order = {"first": 0, "few": 1, "familiar": 2}
        tasks = [(tier, pos, finish, 7 + i) for i, (tier, pos, finish) in enumerate(
            (t, p, f) for t in tiers for p, row in rules_positions.items() if row["insertion"] and order[t] >= order[row["tier_from"]]
            for f in ("inside", "outside", "overflow", "withdraw"))]
        with Pool(args.workers) as pool:
            for info, reached, fallbacks, selected in pool.imap_unordered(run_matrix, tasks):
                games.append(info)
                sweep.reached |= reached
                sweep.fallbacks += fallbacks
                sweep.selected.update(selected)
                if not info["success"]:
                    print(info, flush=True)
        print("matrix routes", len(tasks), "failed", sum(1 for g in games if g.get("success") is False), flush=True)
    all_jobs = [j["id"] for rows in sweep.jobs.values() for j in rows]
    unreached = sorted(set(all_jobs) - sweep.reached)
    by_meaning = Counter(f["meaning"] for f in sweep.fallbacks if not f["waiting"])
    waiting = Counter(f["meaning"] for f in sweep.fallbacks if f["waiting"])
    result = {"games": games, "b2_jobs": len(all_jobs), "b2_jobs_reached": len(sweep.reached), "b2_jobs_unreached": unreached,
              "fallback_by_meaning": dict(by_meaning.most_common()), "fallback_waiting_supplement": dict(waiting.most_common()),
              "fallback_examples": {m: next(f for f in sweep.fallbacks if f["meaning"] == m) for m in set(by_meaning) | set(waiting)},
              "selected_meanings": len(sweep.selected)}
    (ROOT / "verification/b2_sweep.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print("b2 jobs reached", len(sweep.reached), "/", len(all_jobs), "fallback meanings", len(by_meaning), dict(by_meaning.most_common(20)),
          "waiting supplement", dict(waiting))
    failed = [g for g in games if g.get("success") is False]
    return 1 if by_meaning or failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
