"""Write the A2 handoff from measured results and generated prose provenance."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
read = lambda path: json.loads((ROOT / path).read_text(encoding="utf-8"))
provenance = read("content/releases/interaction_008/rules_provenance.json")["a2_texts"]
measure = read("verification/a2_text_integration.json")
runtime = read("verification/results.json")
rebuild = read("verification/a2_rebuild_check.json")
assert runtime["success"] and runtime["tests_run"] >= 199
assert rebuild["same"]

lines = [
    "# 段階A2本文取り込み報告（v7.1.1）",
    "",
    "対象：`凪島_本体修正版_v7_1_0.zip` から作った `interaction_008`。Opus 採用済み J1〜J4 のみを取り込んだ。受入判定は Opus 5.5 が行う。",
    "",
    "## 変更ファイル",
    "",
    "- `authoring/a2_results/J1_分類結果.json`、`J2_慣れた反応_採用.json`、`J3_台詞なし_採用.json`、`J4_仕事と誘い_採用.json`：受領した採用データ。",
    "- `tools/build_life_release.py`：007から008を決定的に再生成し、J1〜J4と24件の書式修正を適用。",
    "- `content/releases/interaction_008/texts.json`、`release.json`、`rules_provenance.json`：生成結果と出典。007以前は変更なし。",
    "- `nagishima/codec.py`、`nagishima/state.schema.json`：`.a2.J2` 等を使うため、全IDの検証と表示・履歴の本文IDスキーマにASCII大文字を許可した。これは本文IDだけに限定された変更ではなく、v7.1.2で取り消した。",
    "- `nagishima/__main__.py`、`nagishima/__init__.py`、`tools/pack_runtime.py`：既定008、本体2.3.3、ZIP名v7.1.1。",
    "- `tests/test_stage_a.py`、`tools/check_a2_text_integration.py`、`tools/check_a2_rebuild.py`：版の期待値、公開操作による本文測定、再生成の同一性。",
    "- `README.md`、`引き継ぎ.md`、`docs/GPT指示_A2本文の取り込み_v7.1.1.md`、`docs/Opus段階A2監査_v7.1.0_2026-09-25.md`、`tools/write_a2_report.py`、本報告：遊び方と根拠。",
    "",
    "## 受入条件",
    "",
    "- **C-01 合格**：J2 42本、J3 65本、J4 48本を追加。意味・group・条件は元jobから取得し、`slots: []`、`fallback: false`。J4の `」。` は16か所を `」` にした。原稿の出典・Opus判定日をprovenanceに記録。",
    "- **C-02 合格**：J1のsurprise／shy 22件だけに、対応行動の `experience.<行動>.tier != familiar` を追加。fallbackは全件無条件。",
    "- **C-03 合格**：下記24件を008で修正。008全本文の「真帆」を含むかぎかっこは0件。",
    "- **C-04 合格**：008全meaningには無条件fallbackがあり、first／few／familiarの各段階で少なくとも1件が候補になることを確認。",
    "- **C-05 合格**：公開`Engine.choose`による35回連続の測定。手つなぎは両seedとも008で5/35（14.3%）、007で35/35（100%）。抱擁・背中も同じ条件で測定した。",
    "- **C-06 合格**：seed 42／20380407でキスを6回経験した後、別行動で連続記録を区切り、`kiss.start`・`kiss.repeat`を確認。J1のsurprise／shy対象は選ばれなかった。",
    "- **C-07 合格**：元v7.1.0 ZIPと003〜007の39ファイルがバイト単位で同一。v7.0.4由来の003〜007の5本の自動プレイログを新版で再生し、全て成功。",
    f"- **C-08 合格**：`check_runtime.py` {runtime['tests_run']}件成功、失敗{runtime['failures']}・エラー{runtime['errors']}。`verify_text.py`の006／007／008、`audit_autoplay_immersion.py --release interaction_008 --policy presence --seeds 20`、`check_progression_routes.py --release interaction_008` は全て終了コード0。",
    f"- **C-09 合格**：008の{rebuild['file_count']}ファイルのハッシュを採取し、`build_life_release.py --replace-unpublished` の再実行後も差分0。",
    "- **C-10 合格**：`start.bat --json --max-turns 1 --no-autosave` をWindowsで起動し、既定release `interaction_008`、終了理由`quit`、終了コード0を確認。",
    "",
    "### C-05 台詞の割合",
    "",
    "| 行動 | seed | 007 | 008 |",
    "| --- | ---: | ---: | ---: |",
]
by_key = {(item["action"], item["seed"], item["release"]): item for item in measure["measurements"]}
for action in ("hands", "hug", "back"):
    for seed in (42, 20380407):
        old = by_key[(action, seed, "interaction_007")]
        new = by_key[(action, seed, "interaction_008")]
        lines.append(f"| {action} | {seed} | {old['dialogue']}/{old['count']} ({old['dialogue']/old['count']:.1%}) | {new['dialogue']}/{new['count']} ({new['dialogue']/new['count']:.1%}) |")

lines += [
    "",
    "### C-03 かぎかっこ修正の全24件",
    "",
    "| ID | 修正前 | 修正後 |",
    "| --- | --- | --- |",
]
for item in provenance["quoted_narration_fixes"]:
    clean = lambda value: value.replace("|", "\\|").replace("\n", "<br>")
    lines.append(f"| `{item['id']}` | {clean(item['before'])} | {clean(item['after'])} |")

lines += [
    "",
    "## 独自判断・未解決・提案",
    "",
    "指定された大文字のJ番号を採用するため、全IDのバリデーションと、表示・履歴の本文IDスキーマにASCII大文字を許した。既存releaseの本文IDと制御データは変えていない。この検証緩和はv7.1.2で取り消した。24件の修正は指定の選別条件と「真帆」を含むかぎかっこだけに適用した。元のOpus仮本文12件は無条件fallbackとして残し、J4採用本文を優先する。",
    "",
    "実装上の未解決はない。Opusによる最終受入判定は未実施。範囲外の改善提案はない。",
    "",
]
target = ROOT / "docs/段階A2本文取り込み報告_v7.1.1.md"
target.write_text("\n".join(lines), encoding="utf-8", newline="\n")
print(target, len(lines), "lines")
