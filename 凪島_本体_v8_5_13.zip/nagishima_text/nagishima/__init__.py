"""Local, authored-text game runtime. No external services are used."""

__version__ = "2.9.13"
RULES_VERSION = "nagishima-2.4"
SAVE_SCHEMA = 4
