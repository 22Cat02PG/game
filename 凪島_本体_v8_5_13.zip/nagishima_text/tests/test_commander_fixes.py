"""Regression paths for the five defects reviewed by the Opus commander."""

from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
import json
import subprocess
import sys
import unittest

from nagishima.codec import digest, decode, write_json
from nagishima.engine import Engine
from nagishima.context import Context
from nagishima.errors import GameError
from nagishima.session import Session
from nagishima.state import validate_state


ROOT = Path(__file__).resolve().parents[1]


class CommanderFixes(unittest.TestCase):
    def setUp(self):
        temporary = TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.directory = Path(temporary.name)

    def game(self, release="interaction_006", cheats=True, autosave=False):
        return Session(Engine(self.directory / "data", seed=42, release=release,
                              autosave=autosave, test_cheats=cheats), max_turns=200)

    def command(self, game, command, **args):
        result = game.execute({"command": command, **args})
        self.assertTrue(result["ok"], result.get("error"))
        return result

    def choose(self, game, identity):
        return self.command(game, "choose", id=identity)

    def page(self, game, name):
        if game.engine.get_view()["page"] != "main":
            self.choose(game, "menu.main")
        if name != "main":
            self.choose(game, "menu." + name)

    def test_affection_at_25_minutes_is_still_available(self):
        game = self.game()
        self.command(game, "cheat", action="all")
        self.choose(game, "private.begin")
        self.choose(game, "private.end")
        self.page(game, "touch")
        self.choose(game, "touch.hands")
        self.page(game, "main")
        while game.engine.snapshot()["world"]["awake_deadline"] - game.engine.snapshot()["world"]["now"] > 145:
            self.choose(game, "wait.120")
        while game.engine.snapshot()["world"]["awake_deadline"] - game.engine.snapshot()["world"]["now"] > 25:
            self.choose(game, "wait.30")
        state = game.engine.snapshot()
        self.assertEqual(state["world"]["awake_deadline"] - state["world"]["now"], 25)
        self.page(game, "talk")
        result = self.choose(game, "touch.affection")
        self.assertEqual(result["state"]["mode"], "normal")
        self.assertEqual(result["state"]["experience"]["affection"]["count"], 1)
        self.assertIn("affection.first", [block["meaning"] for block in result["view"]["blocks"]])

    def test_affection_still_starts_private_with_enough_time(self):
        game = self.game()
        self.command(game, "cheat", action="all")
        self.choose(game, "private.begin")
        self.choose(game, "private.end")
        self.page(game, "touch")
        self.choose(game, "touch.hands")
        self.page(game, "talk")
        result = self.choose(game, "touch.affection")
        self.assertEqual(result["state"]["mode"], "private")

    def test_affection_skips_private_when_activity_capacity_is_full(self):
        game = self.game()
        self.command(game, "cheat", action="all")
        self.choose(game, "private.begin")
        self.choose(game, "private.end")
        self.page(game, "touch")
        self.choose(game, "touch.hands")
        state = game.engine.snapshot()
        state["activities"] = [{"id": f"test.{i}"} for i in range(4)]
        context = Context(state, game.engine.pack, game.engine.repository, game.engine.get_view(), True)
        context.action("affection")
        self.assertEqual(state["experience"]["affection"]["count"], 1)
        self.assertEqual(state["mode"], "normal")

    def test_new_release_ends_hair_and_back_on_joint_move(self):
        for contact in ("hair", "back"):
            with self.subTest(contact=contact):
                game = Session(Engine(self.directory / contact, seed=42, release="interaction_006",
                                      autosave=False, test_cheats=True))
                self.command(game, "cheat", action="all")
                self.choose(game, "near")
                self.page(game, "touch")
                self.choose(game, "touch." + contact)
                self.page(game, "move")
                result = self.choose(game, "move.joint.kitchen")
                self.assertFalse(result["state"]["contacts"])
                self.assertEqual(result["state"]["distance"], "normal")
                self.assertIn("system.contact_ended", [block["meaning"] for block in result["view"]["blocks"]])
                validate_state(result["state"], game.engine.pack, game.engine.repository, True)

    def test_hands_survive_joint_move_while_hair_ends(self):
        game = self.game()
        self.command(game, "cheat", action="all")
        self.choose(game, "near")
        self.page(game, "touch")
        self.choose(game, "touch.hands")
        self.choose(game, "touch.hair")
        self.page(game, "move")
        result = self.choose(game, "move.joint.kitchen")
        self.assertEqual([x["action_id"] for x in result["state"]["contacts"]], ["hands"])
        self.assertEqual(result["state"]["distance"], "near")

    def test_old_save_starts_without_streak_and_keeps_old_contact_rule(self):
        game = self.game(release="interaction_005")
        self.command(game, "cheat", action="contact_unlock")
        self.choose(game, "near")
        self.page(game, "touch")
        self.choose(game, "touch.hair")
        self.page(game, "move")
        self.command(game, "save")
        path = game.engine.storage.slot_path("slot01")
        old = decode(path.read_bytes())
        del old["payload"]["state"]["interaction_streak"]
        for key in ("affinity", "desire", "maho_sleep"):
            del old["payload"]["state"][key]
        old["payload"]["test_cheats"]["intimacy"] = old["payload"]["test_cheats"].pop("contact_unlock")
        old["schema"], old["rules_version"] = 1, "nagishima-2.1"
        old["sha256"] = digest(old["payload"])
        write_json(path, old)
        loaded = self.game()
        self.command(loaded, "load")
        self.assertIsNone(loaded.engine.snapshot()["interaction_streak"])
        self.assertEqual(loaded.engine.active_release, "interaction_005")
        self.page(loaded, "move")
        result = self.choose(loaded, "move.joint.kitchen")
        self.assertEqual([x["action_id"] for x in result["state"]["contacts"]], ["hair"])
        self.assertEqual(result["state"]["distance"], "near")
        self.command(loaded, "adopt", release="interaction_006")
        self.page(loaded, "move")
        moved = self.choose(loaded, "move.joint.living_room")
        self.assertFalse(moved["state"]["contacts"])
        self.assertEqual(moved["state"]["distance"], "normal")

    def test_new_control_release_rejects_suspended_scene(self):
        game = self.game(release="interaction_005", cheats=False)
        self.page(game, "talk")
        self.choose(game, "begin.two_cups")
        self.choose(game, "scene.pause")
        result = game.execute({"command": "adopt", "release": "interaction_006"})
        self.assertFalse(result["ok"])
        self.assertEqual(result["error"]["code"], "control_change")

    def test_streak_counts_consecutive_actions_across_menu_and_save(self):
        game = self.game()
        self.command(game, "cheat", action="contact_unlock")
        self.page(game, "talk")
        first = self.choose(game, "touch.compliment")
        self.assertEqual(first["view"]["blocks"][-1]["meaning"], "compliment.first")
        self.command(game, "save")
        self.page(game, "main")
        self.page(game, "talk")
        self.assertEqual(game.engine.snapshot()["interaction_streak"], {"action_id": "compliment", "count": 1})
        second = self.choose(game, "touch.compliment")
        third = self.choose(game, "touch.compliment")
        self.assertEqual(second["view"]["blocks"][-1]["meaning"], "compliment.repeat")
        self.assertEqual(third["view"]["blocks"][-1]["meaning"], "compliment.heated")
        self.command(game, "load")
        self.assertEqual(game.engine.snapshot()["interaction_streak"], {"action_id": "compliment", "count": 1})
        self.assertEqual(self.choose(game, "touch.compliment")["view"]["blocks"][-1]["meaning"], "compliment.repeat")

    def test_other_actions_and_wait_break_streak(self):
        game = self.game()
        self.command(game, "cheat", action="contact_unlock")
        self.page(game, "talk")
        self.choose(game, "touch.compliment")
        for _ in range(5):
            self.choose(game, "touch.talk")
        self.assertEqual(self.choose(game, "touch.compliment")["view"]["blocks"][-1]["meaning"], "compliment.start")
        self.page(game, "main")
        self.choose(game, "wait.30")
        self.page(game, "talk")
        self.assertEqual(self.choose(game, "touch.compliment")["view"]["blocks"][-1]["meaning"], "compliment.start")
        self.assertEqual(self.choose(game, "touch.compliment")["view"]["blocks"][-1]["meaning"], "compliment.repeat")
        self.assertEqual(self.choose(game, "touch.compliment")["view"]["blocks"][-1]["meaning"], "compliment.heated")

    def test_choice_preview_does_not_change_streak(self):
        game = self.game()
        self.command(game, "cheat", action="contact_unlock")
        self.page(game, "talk")
        self.choose(game, "touch.compliment")
        before = game.engine.snapshot()
        game.engine.get_view()
        self.command(game, "actions")
        self.assertEqual(game.engine.snapshot(), before)

    def test_posture_contact_end_move_and_sleep_break_streak(self):
        for boundary in ("posture", "contact_end", "move", "sleep"):
            with self.subTest(boundary=boundary):
                game = Session(Engine(self.directory / boundary, seed=42, release="interaction_006",
                                      autosave=False, test_cheats=True))
                self.command(game, "cheat", action="contact_unlock")
                if boundary == "contact_end":
                    self.choose(game, "near")
                    self.page(game, "touch")
                    self.choose(game, "touch.hands")
                self.page(game, "talk")
                self.choose(game, "touch.compliment")
                if boundary == "posture":
                    self.page(game, "touch")
                    self.choose(game, "posture.standing")
                elif boundary == "contact_end":
                    self.page(game, "touch")
                    self.choose(game, "end.hands")
                elif boundary == "move":
                    self.page(game, "move")
                    self.choose(game, "move.joint.kitchen")
                else:
                    self.page(game, "main")
                    self.choose(game, "sleep")
                self.assertIsNone(game.engine.snapshot()["interaction_streak"])

    def test_scene_and_maho_offer_break_streak(self):
        game = self.game()
        self.command(game, "cheat", action="contact_unlock")
        self.page(game, "talk")
        self.choose(game, "touch.compliment")
        self.choose(game, "begin.two_cups")
        self.assertIsNone(game.engine.snapshot()["interaction_streak"])
        self.choose(game, "scene.water")
        self.assertIsNone(game.engine.snapshot()["interaction_streak"])

        other = Session(Engine(self.directory / "offer", seed=42, release="interaction_006",
                               autosave=False, test_cheats=True))
        self.command(other, "cheat", action="all")
        self.choose(other, "near")
        self.page(other, "touch")
        self.choose(other, "touch.kiss")
        self.choose(other, "touch.kiss")
        self.assertEqual(other.engine.snapshot()["offer"]["kind"], "kiss_back")
        self.assertIsNone(other.engine.snapshot()["interaction_streak"])
        self.choose(other, "offer.accept")
        self.assertIsNone(other.engine.snapshot()["interaction_streak"])

    def test_json_bad_numbers_do_not_stop_next_line(self):
        process = subprocess.run(
            [sys.executable, "-m", "nagishima", "--json", "--no-autosave", "--data-dir", str(self.directory / "json"), "--log", str(self.directory / "numbers.jsonl")],
            input='{"command":"state","x":' + "9" * 5000 + '}\n{"command":"state","x":1e999}\n{"command":"state"}\n',
            text=True, encoding="utf-8", capture_output=True, cwd=ROOT,
        )
        records = [json.loads(line) for line in process.stdout.splitlines()]
        self.assertEqual([r["type"] for r in records], ["response", "response", "response", "summary"])
        self.assertFalse(records[0]["ok"])
        self.assertIn(records[0]["error"]["code"], {"invalid_json", "invalid_number"})
        self.assertFalse(records[1]["ok"])
        self.assertEqual(records[1]["error"]["code"], "invalid_number")
        self.assertTrue(records[2]["ok"])
        self.assertEqual(process.returncode, 0, process.stderr)

    def test_old_rules_log_has_dedicated_replay_result(self):
        commands = self.directory / "commands.jsonl"
        commands.write_text('{"command":"quit"}\n', encoding="utf-8")
        log = self.directory / "play.jsonl"
        produced = subprocess.run([sys.executable, "-m", "nagishima", "--batch", str(commands),
                                   "--no-autosave", "--data-dir", str(self.directory / "replay_data"),
                                   "--log", str(log)], capture_output=True, text=True, encoding="utf-8", cwd=ROOT)
        self.assertEqual(produced.returncode, 0, produced.stderr)
        lines = log.read_text(encoding="utf-8").splitlines()
        header = json.loads(lines[0])
        header["rules_version"] = "nagishima-2.1"
        lines[0] = json.dumps(header, ensure_ascii=False)
        log.write_text("\n".join(lines) + "\n", encoding="utf-8")
        replay = subprocess.run([sys.executable, "-m", "nagishima", "--replay", str(log)],
                                capture_output=True, text=True, encoding="utf-8", cwd=ROOT)
        summary = json.loads(replay.stdout.splitlines()[-1])
        self.assertEqual(summary["error"]["code"], "rules_version_mismatch")
        self.assertEqual(summary["run"]["reason"], "rules_version_mismatch")

    def test_autosave_warning_clears_only_after_success(self):
        game = self.game(autosave=True)
        original = game.engine.storage.autosave
        calls = 0

        def flaky(*args):
            nonlocal calls
            calls += 1
            if calls <= 2:
                raise OSError("one simulated failure")
            return original(*args)

        with patch.object(game.engine.storage, "autosave", side_effect=flaky):
            self.page(game, "talk")
            self.choose(game, "touch.talk")
            self.assertTrue(game.engine.get_view()["warnings"])
            self.choose(game, "touch.talk")
            self.assertTrue(game.engine.get_view()["warnings"])
            self.choose(game, "touch.talk")
            self.assertFalse(game.engine.get_view()["warnings"])


if __name__ == "__main__":
    unittest.main()
