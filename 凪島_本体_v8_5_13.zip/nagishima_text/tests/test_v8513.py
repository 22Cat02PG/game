"""v8.5.13（ユーザー 2026-10-09 12:30「では君が最良だと思った方法で進めて　併せて直しも」）：010 だけ。
段階2の本文（同居を始めたころの本文は段階1まで）と、朝の食い違いの直し（条件 sleep.morning・life.morning_line）。仕様 第22.6節。"""
import copy
import unittest
from pathlib import Path

from nagishima.conditions import evaluate
from nagishima.content import Pack
from nagishima.errors import GameError
from nagishima.progression import life_day
from nagishima.stage_b_state import neutral_sleep_record, validate_sleep
from tools.run_stage_b_routes import Route
from tests.test_v8512 import DAILY, LOVER_ONLY, MINUTES, PLACES, MIN_STAGE, base_values, values, candidates, set_stage, go, clear

ROOT = Path(__file__).resolve().parents[1]
P009 = Pack(ROOT / "content/releases/interaction_009")
P010 = Pack(ROOT / "content/releases/interaction_010")
NEW = ("v8512.", "v8513.", "cmp.d12")
NEG = {"after_angry": "cold", "after_guard": "cold", "upset": "cold", "after_awkward": "awkward", "question": "question"}


def wake(stage, reaction=None, night=False, h=False, cooling=None, seed=60, pleasure=60, discomfort=0, level=1, nights=1, day_offset=4):
    """21:30 から眠って起きた朝の本文 [(意味, id)]（nights 回くり返す。最後の朝）と、寝込みの記録。"""
    r = Route(seed, hour=21, minute=30, day_offset=day_offset, release="interaction_010", tier="familiar")
    s = r.engine._state
    s["affinity"]["value"] = 0
    set_stage(r.engine, stage)
    if h:
        s["intimacy_history"]["last_at"] = s["world"]["now"] - 60  # その夜にエッチをした
    if night or cooling:
        s["sleep_record"] = neutral_sleep_record()
    if cooling:
        s["sleep_record"]["cooling"] = {"kind": cooling, "until": life_day(s["world"]["now"]) + 3}
    if night:
        s["sleep_record"]["night"] = {"day": life_day(s["world"]["now"]), "kind": None, "pleasure": pleasure, "discomfort": discomfort, "level": level,
                                      "flags": [], "used": [], "fake_reveal": False, "reaction": reaction}
    r.engine._install_choices()
    for _ in range(nights):  # 二度目からは、起きた朝のまま次の朝まで休む（仕事のない日の朝。day_offset 2＝金曜の夜から）
        clear(r)
        go(r, "main")
        view = r.choose("sleep")
    out = [(b["meaning"], b.get("variant")) for b in view["blocks"] if not b["meaning"].startswith(("world.", "offer."))]
    record = copy.deepcopy(r.engine._state.get("sleep_record"))
    r.close()
    return dict(out), record


class V8513(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.base = base_values()

    def test_009_unchanged(self):
        self.assertFalse([i for i in P009.by_text if i.startswith("v8513.")])
        self.assertTrue([i for i in P010.by_text if i.startswith("v8513.")])

    def test_stage2_sees_only_stage_texts(self):
        """段階2（特別に意識している）では、毎日の場面に同居を始めたころの本文が出ない。どの場面も 3本以上の候補がある。"""
        for meaning in LOVER_ONLY + ["system.listen"]:
            v = values(self.base, relation__stage=2, world__minute=MINUTES.get(meaning, [600])[0], actor__player__location=PLACES.get(meaning, ["living_room"])[0])
            found = candidates(v, meaning)
            self.assertEqual([i for i in found if not i.startswith(NEW)], [], meaning)
            self.assertGreaterEqual(len(found), 3, (meaning, found))

    def test_stage1_keeps_old_texts(self):
        for meaning in ("system.slept", "life.breakfast", "work.lunch", "talk.start", "activity.tea.begin", "system.listen"):
            found = candidates(values(self.base, relation__stage=1), meaning)
            self.assertTrue([i for i in found if not i.startswith(NEW)], meaning)

    def test_texts_cover_every_morning(self):
        """朝の場面は、段・怒っている／警戒している日・翌朝の一言が続くか・その朝の翌朝の一言・関係が進んだ翌朝のどの組み合わせでも、書いた本文が出る。"""
        missing = []
        mornings = ["none", "aware", "after_soft", "fake_reveal", "accept", "accept_invite", "uneasy"] + list(NEG)
        for stage in range(5):
            for cooling in ("none", "angry", "guard"):
                for line in (False, True):
                    for morning in mornings:
                        for days in (0, 1, 3):
                            v = values(self.base, relation__stage=stage, sleep__cooling=cooling, life__morning_line=line, sleep__morning=morning,
                                       progression__days_since_milestone=days, sleep__night__has=False)
                            for meaning in ("system.slept", "life.breakfast"):
                                if not candidates(v, meaning):
                                    missing.append((meaning, stage, cooling, line, morning, days))
        self.assertEqual(missing[:10], [])

    def test_daily_cover_stage2(self):
        """段階2のどの状態でも、毎日の場面に書いた本文がある（これまでの本文を外したので確かめ直す）。"""
        missing = []
        for meaning in DAILY:
            if MIN_STAGE.get(meaning, 0) > 2:
                continue
            for cooling in ("none", "angry", "guard"):
                for hug in (False, True):
                    for together in ((True, False) if meaning == "system.waited" else (True,)):
                        for minute in MINUTES.get(meaning, [600]):
                            for place in PLACES.get(meaning, ["living_room"]):
                                v = values(self.base, relation__stage=2, sleep__cooling=cooling, contact__hug__active=hug, together=together,
                                           world__minute=minute, actor__player__location=place)
                                if not candidates(v, meaning):
                                    missing.append((meaning, cooling, hug, together, minute, place))
        self.assertEqual(missing[:10], [])

    def test_breakfast_follows_morning_line(self):
        """寝込みの翌朝の一言のあとの朝食は、その一言に合わせた本文。ふだんの朝食・関係が進んだ翌朝の朝食・怒っている日の朝食は出さない。"""
        for morning, kind in NEG.items():
            for stage in (0, 2, 3):
                for cooling in ("none", "angry", "guard"):
                    found = candidates(values(self.base, relation__stage=stage, sleep__morning=morning, sleep__cooling=cooling,
                                              progression__days_since_milestone=1, life__morning_line=True), "life.breakfast")
                    self.assertTrue(found and all(i.startswith(f"v8513.breakfast.{kind}.") for i in found), (morning, stage, cooling, found))
        ordinary = candidates(values(self.base, sleep__morning="accept"), "life.breakfast")
        self.assertTrue(ordinary and not [i for i in ordinary if ".breakfast.cold." in i or ".awkward." in i or ".question." in i])

    def test_slept_is_plain_when_morning_line_follows(self):
        for stage in range(5):
            found = candidates(values(self.base, relation__stage=stage, life__morning_line=True), "system.slept")
            self.assertTrue(found and all(".slept.plain." in i for i in found), (stage, found))
            self.assertGreaterEqual(len(found), 8)
            ordinary = candidates(values(self.base, relation__stage=stage), "system.slept")
            self.assertFalse([i for i in ordinary if ".plain." in i], stage)

    def test_morning_after_h_and_sleep_play(self):
        """動かして確かめる：エッチの翌朝・寝たふりで止められた・気まずい・問いただされた・怒らせた朝。"""
        out, record = wake(3, h=True)
        self.assertTrue(out["system.slept"].startswith(("v8512.slept.plain.", "v8513.slept.plain.")), out)
        self.assertTrue([m for m in out if m.startswith("h.morning.")], out)
        self.assertFalse(out["life.breakfast"].startswith("v8513.breakfast."), out)
        for reaction, morning, kind in (("fake_stop", "after_angry", "cold"), ("awkward", "after_awkward", "awkward"), ("angry", "after_angry", "cold")):
            out, record = wake(3, night=True, reaction=reaction)
            self.assertIn("sp.morning." + morning, out)
            self.assertTrue(out["system.slept"].startswith(("v8512.slept.plain.", "v8513.slept.plain.")), out)
            self.assertTrue(out["life.breakfast"].startswith(f"v8513.breakfast.{kind}."), (reaction, out))
            self.assertEqual(record["morning"]["id"], morning)
        out, record = wake(1, night=True, pleasure=10, discomfort=20)  # 目覚めなかった夜。受け入れたことがなく深さが浅い → 問いただす
        self.assertIn("sp.morning.question", out)
        self.assertTrue(out["life.breakfast"].startswith("v8513.breakfast.question."), out)
        out, record = wake(3)  # ふだんの朝
        self.assertTrue(out["system.slept"].startswith("v8512.d2.slept.b3."), out)
        self.assertNotIn("morning", record or {})

    def test_cooling_second_morning(self):
        """怒らせた夜の翌朝は一言に合わせた朝食、その次の朝（まだ怒っている、一言はない）は怒っている日の朝食。"""
        out, record = wake(3, night=True, reaction="angry", cooling="angry", nights=2, day_offset=2)  # 怒らせた記録は夜のうちに付く（ここでは先に置く）
        self.assertFalse([m for m in out if m.startswith("sp.morning.")], out)
        self.assertTrue(out["life.breakfast"].startswith("v8512.d2.breakfast.angry."), out)
        self.assertTrue(out["system.slept"].startswith(("v8512.slept.plain.", "v8513.slept.plain.")), out)

    def test_save_without_morning_record(self):
        """v8.5.12 までの保存（寝込みの記録に morning がない）も読める。morning の形が不正なら止める。"""
        r = Route(61, hour=10, minute=0, day_offset=4, release="interaction_010", tier="familiar")
        state = copy.deepcopy(r.engine._state)
        r.close()
        state["sleep_record"] = neutral_sleep_record()
        validate_sleep(state, P010)
        today = life_day(state["world"]["now"])
        state["sleep_record"]["morning"] = {"day": today, "id": "question"}
        validate_sleep(state, P010)
        for bad in ({"day": today, "id": "nothing"}, {"day": today + 1, "id": "question"}, {"day": today}):
            state["sleep_record"]["morning"] = bad
            with self.assertRaises(GameError):
                validate_sleep(state, P010)

    def test_text_style(self):
        texts = [P010.by_text[i] for i in P010.by_text if i.startswith("v8513.")]
        self.assertEqual(len(texts), 47)
        for t in texts:
            for word in ("湯呑", "湯のみ", "彼女", "わたし", "好き", "恋人", "確かめるように", "肩をすくめ"):
                self.assertNotIn(word, t["body"], t["id"])
            self.assertLessEqual(t["body"].count("真帆"), 2, t["id"])
            self.assertTrue(evaluate(t["when"], values(self.base, relation__stage=2, sleep__morning="question", life__morning_line=True)) in (True, False))


if __name__ == "__main__":
    unittest.main()
