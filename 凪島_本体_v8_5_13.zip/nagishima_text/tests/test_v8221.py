"""v8.2.21：胸を吸いながら手でしてもらう（組み合わせの本文）、胸に口づける速さ、余韻の胸（顔を埋める・甘えて吸う）。
ユーザー 2026-09-29 09:42 の提案から Opus が選んだもの（右胸だけ・左胸だけは見送り）。009 だけに効く。
公開の選択肢（Engine.choose／get_view）から確かめる（高まり・慣れなどの準備だけ内部で行う）。"""
import unittest

from nagishima.auto_continue import auto_next
from tools.run_stage_b_routes import Route


def meanings(engine):
    return [b["meaning"] for b in engine.get_view()["blocks"]]


def contacts(engine):
    return [c["action_id"] for c in engine.snapshot()["contacts"]]


class V8221(unittest.TestCase):
    def route(self, seed, tier="familiar", upper="h_lift_upper"):
        route = Route(seed, tier=tier, day_offset=2)
        self.addCleanup(route.close)
        route.begin()
        for key in ((upper,) if upper else ()) + ("h_strip_lower", "h_strip_self", "h_pos_lying_face"):
            route.action(key)
        return route

    def act(self, route, key):
        while route.engine.snapshot()["offer"]:
            route.choose("offer.decline")  # 途中の真帆の申し出は断る
        route.action(key)
        return meanings(route.engine)

    def set_player(self, route, arousal):
        route.engine._state["intimacy"]["player"]["arousal"] = arousal  # 準備：こちらの高まり
        route.engine._install_choices()

    def assert_authored(self, route):
        for block in route.engine.get_view()["blocks"]:
            self.assertFalse(block["variant"].endswith(".base"), block)

    # ---- 1. 胸に口づける速さ ----
    def test_chest_mouth_pace_has_three_names(self):
        route = self.route(5001)
        self.act(route, "h_chest_mouth")
        labels = {c["id"]: c["label"] for c in route.engine.get_view()["choices"] if c["id"].startswith("pace.h_chest_mouth.")}
        self.assertEqual(labels, {"pace.h_chest_mouth.slow": "舌で乳首を転がす", "pace.h_chest_mouth.fast": "乳首を強く吸う"})
        route.choose("pace.h_chest_mouth.fast")
        self.assertEqual(meanings(route.engine)[0], "h_chest_mouth.pace_fast")
        self.assert_authored(route)
        self.assertIn(self.act(route, "h_chest_mouth")[0], ("h_chest_mouth_fast.continue_short", "h.pat.heat"))  # v8.2.22：短い本文か、頭を撫でる一行
        self.assert_authored(route)
        labels = {c["id"]: c["label"] for c in route.engine.get_view()["choices"] if c["id"].startswith("pace.h_chest_mouth.")}
        self.assertEqual(labels, {"pace.h_chest_mouth.slow": "舌で乳首を転がす", "pace.h_chest_mouth.normal": "乳首を口に含んで吸う"})
        route.choose("pace.h_chest_mouth.slow")
        self.assertEqual(meanings(route.engine)[0], "h_chest_mouth.pace_slow")
        self.assertIn(self.act(route, "h_chest_mouth")[0], ("h_chest_mouth_slow.continue_short", "h.pat.heat"))
        self.assert_authored(route)

    # ---- 2. 胸を吸いながら手でしてもらう ----
    def test_suckle_while_hand_uses_combo_texts(self):
        for tier in ("first", "few", "familiar"):
            with self.subTest(tier=tier):
                route = self.route(5010 + len(tier), tier=tier)
                self.act(route, "h_chest_mouth")
                self.set_player(route, 20)
                self.assertEqual(self.act(route, "h_maho_hand")[0], "h_suckle_hand.start")
                self.assert_authored(route)
                self.assertEqual(sorted(contacts(route.engine)), ["h_chest_mouth", "h_maho_hand"])
                found = []
                for key in ("h_maho_hand", "h_maho_hand", "h_maho_hand", "h_chest_mouth"):
                    self.set_player(route, 20)
                    found.append(self.act(route, key)[0])
                    self.assert_authored(route)
                self.assertTrue(all(m in ("h_suckle_hand.continue", "h_suckle_hand.continue_short", "h.pat.suckle_hand") for m in found), found)  # v8.2.22：頭を撫でる一行も
                self.assertIn("h_suckle_hand.continue_short", found)  # 続けているあいだの短い本文
                self.set_player(route, 90)
                self.assertEqual(self.act(route, "h_finish_hand")[0], "h_suckle_hand.finish")
                self.assert_authored(route)

    def test_combo_starts_either_way_and_overflows(self):
        route = self.route(5021)
        self.set_player(route, 20)
        self.assertIn(self.act(route, "h_maho_hand")[0], ("h_maho_hand.first", "h_maho_hand.start"))  # 手だけのときは、いつもの本文
        self.assertEqual(self.act(route, "h_chest_mouth")[0], "h_suckle_hand.start")  # 手でしてもらっているところで、胸に口づける
        self.set_player(route, 100)
        self.assertEqual(self.act(route, "h_maho_hand")[0], "h_suckle_hand.overflow")  # 限界のまま続けて、こらえきれずに
        self.assert_authored(route)

    def test_auto_continue_keeps_going_with_combo(self):
        route = self.route(5031)
        self.act(route, "h_chest_mouth")
        self.set_player(route, 20)
        self.act(route, "h_maho_hand")
        self.set_player(route, 20)
        route.engine._state["intimacy"]["maho"].update(arousal=20, band="low")
        self.act(route, "h_maho_hand")
        self.assertTrue(meanings(route.engine)[0].startswith("h_suckle_hand."))
        self.assertIsNotNone(auto_next(route.engine.pack, route.engine.snapshot(), route.engine.get_view(), "touch.h_maho_hand"))

    # ---- 3. 余韻の胸 ----
    def finished(self, seed, upper="h_lift_upper"):
        route = self.route(seed, upper=upper)
        self.set_player(route, 90)
        self.act(route, "h_maho_hand")
        self.act(route, "h_finish_hand")
        self.assertTrue(route.engine.snapshot()["intimacy"]["after"])
        return route

    def test_after_actions_only_in_afterglow(self):
        route = self.route(5041)
        choices = {c["id"]: c for c in route.engine.get_view()["choices"]}
        route.choose("menu.main")
        route.choose("menu.h_words")
        choices = {c["id"]: c for c in route.engine.get_view()["choices"]}
        for key in ("touch.h_after_bury", "touch.h_after_suckle"):
            self.assertFalse(choices[key]["available"], key)  # 余韻でないときは選べない

    def test_bury_then_cheek_and_keep_afterglow(self):
        route = self.finished(5042)
        self.assertIn(self.act(route, "h_after_bury")[0], ("h_after_bury.first", "h_after_bury.start"))
        self.assert_authored(route)
        self.assertEqual(self.act(route, "h_after_bury")[0], "h_after_bury.continue")  # 続けると頬ずり
        self.assert_authored(route)
        self.assertTrue(route.engine.snapshot()["intimacy"]["after"])  # 余韻は続く
        self.assertEqual(self.act(route, "h_after_suckle")[0] in ("h_after_suckle.first", "h_after_suckle.start"), True)
        self.assertEqual(contacts(route.engine), ["h_after_suckle"])  # 顔を埋めるのと入れ替わる
        self.assertEqual(self.act(route, "h_after_suckle")[0], "h_after_suckle.continue")
        self.assert_authored(route)
        self.act(route, "h_after_hold")
        self.assertNotIn("h_after_suckle", contacts(route.engine))  # 抱きしめて休むと、顔を上げる
        self.assertTrue(route.engine.snapshot()["intimacy"]["after"])

    def test_bury_with_clothes_on_but_suckle_needs_bare_chest(self):
        route = self.finished(5043, upper=None)
        self.assertIn(self.act(route, "h_after_bury")[0], ("h_after_bury.first", "h_after_bury.start"))
        self.assert_authored(route)
        choices = {c["id"]: c for c in route.engine.get_view()["choices"]}
        self.assertFalse(choices.get("touch.h_after_suckle", {"available": False})["available"])


if __name__ == "__main__":
    unittest.main()
