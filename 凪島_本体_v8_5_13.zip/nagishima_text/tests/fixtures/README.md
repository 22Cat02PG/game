# v6.2 実物の保存・ログ

`v62_normal.json` と `v62_cheat.json` は、未変更の `凪島_本体修正版_v6.2.zip` を展開した本体で作成した。両方とも seed 11、`interaction_006`、自動保存なし、`slot01` を公開 `save` 操作で保存した。通常版は `menu.talk` → `touch.talk` → `menu.main`、チート版は `--test-cheats` の `cheat all` のあとで保存した。生成時の短いスクリプトは修正版 ZIP 外の `verification/create_v62_fixtures.py` に保持している。

`v62_run.jsonl` は同じ v6.2 本体を `--json --seed 11 --no-autosave` で起動し、`{"command":"quit"}` を入力した実物の実行ログ。ルール版不一致をチェックポイントを開く前に検出する試験に使う。

`v712_interaction_007_normal.json`、`v712_interaction_007_cheat.json`、`v712_interaction_008_normal.json`、`v712_interaction_008_cheat.json` は、未変更の `凪島_本体修正版_v7_1_2.zip` を展開した本体で公開 `Engine.save("slot01")` を呼んで作成したschema 3の実物保存。seed 42、自動保存なし。cheat版は `--test-cheats` 相当で `all` を適用した。再作成用の入口は `tools/create_v712_fixtures.py`。段階Bの読込・中立移行試験に使う。
