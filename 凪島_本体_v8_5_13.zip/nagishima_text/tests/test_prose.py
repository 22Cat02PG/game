"""Prose expansion must be visible without changing the shared game rules."""
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from nagishima.autoplay import next_command, next_social_command
from nagishima.content import Pack
from nagishima.engine import Engine
from nagishima.recording import stable
from nagishima.session import Session

ROOT = Path(__file__).resolve().parents[1]
SEMANTIC_FIELDS = ('world', 'actors', 'distance', 'mode', 'relation', 'contacts', 'activities',
                   'facts', 'knowledge', 'experience', 'habits', 'progress', 'promises',
                   'promise_history', 'orders', 'order_history', 'items', 'project', 'history')


class ProseTests(unittest.TestCase):
    def setUp(self):
        temporary = TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.directory = Path(temporary.name)

    def test_reviewed_release_has_four_additions_per_meaning_and_same_rules(self):
        base = Pack(ROOT / 'content/releases/base')
        prose = Pack(ROOT / 'content/releases/prose_001')
        self.assertEqual(prose.control_hash, base.control_hash)
        self.assertEqual(prose.scenes, base.scenes)
        additions = [t for t in prose.texts if '.p001.' in t['id']]
        self.assertEqual(len(additions), 4 * len(base.meanings))
        self.assertEqual(len({t['body'] for t in additions}), len(additions))
        for meaning in base.meanings:
            self.assertEqual(sum(t['meaning'] == meaning for t in additions), 4, meaning)
        self.assertTrue(all(30 <= len(t['body']) <= 500 and not t['fallback'] for t in additions))

    def test_presence_release_adds_daily_variation_without_rule_changes(self):
        source = Pack(ROOT / 'content/releases/prose_001')
        presence = Pack(ROOT / 'content/releases/prose_002')
        self.assertEqual(presence.control_hash, source.control_hash)
        self.assertEqual(presence.scenes, source.scenes)
        additions = [t for t in presence.texts if '.p002.' in t['id']]
        self.assertEqual(len(additions), 32)
        self.assertEqual(len({t['body'] for t in additions}), 32)
        self.assertTrue(all(30 <= len(t['body']) <= 500 and not t['fallback'] for t in additions))

    def test_authored_text_is_selected_and_fallback_remains_when_no_authored_match(self):
        engine = Engine(self.directory / 'expanded', release='prose_001', seed=42, autosave=False)
        state = engine.snapshot()
        for meaning in sorted(engine.pack.meanings):
            text, _ = engine.pack.select(meaning, state, {})
            self.assertFalse(engine.pack.by_text[text['variant']]['fallback'], meaning)
        original = Engine(self.directory / 'base', seed=42, autosave=False)
        self.assertEqual(original.get_view()['blocks'][0]['variant'], 'system.welcome.base')

    def test_public_route_matches_original_gameplay_at_every_command(self):
        base = Session(Engine(self.directory / 'base', seed=42, autosave=False))
        prose = Session(Engine(self.directory / 'prose', release='prose_001', seed=42, autosave=False))
        commands = []
        while base.reason is None:
            command = next_command(base.observe()['view'], base.observe()['state'])
            self.assertIsNotNone(command, {'seed': 42, 'commands': commands})
            commands.append(command)
            left, right = base.execute(command), prose.execute(command)
            self.assertTrue(left['ok'] and right['ok'], {'seed': 42, 'commands': commands})
            for field in SEMANTIC_FIELDS:
                self.assertEqual(left['state'][field], right['state'][field], {'field': field, 'seed': 42, 'commands': commands})
            self.assertEqual(left['view']['choices'], right['view']['choices'])
        self.assertEqual(prose.reason, 'completed')
        self.assertEqual(len(commands), 67)

    def test_expanded_save_preserves_text_then_continues_deterministically(self):
        first = Session(Engine(self.directory / 'first', release='prose_001', seed=81, autosave=False))
        for _ in range(23):
            observation = first.observe()
            self.assertTrue(first.execute(next_command(observation['view'], observation['state']))['ok'])
        first.engine.save()
        restored = Engine(self.directory / 'first', seed=0, autosave=False)
        restored.load()
        self.assertEqual(restored.active_release, 'prose_001')
        self.assertEqual(restored.snapshot(), first.engine.snapshot())
        self.assertEqual(stable(restored.get_view()), stable(first.engine.get_view()))
        for _ in range(12):
            command = next_command(first.engine.get_view(), first.engine.snapshot())
            a, b = first.engine.get_view(), restored.get_view()
            first.engine.choose(command['id'], a['revision'], a['session'])
            restored.choose(command['id'], b['revision'], b['session'])
        self.assertEqual(first.engine.snapshot(), restored.snapshot())
        self.assertEqual(stable(first.engine.get_view()), stable(restored.get_view()))

    def test_old_save_keeps_its_release_until_explicit_adoption(self):
        engine = Engine(self.directory / 'saved', seed=42, autosave=False)
        engine.save()
        engine.adopt_release('prose_001')
        self.assertEqual(engine.active_release, 'prose_001')
        engine.load()
        self.assertEqual(engine.active_release, 'base')

    def test_social_autoplay_accepts_maho_initiatives_and_completes(self):
        for seed in (0, 1, 42, 20380407, 2147483647):
            with self.subTest(seed=seed):
                game = Session(Engine(self.directory / ('social-' + str(seed)), release='prose_001',
                                      seed=seed, autosave=False), max_turns=200)
                commands = []
                while game.reason is None:
                    observed = game.observe()
                    command = next_social_command(observed['view'], observed['state'])
                    self.assertIsNotNone(command, {'seed': seed, 'commands': commands})
                    commands.append(command['id'])
                    self.assertTrue(game.execute(command)['ok'], {'seed': seed, 'commands': commands})
                state = game.observe()['state']
                self.assertEqual(game.reason, 'completed')
                self.assertIn('listen', commands)
                self.assertIn('offer.accept', commands)
                self.assertGreater(state['experience']['hands']['by_origin']['maho'], 0)
                self.assertLessEqual(len(commands), 200)


if __name__ == '__main__':
    unittest.main()
