"""v8.2.12：淫乱度（下がらない）と「二人の記録」（ユーザーの提案 2026-09-28 10:11・10:17、10:18「君に任せる」）。
公開の選択肢から確かめる（高まり・回数などの準備だけ内部で行う）。"""
import copy
import unittest

from tools.run_stage_b_routes import Route


def meanings(engine):
    return [b["meaning"] for b in engine.get_view()["blocks"]]


class V8212(unittest.TestCase):
    def route(self, *args, **kwargs):
        route = Route(*args, **kwargs)
        self.addCleanup(route.close)
        return route

    def ready(self, seed, tier, lewdness=None, upper=False):
        route = self.route(seed, tier=tier, day_offset=2)
        if lewdness is not None:
            route.engine.enable_test_cheat("lewdness:" + str(lewdness))
        route.begin()
        for key in ["h_strip_lower", "h_shift_under", "h_strip_self"] + (["h_strip_upper"] if upper else []) + ["h_pos_lying_face"]:
            route.action(key)
        return route

    def set_experience(self, route, key, count):
        now = route.engine.snapshot()["world"]["now"]
        route.engine._state["experience"][key] = {"count": count, "first_at": now - 2880, "last_at": now - 1440, "by_origin": {"player": count, "maho": 0}}
        route.engine._install_choices()

    def end(self, route):
        if route.engine.snapshot()["offer"]:
            route.choose("offer.decline")
        if route.engine.get_view()["page"] != "main":
            route.choose("menu.main")
        route.choose("h.end")
        while route.engine.snapshot()["offer"] and route.engine.snapshot()["offer"]["kind"] == "hold_back":
            route.choose("offer.decline")

    def history(self, route):
        return route.engine.snapshot()["intimacy_history"]

    # ---- 淫乱度の上がり方 ----
    def test_lewdness_grows_by_session_satisfaction_climaxes_and_new_act(self):
        route = self.ready(801, "few")
        self.assertEqual(self.history(route)["lewdness"], 0)
        # 準備：真帆が2回達して満たされた。この回に「服の上から胸に触れる」を初めてした
        route.action("h_chest_over")
        route.engine._state["intimacy"]["maho"].update(climaxes=2, climax_source="finger", satisfaction=90)
        route.engine._state["intimacy"]["player"]["finishes"] = 1
        route.engine._install_choices()
        self.end(route)
        hist = self.history(route)
        self.assertEqual(hist["last_result"], "satisfied")
        self.assertEqual(hist["lewdness"], 1 + 1 + 2 + 1)  # 毎回・満足・達した2回・初めての行為
        self.assertEqual((hist["maho_climaxes"], hist["finishes"]), (2, 1))

    def test_lewdness_never_decreases_and_caps(self):
        route = self.ready(811, "familiar", lewdness=99)
        route.action("h_chest_over")
        route.engine._state["intimacy"]["maho"].update(climaxes=1, climax_source="finger", satisfaction=90)
        route.engine._install_choices()
        self.end(route)
        self.assertEqual(self.history(route)["lewdness"], 100)
        other = self.ready(812, "familiar", lewdness=40)
        self.end(other)  # 何もないまま終えた回：下がらず、上がりもしない（読み手の指摘 S-8）
        self.assertEqual(self.history(other)["last_result"], "unsatisfied")
        self.assertEqual(self.history(other)["lewdness"], 40)

    def test_short_session_does_not_raise_lewdness(self):
        route = self.route(813, tier="few", day_offset=2)
        route.begin()  # 口づけて始めて、すぐ終える
        self.end(route)
        self.assertEqual((self.history(route)["count"], self.history(route)["lewdness"]), (2, 0))

    def test_cheat_needs_history(self):
        route = self.route(821, tier="first", day_offset=2)
        with self.assertRaises(Exception):
            route.engine.enable_test_cheat("lewdness:50")

    # ---- 効き目 ----
    def test_bold_maho_offers_after_one_request(self):
        found = {}
        for lewdness in (0, 80):
            offered = False
            for seed in range(831, 851):
                route = self.ready(seed, "familiar", lewdness=lewdness, upper=True)
                self.set_experience(route, "h_maho_breasts", 1)  # 1回だけお願いした
                route.engine._state["intimacy"]["player"]["arousal"] = 30
                route.engine._install_choices()
                for _ in range(3):
                    route.action("h_chest_skin")
                    offer = route.engine.snapshot()["offer"]
                    if offer and offer["kind"] == "h_help_breasts":
                        offered = True
                        break
                    if offer:
                        route.choose("offer.decline")
                if offered:
                    break
            found[lewdness] = offered
        self.assertEqual(found, {0: False, 80: True})  # 恥ずかしがりは3回、大胆なら1回で申し出る

    def test_bold_maho_begs_earlier(self):
        for lewdness, expect in ((0, False), (80, True)):
            route = self.ready(861, "few", lewdness=lewdness)
            route.engine._state["intimacy"]["maho"].update(arousal=65, band="mid")  # 準備：焦らして 70〜79 になるところ
            route.engine._install_choices()
            route.action("h_tease")
            self.assertEqual("h.sign.beg" in meanings(route.engine), expect, lewdness)

    def test_lewd_band_condition(self):
        route = self.ready(871, "few", lewdness=60)
        values = route.engine.pack.registry.values(route.engine.snapshot())
        self.assertEqual((values["intimacy.lewdness"], values["intimacy.lewd_band"]), (60, "eager"))

    # ---- 二人の記録 ----
    def test_records_page_is_read_only(self):
        first = self.route(881, tier="first", day_offset=2)
        self.assertNotIn("menu.records", [c["id"] for c in first.engine.get_view()["choices"]])
        route = self.route(882, tier="familiar", day_offset=2)
        route.engine.enable_test_cheat("lewdness:30")
        self.set_experience(route, "h_maho_mouth", 4)
        self.set_experience(route, "h_pos_from_behind", 2)
        before = copy.deepcopy(route.engine.snapshot())
        route.choose("menu.records")
        view = route.engine.get_view()
        self.assertEqual(view["page_title"], "二人の記録")
        record = view["record"]
        self.assertEqual((record["count"], record["lewdness"], record["lewd_band"], record["lewd_label"]), (5, 30, "open", "素直になってきた"))
        self.assertEqual(record["top_acts"][0], {"label": "口でしてもらう", "count": 4})
        self.assertEqual(record["top_positions"][0], {"label": "後ろからにする", "count": 2})
        self.assertTrue(record["maho_line"].startswith("「"))
        route.engine.get_view()
        after = route.engine.snapshot()
        self.assertEqual(after["world"], before["world"])  # 時間・乱数・操作番号を進めない
        self.assertEqual(after["intimacy_history"], before["intimacy_history"])
        self.assertEqual([c["id"] for c in view["choices"]], ["menu.main"])

    def test_maho_line_follows_band_and_result(self):
        route = self.route(891, tier="familiar", day_offset=2)
        route.engine.enable_test_cheat("lewdness:90")
        route.choose("menu.records")
        line = route.engine.get_view()["record"]["maho_line"]
        bold = [t["body"] for t in route.engine.pack.by_meaning["record.maho_line"] if t["id"].startswith("o25.record.maho_line.bold.satisfied.")]
        self.assertTrue(bold)
        self.assertIn(line, bold)  # v8.2.30：慣れのチートは、数日前に満たされて終えた扱い

    def test_lewd_texts_alternate_with_existing(self):
        # 段の本文と既存の本文を交互に出す（段の本文ばかりにならない。読み手の指摘 S-1）
        route = self.route(897, tier="familiar", day_offset=2)
        route.engine.enable_test_cheat("lewdness:80")
        pack, engine = route.engine.pack, route.engine
        lewd = pack._lewd_text_ids()
        state = engine._state
        picked = []
        for _ in range(4):
            variant = pack.select("h.ended.satisfied", state, {})[0]["variant"]
            picked.append(variant in lewd)
            state["recent_text"].append({"id": variant, "group": pack.by_text[variant]["group"]})  # 準備：出したことにする
        self.assertIn(True, picked)
        self.assertIn(False, picked)

    def test_record_without_maho_nearby_has_no_line(self):
        route = self.route(898, tier="familiar", day_offset=2)
        route.engine._state["actors"]["maho"]["location"] = "town"  # 準備：真帆は町にいる
        route.engine._install_choices()
        route.choose("menu.records")
        record = route.engine.get_view()["record"]
        self.assertIsNone(record["maho_line"])
        self.assertEqual(record["count"], 5)

    def test_record_excludes_withdraw_endure_finish_and_resets_on_first(self):
        route = self.route(899, tier="familiar", day_offset=2)
        for key, n in (("h_withdraw", 9), ("h_endure", 8), ("h_finish_inside", 7), ("h_kiss_deep", 3)):
            self.set_experience(route, key, n)
        route.choose("menu.records")
        labels = [row["label"] for row in route.engine.get_view()["record"]["top_acts"]]
        self.assertEqual(labels, ["深く口づける"])
        route.engine.enable_test_cheat("intimacy_tier:first")  # 記録の画面を開いたまま未経験に戻すと、いつもの時間へ
        self.assertEqual(route.engine.get_view()["page"], "main")
        self.assertNotIn("record", route.engine.get_view())

    def test_status_shows_lewdness_with_affinity(self):
        route = self.route(895, tier="few", day_offset=2)
        route.engine.enable_test_cheat("lewdness:12")
        self.assertEqual(route.engine.get_view()["status"]["lewdness"], 12)


if __name__ == "__main__":
    unittest.main()
