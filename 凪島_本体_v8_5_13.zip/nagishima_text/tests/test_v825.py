"""v8.2.5：一気に奥まで入れる（h_insert_deep、ユーザー了承 2026-09-28）と、grok の第7陣の本文。
公開の選択肢から確かめる（時刻・高まりなどの準備だけ内部で行う）。"""
import unittest

from tools.run_stage_b_routes import Route


def choices(engine):
    return {c["id"]: c for c in engine.get_view()["choices"]}


def meanings(engine):
    return [b["meaning"] for b in engine.get_view()["blocks"]]


def variants(engine):
    return [b["variant"] for b in engine.get_view()["blocks"]]


class V825(unittest.TestCase):
    def route(self, *args, **kwargs):
        route = Route(*args, **kwargs)
        self.addCleanup(route.close)
        return route

    def ready(self, seed, tier, arousal, band, position="h_pos_player_above"):
        route = self.route(seed, tier=tier, day_offset=2)
        route.begin()
        for key in ("h_strip_lower", "h_shift_under", "h_strip_self", position):
            route.action(key)
        route.engine._state["intimacy"]["maho"].update(arousal=arousal, band=band)  # 準備：真帆の高まり
        route.engine._install_choices()
        return route

    def test_deep_insert_needs_few_tier(self):
        route = self.ready(81, "first", 85, "high")
        route.choose("menu.main")
        route.choose("menu.h_connect")
        self.assertNotIn("touch.h_insert_deep", choices(route.engine))  # v8.2.19（ユーザー）：回数で開く行為は、開くまで一覧に出さない

    def test_deep_insert_when_she_is_ready(self):
        slow = self.ready(82, "few", 85, "high")
        slow.action("h_insert")
        gain_slow = slow.engine.snapshot()["intimacy"]["maho"]["arousal"]
        route = self.ready(82, "few", 85, "high")
        route.action("h_insert_deep")
        state = route.engine.snapshot()["intimacy"]
        self.assertTrue(state["inserted"])
        self.assertEqual(meanings(route.engine)[0], "h_insert_deep.start")
        self.assertTrue(variants(route.engine)[0].startswith(("o12.h_insert_deep.face.few.", "p7.h_insert_deep.start.few.face.", "x6.h_insert_deep.start.few.face.")), variants(route.engine))  # v8.2.7：grok の本文（第7陣 07・08）も
        self.assertGreater(state["maho"]["arousal"], gain_slow)  # ゆっくり入れるより高まる
        self.assertGreater(state["player"]["arousal"], slow.engine.snapshot()["intimacy"]["player"]["arousal"])

    def test_deep_insert_deflected_until_she_is_high(self):
        route = self.ready(83, "familiar", 60, "mid")
        route.action("h_insert_deep")
        self.assertFalse(route.engine.snapshot()["intimacy"]["inserted"])
        self.assertIn("h.deflect.deep", meanings(route.engine))
        self.assertTrue(variants(route.engine)[meanings(route.engine).index("h.deflect.deep")].startswith("o12.h.deflect.deep."))
        route.action("h_insert")  # ゆっくりなら入れる
        self.assertTrue(route.engine.snapshot()["intimacy"]["inserted"])

    def test_deep_insert_back_facing_texts(self):
        route = self.ready(84, "familiar", 85, "high", position="h_pos_from_behind")
        route.action("h_insert_deep")
        self.assertTrue(variants(route.engine)[0].startswith(("o12.h_insert_deep.back.familiar.", "p7.h_insert_deep.start.familiar.back.", "x6.h_insert_deep.start.familiar.back.")), variants(route.engine))

    def test_deep_insert_at_the_limit_finishes_on_entry(self):
        route = self.ready(85, "few", 85, "high")
        route.engine._state["intimacy"]["player"]["arousal"] = 100  # 準備：限界
        route.engine._install_choices()
        route.choose("menu.main")
        route.choose("menu.h_connect")
        self.assertEqual(choices(route.engine)["touch.h_insert_deep"]["label"], "一気に奥まで入れる（もうこらえきれない）")
        route.choose("touch.h_insert_deep")
        state = route.engine.snapshot()["intimacy"]
        self.assertEqual((state["inserted"], state["player"]["finishes"], state["mess"]), (True, 1, "inside"))
        found = meanings(route.engine)
        self.assertIn("h_overflow.insert_deep", found)  # v8.2.7（精査 F-9）：一気に奥までの限界は専用の meaning
        self.assertFalse(any(m.startswith("h_insert_deep.") for m in found), found)
        # v8.2.6：達する場面なので、grok の濃い本文が先に出る（v8.2.18：写しをやめ、第13陣の専用の本文 x12.）
        self.assertTrue(variants(route.engine)[found.index("h_overflow.insert_deep")].startswith("x12.h_overflow.insert_deep.few.face."), variants(route.engine))

    def test_wave7_texts_are_in_with_face_condition(self):
        pack = self.route(86).engine.pack
        for meaning in ("h_endure.hand", "h_endure.mouth", "h_wipe.start", "h.sign.sensitive"):
            grok = [t for t in pack.by_meaning[meaning] if t["id"].startswith("p7.")]
            self.assertGreaterEqual(len(grok), 10, meaning)
        back = {"field": "intimacy.facing", "op": "ne", "value": "back"}
        for t in pack.by_meaning["h.sign.sensitive"]:
            if t["id"].startswith("p7."):
                self.assertIn(back, t["when"]["all"], t["id"])  # 顔を書く本文は、背を向けた体位では出さない
        self.assertNotIn("p7.h_endure.hand.few.s.v3", pack.by_text)  # 不採用
        self.assertIn("止められ", pack.by_text["p7.h_endure.hand.few.s.v2"]["body"])  # 直し


if __name__ == "__main__":
    unittest.main()
