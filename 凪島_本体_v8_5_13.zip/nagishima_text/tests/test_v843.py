"""v8.4.3（ユーザー 2026-10-06 12:11「やっていいよ」＝v8.4.2 の提案 2つ）：010 だけ。
- 体位を移る本文が、移る前の体位（向き）を条件に使える（intimacy.position_from・facing_from）。前の向きを前提にした本文は、合う移り方のときだけ出す。
  背を向けた体位・顔面騎乗などから移るときのために書いた本文（「仰向けに返す」など）を、最近出ていない限り先に出す。
- 暮らしで両手をつないでいるあいだは、真帆やこちらの手が、つないだ手のほかのことをしている本文を出さない。両手をつないでいるとき用の本文を足した。
  手をつないでいるあいだは、真帆が「手、つないでもいい？」と誘わない。"""
import json
import unittest
from pathlib import Path

from nagishima.conditions import evaluate
from nagishima.content import Pack
from tools.run_stage_b_routes import Route

ROOT = Path(__file__).resolve().parents[1]
P009 = Pack(ROOT / "content/releases/interaction_009")
P010 = Pack(ROOT / "content/releases/interaction_010")
TIERS = ("first", "few", "familiar")
# 前の向きを前提にした本文（代表）：向かい合う体位から移るときだけ
FACE_ONLY = ("o13.h_pos_player_above.start.s.v1", "p1.h_pos_leg_up.start.few_familiar.s.v2", "p3.h_pos_legs_shoulder.start.familiar.s.v1", "p10.h_pos_face_sit.start.familiar.n.v3")
# 暮らしで両手をつないでいるあいだは出さない本文（代表）
HANDS_BUSY = ("cheek_kiss.first.o2.1", "o34.kiss.maho.familiar.s.v2", "p3.push_down.start.before_h.s.v1", "offer.closeness.p001.1", "talk.heated.i003.draft2")
# 両手をつないでいても出せない場面（その触れ合いと両手は同時に続かない／誘いのもとで止める）
HB_UNREACHABLE = ("offer.closeness", "system.contact_ended.hug", "system.contact_ended.lap_take")


def act(route, key):
    while route.engine.snapshot()["offer"]:
        route.choose("offer.decline")
    route.action(key)


def move_values(target, origin, tier, inserted=False):
    pos = P010.intimacy.positions
    return {"intimacy.position": target, "intimacy.facing": pos[target]["facing"], "intimacy.position_from": origin, "intimacy.facing_from": pos[origin]["facing"],
            "intimacy.tier": tier, "intimacy.inserted": inserted, "together": True, "intimacy.active": True}


def hb_values(**extra):
    values = {"contact.hands_both.active": True, "together": True, "intimacy.active": False}
    values.update({f"contact.{k}.active": False for k in P010.actions["hands_both"]["replaces"]})
    values.update(extra)
    return values


class V843(unittest.TestCase):
    def test_009_unchanged(self):
        self.assertFalse(P009.intimacy.position_from)
        self.assertFalse(P009.intimacy.position_from_prefer)
        self.assertTrue(P010.intimacy.position_from_prefer)
        self.assertFalse(any(t["id"].startswith("v843.") for t in P009.by_text.values()))
        self.assertNotIn("contact.hands_both.active", json.dumps(P009.catalog["goals"]["closeness"]["when"]))

    def test_position_from_recorded_and_preferred(self):
        """後ろから → 真帆の上に重なる：移る前の体位を持ち、「仰向けに返す」本文（v843）を先に出す。"""
        for seed in (8431, 8432, 8433):
            route = Route(seed, tier="familiar", release="interaction_010", hour=21, day_offset=2)
            self.addCleanup(route.close)
            route.begin()
            for _ in range(10):
                if route.engine.snapshot()["intimacy"]["maho"]["arousal"] >= 50:
                    break
                act(route, "h_kiss_deep")
            act(route, "h_lift_upper")
            act(route, "h_pos_from_behind")
            self.assertEqual(route.engine.snapshot()["intimacy"]["position_from"], "sitting_close")
            act(route, "h_pos_player_above")
            state = route.engine.snapshot()
            self.assertEqual(state["intimacy"]["position_from"], "from_behind")
            chosen = state["recent_text"][-1]["id"]
            # v8.4.14：後ろからの体位から移る組み合わせた本文（前半 mpaback）も、移る前の体位に合わせた本文
            self.assertTrue(chosen.startswith("v843.h_pos_player_above.start.bed.") or (chosen.startswith("cmp.h_pos_player_above.start.") and "mpaback" in chosen.rsplit(".", 2)[1]), chosen)

    def test_face_only_texts_not_from_back(self):
        """向かい合う体位から移るときだけの本文は、背を向けた体位・顔面騎乗・シックスナインから移るときは出ない。"""
        for identity in FACE_ONLY:
            text = P010.by_text[identity]
            target = text["meaning"][len("h_pos_"):-len(".start")]
            inserted = identity.startswith("o13.")
            values = move_values(target, "leg_up" if inserted else "lying_face", "familiar", inserted)
            for facing in ("back", "face_sit", "sixty_nine"):
                self.assertIs(evaluate(text["when"], dict(values, **{"intimacy.facing_from": facing})), False, (identity, facing))
            self.assertIsNot(evaluate(text["when"], values), False, identity)

    def test_every_move_has_texts(self):
        """どの移り方（移る前の体位 × 回 × 入れたまま）でも、体位を移る本文が 2本以上ある（限界で顔面騎乗・シックスナインへは移れないので除く）。"""
        raw = P010.intimacy.raw
        pos = raw["positions"]
        for key, action in raw["actions"].items():
            if not key.startswith("h_pos_"):
                continue
            target = action["sets"]["position"]
            for ti, tier in enumerate(TIERS):
                if TIERS.index(pos[target]["tier_from"]) > ti:
                    continue
                for origin in action["positions"]:
                    if TIERS.index(pos[origin]["tier_from"]) > ti:
                        continue
                    for inserted in (False, True):
                        if inserted and origin not in pos[target]["linked"]:
                            continue
                        meanings = [key + ".start"] + ([] if inserted or not pos[target]["insertion"] else ["h_limit_move.start"])
                        for meaning in meanings:
                            values = move_values(target, origin, tier, inserted)
                            rows = [t for t in P010.by_meaning[meaning] if not t["fallback"] and evaluate(t["when"], values) is not False]
                            self.assertGreaterEqual(len(rows), 2, (meaning, origin, target, tier, inserted))

    def test_back_origin_texts(self):
        """背を向けた体位から向かい合う体位へ：移る前の体位を条件にした本文がある。"""
        for target in ("player_above", "lying_face", "sitting_close", "maho_above", "sitting_face"):
            for origin in ("from_behind", "side_lying", "prone_back", "standing_back", "reverse_ride"):
                rows = [t for t in P010.by_meaning[f"h_pos_{target}.start"] if t["id"].startswith("v843.") and evaluate(t["when"], move_values(target, origin, "familiar")) is not False]
                self.assertGreaterEqual(len(rows), 1, (origin, target))
        rows = [t for t in P010.by_meaning["h_limit_move.start"] if t["id"].startswith("v843.") and evaluate(t["when"], move_values("player_above", "from_behind", "few")) is not False]
        self.assertGreaterEqual(len(rows), 2)

    def test_daily_hands_busy_texts(self):
        for identity in HANDS_BUSY:
            text = P010.by_text[identity]
            self.assertIs(evaluate(text["when"], hb_values(**{"intimacy.history_count": 0, "intimacy.tier": "few", "experience.kiss.tier": "familiar"})), False, identity)
            self.assertIsNot(evaluate(text["when"], hb_values(**{"contact.hands_both.active": False, "intimacy.history_count": 0, "intimacy.tier": "few",
                                                                "experience.kiss.tier": "familiar"})), False, identity)

    def test_daily_meanings_keep_texts(self):
        """両手をつないでいるあいだも、条件を足した場面に本文が残る（両手と同時に続かない場面を除く）。"""
        busy = [t for t in P010.by_text.values() if '"contact.hands_both.active", "op": "eq", "value": false' in json.dumps(t["when"], ensure_ascii=False)
                and not t["meaning"].startswith(("h_", "h.", "offer.h_"))]
        self.assertGreater(len(busy), 150)
        for meaning in sorted({t["meaning"] for t in busy} - set(HB_UNREACHABLE)):
            for extra in ({"intimacy.history_count": 0}, {"intimacy.history_count": 1}):
                rows = [t for t in P010.by_meaning[meaning] if not t["fallback"] and evaluate(t["when"], hb_values(**extra)) is not False]
                self.assertGreaterEqual(len(rows), 1, (meaning, extra))

    def test_closeness_not_offered_while_holding(self):
        goal = P010.catalog["goals"]["closeness"]
        base = {"relation.stage": 3, "experience.hands.count": 0, "contact.finger_lace.active": False}
        self.assertIs(evaluate(goal["when"], dict(base, **{"contact.hands_both.active": True})), False)
        self.assertIs(evaluate(goal["when"], dict(base, **{"contact.hands_both.active": False})), True)

    def test_walk_ends_hands_both(self):
        """散歩を始める・続けるときは、両手をつなぐを終える（010）。片手をつなぐは続く。"""
        self.assertEqual(P010.life.contact_stops, {"walk": frozenset({"hands_both"})})
        self.assertEqual(P009.life.contact_stops, {})

    def test_daily_cheek_kiss_while_holding(self):
        route = Route(8434, release="interaction_010", hour=19, minute=30, day_offset=5)
        self.addCleanup(route.close)
        for key in ("near", "touch.hands_both", "touch.cheek_kiss"):
            if route.engine.get_view()["page"] != "touch":
                route.choose("menu.touch")
            route.choose(key)
        state = route.engine.snapshot()
        self.assertIn("hands_both", [c["action_id"] for c in state["contacts"]])
        self.assertTrue(state["recent_text"][-1]["id"].startswith("v843.cheek_kiss."), state["recent_text"][-1]["id"])

    def test_new_texts(self):
        rows = [t for t in P010.by_text.values() if t["id"].startswith("v843.")]
        self.assertGreaterEqual(len(rows), 80)
        for text in rows:
            self.assertFalse(text["fallback"])
            fields = json.dumps(text["when"], ensure_ascii=False)
            if text["meaning"].startswith(("h_pos_", "h_limit_move")):
                self.assertRegex(fields, r"intimacy\.(position|facing)_from", text["id"])
            else:
                self.assertIn('"contact.hands_both.active", "op": "eq", "value": true', fields, text["id"])


if __name__ == "__main__":
    unittest.main()
