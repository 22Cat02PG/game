"""v8.5.11（ユーザー 2026-10-09 0:00「次は日常パートを仕上げて」）：010 だけ。段階C：島の町（喫茶店・売店）・釣り・休日の昼の支度・町で頼む・新しく始めたときの導入。
仕様 docs/凪島_段階C_仕様_2026-10-08.md の第21節。"""
import tempfile
import unittest
from pathlib import Path

from nagishima import clock
from nagishima.conditions import evaluate
from nagishima.content import Pack
from nagishima.engine import Engine
from nagishima.progression import life_day
from tools.run_stage_b_routes import Route

ROOT = Path(__file__).resolve().parents[1]
P009 = Pack(ROOT / "content/releases/interaction_009")
P010 = Pack(ROOT / "content/releases/interaction_010")
SPECIES = list(P010.life.fishing["species"])
DINNER_ONLY = {"v852.k5a.begin.lover.01", "v852.k5b.begin.near.01"}  # 夕食を書いた台所の始まりの本文（休日の昼には出さない）


def route(hour=10, minute=30, day_offset=3, stage=3, seed=11, lewd=None):
    """day_offset 3 は土曜（Route の始まりの 4月7日が水曜）。"""
    r = Route(seed, hour=hour, minute=minute, day_offset=day_offset, release="interaction_010", tier="familiar")
    state = r.engine._state
    state["relation"]["stage"] = stage
    if lewd is not None:
        state["affinity"]["value"], state["desire"] = 80, 70
        state["intimacy_history"]["lewdness"] = lewd
    r.engine._install_choices()
    return r


def go(r, page):
    view = r.engine.get_view()
    if view["page"] != page:
        if view["page"] != "main":
            r.choose("menu.main")
        if page != "main":
            r.choose("menu." + page)


def choices(r):
    view = r.engine.get_view()
    return {c["id"]: (c["available"], view["explanations"].get(c["id"])) for c in view["choices"]}


def blocks(view, meaning):
    return [b for b in view["blocks"] if b["meaning"] == meaning]


def where(r):
    s = r.engine._state
    return s["actors"]["player"]["location"], s["actors"]["maho"]["location"]


def shown(r, meaning):
    """最後に出た、その意味の本文の id。"""
    return next(x["id"] for x in reversed(r.engine._state["recent_text"]) if P010.by_text[x["id"]]["meaning"] == meaning)


def authored(values, meaning):
    return [t["id"] for t in P010.by_meaning[meaning] if not t["fallback"] and evaluate(t["when"], values) is True]


def holiday_offset(seed, rain):
    """Route の day_offset で、雨の（雨でない）土曜を探す。"""
    r = Route(seed, release="interaction_010")
    base = r.engine._state["world"]["now"] // 1440
    r.close()
    for offset in range(3, 200, 7):
        if (clock.weather(seed, base + offset) == "rain") == rain:
            return offset
    raise AssertionError("見つからない")


class V8511(unittest.TestCase):
    def test_rules_009_unchanged(self):
        self.assertIsNone(P009.life.town)
        self.assertIsNone(P009.life.fishing)
        self.assertIsNone(P009.life.holiday_lunch)
        self.assertNotIn("cafe", P009.catalog["locations"])
        self.assertNotIn("opening", P009.scenes)
        self.assertEqual(P010.catalog["locations"]["cafe"]["group"], "island")
        self.assertEqual(set(P010.life.town["places"]), {"cafe", "shop"})
        self.assertEqual(len(SPECIES), 19)
        self.assertIn("opening", P010.scenes)

    def test_texts_cover_every_state(self):
        """新しい場面は、どの状態でも書いた本文が出る（仮の本文「（…）」にならない）。町では、これまでの移動・食事の本文を出さない。"""
        r = route()
        base = P010.registry.values(r.engine._state)
        r.close()
        for place in ("cafe", "shop"):
            for together in (True, False):
                for visits in range(0, 7):
                    for weather in ("clear", "cloudy", "rain"):
                        for weekday, minute in ((2, 600), (2, 1080), (5, 1080)):
                            values = dict(base, **{"actor.player.location": place, "together": together, "town.visits": visits, "world.weather": weather,
                                                   "world.weekday": weekday, "world.minute": minute, "world.season": "summer"})
                            found = authored(values, "system.moved")
                            self.assertTrue(found, (place, together, visits, weather))
                            self.assertTrue(all(x.startswith("v8511.") for x in found), found)
                            if together and visits == 0:
                                self.assertTrue(all(".first." in x for x in found), found)
            for together in (True, False):
                self.assertTrue(authored(dict(base, together=together), "town.close." + place))
        for item in ("tea", "mug", "shelf"):
            for together in (True, False):
                self.assertTrue(authored(dict(base, together=together), "town.order." + item))
        for minute in (600, 1019, 1020, 1190):
            values = dict(base, **{"actor.player.location": "cafe", "world.minute": minute})
            self.assertTrue(authored(values, "activity.meal.begin") and authored(values, "activity.meal.end"))
            self.assertTrue(all(x.startswith("v8511.") for x in authored(values, "activity.meal.begin")))
        for kind in ("cafe_tea", "shop_browse", "fishing"):
            for stage in range(5):
                for weather in ("clear", "cloudy", "rain"):
                    for slot, minute in (("morning", 420), ("noon", 800), ("evening", 1050), ("evening", 1200), ("night", 1300)):
                        for season_name in ("spring", "summer", "autumn", "winter"):
                            values = dict(base, **{"relation.stage": stage, "world.weather": weather, "world.slot": slot, "world.minute": minute, "world.season": season_name})
                            self.assertTrue(authored(values, f"activity.{kind}.begin"), (kind, stage, weather, slot, season_name))
        # 釣りの終わりは、釣果（19種と、何も釣れない）と初めてかで書き分ける
        for caught in SPECIES + ["none"]:
            for new in ((True, False) if caught != "none" else (False,)):
                found = authored(dict(base, **{"fish.last": caught, "fish.new": new}), "activity.fishing.end")
                self.assertTrue(found, (caught, new))
                self.assertTrue(all((".end." + caught) in x and (x.split(".")[-2] == "new") == new for x in found), found)
        for key, row in P010.life.fishing["species"].items():
            self.assertEqual("fish.dinner." + key in P010.meanings, row["dinner"], key)
            if row["dinner"]:
                self.assertTrue(authored(base, "fish.dinner." + key), key)
        # 町で頼む：服・場所・淫乱度のどれでも
        for place in ("cafe", "shop"):
            for outfit in ("work", "casual", "room"):
                for band in ("eager", "bold"):
                    values = dict(base, **{"actor.player.location": place, "actor.maho.outfit": outfit, "intimacy.lewd_band": band})
                    self.assertTrue(authored(values, "ask.show.town.under"), (place, outfit))
                    if band == "bold":
                        self.assertTrue(authored(values, "ask.show.town.inside"), (place, outfit))
                for kind in ("hand", "mouth"):
                    self.assertTrue(authored(dict(base, **{"actor.player.location": place}), f"ask.serve.{kind}.begin.town"))
        for meaning in ("ask.show.decline.town", "ask.serve.close.town", "ask.serve.hand.begin.town_home", "ask.serve.mouth.begin.town_home", "life.lunch.holiday"):
            self.assertTrue(authored(base, meaning), meaning)
        for node in ("island", "maho", "home", "places", "end"):
            self.assertTrue(authored(base, "opening." + node), node)

    def test_kitchen_texts_by_meal(self):
        """休日の昼の支度では、夕食を書いた本文を出さない。釣った魚がある日の夕食の支度は、魚を書いた始まりの本文だけ。"""
        r = route()
        base = P010.registry.values(r.engine._state)
        r.close()
        for stage in range(5):
            lunch = dict(base, **{"event.meal": "lunch", "event.phase": "pre", "relation.stage": stage, "fish.dinner": None})
            begin = authored(lunch, "ev.kitchen.begin")
            self.assertTrue(begin and not set(begin) & DINNER_ONLY, begin)
            self.assertTrue(any(".lunch." in x for x in begin))
            for meaning in ("ev.kitchen.pre.talk", "ev.kitchen.timeout", "ev.kitchen.notice.invite", "ev.kitchen.offer.decline"):
                self.assertTrue(authored(lunch, meaning), (stage, meaning))
            self.assertFalse([x for x in authored(lunch, "ev.kitchen.pre.talk") if x.startswith("v852.") and ("夕" in P010.by_text[x]["body"] or "夜" in P010.by_text[x]["body"])])
            fish = dict(base, **{"event.meal": "dinner", "relation.stage": stage, "fish.dinner": "aji"})
            begin = authored(fish, "ev.kitchen.begin")
            self.assertTrue(begin and all(".kitchen.begin.fish." in x for x in begin), begin)
            plain = authored(dict(fish, **{"fish.dinner": None}), "ev.kitchen.begin")
            self.assertTrue(plain and not any(".fish." in x for x in plain))

    def test_town_hours_and_closing(self):
        r = route(hour=9, minute=30)
        go(r, "move")
        self.assertEqual(choices(r)["move.joint.cafe"], (False, "喫茶店が開いているのは10時から20時まで。"))
        self.assertTrue(choices(r)["move.joint.shop"][0])
        view = r.choose("move.joint.shop")
        self.assertEqual(where(r), ("shop", "shop"))
        self.assertIn(".moved.shop.first.", shown(r, "system.moved"))
        self.assertEqual(r.engine._state["town"]["visits"], {"shop": 1})
        self.assertNotIn("system.moved", [b["meaning"] for b in view["blocks"][:-1]])
        # 閉まる時刻まで待つと、二人で家へ（待つのは閉まる時刻まで）
        r.engine._state["world"]["now"] = r.engine._state["world"]["now"] // 1440 * 1440 + 18 * 60 + 50
        r.engine._state["world"]["processed_until"] = r.engine._state["world"]["now"]
        r.engine._install_choices()
        go(r, "main")
        view = r.choose("wait.120")
        self.assertTrue(blocks(view, "town.close.shop"))
        self.assertIn(".close.shop.together.", shown(r, "town.close.shop"))
        self.assertEqual(where(r), ("living_room", "living_room"))
        self.assertEqual(clock.format_time(r.engine._state["world"]["now"])[-5:], "19:10")
        r.close()
        # 一人で来て閉まると、一人で帰る（真帆は家のまま）
        r = route(hour=19, minute=30)
        go(r, "move")
        r.choose("move.solo.cafe")
        self.assertEqual(where(r), ("cafe", "living_room"))
        self.assertIn(".moved.cafe.alone.", shown(r, "system.moved"))
        self.assertNotIn("town", r.engine._state)  # 二人で来た回数は数えない
        go(r, "main")
        view = r.choose("wait.30")
        self.assertIn(".close.cafe.alone.", shown(r, "town.close.cafe"))
        self.assertEqual(where(r)[0], "living_room")
        r.close()

    def test_visits_first_and_regular(self):
        r = route()
        regular = P010.life.town["regular_from"]
        for visit in range(1, regular + 2):
            go(r, "move")
            r.choose("move.joint.cafe")
            moved = shown(r, "system.moved")
            self.assertEqual(r.engine._state["town"]["visits"]["cafe"], visit)
            if visit == 1:
                self.assertIn(".first.", moved)
            else:
                self.assertNotIn(".first.", moved)
            values = P010.registry.values(r.engine._state)
            tea = authored(values, "activity.cafe_tea.begin")
            self.assertEqual(any(".regular." in x for x in tea), visit >= regular, visit)
            moving = authored(dict(values, **{"town.visits": visit}), "system.moved")
            self.assertEqual(any(".regular." in x for x in moving), visit + 1 >= regular, visit)  # 次に着いたときの本文（足す前の回数で見る）
            go(r, "move")
            r.choose("move.joint.shop")
        r.close()

    def test_shop_order(self):
        r = route(hour=10, minute=0)  # 土曜
        go(r, "orders")
        self.assertEqual({k: v for k, v in choices(r).items() if k.startswith("shop.")},
                         {k: (False, "売店で頼む。") for k in ("shop.tea", "shop.mug", "shop.shelf")})  # 売店にいないときはグレーアウト
        go(r, "move")
        r.choose("move.joint.shop")
        go(r, "orders")
        self.assertEqual({k: v for k, v in choices(r).items() if k.startswith("shop.")}, {k: (True, None) for k in ("shop.tea", "shop.mug", "shop.shelf")})
        view = r.choose("shop.mug")
        self.assertTrue(blocks(view, "town.order.mug"))
        self.assertFalse(blocks(view, "order.created"))
        self.assertIn(".order.mug.together.", shown(r, "town.order.mug"))
        go(r, "orders")
        r.choose("shop.shelf")
        orders = {o["catalog_id"]: o["due_at"] for o in r.engine._state["orders"]}
        today = r.engine._state["world"]["now"] // 1440
        self.assertEqual(orders["mug"], (today + 1) * 1440 + 600)  # 翌日の定型便
        self.assertEqual(clock.date_time(orders["shelf"]).weekday(), 3)  # 木曜の補給便
        r.close()

    def test_fishing_time_rain_and_book(self):
        r = route(hour=22, minute=0)
        go(r, "move")
        r.choose("move.joint.pier")  # 22:10
        go(r, "activities")
        self.assertTrue(choices(r)["activity.fishing"][0])
        r.engine._state["world"]["now"] += 6  # 22:16 から始めると 23時を過ぎる
        r.engine._state["world"]["processed_until"] = r.engine._state["world"]["now"]
        r.engine._install_choices()
        self.assertEqual(choices(r)["activity.fishing"], (False, "夜釣りは23時まで。今からでは、もう竿を出せない。"))
        r.close()
        offset = holiday_offset(11, True)
        r = route(hour=8, minute=0, day_offset=offset)
        go(r, "move")
        r.choose("move.joint.pier")
        caught = []
        for _ in range(4):
            go(r, "activities")
            view = r.choose("activity.fishing")
            begin = shown(r, "activity.fishing.begin")
            self.assertTrue(".begin.rain." in begin or ".wait." in begin, begin)  # 雨の日は、雨を書いた本文か待つ間の本文
            view = r.choose("scene.finish")
            fish = r.engine._state["fish"]
            self.assertTrue(blocks(view, "activity.fishing.end"))
            self.assertIn(".end." + fish["last"], shown(r, "activity.fishing.end"))
            caught.append(fish["last"])
            self.assertNotEqual(fish["last"], "aoriika")  # 雨の濁りを嫌う
        self.assertEqual(r.engine._state["fish"]["sessions"], 4)
        book = r.engine._state["fish"]["book"]
        self.assertEqual(sum(book.values()), len([x for x in caught if x != "none"]))
        if book:
            go(r, "activities")
            view = r.choose("fish.book")
            self.assertIn("真帆の手帳の、釣った魚のページ。", blocks(view, "fish.book")[0]["body"])
        r.close()

    def test_fish_dinner(self):
        r = route(hour=18, minute=20, day_offset=3)
        state = r.engine._state
        state["cooldowns"] = [c for c in state["cooldowns"] if c["group"] != "meal_dinner"]
        state["fish"] = {"book": {"aji": 1, "kusafugu": 1}, "day": life_day(state["world"]["now"]), "sessions": 2, "last": "kusafugu", "new": True, "dinner": "aji"}
        r.engine._install_choices()
        for _ in range(4):
            r.choose("wait.30")
            if state.get("event_play") or r.engine._state.get("event_play"):
                break
        play = r.engine._state["event_play"]
        self.assertEqual(play["meal"], "dinner")
        self.assertIn(".kitchen.begin.fish.", shown(r, "ev.kitchen.begin"))
        view = r.choose("event.leave")
        self.assertTrue(blocks(view, "fish.dinner.aji"))
        self.assertFalse(blocks(view, "life.dinner"))
        self.assertIsNone(r.engine._state["fish"]["dinner"])
        r.close()

    def test_holiday_lunch(self):
        r = route(hour=11, minute=50)
        r.choose("wait.30")
        play = r.engine._state["event_play"]
        self.assertEqual((play["kind"], play["meal"]), ("kitchen", "lunch"))
        self.assertNotIn(shown(r, "ev.kitchen.begin"), DINNER_ONLY)
        labels = {c["id"]: c["label"] for c in r.engine.get_view()["choices"]}
        self.assertIn("event.leave", labels)
        view = r.choose("event.leave")
        self.assertTrue(blocks(view, "life.lunch.holiday"))
        self.assertEqual(where(r), ("living_room", "living_room"))
        self.assertTrue(any(c["group"] == "meal_lunch" for c in r.engine._state["cooldowns"]))
        r.close()
        r = route(hour=12, minute=5, day_offset=0)  # 平日は始まらない
        self.assertIsNone(r.engine._state.get("event_play"))
        r.close()
        r = route(hour=11, minute=50)  # 町にいるあいだは始まらない
        go(r, "move")
        r.choose("move.joint.cafe")
        go(r, "main")
        r.choose("wait.30")
        self.assertIsNone(r.engine._state.get("event_play"))
        r.close()

    def test_town_ask(self):
        """町で「してもらう」：大胆の段でなければ、真帆が家（主人公の部屋）へ連れて帰る。大胆なら店の隠れ場所（トイレの個室・裏手の路地）で。"""
        for lewd, place, home in ((20, "cafe", True), (65, "cafe", False), (65, "shop", False)):
            r = route(hour=14, minute=0, lewd=lewd)
            go(r, "move")
            r.choose("move.joint." + place)
            go(r, "touch")
            view = r.choose("ask.serve.hand")
            if home:
                self.assertTrue(blocks(view, "ask.serve.hand.begin.town_home"))
                self.assertEqual(where(r), ("player_room", "player_room"))
            else:
                self.assertTrue(blocks(view, "ask.serve.hand.begin.town"))
                self.assertEqual(where(r), (place, place))
                self.assertIn(("トイレの個室" if place == "cafe" else "店の裏手の路地"), r.engine.get_view()["status"]["ask"]["place"])
            while "ask.finish" not in choices(r):
                r.choose("ask.next")
            view = r.choose("ask.finish")
            self.assertTrue(blocks(view, "ask.serve.close." + ("home" if home else "town")))
            r.close()
        r = route(hour=14, minute=0, lewd=20)  # 町では、見せては「自分から求める」段から
        go(r, "move")
        r.choose("move.joint.shop")
        go(r, "touch")
        view = r.choose("ask.show")
        self.assertTrue(blocks(view, "ask.show.decline.town"))
        r.close()

    def test_opening(self):
        with tempfile.TemporaryDirectory() as data:
            engine = Engine(data, seed=5, release="interaction_010", autosave=False, opening=True)
            view = engine.get_view()
            self.assertEqual([b["meaning"] for b in view["blocks"]], ["opening.island"])
            self.assertEqual([c["id"] for c in view["choices"]], ["scene.next", "scene.skip"])
            now = engine._state["world"]["now"]
            view = engine.choose("scene.next", view["revision"], view["session"])
            self.assertEqual(view["blocks"][-1]["meaning"], "opening.maho")
            view = engine.choose("scene.skip", view["revision"], view["session"])
            self.assertEqual(view["blocks"][-1]["meaning"], "opening.end")
            self.assertIsNone(engine._state["scene"])
            self.assertEqual(engine._state["world"]["now"], now)
            self.assertIn("work.go", [c["id"] for c in view["choices"]])
        for release, opening in (("interaction_010", False), ("interaction_009", True)):
            with tempfile.TemporaryDirectory() as data:
                engine = Engine(data, seed=5, release=release, autosave=False, opening=opening)
                self.assertEqual([b["meaning"] for b in engine.get_view()["blocks"]], ["system.welcome"])


if __name__ == "__main__":
    unittest.main()
