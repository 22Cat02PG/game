"""v8.2.20：続けているあいだの短い本文と、テキスト版の「自動で続ける」（ユーザー 2026-09-29）。009 だけに効く。
公開の選択肢（Engine.choose／get_view）とテキスト版の画面から確かめる（高まり・慣れなどの準備だけ内部で行う）。"""
import contextlib
import io
import json
import unittest
from copy import deepcopy
from pathlib import Path
from unittest import mock

import nagishima.__main__ as cli
from nagishima.auto_continue import auto_next
from nagishima.session import Session
from nagishima.stage_b_state import validate as validate_intimacy_state
from tools.run_stage_b_routes import Route
from tools.build_intimacy_release import text_fix_conditions

ROOT = Path(__file__).resolve().parents[1]


def meanings(engine):
    return [b["meaning"] for b in engine.get_view()["blocks"]]


class FakeLog:
    path = "（試験）"

    def __init__(self):
        self.lines = []

    def command(self, raw, token, response):
        self.lines.append(raw)


class V8220(unittest.TestCase):
    def route(self, seed, tier="familiar", arousal=45):
        route = Route(seed, tier=tier, day_offset=2)
        self.addCleanup(route.close)
        return route

    def connect(self, route, arousal=45):
        route.begin()
        for key in ("h_strip_lower", "h_shift_under", "h_strip_self", "h_pos_lying_face"):
            route.action(key)
        route.engine._state["intimacy"]["maho"].update(arousal=arousal, band="mid")  # 準備：入れられるところまで
        route.engine._install_choices()
        route.action("h_insert")
        return route

    def calm(self, route):
        """準備：真帆とこちらの高まりを下げて、達する・限界の本文が混ざらないようにする（本文の出し分けだけを見る）。"""
        intimate = route.engine._state["intimacy"]
        intimate["maho"].update(arousal=30, band="mid")
        intimate["player"]["arousal"] = 10
        route.engine._install_choices()

    def move(self, route, times):
        found = []
        for _ in range(times):
            self.calm(route)
            while route.engine.snapshot()["offer"]:
                route.choose("offer.decline")
            route.action("h_move_normal")
            found.append(meanings(route.engine)[0])
        return found

    # ---- 1. 短い本文 ----
    def test_short_texts_between_long_ones(self):
        """v8.2.23：長い本文は始めだけ。続けている手（しばらく続けた手も）は、ずっと短い本文（long_every 0）。"""
        route = self.connect(self.route(2001))
        found = self.move(route, 7)
        self.assertEqual(found, ["h_move_normal.start"] + ["h_move_normal.continue_short"] * 6)
        for block in route.engine.get_view()["blocks"]:
            self.assertFalse(block["variant"].endswith(".base"), block)

    def test_long_setting_keeps_long_texts(self):
        """v8.2.29（ユーザー 2026-09-30「なにこれ」）：設定「続けるときの本文」はなくした（いつも短い1行。test_v8229 で前の保存の long も確かめる）。"""
        route = self.route(2002)
        route.choose("menu.settings")
        self.assertFalse([c["id"] for c in route.engine.get_view()["choices"] if c["id"].startswith("settings.continue_text.")])

    def test_other_moves_also_short(self):
        route = self.connect(self.route(2003))
        found = []
        for _ in range(3):
            self.calm(route)
            route.action("h_move_slow")
            found.append(meanings(route.engine)[0])
        self.assertEqual(found, ["h_move_slow.start", "h_move_slow.continue_short", "h_move_slow.continue_short"])  # v8.2.22：ほかの動く行為も短い本文

    def test_old_saves_without_setting_are_valid(self):
        route = self.route(2004)
        state = deepcopy(route.engine.snapshot())
        self.assertNotIn("continue_text", state["settings"])  # 既定は保存に書かない（v8.2.19 までの保存と同じ形）
        validate_intimacy_state(state, route.engine.pack)
        state["settings"]["continue_text"] = "short"
        validate_intimacy_state(state, route.engine.pack)
        state["settings"]["continue_text"] = "tiny"
        with self.assertRaises(Exception):
            validate_intimacy_state(state, route.engine.pack)

    def test_short_texts_copy_source_conditions(self):
        """切り出し（sh.・sh2.）は、もとの本文の条件と濃さを写す。v8.2.23：熱さの札（heat）があれば高まりの条件を1つ足す。台詞・声のあとで改行する。"""
        pack = self.route(2005).engine.pack
        data = json.loads((ROOT / "tools/stage_b/short_texts.json").read_text(encoding="utf-8"))["texts"]
        shorts = [t for t in pack.texts if t["id"].startswith(("sh.", "sh2."))]
        self.assertEqual(len(shorts), len(data))
        self.assertEqual({row["cut"] for row in data}, {1, 2})
        forms, heats = {}, {}
        fix_when, _, _ = text_fix_conditions()
        for row in data:
            text, source = pack.by_text[("sh." if row["cut"] == 1 else "sh2.") + row["source"]], pack.by_text[row["source"]]
            self.assertEqual(text["meaning"], source["meaning"].rsplit(".", 1)[0] + ".continue_short")
            extra = text["when"]["all"][len(source["when"]["all"]):]
            extra = [c for c in extra if c not in fix_when.get(text["id"], [])]  # v8.2.26（精査 C U-5）：短い1行そのものに足した条件は除く
            self.assertEqual(text["when"]["all"][:len(source["when"]["all"])], source["when"]["all"])
            if row.get("heat"):
                heat = extra or [c for c in source["when"]["all"] if c["field"] in ("intimacy.maho.band", "intimacy.player.arousal_band")]  # v8.2.27：もとの本文が同じ条件を持つときは重ねない
                self.assertEqual(len(heat), 1, row)
                self.assertIn(heat[0]["field"], ("intimacy.maho.band", "intimacy.player.arousal_band"))
                self.assertEqual(heat[0]["value"][0] == "low", row["heat"] == "early", row)
            else:
                self.assertEqual(extra, [], row)
            self.assertEqual(text.get("style"), source.get("style"))
            self.assertEqual(text["body"].count("「"), {"s": 1, "d": 1, "a": 0, "b": 1}[row["form"]], row)
            if row["form"] == "d":
                self.assertTrue(text["body"].startswith("「") and text["body"].endswith("」"), row)
            if row["form"] in ("s", "b"):
                self.assertEqual(text["body"].count("\n"), 1, row)  # 台詞・声と地の文のあいだで改行
            else:
                self.assertNotIn("\n", text["body"], row)
            forms[row["form"]] = forms.get(row["form"], 0) + 1
            heats[row.get("heat")] = heats.get(row.get("heat"), 0) + 1
            self.assertLessEqual(len(text["body"]), 62, row)
        self.assertEqual(set(forms), {"s", "d", "a", "b"})
        self.assertEqual(set(heats), {"early", "late", None})

    def test_source_of_recent_short_is_avoided(self):
        """v8.2.23：同じ長い本文から切り出した2本（sh.・sh2.）は、片方が最近出ていれば、もう片方も選ばない（ほかに本文があるとき）。"""
        route = self.connect(self.route(2006))
        self.move(route, 1)
        pack, state = route.engine.pack, route.engine.snapshot()
        values = pack.registry.values(state)
        meaning = "h_move_normal.continue_short"
        from nagishima.conditions import evaluate
        pool = [t for t in pack.by_meaning[meaning] if evaluate(t["when"], values) is True and not t["fallback"]]
        pair = next(t for t in pool if t["id"].startswith("sh.") and "sh2." + t["id"][3:] in {x["id"] for x in pool})
        sibling = pack.by_text["sh2." + pair["id"][3:]]
        other = next(t for t in pool if t["id"].startswith("q."))
        original = pack.by_meaning[meaning]
        self.addCleanup(lambda: pack.by_meaning.__setitem__(meaning, original))
        for first, second in ((pair, sibling), (sibling, pair)):
            for order in ((second, other), (other, second)):
                pack.by_meaning[meaning] = list(order)
                trial = deepcopy(state)
                trial["recent_text"].append({"id": first["id"], "group": first["group"], "release": pack.id})
                self.assertEqual(pack.select(meaning, trial, {}, values)[0]["variant"], other["id"])

    # ---- 2. 自動で続ける ----
    def test_auto_next_rules(self):
        route = self.connect(self.route(2011))
        pack = route.engine.pack
        self.calm(route)
        route.action("h_move_normal")
        wait = auto_next(pack, route.engine.snapshot(), route.engine.get_view(), "touch.h_move_normal")
        self.assertIsNotNone(wait)
        auto = pack.intimacy.auto
        self.assertTrue(auto["min_ms"] <= wait <= auto["max_ms"])
        self.assertIsNone(auto_next(pack, route.engine.snapshot(), route.engine.get_view(), "touch.h_move_slow"))  # 続けていない行為
        # 真帆がもうすぐ・こちらが限界・申し出があるときは止める
        state = route.engine.snapshot()
        near = deepcopy(state)
        near["intimacy"]["maho"]["arousal"] = pack.intimacy.raw["maho"]["arousal_bands"]["near_from"]
        self.assertIsNone(auto_next(pack, near, route.engine.get_view(), "touch.h_move_normal"))
        limit = deepcopy(state)
        limit["intimacy"]["player"]["arousal"] = pack.intimacy.raw["player"]["arousal_max"]
        self.assertIsNone(auto_next(pack, limit, route.engine.get_view(), "touch.h_move_normal"))
        offered = deepcopy(state)
        offered["offer"] = {"kind": "h_lead_straddle"}
        self.assertIsNone(auto_next(pack, offered, route.engine.get_view(), "touch.h_move_normal"))
        # 行為の本文と止めない合図のほかの本文（達した、など）が出たら止める
        view = deepcopy(route.engine.get_view())
        view["blocks"].append({"meaning": "h.climax.maho", "body": "…", "variant": "x", "release": "interaction_009"})
        self.assertIsNone(auto_next(pack, state, view, "touch.h_move_normal"))

    def test_auto_skips_actions_not_listed(self):
        route = self.route(2012)
        route.begin()
        route.action("h_kiss_deep")
        self.assertIsNone(auto_next(route.engine.pack, route.engine.snapshot(), route.engine.get_view(), "touch.h_kiss_deep"))  # 口づけは自動にしない

    def test_cli_continues_until_key(self):
        route = self.connect(self.route(2013, tier="familiar"))
        self.calm(route)
        route.engine._state["intimacy"]["maho"]["arousal"] = 0  # 準備：3手のうちに真帆がもうすぐにならないように
        session = Session(route.engine, 400, test_cheats=True)
        log = FakeLog()
        waits = iter([("next", None), ("next", None), ("stop", None)])
        buffer = io.StringIO()
        with mock.patch.object(cli, "wait_key", side_effect=lambda ms: next(waits)), \
                mock.patch("builtins.input", side_effect=["choose touch.h_move_normal", EOFError]), contextlib.redirect_stdout(buffer):
            cli.interactive(session, log)
        output = buffer.getvalue()
        self.assertEqual(log.lines, ['{"command": "choose", "id": "touch.h_move_normal"}'] * 3)  # 手で1回、自動で2回（実行ログに残る）
        self.assertIn("（自動で続ける・ふつう　Enter で次へ／ほかのキーで止める）", output)
        self.assertIn("（自動を止めた）", output)
        self.assertEqual(output.count("（自動で続ける・"), 3)  # v8.2.28：案内は待つたびに出す（v8.2.20〜27 は1手目だけ）

    def test_cli_toggle(self):
        route = self.connect(self.route(2014))
        self.calm(route)
        session = Session(route.engine, 400, test_cheats=True)
        log = FakeLog()
        buffer = io.StringIO()
        with mock.patch.object(cli, "wait_key", side_effect=AssertionError("自動を切ったのに待った")), \
                mock.patch("builtins.input", side_effect=["自動", "choose touch.h_move_normal", EOFError]), contextlib.redirect_stdout(buffer):
            cli.interactive(session, log)
        self.assertIn("自動で続ける：切", buffer.getvalue())
        self.assertEqual(len(log.lines), 1)


if __name__ == "__main__":
    unittest.main()
