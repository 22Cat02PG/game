"""v8.2.11：「続いている」の表示に追加（玉も・先端も）を添える（ユーザーの質問 2026-09-28 13:39）。胸・足でしてもらう最中の体位の一文。
grok 第9陣・第10陣の取り込み（本文の中身は tools/check_stage_b_texts.py と遊び回りで確かめる）。"""
import unittest

from tools.run_stage_b_routes import Route


class V8211(unittest.TestCase):
    def route(self, *args, **kwargs):
        route = Route(*args, **kwargs)
        self.addCleanup(route.close)
        return route

    def ready(self, seed, tier, upper=False):
        route = self.route(seed, tier=tier, day_offset=2)
        route.begin()
        for key in ["h_strip_lower", "h_strip_self"] + (["h_strip_upper"] if upper else []) + ["h_pos_lying_face"]:
            route.action(key)
        return route

    def decline(self, route):
        if route.engine.snapshot()["offer"]:
            route.choose("offer.decline")

    def status(self, route):
        return route.engine.get_view()["status"]

    def test_held_actions_show_extras(self):
        route = self.ready(601, "familiar")
        route.action("h_maho_mouth")
        self.decline(route)
        self.assertEqual(self.status(route)["held_actions"], ["口でしてもらう"])
        self.assertEqual(self.status(route)["intimacy"]["position"], "真帆が、こちらの脚のあいだに身をかがめている。")
        route.action("h_extra_balls")
        self.decline(route)
        self.assertEqual(self.status(route)["held_actions"], ["口でしてもらう（玉も）"])
        route.choose("menu.main") if route.engine.get_view()["page"] != "main" else None
        route.choose("end.h_maho_mouth")
        self.assertEqual(self.status(route)["held_actions"], [])

    def test_breasts_pose_line_and_lick_mark(self):
        route = self.ready(611, "familiar", upper=True)
        route.action("h_maho_breasts")
        self.decline(route)
        self.assertEqual(self.status(route)["intimacy"]["position"], "真帆が、こちらの脚のあいだで胸を寄せている。")
        route.action("h_extra_lick")
        self.decline(route)
        self.assertEqual(self.status(route)["held_actions"], ["胸でしてもらう（先端も）"])

    def test_text_ui_prints_held_line(self):
        import contextlib
        import io
        from nagishima.__main__ import show

        class Session:
            turns, max_turns = 0, 999

            def __init__(self, engine):
                self.engine = engine

            def observe(self):
                return {"view": self.engine.get_view(), "state": self.engine.snapshot()}

        route = self.ready(621, "familiar")
        route.action("h_maho_hand")
        self.decline(route)
        route.action("h_extra_balls")
        self.decline(route)
        out = io.StringIO()
        with contextlib.redirect_stdout(out):
            show(Session(route.engine))
        self.assertIn("続いている：手でしてもらう（玉も）", out.getvalue())


if __name__ == "__main__":
    unittest.main()
