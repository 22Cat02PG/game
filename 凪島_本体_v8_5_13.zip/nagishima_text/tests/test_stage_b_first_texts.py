"""Stage B spec revision 2: first-time action texts are used only in the tier they were written for.

行為の「初めて」の本文（`.first`）は、書いた慣れの段階（初回、または数回）の回でだけ出す。
それより慣れた回に初めてする行為は、その回の慣れの「始め」（`.start`）の本文を出す。
"""
import tempfile
import unittest

from nagishima.engine import Engine


class FirstTextsFollowTier(unittest.TestCase):
    def play_first_deep_kiss(self, tier):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        engine = Engine(temp.name, seed=42, release="interaction_009", autosave=False, test_cheats=True)
        engine.enable_test_cheat("all")
        today = engine._state["world"]["now"] // 1440
        engine._state["world"]["now"] = today * 1440 + 19 * 60
        engine._state["world"]["processed_until"] = engine._state["world"]["now"]
        engine._install_choices()
        engine.enable_test_cheat("intimacy_tier:" + tier)
        result = None
        for identity in ("private.begin", "menu.touch", "touch.h_kiss_deep"):
            view = engine.get_view()
            option = next(c for c in view["choices"] if c["id"] == identity)
            self.assertTrue(option["available"], (identity, option))
            result = engine.choose(identity, view["revision"], view["session"])
        self.assertEqual(engine.snapshot()["experience"]["h_kiss_deep"]["count"], 1)
        return [b for b in result["blocks"] if b["meaning"].startswith("h_kiss_deep.")]

    def test_first_tier_uses_first_text(self):
        blocks = self.play_first_deep_kiss("first")
        self.assertEqual([b["meaning"] for b in blocks], ["h_kiss_deep.first"])
        self.assertTrue(blocks[0]["variant"].startswith("b1.h_kiss_deep.first.first."), blocks[0]["variant"])

    def test_later_tiers_use_start_text_of_their_tier(self):
        for tier in ("few", "familiar"):
            with self.subTest(tier=tier):
                blocks = self.play_first_deep_kiss(tier)
                self.assertEqual([b["meaning"] for b in blocks], ["h_kiss_deep.start"])
                self.assertIn(".h_kiss_deep.start." + tier + ".", blocks[0]["variant"])


if __name__ == "__main__":
    unittest.main()
