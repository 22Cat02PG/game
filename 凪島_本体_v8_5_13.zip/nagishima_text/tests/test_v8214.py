"""v8.2.14：真帆に動いてもらう、頭をなでる、撫で返し、いつもの時間の頭を撫でるの本文（ユーザー 2026-09-28 12:47〜13:21）。
公開の選択肢から確かめる（高まり・回数などの準備だけ内部で行う）。"""
import unittest

from tools.run_stage_b_routes import Route


def meanings(engine):
    return [b["meaning"] for b in engine.get_view()["blocks"]]


def choices(engine):
    return {c["id"]: c for c in engine.get_view()["choices"]}


class V8214(unittest.TestCase):
    def route(self, *args, **kwargs):
        route = Route(*args, **kwargs)
        self.addCleanup(route.close)
        return route

    def main(self, route):
        while route.engine.snapshot()["offer"]:
            route.choose("offer.decline")
        if route.engine.get_view()["page"] != "main":
            route.choose("menu.main")

    def intimate(self, route):
        return route.engine.snapshot()["intimacy"]

    def on_top(self, seed, tier="familiar"):
        route = self.route(seed, tier=tier, day_offset=2)
        route.begin()
        for key in ("h_strip_lower", "h_shift_under", "h_strip_self", "h_pos_maho_above"):
            route.action(key)
        route.engine._state["intimacy"]["maho"].update(arousal=60, band="mid")  # 準備：入れられるところまで
        route.engine._install_choices()
        route.action("h_insert")
        self.main(route)
        return route

    def lying(self, seed, tier="familiar"):
        route = self.route(seed, tier=tier, day_offset=2)
        route.begin()
        for key in ("h_strip_lower", "h_shift_under", "h_strip_self", "h_pos_lying_face"):
            route.action(key)
        return route

    def set_experience(self, route, key, count):
        now = route.engine.snapshot()["world"]["now"]
        route.engine._state["experience"][key] = {"count": count, "first_at": now - 2880, "last_at": now - 1440, "by_origin": {"player": count, "maho": 0}}
        route.engine._install_choices()

    # ---- 真帆に動いてもらう ----
    def test_maho_moves_and_pace(self):
        route = self.on_top(1201)
        route.action("h_maho_move")
        self.assertIn(meanings(route.engine)[0], ("h_maho_move.first", "h_maho_move.start"))
        self.main(route)
        found = choices(route.engine)
        self.assertEqual(found["touch.h_maho_move"]["label"], "真帆に動き続けてもらう")
        self.assertEqual(found["pace.h_maho_move.fast"]["label"], "もっと激しく動いてもらう")
        intimate = route.engine._state["intimacy"]
        intimate["maho"].update(arousal=82, band="high")  # 準備：v8.2.26 から、真帆が自分で動く「激しく」も高まり「高い」から（test_v8226）
        route.engine._install_choices()
        route.choose("pace.h_maho_move.fast")
        self.assertEqual(meanings(route.engine)[0], "h_maho_move.pace_fast")
        route.action("h_move_normal")  # こちらが動くと、真帆の動きは終わる
        contacts = [c["action_id"] for c in route.engine.snapshot()["contacts"]]
        self.assertIn("h_move_normal", contacts)
        self.assertNotIn("h_maho_move", contacts)

    def test_finish_and_endure_while_maho_moves(self):
        route = self.on_top(1211)
        route.action("h_maho_move")
        route.engine._state["intimacy"]["player"]["arousal"] = 80  # 準備：出せるところまで
        route.engine._install_choices()
        self.main(route)
        found = choices(route.engine)
        self.assertTrue(found["touch.h_finish_inside"]["available"])  # 資源がぶつからない（読み手の指摘 M-1）
        route.engine._state["intimacy"]["player"]["arousal"] = 100  # 準備：限界
        route.engine._install_choices()
        self.main(route)
        found = choices(route.engine)
        self.assertEqual(found["touch.h_maho_move"]["label"], "真帆に動き続けてもらう（もうこらえきれない）")
        self.assertTrue(found["touch.h_endure"]["available"])
        route.choose("touch.h_endure")
        self.assertEqual(meanings(route.engine)[0], "h_endure.maho_move")
        other = self.on_top(1212)
        other.action("h_maho_move")
        other.engine._state["intimacy"]["player"]["arousal"] = 100
        other.engine._install_choices()
        self.main(other)
        other.choose("touch.h_maho_move")
        self.assertEqual(meanings(other.engine)[0], "h_overflow.maho_move")
        self.assertEqual(self.intimate(other)["mess"], "inside")

    # ---- 頭をなでる ----
    def test_stroke_during_mouth_heats_up_and_keeps_service(self):
        route = self.lying(1221)
        self.set_experience(route, "h_maho_mouth", 3)
        route.action("h_maho_mouth")
        self.main(route)
        route.choose("touch.h_stroke_head")
        self.assertEqual(meanings(route.engine)[0], "h_stroke_head.mouth")
        state = self.intimate(route)
        self.assertEqual(state["paces"], {"h_maho_mouth": "fast"})  # 熱が入る
        self.assertIn("h_maho_mouth", [c["action_id"] for c in route.engine.snapshot()["contacts"]])  # 口は続く
        self.main(route)
        route.choose("touch.h_stroke_head")
        self.main(route)
        route.choose("touch.h_stroke_head")
        self.assertEqual(meanings(route.engine)[0], "h_stroke_head.again")  # 3回目は短い反応

    def test_stroke_in_afterglow_keeps_afterglow(self):
        route = self.lying(1231)
        route.engine._state["intimacy"]["maho"].update(climaxes=1, climax_source="finger", arousal=40, band="mid")
        route.engine._state["intimacy"]["after"] = True  # 準備：真帆が達したあとの余韻
        route.engine._install_choices()
        self.main(route)
        route.choose("touch.h_stroke_head")
        self.assertEqual(meanings(route.engine)[0], "h_stroke_head.after")
        self.assertTrue(self.intimate(route)["after"])
        self.main(route)
        self.assertTrue(choices(route.engine)["touch.h_after_hold"]["available"])

    def test_stroke_on_top_depends_on_maho_moving(self):
        still = self.on_top(1241)
        still.choose("touch.h_stroke_head")
        self.assertEqual(meanings(still.engine)[0], "h_stroke_head.player_top")  # 真帆が動いていなければ、甘える本文
        moving = self.on_top(1242)
        moving.action("h_maho_move")
        moving.engine._state["intimacy"]["maho"].update(arousal=85, band="high")  # 準備：「激しく」を止めない高まり（v8.2.29 で入れる・動くの高まりを下げた）
        moving.engine._install_choices()
        self.main(moving)
        moving.choose("touch.h_stroke_head")
        self.assertEqual(meanings(moving.engine)[0], "h_stroke_head.maho_top")
        self.assertEqual(self.intimate(moving)["paces"], {"h_maho_move": "fast"})
        # v8.2.29（確かめ役 F-12）：まだ「激しく」を止める高まりなら、速さは上げず、腰が激しくなる本文も出さない（撫でられて和らぐ本文）
        calm = self.on_top(1243)
        calm.action("h_maho_move")
        calm.engine._state["intimacy"]["maho"].update(arousal=60, band="mid")
        calm.engine._install_choices()
        self.main(calm)
        calm.choose("touch.h_stroke_head")
        self.assertEqual(meanings(calm.engine)[0], "h_stroke_head.again")
        self.assertEqual(self.intimate(calm)["paces"], {})

    def test_stroke_never_makes_her_climax_and_needs_reach(self):
        route = self.lying(1251)
        route.engine._state["intimacy"]["maho"].update(arousal=99, band="near")
        route.engine._install_choices()
        self.main(route)
        route.choose("touch.h_stroke_head")
        self.assertEqual(self.intimate(route)["maho"]["climaxes"], 0)
        behind = self.route(1252, tier="familiar", day_offset=2)
        behind.begin()
        for key in ("h_strip_lower", "h_shift_under", "h_strip_self", "h_pos_from_behind"):
            behind.action(key)
        self.main(behind)
        behind.choose("menu.h_touch")
        view = behind.engine.get_view()
        self.assertFalse(choices(behind.engine)["touch.h_stroke_head"]["available"])
        self.assertEqual(view["explanations"]["touch.h_stroke_head"], "今の姿勢では、真帆の頭に手が届かない。")

    # ---- 撫で返し ----
    def test_stroke_back_after_hold_once(self):
        seen = 0
        for seed in range(1261, 1281):
            route = self.lying(seed)
            route.engine._state["intimacy"]["maho"].update(climaxes=1, climax_source="finger", arousal=40, band="mid")
            route.engine._state["intimacy"]["after"] = True
            route.engine._install_choices()
            self.main(route)
            route.choose("touch.h_after_hold")
            found = meanings(route.engine)
            if "h.stroke_back.after" in found:
                seen += 1
                self.assertTrue(self.intimate(route)["stroked_back"])
        self.assertTrue(0 < seen < 20)  # 慣れの回は半分ほど

    def test_no_stroke_back_when_she_was_between_legs(self):
        for seed in range(1281, 1291):
            route = self.lying(seed)
            self.set_experience(route, "h_maho_mouth", 3)
            route.action("h_maho_mouth")
            route.engine._state["intimacy"]["player"]["arousal"] = 100  # 準備：限界
            route.engine._install_choices()
            self.main(route)
            route.choose("end.h_maho_mouth")  # 口を離してもらう（こらえる）
            self.assertNotIn("h.stroke_back.endure", meanings(route.engine))

    # ---- いつもの時間の頭を撫でる ----
    def test_daily_head_texts_after_intimacy(self):
        route = self.route(1301, tier="familiar", day_offset=2)
        pack = route.engine.pack
        values = pack.registry.values(route.engine.snapshot())
        self.assertGreaterEqual(values["intimacy.history_count"], 1)
        from nagishima.conditions import evaluate
        new = [t["id"] for t in pack.by_meaning["head.start"] if t["id"].startswith("o30.") and evaluate(t["when"], values) is True]
        self.assertTrue(new)


if __name__ == "__main__":
    unittest.main()
