"""段階C（010、v8.5.6）：添い寝。仕様 docs/凪島_段階C_仕様_2026-10-08.md の第6.1節。決まりは intimacy.json の co_sleep 節。
- 夜（from から真帆の就寝まで）、恋人で真帆が起きているとき「一緒に寝ようと誘う」。反応の表（上から、最後はいつも当たる）で、受け入れる・断る（理由つき）。暮らしの日に1回。
- 受け入れたら、二人で真帆の部屋へ移り、並んで横になる（state の co_sleep：phase talk）。話す・目を閉じる。受け入れてから asleep_after 分で真帆が眠る（phase asleep）。
- 真帆が眠ったあと：このまま眠る（同じベッドで翌朝。朝の一言 cs.morning）・寝顔を見る（一文）・眠っている真帆に触れる（寝込み。種類 cosleep、目覚めの倍率は sleep_play の kinds.cosleep）。
- 寝込みで真帆が目を覚ましたら、反応の表の行の cosleep（stay：そのまま並んで眠る／leave：自分の部屋へ戻る。書かなければ leave）。受け入れる反応なら起きているエッチへ（添い寝は終える）。"""
from .conditions import evaluate
from .errors import GameError, ensure
from .intimacy_rules import check, number, time
from .progression import day_time, life_day

PHASES = ("talk", "asleep")
ALWAYS = {"all": []}
LABELS = ("invite", "talk", "close_eyes", "sleep", "look", "touch")


class CoSleepRules:
    def __init__(self, raw):
        check(raw, ["_note", "from", "min_stage", "places", "when", "order", "accept", "minutes", "labels"])
        self.start = time(raw["from"])
        self.min_stage = number(raw["min_stage"], 0, 4)
        ensure(type(raw["places"]) is list and raw["places"] and all(type(v) is str for v in raw["places"]), "intimacy_data", "添い寝の誘える場所が不正。")
        self.places = raw["places"]
        ensure(type(raw["when"]) is dict, "intimacy_data", "添い寝の条件が不正。")
        self.when = raw["when"]
        ensure(type(raw["order"]) is list and raw["order"] and all(type(r) is dict and set(r) == {"id", "when"} and type(r["id"]) is str for r in raw["order"]),
               "intimacy_data", "添い寝の反応の表が不正。")
        ensure(raw["order"][-1]["when"] == ALWAYS, "intimacy_data", "添い寝の反応の表の最後は、いつも当たる行にする。")
        self.order = raw["order"]
        self.reactions = list(dict.fromkeys(r["id"] for r in self.order))
        ensure(type(raw["accept"]) is list and raw["accept"] and set(raw["accept"]) <= set(self.reactions), "intimacy_data", "添い寝を受け入れる反応が未登録。")
        self.accept = frozenset(raw["accept"])
        ensure(set(self.reactions) - self.accept, "intimacy_data", "添い寝を断る反応がない。")
        check(raw["minutes"], ["invite", "talk", "asleep_after", "look"])
        self.minutes = {k: number(v, 1, 60) for k, v in raw["minutes"].items()}
        check(raw["labels"], list(LABELS))
        ensure(all(type(v) is str and 1 <= len(v) <= 40 for v in raw["labels"].values()), "intimacy_data", "添い寝の選択肢の名前が不正。")
        self.labels = raw["labels"]

    def meanings(self):
        return (["cs.accept." + r for r in self.reactions if r in self.accept] + ["cs.decline." + r for r in self.reactions if r not in self.accept]
                + ["cs.talk", "cs.asleep", "cs.look", "cs.morning"])

    def check_content(self, fields, meanings, validate_condition):
        for when in [self.when] + [r["when"] for r in self.order] + [{"field": "actor.player.location", "op": "in", "value": self.places}]:
            validate_condition(when, fields)
        missing = [m for m in self.meanings() if m not in meanings]
        ensure(not missing, "meaning", "添い寝の本文の意味が未登録：" + "、".join(missing[:5]))


def invite_blocked(state, pack):
    """一緒に寝ようと誘えない理由（code, 文）。誘えるなら None。メニューと操作で同じ判定を使う。"""
    rules = pack.intimacy.co_sleep
    player, maho = state["actors"]["player"], state["actors"]["maho"]
    if state["mode"] != "normal" or state.get("co_sleep") or state.get("sleep_play") or state.get("event_play") or state["maho_sleep"]["state"] != "awake":
        return "co_sleep", "今は誘えない。"
    if player["location"] not in rules.places or maho["location"] != player["location"]:
        return "location", "家の中で、真帆と一緒のときに誘う。"
    if state["relation"]["stage"] < rules.min_stage:
        return "relationship", "まだ、そこまで誘える間柄ではない。"
    if day_time(state["world"]["now"]) < rules.start:
        return "event_time", "もう少し夜が更けてから誘う。"
    if any(x["group"] == "event_cosleep" and x["day"] == life_day(state["world"]["now"]) for x in state["cooldowns"]):
        return "event_time", "今日はもう誘った。"
    if evaluate(rules.when, pack.registry.values(state)) is not True:
        return "co_sleep", "今は誘えない。"
    return None


class CoSleep:
    @property
    def csr(self):
        rules = self.pack.intimacy.co_sleep if self.pack.intimacy else None
        ensure(rules is not None, "co_sleep", "この原稿版に添い寝は登録されていない。")
        return rules

    def cosleep_invite(self):
        rules = self.csr
        self.free()
        self.require_awake()
        blocked = invite_blocked(self.s, self.pack)
        if blocked:
            raise GameError(*blocked)
        self.record_offer("event_cosleep")
        reaction = next(r["id"] for r in rules.order if evaluate(r["when"], self.pack.registry.values(self.s)) is True)
        minutes = min(rules.minutes["invite"], max(0, self.s["world"]["awake_deadline"] - self.now))
        if reaction not in rules.accept:
            self.emit("cs.decline." + reaction)
            if minutes:
                self.advance(minutes)
            return
        self.s["contacts"] = []
        for actor in self.s["actors"].values():
            actor["location"], actor["posture"] = "maho_room", "reclined"
        self.s["distance"] = "near"
        self.s["interaction_streak"] = None
        self.s["co_sleep"] = {"day": life_day(self.now), "phase": "talk", "since": self.now}
        self.emit("cs.accept." + reaction)
        if minutes:
            self.advance(minutes)
        self._cosleep_check_asleep()

    def _cosleep(self, phase):
        cs = self.s.get("co_sleep")
        ensure(cs and cs["phase"] == phase, "co_sleep", "今は選べない。")
        return cs

    def _cosleep_check_asleep(self, force=False):
        """受け入れてから asleep_after 分たったら（目を閉じたらすぐ）、真帆が眠る。"""
        cs = self.s["co_sleep"]
        if cs["phase"] == "talk" and (force or self.now >= cs["since"] + self.csr.minutes["asleep_after"]):
            cs["phase"] = "asleep"
            self.s["maho_sleep"].update(state="asleep", since=self.now)
            self.emit("cs.asleep")

    def cosleep_talk(self):
        self._cosleep("talk")
        self.emit("cs.talk")
        minutes = min(self.csr.minutes["talk"], max(0, self.s["world"]["awake_deadline"] - self.now))
        if minutes:
            self.advance(minutes)
        self._cosleep_check_asleep()

    def cosleep_close_eyes(self):
        """目を閉じる：真帆が眠るまで待つ。"""
        cs = self._cosleep("talk")
        minutes = min(max(0, cs["since"] + self.csr.minutes["asleep_after"] - self.now), max(0, self.s["world"]["awake_deadline"] - self.now))
        if minutes:
            self.advance(minutes)
        self._cosleep_check_asleep(force=True)

    def cosleep_look(self):
        self._cosleep("asleep")
        self.emit("cs.look")
        minutes = min(self.csr.minutes["look"], max(0, self.s["world"]["awake_deadline"] - self.now))
        if minutes:
            self.advance(minutes)

    def cosleep_end(self, leave):
        """添い寝を終える（寝込みで目を覚ました真帆の反応・起きているエッチへ移るとき）。leave なら主人公は自分の部屋へ。"""
        if not self.s.get("co_sleep"):
            return
        self.s["co_sleep"] = None
        if leave:
            player = self.s["actors"]["player"]
            player["location"], player["posture"] = "player_room", "standing"
            self.s["distance"] = "normal"
