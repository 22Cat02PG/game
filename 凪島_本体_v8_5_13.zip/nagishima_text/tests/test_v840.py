"""v8.4.0（ユーザー 2026-10-06）：010 だけ。エッチ中の触れ合いを足し、手をつなぐを左右で選べるようにした。
- エッチ中（頁「寄り添う」。v8.4.1 で「手と体」）：手をつなぐ（真帆の右手・左手。向かい合えば右手、後ろからなら左手が既定）、両手をつなぐ、抱きしめる（後ろからの体位では「後ろから抱きしめる」。v8.4.1 から四つん這い・立って後ろからは「覆いかぶさって抱きしめる」）、
  背中を撫でる、頬に触れる、額を寄せる、頬に口づける。何度か・慣れたでは、手をつなぐと指を絡める本文。
- 暮らし：手をつなぐ（右手が既定・左手も選べる）、両手をつなぐ。関係の段階 3 から、手をつなぐと指を絡める本文。「指を絡める」の選択肢はしまった。"""
import json
import re
import unittest
from pathlib import Path

from nagishima.conditions import evaluate
from nagishima.content import Pack
from tools.run_stage_b_routes import Route

ROOT = Path(__file__).resolve().parents[1]
P009 = Pack(ROOT / "content/releases/interaction_009")
P010 = Pack(ROOT / "content/releases/interaction_010")
NEW = ("h_hands", "h_hands_both", "h_hug", "h_back", "h_cheek", "h_forehead", "h_cheek_kiss")
LABELS = {"h_hands_both": "両手をつなぐ", "h_hug": "抱きしめる", "h_back": "背中を撫でる", "h_cheek": "頬に触れる", "h_forehead": "額を寄せる", "h_cheek_kiss": "頬に口づける"}
DIALOGUE = re.compile(r"「[^」]*」")


def choices(route):
    return {c["id"]: c for c in route.engine.get_view()["choices"]}


def meanings(route):
    return [b["meaning"] for b in route.engine.get_view()["blocks"]]


def contacts(route):
    return {c["action_id"] for c in route.engine.snapshot()["contacts"]}


def act(route, key):
    while route.engine.snapshot()["offer"]:
        route.choose("offer.decline")
    route.action(key)


def close_page(route):
    while route.engine.snapshot()["offer"]:
        route.choose("offer.decline")
    if route.engine.get_view()["page"] != "h_close":
        if route.engine.get_view()["page"] != "main":
            route.choose("menu.main")
        route.choose("menu.h_close")
    return choices(route)


class V840(unittest.TestCase):
    def route(self, seed, tier, **kwargs):
        route = Route(seed, tier=tier, release="interaction_010", **{"hour": 21, "day_offset": 2, **kwargs})
        self.addCleanup(route.close)
        return route

    def warmed(self, seed, tier, arousal=50):
        route = self.route(seed, tier)
        route.begin()
        for _ in range(12):
            if route.engine.snapshot()["intimacy"]["maho"]["arousal"] >= arousal:
                break
            act(route, "h_kiss_deep")
        return route

    def test_009_unchanged(self):
        for key in NEW:
            self.assertNotIn(key, P009.intimacy.actions)
        self.assertFalse(P009.intimacy.daily_hidden)
        self.assertFalse(P009.intimacy.daily_extra)
        self.assertIn("finger_lace", P009.actions)

    def test_new_actions_and_texts(self):
        rules = P010.intimacy
        for key in NEW:
            self.assertIn(key, rules.actions)
            self.assertEqual(rules.action_pages[key], "h_close")
            for phase in ("start",) + (("continue", "continue_short") if rules.actions[key].get("ongoing") else ()):
                authored = [t for t in P010.by_meaning.get(f"{key}.{phase}", []) if not t["fallback"]]
                self.assertGreaterEqual(len(authored), 3, (key, phase))
        self.assertEqual(rules.side_defaults["h_hands"], {"face": "right", "back": "left", "maho_mouth": "right", "player_mouth": "right"})

    def test_texts_have_quiet_variant_and_no_finger_lace_before_few(self):
        """深い口づけのあいだは台詞のない本文に絞る。足した本文の組ごとに、台詞のない本文が1つはある。
        初めて（first）の手をつなぐ本文は指を絡めない（絡めるのは何度か・慣れたから）。"""
        groups = {}
        for text in P010.by_text.values():
            if text["meaning"].split(".")[0] in NEW and not text["fallback"]:
                # 短い1行（sh.<意味>.<形>）は形ごとの組なので、同じ条件の行をまとめて見る
                # （口でしてもらっている最中は台詞を出さない条件 facing ne maho_mouth は、台詞の行だけにつく）
                when = [c for c in text["when"].get("all", [text["when"]]) if c.get("op") != "ne"]
                key = (text["meaning"], json.dumps(when, sort_keys=True)) if text["group"].startswith("sh.") else text["group"]
                groups.setdefault(key, []).append(text)
        self.assertGreater(len(groups), 40)
        for group, rows in groups.items():
            self.assertTrue(any(not DIALOGUE.search(t["body"]) for t in rows), group)
        for text in P010.by_text.values():
            if text["id"].startswith("v840.h_hands.") and ".first." in text["id"]:
                self.assertNotIn("絡", text["body"], text["id"])

    def test_face_texts_not_during_deep_kiss(self):
        """真帆の顔が別のところにある書き方（首すじに鼻先・胸に額・耳もとの吐息・手首に唇）は、深く口づけている・胸に口づけているあいだは出ない。"""
        rows = [t for t in P010.by_text.values() if t["id"].startswith("v840.") and re.search("首すじに鼻先|胸に額|吐息が耳もと|手首に唇|吐息が、首すじ", t["body"])]
        self.assertEqual(len(rows), 5)
        for text in rows:
            when = json.dumps(text["when"])
            self.assertIn("contact.h_kiss_deep.active", when, text["id"])
            self.assertIn("contact.h_chest_mouth.active", when, text["id"])

    def test_close_page_labels_and_hands_side(self):
        route = self.warmed(8401, "few")
        page = close_page(route)
        self.assertEqual(page["touch.h_hands"]["label"], "手をつなぐ（真帆の右手）")
        self.assertEqual(page["side.h_hands.left"]["label"], "手をつなぐ（真帆の左手）")
        for key, label in LABELS.items():
            self.assertEqual(page["touch." + key]["label"], label)
            self.assertTrue(page["touch." + key]["available"], key)
        act(route, "h_hands")
        self.assertEqual(route.engine.snapshot()["intimacy"]["sides"]["h_hands"], "right")
        page = close_page(route)
        self.assertEqual((page["touch.h_hands"]["label"], page["side.h_hands.left"]["label"], page["end.h_hands"]["label"]),
                         ("手をつないだままでいる", "真帆の左手に持ち替える", "手を離す"))
        route.choose("side.h_hands.left")
        self.assertIn("h_hands.side_left", meanings(route))
        self.assertEqual(route.engine.snapshot()["intimacy"]["sides"]["h_hands"], "left")
        page = choices(route)
        self.assertEqual((page["touch.h_hands"]["label"], page["side.h_hands.left"]["label"]), ("真帆の右手に持ち替える", "手をつないだままでいる"))
        route.choose("touch.h_hands")
        self.assertIn("h_hands.side_right", meanings(route))
        route.choose("touch.h_hands")
        self.assertTrue({"h_hands.continue", "h_hands.continue_short"} & set(meanings(route)), meanings(route))

    def test_back_position_defaults_and_reach(self):
        route = self.warmed(8402, "familiar")
        for key in ("h_lift_upper", "h_strip_lower", "h_shift_under", "h_strip_self", "h_pos_from_behind"):
            act(route, key)
        page = close_page(route)
        self.assertEqual(page["touch.h_hands"]["label"], "手をつなぐ（真帆の左手）")
        self.assertEqual(page["side.h_hands.right"]["label"], "手をつなぐ（真帆の右手）")
        self.assertEqual(page["touch.h_hug"]["label"], "覆いかぶさって抱きしめる")  # v8.4.1：四つん這いでは、引き寄せて抱きしめると二通り
        for key in ("h_forehead", "h_hands_both", "h_cheek", "h_cheek_kiss"):  # 四つん這いの後ろからは、顔・両手に届かない
            self.assertFalse(page["touch." + key]["available"], key)
        for key in ("h_hands", "h_hug", "h_back"):
            self.assertTrue(page["touch." + key]["available"], key)
        act(route, "h_hands")
        self.assertEqual(route.engine.snapshot()["intimacy"]["sides"]["h_hands"], "left")

    def test_hands_and_cheek_keep_her_mouth(self):
        route = self.warmed(8403, "few")
        for key in ("h_lift_upper", "h_strip_lower", "h_shift_under", "h_strip_self", "h_pos_lying_face", "h_maho_mouth"):
            act(route, key)
        self.assertIn("h_maho_mouth", contacts(route))
        act(route, "h_hands")
        self.assertTrue({"h_maho_mouth", "h_hands"} <= contacts(route), contacts(route))
        act(route, "h_cheek")
        self.assertIn("h_maho_mouth", contacts(route))
        page = close_page(route)
        for key in ("h_hug", "h_forehead", "h_cheek_kiss", "h_hands_both", "h_back"):
            self.assertFalse(page["touch." + key]["available"], key)

    def test_facing_change_ends_touches_out_of_reach(self):
        """口でしてもらい始めたら、抱きしめる・背中を撫でるは終える（手をつなぐは続く）。顔にまたがってもらえば、手をつなぐも終える。"""
        route = self.warmed(8404, "few")
        for key in ("h_lift_upper", "h_strip_lower", "h_shift_under", "h_strip_self", "h_pos_lying_face", "h_hands", "h_back"):
            act(route, key)
        self.assertTrue({"h_hands", "h_back"} <= contacts(route), contacts(route))
        act(route, "h_maho_mouth")
        self.assertIn("h_hands", contacts(route))
        self.assertNotIn("h_back", contacts(route))
        route = self.warmed(8405, "familiar")
        for key in ("h_lift_upper", "h_strip_lower", "h_shift_under", "h_strip_self", "h_pos_lying_face", "h_hug"):
            act(route, key)
        self.assertIn("h_hug", contacts(route))
        act(route, "h_maho_mouth")
        self.assertNotIn("h_hug", contacts(route))

    def test_her_hand_service_and_holding_hands_exclude_each_other(self):
        route = self.warmed(8406, "few")
        for key in ("h_lift_upper", "h_strip_lower", "h_shift_under", "h_strip_self", "h_hands", "h_maho_hand"):
            act(route, key)
        self.assertIn("h_maho_hand", contacts(route))
        self.assertNotIn("h_hands", contacts(route))
        act(route, "h_hands")
        self.assertIn("h_hands", contacts(route))
        self.assertNotIn("h_maho_hand", contacts(route))

    def test_touch_page_stays_within_limit_while_face_sitting(self):
        """顔にまたがって舐めてもらっている最中の「触れる」の頁（v8.4.0 の通しプレイで選択肢が 33 になった）。体位の近道は上限 32 に収まる分だけ。"""
        route = self.warmed(9234, "familiar", arousal=60)
        for key in ("h_lift_upper", "h_strip_lower", "h_shift_under", "h_strip_self", "h_pos_face_sit", "h_face_lick"):
            act(route, key)
        route.choose("menu.main")
        route.choose("menu.h_touch")
        self.assertLessEqual(len(route.engine.get_view()["choices"]), 32)
        self.assertIn("menu.h_close", choices(route))

    def test_daily_hands_sides_and_both(self):
        route = Route(4, hour=20, day_offset=2, release="interaction_010")
        self.addCleanup(route.close)
        route.choose("near")
        route.choose("menu.touch")
        page = choices(route)
        self.assertNotIn("touch.finger_lace", page)
        self.assertEqual((page["touch.hands"]["label"], page["side.hands.left"]["label"], page["touch.hands_both"]["label"]),
                         ("手をつなぐ（真帆の右手）", "手をつなぐ（真帆の左手）", "両手をつなぐ"))
        ids = [c["id"] for c in route.engine.get_view()["choices"]]
        self.assertEqual(ids.index("touch.hands_both"), ids.index("side.hands.left") + 1)
        route.choose("touch.hands")
        side = [c.get("side") for c in route.engine.snapshot()["contacts"] if c["action_id"] == "hands"]
        self.assertEqual(side, ["right"])
        page = choices(route)
        self.assertEqual((page["touch.hands"]["label"], page["side.hands.left"]["label"]), ("手をつないだままでいる", "真帆の左手に持ち替える"))
        route.choose("side.hands.left")
        self.assertIn("hands.side_left", meanings(route))
        self.assertEqual([c.get("side") for c in route.engine.snapshot()["contacts"] if c["action_id"] == "hands"], ["left"])
        self.assertFalse([b for b in route.engine.get_view()["blocks"] if route.engine.pack.by_text[b["variant"]]["fallback"]])
        route.choose("touch.hands_both")
        self.assertIn("hands_both", contacts(route))
        self.assertNotIn("hands", contacts(route))

    def test_daily_finger_lace_texts_from_stage_3(self):
        route = Route(4, hour=20, day_offset=2, release="interaction_010")
        self.addCleanup(route.close)
        engine, pack = route.engine, route.engine.pack
        for stage, laced in ((2, False), (3, True)):
            engine._state["relation"]["stage"] = stage
            values = pack.registry.values(engine.snapshot())
            for meaning in ("hands.start", "hands.continue"):
                rows = [t for t in pack.by_meaning[meaning] if evaluate(t["when"], values) is True and not t["fallback"]]
                self.assertGreaterEqual(len(rows), 3, (stage, meaning))
                if laced:
                    self.assertTrue(all("絡" in t["body"] for t in rows), (stage, meaning, [t["body"][:20] for t in rows]))
                elif meaning == "hands.start":
                    self.assertFalse([t["id"] for t in rows if "絡め" in t["body"]], stage)

    def test_directed_sweep_has_no_placeholder(self):
        """体位ごとに、足した触れ合いを選べるだけ選ぶ（入れる前と入れたあと）。仮の本文が出ない。"""
        seen, placeholders = set(), []
        for n, position in enumerate(("lying_face", "maho_above", "from_behind", "side_lying", "prone_back", "standing_back")):
            route = self.warmed(8410 + n, "familiar")
            for key in ("h_lift_upper", "h_strip_lower", "h_shift_under", "h_strip_self", "h_pos_" + position):
                act(route, key)
            for phase in ("out", "in"):
                if phase == "in":
                    for _ in range(6):
                        if route.engine.snapshot()["intimacy"]["maho"]["arousal"] >= 70:
                            break
                        act(route, "h_chest_skin")
                    act(route, "h_insert")
                for key in NEW + ("h_hands",):
                    if not close_page(route)["touch." + key]["available"]:
                        continue
                    route.choose("touch." + key)
                    for block in route.engine.get_view()["blocks"]:
                        if block["meaning"].split(".")[0] in NEW:
                            seen.add(block["meaning"].split(".")[0])
                            if route.engine.pack.by_text[block["variant"]]["fallback"]:
                                placeholders.append((position, phase, block["meaning"]))
                    if phase == "in":
                        act(route, "h_move_slow")
        self.assertEqual(placeholders, [])
        self.assertEqual(seen, set(NEW))


if __name__ == "__main__":
    unittest.main()
