"""Public runtime. Every UI submits only displayed choice IDs, never effects."""
from copy import deepcopy
import re
from pathlib import Path
from secrets import token_hex

from .codec import digest, exact, identifier, clone_state
from .conditions import evaluate
from .content import Repository
from .context import Context
from .errors import ensure, GameError
from .menus import PAGES, build_choices
from .schema import validate as validate_schema
from .state import new_state, validate_state, SCHEMA
from .stage_b_state import add_neutral
from .life import work_clock
from .storage import Storage
from . import clock
from . import progression


class Engine:
    def __init__(self, data_dir="userdata", seed=20380407, name="悠", release="base", builtin=None, autosave=True, test_cheats=False, opening=False):
        ensure(type(test_cheats) is bool, "test_cheats", "test_cheatsは真偽値で指定する。")
        self.storage = Storage(data_dir)
        self.repository = Repository(builtin or Path(__file__).resolve().parents[1] / "content" / "releases", Path(data_dir) / "releases")
        self.active_release = release
        self.pack = self.repository.get(release)
        self._state = new_state(self.pack, seed, name)
        self._page, self._trace_refs = ("main", 0), {}
        self._session, self.autosave_enabled = token_hex(16), autosave
        # Permission and activation are separate.  The explicit cheat command
        # turns the process-local override on; normal play never sees it.
        self.test_cheats = test_cheats
        self._test_cheat_intimacy = False
        self._test_cheat_all = False
        self.warnings, self.diagnostics = [], {"candidates": []}
        context = Context(self._state, self.pack, self.repository, None, self._test_cheat_intimacy)
        if opening and "opening" in self.pack.scenes:
            context.begin_scene("opening")  # v8.5.11（010）：新しく始めたときの導入（島・真帆・家・島の場所・七日目の朝）
        else:
            context.emit("system.welcome")
        blocks = self._render(context)
        self._frame = self._make_frame(self._state, blocks, 0)
        self._install_choices()
        validate_state(self._state, self.pack, self.repository)

    def snapshot(self):
        return clone_state(self._state)

    def _owner(self, state):
        return (state["scene"] or state["offer"] or {}).get("id")

    def _make_frame(self, state, blocks, revision, pack=None):
        pack = pack or self.pack
        return {"id": f"frame.{revision}", "revision": revision, "blocks": deepcopy(blocks[-8:]), "choices": [], "question_owner": self._owner(state), "release": state["scene"]["release"] if state["scene"] else pack.id}

    def _render(self, context):
        blocks, counts = [], []
        for event in context.events:
            block, count = self.repository.get(event["release"]).select(event["meaning"], context.s, event["bindings"], event["values"])
            if "body" in event: block["body"] = event["body"]
            blocks.append(block)
            counts.append({"meaning": event["meaning"], "count": count})
        context.candidate_counts = counts
        return blocks

    def _bath_line(self, s):
        """009（v8.2.0）：状態表示の「風呂」の行。時間帯の前は入る時刻、湯上がりの間はその終わり、済んだら「済み」。"""
        rules = self.pack.life.bath if self.pack.life else None
        if not rules or "bath" not in s:
            return None
        from .progression import day_time, life_day
        from .life_rules import bath_after
        now, bath = s["world"]["now"], s["bath"]
        if bath_after(s, self.pack.life):
            return ("二人で入った。湯上がり（" if bath["together"] else "湯上がり（") + clock.format_time(bath["after_until"])[-5:] + "まで）"
        if day_time(now) < rules["invite_from"] or day_time(now) >= rules["until"]:
            return None
        if bath["day"] == life_day(now):
            return "済み"
        start = rules["from"] % 1440
        return f"{start // 60:02d}:{start % 60:02d}ごろ（手が空いたら入る）"

    def _install_choices(self):
        self._frame["choices"], self._plans, self._explanations = build_choices(self._state, self.pack, self.repository, self._page, self._frame, self._test_cheat_intimacy)
        validate_schema(self._frame, SCHEMA["$defs"]["frame"], SCHEMA, "frame")

    def get_view(self):
        s = self._state
        result = deepcopy(self._frame)
        title = PAGES.get(self._page[0], "")
        if self.pack.intimacy and s.get("event_play"):
            from .event_play import place_label
            title = place_label(s, self.pack, self.pack.intimacy.events.events[s["event_play"]["kind"]])  # 段階C（010、v8.5.1）：浴室など。v8.5.4：野外は「海岸の物陰」など
        elif self.pack.intimacy and s.get("co_sleep") and not s.get("sleep_play"):
            title = "真帆の部屋（添い寝）"  # 段階C（010、v8.5.6）
        elif self.pack.intimacy and s.get("ask_play"):
            title = self._ask_place(s)  # 段階C（010、v8.5.10）：してもらっている場所（職場・野外は隠れられる所）
        elif self.pack.intimacy and s.get("sleep_play"):
            pages = self.pack.intimacy.sleep_play.pages
            title = "眠っている真帆" + ("" if self._page[0] not in pages or self._page[0] == "main" else "（" + pages[self._page[0]] + "）")  # 段階C（010）
        elif self.pack.intimacy and self._page[0] == "main" and s["mode"] == "private":
            title = "エッチの時間" if s["intimacy"] else "二人の時間"  # 009（v8.2.7、精査 A-12）
        result.update(session=self._session, page=self._page[0], page_title=title, explanations=deepcopy(self._explanations), warnings=list(self.warnings))
        if self.pack.intimacy and self._page[0] == "records" and s["intimacy_history"]["count"] > 0 and not s["intimacy"]:
            result["record"] = self._intimacy_record(s)  # v8.2.12：二人の記録
        player_location = self.pack.catalog["locations"][s["actors"]["player"]["location"]]["label"]
        maho_location = self.pack.catalog["locations"][s["actors"]["maho"]["location"]]["label"]
        shown_time = clock.format_time(s["world"]["now"])
        if self.pack.intimacy:
            # 009：曜日も出す（v8.1.0、3回目の試運転の指摘3）
            shown_time = shown_time[:10] + "（" + "月火水木金土日"[clock.date_time(s["world"]["now"]).weekday()] + "）" + shown_time[10:]
        result["status"] = {"time": shown_time, "weather": clock.weather(s["world"]["seed"], s["world"]["now"] // 1440), "player_location": player_location, "maho_location": maho_location, "maho_posture": s["actors"]["maho"]["posture"], "distance": s["distance"], "presence": self._presence(s, player_location, maho_location), "mood": deepcopy(s["mood"]), "mood_label": self._mood_label(s["mood"]), "relationship": ["同じ家で暮らし始めた", "暮らしに慣れた", "触れ合える距離", "恋人", "これからも共に暮らす"][s["relation"]["stage"]], "private": s["mode"] == "private", "unread_messages": sum(m["read_at"] is None for m in s["inbox"]), "held_actions": self._held_actions(s), "maho_sleep": s["maho_sleep"]["state"]}
        if self.pack.progression and (self.pack.progression.display or self.test_cheats):
            result["status"]["affinity"], result["status"]["desire"] = s["affinity"]["value"], s["desire"]
            if self.pack.intimacy and self.pack.intimacy.lewd and s["intimacy_history"]["count"] > 0:
                result["status"]["lewdness"] = s["intimacy_history"]["lewdness"]  # v8.2.12：親密度と同じく、表示する設定かテストチートのとき
        if self.pack.intimacy:
            result["status"]["settings"] = deepcopy(s["settings"])
            work = work_clock(self.pack.life, s["world"]["now"])
            if work:
                result["status"]["work"] = work
            bath = self._bath_line(s)
            if bath:
                result["status"]["bath"] = bath
            if self.pack.life and self.pack.life.town:
                # v8.5.11：島の町の店にいるときは、閉まる時刻
                from .island import town_place, hhmm
                row = town_place(s, self.pack)
                if row is not None:
                    result["status"]["town"] = self.pack.catalog["locations"][s["actors"]["player"]["location"]]["label"] + "は" + hhmm(row["close"]) + "まで"
            if s["relation"]["stage"] >= 3:
                value = s["stamina"]["value"]
                maximum = self.pack.intimacy.raw["player"]["stamina_max"]
                result["status"]["stamina"] = "●" * value + "○" * (maximum - value)
            if s["intimacy"]:
                intimate, rules = s["intimacy"], self.pack.intimacy
                parts = [rules.raw["clothing"]["labels"][actor + "." + layer][s["actors"][actor]["clothing"][layer]] for actor in ("maho", "player") for layer in ("upper", "lower")]
                bars = min(5, (intimate["player"]["arousal"] + 19) // 20)
                status = {"position": self._pose_line(s), "clothing": "。".join(x for x in parts if x), "inserted": intimate["inserted"],
                          "stamina": result["status"]["stamina"], "player_arousal": "■" * bars + "□" * (5 - bars),
                          "maho_sign": rules.raw["maho"]["signs"][rules.band(intimate["maho"]["arousal"])],
                          "night": "翌日は仕事" if rules.night_kind(s["world"]["now"], self.pack.life) == "workday_eve" else "翌日は休み",
                          "deadline": clock.format_time(rules.deadline(s["world"]["now"], self.pack.life))}
                # v8.2.30（通し確かめ 2）：朝・昼休みは、仕事の始まりがこの回の区切り（夜の時刻を出していた）
                limit, work = Context(s, self.pack, self.repository, None, self._test_cheat_intimacy)._session_deadline()
                if work:
                    status["night"], status["deadline"] = "このあと仕事", clock.format_time(limit) + "（仕事）"
                elif intimate["entry"] == "wake" and rules.sleep_play:
                    status["deadline"] = clock.format_time(limit)  # 段階C（010）：寝込みから移った回は、移ってからの区切り
                if intimate["wrap_up"] is not None:
                    # v8.2.32（確かめ役 7）：切り上げの一言のあとは、始めたときの区切りを「過ぎた」と出す（今の時刻に動いて、区切りが延びていくように見えた）
                    started = dict(s, world=dict(s["world"], now=intimate["started_at"]))
                    limit, work = Context(started, self.pack, self.repository, None, self._test_cheat_intimacy)._session_deadline()
                    if work:
                        status["night"] = "このあと仕事"
                    status["deadline"] = clock.format_time(limit) + ("（仕事）" if work else "") + "を過ぎた"
                if s["settings"]["gauges"] == "shown":  # B2：テストチートの起動でも設定に従う（検査役G2 L-2）
                    status["maho_arousal"] = intimate["maho"]["arousal"]
                    status["maho_satisfaction"] = intimate["maho"]["satisfaction"]
                    # B2：真帆の高まり・満足も、主人公と同じ棒で出す（ユーザー決定。既定で表示）
                    for key in ("arousal", "satisfaction"):
                        filled = min(5, (intimate["maho"][key] + 19) // 20)
                        status["maho_" + key + "_bar"] = "■" * filled + "□" * (5 - filled)
                result["status"]["intimacy"] = status
            if s.get("sleep_play"):
                result["status"]["sleep"] = self._sleep_status(s)
            if s.get("co_sleep"):
                result["status"]["co_sleep"] = "真帆と並んで横になっている" if s["co_sleep"]["phase"] == "talk" else "真帆が隣で眠っている"  # v8.5.6：添い寝
            if s.get("event_play"):
                result["status"]["event"] = self._event_status(s)
                result["status"]["player_location"] = result["status"]["maho_location"] = result["status"]["event"]["place"]
            if s.get("ask_play"):
                play = s["ask_play"]  # 段階C（010、v8.5.10）：してもらっている様子とこちらの高まり
                bars = min(5, (play["arousal"] + 19) // 20)
                result["status"]["ask"] = {"place": self._ask_place(s), "kind": {"hand": "手でしてもらっている", "mouth": "口でしてもらっている"}[play["kind"]],
                                           "player_arousal": "■" * bars + "□" * (5 - bars)}
                result["status"]["player_location"] = result["status"]["maho_location"] = result["status"]["ask"]["place"]
        return result

    def _sleep_status(self, s):
        """段階C（010、v8.5.0）：寝込みの様子。夜の印の一言（データの flags の status）も出す。ゲージ表示が表示のときは、目覚め・不快・快感の棒も出す（仕様 2.2・第12節）。"""
        play, rules = s["sleep_play"], self.pack.intimacy.sleep_play
        kind = {"doze": "うたた寝", "asleep": "眠っている", "cosleep": "隣で眠っている"}[play["kind"]]  # v8.5.6：添い寝
        look = {"low": "寝息は深い", "mid": "眠りが浅くなっている", "high": "今にも目を覚ましそう"}[rules.band(play["gauges"]["wake"])]
        status = {"kind": kind, "look": look, "marks": "。".join(rules.flags[f]["status"] for f in play["flags"] if rules.flags[f]["status"])}
        if s["settings"]["gauges"] == "shown":
            for gauge in ("wake", "discomfort", "pleasure"):
                filled = min(5, (play["gauges"][gauge] + 19) // 20)
                status[gauge + "_bar"] = "■" * filled + "□" * (5 - filled)
        return status

    def _ask_place(self, s):
        location = s["actors"]["player"]["location"]
        spot = self.pack.intimacy.ask.spots.get(location)
        return self.pack.catalog["locations"][location]["label"] + ("（" + spot + "）" if spot else "")

    def _event_status(self, s):
        """段階C（010、v8.5.1）：イベントの様子（場所・体位・あと何分・真帆の様子・こちらの高まり。ゲージ表示が表示のときは真帆の高まりの棒も）。"""
        play, rules = s["event_play"], self.pack.intimacy
        define = rules.events.events[play["kind"]]
        from .event_play import place_label
        limit_at = play["h_at"] + define.h_limit if play["h"] and define.h_limit else play["started_at"] + define.limit
        left = max(0, limit_at - s["world"]["now"])  # v8.5.4：エッチへ移ってからは h_limit の残り
        status = {"place": place_label(s, self.pack, define), "minutes_left": left, "position": define.positions[play["position"]]["label"] if play["position"] else ""}
        if define.drunk:
            status["drunk"] = define.drunk["labels"][define.drunk_level(play["drunk"])]  # v8.5.3：真帆の酔いの段
        if define.exposure:
            status["exposure"] = define.exposure["labels"][define.exposure_level(play["exposure"])]  # v8.5.4：人目の様子（数値は出さない）
        if play["h"]:
            bars = min(5, (play["player"] + 19) // 20)
            status.update(maho_sign=rules.raw["maho"]["signs"][rules.band(play["maho"])], player_arousal="■" * bars + "□" * (5 - bars), inserted=play["inserted"])
            if s["settings"]["gauges"] == "shown":
                filled = min(5, (play["maho"] + 19) // 20)
                status["maho_arousal_bar"] = "■" * filled + "□" * (5 - filled)
        return status

    def _pose_line(self, state):
        """体位の一文。口での愛撫・胸や足でしてもらう最中は、その姿勢を言う（B2、v8.2.11）。"""
        rules = self.pack.intimacy
        facing = rules.facing(state)
        if facing == "player_mouth":
            return "横になった真帆の脚のあいだに、顔を寄せている。"
        if facing == "maho_mouth":
            return "真帆が、こちらの脚のあいだに身をかがめている。"
        if facing == "maho_breasts":
            return "真帆が、こちらの脚のあいだで胸を寄せている。"
        if facing == "maho_feet":
            return "真帆が向かいに座って、足をこちらへ伸ばしている。"
        return rules.positions[state["intimacy"]["position"]]["presence"]

    def _intimacy_record(self, state):
        """v8.2.12：二人の記録（ユーザーの提案 2026-09-28 10:11「エッチ履歴」）。state を変えず、乱数も使わない。"""
        rules, hist = self.pack.intimacy, state["intimacy_history"]
        rows = [(key, entry) for key, entry in state["experience"].items() if key in rules.actions and entry["count"] > 0]
        from .intimacy_rules import FINISH_ACTIONS
        acts = sorted(((entry["count"], key) for key, entry in rows  # 選んだ回数（続けるたびに数える）。抜く・こらえる・出すは除く（読み手の指摘 M-4）
                       if rules.actions[key]["category"] not in ("position", "undress", "words", "after", "maho_lead") and key not in FINISH_ACTIONS and key not in ("h_withdraw", "h_endure")),
                      key=lambda x: (-x[0], x[1]))
        positions = sorted(((entry["count"], key) for key, entry in rows if rules.actions[key]["category"] == "position"), key=lambda x: (-x[0], x[1]))
        recent = [m for m in state["memories"]["recent"] if m["kind"] == "intimacy"][-5:][::-1]  # 新しい順（読み手の指摘 M-9）
        band = rules.lewd_band(hist["lewdness"])
        present = state["actors"]["player"]["location"] == state["actors"]["maho"]["location"] and state["maho_sleep"]["state"] == "awake"
        values = self.pack.registry.values(state)
        lines = [t for t in self.pack.by_meaning.get("record.maho_line", []) if not t["fallback"] and evaluate(t["when"], values) is True] \
            or [t for t in self.pack.by_meaning.get("record.maho_line", []) if t["fallback"]]
        return {"count": hist["count"], "by_entry": dict(hist["by_entry"]),
                "first": clock.format_time(hist["first_at"])[:10], "last": clock.format_time(hist["last_at"])[:10],
                "last_result": hist["last_result"], "maho_climaxes": hist["maho_climaxes"], "finishes": hist["finishes"],
                "maho_led": sum(entry["by_origin"]["maho"] for _, entry in rows) + hist["by_entry"]["invite"],  # 真帆の誘いで始まった回と、真帆からした行動（読み手の指摘 M-5）
                "top_acts": [{"label": rules.actions[key]["label"], "count": n} for n, key in acts[:5]],
                "top_positions": [{"label": rules.actions[key]["label"], "count": n} for n, key in positions[:3]],
                "recent": [{"date": clock.format_time(m["at"])[:10], "time": clock.format_time(m["at"])[11:16], "result": m["choice_summary"].get("result")} for m in recent],
                "lewdness": hist["lewdness"], "lewd_band": band, "lewd_label": rules.lewd["labels"][band] if rules.lewd else None,
                # 真帆のひとことは、そばにいて起きているときだけ（読み手の指摘 S-2）
                "maho_line": lines[hist["count"] % len(lines)]["body"] if lines and present else None}

    def _held_actions(self, state):
        """続いている行動の名前。009 で追加（先端も舐める・玉も揉む）が効いていれば「口でしてもらう（玉も）」のように添える（v8.2.11、ユーザーの質問 2026-09-28 13:39）。
        v8.2.13：速さが ふつう でなければ「（激しく）」「（ゆっくり）」、口は「（舌で）」「（深く）」も添える（読み手の指摘 M-5）。"""
        intimate = state["intimacy"] if self.pack.intimacy and state.get("intimacy") else None
        extras = intimate["extras"] if intimate else []
        paces = intimate["paces"] if intimate else {}
        result = []
        for contact in state["contacts"]:
            key = contact["action_id"]
            label = self.pack.actions[key]["label"]
            marks = []
            if extras:
                from .intimacy import EXTRAS, EXTRA_NAME
                marks = [{"lick": "先端も", "balls": "玉も"}[EXTRA_NAME[extra]] for extra, bases in EXTRAS.items() if EXTRA_NAME[extra] in extras and key in bases]
            pace = paces.get(key, "normal")
            if pace != "normal":
                marks.append({"slow": "舌で", "fast": "深く"}[pace] if key == "h_maho_mouth" else {"slow": "ゆっくり", "fast": "激しく"}[pace])
            if marks:
                label += "（" + "・".join(marks) + "）"
            result.append(label)
        return result

    @staticmethod
    def _mood_label(mood):
        if mood["joy"] >= 2 and mood["shy"] >= 2:
            return "熱っぽく高揚している"
        if mood["ease"] >= 2 and mood["joy"] >= 1:
            return "安心して甘えている"
        if mood["interest"] >= 2:
            return "こちらに気持ちを向けている"
        if mood["joy"] >= 1:
            return "うれしそう"
        return "穏やか"

    def _presence(self, state, player_location, maho_location):
        """Describe Maho's immediately visible state without changing the world."""
        if self.pack.intimacy and state["intimacy"]:
            rules = self.pack.intimacy
            intimate = state["intimacy"]
            head = self._pose_line(state)
            labels = [rules.raw["clothing"]["labels"]["maho." + layer][state["actors"]["maho"]["clothing"][layer]] for layer in ("upper", "lower")]
            return head + "".join(word.rstrip("。") + "。" for word in labels if word)
        actor = state["actors"]["maho"]
        posture = {"standing": "立っている", "seated": "座っている", "reclined": "横になっている"}[actor["posture"]]
        outfit = {"work": "仕事着", "casual": "普段着", "room": "部屋着"}[actor["outfit"]]
        hair = {"short": "短い髪", "tied": "結んだ髪", "down": "下ろした髪"}[actor["hair"]]
        together = state["actors"]["player"]["location"] == actor["location"]
        if state["maho_sleep"]["state"] == "asleep":
            return "真帆は自分の部屋で眠っている。"
        if together and state["maho_sleep"]["state"] == "dozing":
            return f"真帆は同じ{player_location}で、うたた寝している。"
        if not together:
            return f"真帆は{maho_location}にいる。{outfit}で、{hair}のまま{posture}。"
        parts = [f"真帆は同じ{player_location}で、{outfit}に{hair}のまま{posture}。"]
        if state["distance"] == "near":
            parts.append("手を伸ばせば触れられる、すぐそばにいる。")
        contact_words = {
            "hands": "二人は手をつないだまま。", "hug": "二人は抱き合ったまま。",
            "head": "真帆の髪に手を添えたまま。", "hold_mug": "真帆はカップを手にしている。",
            "hair": "真帆の髪に指を通したまま。", "back": "真帆の背中に手を添えたまま。",
            "waist": "真帆の腰を抱いたまま。",
        }
        for contact in state["contacts"]:
            wording = contact_words.get(contact["action_id"])
            if wording:
                parts.append(wording)
        mood = state["mood"]
        if mood["joy"] >= 2 and mood["shy"] >= 2:
            parts.append("真帆の頬は熱を帯び、離れがたそうに視線が何度もこちらへ戻ってくる。")
        elif mood["shy"] >= 2:
            parts.append("真帆は少し照れている。")
        elif mood["ease"] >= 2:
            parts.append("真帆の表情から、すっかり力が抜けている。")
        elif mood["joy"] >= 2:
            parts.append("真帆の表情は明るい。")
        elif mood["interest"] >= 2:
            parts.append("真帆はこちらの話に気持ちを向けている。")
        return "".join(parts)

    def choose(self, choice_id, revision, session):
        ensure(type(revision) is int and revision == self._frame["revision"] and session == self._session, "stale_choice", "表示が更新されている。今の画面から選び直す。")
        ensure(type(choice_id) is str and choice_id in self._plans, "choice", "現在表示している操作から選ぶ。")
        selected = next(c for c in self._frame["choices"] if c["id"] == choice_id)
        ensure(selected["available"], selected["reason"] or "unavailable", self._explanations.get(choice_id, "今は選べない。"))
        plan = self._plans[choice_id]
        if plan["op"] == "menu":
            page = (plan["page"], plan["offset"])
            frame = self._make_frame(self._state, self._frame["blocks"], revision + 1)
            frame["choices"], plans, explanations = build_choices(self._state, self.pack, self.repository, page, frame, self._test_cheat_intimacy)
            validate_schema(frame, SCHEMA["$defs"]["frame"], SCHEMA, "frame")
            self._page, self._frame, self._plans, self._explanations = page, frame, plans, explanations
            return self.get_view()
        work = clone_state(self._state)
        work["world"]["operation_seq"] += 1
        context = Context(work, self.pack, self.repository, self._frame, self._test_cheat_intimacy)
        context.apply(plan)
        context.finalize()
        context.boundary()
        validate_state(work, self.pack, self.repository, self._test_cheat_intimacy)
        blocks = self._render(context)
        # Keep the original question verbatim after a brief touch or a reply.
        same_question = work["scene"] and self._state["scene"] and work["scene"]["id"] == self._state["scene"]["id"] and work["scene"]["visit"] == self._state["scene"]["visit"]
        if context.restore_frame:
            display = context.restore_frame["blocks"]
        elif same_question:
            display = blocks + self._frame["blocks"][-1:]
        else:
            display = blocks or self._frame["blocks"]
        intimacy_changed = self.pack.intimacy and (bool(work["intimacy"]) != bool(self._state["intimacy"])
                                                   or bool(work.get("sleep_play")) != bool(self._state.get("sleep_play"))  # 段階C（010）：寝込みの始まり・終わりも最初の画面へ
                                                   or bool(work.get("event_play")) != bool(self._state.get("event_play")))
        # 009：自動の仕事・食事・眠り、場所や二人の時間の切り替えのあとは、最初の画面へ戻す（v8.1.0、3回目の試運転の指摘2）
        switched = self.pack.intimacy and (context.auto_minutes > 0 or work["mode"] != self._state["mode"]
                                           or work["actors"]["player"]["location"] != self._state["actors"]["player"]["location"]
                                           or work["world"]["now"] // 1440 != self._state["world"]["now"] // 1440)
        page = ("main", 0) if self._owner(work) or self._owner(self._state) or intimacy_changed or switched else self._page
        frame = self._make_frame(work, display, revision + 1)
        frame["choices"], plans, explanations = build_choices(work, self.pack, self.repository, page, frame, self._test_cheat_intimacy)
        validate_schema(frame, SCHEMA["$defs"]["frame"], SCHEMA, "frame")
        outcome = blocks[-1]["meaning"] if blocks else "system.paused"
        work["history"].append({"seq": work["world"]["operation_seq"], "choice": choice_id, "at": work["world"]["now"], "outcome": outcome})
        work["history"] = work["history"][-1024:]
        traces = self._update_traces(context, blocks, choice_id)
        validate_state(work, self.pack, self.repository, self._test_cheat_intimacy)
        # Files written above are immutable archives. Failure leaves the live game untouched.
        self._state, self._frame, self._page, self._plans, self._explanations, self._trace_refs = work, frame, page, plans, explanations, traces
        self.diagnostics = {"candidates": context.candidate_counts, "operation": work["world"]["operation_seq"]}
        if self.autosave_enabled:
            try:
                self.storage.autosave(self._payload(), self._validate_payload)
                self.warnings = []
            except (GameError, OSError) as error: self.warnings = ["自動保存できなかった。現在の画面は保持している。 " + str(error)]
        return self.get_view()

    def _update_traces(self, context, blocks, choice):
        refs = dict(self._trace_refs)
        before, after = self._state["scene"], context.s["scene"]
        target = before or after
        if target and not context.restore_frame and choice != "scene.pause":
            trace = {"scene_id": target["scene_id"], "release": target["release"], "records": [], "truncated": False, "incomplete": False}
            if target["id"] in refs:
                try: trace = self.storage.read_archive(refs[target["id"]])
                except (GameError, OSError): trace["incomplete"] = True
            for block in blocks:
                if not block["meaning"].startswith("offer."):
                    trace["records"].append({"choice": choice, "at": context.now, "block": deepcopy(block)})
            if len(trace["records"]) > 256: trace["truncated"] = True
            trace["records"] = trace["records"][-256:]
            if trace["records"]: refs[target["id"]] = self.storage.archive(trace)
        for scene in context.finished_scenes:
            if scene["id"] in refs:
                trace = self.storage.read_archive(refs[scene["id"]])
                context.s["gallery"].append({"id": scene["id"], "scene_id": scene["scene_id"], "release": scene["release"], "at": scene["at"], "archive_sha256": refs[scene["id"]], "block_count": len(trace["records"])})
                context.s["gallery"] = context.s["gallery"][-128:]
        living = {s["id"] for s in [context.s["scene"], *context.s["suspended"]] if s}
        return {identity: sha for identity, sha in refs.items() if identity in living}

    def _required_releases(self, state, frame, active):
        releases = {active, frame["release"], *[b["release"] for b in frame["blocks"]]}
        for scene in [state["scene"], *state["suspended"]]:
            if scene:
                releases.add(scene["release"])
                if scene["saved_frame"]:
                    releases.add(scene["saved_frame"]["release"])
                    releases.update(b["release"] for b in scene["saved_frame"]["blocks"])
        return {identity: self.repository.get(identity).hash for identity in sorted(releases)}

    def _payload(self):
        payload = {"state": clone_state(self._state), "frame": deepcopy(self._frame), "page": list(self._page), "active_release": self.active_release, "releases": self._required_releases(self._state, self._frame, self.active_release), "trace_refs": dict(self._trace_refs)}
        if self._test_cheat_intimacy:
            payload["test_cheats"] = {"contact_unlock": True, "all": self._test_cheat_all}
        return payload

    def _validate_payload(self, payload):
        try:
            return self._validate_payload_contents(payload)
        except (KeyError, TypeError, ValueError, AttributeError, IndexError, RecursionError) as error:
            if isinstance(error, GameError): raise
            raise GameError("save_format", "保存データの型・登録・参照が不正。現在の進行は変更していない。") from error

    def _validate_payload_contents(self, payload):
        exact(payload, ["state", "frame", "page", "active_release", "releases", "trace_refs"], ("test_cheats", "_legacy_rules_migrated"))
        ensure(payload.get("_legacy_rules_migrated", True) is True, "save_format", "旧保存の移行情報が不正。")
        test_cheats = payload.get("test_cheats", {})
        ensure(type(test_cheats) is dict and set(test_cheats) <= {"contact_unlock", "all"} and all(type(v) is bool for v in test_cheats.values()), "save_format", "テストチート情報の型が不正。")
        saved_intimacy_cheat = test_cheats.get("contact_unlock", False)
        saved_all_cheat = test_cheats.get("all", False)
        ensure(not saved_all_cheat or saved_intimacy_cheat, "save_format", "全開放チートの保存情報が不正。")
        ensure(not (saved_intimacy_cheat or saved_all_cheat) or self.test_cheats, "cheat_disabled", "この保存にはテストチートが含まれる。--test-cheats付きで読み込む。")
        pack = self.repository.get(payload["active_release"])
        ensure(type(payload["page"]) is list and len(payload["page"]) == 2 and payload["page"][0] in PAGES and type(payload["page"][1]) is int and 0 <= payload["page"][1] <= 1000000, "page", "保存した画面が不正。")
        validate_state(payload["state"], pack, self.repository, saved_intimacy_cheat)
        frame = payload["frame"]
        validate_schema(frame, SCHEMA["$defs"]["frame"], SCHEMA, "frame")
        ensure(frame["question_owner"] == self._owner(payload["state"]), "frame_owner", "保存した問いと場面が一致しない。")
        ensure(payload["releases"] == self._required_releases(payload["state"], frame, pack.id), "release_hash", "保存時の原稿の版と一致しない。")
        for f in [frame, *[s["saved_frame"] for s in payload["state"]["suspended"]]]:
            for block in f["blocks"]:
                source = self.repository.get(block["release"])
                ensure(block["variant"] in source.by_text and source.by_text[block["variant"]]["meaning"] == block["meaning"], "saved_text", "保存した本文の参照が不正。")
        expected, _, _ = build_choices(payload["state"], pack, self.repository, tuple(payload["page"]), frame, saved_intimacy_cheat)
        if payload.get("_legacy_rules_migrated"):
            frame["choices"] = expected
        ensure(expected == frame["choices"], "saved_choices", "保存した操作と現在の状態が一致しない。")
        living = {s["id"] for s in [payload["state"]["scene"], *payload["state"]["suspended"]] if s}
        ensure(type(payload["trace_refs"]) is dict and payload["trace_refs"].keys() <= living, "trace", "場面記録の参照が不正。")
        import re
        ensure(all(type(v) is str and re.fullmatch(r"[a-f0-9]{64}", v) for v in payload["trace_refs"].values()), "trace", "場面記録の検査値が不正。")
        return pack

    def save(self, slot="slot01"):
        ensure(type(slot) is str and slot.startswith("slot"), "save_slot", "手動保存はslot01〜slot10を使う。")
        payload = self._payload()
        self._validate_payload(payload)
        self.storage.write(slot, payload, self._validate_payload)
        return {"slot": slot, "bytes": len(self.storage.encode(payload))}

    def load(self, slot="slot01", backup=False):
        ensure(type(backup) is bool, "save_slot", "backupは真偽値で指定する。")
        payload = self.storage.read(slot, backup)
        pack = self._validate_payload(payload)
        self._test_cheat_intimacy = payload.get("test_cheats", {}).get("contact_unlock", False)
        self._test_cheat_all = payload.get("test_cheats", {}).get("all", False)
        state, frame, page = deepcopy(payload["state"]), deepcopy(payload["frame"]), tuple(payload["page"])
        _, plans, explanations = build_choices(state, pack, self.repository, page, frame, self._test_cheat_intimacy)
        self._state, self._frame, self._page, self.pack, self.active_release = state, frame, page, pack, pack.id
        self._trace_refs, self._plans, self._explanations = dict(payload["trace_refs"]), plans, explanations
        self._session, self.warnings = token_hex(16), []
        self.diagnostics = {"candidates": [], "operation": state["world"]["operation_seq"]}
        return self.get_view()

    def get_diagnostics(self):
        return {"rules": self.pack.manifest["rules_version"], "release": self.active_release, "seed": self._state["world"]["seed"], "operation": self._state["world"]["operation_seq"], "scene": deepcopy(self._state["scene"]), "contacts": deepcopy(self._state["contacts"]), "intention": deepcopy(self._state["intention"]), "unavailable": deepcopy(self._explanations), "last_selection": deepcopy(self.diagnostics), "save_budget": deepcopy(self.pack.save_budget), "test_cheats": {"allowed": self.test_cheats, "contact_unlock_active": self._test_cheat_intimacy, "all_active": self._test_cheat_all}, "progression": self._progression_diagnostics()}

    def _progression_diagnostics(self):
        rules, s = self.pack.progression, self._state
        if rules is None:
            return {"enabled": False}
        start, day = clock.minutes(self.pack.catalog["start_at"]), progression.life_day(s["world"]["now"])
        plan = rules.doze_plan(s["world"]["seed"], day)
        hhmm = lambda t: f"{t // 60 % 24:02d}:{t % 60:02d}"
        stage, following = s["relation"]["stage"], None
        if stage < 4:
            missing = [] if evaluate(self.pack.catalog["milestones"][stage]["when"], self.pack.registry.values(s)) is True else ["catalog"]
            following = {"stage": stage + 1, "missing": missing + progression.milestone_missing(s, rules, stage + 1, start)}
        return {"enabled": True, "affinity": {**deepcopy(s["affinity"]), "display": rules.display},
                "desire": {"value": s["desire"], "level": rules.desire_level(s["desire"])},
                "life_day": day, "days_since_milestone": progression.days_since_milestone(s, start),
                "maho_sleep": deepcopy(s["maho_sleep"]),
                "doze_today": {"scheduled": plan is not None, "start": hhmm(plan[0]) if plan else None, "end": hhmm(plan[1]) if plan else None},
                "next_milestone": following}

    def enable_test_cheat(self, action):
        """Enable a named test override or a consistent near-end play state."""
        ensure(self.test_cheats, "cheat_disabled", "テストチートは--test-cheats付きの実行でだけ使える。")
        ensure(type(action) is str and action not in ("intimacy", "親密度"), "cheat_renamed", "『チート 親密度』は『チート 接触解放』に改名した。")
        lewd_cheat = type(action) is str and re.fullmatch(r"lewdness:[0-9]{1,4}", action) is not None  # v8.2.12：淫乱度を設定（試運転用）
        ensure(lewd_cheat or action in ("contact_unlock", "接触解放", "all", "全開放", "intimacy_tier:first", "intimacy_tier:few", "intimacy_tier:familiar"), "cheat_action", "使用できるテストチートは接触解放・全開放・intimacy_tier・lewdness。")
        if lewd_cheat:
            rules = self.pack.intimacy
            ensure(rules is not None and rules.lewd is not None, "cheat_action", "この原稿版に淫乱度はない。interaction_009 で使う。")
            ensure(self._state["intimacy"] is None and not self._state["scene"] and not self._state["offer"], "answer_first", "エッチや話、誘いを区切ってから淫乱度を変える。")
            ensure(self._state["intimacy_history"]["count"] > 0, "cheat_action", "エッチを1回以上してから淫乱度を変える（先に『チート intimacy_tier:few』）。")
            value = min(int(action.split(":", 1)[1]), rules.lewd["max"])
            work = clone_state(self._state)
            work["world"]["operation_seq"] += 1
            work["intimacy_history"]["lewdness"] = value
            work["history"].append({"seq": work["world"]["operation_seq"], "choice": "cheat.lewdness." + str(value), "at": work["world"]["now"], "outcome": "cheat.lewdness"})
            work["history"] = work["history"][-1024:]
            validate_state(work, self.pack, self.repository, True)
            frame = self._make_frame(work, self._frame["blocks"], self._frame["revision"] + 1)
            frame["choices"], plans, explanations = build_choices(work, self.pack, self.repository, self._page, frame, True)
            self._state, self._frame, self._plans, self._explanations = work, frame, plans, explanations
            self._test_cheat_intimacy = True
            if self.autosave_enabled: self.storage.autosave(self._payload(), self._validate_payload)
            return {"action": "lewdness", "value": value, "enabled": True}
        if action.startswith("intimacy_tier:"):
            ensure(self.pack.intimacy is not None, "cheat_action", "この原稿版にエッチはない。慣れのチートは interaction_009 で使う。")
            ensure(self._state["intimacy"] is None, "cheat_action", "エッチの最中は慣れを変更できない。")
            # 誘いや話の途中、恋人になる前は使えない。使った保存はチート使用済みとして残す（v8.0.5、監査 D-03・D-04・E-05）。
            ensure(not self._state["scene"] and not self._state["offer"], "answer_first", "進行中の話や誘いを区切ってから慣れを変える。")
            ensure(self._state["relation"]["stage"] >= 3, "relationship", "恋人になってから慣れを変える（先に『チート 全開放』）。")
            tier = action.split(":", 1)[1]
            count = {"first": 0, "few": 1, "familiar": 5}[tier]
            work = clone_state(self._state)
            work["world"]["operation_seq"] += 1
            hist = work["intimacy_history"]
            # v8.2.30（通し確かめ 17）：前の回は数日前に満たされて終えたことにする（「前夜に満たされなかった」扱いで、翌朝に「足りなかった」と言っていた）
            past = max(0, work["world"]["now"] - 3 * 1440)
            hist.update(count=count, first_at=past if count else None, last_at=past if count else None,
                        last_result="satisfied" if count else None, by_entry={"private": count, "invite": 0, "wake": 0}, declined_at=None)
            if not count:
                hist.update(lewdness=0, maho_climaxes=0, finishes=0)  # v8.2.12：未経験に戻すときは記録の数も戻す
                if self._page[0] == "records":
                    self._page = ("main", 0)  # 記録の画面を開いたままなら、いつもの時間へ（読み手の指摘 M-7）
            work["stamina"]["value"] = self.pack.intimacy.raw["player"]["stamina_max"]
            work["history"].append({"seq": work["world"]["operation_seq"], "choice": "cheat.intimacy_tier." + tier, "at": work["world"]["now"], "outcome": "cheat.intimacy_tier"})
            work["history"] = work["history"][-1024:]
            validate_state(work, self.pack, self.repository, True)
            frame = self._make_frame(work, self._frame["blocks"], self._frame["revision"] + 1)
            frame["choices"], plans, explanations = build_choices(work, self.pack, self.repository, self._page, frame, True)
            self._state, self._frame, self._plans, self._explanations = work, frame, plans, explanations
            self._test_cheat_intimacy = True
            if self.autosave_enabled: self.storage.autosave(self._payload(), self._validate_payload)
            return {"action": "intimacy_tier", "tier": tier, "enabled": True}
        if action in ("contact_unlock", "接触解放"):
            self._test_cheat_intimacy = True
            self._install_choices()
            return {"action": "contact_unlock", "enabled": True, "scope": "current_run", "relation_stage": self._state["relation"]["stage"]}
        ensure(not self._state["scene"] and not self._state["offer"], "answer_first", "進行中の話や誘いを区切ってから全開放を使う。")
        ensure(not any(scene["scene_id"] in {"milestone_1", "milestone_2", "milestone_3"} for scene in self._state["suspended"]),
               "answer_first", "保留中の関係の話を終えてから全開放を使う。")
        ensure(self._state["mode"] == "normal", "private", "二人の時間を終えてから全開放を使う。")
        ensure(self._state["actors"]["player"]["location"] == self._state["actors"]["maho"]["location"],
               "location", "真帆と同じ場所で全開放を使う。")
        ensure(self._state["maho_sleep"]["state"] == "awake", "maho_sleeping", "真帆は眠っている。起きているときに全開放を使う。")
        work = clone_state(self._state)
        previous_stage = work["relation"]["stage"]
        work["world"]["operation_seq"] += 1
        context = Context(work, self.pack, self.repository, self._frame, True)
        for stage in range(work["relation"]["stage"] + 1, 4):
            context.commit_relation(stage, test_cheat=True)
        work["mood"] = {key: 2 for key in work["mood"]}
        work["interaction_streak"] = None
        if self.pack.progression:
            work["affinity"]["value"] = max(work["affinity"]["value"], self.pack.progression.min_affinity[2])
        validate_state(work, self.pack, self.repository, True)
        blocks = self._render(context)
        frame = self._make_frame(work, blocks or self._frame["blocks"], self._frame["revision"] + 1)
        frame["choices"], plans, explanations = build_choices(work, self.pack, self.repository, self._page, frame, True)
        validate_schema(frame, SCHEMA["$defs"]["frame"], SCHEMA, "frame")
        work["history"].append({"seq": work["world"]["operation_seq"], "choice": "cheat.all", "at": work["world"]["now"], "outcome": "relation.3" if previous_stage < 3 else "mood.max"})
        work["history"] = work["history"][-1024:]
        validate_state(work, self.pack, self.repository, True)
        self._state, self._frame, self._plans, self._explanations = work, frame, plans, explanations
        self._test_cheat_intimacy = self._test_cheat_all = True
        self.diagnostics = {"candidates": context.candidate_counts, "operation": work["world"]["operation_seq"]}
        if self.autosave_enabled:
            try:
                self.storage.autosave(self._payload(), self._validate_payload)
                self.warnings = []
            except (GameError, OSError) as error:
                self.warnings = ["自動保存できなかった。現在の画面は保持している。 " + str(error)]
        return {"action": "all", "enabled": True, "scope": "current_run", "relation_stage": work["relation"]["stage"], "mood": deepcopy(work["mood"])}

    def adopt_release(self, identity):
        ensure(not self._state["scene"] and not self._state["offer"], "answer_first", "原稿の切替は問いを区切ってから行う。")
        pack = self.repository.get(identity)
        same_control = pack.control_hash == self.pack.control_hash
        old_releases = {"interaction_003", "interaction_004", "interaction_005"}
        into_a2 = identity == "interaction_008" and self.active_release in old_releases | {"interaction_006", "interaction_007"} and not self._state["suspended"] and self._state["mode"] == "normal"
        into_b = identity == "interaction_009" and self.active_release == "interaction_008" and not self._state["suspended"] and self._state["mode"] == "normal"
        # v8.3.0：009 を確定した。次の版 010 は、009 の保存から通常時に切り替えられる（決まりが変わっても、状態の形が合えば。合わなければ検査で止まる）
        into_next = identity == "interaction_010" and self.active_release == "interaction_009" and not self._state["suspended"] and self._state["mode"] == "normal"
        to_progression = identity in {"interaction_007", "interaction_008"} and self.active_release in old_releases | {"interaction_006"} and not self._state["suspended"]
        compatible = into_b or into_next or (self.active_release != "interaction_008" and (same_control or (identity == "interaction_006" and self.active_release in old_releases and not self._state["suspended"]) or to_progression or into_a2))
        ensure(compatible, "control_change", "状態や動作の変更には専用の移行実装が必要。本文・場面の追加版だけを切り替えられる。")
        state = self._state
        if to_progression and not same_control:
            ensure(self._state["mode"] == "normal", "private", "二人の時間を終えてから原稿を切り替える。")
            # Rules 2.2 never tracked affinity: start from the lower bound of the current stage.
            state = clone_state(self._state)
            stage = state["relation"]["stage"]
            state["affinity"] = progression.neutral_affinity()
            state["affinity"]["value"] = pack.progression.min_affinity[stage - 1] if stage else 0
            state["desire"], state["maho_sleep"] = 0, progression.neutral_sleep()
        if into_b:
            state = add_neutral(clone_state(self._state), pack)
            for key in pack.actions:
                state["experience"].setdefault(key, {"count": 0, "first_at": None, "last_at": None, "by_origin": {"player": 0, "maho": 0}})
        validate_state(state, pack, self.repository, self._test_cheat_intimacy)
        frame = self._make_frame(state, self._frame["blocks"], self._frame["revision"] + 1, pack)
        frame["choices"], plans, explanations = build_choices(state, pack, self.repository, self._page, frame, self._test_cheat_intimacy)
        validate_schema(frame, SCHEMA["$defs"]["frame"], SCHEMA, "frame")
        self._state = state
        self.pack, self.active_release, self._frame, self._plans, self._explanations = pack, identity, frame, plans, explanations
        return self.get_view()

    def get_collection(self, kind="memories", identity=None):
        if kind == "replay":
            record = next((r for r in self._state["gallery"] if r["id"] == identity), None)
            ensure(record is not None, "replay", "この回想は記録されていない。")
            return self.storage.read_archive(record["archive_sha256"])
        ensure(kind in ("memories", "gallery", "promises", "promise_history", "orders", "order_history", "items", "project", "inbox"), "collection", "一覧の種類が違う。")
        return deepcopy(self._state[kind])
