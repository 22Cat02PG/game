"""v8.5.0（ユーザー 2026-10-08 07:02「ではそれから進めて」、07:59「GROKが作れるようゲージなどの土台となるシステムはちゃんと作っておいてね」）：010 だけ。
段階C の一歩目：眠っている真帆に触れる（寝込み）・夜這い・翌朝・警戒。仕様 docs/凪島_段階C_仕様_2026-10-08.md の第2・3・5.1・6.3・16節。
この版の行動は、触れ合いと唇までの口づけ。行動・夜の印・反応・翌朝はデータで足せる（test_data_extension で、エンジンを触らずに足して確かめる）。"""
import copy
import functools
import json
import shutil
import tempfile
import unittest
from pathlib import Path

import tools.run_stage_b_routes as routes
from nagishima.codec import bytes_digest, digest
from nagishima.conditions import validate
from nagishima.content import Pack
from nagishima.engine import Engine
from nagishima.errors import GameError
from nagishima.progression import life_day
from nagishima.sleep_rules import SleepRules
from tools.run_stage_b_routes import Route

ROOT = Path(__file__).resolve().parents[1]
P009 = Pack(ROOT / "content/releases/interaction_009")
P010 = Pack(ROOT / "content/releases/interaction_010")


def night_route(affinity, desire=0, tier="familiar", hour=23, minute=20, day_offset=0, seed=8):
    """真帆の就寝の少し前（平日前夜 23:30 の前）。day_offset 3 は休日前夜（就寝 1:30）。"""
    route = Route(seed, hour=hour, minute=minute, tier=tier, release="interaction_010", dinner=True, bath=True, day_offset=day_offset)
    state = route.engine._state
    state["affinity"]["value"], state["desire"] = affinity, desire
    route.engine._install_choices()
    route.choose("wait.30")
    assert route.engine.snapshot()["maho_sleep"]["state"] == "asleep"
    return route


def act(route, key):
    """寝込みの手を選ぶ（ほかのページにあれば移ってから）。"""
    engine = route.engine
    for page in [None] + ["sleep.menu." + p for p in engine.pack.intimacy.sleep_play.pages]:
        if page:
            if not any(c["id"] == page for c in engine.get_view()["choices"]):
                continue
            route.choose(page)
        choice = next((c for c in engine.get_view()["choices"] if c["id"] == "sleep." + key), None)
        if choice and choice["available"]:
            return route.choose("sleep." + key)
    raise AssertionError((key, [(c["id"], c["available"], c["reason"]) for c in engine.get_view()["choices"]]))


def until_awake(route, key, limit=30):
    view = None
    for _ in range(limit):
        if not route.engine.snapshot()["sleep_play"]:
            return view
        view = act(route, key)
    raise AssertionError("目覚めない")


def no_fake(route):
    """寝たふり（50%）を外して、目覚めの反応だけを確かめる。"""
    route.engine._state["sleep_play"]["fake"] = False
    route.engine._install_choices()


def meanings(view):
    return [b["meaning"] for b in view["blocks"]]


def ids(view):
    return [c["id"] for c in view["choices"]]


class V850(unittest.TestCase):
    def test_009_unchanged(self):
        self.assertIsNone(P009.intimacy.sleep_play)
        self.assertFalse(any(m.startswith("sp.") for m in P009.meanings))

    def test_rules(self):
        rules = P010.intimacy.sleep_play
        self.assertEqual(list(rules.actions), ["sp_stroke_head", "sp_hold_hand", "sp_cheek", "sp_hair", "sp_back", "sp_hug", "sp_waist", "sp_kiss_cheek", "sp_kiss", "sp_blanket", "sp_wait", "sp_leave"])
        self.assertEqual([rules.depth(a, 0) for a in (0, 15, 35, 45, 60, 80, 100)], [-2, -1, 0, 1, 2, 3, 3])
        self.assertEqual(rules.depth(70, 3), 3)  # 受け入れが3回以上なら +1
        self.assertEqual(rules.accept, frozenset({"fake_crumble", "sleepy_accept", "surprised_accept", "accept"}))
        self.assertEqual(rules.actions["sp_kiss"]["level"], 1)
        self.assertEqual(max(row.get("level", 0) for row in rules.actions.values()), 1)  # この版は唇への口づけまで
        for key in rules.actions:
            if key != "sp_leave":
                self.assertIn("sp." + key[3:], P010.meanings)
        for key in ("sleep.last", "sleep.flag.covered", "sleep.night.flag.covered", "sleep.used.sp_kiss", "sleep.night.used.sp_kiss", "sleep.level", "sleep.lead", "sleep.night.reaction"):
            self.assertIn(key, P010.registry.fields)

    def test_rules_reject_bad_data(self):
        """データの誤りは読み込みで止まる：未登録の印、最後がいつも当たらない表、本文の意味がない行動。"""
        raw = json.loads((ROOT / "content/releases/interaction_010/intimacy.json").read_text(encoding="utf-8"))["sleep_play"]
        catalog = P010.catalog
        SleepRules(copy.deepcopy(raw), catalog)
        bad = copy.deepcopy(raw)
        bad["actions"]["sp_hug"]["sets"] = ["unknown"]
        with self.assertRaises(GameError):
            SleepRules(bad, catalog)
        bad = copy.deepcopy(raw)
        bad["reactions"]["order"].pop()
        with self.assertRaises(GameError):
            SleepRules(bad, catalog)
        bad = copy.deepcopy(raw)
        bad["actions"]["sp_new"] = {"label": "新しい行動", "wake": 1, "discomfort": 1, "pleasure": 1}
        rules = SleepRules(bad, catalog)
        with self.assertRaises(GameError):
            rules.check_content(P010.registry.fields, P010.meanings, validate)

    def test_visit_and_choices(self):
        route = night_route(50)
        view = route.choose("sleep.visit")
        state = route.engine.snapshot()
        self.assertEqual(meanings(view)[-2:], ["sp.visit.enter", "sp.begin.asleep"])
        self.assertEqual(state["actors"]["player"]["location"], "maho_room")
        self.assertEqual(state["sleep_play"]["depth"], 1)
        self.assertIn("sleep.sp_kiss", ids(view))
        self.assertIn("sleep.sp_leave", ids(view))
        self.assertNotIn("sleep", ids(view))  # 寝込みの最中は、休むなどを出さない
        self.assertFalse(any(i.startswith("sleep.menu.") for i in ids(view)))  # ページは「触れる」だけ
        self.assertEqual(view["page_title"], "眠っている真帆")
        self.assertIn("wake_bar", view["status"]["sleep"])
        self.assertEqual(view["status"]["sleep"]["marks"], "")
        # 毛布をかけ直すと印が立ち、もう出さない。状態の欄に一言
        view = act(route, "sp_blanket")
        self.assertIn("sp.blanket", meanings(view))
        self.assertNotIn("sleep.sp_blanket", ids(view))
        self.assertEqual(view["status"]["sleep"]["marks"], "毛布を掛け直した")
        self.assertEqual(route.engine.snapshot()["sleep_play"]["flags"], ["covered"])
        self.assertEqual(route.engine.pack.registry.values(route.engine.snapshot())["sleep.last"], "sp_blanket")
        route.close()

    def test_low_affinity_guard(self):
        """好感度が低いうちに唇に口づけて見つかると、本気で怒って警戒（5日）。部屋の鍵・距離をとる・謝る。"""
        route = night_route(10)
        route.choose("sleep.visit")
        no_fake(route)
        view = until_awake(route, "sp_kiss")
        state = route.engine.snapshot()
        self.assertIn("sp.wake.furious_guard", meanings(view))
        self.assertEqual(state["sleep_record"]["cooling"]["kind"], "guard")
        self.assertEqual(state["sleep_record"]["cooling"]["until"] - life_day(state["world"]["now"]), 5)
        self.assertEqual(state["affinity"]["value"], 10)  # 段階の下限より下にはもう下げない
        self.assertEqual(state["actors"]["player"]["location"], "player_room")
        self.assertEqual(state["sleep_record"]["night"]["reaction"], "furious_guard")
        view = route.choose("sleep.visit")
        self.assertIn("sp.visit.locked", meanings(view))  # 警戒の間は、部屋に鍵がかかっている
        self.assertIsNone(route.engine.snapshot()["sleep_play"])
        view = route.choose("sleep")
        self.assertIn("sp.morning.after_guard", meanings(view))
        view = route.choose("near")
        self.assertIn("sp.guard.distance", meanings(view))  # 警戒の間は距離をとられる
        view = route.choose("sleep.apologize")
        self.assertIn("sp.apologize", meanings(view))
        route.close()

    def test_low_affinity_touch_only(self):
        """好感度が低いうちに、口づけずに触れるだけで目覚めた：気まずく離れる（警戒はしない）。"""
        route = night_route(20)
        route.choose("sleep.visit")
        no_fake(route)
        view = until_awake(route, "sp_cheek")
        state = route.engine.snapshot()
        self.assertIn("sp.wake.awkward", meanings(view))
        self.assertIsNone(state["sleep_record"]["cooling"])
        view = route.choose("sleep")
        self.assertIn("sp.morning.after_awkward", meanings(view))
        route.close()

    def test_lover_accepts_and_continues(self):
        """恋人で深さ3・休日前夜：口づけを重ねて目覚め、寝ぼけたまま受け入れる → 起きているエッチへ（夜の区切りのあとでも続けられる）。"""
        route = night_route(90, 95, hour=1, minute=20, day_offset=3)
        route.choose("sleep.visit")
        no_fake(route)
        view = until_awake(route, "sp_kiss")
        state = route.engine.snapshot()
        self.assertIn("sp.wake.sleepy_accept", meanings(view))
        self.assertEqual(state["mode"], "private")
        self.assertEqual((state["intimacy"]["entry"], state["intimacy"]["inserted"]), ("wake", False))
        self.assertEqual(state["actors"]["maho"]["clothing"], {"upper": "worn", "lower": "worn"})
        self.assertEqual(state["sleep_record"]["accepted"], 1)
        self.assertEqual(state["sleep_record"]["habits"], {"sp_kiss": 1})
        status = route.engine.get_view()["status"]["intimacy"]
        self.assertNotIn("01:30", status["deadline"])  # 寝込みから移った回は、移ってからの区切り
        route.action("h_kiss_deep")
        self.assertIsNone(route.engine.snapshot()["intimacy"]["wrap_up"])
        route.close()

    def test_leave_and_morning(self):
        """目覚める前に離れた夜：翌朝の表。受け入れたことがないうちに唇に口づけていたら問いただす。受け入れたことがあり快感が高ければ受け入れる。"""
        route = night_route(50)
        route.choose("sleep.visit")
        no_fake(route)
        act(route, "sp_kiss")
        view = route.choose("sleep.sp_leave")
        self.assertIn("sp.leave.asleep", meanings(view))
        night = route.engine.snapshot()["sleep_record"]["night"]
        self.assertEqual((night["level"], night["used"], night["reaction"]), (1, ["sp_kiss"], None))
        view = route.choose("sleep")
        self.assertIn("sp.morning.question", meanings(view))
        self.assertIsNone(route.engine.snapshot()["sleep_record"]["night"])
        route.close()
        route = night_route(90, 95, hour=1, minute=20, day_offset=3)
        route.engine._state["sleep_record"] = {"accepted": 3, "habits": {}, "cooling": None, "night": None, "apologized_day": None}
        route.choose("sleep.visit")
        no_fake(route)
        for _ in range(7):
            act(route, "sp_hug")
        self.assertGreaterEqual(route.engine.snapshot()["sleep_play"]["gauges"]["pleasure"], 50)
        route.choose("sleep.sp_leave")
        view = route.choose("sleep")
        self.assertTrue({"sp.morning.accept", "sp.morning.accept_invite"} & set(meanings(view)))
        record = route.engine.snapshot()["sleep_record"]
        self.assertEqual((record["accepted"], record["habits"]), (4, {"sp_hug": 1}))
        route.close()

    def test_quiet_morning(self):
        """快感・不快とも低いまま離れた夜は、翌朝に何も言わない（気づかないふり）。"""
        route = night_route(50)
        route.choose("sleep.visit")
        no_fake(route)
        act(route, "sp_stroke_head")
        route.choose("sleep.sp_leave")
        view = route.choose("sleep")
        self.assertFalse(any(m.startswith("sp.morning.") for m in meanings(view)))
        route.close()

    def test_doze(self):
        """居間のうたた寝：目覚めやすさは 1.5倍。目覚めたら真帆は起きる（居間のまま）。"""
        engine_route = Route(5, hour=20, minute=50, tier="familiar", release="interaction_010", dinner=True, bath=True)
        pack = engine_route.engine.pack
        day = life_day(engine_route.engine._state["world"]["now"])
        offset, plan = next((off, pack.progression.doze_plan(5, day + off)) for off in range(30) if pack.progression.doze_plan(5, day + off))
        engine_route.close()
        route = Route(5, hour=plan[0] // 60 % 24, minute=plan[0] % 60, tier="familiar", release="interaction_010", dinner=True, bath=True, day_offset=offset)
        route.engine._state["affinity"]["value"] = 40
        route.engine._install_choices()
        route.choose("listen")
        self.assertEqual(route.engine.snapshot()["maho_sleep"]["state"], "dozing")
        route.choose("sleep.begin")
        self.assertEqual(route.engine.snapshot()["sleep_play"]["kind"], "doze")
        until_awake(route, "sp_kiss")
        state = route.engine.snapshot()
        self.assertEqual(state["maho_sleep"]["state"], "awake")
        self.assertEqual(state["actors"]["player"]["location"], "living_room")
        route.close()

    def test_save_load_during_sleep(self):
        route = night_route(50)
        route.choose("sleep.visit")
        act(route, "sp_kiss")
        act(route, "sp_blanket")
        route.engine.save("slot02")
        route.engine.load("slot02")
        play = route.engine.snapshot()["sleep_play"]
        self.assertEqual((play["level"], play["flags"]), (1, ["covered"]))
        act(route, "sp_hug")
        route.close()

    def test_data_extension(self):
        """土台の確かめ：エンジンを触らずに、データだけでページ・印・行動・反応・翌朝を足せる（仕様 第16節）。"""
        temp = tempfile.TemporaryDirectory(prefix="nagishima-v850-")
        try:
            target = Path(temp.name) / "interaction_010"
            shutil.copytree(ROOT / "content/releases/interaction_010", target)
            load = lambda name: json.loads((target / name).read_text(encoding="utf-8"))  # noqa: E731
            intimacy, meanings_list, texts = load("intimacy.json"), load("meanings.json"), load("texts.json")
            sp = intimacy["sleep_play"]
            sp["pages"]["sp_test"] = "試し"
            sp["flags"]["test_mark"] = {"status": "試しの印"}
            sp["actions"]["sp_test_touch"] = {"label": "試しに触れる", "wake": 30, "discomfort": 0, "pleasure": 10, "page": "sp_test", "level": 2,
                                              "sets": ["test_mark"], "when": {"field": "sleep.depth", "op": "ge", "value": 2}}
            sp["actions"]["sp_test_undo"] = {"label": "印を消す", "wake": 0, "discomfort": 0, "pleasure": 0, "page": "sp_test", "clears": ["test_mark"],
                                             "when": {"field": "sleep.flag.test_mark", "op": "eq", "value": True}}
            sp["reactions"]["effects"]["test_react"] = {"accept": False, "cooling": "angry", "affinity_loss": 1, "morning": "test_morning"}
            sp["reactions"]["order"].insert(0, {"id": "test_react", "when": {"field": "sleep.level", "op": "ge", "value": 2}})
            sp["morning"]["ids"].append("test_morning")
            sp["morning"]["order"].insert(0, {"id": "test_morning", "when": {"field": "sleep.night.flag.test_mark", "op": "eq", "value": True}})
            for meaning in ("sp.test_touch", "sp.test_undo", "sp.wake.test_react", "sp.morning.test_morning"):
                meanings_list.append(meaning)
                texts.append({"id": meaning + ".base", "meaning": meaning, "when": {"all": []}, "slots": [], "group": meaning + ".base", "body": "（" + meaning + "）", "fallback": True})
            for name, value in (("intimacy.json", intimacy), ("meanings.json", meanings_list), ("texts.json", texts)):
                (target / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            manifest = load("release.json")
            control = {"catalog": load("catalog.json"), "actions": load("actions.json"), "progression": load("progression.json"), "life": load("life.json"), "intimacy": intimacy}
            manifest.update(files={name: bytes_digest((target / name).read_bytes()) for name in manifest["files"]}, control_sha256=digest(control))
            (target / "release.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            original = routes.Engine
            routes.Engine = functools.partial(Engine, builtin=Path(temp.name))
            try:
                # 1) 足した行動で目覚めさせる：足した反応 → 怒らせた日数・翌朝の一言
                route = night_route(90)
                self.assertIn("sp_test_touch", route.engine.pack.intimacy.sleep_play.actions)
                view = route.choose("sleep.visit")
                self.assertIn("sleep.menu.sp_test", ids(view))
                view = route.choose("sleep.menu.sp_test")
                self.assertEqual(view["page_title"], "眠っている真帆（試し）")
                self.assertIn("sleep.sp_test_touch", ids(view))
                self.assertNotIn("sleep.sp_test_undo", ids(view))  # 印がないうちは出さない
                view = route.choose("sleep.sp_test_touch")
                self.assertIn("sp.test_touch", meanings(view))
                self.assertEqual(view["status"]["sleep"]["marks"], "試しの印")
                self.assertIn("sleep.sp_test_undo", ids(view))
                view = route.choose("sleep.sp_test_undo")
                self.assertEqual(route.engine.snapshot()["sleep_play"]["flags"], [])
                view = until_awake(route, "sp_test_touch")
                self.assertIn("sp.wake.test_react", meanings(view))
                state = route.engine.snapshot()
                self.assertEqual(state["sleep_record"]["cooling"]["kind"], "angry")
                self.assertEqual(state["affinity"]["value"], 89)
                view = route.choose("sleep")
                self.assertIn("sp.morning.test_morning", meanings(view))
                route.close()
                # 2) 印を立てたまま離れた夜：翌朝の表の足した行
                route = night_route(90)
                route.choose("sleep.visit")
                act(route, "sp_test_touch")
                route.choose("sleep.sp_leave")
                self.assertEqual(route.engine.snapshot()["sleep_record"]["night"]["flags"], ["test_mark"])
                view = route.choose("sleep")
                self.assertIn("sp.morning.test_morning", meanings(view))
                route.close()
            finally:
                routes.Engine = original
        finally:
            temp.cleanup()


if __name__ == "__main__":
    unittest.main()
