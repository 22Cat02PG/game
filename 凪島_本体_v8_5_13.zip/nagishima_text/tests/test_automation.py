"""Public command tests; failure messages retain the seed and command prefix."""
from copy import deepcopy
import json
import os
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
import unittest

from nagishima.engine import Engine
from nagishima.session import Session
from tests.support import stage_four

ROOT = Path(__file__).resolve().parents[1]


class SessionTests(unittest.TestCase):
    seed = 37

    def setUp(self):
        self.temporary = TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.directory = Path(self.temporary.name)
        self.engine = Engine(self.directory / "first", seed=self.seed, autosave=False)
        self.session = Session(self.engine, max_turns=200)
        self.commands = []

    def execute(self, command, ok=True):
        self.commands.append(deepcopy(command))
        response = self.session.execute(command)
        context = json.dumps({"seed": self.seed, "commands": self.commands}, ensure_ascii=False)
        self.assertEqual(response["ok"], ok, context + "\n" + json.dumps(response.get("error"), ensure_ascii=False))
        # Every public response must be transportable without custom encoders.
        self.assertEqual(json.loads(json.dumps(response, allow_nan=False)), response, context)
        for field in ("state", "view", "run", "available_actions"):
            self.assertIn(field, response, context)
        self.assertEqual(response["state"], self.engine.snapshot(), context)
        return response

    def choose(self, identity):
        return self.execute({"command": "choose", "id": identity})

    def test_queries_consume_budget_but_do_not_advance_world_or_rng(self):
        before, view = self.engine.snapshot(), self.engine.get_view()
        for command in ("view", "state", "actions", "collection", "slots", "diagnostics"):
            response = self.execute({"command": command})
            self.assertEqual(response["state"], before)
            self.assertEqual(response["view"], view)
        self.assertEqual(response["run"]["turns"], 6)
        self.assertFalse(response["run"]["ended"])

    def test_available_actions_are_executable_choices_and_exclude_locked_choices(self):
        self.choose("menu.touch")
        response = self.execute({"command": "actions"})
        expected = [choice for choice in response["view"]["choices"] if choice["available"]]
        self.assertEqual(response["available_actions"], expected)
        self.assertEqual(response["result"], response["view"]["choices"])
        self.assertNotIn("touch.kiss", [choice["id"] for choice in expected])
        self.assertIn("touch.talk", [choice["id"] for choice in expected])

    def test_choices_hide_actions_that_would_repeat_the_current_state(self):
        self.choose("near")
        self.assertNotIn("near", [choice["id"] for choice in self.engine.get_view()["choices"]])

        self.choose("menu.touch")
        touch_ids = {choice["id"] for choice in self.engine.get_view()["choices"]}
        self.assertNotIn("near", touch_ids)
        self.assertNotIn("posture.seated", touch_ids)
        self.assertIn("posture.standing", touch_ids)

        self.choose("menu.main")
        self.choose("menu.move")
        move_ids = {choice["id"] for choice in self.engine.get_view()["choices"]}
        self.assertNotIn("move.solo.living_room", move_ids)
        self.assertNotIn("move.joint.living_room", move_ids)

        self.choose("menu.main")
        self.choose("menu.appearance")
        appearance_ids = {choice["id"] for choice in self.engine.get_view()["choices"]}
        self.assertNotIn("prepare.player.work.short", appearance_ids)
        self.assertNotIn("prepare.maho.work.tied", appearance_ids)

    def test_presence_tracks_distance_and_ongoing_contact(self):
        self.assertIn("同じ居間", self.engine.get_view()["status"]["presence"])
        self.choose("near")
        self.assertIn("すぐそば", self.engine.get_view()["status"]["presence"])
        engine = Engine(self.directory / "presence", seed=self.seed, autosave=False, test_cheats=True)
        session = Session(engine, test_cheats=True)
        self.assertTrue(session.execute({"command": "cheat", "action": "contact_unlock"})["ok"])
        for identity in ("near", "menu.touch", "touch.hands"):
            self.assertTrue(session.execute({"command": "choose", "id": identity})["ok"])
        self.assertIn("手をつないだまま", engine.get_view()["status"]["presence"])

    def test_active_contact_shows_continuation_and_end_side_by_side(self):
        engine = Engine(self.directory / "contact-labels", seed=self.seed, autosave=False, test_cheats=True)
        session = Session(engine, test_cheats=True)
        self.assertTrue(session.execute({"command": "cheat", "action": "contact_unlock"})["ok"])
        for identity in ("near", "menu.touch", "touch.hug"):
            self.assertTrue(session.execute({"command": "choose", "id": identity})["ok"])
        choices = engine.get_view()["choices"]
        labels = {choice["id"]: choice["label"] for choice in choices}
        ids = [choice["id"] for choice in choices]
        self.assertEqual(labels["touch.hug"], "抱きしめたままでいる")
        self.assertEqual(labels["end.hug"], "腕をほどく")
        self.assertEqual(ids.index("end.hug"), ids.index("touch.hug") + 1)

    def test_observe_is_detached_and_does_not_consume_a_turn(self):
        before = self.session.observe()
        modified = self.session.observe()
        modified["state"]["relation"]["stage"] = 4
        modified["view"]["choices"].clear()
        modified["available_actions"].clear()
        modified["run"]["turns"] = 100
        self.assertEqual(self.session.observe(), before)
        self.assertEqual(before["run"]["turns"], 0)

    def test_unavailable_choice_preserves_state_rng_and_view(self):
        self.choose("menu.touch")
        before, view = self.engine.snapshot(), self.engine.get_view()
        response = self.execute({"command": "choose", "id": "touch.kiss"}, ok=False)
        self.assertEqual(response["error"]["code"], "relationship")
        self.assertEqual(self.engine.snapshot(), before)
        self.assertEqual(self.engine.get_view(), view)
        self.assertEqual(response["run"]["turns"], 2)

    def test_explicit_stale_revision_is_rejected(self):
        old = self.session.observe()["view"]
        self.choose("menu.talk")
        before, view = self.engine.snapshot(), self.engine.get_view()
        response = self.execute({"command": "choose", "id": "begin.two_cups",
                                 "revision": old["revision"], "session": old["session"]}, ok=False)
        self.assertEqual(response["error"]["code"], "stale_choice")
        self.assertEqual(self.engine.snapshot(), before)
        self.assertEqual(self.engine.get_view(), view)

    def test_malformed_commands_are_json_errors_without_state_mutation(self):
        before, view = self.engine.snapshot(), self.engine.get_view()
        invalid = [None, [], "view", 2, {}, {"command": []}, {"command": "unknown"},
                   {"command": "view", "unexpected": True}, {"command": "choose"},
                   {"command": "choose", "id": ["menu.talk"]},
                   {"command": "choose", "id": "menu.talk", "revision": 0},
                   {"command": "choose", "id": "menu.talk", "session": view["session"]},
                   {"command": "choose", "id": "menu.talk", "revision": False, "session": view["session"]},
                   {"command": "save", "slot": []},
                   {"command": "load", "backup": "false"},
                   {"command": "collection", "kind": []}]
        for command in invalid:
            with self.subTest(command=command):
                response = self.execute(command, ok=False)
                self.assertIsInstance(response["error"]["code"], str)
                self.assertIsInstance(response["error"]["message"], str)
                self.assertEqual(self.engine.snapshot(), before)
                self.assertEqual(self.engine.get_view(), view)
        self.assertEqual(response["run"]["turns"], len(invalid))

    def test_save_load_restores_world_and_rng_without_resetting_run_budget(self):
        self.choose("menu.talk")
        self.choose("begin.two_cups")
        self.choose("scene.water")
        saved, saved_view = self.engine.snapshot(), self.engine.get_view()
        self.execute({"command": "save", "slot": "slot02"})
        self.choose("scene.remember")
        expected_next, expected_blocks = self.engine.snapshot(), self.engine.get_view()["blocks"]
        restored = self.execute({"command": "load", "slot": "slot02"})
        self.assertEqual(restored["state"], saved)
        self.assertEqual(restored["view"]["blocks"], saved_view["blocks"])
        self.assertNotEqual(restored["view"]["session"], saved_view["session"])
        self.assertEqual(restored["run"]["turns"], 6)
        stale = self.execute({"command": "choose", "id": "scene.remember",
                              "revision": saved_view["revision"], "session": saved_view["session"]}, ok=False)
        self.assertEqual(stale["error"]["code"], "stale_choice")
        final = self.choose("scene.remember")
        self.assertEqual(final["state"], expected_next)
        self.assertEqual(final["view"]["blocks"], expected_blocks)
        self.assertEqual(final["run"]["turns"], 8)

    def test_same_seed_and_commands_reproduce_state_and_prose(self):
        other = Session(Engine(self.directory / "second", seed=self.seed, autosave=False), max_turns=200)
        commands = [{"command": "choose", "id": identity} for identity in
                    ("menu.talk", "begin.two_cups", "scene.tea", "scene.remember")]
        for command in commands:
            first, second = self.execute(command), other.execute(command)
            self.assertTrue(second["ok"])
            self.assertEqual(first["state"], second["state"])
            self.assertEqual(first["run"], second["run"])
            first_view, second_view = deepcopy(first["view"]), deepcopy(second["view"])
            # Session tokens intentionally differ to reject stale UI inputs.
            first_view.pop("session")
            second_view.pop("session")
            self.assertEqual(first_view, second_view)

    def test_max_turns_prevents_query_loops_and_further_actions(self):
        self.session = Session(self.engine, max_turns=2)
        before = self.engine.snapshot()
        self.execute({"command": "state"})
        final = self.execute({"command": "state"})
        self.assertTrue(final["run"]["ended"])
        self.assertEqual(final["run"]["reason"], "max_turns")
        self.assertFalse(final["run"]["completed"])
        self.assertEqual(final["available_actions"], [])
        rejected = self.execute({"command": "choose", "id": "menu.talk"}, ok=False)
        self.assertEqual(rejected["error"]["code"], "run_ended")
        self.assertEqual(rejected["run"]["turns"], 2)
        self.assertEqual(self.engine.snapshot(), before)

    def test_last_allowed_command_is_executed_before_turn_limit(self):
        self.session = Session(self.engine, max_turns=2)
        self.choose("menu.touch")
        final = self.choose("touch.talk")
        self.assertEqual(final["state"]["experience"]["talk"]["count"], 1)
        self.assertEqual(final["run"]["turns"], 2)
        self.assertEqual(final["run"]["reason"], "max_turns")

    def test_malformed_request_also_hits_budget(self):
        self.session = Session(self.engine, max_turns=1)
        response = self.execute(None, ok=False)
        self.assertEqual(response["run"]["reason"], "max_turns")
        self.assertEqual(response["run"]["turns"], 1)
        self.assertEqual(response["available_actions"], [])

    def test_invalid_json_and_duplicate_keys_are_bounded_errors(self):
        raw_commands = ['{', '{"command":"view","command":"quit"}',
                        '{"command":"choose","id":NaN}']
        self.session = Session(self.engine, max_turns=len(raw_commands))
        before = self.engine.snapshot()
        for number, raw in enumerate(raw_commands, 1):
            response = self.session.execute_line(raw)
            context = json.dumps({"seed": self.seed, "raw_commands": raw_commands[:number]})
            self.assertFalse(response["ok"], context)
            self.assertEqual(response["state"], before, context)
            self.assertEqual(response["run"]["turns"], number, context)
        self.assertEqual(response["run"]["reason"], "max_turns")

    def test_quit_records_reason_and_freezes_budget(self):
        response = self.execute({"command": "quit"})
        self.assertTrue(response["run"]["ended"])
        self.assertFalse(response["run"]["completed"])
        self.assertEqual(response["run"]["reason"], "quit")
        self.assertEqual(response["available_actions"], [])
        rejected = self.execute({"command": "view"}, ok=False)
        self.assertEqual(rejected["error"]["code"], "run_ended")
        self.assertEqual(rejected["run"]["turns"], 1)

    def test_batch_error_finish_does_not_consume_extra_turn(self):
        self.execute({"command": "choose", "id": "absent"}, ok=False)
        self.session.finish("error")
        final = self.session.observe()
        self.assertEqual(final["run"]["turns"], 1)
        self.assertEqual(final["run"]["reason"], "error")
        self.assertTrue(final["run"]["ended"])
        self.assertEqual(final["available_actions"], [])

    def test_complete_public_route_stops_at_stage_four(self):
        case = self

        class CommandsOnly:
            def snapshot(self):
                return case.session.observe()["state"]

            def get_view(self):
                return case.session.observe()["view"]

            def choose(self, identity, revision, session):
                return case.choose(identity)["view"]

        stage_four(CommandsOnly())
        final = self.session.observe()
        self.assertEqual(final["state"]["relation"]["stage"], 4)
        self.assertIsNone(final["state"]["scene"])
        self.assertIsNone(final["state"]["offer"])
        self.assertEqual(final["run"]["reason"], "completed")
        self.assertTrue(final["run"]["completed"])
        self.assertTrue(final["run"]["ended"])
        self.assertEqual(final["available_actions"], [])
        self.assertEqual(final["run"]["turns"], len(self.commands))
        # Finishing on exactly the last permitted command counts as success.
        other = Session(Engine(self.directory / "exact_limit", seed=self.seed, autosave=False),
                        max_turns=len(self.commands))
        for command in self.commands:
            response = other.execute(command)
            self.assertTrue(response["ok"], json.dumps(command))
        self.assertEqual(response["run"]["reason"], "completed")
        self.assertEqual(response["state"], final["state"])
        before = deepcopy(final["state"])
        self.execute({"command": "choose", "id": "sleep"}, ok=False)
        self.assertEqual(self.engine.snapshot(), before)

    def test_completed_engine_is_terminal_when_session_is_constructed(self):
        stage_four(self.engine)
        self.session = Session(self.engine, max_turns=200)
        final = self.session.observe()
        self.assertEqual(final["run"]["reason"], "completed")
        self.assertEqual(final["run"]["turns"], 0)
        self.assertTrue(final["run"]["completed"])
        self.assertEqual(final["available_actions"], [])


class CommandLineTests(unittest.TestCase):
    def setUp(self):
        self.temporary = TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.directory = Path(self.temporary.name)
        self.invocations = 0

    def run_cli(self, *arguments, lines=""):
        self.invocations += 1
        environment = os.environ.copy()
        environment.pop("PYTHONUTF8", None)
        environment.pop("PYTHONIOENCODING", None)
        environment["PYTHONUTF8"] = "1"
        mode = [] if any(item in arguments for item in ("--batch", "--autoplay", "--autoplay-social", "--replay")) else ["--json"]
        process = subprocess.run(
            [sys.executable, "-m", "nagishima", *mode, "--no-autosave",
             "--data-dir", str(self.directory / f"data{self.invocations}"),
             "--log", str(self.directory / f"run{self.invocations}.jsonl"), *arguments],
            input=lines, capture_output=True, text=True, encoding="utf-8",
            cwd=ROOT, env=environment, timeout=30)
        self.assertNotIn("Traceback", process.stderr, process.stderr)
        self.assertTrue(process.stdout.strip(), process.stderr)
        try:
            records = [json.loads(line) for line in process.stdout.splitlines()]
        except ValueError:
            self.fail("JSON mode wrote a prompt or non-JSON output:\n" + process.stdout)
        return process, records

    def test_json_stdin_reports_invalid_input_then_accepts_utf8_commands(self):
        lines = '\n'.join(['{', '{"command":"state"}', '{"command":"quit"}']) + '\n'
        process, records = self.run_cli("--name", "葵", "--seed", "37", lines=lines)
        self.assertEqual(process.returncode, 0, process.stderr)
        responses = [record for record in records if "ok" in record and "state" in record]
        self.assertFalse(responses[0]["ok"])
        self.assertTrue(any(record["ok"] for record in responses[1:]))
        self.assertEqual(records[-1]["state"]["actors"]["player"]["name"], "葵")
        self.assertEqual(records[-1]["run"]["reason"], "quit")
        self.assertEqual(records[-1]["run"]["turns"], 3)

    def test_autoplay_finishes_and_writes_seed_commands_and_ending(self):
        log = self.directory / "success.jsonl"
        process, records = self.run_cli("--autoplay", "--seed", "37", "--release", "interaction_006", "--log", str(log))
        self.assertEqual(process.returncode, 0, process.stderr)
        self.assertEqual(records[-1]["run"]["reason"], "completed")
        self.assertEqual(records[-1]["state"]["relation"]["stage"], 4)
        stored = [json.loads(line) for line in log.read_text(encoding="utf-8").splitlines()]
        self.assertEqual(stored[0]["config"]["seed"], 37)
        commands = [record for record in stored if record["type"] == "command"]
        self.assertTrue(commands)
        self.assertEqual(stored[-1]["type"], "end")
        self.assertEqual(stored[-1]["run"]["reason"], "completed")
        self.assertEqual(len(commands), stored[-1]["run"]["turns"])
        self.assertTrue(all("input" in command and "response" in command for command in commands))

        replay, replayed = self.run_cli("--replay", str(log))
        self.assertEqual(replay.returncode, 0, replay.stderr)
        self.assertEqual(replayed[-1]["run"]["reason"], "completed")
        self.assertEqual(replayed[-1]["state"], records[-1]["state"])

        commands[0]["sha256"] = "0" * 64
        log.write_text("\n".join(json.dumps(record, ensure_ascii=False) for record in stored) + "\n", encoding="utf-8")
        mismatch, rejected = self.run_cli("--replay", str(log))
        self.assertEqual(mismatch.returncode, 3, mismatch.stderr)
        self.assertFalse(rejected[-1]["ok"])

    def test_replay_restores_checkpoint_for_a_loaded_mid_scene_save(self):
        data = self.directory / "saved_data"
        engine = Engine(data, seed=91, autosave=False)
        session = Session(engine)
        for identity in ("menu.talk", "begin.two_cups", "scene.water"):
            self.assertTrue(session.execute({"command": "choose", "id": identity})["ok"])
        self.assertTrue(session.execute({"command": "save"})["ok"])
        batch = self.directory / "resume.jsonl"
        batch.write_text('{"command":"choose","id":"scene.remember"}\n{"command":"quit"}\n', encoding="utf-8")
        log = self.directory / "loaded.jsonl"
        process, records = self.run_cli("--data-dir", str(data), "--seed", "37", "--load", "slot01",
                                        "--batch", str(batch), "--log", str(log))
        self.assertEqual(process.returncode, 0, process.stderr)
        replay, replayed = self.run_cli("--replay", str(log))
        self.assertEqual(replay.returncode, 0, replay.stderr)
        self.assertEqual(replayed[-1]["state"], records[-1]["state"])
        self.assertEqual(replayed[-1]["view"]["blocks"], records[-1]["view"]["blocks"])

    def test_autoplay_max_turns_is_a_bounded_incomplete_run(self):
        process, records = self.run_cli("--autoplay", "--seed", "37", "--max-turns", "2")
        self.assertEqual(records[-1]["run"]["reason"], "max_turns")
        self.assertEqual(records[-1]["run"]["turns"], 2)
        self.assertFalse(records[-1]["run"]["completed"])
        self.assertEqual(records[-1]["available_actions"], [])

    def test_social_autoplay_cli_accepts_maho_actions_and_completes(self):
        process, records = self.run_cli("--autoplay-social", "--seed", "37", "--release", "interaction_006", "--max-turns", "200")
        self.assertEqual(process.returncode, 0, process.stderr)
        final = records[-1]
        self.assertEqual(final["run"]["reason"], "completed")
        self.assertEqual(final["run"]["turns"], 70)
        self.assertGreater(final["state"]["experience"]["hands"]["by_origin"]["maho"], 0)

    def test_batch_records_error_and_stops_before_later_commands(self):
        batch = self.directory / "invalid.jsonl"
        batch.write_text('{"command":"choose","id":"absent"}\n{"command":"quit"}\n', encoding="utf-8")
        log = self.directory / "failure.jsonl"
        process, records = self.run_cli("--batch", str(batch), "--seed", "37", "--log", str(log))
        self.assertNotEqual(process.returncode, 0)
        self.assertEqual(records[-1]["run"]["reason"], "error")
        self.assertEqual(records[-1]["run"]["turns"], 1)
        stored = [json.loads(line) for line in log.read_text(encoding="utf-8").splitlines()]
        self.assertEqual(stored[0]["config"]["seed"], 37)
        failed = [record for record in stored if record["type"] == "command"]
        self.assertEqual(len(failed), 1)
        self.assertEqual(json.loads(failed[0]["input"])["id"], "absent")
        self.assertFalse(failed[0]["response"]["ok"])

    def test_batch_exhaustion_has_explicit_end_reason(self):
        batch = self.directory / "short.jsonl"
        batch.write_text('{"command":"state"}\n', encoding="utf-8")
        process, records = self.run_cli("--batch", str(batch), "--seed", "37")
        self.assertEqual(records[-1]["run"]["reason"], "commands_exhausted")
        self.assertEqual(records[-1]["run"]["turns"], 1)
        self.assertFalse(records[-1]["run"]["completed"])

    def test_invalid_seed_is_a_structured_startup_error(self):
        process, records = self.run_cli("--seed", "not-an-integer")
        self.assertNotEqual(process.returncode, 0)
        self.assertFalse(records[-1]["ok"])
        self.assertIsInstance(records[-1]["error"]["code"], str)


if __name__ == "__main__":
    unittest.main()
