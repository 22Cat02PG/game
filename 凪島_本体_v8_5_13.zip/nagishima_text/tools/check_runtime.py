"""Reproduce the runtime gate using only the Python standard library."""
from pathlib import Path
import io
import platform
import sys
import time
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from nagishima.authoring import compile_text
from nagishima.codec import bytes_digest, read_json, write_json
from nagishima.content import Pack


def source_hashes():
    paths = []
    for directory in ("nagishima", "content", "tests", "tools", "authoring"):
        paths.extend(p for p in (ROOT / directory).rglob("*") if p.is_file() and p.suffix in (".py", ".json") and "__pycache__" not in p.parts)
    return {str(p.relative_to(ROOT)): bytes_digest(p.read_bytes()) for p in sorted(paths)}


def case_ids(suite):
    for value in suite:
        if isinstance(value, unittest.TestSuite): yield from case_ids(value)
        else: yield value.id()


def main():
    import os
    os.chdir(ROOT)
    pack = Pack(ROOT / "content/releases/base")
    example = read_json(ROOT / "authoring/example_bundle.json")
    compile_text(**example, source=pack)
    suite = unittest.defaultTestLoader.discover(str(ROOT / "tests"), top_level_dir=str(ROOT))
    identities = list(case_ids(suite))
    output = io.StringIO()
    started = time.perf_counter()
    result = unittest.TextTestRunner(stream=output, verbosity=2).run(suite)
    elapsed = time.perf_counter() - started
    target = ROOT / "verification"
    target.mkdir(exist_ok=True)
    (target / "test_results.txt").write_text(output.getvalue(), encoding="utf-8")
    write_json(target / "results.json", {
        "command": "python3 tools/check_runtime.py", "python": platform.python_version(),
        "platform": platform.platform(), "seconds": elapsed, "tests_run": result.testsRun,
        "failures": len(result.failures), "errors": len(result.errors), "skipped": len(result.skipped),
        "success": result.wasSuccessful(), "test_ids": identities,
        "release": pack.id, "release_sha256": pack.hash, "save_budget": pack.save_budget,
        "source_sha256": source_hashes(), "authoring_example_valid": True,
    })
    print(output.getvalue(), end="")
    print("verification/results.json と test_results.txt を更新した。")
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__": sys.exit(main())
