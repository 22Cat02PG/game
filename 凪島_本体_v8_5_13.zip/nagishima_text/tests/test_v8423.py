"""v8.4.23（ユーザー 2026-10-07 13:41「進めろ。次があるだろ」）：010 だけ。
本文の再会を減らす 九束目（体位を移ったあとの真帆の反応：並んで座る・向かい合って横になる・こちらが上）。"""
import re
import unittest
from pathlib import Path

from nagishima.content import Pack

ROOT = Path(__file__).resolve().parents[1]
P009 = Pack(ROOT / "content/releases/interaction_009")
P010 = Pack(ROOT / "content/releases/interaction_010")
NEW = [t for t in P010.texts if t["id"].startswith("cmp.h_pos_") and re.match(r"r[1-4]m", t["id"].rsplit(".", 1)[1])]
KISS_OFF = {"field": "contact.h_kiss_deep.active", "op": "eq", "value": False}


class V8423(unittest.TestCase):
    def test_009_unchanged(self):
        self.assertFalse(any(t["id"].startswith("cmp.") for t in P009.texts))

    def test_new_reactions(self):
        self.assertEqual({t["meaning"] for t in NEW}, {"h_pos_sitting_close.start", "h_pos_lying_face.start", "h_pos_player_above.start"})
        for text in NEW:
            a, b = text["id"].rsplit(".", 2)[1:]
            self.assertEqual(text["group"], f"cmp.{text['meaning']}.{a}")
            self.assertIn({"field": "flow.prev.urgent", "op": "eq", "value": False}, text["when"]["all"])
            self.assertIn({"field": "intimacy.maho.band", "op": "in", "value": ["low", "mid"]}, text["when"]["all"])
            if "「" in text["body"]:
                self.assertIn(KISS_OFF, text["when"]["all"], text["id"])  # 深く口づけているあいだは台詞を出さない

    def test_review_fixes(self):
        """読む係の指摘（v8423/read）：同じ語の二度書き・手をつないで移る前半とこちらの手を取る後半などをつながない、本文の直し。"""
        for text in NEW:
            a, b = text["id"].rsplit(".", 2)[1:]
            self.assertFalse(b in ("r4msbcalm03", "r1mpbcalm02"), text["id"])
            self.assertFalse(b == "r3mpbcalm02" and re.match(r"y\d(sc|lc|tc|pc)a", a), text["id"])
            self.assertNotIn("風、やんだね", text["body"])
            self.assertNotIn("もうひと声", text["body"])
            self.assertFalse(b in ("r1mpbcalm01", "r2mpbcalm03") and a == "y2tcaback01", text["id"])  # 両手を肩にかけた直後に手を使わない
            if b == "r2msbcalm04":
                self.assertIn({"not": {"field": "intimacy.position_from", "op": "in", "value": ["sitting_face", "maho_above"]}}, text["when"]["all"])
        for text in P010.texts:  # 前からある前半に足した条件（これまでの組み合わせた本文にも）
            if text["id"].startswith("cmp.h_pos_sitting_close.start.y1scaface01."):
                self.assertIn({"field": "intimacy.position_from", "op": "ne", "value": "maho_above"}, text["when"]["all"])
            if text["id"].startswith("cmp.h_pos_player_above.start.w7mpaback01."):
                self.assertIn({"field": "intimacy.position_from", "op": "ne", "value": "side_lying"}, text["when"]["all"])


if __name__ == "__main__":
    unittest.main()
