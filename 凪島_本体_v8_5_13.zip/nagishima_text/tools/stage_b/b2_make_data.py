"""段階Bの2版目（B2）：intimacy_009.json・actions_009追加.json・meanings_009追加.json に B2 の宣言を足す（Opus、2026-09-27）。

一度だけ使う変換。すでに足してあれば何もしない。以後は3つの JSON が正本。
"""
import json
from pathlib import Path

DATA = Path(__file__).resolve().parent


def read(name):
    return json.loads((DATA / name).read_text(encoding="utf-8"))


def dump(name, value):
    (DATA / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")


intimacy = read("intimacy_009.json")
if "b2" in intimacy:
    raise SystemExit("B2 の宣言はもう足してある。")
decls = read("actions_009追加.json")
meanings = read("meanings_009追加.json")

FACE_OLD = ["lying_face", "sitting_close", "player_above", "maho_above"]
FEW = ["from_behind", "sitting_face", "side_lying", "leg_up"]
FAMILIAR = ["prone_back", "standing_back", "reverse_ride", "legs_shoulder"]
BACK = ["from_behind", "side_lying", "prone_back", "standing_back", "reverse_ride"]
FACE_ALL = FACE_OLD + ["sitting_face", "leg_up", "legs_shoulder"]
ALL = FACE_ALL + BACK
INSERTABLE = ["player_above", "maho_above", "sitting_face", "leg_up", "legs_shoulder"] + BACK

# ---- 体位 ----
positions = intimacy["positions"]
for key, row in positions.items():
    row["facing"] = "face"
    row["linked"] = []
positions["player_above"]["linked"] = ["leg_up", "legs_shoulder"]
NEW_POS = {
    "from_behind": ("後ろから", "四つん這いの真帆に、後ろから腰を寄せている。", "seated", "reclined", "few", "back", []),
    "sitting_face": ("向かい合って膝に", "座ったこちらの膝に、真帆が向かい合ってまたがっている。", "seated", "seated", "few", "face", []),
    "side_lying": ("横向きで後ろから", "二人とも横向きに寝て、真帆の背中に寄り添っている。", "reclined", "reclined", "few", "back", []),
    "leg_up": ("片脚を抱えて", "仰向けの真帆に重なり、真帆の片脚を抱え上げている。", "reclined", "reclined", "few", "face", ["player_above", "legs_shoulder"]),
    "prone_back": ("うつ伏せに後ろから", "うつ伏せの真帆に、後ろから重なっている。", "reclined", "reclined", "familiar", "back", []),
    "standing_back": ("立って後ろから", "壁に手をついて立つ真帆に、後ろから寄り添っている。", "standing", "standing", "familiar", "back", []),
    "reverse_ride": ("背を向けて乗る", "仰向けのこちらに、真帆が背を向けてまたがっている。", "reclined", "seated", "familiar", "back", []),
    "legs_shoulder": ("両脚を肩に", "仰向けの真帆の両脚を肩にかけ、上から重なっている。", "reclined", "reclined", "familiar", "face", ["player_above", "leg_up"]),
}
for key, (label, presence, player, maho, tier, facing, linked) in NEW_POS.items():
    positions[key] = {"label": label, "presence": presence, "postures": {"player": player, "maho": maho}, "insertion": True,
                      "tier_from": tier, "facing": facing, "linked": linked}

# ---- 既存の行動の体位 ----
actions = intimacy["actions"]
for key in ("h_pos_lying_face", "h_pos_sitting_close", "h_pos_maho_above", "h_pos_player_above"):
    target = actions[key]["sets"]["position"]
    actions[key]["positions"] = [p for p in ALL if p != target]
actions["h_pos_player_above"]["needs"]["inserted"] = None  # 入れたまま移れるのは linked から（片脚・両脚から戻す）
actions["h_kiss_deep"]["positions"] = FACE_OLD + ["sitting_face", "leg_up"]
actions["h_chest_over"]["positions"] = list(ALL)
actions["h_chest_skin"]["positions"] = list(ALL)
actions["h_lift_upper"]["positions"] = ["lying_face", "sitting_close", "player_above", "sitting_face"]
for key in ("h_insert", "h_withdraw", "h_move_slow", "h_move_normal", "h_move_fast", "h_finish_inside", "h_finish_outside", "h_endure"):
    actions[key]["positions"] = list(INSERTABLE)
for key in ("h_after_hold", "h_check", "h_feel"):
    actions[key]["positions"] = list(ALL)


def needs(tier="first", **extra):
    row = {"maho_clothing": {}, "player_clothing": {}, "inserted": None, "maho_ready": None, "maho_band": None, "player_ready": False,
           "player_arousal": None, "after": False, "tier_from": tier}
    row.update(extra)
    return row


def sets(**extra):
    row = {"position": None, "maho_clothing": {}, "player_clothing": {}, "inserted": None}
    row.update(extra)
    return row


def effects(maho, cap, satisfaction, player, per=2):
    return {"maho_arousal": maho, "maho_arousal_cap": cap, "satisfaction": satisfaction, "satisfaction_per_session": per, "player_arousal": player}


def action(label, category, positions_, needs_, effects_, sets_=None, *, minutes=3, pace="none", heart=False, ongoing=False, entry=False,
           continue_label=None, end_label=None):
    row = {"label": label, "category": category, "origin": "player", "ongoing": ongoing, "entry": entry, "offer_only": False, "minutes": minutes,
           "pace": pace, "heart": heart, "positions": positions_, "needs": needs_, "effects": effects_, "sets": sets_ or sets()}
    if ongoing:
        row["continue_label"], row["end_label"] = continue_label, end_label
    return row


POS_LABELS = {"from_behind": "後ろからにする", "sitting_face": "向かい合って膝に乗ってもらう", "side_lying": "横向きで後ろから寄り添う",
              "leg_up": "片脚を抱え上げる", "prone_back": "うつ伏せになってもらう", "standing_back": "立って壁に手をついてもらう",
              "reverse_ride": "背を向けて乗ってもらう", "legs_shoulder": "両脚を肩にかける"}
new = {}
for key, label in POS_LABELS.items():
    linked = positions[key]["linked"]
    new["h_pos_" + key] = action(label, "position", linked if linked else [p for p in ALL if p != key],
                                 needs(positions[key]["tier_from"], inserted=None if linked else False), effects(2, 60, 0, 2), sets(position=key), minutes=2)
MAHO_LOWER_OPEN = {"lower": ["aside", "off"]}
new["h_ear_neck"] = action("耳元や首筋に口づける", "kiss", list(ALL), needs(), effects(7, 60, 3, 3), minutes=3, pace="slow", ongoing=True, entry=True,
                           continue_label="耳元や首筋に口づけ続ける", end_label="唇を離す")
new["h_chest_mouth"] = action("胸に口づける", "caress", FACE_OLD + ["sitting_face", "leg_up"], needs(maho_clothing={"upper": ["raised", "off"]}),
                              effects(11, 88, 3, 5), minutes=3, pace="slow", ongoing=True, continue_label="胸に口づけ続ける", end_label="胸から唇を離す")
new["h_touch_under"] = action("下着の上から秘所に触れる", "caress", ["lying_face", "sitting_close", "player_above"],
                              needs(maho_clothing={"lower": ["underwear"]}, inserted=False), effects(9, 85, 2, 4), minutes=3, pace="slow", ongoing=True,
                              continue_label="下着の上から触れ続ける", end_label="下着から手を離す")
new["h_finger_in"] = action("指を中に入れる", "caress", ["lying_face", "player_above", "maho_above"],
                            needs("few", maho_clothing=MAHO_LOWER_OPEN, inserted=False, maho_ready="mid"), effects(13, 100, 3, 6), minutes=4, pace="normal",
                            ongoing=True, continue_label="中で指を動かし続ける", end_label="指を抜く")
new["h_player_mouth"] = action("口で愛撫する", "caress", ["lying_face", "player_above"],
                               needs("few", maho_clothing=MAHO_LOWER_OPEN, inserted=False, maho_band="mid"), effects(15, 100, 4, 4), minutes=4, pace="normal",
                               heart=True, ongoing=True, continue_label="口での愛撫を続ける", end_label="顔を上げる")
new["h_strip_upper"] = action("上を脱がせる", "undress", ["lying_face", "sitting_close", "player_above", "maho_above", "sitting_face"],
                              needs(maho_clothing={"upper": ["worn", "raised"]}), effects(4, 60, 0, 4), sets(maho_clothing={"upper": "off"}), minutes=2)
new["h_strip_under"] = action("下着を脱がせる", "undress", ["lying_face", "sitting_close", "player_above"],
                              needs(maho_clothing={"lower": ["underwear", "aside"]}, inserted=False), effects(6, 70, 0, 6), sets(maho_clothing={"lower": "off"}), minutes=2)
new["h_strip_self_upper"] = action("自分の上を脱ぐ", "undress", list(FACE_ALL), needs(player_clothing={"upper": ["worn"]}), effects(2, 60, 0, 2),
                                   sets(player_clothing={"upper": "off"}), minutes=2)
SERVICE_POS = ["lying_face", "sitting_close", "maho_above"]
MOUTH_POS = ["lying_face", "sitting_close"]
PLAYER_OPEN = {"lower": ["off"]}
new["h_maho_hand"] = action("手でしてもらう", "service", SERVICE_POS, needs(player_clothing=PLAYER_OPEN, inserted=False, player_ready=True),
                            effects(3, 60, 3, 12), minutes=3, ongoing=True, continue_label="手で続けてもらう", end_label="手を止めてもらう")
new["h_maho_mouth"] = action("口でしてもらう", "service", MOUTH_POS, needs("few", player_clothing=PLAYER_OPEN, inserted=False, player_ready=True),
                             effects(4, 65, 3, 16), minutes=3, ongoing=True, continue_label="口で続けてもらう", end_label="口を離してもらう")
new["h_finish_hand"] = action("手の中で出す", "service", SERVICE_POS,
                              needs(player_clothing=PLAYER_OPEN, inserted=False, player_ready=True, player_arousal="finish"), effects(0, 100, 5, 0),
                              minutes=2, heart=True)
new["h_finish_mouth"] = action("口の中で出す", "service", MOUTH_POS,
                               needs("few", player_clothing=PLAYER_OPEN, inserted=False, player_ready=True, player_arousal="finish"), effects(0, 100, 5, 0),
                               minutes=2, heart=True)
new["h_self"] = action("自分で高める", "self", ["lying_face", "sitting_close"], needs(player_clothing=PLAYER_OPEN, inserted=False, player_ready=True),
                       effects(4, 55, 1, 10), minutes=3, ongoing=True, continue_label="自分で続ける", end_label="手を止める")
actions.update(new)
intimacy["deflect"]["hand"].append("h_finger_in")
intimacy["settings"]["default"]["gauges"] = "shown"
intimacy["b2"] = {
    "_note": "段階Bの2版目（2026-09-27）。sleep_after：この時刻から until までに終えたら、そのまま一緒に眠って翌朝へ。self_cap：自分で高めるだけで上がる主人公の高まりの上限（出すには真帆の手・口か、つながる）。help_offer：自分で高めているとき、真帆が手・口を申し出る確率と条件。quiet_sign_categories：真帆の高まりの合図（h.sign）を出さず、達しない分類。overflow：限界のまま続けると代わりにする出す行動。gate：いつもの触れ合いから深める。",
    "sleep_after": {"from": "19:00", "until": "05:00"},
    "self_cap": 90,
    "help_offer": {"chance_percent": 50, "min_player_arousal": 20, "mouth_tier_from": "few"},
    "quiet_sign_categories": ["service", "self"],
    "overflow": {"h_move_slow": "h_finish_inside", "h_move_normal": "h_finish_inside", "h_move_fast": "h_finish_inside",
                 "h_maho_hand": "h_finish_hand", "h_maho_mouth": "h_finish_mouth"},
    "gate": {
        "touches": {
            "deep_kiss": {"h_action": "h_kiss_deep", "strong": False},
            "ear_kiss": {"h_action": "h_ear_neck", "strong": False},
            "chest_touch": {"h_action": "h_chest_over", "strong": True},
            "thigh_touch": {"h_action": "h_thigh", "strong": True},
            "under_clothes": {"h_action": None, "strong": True},
            "push_down": {"h_action": None, "strong": True},
        },
        "hints": {
            "deep_kiss": "恋人としてキスを3回重ねると選べる。",
            "ear_kiss": "恋人としてキスを3回重ねると選べる。",
            "chest_touch": "いつもの時間に一度深くキスするか、エッチを一度してから。家の中で選べる。",
            "thigh_touch": "いつもの時間に一度深くキスするか、エッチを一度してから。家の中で選べる。",
            "under_clothes": "いつもの時間に一度深くキスするか、エッチを一度してから。家の中で選べる。",
            "push_down": "服の上から胸か太ももに一度触れてから。居間か部屋で選べる。",
        },
        "public_rooms": ["living_room", "kitchen"],
        "work_margin_minutes": 30,
    },
}
dump("intimacy_009.json", intimacy)

# ---- actions.json の宣言（エッチの行動） ----
by_id = {row["id"]: row for row in decls}
TOGETHER = {"field": "together", "op": "eq", "value": True}
POSTURES = ["standing", "seated", "reclined"]


def decl(identity, label, ongoing, resources, replaces, when=None, near=True, min_stage=3, keep=False):
    return {"id": identity, "label": label, "ongoing": ongoing, "min_stage": min_stage, "near": near, "resources": resources, "replaces": replaces,
            "keep_on_joint_move": keep, "when": when or TOGETHER, "maintain": TOGETHER, "postures": list(POSTURES)}


HAND_CARESS = ["h_chest_over", "h_chest_skin", "h_thigh", "h_touch_direct", "h_touch_under", "h_finger_in"]
MOVES = ["h_move_slow", "h_move_normal", "h_move_fast"]
for key, label in POS_LABELS.items():
    decls.append(decl("h_pos_" + key, label, False, ["player.posture", "maho.posture"], []))
decls.append(decl("h_ear_neck", "耳元や首筋に口づける", True, ["player.speech", "maho.head_contact"], ["h_kiss_deep", "h_chest_mouth", "h_player_mouth"]))
decls.append(decl("h_chest_mouth", "胸に口づける", True, ["player.speech", "maho.chest"], ["h_kiss_deep", "h_ear_neck", "h_chest_over", "h_chest_skin", "h_player_mouth"]))
decls.append(decl("h_touch_under", "下着の上から秘所に触れる", True, ["player.right_hand", "maho.lower"], [k for k in HAND_CARESS if k != "h_touch_under"] + ["h_player_mouth"]))
decls.append(decl("h_finger_in", "指を中に入れる", True, ["player.right_hand", "maho.lower"], [k for k in HAND_CARESS if k != "h_finger_in"] + ["h_player_mouth"]))
decls.append(decl("h_player_mouth", "口で愛撫する", True, ["player.speech", "maho.lower"], ["h_kiss_deep", "h_ear_neck", "h_chest_mouth", "h_touch_direct", "h_touch_under", "h_finger_in", "h_thigh"]))
for key, label in (("h_strip_upper", "上を脱がせる"), ("h_strip_under", "下着を脱がせる"), ("h_strip_self_upper", "自分の上を脱ぐ")):
    decls.append(decl(key, label, False, ["player.right_hand"], list(HAND_CARESS)))
SELF_SERVICE = ["h_maho_hand", "h_maho_mouth", "h_self"]
decls.append(decl("h_maho_hand", "手でしてもらう", True, ["maho.right_hand", "player.hips"], [k for k in SELF_SERVICE if k != "h_maho_hand"]))
decls.append(decl("h_maho_mouth", "口でしてもらう", True, ["maho.speech", "player.hips"], [k for k in SELF_SERVICE if k != "h_maho_mouth"] + ["h_kiss_deep"]))
decls.append(decl("h_finish_hand", "手の中で出す", False, ["player.hips"], list(SELF_SERVICE)))
decls.append(decl("h_finish_mouth", "口の中で出す", False, ["player.hips"], list(SELF_SERVICE)))
decls.append(decl("h_self", "自分で高める", True, ["player.right_hand", "player.hips"], list(HAND_CARESS) + ["h_maho_hand", "h_maho_mouth"]))
# 既存の宣言：新しい行動と入れ替えられるようにする
by_id = {row["id"]: row for row in decls}
by_id["h_kiss_deep"]["replaces"] = ["h_ear_neck", "h_chest_mouth"]
for key in ("h_chest_over", "h_chest_skin", "h_thigh", "h_touch_direct"):
    by_id[key]["replaces"] = sorted(set(by_id[key]["replaces"]) | {"h_touch_under", "h_finger_in", "h_self"} - {key})
for key in ("h_lift_upper", "h_strip_lower", "h_shift_under", "h_strip_self", "h_after_hold"):
    by_id[key]["replaces"] = sorted(set(by_id[key]["replaces"]) | {"h_touch_under", "h_finger_in", "h_self"})
for key in ("h_insert", "h_lead_takein"):
    by_id[key]["replaces"] = sorted(set(by_id[key]["replaces"]) | {"h_touch_under", "h_finger_in", "h_player_mouth", "h_maho_hand", "h_maho_mouth", "h_self"})
for key in ("h_check", "h_feel"):
    by_id[key]["replaces"] = sorted(set(by_id[key]["replaces"]) | {"h_ear_neck", "h_chest_mouth"})

# ---- いつもの触れ合い（生活の行動） ----
RESIDENCE = ["living_room", "kitchen", "player_room", "maho_room"]
def at(places):
    return {"field": "actor.player.location", "op": "in", "value": places}
KISSED = {"field": "experience.kiss.count", "op": "ge", "value": 3}
DEEPENED = {"any": [{"field": "experience.deep_kiss.count", "op": "ge", "value": 1}, {"field": "intimacy.history_count", "op": "ge", "value": 1}]}
TOUCHED = {"any": [{"field": "experience.chest_touch.count", "op": "ge", "value": 1}, {"field": "experience.thigh_touch.count", "op": "ge", "value": 1}]}
decls.append(decl("deep_kiss", "深くキスする", True, ["player.speech", "maho.speech"], ["cheek_kiss", "ear_kiss"], {"all": [TOGETHER, KISSED]}))
decls.append(decl("ear_kiss", "耳元や首筋に口づける", True, ["player.speech", "maho.head_contact"], ["deep_kiss", "cheek_kiss"], {"all": [TOGETHER, KISSED]}))
decls.append(decl("chest_touch", "服の上から胸に触れる", True, ["player.right_hand", "maho.chest"], ["head", "hair", "cheek", "shoulder", "arm", "back", "thigh_touch", "under_clothes"],
                  {"all": [TOGETHER, DEEPENED, at(RESIDENCE)]}))
decls.append(decl("thigh_touch", "太ももを撫でる", True, ["player.right_hand", "maho.lower"], ["head", "hair", "cheek", "shoulder", "arm", "back", "chest_touch", "under_clothes"],
                  {"all": [TOGETHER, DEEPENED, at(RESIDENCE)]}))
decls.append(decl("under_clothes", "服の中に手を入れる", True, ["player.right_hand", "maho.body_contact"], ["head", "hair", "cheek", "shoulder", "arm", "back", "chest_touch", "thigh_touch"],
                  {"all": [TOGETHER, DEEPENED, at(RESIDENCE)]}))
decls.append(decl("push_down", "押し倒す", False, ["player.posture", "maho.posture"], [], {"all": [TOGETHER, TOUCHED, at(["living_room", "player_room", "maho_room"])]}))
decls.append(decl("back_hug", "後ろから抱きしめる", True, ["player.left_hand", "player.right_hand", "maho.body_contact"], ["head", "hair", "hands", "back", "waist"]))
decls.append(decl("lap_pillow", "膝枕をしてあげる", True, ["player.posture", "maho.posture", "maho.head_contact"], ["head", "hair"]))
decls.append(decl("lap_pillow_take", "膝枕をしてもらう", True, ["player.posture", "maho.posture", "player.left_hand"], []))
decls.append(decl("finger_lace", "指を絡める", True, ["player.left_hand", "maho.right_hand"], ["hands"], keep=True))
decls.append(decl("cheek_kiss", "頬にキスする", False, ["player.speech", "maho.face_contact"], []))
dump("actions_009追加.json", decls)

# ---- meanings ----
added = []
for key, row in new.items():
    phases = ["first", "start", "continue", "settled"] if row["ongoing"] else ["first", "start"]
    added += [key + "." + phase for phase in phases]
for key in ("deep_kiss", "ear_kiss", "chest_touch", "thigh_touch", "under_clothes", "back_hug", "lap_pillow", "lap_pillow_take", "finger_lace"):
    added += [key + "." + phase for phase in ("first", "start", "continue", "settled")]
for key in ("push_down", "cheek_kiss"):
    added += [key + "." + phase for phase in ("first", "start")]
added += ["h_overflow.inside", "h_overflow.hand", "h_overflow.mouth", "h.self.react.look_away", "h.self.react.watch", "offer.h_help.hand", "offer.h_help.mouth",
          "offer.h_help.declined", "h.sleep_together.satisfied", "h.sleep_together.unsatisfied", "h.morning_together.satisfied", "h.morning_together.unsatisfied",
          "gate.react.invite", "gate.react.allow", "gate.react.deflect_place", "gate.react.deflect_time", "offer.gate.declined"]
assert not set(added) & set(meanings), set(added) & set(meanings)
dump("meanings_009追加.json", meanings + added)
print(len(actions), len(decls), len(meanings + added))
