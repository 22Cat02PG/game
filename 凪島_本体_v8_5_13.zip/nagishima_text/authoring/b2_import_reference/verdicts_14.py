"""第14陣（新規 テキスト ドキュメント (142)〜(144).txt、p14 30 job、150本、深い口づけを続けたまま）の判定（2026-09-30）。Opus の読み手3人（review14/）。
使い方：python3 verdicts_14.py --dry／python3 verdicts_14.py"""
import collections, glob, json, os, sys
pool = json.load(open("pool_14.json", encoding="utf-8"))
rows = [r for rs in pool.values() for r in rs]
R = {}
for path in sorted(glob.glob("review14/*_判定.json")):
    items = json.load(open(path, encoding="utf-8"))
    names = [v["id"] for v in items]
    assert len(names) == len(set(names)), path
    for v in items:
        assert v["id"] not in R, v["id"]
        assert v["verdict"] in ("ok", "fix", "reject"), v
        R[v["id"]] = (v["verdict"], v.get("reason", ""), [tuple(c) for c in v.get("changes") or []])
assert set(R) == {r["id"] for r in rows}, (len(R), len(rows), list(set(r["id"] for r in rows) - set(R))[:5])
OVERRIDE = json.load(open("review14/override.json", encoding="utf-8")) if os.path.exists("review14/override.json") else {}
DROP = json.load(open("review14/drop.json", encoding="utf-8")) if os.path.exists("review14/drop.json") else {}
for i, (reason, changes) in OVERRIDE.items():
    verdict, old_reason, old_changes = R[i]
    assert verdict != "reject", i
    R[i] = ("fix", (old_reason + "；" if old_reason else "") + reason, old_changes + [tuple(c) for c in changes])
for i, reason in DROP.items():
    verdict, old_reason, _ = R[i]
    assert verdict != "reject", i
    R[i] = ("reject", (old_reason + "；" if old_reason else "") + "取りまとめ：" + reason, [])
final = {}
for r in rows:
    verdict, reason, changes = R[r["id"]]
    if verdict == "reject":
        continue
    body = r["body"]
    for old, new in changes:
        assert body.count(old) == 1, (r["id"], old)
        body = body.replace(old, new)
    final[r["id"]] = {"job_id": r["job_id"], "body": body, "verdict": verdict}
json.dump(final, open("review14/final_bodies.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
count = collections.Counter(v[0] for v in R.values())
per_job = collections.Counter(v["job_id"] for v in final.values())
print(count, "kept", len(final), "jobs<3 (this batch only):", len([j for j in pool if per_job[j] < 3]), "jobs0:", [j for j in pool if per_job[j] == 0])
if "--dry" in sys.argv:
    sys.exit()
rec = json.load(open("b2_判定.json", encoding="utf-8"))
known = {e["id"] for e in rec}
for r in rows:
    assert r["id"] not in known, r["id"]
    verdict, reason, changes = R[r["id"]]
    e = {"id": r["id"], "job_id": r["job_id"], "file": r["file"], "verdict": verdict, "reason": ("Opus：" + reason) if reason else "", "orig": r["body"]}
    if verdict == "fix":
        e["body"] = final[r["id"]]["body"]
    rec.append(e)
json.dump(rec, open("b2_判定.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("appended", len(rows))
