"""v8.2.37（ユーザー 2026-10-01 22:43「進めて」）：同じ本文を避ける記録（recent_text）を 009 だけ 256本に伸ばし、
候補がどれも記録に入っているときは、いちばん前に出た本文から選ぶ（出た回数より先に見る）。006〜008 は 64本のまま、選び方も変えない。
あわせて v8.2.36（確かめ役の本文の足し 115本、k1）の取り込みと、その直し。"""
import json
import unittest
from pathlib import Path

from nagishima.conditions import evaluate
from nagishima.content import Pack
from nagishima.state import SCHEMA, validate_state
from tools.run_stage_b_routes import Route

ROOT = Path(__file__).resolve().parents[1]
PACK = Pack(ROOT / "content/releases/interaction_009")


def item(text):
    return {"id": text["id"], "group": text["group"], "release": "interaction_009"}


class V8237(unittest.TestCase):
    def route(self, seed, tier="familiar", **kw):
        route = Route(seed, tier=tier, **({"day_offset": 3, "hour": 13} | kw))
        self.addCleanup(route.close)
        return route

    # ---- 記録の長さ：009 は 256、ほかの版は 64。保存の検査も 256 まで ----
    def test_window(self):
        self.assertEqual(PACK.recent_window, 256)
        for release in ("interaction_006", "interaction_007", "interaction_008"):
            self.assertEqual(Pack(ROOT / "content/releases" / release).recent_window, 64, release)
        self.assertEqual(SCHEMA["properties"]["recent_text"]["maxItems"], 256)

    def setup_after_hold(self, seed):
        route = self.route(seed)
        route.begin()
        state = route.engine.snapshot()
        state["intimacy"]["after"] = True
        values = PACK.registry.values(state)
        texts = [t for t in PACK.by_meaning["h_after_hold.again"] if not t["fallback"] and evaluate(t["when"], values) is True and not t["slots"]]
        self.assertGreaterEqual(len(texts), 10)
        filler = [t for t in PACK.by_meaning["h_kiss_deep.start"] if not t["fallback"]][:4]  # 直近4本の group を外す
        return state, values, texts, filler

    # ---- 候補がどれも記録に入っているときは、いちばん前に出た本文（出た回数が多くても） ----
    def test_oldest_first(self):
        state, values, texts, filler = self.setup_after_hold(9001)
        oldest = texts[0]
        state["recent_text"] = [item(oldest), item(oldest)] + [item(t) for t in texts[1:]] + [item(t) for t in filler]
        block, _ = PACK.select("h_after_hold.again", state, {}, values)
        self.assertEqual(block["variant"], oldest["id"])  # 出た回数（2回）より、前に出たほうを先に見る
        # まだ出ていない本文があれば、そちらが先
        state["recent_text"] = [item(t) for t in texts[1:]] + [item(t) for t in filler]
        block, _ = PACK.select("h_after_hold.again", state, {}, values)
        self.assertEqual(block["variant"], oldest["id"])

    # ---- 65本以上前に出た本文も、記録に入っていれば後回しにする（v8.2.36 までは候補に戻っていた） ----
    def test_beyond_64(self):
        state, values, texts, filler = self.setup_after_hold(9002)
        seen = texts[:-1]
        others = [t for t in PACK.texts if not t["meaning"].startswith(("h_", "h.")) and not t["fallback"]][:120]
        state["recent_text"] = [item(t) for t in seen] + [item(t) for t in others] + [item(t) for t in filler]
        self.assertGreater(len(state["recent_text"]), 64)
        block, _ = PACK.select("h_after_hold.again", state, {}, values)
        self.assertEqual(block["variant"], texts[-1]["id"])
        self.assertLessEqual(len(state["recent_text"]), 256)

    # ---- 記録は 256本まで、保存の検査を通る。257本は通らない ----
    def test_record_validates(self):
        route = self.route(9003)
        route.begin()
        pool = [t for t in PACK.texts if not t["meaning"].startswith(("h_", "h.")) and not t["fallback"]]
        state = route.engine.snapshot()
        state["recent_text"] = [item(t) for t in pool[:256]]
        validate_state(state, route.engine.pack, route.engine.repository)
        state["recent_text"].append(item(pool[256]))
        with self.assertRaises(Exception):
            validate_state(state, route.engine.pack, route.engine.repository)

    # ---- v8.2.36：確かめ役の本文の足し（k1）と、取り込みの直し ----
    def test_k1_texts(self):
        data = json.loads((ROOT / "tools/stage_b/texts_k1_v8236.json").read_text(encoding="utf-8"))
        self.assertEqual(len(data["texts"]), 115)
        fixed = {"k1.h.player.recovered.familiar.n.v2", "k1.h.sign.sensitive.familiar.face.outside.n.v1"}
        for row in data["texts"]:
            if row["id"] not in fixed:
                self.assertEqual(PACK.by_text[row["id"]]["body"], row["body"], row["id"])
        self.assertNotIn("休んでいるうちに", PACK.by_text["k1.h.player.recovered.familiar.n.v2"]["body"])
        self.assertNotIn("指先", PACK.by_text["k1.h.sign.sensitive.familiar.face.outside.n.v1"]["body"])
        self.assertEqual(PACK.by_text["k1.h.sign.sensitive.familiar.face.outside.n.v1"]["body"].count("軽く"), 1)  # 確かめ役 v8.2.37（軽 1）：「軽く」が2回にならない
        self.assertIn('"world.slot"', json.dumps(PACK.by_text["k1.private.began.familiar.s.v3"]["when"]))
        self.assertIn('"intimacy.facing", "op": "ne", "value": "back"', json.dumps(PACK.by_text["b3.h.sign.mid.familiar.n.v1"]["when"]))
        provenance = json.loads((ROOT / "content/releases/interaction_009/rules_provenance.json").read_text(encoding="utf-8"))
        text = json.dumps(provenance, ensure_ascii=False)
        self.assertIn("k1_texts_v8236", text)


if __name__ == "__main__":
    unittest.main()
