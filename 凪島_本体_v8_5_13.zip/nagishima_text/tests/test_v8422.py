"""v8.4.22（ユーザー 2026-10-07 13:41「進めろ。次があるだろ」）：010 だけ。
本文の再会を減らす 八束目（もっとせがむ合図の前半：こちらが胸・首すじに口をつけているとき）。"""
import json
import unittest
from pathlib import Path

from nagishima.conditions import evaluate
from nagishima.content import Pack

ROOT = Path(__file__).resolve().parents[1]
P009 = Pack(ROOT / "content/releases/interaction_009")
P010 = Pack(ROOT / "content/releases/interaction_010")
NEW = [t for t in P010.texts if t["id"].startswith("cmp.h.sign.wants_more.t")]


class V8422(unittest.TestCase):
    def test_009_unchanged(self):
        self.assertFalse(any(t["id"].startswith("cmp.") for t in P009.texts))

    def test_new_fronts(self):
        self.assertGreater(len(NEW), 500)
        flow = P010.intimacy.flow
        for text in NEW:
            a = text["id"].rsplit(".", 2)[1]
            self.assertEqual(text["group"], f"cmp.h.sign.wants_more.{a}")
            self.assertIn("begging", flow.info(text)[3], text["id"])
            self.assertIn({"field": "intimacy.inserted", "op": "eq", "value": False}, text["when"]["all"])
            busy = "contact.h_chest_mouth.active" if "achest" in a else "contact.h_ear_neck.active"
            self.assertIn({"field": busy, "op": "eq", "value": True}, text["when"]["all"], text["id"])
            if "achest" in a:  # こちらの顔が胸にあるとき、真帆がこちらの首すじへ顔をうずめる・耳へ唇を運ぶ後半はつながない
                self.assertNotIn(text["id"].rsplit(".", 1)[1], ("w7wmbhot03", "z4wmbhot01"))

    def test_mouth_busy_has_composed(self):
        """こちらが胸に口をつけている（向かい合う・何度か・入れていない・高まり high）ときに、組み合わせた本文が出せる。"""
        rows = [t for t in P010.by_meaning["h.sign.wants_more"] if t["id"].startswith("cmp.")]
        fields = {c["field"] for t in rows for c in t["when"]["all"] if "field" in c}
        values = {f: False for f in fields if f.startswith(("contact.", "flow.prev."))}
        values.update({"contact.h_chest_mouth.active": True, "contact.h_chest_skin.active": True, "intimacy.facing": "face", "intimacy.tier": "few",
                       "intimacy.inserted": False, "intimacy.maho.band": "high", "intimacy.position": "lying_face", "intimacy.position_from": None,
                       "actor.maho.clothing.upper": "off", "intimacy.maho.climaxes": 0, "intimacy.maho.afterglow": False})
        ok = [t for t in rows if evaluate(t["when"], values) is True]
        self.assertTrue(ok)
        self.assertTrue(all(".t" in t["id"] for t in ok), json.dumps([t["id"] for t in ok[:3]]))

    def test_review_fixes(self):
        """読む係の指摘（v8422/read）：真帆が上では出さない前半、つながない組。"""
        not_above = {"field": "intimacy.position", "op": "ne", "value": "maho_above"}
        for text in NEW:
            a, b = text["id"].rsplit(".", 2)[1:]
            if a in ("t4wmachest03", "t2wmachest02", "t1wmaneck02", "t2wmaneck01"):
                self.assertIn(not_above, text["when"]["all"], text["id"])
            self.assertNotIn((a, b), {("t2wmaneck01", "w6wmbhot03"), ("t2wmaneck01", "v1wmbhot03"), ("t2wmaneck01", "w7wmbmid02"),
                                      ("t2wmachest01", "v1wmbhot01"), ("t2wmachest01", "w6wmbmid02"), ("t4wmachest01", "u3wmbmid01"),
                                      ("t3wmaneck02", "z4wmbhot01")})


if __name__ == "__main__":
    unittest.main()
