"""v8.2.15：grok 第11陣（真帆に動いてもらう・頭をなでる・撫で返し・いつもの時間の頭なで）・第12陣（速さ）と、第9・10陣の補充の取り込み。
本文の中身は tools/check_stage_b_texts.py と遊び回りで確かめる。ここでは、取り込んだ本文が組み立てた本文に入り、依頼で決めた出る条件を持っていることを確かめる。"""
import unittest

from tools.run_stage_b_routes import Route

KISS_OFF = {"field": "contact.h_kiss_deep.active", "op": "eq", "value": False}


def conditions(text):
    when = text["when"]
    return when["all"] if set(when) == {"all"} else [when]


class V8215(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        route = Route(1501, tier="familiar", day_offset=2)
        cls.pack = route.engine.pack
        route.close()

    def grok(self, meaning, prefix):
        return [t for t in self.pack.by_meaning.get(meaning, []) if t["id"].startswith(prefix)]

    def test_new_waves_are_in_the_pack(self):
        for meaning in ("h_maho_move.start", "h_overflow.maho_move", "h_stroke_head.mouth", "h_stroke_head.again", "h.stroke_back.after", "head.start"):
            self.assertTrue(self.grok(meaning, "p11."), meaning)
        for meaning in ("h_maho_hand.pace_fast", "h_maho_mouth_slow.continue", "h_sixty_nine_fast.continue", "h_maho_move_slow.continue"):
            self.assertTrue(self.grok(meaning, "p12."), meaning)
        self.assertTrue(self.grok("h.deadline.sixty_nine", "p10."))  # 補充で埋まった job（第10陣が必須の陣に）

    def test_speaking_texts_wait_for_the_kiss_to_end(self):
        # 口づけは指・素股・真帆に動いてもらうでは途切れない。台詞のある grok の本文は口づけしていないときだけ（依頼の点検 G-5）
        for meaning in ("h_touch_direct.pace_fast", "h_sumata_slow.continue", "h_maho_move.start", "h_maho_move_fast.continue"):
            spoken = [t for t in self.grok(meaning, ("p11.", "p12.")) if "「" in t["body"]]
            self.assertTrue(spoken, meaning)
            for text in spoken:
                self.assertIn(KISS_OFF, conditions(text), text["id"])

    def test_back_ride_texts_follow_lewdness(self):
        # 背を向けて乗って動いてもらう本文は、淫乱度の段で照れと大胆に分ける（依頼の点検 G-9）
        back = [t for t in self.grok("h_maho_move.start", "p11.") if ".back." in t["id"]]
        self.assertTrue(back)
        for text in back:
            fields = [c.get("field") for c in conditions(text)]
            self.assertIn("intimacy.lewd_band", fields, text["id"])
            self.assertIn({"field": "intimacy.facing", "op": "eq", "value": "back"}, conditions(text))


if __name__ == "__main__":
    unittest.main()
