"""段階Bの2版目（B2、2026-09-27）の試験。公開の選択肢から確かめる（時刻・欲求などの準備だけ内部で行う）。"""
import json
import re
import tempfile
import unittest
from pathlib import Path

from tools.run_stage_b_routes import Route, DAYTIME
from tools.build_intimacy_release import OWN_FACING_SKIP

ROOT = Path(__file__).resolve().parents[1]
FACE_CUES = ("目が合", "見上げ", "見下ろ", "首に腕", "首に回", "胸に顔", "見つめ", "覗き", "のぞき込", "額", "唇を重", "口づけ", "向かい合",
             "背中に回", "抱きつ", "しがみつ", "顔を埋", "瞳", "目を合わせ", "こちらを見", "頬に触", "頬を寄せ", "胸元に顔", "胸に額")


def choices(route):
    return {c["id"]: c for c in route.engine.get_view()["choices"]}


def meanings(route):
    return [b["meaning"] for b in route.engine.get_view()["blocks"]]


def undress(route):
    for key in ("h_strip_lower", "h_shift_under", "h_strip_self"):
        route.action(key)


def aroused(route, level=40):
    for _ in range(40):
        if route.engine.snapshot()["intimacy"]["maho"]["arousal"] >= level:
            return
        route.action("h_kiss_deep")
    raise AssertionError(route.status())


def decline_offers(route):
    while route.engine.snapshot()["offer"]:
        route.choose("offer.decline")


class B2Tests(unittest.TestCase):
    def route(self, *args, **kwargs):
        route = Route(*args, **kwargs)
        self.addCleanup(route.close)
        return route

    def test_gauges_are_shown_by_default_as_bars(self):
        route = self.route(42)
        self.assertEqual(route.engine.snapshot()["settings"]["gauges"], "shown")
        route.begin()
        status = route.engine.get_view()["status"]["intimacy"]
        for key in ("maho_arousal_bar", "maho_satisfaction_bar"):
            self.assertRegex(status[key], r"^[■□]{5}$")

    def test_private_touch_page_lists_entry_actions_and_entry_page_is_gone(self):
        route = self.route(42)
        route.choose("private.begin")
        self.assertNotIn("menu.h_entry", choices(route))
        route.choose("menu.touch")
        rows = choices(route)
        for key in ("h_kiss_deep", "h_ear_neck", "h_chest_over", "h_thigh"):
            self.assertIn("touch." + key, rows)
        for key in ("deep_kiss", "chest_touch", "push_down"):
            self.assertNotIn("touch." + key, rows)  # いつもの時間の「深める」は、二人の時間では入口の行動に置き換わる
        self.assertNotIn("menu.next", rows)
        route.choose("touch.h_ear_neck")
        self.assertIsNotNone(route.engine.snapshot()["intimacy"])
        self.assertTrue(any(m.startswith("h_ear_neck.") for m in meanings(route)))

    def test_overflow_inside_when_continuing_at_the_limit(self):
        route = self.route(42, day_offset=2)
        route.begin()
        aroused(route)
        for key in ("h_strip_lower", "h_shift_under", "h_strip_self", "h_pos_player_above", "h_insert"):
            route.action(key)
        while route.engine.snapshot()["intimacy"]["player"]["arousal"] < 100:
            route.action("h_move_normal")
        before = route.engine.snapshot()
        route.action("h_move_normal")
        after = route.engine.snapshot()
        self.assertIn("h_overflow.inside", meanings(route))
        self.assertNotIn("h_move_normal.continue", meanings(route))
        self.assertEqual(after["stamina"]["value"], before["stamina"]["value"] - 1)
        self.assertEqual(after["intimacy"]["player"]["finishes"], 1)
        self.assertFalse(any(c["action_id"].startswith("h_move") for c in after["contacts"]))

    def test_self_help_offer_and_overflow_in_hand(self):
        route = self.route(7, day_offset=2, tier="familiar")
        route.begin()
        route.action("h_strip_self")
        route.action("h_self")
        self.assertIn("h.self.react.watch", meanings(route))  # 慣れの回は、見つめる反応
        offered = None
        for _ in range(12):
            offer = route.engine.snapshot()["offer"]
            if offer and offer["kind"] in ("h_help_hand", "h_help_mouth"):
                offered = offer["kind"]
                break
            if offer:
                route.choose("offer.decline")
            route.action("h_self")
        self.assertIsNotNone(offered, route.status())
        route.choose("offer.accept")
        service = {"h_help_hand": "h_maho_hand", "h_help_mouth": "h_maho_mouth"}[offered]
        self.assertTrue(any(c["action_id"] == service for c in route.engine.snapshot()["contacts"]))
        for _ in range(20):
            state = route.engine.snapshot()
            if state["intimacy"]["player"]["finishes"]:
                break
            decline_offers(route)
            route.action(service)
            self.assertLess(route.engine.snapshot()["intimacy"]["maho"]["climaxes"], 1)
            self.assertFalse(any(m.startswith("h.sign.") for m in meanings(route)))  # 真帆がする行動では合図を出さない
        kind = {"h_maho_hand": "hand", "h_maho_mouth": "mouth"}[service]
        self.assertIn("h_overflow." + kind, meanings(route))

    def test_self_alone_stops_short_of_the_limit_and_finish_in_hand_needs_her_hand(self):
        route = self.route(3, day_offset=2, tier="first")
        route.begin()
        route.action("h_strip_self")
        for _ in range(15):
            decline_offers(route)
            route.action("h_self")
        decline_offers(route)
        rules = route.engine.pack.intimacy
        self.assertEqual(route.engine.snapshot()["intimacy"]["player"]["arousal"], rules.b2["self_cap"])
        if route.engine.get_view()["page"] != "main":
            route.choose("menu.main")
        self.assertNotIn("touch.h_finish_hand", choices(route))
        route.choose("menu.h_service")
        row = choices(route)["touch.h_finish_hand"]
        self.assertFalse(row["available"])
        self.assertIn("手でしてもらう", route.engine.get_view()["explanations"]["touch.h_finish_hand"])

    def test_self_continued_long_uses_continue_texts_not_fallback(self):
        # v8.1.1：「自分で高める」には「さらに続ける」の本文がない。4回目以降は「続ける」の本文を出す。
        route = self.route(3, day_offset=2, tier="first")
        route.begin()
        route.action("h_strip_self")
        seen = []
        for _ in range(6):
            decline_offers(route)
            route.action("h_self")
            seen += [b for b in route.engine.get_view()["blocks"] if b["meaning"].startswith("h_self.")]
        pack = route.engine.pack
        contact = next(c for c in route.engine.snapshot()["contacts"] if c["action_id"] == "h_self")
        self.assertGreaterEqual(contact["continues"], 3)  # 「さらに続ける」の段になっている
        self.assertIn(seen[-1]["meaning"], ("h_self.continue", "h_self.continue_short"))  # v8.2.22：続けているあいだは短い本文（長い本文は3手に1回）
        self.assertFalse(any(pack.by_text[b["variant"]]["fallback"] for b in seen), [b["meaning"] for b in seen])

    def test_first_night_uses_first_time_sleep_and_morning_texts(self):
        # v8.1.1：一緒に眠る夜と翌朝の本文は回数を数えた後に出る。1回目の夜は「1回目」の本文、2回目以降はそれ以外。
        from tools.run_stage_b_routes import satisfied
        for tier, part in (("first", ".first."), ("few", ".few_familiar.")):
            route = self.route(0, tier=tier)
            try:
                satisfied(route)
            except AssertionError:
                pass  # 夜に終えると翌朝になる（経路の最後の確かめは昼の経路用）
            rows = [b for b in route.engine.get_view()["blocks"] if "_together." in b["meaning"]]
            self.assertEqual([b["meaning"].split(".")[1] for b in rows], ["sleep_together", "morning_together"], route.status())
            for block in rows:
                self.assertIn(part, block["variant"], (tier, block))

    def test_everyday_deeper_touches_have_written_texts(self):
        # v8.1.1：いつもの時間の「深める」触れ合い（第3陣）を、公開の選択肢で最初から続けても仮の本文に落ちない。
        plan = ["kiss"] * 3 + ["deep_kiss"] * 4 + ["ear_kiss"] * 4 + ["chest_touch"] * 4 + ["thigh_touch"] * 4 + ["under_clothes"] * 4 + ["push_down"]
        for tier in ("first", "few"):
            route = self.route(4, tier=tier, hour=20, day_offset=2)
            pack = route.engine.pack
            route.choose("near")
            seen = []
            for key in plan:
                while route.engine.snapshot()["offer"]:
                    route.choose("offer.accept" if route.engine.snapshot()["offer"]["kind"] == "kiss_back" else "offer.decline")
                view = route.engine.get_view()
                if view["page"] != "touch":
                    route.choose("menu.touch")
                row = choices(route).get("touch." + key)
                if not row or not row["available"]:
                    continue
                route.choose("touch." + key)
                seen += route.engine.get_view()["blocks"]
            names = {b["meaning"].split(".")[0] for b in seen}
            self.assertTrue({"deep_kiss", "ear_kiss", "chest_touch", "thigh_touch", "under_clothes", "push_down", "gate"} <= names, (tier, sorted(names)))
            self.assertFalse([b["meaning"] for b in seen if pack.by_text[b["variant"]]["fallback"]], tier)

    def test_position_texts_with_underwear_need_lower_not_off(self):
        # v8.1.1：体位を決めた本文でも「下着」があれば、下着を脱がせた後には出さない。
        pack = Route(42).engine.pack
        for text in pack.texts:
            if text["fallback"] or not text["meaning"].startswith(("h_", "h.")) or text["meaning"].startswith("h_strip_under"):
                continue
            if "下着" in text["body"]:
                self.assertIn('"actor.maho.clothing.lower"', json.dumps(text["when"], ensure_ascii=False), text["id"])

    def test_positions_linked_while_inserted(self):
        route = self.route(42, tier="familiar", day_offset=2)
        route.begin()
        aroused(route)
        for key in ("h_strip_lower", "h_shift_under", "h_strip_self", "h_pos_player_above", "h_insert"):
            route.action(key)
        for key in ("h_pos_leg_up", "h_pos_legs_shoulder", "h_pos_player_above"):
            decline_offers(route)
            route.action(key)
            self.assertTrue(route.engine.snapshot()["intimacy"]["inserted"], key)
        route.choose("menu.main")
        route.choose("menu.h_position")
        reason = route.engine.get_view()["explanations"]["touch.h_pos_from_behind"]
        self.assertIn("抜く", reason)
        route.choose("menu.main")
        route.action("h_withdraw")
        route.action("h_pos_from_behind")
        self.assertEqual(route.engine.snapshot()["intimacy"]["position"], "from_behind")

    def test_back_positions_lock_face_actions_and_use_facing(self):
        route = self.route(42, tier="few", day_offset=2)
        route.begin()
        aroused(route)
        undress(route)
        route.action("h_pos_from_behind")
        pack = route.engine.pack
        self.assertEqual(pack.registry.values(route.engine.snapshot())["intimacy.facing"], "back")
        route.choose("menu.main")
        route.choose("menu.h_touch")
        rows = choices(route)
        self.assertFalse(rows["touch.h_kiss_deep"]["available"])
        self.assertIn("体位", route.engine.get_view()["explanations"]["touch.h_kiss_deep"])
        self.assertTrue(rows["touch.h_ear_neck"]["available"])
        route.action("h_insert")
        texts = []
        for _ in range(12):
            if route.engine.snapshot()["intimacy"]["player"]["arousal"] >= 100:
                break
            decline_offers(route)
            route.action("h_move_normal")
            texts += [b for b in route.engine.get_view()["blocks"]]
        for block in texts:
            source = pack.by_text[block["variant"]]
            if source["fallback"]:
                continue
            if '"intimacy.position"' in json.dumps(source["when"]):
                continue
            self.assertFalse(any(cue in source["body"] for cue in FACE_CUES), (block["meaning"], source["body"]))

    def test_face_cue_texts_are_conditioned(self):
        pack = Route(42).engine.pack
        back = {"h_pos_" + name for name, p in pack.intimacy.positions.items() if p["facing"] == "back"}
        for text in pack.texts:
            if text["fallback"] or not text["meaning"].startswith(("h_", "h.")):
                continue
            when = json.dumps(text["when"], ensure_ascii=False)
            # 体位を1つに決めて出す本文は除く（v8.2.19：服の「ne」の条件が足されても、体位の条件が eq・in なら除く）
            positions = [c for c in text["when"].get("all", [text["when"]]) if isinstance(c, dict) and c.get("field") == "intimacy.position"]
            if positions and all(c["op"] in ("eq", "in") for c in positions) and '"not"' not in when:
                continue
            # 背を向けた体位へ移る本文は、その体位の state で書いて確かめた（額を壁へ、など）。下着を脱がせる本文は、脱がせることそのもの（v8.1.1）。
            # 顔面騎乗・シックスナインの本文は、その向きで出る前提で書いた（v8.2.10、生成と同じく条件を足さない）
            own = text["meaning"].startswith(OWN_FACING_SKIP) or text["meaning"].endswith((".face_sit", ".sixty_nine"))
            if any(cue in text["body"] for cue in FACE_CUES) and text["meaning"].split(".")[0] not in back and not own:
                self.assertIn('"intimacy.facing"', when, text["id"])
            if "下着" in text["body"] and not text["meaning"].startswith("h_strip_under"):
                self.assertIn('"actor.maho.clothing.lower"', when, text["id"])

    def test_strip_under_leaves_lower_off_and_no_underwear_text_follows(self):
        route = self.route(42, day_offset=2, tier="few")
        route.begin()
        aroused(route)
        for key in ("h_strip_lower", "h_strip_under", "h_strip_self", "h_pos_player_above"):
            route.action(key)
        self.assertEqual(route.engine.snapshot()["actors"]["maho"]["clothing"]["lower"], "off")
        self.assertIn("何も着けていない", route.engine.get_view()["status"]["intimacy"]["clothing"])
        bodies = []
        route.action("h_insert")
        bodies += [b["body"] for b in route.engine.get_view()["blocks"]]
        for _ in range(8):
            decline_offers(route)
            route.action("h_move_slow")
            bodies += [b["body"] for b in route.engine.get_view()["blocks"]]
        self.assertFalse([b for b in bodies if "下着" in b])

    def test_mouth_climax_records_source(self):
        route = self.route(42, day_offset=2, tier="few")
        route.begin()
        aroused(route)
        for key in ("h_strip_lower", "h_strip_under", "h_pos_lying_face"):
            route.action(key)
        for _ in range(20):
            decline_offers(route)
            if route.engine.snapshot()["intimacy"]["maho"]["climaxes"]:
                break
            route.action("h_player_mouth")
        state = route.engine.snapshot()["intimacy"]
        self.assertEqual(state["maho"]["climax_source"], "mouth")
        self.assertIn("h.climax.maho", meanings(route))
        self.assertIn("脚のあいだ", route.engine.get_view()["status"]["intimacy"]["position"])

    def test_night_end_sleeps_together_day_end_does_not(self):
        route = self.route(42)
        route.begin()
        route.choose("h.end")
        route.choose("offer.decline")
        self.assertEqual(meanings(route)[-3:], ["h.sleep_together.unsatisfied", "h.morning_together.unsatisfied", "life.breakfast"])
        state = route.engine.snapshot()  # 一緒に眠った翌朝は、朝食を済ませて二人とも居間へ（検査役G2 M-4）
        self.assertEqual({state["actors"][a]["location"] for a in ("player", "maho")}, {"living_room"})
        self.assertNotIn("system.slept", meanings(route))
        self.assertEqual(route.engine.snapshot()["stamina"]["value"], 3)
        route = self.route(42, **DAYTIME)
        route.begin()
        route.choose("h.end")
        route.choose("offer.decline")
        self.assertNotIn("h.sleep_together.unsatisfied", meanings(route))
        self.assertEqual(route.engine.snapshot()["mode"], "normal")

    def normal_route(self, desire, hour=20, minute=0, **kwargs):
        route = self.route(13, hour=hour, minute=minute, **kwargs)
        route.engine._state["desire"] = desire
        route.engine._install_choices()
        if "near" in choices(route) and choices(route)["near"]["available"]:
            route.choose("near")
        route.choose("menu.touch")
        self.assertIn("恋人としてキスを3回", route.engine.get_view()["explanations"]["touch.deep_kiss"])
        for _ in range(3):
            decline_offers(route)
            if route.engine.get_view()["page"] != "touch":
                route.choose("menu.touch")
            route.choose("touch.kiss")
        decline_offers(route)
        if route.engine.get_view()["page"] != "touch":
            route.choose("menu.touch")
        route.engine._state["desire"] = desire
        route.engine._install_choices()
        return route

    def test_gate_low_desire_allows_kiss_and_stops_chest_in_living_room(self):
        route = self.normal_route(0)
        route.choose("touch.deep_kiss")
        self.assertIn("gate.react.allow", meanings(route))
        self.assertIsNone(route.engine.snapshot()["offer"])
        route.choose("menu.touch") if route.engine.get_view()["page"] != "touch" else None
        route.choose("touch.chest_touch")
        self.assertIn("gate.react.deflect_place", meanings(route))
        self.assertFalse(any(c["action_id"] == "chest_touch" for c in route.engine.snapshot()["contacts"]))

    def test_gate_invite_accept_starts_intimacy_from_the_touch(self):
        route = self.normal_route(95)
        route.choose("touch.deep_kiss")
        self.assertEqual(route.engine.snapshot()["offer"]["kind"], "gate_invite_deep_kiss")
        self.assertIn("gate.react.invite", meanings(route))
        route.choose("offer.accept")
        state = route.engine.snapshot()
        self.assertEqual((state["mode"], state["actors"]["player"]["location"]), ("private", "maho_room"))
        self.assertEqual((state["intimacy"]["entry"], state["intimacy"]["origin"]), ("invite", "maho"))
        self.assertEqual(meanings(route)[:2], ["h.begin.invite", "h_kiss_deep.first"])

    def test_gate_invite_decline_has_its_own_line(self):
        route = self.normal_route(95)
        route.choose("touch.deep_kiss")
        route.choose("offer.decline")
        self.assertEqual(meanings(route)[-1], "offer.gate.declined")
        self.assertIsNone(route.engine.snapshot()["intimacy"])

    def test_gate_before_work_is_stopped_for_time(self):
        route = self.normal_route(95, hour=7, minute=40, day_offset=1)  # 仕事は 8:30 から
        route.choose("touch.deep_kiss")
        self.assertIn("gate.react.deflect_time", meanings(route))
        self.assertIsNone(route.engine.snapshot()["offer"])

    def test_couple_touches_have_written_texts(self):
        route = self.route(13)
        if "near" in choices(route) and choices(route)["near"]["available"]:
            route.choose("near")
        route.choose("menu.touch")
        pack = route.engine.pack
        for key in ("back_hug", "finger_lace", "cheek_kiss", "lap_pillow_take", "lap_pillow"):
            decline_offers(route)
            if route.engine.get_view()["page"] != "touch":
                route.choose("menu.touch")
            for contact in list(route.engine.snapshot()["contacts"]):
                route.choose("end." + contact["action_id"])
            route.choose("touch." + key)
            block = next(b for b in route.engine.get_view()["blocks"] if b["meaning"].startswith(key + "."))
            self.assertFalse(pack.by_text[block["variant"]]["fallback"], key)

    def test_touch_page_fits_and_hints_for_gate(self):
        route = self.route(13)
        if "near" in choices(route) and choices(route)["near"]["available"]:
            route.choose("near")
        route.choose("menu.touch")
        view = route.engine.get_view()
        ids = {c["id"] for c in view["choices"]}
        self.assertNotIn("menu.next", ids)
        self.assertIn("touch.push_down", ids)
        self.assertIn("服の上から胸か太もも", view["explanations"]["touch.push_down"])

    def test_standing_back_keeps_to_standing_actions(self):
        route = self.route(42, tier="familiar", day_offset=2)
        route.begin()
        aroused(route)
        undress(route)
        route.action("h_pos_standing_back")
        state = route.engine.snapshot()
        self.assertEqual({state["actors"][a]["posture"] for a in ("player", "maho")}, {"standing"})
        route.choose("menu.main")
        route.choose("menu.h_touch")
        rows = choices(route)
        self.assertFalse(rows["touch.h_touch_direct"]["available"])
        self.assertFalse(rows["touch.h_player_mouth"]["available"])
        self.assertTrue(rows["touch.h_ear_neck"]["available"])

    def test_save_and_load_with_help_offer_open(self):
        route = self.route(7, day_offset=2, tier="familiar")
        route.begin()
        route.action("h_strip_self")
        for _ in range(12):
            offer = route.engine.snapshot()["offer"]
            if offer and offer["kind"].startswith("h_help_"):
                break
            if offer:
                route.choose("offer.decline")
            route.action("h_self")
        self.assertTrue(route.engine.snapshot()["offer"]["kind"].startswith("h_help_"))
        before = route.engine.snapshot()
        route.engine.save("slot02")
        route.engine.load("slot02")
        self.assertEqual(route.engine.snapshot(), before)


if __name__ == "__main__":
    unittest.main()
