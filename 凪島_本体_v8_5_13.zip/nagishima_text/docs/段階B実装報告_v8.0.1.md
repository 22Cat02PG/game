# 段階B 本体修正報告（v8.0.1）

対象：`GPT指示_段階B_v8.0.1.md` の第1節（F-1〜F-4、D-1、job の差し替え、F-5）。起点は `凪島_本体修正版_v8_0_0.zip`。基準は `凪島_段階B_仕様と受入条件_2026-09-26.md`（改訂1）と `Opus段階B受入監査_v8.0.0_2026-09-26.md`。

**分担**：修正の実装と試験の追加は GPT-6 Sol が行った（`docs/段階B_v8.0.1作業引継ぎ.md` の時点まで）。GPT の作業停止の後、総合検査・本文検査・経路・互換・自動プレイ・再生成の確認、この報告、ZIP の作成は Claude Opus 5.5 が行った。Opus はコードを変えていない。

版：本体 2.4.1、rules `nagishima-2.4`、SAVE_SCHEMA 4（変更なし）。新規開始の既定は `interaction_008` のまま。

## 1. 変えたところ

| 項目 | 変えたファイル | 内容 |
|---|---|---|
| F-1 | `nagishima/intimacy.py` | 誘いを受けたとき、移動と二人の時間の開始の状態処理はそのままにし、その本文（`system.moved`、`private.began`）を捨てて `h.begin.invite` だけを出す |
| F-2 | `nagishima/engine.py` | エッチの最中の presence：服の語ごとに「。」で区切り、空の語は飛ばす |
| F-3 | `nagishima/menus.py` | 設定の表示を仕様 7.1（改訂1）の日本語にした。選択肢 ID は v8.0.0 と同じ |
| F-4 | `nagishima/intimacy.py`、`nagishima/menus.py` | 設定を、エッチの前の二人の時間でも変えられる（`intimacy` が null、場面・問いがないとき）。二人の時間の中の戻り先は「二人の時間へ」 |
| D-1 | `tools/stage_b/intimacy_009.json`、`docs/intimacy_009.json`、`content/releases/interaction_009/` | Opus 改訂1のデータに差し替え（`h_shift_under` の `maho_ready` を null、`deflect.hand` を `h_touch_direct` だけ）。009 を作り直した（46行動・289 meaning・1137本文、control `8759bfc6…`） |
| job | `authoring/b_jobs/grok_wave_1〜3.json`、`authoring/b_jobs/README.md`、`tools/build_stage_b_jobs.py` | Opus の正本（118・150・95件）に差し替え。生成ツールは検査ツールに変え、取り込みの規則を README に書いた。`sonnet_life_8.json` はそのまま |
| 試験 | `tests/test_stage_b_v801.py`（新規7件）、`tests/test_stage_b.py`、`tests/test_stage_a.py`、`tools/check_stage_b_job_coverage.py`（新規） | F-1〜F-4・D-1・job の試験。D-1 で止めの例を `h_touch_direct`・`h_insert` に変えた（B-06・B-23・B-43）。版の期待値を 2.4.1 に |
| 版・資料 | `nagishima/__init__.py`、`tools/pack_runtime.py`、README、API 資料2つ、引き継ぎ | 2.4.1、ZIP 名 v8.0.1 |

## 2. 検証の結果（Linux、Python 3.11.15。Opus が実行）

| 検査 | 結果 | 記録 |
|---|---|---|
| 全試験（check_runtime） | 258件成功（失敗0・エラー0、302秒） | `verification/results.json`、`test_results.txt` |
| 本文検証 006〜009 | 4つとも成功 | `verification/verify_006〜009_v801.txt` |
| 18経路（6経路 × seed 0・42・20380407） | 18件成功 | `verification/stage_b_routes.json` |
| job の網羅（仮本文を job ごとに1本入れて19経路） | 19件成功、本文の選択423回、46 meaning、fallback に落ちたもの0 | `verification/stage_b_job_coverage.json` |
| B-02（003・006・007・008 × 3方式 × seed 0・42） | 24通りすべて v7.1.2 と一致 | `verification/stage_b_compat.json` |
| 自動プレイ 009 | 標準 seed 0〜2：194操作で cleared、satisfied。交流 seed 0〜2：188操作で cleared、satisfied。存在感 seed 0〜19：188操作で cleared、unsatisfied。どれもエッチ1回、生活日8日 | `verification/stage_b_audit_*.json` |
| B-08（完成 ZIP を新しく展開して 009 を作り直す） | 11ファイルすべて一致 | `verification/stage_b_zip_rebuild.json` |

Windows：GPT が作業停止の直前に、同じコードで全258件の成功を確認した（GPT の報告。記録は GPT の作業フォルダーの `verification/results.json`）。この ZIP のコードは、その作業時点から変えていない。`start.bat` での 009 の自動プレイは v8.0.1 では未実施。

## 3. 仕様から外れたところ（F-5）

自動プレイは、仕様第8節（改訂前）と次の3点が違う。Opus の監査で受け入れ、仕様は改訂1で実装に合わせた。方策は v8.0.0 から変えていない。

1. エッチを通すのは最初の1回だけ。
2. 手順の省略：口づけで高まり40まで待ってから、上をめくる → 下を脱がせる → 下着をずらす → 自分の下 → 上に重なる → 入れる → 帯に合わせた速さ…と進む。胸・指の行動は通らない。
3. 存在感方式は、始めてすぐ「終える」→ 引き留めに「今日はここまで」（結果は unsatisfied）。標準の方策では200操作で cleared に届かないため（Opus が seed 0〜3 で確認）。

これ以外の逸脱：なし。

## 4. 注意と未確認

- **v8.0.0 で作った 009 の保存は、v8.0.1 では読めない**（`release_hash`「保存時の原稿の版と一致しない」）。D-1 で 009 のデータが変わったため。009 は未公開の試遊版なので移行は作らない。008 と 007 の保存は今までどおり読める。
- 未確認：Windows の `start.bat` での v8.0.1 の起動と自動プレイ。
- B-50・B-51（本文の取り込み）は次の版。
