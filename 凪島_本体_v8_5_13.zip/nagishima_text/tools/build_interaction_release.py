"""Build the first structural interaction expansion without rewriting published releases."""

from copy import deepcopy
from pathlib import Path
import os
import shutil
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from nagishima.codec import bytes_digest, digest, read_json, write_json
from nagishima.content import FILES, Pack
from nagishima.errors import ensure


SOURCE = "prose_002"
TARGET = "interaction_003"
TRUE = {"all": []}
TOGETHER = {"field": "together", "op": "eq", "value": True}
POSTURES = ["standing", "seated", "reclined"]


def action(identity, label, ongoing, min_stage, resources, replaces=()):
    return {
        "id": identity, "label": label, "ongoing": ongoing,
        "min_stage": min_stage, "near": identity not in {
            "compliment", "gratitude", "together_words", "check_mood", "share_day", "reassurance"
        },
        "resources": list(resources), "replaces": list(replaces),
        "keep_on_joint_move": identity in {"hair", "back"},
        "when": TOGETHER, "maintain": TOGETHER, "postures": POSTURES,
    }


NEW_ACTIONS = [
    action("compliment", "かわいいと伝える", False, 1, ("player.speech", "maho.speech")),
    action("gratitude", "ありがとうと伝える", False, 0, ("player.speech", "maho.speech")),
    action("together_words", "一緒にいられてうれしいと伝える", False, 2, ("player.speech", "maho.speech")),
    action("check_mood", "今の気分を尋ねる", False, 0, ("player.speech", "maho.speech")),
    action("share_day", "今日のことを話す", False, 0, ("player.speech", "maho.speech")),
    action("reassurance", "そばにいたいと伝える", False, 2, ("player.speech", "maho.speech")),
    action("hair", "髪に触れる", True, 2, ("player.right_hand", "maho.head_contact"), ("head",)),
    action("cheek", "頬に触れる", False, 2, ("player.right_hand", "maho.face_contact")),
    action("shoulder", "肩に触れる", False, 1, ("player.right_hand", "maho.shoulder_contact")),
    action("arm", "腕に触れる", False, 1, ("player.right_hand", "maho.arm_contact")),
    action("back", "背中を撫でる", True, 2, ("player.right_hand", "maho.body_contact")),
    action("forehead", "額を寄せる", False, 2, ("player.posture", "maho.posture", "maho.face_contact")),
    action("waist", "腰を抱く", True, 3, ("player.left_hand", "player.right_hand", "maho.body_contact"), ("head", "hair", "hands", "back")),
]


PROFILES = {
    "talk": {
        "act": "声をかけると", "detail": "真帆は手元を止めてこちらへ顔を向けた",
        "first": "こうして話しかけてもらえるの、うれしいな",
        "start": "うん、聞いてるよ。今日はどんな話？",
        "repeat": "まだ話していたかったんだね。私も、もう少し聞きたい",
        "heated": "そんなに私と話したいの？　ふふ、ちゃんとこっちを見て",
    },
    "affection": {
        "act": "好きだと伝えると", "detail": "真帆は一瞬まばたきを忘れ、頬をゆるめた",
        "first": "今の言葉、ずっと覚えていたい",
        "start": "知っていても、言ってもらうとやっぱりうれしい",
        "repeat": "さっきも聞いたのに、またうれしくなってる",
        "heated": "何度も言われたら、私も我慢できなくなるよ。大好き",
    },
    "kiss": {
        "act": "唇を重ねると", "detail": "真帆は近い息づかいのまま、こちらの目を見た",
        "first": "びっくりした。でも、嫌じゃない。もう少しだけ近くにいて",
        "start": "ん……ちゃんと、あなたのキスだって分かる",
        "repeat": "また？　そう言いながら、私も待ってたみたい",
        "heated": "もう回数なんて数えられない。今度は私からしてもいい？",
    },
    "compliment": {
        "act": "かわいいと伝えると", "detail": "真帆は前髪を指で直しながら、隠しきれない笑みを浮かべた",
        "first": "急に言うから、どんな顔をすればいいか分からないよ",
        "start": "今日の私をちゃんと見て言ってくれたなら、うれしい",
        "repeat": "また言った。冗談じゃない顔をしてるから、余計に照れる",
        "heated": "そんなに見つめて言わないで。うれしくて、離れたくなくなる",
    },
    "gratitude": {
        "act": "ありがとうと伝えると", "detail": "真帆は何に向けた言葉かを確かめるように、穏やかに目を細めた",
        "first": "こちらこそ。二人でやれたことが、いちばんうれしい",
        "start": "どういたしまして。そう言ってもらえると、やってよかったって思える",
        "repeat": "もう受け取ったよ。でも、二度目は二度目でうれしいね",
        "heated": "そんなに感謝されたら、次はもっと何かしてあげたくなる",
    },
    "together_words": {
        "act": "一緒にいられてうれしいと伝えると", "detail": "真帆は部屋の中を一度見回し、最後にこちらを見つめた",
        "first": "私も。同じ家にあなたの気配があること、毎日うれしい",
        "start": "特別なことがない日も、あなたとなら大事な日に思えるよ",
        "repeat": "何度確認してもいいよ。私も同じ気持ちだから",
        "heated": "そんなふうに重ねて言われたら、ずっとそばにいたくなる",
    },
    "check_mood": {
        "act": "今の気分を尋ねると", "detail": "真帆は胸の内を探るように少し黙ってから答えた",
        "first": "穏やかかな。あなたが聞いてくれたから、少しうれしくもなった",
        "start": "今は落ち着いてるよ。あなたはどう？",
        "repeat": "さっきより、あなたに気持ちが向いてる。何か気づいた？",
        "heated": "今？　顔を見れば分かるでしょう。うれしくて、少し熱い",
    },
    "share_day": {
        "act": "今日あったことを話すと", "detail": "真帆は小さな出来事にも相づちを返し、話の続きを待った",
        "first": "そういう一日の話、もっと聞きたい。離れていた時間も近くなるから",
        "start": "うん、それから？　今日はそんなことがあったんだね",
        "repeat": "まだ続きがあったんだ。急がなくていいから聞かせて",
        "heated": "あなたの一日をこんなに聞けるの、私だけの時間みたいでうれしい",
    },
    "reassurance": {
        "act": "そばにいたいと伝えると", "detail": "真帆は二人の間の距離を確かめ、安心したように息をついた",
        "first": "うん。言葉にしてくれて、ほっとした。私もここにいたい",
        "start": "じゃあ、しばらくこのままでいよう。何もしなくてもいいから",
        "repeat": "ちゃんと聞こえてるよ。私も離れるつもりはないよ",
        "heated": "何度も確かめなくても、私はあなたのそばにいる。もっと近くてもいいよ",
    },
    "hair": {
        "act": "結んだ髪へそっと指を入れると", "detail": "真帆は首をわずかに傾け、触れやすい向きへ頭を預けた",
        "first": "髪に触れられると、近さがよく分かるね",
        "start": "今日は少し乱れてるかも。あなたなら、そのまま触っていいよ",
        "continue": "指が通るたび、真帆の肩から力が抜けていく",
        "settled": "真帆はすっかり目を細め、髪を任せたまま静かに呼吸している",
    },
    "cheek": {
        "act": "頬に手を添えると", "detail": "真帆は手のひらの温度を確かめるように、わずかに顔を寄せた",
        "first": "手、あたたかいね。こんなに近いと少し照れる",
        "start": "うん、触れていいよ。今はあなたの手が落ち着く",
        "repeat": "また頬？　さっきの温度、もう一度ほしかったのかな",
        "heated": "何度も触れられると、そこだけずっと熱い。あなたにも分かる？",
    },
    "shoulder": {
        "act": "肩へそっと手を置くと", "detail": "真帆は驚かず、触れた手の重みを受け止めてこちらを向いた",
        "first": "呼んだ？　こうして触れてから声をかけるの、あなたらしいね",
        "start": "ここにいるよ。肩の手、そのままでも大丈夫",
        "repeat": "また確かめにきたの？　ちゃんと隣にいるよ",
        "heated": "何度も触れるなら、肩だけじゃ足りないって顔をしてる",
    },
    "arm": {
        "act": "腕へ指先で触れると", "detail": "真帆は触れた場所へ目を落としてから、こちらの手元を見つめた",
        "first": "そこから触れるんだ。近づきたいって、ちゃんと伝わったよ",
        "start": "腕なら歩くときも近くにいられるね",
        "repeat": "さっきから何度も私を確かめてる。うれしいけど、少しくすぐったい",
        "heated": "そんなふうに触れ直されたら、私から腕を絡めたくなるよ",
    },
    "back": {
        "act": "背中をゆっくり撫でると", "detail": "真帆は息を長く吐き、張っていた背中を手のひらへ預けた",
        "first": "背中って、自分では届きにくいから……安心する",
        "start": "今日も撫でてくれるの？　あなたの速さ、覚えてるよ",
        "continue": "手のひらが往復するたび、真帆の呼吸がゆるやかになる",
        "settled": "真帆はもう言葉を足さず、背中越しにこちらの気配を受け取っている",
    },
    "forehead": {
        "act": "額をそっと寄せると", "detail": "真帆の視線がすぐ近くで揺れ、互いの呼吸だけが残った",
        "first": "近いね。声にしなくても、今の気持ちが伝わりそう",
        "start": "少しだけこのまま。あなたの体温、落ち着くから",
        "repeat": "またここまで来たね。今度は私も目をそらさない",
        "heated": "何度も額を合わせたら、次を待ってるみたいに見えるでしょう",
    },
    "waist": {
        "act": "腰へ腕を回すと", "detail": "真帆は体勢を確かめてから、逃げずに体重をこちらへ預けた",
        "first": "そこを抱かれると、本当に離れられなくなるね",
        "start": "うん、もっと近くていい。あなたの腕の中だって分かるから",
        "continue": "真帆は腰を支える腕に慣れ、こちらの胸元へ少し近づく",
        "settled": "二人の姿勢がなじみ、真帆は抱かれたまま安心した息をついた",
    },
}


TAILS = {
    "first": [
        "初めて受け取る言葉や感触を急いで決めつけず、うれしさごと確かめている。",
        "窓の外の波音が一度響くあいだも、真帆の意識はこちらから離れなかった。",
        "返事のあとにも視線を残し、こちらがどう受け取ったかまで見届けようとしている。",
        "戸惑いはあるが拒む気配はなく、新しく縮まった距離を丁寧に受け止めている。",
    ],
    "start": [
        "以前にも交わしたことを覚えている声で、自然にこちらを受け入れた。",
        "暮らしの中で知ったこちらの癖まで思い出したらしく、口元がやわらぐ。",
        "特別に構えず、それでも雑には扱わず、今この瞬間の返事を返してくれた。",
        "慣れたやりとりの中にも今日の気分を混ぜ、こちらとの時間を楽しんでいる。",
    ],
    "repeat": [
        "同じ働きかけが続いていることに気づき、真帆は可笑しそうに目を細めた。",
        "一度目の余韻が残っているため、反応はさっきより早く、距離も近い。",
        "繰り返しを知らないふりにはせず、こちらの意図を測るように見つめ返す。",
        "また選ばれたこと自体を喜びながら、少しだけからかう調子を声に混ぜた。",
    ],
    "heated": [
        "重なる働きかけに頬の熱を隠せなくなり、真帆からも距離を詰めようとする。",
        "もう偶然ではないと分かり、照れながらもこちらへ向ける気持ちが強くなる。",
        "呼吸を整えようとして失敗し、真帆は熱を帯びた目でこちらを見上げた。",
        "受け取るだけでは足りなくなったらしく、次は自分から返したい気持ちが表に出る。",
    ],
    "continue": [
        "続いていることを確かめるように、真帆は小さくうなずいた。",
        "離れずにいる時間そのものが安心になるらしく、肩の力が少しずつ抜けていく。",
        "同じ触れ方の中のわずかな変化にも気づき、心地よい位置へ自分からなじむ。",
        "言葉を足すより今の感触を選び、真帆は静かな返事を呼吸に込めた。",
    ],
    "settled": [
        "もう姿勢を探る必要もなく、二人の距離が暮らしの一部のように落ち着いている。",
        "長く続く触れ合いを当然にはせず、時おりこちらを見てうれしそうに確かめる。",
        "部屋の物音へ意識を戻しながらも、触れている場所だけは大切に保っている。",
        "真帆は安心しきった表情で、終える合図があるまでこのままでいたそうにしている。",
    ],
}


def phase_texts(identity, phase):
    profile = PROFILES[identity]
    reply = profile[phase]
    lead = f"{profile['act']}、{profile['detail']}。「{reply}」"
    return [lead + tail for tail in TAILS[phase]]


def text(identity, meaning, body, fallback=False, index=0):
    suffix = "base" if fallback else f"draft{index}"
    return {
        "id": f"{meaning}.i003.{suffix}", "meaning": meaning, "when": TRUE,
        "slots": [], "group": f"{meaning}.interaction_003", "body": body,
        "fallback": fallback,
    }


def add_meaning(meanings, texts, drafts, meaning, bodies):
    meanings.add(meaning)
    texts.append(text("", meaning, bodies[0], True))
    for index, body in enumerate(bodies[1:], 1):
        entry = text("", meaning, body, False, index)
        texts.append(entry)
        drafts.append({"id": entry["id"], "meaning": meaning, "status": "working_draft", "reviewed": False})


def main():
    source_path = ROOT / "content" / "releases" / SOURCE
    source = Pack(source_path)
    target = source_path.parent / TARGET
    ensure(not target.exists(), "release_exists", "interaction_003は既に存在する。公開済み版を上書きしない。")
    catalog = deepcopy(source.catalog)
    actions = deepcopy(list(source.actions.values())) + deepcopy(NEW_ACTIONS)
    scenes = deepcopy(list(source.scenes.values()))
    meanings = set(source.meanings)
    texts = deepcopy(source.texts)
    drafts = []

    catalog["resources"].update({
        "maho.face_contact": 1, "maho.shoulder_contact": 1,
        "maho.arm_contact": 1, "maho.body_contact": 1,
    })
    catalog["offers"].update({
        "reciprocal_hug": {"plan": {"op": "action", "id": "hug", "origin": "maho"}},
        "kiss_back": {"plan": {"op": "action", "id": "kiss", "origin": "maho"}},
    })

    for definition in NEW_ACTIONS:
        identity = definition["id"]
        phases = ("first", "start", "continue", "settled") if definition["ongoing"] else ("first", "start", "repeat", "heated")
        for phase in phases:
            bodies = phase_texts(identity, phase)
            add_meaning(meanings, texts, drafts, identity + "." + phase, bodies)

    for identity in ("talk", "affection", "kiss"):
        for phase in ("repeat", "heated"):
            bodies = phase_texts(identity, phase)
            add_meaning(meanings, texts, drafts, identity + "." + phase, bodies)

    offer_bodies = {
        "offer.reciprocal_hug": [
            "真帆は何度も届いた言葉を胸の内で確かめ、両腕を少し広げた。「今度は私から抱きしめてもいい？」",
            "頬の熱を隠す代わりに、真帆はこちらへ一歩近づいた。「聞くだけじゃ足りなくなった。私からも抱きしめたいな」",
            "真帆はうれしさをこらえきれず、こちらの返事を待って腕を伸ばしかける。「私の気持ちも、近くで受け取ってくれる？」",
            "何度も向けられた好意に、真帆のほうから距離を縮める。「次は私の番。ぎゅっとしてもいい？」",
        ],
        "offer.kiss_back": [
            "真帆は近い距離のまま唇へ一度視線を落とした。「今度は私からキスしてもいい？」",
            "重ねたキスの余韻の中で、真帆がそっと顔を上げる。「受け取ってばかりじゃずるいから、私からもしたい」",
            "真帆は照れたまま逃げず、こちらの返事を待った。「次の一回、私に任せてくれる？」",
            "息を整えた真帆は、今度は自分から距離を詰める前に尋ねた。「私から触れても、いい？」",
        ],
    }
    for meaning, bodies in offer_bodies.items():
        add_meaning(meanings, texts, drafts, meaning, bodies)

    parent = target.parent
    temporary = Path(tempfile.mkdtemp(prefix=".building-interaction-", dir=parent))
    try:
        documents = [catalog, actions, scenes, sorted(meanings), texts]
        for filename, value in zip(FILES, documents):
            write_json(temporary / filename, value)
        manifest = {
            "id": TARGET, "rules_version": source.manifest["rules_version"],
            "files": {name: bytes_digest((temporary / name).read_bytes()) for name in FILES},
            "control_sha256": digest({"catalog": catalog, "actions": actions}),
        }
        write_json(temporary / "release.json", manifest)
        previous_ledger = source_path / "authoring_ledger.json"
        if previous_ledger.exists():
            shutil.copy2(previous_ledger, temporary / "authoring_ledger.json")
        write_json(temporary / "interaction_drafts.json", {
            "release": TARGET, "source_release": SOURCE,
            "note": "構造追加に伴う高速生成の作業原稿。既存の検品記録とは分離し、承認済みとは扱わない。",
            "texts": drafts,
        })
        pack = Pack(temporary)
        os.rename(temporary, target)
    finally:
        if temporary.exists():
            shutil.rmtree(temporary)

    report = {
        "release": pack.id, "source_release": source.id,
        "actions": len(pack.actions), "new_actions": len(NEW_ACTIONS),
        "meanings": len(pack.meanings), "texts": len(pack.texts),
        "new_texts": len(pack.texts) - len(source.texts),
        "draft_texts": len(drafts), "control_sha256": pack.control_hash,
        "release_sha256": pack.hash,
    }
    write_json(ROOT / "verification" / "interaction_003_inventory.json", report)
    print(report)


if __name__ == "__main__":
    main()
