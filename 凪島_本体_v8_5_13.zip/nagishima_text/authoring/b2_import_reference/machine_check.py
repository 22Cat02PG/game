"""B2 の grok の本文の機械検査（Opus、2026-09-27）。pool.json → machine.json。

段階Bの検査項目（check_stage_b_texts.py）に、B2 の state に合わせた項目を足す。
fail は採用しない（直せるものは直して採用）、warn は読む係と Opus が確かめる。
"""
import json
import re
import sys
from collections import Counter, defaultdict

sys.path.insert(0, "/home/claude/work/v810/nagishima_text")
from tools.check_stage_b_texts import ORGANS, PREGNANCY, ELASTIC, TIER_WORDS, WORD, MEANING_WORDS, split

BASE = "/home/claude/work/b2"
jobs = {}
import glob
for path in sorted(glob.glob(f"{BASE}/grok_b2_wave_*.json")):  # 補充（第4）も
    for j in json.load(open(path, encoding="utf-8")):
        jobs[j["id"]] = j
POOL = sys.argv[1] if len(sys.argv) > 1 else "pool.json"
OUT = sys.argv[2] if len(sys.argv) > 2 else "machine.json"
pool = json.load(open(POOL, encoding="utf-8"))

TOKENS = {"penis", "vagina", "semen", "breasts", "nipple", "clitoris", "love_juice"}
BANNED_NARRATION = ["拒む", "避ける", "抵抗", "満たされる", "欲しい", "熱が戻る", "跡"]
FACE_CUES = ["見つめ", "目が合", "見上げ", "見下ろ", "首に腕", "首に回", "胸に顔", "額", "唇を重", "向かい合", "瞳", "目を合わせ", "顔を埋", "口づけを返"]
BED_WORDS = ["ベッド", "シーツ", "枕", "布団", "壁", "マットレス"]
HOME_WORDS = ["ベッド", "布団", "シーツ", "枕", "居間", "台所", "寝室", "個室", "ソファ", "キッチン", "リビング"]
HOME_ACTS = ["脱が", "秘所", "{vagina}", "{clitoris}", "{nipple}", "下着"]
FINISH_DIALOGUE = ["中", "外", "待って", "止まって", "入った", "出てる", "出して"]


def length_range(text):
    m = re.search(r"(\d+)〜(\d+)字", text)
    return (int(m.group(1)), int(m.group(2))) if m else None


def tier_of(job):
    t = job["state"].get("慣れ", "")
    if t:
        return "first" if t.startswith("初回") else "few" if t.startswith(("数回", "数回か慣れ")) else None
    rel = job["state"].get("関係", "")
    if "まだエッチはしていない" in rel:
        return "first"
    if "エッチをしたことがある" in rel:
        return "few"
    return None


result = {}
for jid, rows in pool.items():
    job = jobs[jid]
    st = job["state"]
    tier = tier_of(job)
    back = "背を向けて" in st.get("体位", "") or any(c.get("field") == "intimacy.facing" and c.get("value") == "back" for c in job["when"]["all"])
    back_place = "ベッド・シーツ・枕・壁の語を書かない" in st.get("場所", "")
    home = st.get("場所", "").startswith(("二人の家の中", "居間か"))
    lower_open = "下着について書かない" in st.get("服", "") or "下着・布・服について書かない" in st.get("服", "")
    lower_off = "下着まで脱いでいる" in st.get("服", "")  # 補充 p4
    finish = job["_meaning"].startswith(("h_finish", "h_overflow"))
    lr = length_range(job["length"])
    for row in rows:
        body = row["body"]
        dialogues, narration = split(body)
        fails, warns = [], []
        if len(dialogues) != (1 if job["speech"] else 0):
            fails.append(f"台詞の数 {len(dialogues)}")
        fails += [f"地の文に器官の語：{w}" for w in ORGANS if w in narration]
        fails += [f"妊娠・避妊の語：{w}" for w in PREGNANCY if w in ELASTIC.sub("", body)]
        if "あなた" in narration:
            fails.append("地の文に「あなた」")
        if "彼女" in body:
            fails.append("「彼女」")
        if body.count("真帆") > 2:
            fails.append("「真帆」が3回以上")
        if "初めて" in narration:
            fails.append("地の文に「初めて」")
        for token in re.findall(r"\{([a-z_]+)\}", body):
            if token not in TOKENS:
                fails.append(f"未登録の記号 {token}")
        if any(re.search(r"\{[a-z_]+\}", d) for d in dialogues):
            fails.append("台詞の中に記号")
        if "{" in re.sub(r"\{[a-z_]+\}", "", body) or "}" in re.sub(r"\{[a-z_]+\}", "", body):
            fails.append("記号の形が崩れている")
        if tier in TIER_WORDS:
            fails += [f"台詞に慣れの段階で使えない語：{w}" for d in dialogues for w in TIER_WORDS[tier] if w in d]
        warns += [f"地の文で使わない語：{w}" for w in BANNED_NARRATION if w in narration]
        if back:
            warns += [f"背を向けた体位で向かい合う語：{w}" for w in FACE_CUES if w in narration]
        if back_place:
            fails += [f"ベッド・壁の語：{w}" for w in BED_WORDS if w in narration]
        if home:
            fails += [f"いつもの暮らしの場面で場所の語：{w}" for w in HOME_WORDS if w in narration]
            fails += [f"いつもの暮らしの場面で先へ進む語：{w}" for w in HOME_ACTS if w in body]
        if lower_open and "下着" in body:
            fails.append("下着について書いた")
        if job["_meaning"].startswith("h_touch_direct.") and "{vagina}" in body:
            fails.append("外側に触れる本文で {vagina}")
        if lower_off:
            fails += [f"下着まで脱いだ場面で布の語：{w}" for w in ("ずら", "布", "ショーツ", "パンツ") if w in body]
        if finish:
            fails += [f"出す場面の台詞：{w}" for d in dialogues for w in FINISH_DIALOGUE if w in d and not (w == "中" and "夢中" in d)]
        if lr:
            n = len(re.sub(r"\{[a-z_]+\}", "語", body))
            if n < lr[0] * 0.8:
                warns.append(f"短い（{n}字）")
            elif n > lr[1] * 1.3:
                warns.append(f"長い（{n}字）")
        result[row["id"]] = {"job_id": jid, "fails": fails, "warns": warns}
    # 同じ job の台詞に同じ語が3本以上
    sets = []
    for row in rows:
        dialogues, _ = split(row["body"])
        sets.append((row["id"], {w for d in dialogues for w in WORD.findall(d)} - MEANING_WORDS))
    counter = Counter(w for _, s in sets for w in s)
    repeated = {w for w, n in counter.items() if n >= 3}
    for tid, s in sets:
        hit = sorted(s & repeated)
        if hit:
            result[tid]["warns"].append("同じ job の台詞で3本以上の語：" + "・".join(hit))

# 別の job と同じ台詞（同じファイルの中）
by_dialogue = defaultdict(list)
for jid, rows in pool.items():
    for row in rows:
        for d in split(row["body"])[0]:
            if len(d) >= 8:
                by_dialogue[d].append(row["id"])
for d, ids in by_dialogue.items():
    if len({i.rsplit(".v", 1)[0] for i in ids}) > 1:
        for i in ids:
            result[i]["warns"].append("別の job と同じ台詞：" + d)

json.dump(result, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
fails = Counter(f.split("：")[0].split(" ")[0] for r in result.values() for f in r["fails"])
warns = Counter(w.split("：")[0].split("（")[0] for r in result.values() for w in r["warns"])
print("texts", len(result), "with fails", sum(1 for r in result.values() if r["fails"]), "with warns", sum(1 for r in result.values() if r["warns"]))
print("fails", fails.most_common())
print("warns", warns.most_common())
ok_per_job = Counter(r["job_id"] for r in result.values() if not r["fails"])
low = [(j, ok_per_job.get(j, 0)) for j in jobs if ok_per_job.get(j, 0) < 3]
print("jobs with <3 passing", len(low), low[:20])
