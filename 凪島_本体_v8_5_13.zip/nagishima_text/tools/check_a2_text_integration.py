"""Acceptance measurements for the v7.1.1 prose import."""
import json
import re
import sys
from collections import Counter
from pathlib import Path
from tempfile import TemporaryDirectory

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from nagishima.content import Pack
from nagishima.engine import Engine


def choose(engine, identity, commands):
    view = engine.get_view()
    choices = {item["id"]: item for item in view["choices"]}
    if identity not in choices or not choices[identity]["available"]:
        raise AssertionError(f"seed={engine.snapshot()['world']['seed']} commands={commands} unavailable={identity}")
    commands.append(identity)
    return engine.choose(identity, view["revision"], view["session"])


def clear_offer(engine, commands):
    if engine.snapshot()["offer"]:
        choose(engine, "offer.decline", commands)
        if engine.get_view()["page"] != "touch":
            choose(engine, "menu.touch", commands)


def touch_measure(release, seed, action, count=35):
    with TemporaryDirectory(prefix="nagishima-a2-touch-") as directory:
        engine = Engine(Path(directory), seed=seed, release=release, autosave=False, test_cheats=True)
        commands = ["cheat.all"]
        engine.enable_test_cheat("all")
        choose(engine, "near", commands)
        choose(engine, "menu.touch", commands)
        choose(engine, "touch." + action, commands)
        observations = []
        for _ in range(count):
            clear_offer(engine, commands)
            view = choose(engine, "touch." + action, commands)
            blocks = [block for block in view["blocks"] if block["meaning"] in {action + ".continue", action + ".settled"}]
            if not blocks:
                raise AssertionError(f"seed={seed} release={release} commands={commands} missing touch prose")
            observations.append({"meaning": blocks[-1]["meaning"], "variant": blocks[-1]["variant"],
                                 "dialogue": "「" in blocks[-1]["body"] and "」" in blocks[-1]["body"]})
        return {"seed": seed, "release": release, "action": action, "count": len(observations),
                "dialogue": sum(item["dialogue"] for item in observations), "commands": commands}


def kiss_measure(seed, restricted):
    with TemporaryDirectory(prefix="nagishima-a2-kiss-") as directory:
        engine = Engine(Path(directory), seed=seed, release="interaction_008", autosave=False, test_cheats=True)
        commands = ["cheat.all"]
        engine.enable_test_cheat("all")
        choose(engine, "near", commands)
        choose(engine, "menu.touch", commands)
        chosen = []
        for index in range(6):
            clear_offer(engine, commands)
            view = choose(engine, "touch.kiss", commands)
            blocks = [block for block in view["blocks"] if block["meaning"].startswith("kiss.")]
            if blocks:
                chosen.append(blocks[-1]["variant"])
            else:
                raise AssertionError(f"seed={seed} commands={commands} missing kiss prose")
        assert len(chosen) >= 6
        assert engine.pack.registry.values(engine.snapshot())["experience.kiss.tier"] == "familiar"
        clear_offer(engine, commands)
        choose(engine, "touch.head", commands)
        choose(engine, "end.head", commands)
        post_six = []
        for _ in range(2):
            clear_offer(engine, commands)
            view = choose(engine, "touch.kiss", commands)
            blocks = [block for block in view["blocks"] if block["meaning"] in {"kiss.start", "kiss.repeat"}]
            assert blocks, (seed, commands, view["blocks"])
            post_six.append({"meaning": blocks[-1]["meaning"], "variant": blocks[-1]["variant"]})
            assert blocks[-1]["variant"] not in restricted, (seed, commands)
        return {"seed": seed, "count": len(chosen), "post_six": post_six, "commands": commands}


def main():
    pack = Pack(ROOT / "content/releases/interaction_008")
    provenance = json.loads((pack.path / "rules_provenance.json").read_text(encoding="utf-8"))["a2_texts"]
    assert {key: len(value) for key, value in provenance["imported"].items()} == {"J2": 42, "J3": 65, "J4": 48}
    assert all(not pack.by_text[text_id]["fallback"] for values in provenance["imported"].values() for text_id in values)
    assert len(provenance["j1_restricted"]) == 22
    assert len(provenance["quoted_narration_fixes"]) == 24
    assert all(item["when"] == {"all": []} for item in pack.texts if item["fallback"])
    assert not any(re.search(r"「[^「」]*真帆[^「」]*」", item["body"]) for item in pack.texts)
    # An unconditional fallback is a candidate at each familiarity stage.
    assert all(any(item["fallback"] and item["when"] == {"all": []} for item in pack.by_meaning[meaning]) for meaning in pack.meanings)
    measurements = []
    for action in ("hands", "hug", "back"):
        for seed in (42, 20380407):
            measurements.append(touch_measure("interaction_007", seed, action))
            measurements.append(touch_measure("interaction_008", seed, action))
    for item in measurements:
        if item["action"] == "hands" and item["release"] == "interaction_008":
            assert item["count"] >= 30 and item["dialogue"] * 2 <= item["count"], item
        if item["action"] == "hands" and item["release"] == "interaction_007":
            assert item["dialogue"] == item["count"], item
    kisses = [kiss_measure(seed, set(provenance["j1_restricted"])) for seed in (42, 20380407)]
    report = {"imported": {key: len(value) for key, value in provenance["imported"].items()},
              "restricted": len(provenance["j1_restricted"]), "quote_fixes": len(provenance["quoted_narration_fixes"]),
              "measurements": [{key: value for key, value in item.items() if key != "commands"} for item in measurements],
              "kisses": [{key: value for key, value in item.items() if key != "commands"} for item in kisses]}
    output = ROOT / "verification/a2_text_integration.json"
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False))


if __name__ == "__main__":
    main()
