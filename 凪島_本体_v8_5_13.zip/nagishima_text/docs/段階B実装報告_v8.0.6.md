# 段階B 作業中の触れ合い（v8.0.6）

実施：Claude Opus 5.5。起点：v8.0.5。版：本体 2.4.6、rules `nagishima-2.4`、SAVE_SCHEMA 4（変更なし）。新規開始の既定は `interaction_008` のまま。

## 1. 変えたこと

| 項目 | 内容 |
|---|---|
| 作業中の触れ合い | 009 で、食事と同じく「仕事を手伝う」（help）・「道具を手入れする」（repair）を始めるとき・保留から再開するときに、続いている触れ合いを終える。作業の場面で選べる触れ合いは「話しかける」だけ（scenes.json の activity_help・activity_repair。revision 2）。手を使う作業中に手をつないでいられる違和感を直した（v8.0.5 の報告の提案。ユーザーの了承） |
| データ | `tools/stage_b/life_tuning_009.json`：`actions.hands_free` を meal・help・repair に、`scene_micro` に activity_help・activity_repair を足した。本体のコードは変えていない |
| 仕様 | 段階B仕様 6.11 の表の行を直した |
| 試験 | `tests/test_v805_fixes.py` に、手伝い・手入れで触れ合いが終わり、話しかけるだけになる試験と、008 の3つの場面が変わらない試験を足した |

## 2. 検証（Linux、Python 3.11。Opus が実行）

| 検査 | 結果 |
|---|---|
| 全試験（check_runtime） | 306件成功 |
| 本文検証 006〜009 | 4つとも成功 |
| 段階Bの本文の機械検査と B-50 | grok の本文1357本と Opus の本文6本で失敗0、服の警告0 |
| 18経路・job の網羅（19経路） | すべて成功、fallback に落ちたもの0 |
| B-02（旧版互換 24通り） | すべて一致 |
| 自動プレイ 009 | reference 3 seed、social 3 seed、presence 20 seed をすべて cleared で完走し、どれもエッチを1回以上通る（最多195操作／上限200） |
| B-08（完成 ZIP から 009 を作り直す） | 11ファイルすべて一致（`verification/stage_b_zip_rebuild.json`） |

- 実本文で遊ぶ網羅（`verification/stage_b_realplay_*.json`）は v8.0.5 のもの。v8.0.6 はエッチの本文と規則を変えていない。

## 3. 注意

- v8.0.5 の 009 の保存は、場面の定義が変わったため読めない（009 は未公開の試遊版）。008・007 の保存は読める。
- 未確認：Windows の `start.bat` での v8.0.6。
