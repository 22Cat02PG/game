"""v8.2.24（ユーザー 2026-09-30「直すよ」）：申し出と体勢の食い違い、物足りない合図の繰り返し、grok 第14陣（口づけしたまま）。
公開の選択肢（Engine.choose／get_view）から確かめる（高まり・慣れなどの準備だけ内部で行う）。"""
import json
import unittest
from pathlib import Path

from tools.run_stage_b_routes import Route

ROOT = Path(__file__).resolve().parents[1]
SIGNS = ("h.sign.wants_more", "h.sign.wants_more_urge")


def meanings(engine):
    return [b["meaning"] for b in engine.get_view()["blocks"]]


class V8224(unittest.TestCase):
    def route(self, seed, setup, tier="familiar"):
        route = Route(seed, tier=tier, day_offset=2)
        self.addCleanup(route.close)
        route.begin()
        for key in setup:
            route.action(key)
        return route

    def hold(self, route, maho, player=10):
        """準備：真帆とこちらの高まりをその値に置く。"""
        intimate = route.engine._state["intimacy"]
        intimate["maho"].update(arousal=maho, band=route.engine.pack.intimacy.band(maho))
        intimate["player"]["arousal"] = player
        route.engine._install_choices()

    # ---- 1. 「上になる」申し出は、口の最中・高い／もうすぐのときに出さない ----
    def test_no_straddle_offer_while_licking(self):
        offers = []
        for seed in range(9401, 9416):
            route = self.route(seed, ("h_strip_lower", "h_shift_under", "h_pos_lying_face"))
            for _ in range(5):
                self.hold(route, 50)
                route.action("h_player_mouth")
                offer = route.engine.snapshot()["offer"]
                if offer:
                    offers.append(offer["kind"])
                    route.choose("offer.decline")
        self.assertNotIn("h_lead_straddle", offers)

    def test_no_straddle_offer_near_the_peak(self):
        """v8.2.26（ユーザー了承 2026-09-30、精査 D-7）：止めるのは「もうすぐ」だけ（「高い」では出す。test_v8226）。"""
        offers = []
        for seed in range(9421, 9436):
            route = self.route(seed, ("h_strip_lower", "h_strip_self"))
            for _ in range(5):
                self.hold(route, 92)
                route.action("h_kiss_deep")
                offer = route.engine.snapshot()["offer"]
                if offer:
                    offers.append(offer["kind"])
                    route.choose("offer.decline")
        self.assertNotIn("h_lead_straddle", offers)

    def test_straddle_offer_still_comes_while_kissing(self):
        """口づけの最中（真帆の高まりが中くらい）は、これまでどおり出る（いちばん多い出どころ）。"""
        kinds = []
        for seed in range(9441, 9451):
            route = self.route(seed, ("h_strip_lower", "h_strip_self"))
            for _ in range(5):
                self.hold(route, 50)
                route.action("h_kiss_deep")
                offer = route.engine.snapshot()["offer"]
                if offer:
                    kinds.append(offer["kind"])
                    break
        self.assertIn("h_lead_straddle", kinds)

    # ---- 2. 物足りない合図：間を空け、重なると焦れた合図 ----
    def test_wants_more_spacing_and_urge(self):
        route = self.route(9461, ("h_lift_upper", "h_strip_lower", "h_strip_self", "h_pos_lying_face"), tier="few")
        seen = []
        self.hold(route, 85)  # 準備：高い段から。胸に口づけるだけでは頭打ちになり、そこで物足りなさの合図が出る
        for step in range(34):
            route.engine._state["intimacy"]["player"]["arousal"] = 10
            route.engine._install_choices()
            while route.engine.snapshot()["offer"]:
                route.choose("offer.decline")
            route.action("h_chest_mouth")
            for meaning in meanings(route.engine):
                if meaning in SIGNS:
                    seen.append((step, meaning))
        steps = [s for s, _ in seen]
        kinds = [m for _, m in seen]
        self.assertGreaterEqual(len(seen), 3, seen)
        self.assertLessEqual(len(seen), 6, seen)  # これまでは3手おき（30手で10回）
        gaps = [b - a for a, b in zip(steps, steps[1:])]
        config = json.loads((ROOT / "tools/stage_b/intimacy_009.json").read_text(encoding="utf-8"))["b2"]["wants_more"]
        for index, gap in enumerate(gaps):
            self.assertGreaterEqual(gap, config["gaps"][min(index, len(config["gaps"]) - 1)], seen)
        self.assertEqual(kinds[:2], ["h.sign.wants_more"] * 2, seen)
        self.assertTrue(all(kind == "h.sign.wants_more_urge" for kind in kinds[2:]), seen)

    def test_urge_texts(self):
        pack = Route(9470).engine.pack
        urge = [t for t in pack.texts if t["meaning"] == "h.sign.wants_more_urge" and not t["fallback"]]
        self.assertGreaterEqual(len(urge), 36)
        quiet = [t for t in urge if "「" not in t["body"]]
        self.assertGreaterEqual(len(quiet), 6)  # 深い口づけの最中にも出るように、台詞のない本
        for text in urge:
            self.assertNotRegex(text["body"], r"いく|イく|入れて|速く", text["id"])

    # ---- 3. grok 第14陣（口づけしたまま） ----
    def test_wave14_texts_keep_the_kiss(self):
        pack = Route(9480).engine.pack
        rows = [t for t in pack.texts if t["id"].startswith("p14.")]
        self.assertEqual(len(rows), 132)
        for text in rows:
            self.assertNotIn("「", text["body"], text["id"])
            self.assertIn('"contact.h_kiss_deep.active"', json.dumps(text["when"]), text["id"])


if __name__ == "__main__":
    unittest.main()
