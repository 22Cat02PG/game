"""v8.2.23（ユーザー 2026-09-29 18:47「進めて」）：続けている手の短い本文を、高まりで出し分ける（熱さの札）・声だけの行・台詞のあとで改行。
公開の選択肢（Engine.choose／get_view）から確かめる（高まり・慣れなどの準備だけ内部で行う）。"""
import json
import re
import unittest
from pathlib import Path

from tools.run_stage_b_routes import Route

ROOT = Path(__file__).resolve().parents[1]
DATA = json.loads((ROOT / "tools/stage_b/short_texts.json").read_text(encoding="utf-8"))["texts"]
HEAT = {("sh." if row["cut"] == 1 else "sh2.") + row["source"]: row.get("heat") for row in DATA}


def blocks(engine):
    return engine.get_view()["blocks"]


class V8223(unittest.TestCase):
    def connect(self, seed, tier="few", position="h_pos_player_above"):
        route = Route(seed, tier=tier, day_offset=2)
        self.addCleanup(route.close)
        route.begin()
        for key in ("h_strip_lower", "h_shift_under", "h_strip_self", position):
            route.action(key)
        route.engine._state["intimacy"]["maho"].update(arousal=45, band="mid")  # 準備：入れられるところまで
        route.engine._install_choices()
        route.action("h_insert")
        return route

    def hold(self, route, maho):
        """準備：真帆の高まりをその段に置き、こちらは限界にならないようにする。"""
        intimate = route.engine._state["intimacy"]
        intimate["maho"].update(arousal=maho, band=route.engine.pack.intimacy.band(maho))
        intimate["player"]["arousal"] = 10
        route.engine._install_choices()

    def shown(self, route, key, maho, times):
        found = []
        for _ in range(times):
            self.hold(route, maho)
            while route.engine.snapshot()["offer"]:
                route.choose("offer.decline")
            route.action(key)
            found += [b for b in blocks(route.engine) if b["meaning"] == key + ".continue_short"]
        return found

    # ---- 1. 熱さの札：山場に落ち着いた行を出さない ----
    def test_peak_has_no_early_lines(self):
        seen = []
        for seed in (8301, 8302, 8303):
            route = self.connect(seed)
            seen += self.shown(route, "h_move_slow", 85, 12)
        self.assertGreater(len(seen), 20)
        for block in seen:
            variant = block["variant"]
            self.assertNotEqual(HEAT.get(variant), "early", block)
            self.assertNotIn(".h1.", variant, block)  # 新しく書いた行の前半
        self.assertTrue(any(HEAT.get(b["variant"]) == "late" or ".h2." in b["variant"] for b in seen))

    def test_start_has_no_late_lines(self):
        seen = []
        for seed in (8311, 8312):
            route = self.connect(seed)
            seen += self.shown(route, "h_move_slow", 20, 12)
        self.assertGreater(len(seen), 15)
        for block in seen:
            self.assertNotEqual(HEAT.get(block["variant"]), "late", block)
            self.assertNotIn(".h2.", block["variant"], block)

    def test_service_heat_follows_player(self):
        """してもらう行為（手）は、こちらの高まりで出し分ける。"""
        route = Route(8321, tier="few", day_offset=2)
        self.addCleanup(route.close)
        route.begin()
        for key in ("h_lift_upper", "h_strip_lower", "h_strip_self", "h_pos_lying_face"):
            route.action(key)
        seen = []
        for _ in range(10):
            intimate = route.engine._state["intimacy"]
            intimate["player"]["arousal"] = 10
            intimate["maho"].update(arousal=30, band="low")
            route.engine._install_choices()
            while route.engine.snapshot()["offer"]:
                route.choose("offer.decline")
            route.action("h_maho_hand")
            seen += [b for b in blocks(route.engine) if b["meaning"] == "h_maho_hand.continue_short"]
        self.assertGreater(len(seen), 5)
        for block in seen:
            self.assertNotEqual(HEAT.get(block["variant"]), "late", block)
            self.assertNotIn(".h2.", block["variant"], block)

    # ---- 2. 声だけの行 ----
    def test_voice_lines_show_near_the_peak(self):
        seen = []
        for seed in range(8331, 8337):
            route = self.connect(seed)
            seen += self.shown(route, "h_move_normal", 85, 6)
        voices = [b for b in seen if b["variant"].startswith("v.")]
        self.assertTrue(voices, [b["variant"] for b in seen])
        for block in voices:
            self.assertRegex(block["body"], r"^「[^「」\n]{3,20}」$")

    def test_voice_lines_are_grouped_as_their_own_kind(self):
        pack = Route(8340).engine.pack
        voices = [t for t in pack.texts if t["id"].startswith("v.")]
        self.assertGreater(len(voices), 600)
        for text in voices:
            self.assertTrue(text["group"].endswith(".v"), text["id"])
            self.assertFalse(re.search(r"[!?]", text["body"]), text["id"])

    # ---- 3. 台詞・声と地の文のあいだで改行 ----
    def test_short_lines_break_after_speech(self):
        pack = Route(8350).engine.pack
        checked = 0
        for text in pack.texts:
            if text["fallback"] or not text["meaning"].endswith(".continue_short") or "「" not in text["body"]:
                continue
            body = text["body"]
            if re.fullmatch(r"「[^「」]*」", body):
                continue  # 台詞だけ・声だけ
            checked += 1
            self.assertIn("\n", body, text["id"])
            for line in body.split("\n"):
                self.assertTrue(line)
                self.assertFalse("「" in line and not (line.startswith("「") and line.endswith("」")), text["id"])
        self.assertGreater(checked, 3000)

    # ---- 4. 達したと読める言い方（遊び回りで見つかった2本）----
    def test_no_ambiguous_iku(self):
        pack = Route(8360).engine.pack
        for identity in ("p2.h_maho_mouth.start.familiar.s.v3", "p1.h.sign.wants_more.familiar.back.s.v1"):
            self.assertNotIn("いくよ", pack.by_text[identity]["body"], identity)


if __name__ == "__main__":
    unittest.main()
