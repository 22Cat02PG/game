"""v8.3.8（ユーザー 2026-10-03）：010 だけ。
「触れた胸から、乳輪の感触までこちらに伝わる。遊ぶとそっこーでこれ出てきたけど？触ってない」「このままだと延々に漏れる」→「手分けして読む」。
エッチの本文 25,607 本（短い一行を含む）を言葉の検索ではなく全部読み、プレイヤーがしていない行為の描写に条件を足すか書き換えた。"""
import json
import re
import unittest
from pathlib import Path

from nagishima.content import Pack

ROOT = Path(__file__).resolve().parents[1]
P009 = Pack(ROOT / "content/releases/interaction_009")
P010 = Pack(ROOT / "content/releases/interaction_010")
LAYER = json.loads((ROOT / "tools/stage_b/release_010.json").read_text(encoding="utf-8"))
NOTE = "全文の読み直し"
TOKEN = re.compile(r"\{[a-z_]+\}")


class V838(unittest.TestCase):
    def test_reported_line(self):
        """ユーザーの指摘：「触れた胸から、乳輪の感触までこちらに伝わる。」（触っていない）"""
        identity = "sh.x4.h_move_slow.continue.first.lying_face.n.v5"
        self.assertIn("触れた{breasts}から", P009.by_text[identity]["body"])
        self.assertNotIn("触れた{breasts}から", P010.by_text[identity]["body"])
        self.assertIn("こちらの胸に", P010.by_text[identity]["body"])

    def test_rewrites_keep_slots(self):
        """全文の読み直しで書き換えた本文：もとと違い、もとにない差し込みを足していない。"""
        fixes = [f for f in LAYER["fixes"]["body"] if NOTE in f["_note"]]
        self.assertGreaterEqual(len(fixes), 400)
        removed = {i for p in LAYER["fixes"].get("remove", []) for i in p["ids"]}  # v8.3.9b：本文ごと消したもの
        for fix in fixes:
            self.assertNotEqual(fix["orig"], fix["body"], fix["id"])
            self.assertLessEqual(set(TOKEN.findall(fix["body"])), set(TOKEN.findall(fix["orig"])), fix["id"])
            if fix["id"] not in removed:
                self.assertEqual(P010.by_text[fix["id"]]["body"], fix["body"], fix["id"])

    def test_rewrite_samples(self):
        samples = {
            "q.h_ear_neck.familiar.f.h1.v14": "髪、撫でてて",  # 髪を撫でる（選んでいない）
            "o38.h_after_hold.start.s.v2": "髪を指で梳く",
            "q.h_move_slow.few.g3.h1.v5": "背骨のくぼみを指でなぞる",  # ゲームにない行為
            "x3.h_move_fast.start.familiar.prone_back.s.v4": "{clitoris}を押さえたまま",  # 入れているのに指で陰核
            "o37.h.hold_back.accepted.n.v1": "抱き寄せると",
            "p12.h_maho_hand_slow.continue.few_familiar.n.v1": "もどかしさ",  # 気持ちの決めつけ
        }
        for identity, phrase in samples.items():
            self.assertIn(phrase, P009.by_text[identity]["body"], identity)
            self.assertNotIn(phrase, P010.by_text[identity]["body"], identity)
        identity = "sh.p5.h_move_slow.continue.first.lying_face.n.v1"  # 誰の指か分からない短い一行
        self.assertTrue(P009.by_text[identity]["body"].startswith("背中を往復する指"))
        self.assertTrue(P010.by_text[identity]["body"].startswith("こちらの背中を往復する指"))

    def test_condition_samples(self):
        finger = ("contact.h_touch_under.active", "contact.h_touch_direct.active", "contact.h_finger_in.active")
        for identity in ("b1.h.climax.maho.first.not_inserted.n.v6", "x5.h.climax.maho.few.not_inserted.s.v1"):
            for field in finger:
                self.assertNotIn(field, str(P009.by_text[identity]["when"]), identity)
                self.assertIn(field, str(P010.by_text[identity]["when"]), identity)
        for identity in ("x2.h_move_slow.start.few.sitting_face.s.v5", "sh2.x2.h_move_normal.continue.few.maho_above.s.v4"):  # v8.3.9：x5.h_chest_mouth.start.few.n.v3 は満たせない条件だったので外した（test_v839）
            self.assertNotIn("contact.h_chest_skin.active", str(P009.by_text[identity]["when"]), identity)
            self.assertIn("contact.h_chest_skin.active", str(P010.by_text[identity]["when"]), identity)
        self.assertIn("contact.h_chest_mouth.active", str(P010.by_text["sh.x2.h_move_fast.continue.familiar.player_above.s.v2"]["when"]))
        # v8.3.9：q.h_touch_direct_slow.familiar.all.h1.v10 の太ももの条件は、秘所に触れている最中に満たせないので外して本文を直した（test_v839）

    def test_first_climax_needs_finger(self):
        """初めての回の入れていない絶頂は、指の本文しかない（指の条件を足した）。初めての回で高まりを上限まで上げられる入れない行為（入れる行為そのものを除く）が、指で直に触れるだけであること。"""
        reach = [k for k, a in P010.intimacy.actions.items()
                 if a["needs"].get("inserted") is not True and a["sets"].get("inserted") is not True and a["needs"].get("tier_from") == "first" and a["effects"].get("maho_arousal", 0) > 0
                 and a["effects"].get("maho_arousal_cap", 100) >= 100]
        self.assertEqual(reach, ["h_touch_direct"])


if __name__ == "__main__":
    unittest.main()
