"""別係の監査（v8.1.1、2026-09-27）の指摘と、4回目の試運転の指摘1・3への対応の試験（v8.2.0）。公開の選択肢から確かめる（時刻・欲求・場所などの準備だけ内部で行う）。"""
import unittest

from tools.run_stage_b_routes import Route


def choices(route):
    return {c["id"]: c for c in route.engine.get_view()["choices"]}


def meanings(route):
    return [b["meaning"] for b in route.engine.get_view()["blocks"]]


def touch(route, key):
    while route.engine.snapshot()["offer"]:
        route.choose("offer.accept" if route.engine.snapshot()["offer"]["kind"] == "kiss_back" else "offer.decline")
    if route.engine.get_view()["page"] != "touch":
        route.choose("menu.touch")
    route.choose("touch." + key)


def prepare(route, location=None, desire=None):
    state = route.engine._state
    if location:
        for actor in state["actors"].values():
            actor["location"] = location
    if desire is not None:
        state["desire"] = desire
    route.engine._install_choices()


class AuditV821(unittest.TestCase):
    def route(self, *args, **kwargs):
        route = Route(*args, **kwargs)
        self.addCleanup(route.close)
        return route

    def kissed(self, route):
        route.choose("near")
        for key in ("kiss", "kiss", "kiss"):
            touch(route, key)

    def test_h01_move_hint_includes_clothing_steps_for_insert(self):
        route = self.route(3, tier="few", day_offset=2)
        route.begin()
        route.action("h_strip_self")
        route.choose("menu.main")
        route.choose("menu.h_connect")
        reason = route.engine.get_view()["explanations"]["touch.h_move_slow"]
        self.assertIn("「下を脱がせる」", reason)
        self.assertTrue(reason.endswith("「ゆっくり入れる」でつながる。"), reason)

    def test_l01_late_night_deflect_is_not_about_work(self):
        route = self.route(13, tier="few", hour=21, minute=20, day_offset=1)  # 木曜の夜（翌日は仕事。締め切り 22:00）
        self.kissed(route)
        prepare(route, desire=0)
        touch(route, "deep_kiss")
        self.assertIn("gate.react.deflect_late", meanings(route))
        self.assertNotIn("gate.react.deflect_time", meanings(route))

    def test_l02_invite_inside_a_private_room_starts_here(self):
        route = self.route(6, tier="few", hour=14, day_offset=3)
        prepare(route, location="player_room", desire=70)
        self.kissed(route)
        touch(route, "deep_kiss")
        self.assertIn("gate.react.invite_here", meanings(route))
        route.choose("offer.accept")
        state = route.engine.snapshot()
        self.assertIsNotNone(state["intimacy"])
        self.assertEqual(state["actors"]["player"]["location"], "player_room")  # 真帆の部屋へ移らない
        self.assertIn("h.begin.invite_here", meanings(route))

    def test_l03_no_private_offer_within_an_hour_of_work(self):
        route = self.route(7, tier="few", hour=7, minute=45, day_offset=2)  # 木曜 7:45、仕事は 8:30 から
        route.choose("near")
        touch(route, "hands")
        route.choose("menu.main")
        route.choose("menu.talk")
        route.choose("touch.affection")
        offer = route.engine.snapshot()["offer"]
        self.assertFalse(offer and offer["kind"] == "private")

    def test_h02_climax_on_the_inserting_action_is_inserted(self):
        route = self.route(8, tier="familiar", day_offset=2)
        route.begin()
        for key in ("h_lift_upper", "h_strip_lower", "h_shift_under", "h_strip_self", "h_pos_player_above"):
            route.action(key)
        state = route.engine._state
        state["intimacy"]["maho"]["arousal"] = 98  # 準備：達する手前
        route.engine._install_choices()
        route.action("h_insert")
        maho = route.engine.snapshot()["intimacy"]["maho"]
        self.assertEqual(maho["climaxes"], 1)
        self.assertEqual(maho["climax_source"], "inserted")

    def test_t207_first_after_h_texts_are_skipped_after_the_same_act_in_h(self):
        pack = self.route(9).engine.pack
        for text in pack.texts:
            if text["id"].startswith("p3.ear_kiss.first.after_h"):
                self.assertIn('"experience.h_ear_neck.count"', str(text["when"]).replace("'", '"'))

    def test_1_chest_under_while_hand_is_under_clothes(self):
        route = self.route(10, tier="few", hour=16, day_offset=3)
        prepare(route, location="player_room", desire=10)
        self.kissed(route)
        touch(route, "deep_kiss")
        if route.engine.get_view()["page"] != "touch":
            route.choose("menu.touch")
        self.assertFalse(choices(route)["touch.chest_under"]["available"])
        self.assertIn("服の中に手を入れる", route.engine.get_view()["explanations"]["touch.chest_under"])
        touch(route, "under_clothes")
        prepare(route, desire=70)  # 誘う水準（深いキスで「許す」は使ったので、次は誘い）
        touch(route, "chest_under")
        found = meanings(route)
        self.assertTrue(any(m.startswith("chest_under.") for m in found))
        self.assertIn("gate.react.invite_here", found)
        contacts = [c["action_id"] for c in route.engine.snapshot()["contacts"]]
        self.assertNotIn("under_clothes", contacts)  # 同じ手なので置き換わる

    def _connected(self, seed):
        route = self.route(seed, tier="familiar", day_offset=2)
        route.begin()
        for key in ("h_strip_lower", "h_shift_under", "h_strip_self", "h_pos_player_above"):
            route.action(key)
        for _ in range(20):
            if route.engine.snapshot()["intimacy"]["maho"]["arousal"] >= 60:
                break
            route.action("h_kiss_deep")
        route.action("h_insert")
        return route

    def _variants(self, route, head):
        return [b["variant"] for b in route.engine.get_view()["blocks"] if b["meaning"].startswith(head + ".")]

    def test_3_dense_texts_follow_arousal_not_a_setting(self):
        """v8.2.2：濃い本文は設定でなく高まりで出る。低いうちは出ず、高まると先に出る。達する・出す場面は山として濃い本文。"""
        pack = self.route(11).engine.pack
        self.assertGreaterEqual(sum(1 for t in pack.texts if t.get("style") == "explicit"), 2500)
        route = self.route(11, tier="familiar", day_offset=2)
        route.choose("menu.settings")
        self.assertFalse(any(c["id"].startswith("settings.density.") for c in route.engine.get_view()["choices"]))
        route.choose("menu.main")
        # 低い：始めたばかりの触れ合い（胸に直接触れる。濃い本文はあるが出ない）
        low = self.route(12, tier="familiar", day_offset=2)
        low.begin()
        low.action("h_lift_upper")
        state = low.engine.snapshot()["intimacy"]
        self.assertLess(state["maho"]["arousal"], 40)
        low.action("h_chest_skin")
        seen = self._variants(low, "h_chest_skin")
        self.assertTrue(seen and not any(v.startswith("x") for v in seen), seen)
        # 高い：真帆の高まりが高い（準備：内部で高まりだけを上げる）と、動く本文は濃い本文が先
        high = self._connected(13)
        high.engine._state["intimacy"]["maho"]["arousal"] = 85
        high.engine._state["intimacy"]["maho"]["band"] = "high"
        high.engine._install_choices()
        high.action("h_move_normal")
        seen = self._variants(high, "h_move_normal")
        self.assertTrue(seen and seen[0].startswith("x"), seen)
        # 山：中で出す場面は、高まりによらず濃い本文が先
        peak = self._connected(14)
        peak.engine._state["intimacy"]["player"]["arousal"] = 75  # 準備：出せるところまで
        peak.engine._state["intimacy"]["maho"]["arousal"] = 45
        peak.engine._install_choices()
        peak.action("h_finish_inside")
        seen = self._variants(peak, "h_finish_inside")
        self.assertTrue(seen and seen[0].startswith("x"), seen)

    def test_3b_high_falls_back_to_fresh_standard_when_all_dense_are_recent(self):
        pack = self.route(15).engine.pack
        state = self.route(15, tier="familiar", day_offset=2)
        route = self._connected(15)
        state = route.engine.snapshot()
        state["intimacy"]["maho"]["arousal"] = 85
        meaning = "h_move_normal.continue"
        values = pack.registry.values(state)
        from nagishima.conditions import evaluate
        dense = [t for t in pack.by_meaning[meaning] if t.get("style") and evaluate(t["when"], values) is True]
        self.assertTrue(dense)
        state["recent_text"] = [{"id": t["id"], "group": t["group"], "release": pack.id} for t in dense]
        chosen = pack.select(meaning, state, {"penis": "a", "vagina": "b", "semen": "c", "breasts": "d", "nipple": "e", "clitoris": "f", "love_juice": "g"}, values)[0]["variant"]
        self.assertFalse(chosen.startswith("x"), chosen)

if __name__ == "__main__":
    unittest.main()
