from .codec import clone_state
from .conditions import evaluate
from .context import Context
from .errors import GameError, ensure
from .progression import MILESTONE_SCENES
from .labels import CONTINUE_LABELS, END_LABELS
from .state import validate_state

PAGES = {"main": "いつもの時間", "talk": "話す", "touch": "触れ合う", "activities": "一緒に過ごす", "move": "移動する", "plans": "約束と共同作業", "orders": "買い物", "inventory": "所持品", "memories": "思い出", "inbox": "便り", "appearance": "身支度", "resume": "保留した話", "h_entry": "触れ方を深める", "h_touch": "触れる", "h_close": "手と体", "h_clothes": "服", "h_position": "体位", "h_connect": "つながる", "h_service": "してもらう・自分で", "h_words": "言葉と余韻", "records": "二人の記録", "settings": "設定", "settings_terms": "呼び方を1つずつ選ぶ"}

AUTO_SPEED_LABELS = {"slow": "ゆっくり", "normal": "ふつう", "fast": "はやい", "off": "切"}  # v8.2.28
STAGE_B_PAGES = {"h_entry", "h_touch", "h_close", "h_clothes", "h_position", "h_connect", "h_service", "h_words", "records", "settings", "settings_terms"}
INTIMACY_PAGES = {"h_touch": {"kiss", "caress"}, "h_close": set(), "h_clothes": {"undress"}, "h_position": {"position"}, "h_connect": {"insert", "move", "finish", "tease", "grind"}, "h_service": {"service", "self", "mutual"}, "h_words": {"words", "after"}}
QUICK_ACTIONS = ("h_stroke_head", "h_finish_inside", "h_finish_outside", "h_finish_hand", "h_finish_mouth", "h_finish_sumata", "h_finish_breasts", "h_finish_feet", "h_finish_sixty_nine",
                 "h_extra_lick", "h_extra_balls", "h_endure", "h_withdraw", "h_wipe", "h_after_hold")


def _pages(rules):
    """v8.4.0（010）：使う頁だけ（手と体＝h_close は、settings.action_pages で行為を置いた版だけ。v8.4.1 で「寄り添う」から名前を変えた）。"""
    used = set(rules.action_pages.values())
    return [key for key, categories in INTIMACY_PAGES.items() if categories or key in used]


def _in_page(rules, key, page):
    """v8.4.0（010）：行為の頁（settings.action_pages があればそれ、なければ種類で）。"""
    if key in rules.action_pages:
        return rules.action_pages[key] == page
    return rules.actions[key]["category"] in INTIMACY_PAGES[page]


def _overflow_label(state, rules, key, label):
    """B2：限界のまま続けると出る行動には、そのことを添える。"""
    at_max = state["intimacy"]["player"]["arousal"] >= rules.raw["player"]["arousal_max"]
    if key in rules.b2["overflow"] and at_max and not (rules.actions[key]["sets"]["inserted"] is True and state["intimacy"]["inserted"]):
        return label + "（もうこらえきれない）"
    if at_max and rules.limit_caress is not None and rules.actions[key]["category"] in ("kiss", "caress"):
        # v8.2.29：限界のまま口づけ・愛撫をしても、真帆の手・真帆の動きが続いていれば、こらえきれずに出る
        active = {c["action_id"] for c in state["contacts"]}
        leads = set(rules.stroke["lead_actions"]) if key == "h_stroke_head" and rules.stroke else set()
        if "h_maho_hand" in active or "h_maho_move" in active and state["intimacy"]["inserted"] or active & leads:
            return label + "（もうこらえきれない）"
    return label


def _position_label(state, rules, key, label):
    """v8.3.3（依頼 C）：体位で名前が変わる行動（膝の上で向かい合うときは「下から揺すり上げる」）。010 の設定 action_position_labels。"""
    return rules.settings.get("action_position_labels", {}).get(key, {}).get(state["intimacy"]["position"], label)


def _thrust_hides_moves(state, rules):
    """v8.3.3（依頼 C）：上に乗った真帆が動いているときは、こちらの動き3つの代わりに「下から突き上げる」を出す。"""
    thrust = rules.settings.get("thrust_up")
    return bool(thrust) and state["intimacy"]["position"] in rules.actions[thrust["action"]]["positions"] and any(c["action_id"] == thrust["with"] for c in state["contacts"])


SIDE_NAMES = {"right": "右", "left": "左"}


def _side_label(rules, key, active, current, target):
    """v8.2.29（ユーザー 2026-09-30）：胸に触れる左右の選択肢の名前。active：その行為が続いているか、current：いまの左右、target：選ぶ左右。"""
    over, mouth = key == "h_chest_over", key == "h_chest_mouth"
    where = "両胸" if target == "both" else SIDE_NAMES[target] + "の胸"
    if not active:
        return ("服の上から" + where + "に触れる") if over else (where + "に口づける") if mouth else (where + "に直接触れる")
    if target == current:
        return ("服の上から" + where + "に触れ続ける") if over else (where + "に口づけ続ける") if mouth else (where + "に触れ続ける")
    if mouth:
        return where + "に口を移す"
    if target == "both":
        return SIDE_NAMES["left" if current == "right" else "right"] + "の胸にも触れる"
    return where + ("だけに触れる" if current == "both" else "に手を移す")


def _named_side_label(labels, active, current, target):
    """v8.4.0（010）：手をつなぐの左右の名前（settings.touch_sides の labels）。"""
    if not active:
        return labels["start"][target]
    return labels["keep"] if target == current else labels["switch"][target]


def _chest_entries(state, rules, add, key):
    """v8.2.29：胸に触れる行為の選択肢（touch.<行為>＝既定の左右、side.<行為>.<左右>＝ほかの左右）。v8.4.0：既定は rules.default_side（手をつなぐは向きで決まる）。"""
    active = any(c["action_id"] == key for c in state["contacts"])
    default = rules.default_side(state, key)
    current = rules.side_of(state, key) if active else None
    def label(target):
        if key in rules.side_labels:
            return _named_side_label(rules.side_labels[key], active, current, target)
        return _side_label(rules, key, active, current, target)
    add("touch." + key, _overflow_label(state, rules, key, label(default)), "intimacy.action", id=key)
    for side in rules.side_choices(state, key):  # v8.4.2：片手がふさがっていれば、両方は出さない
        if side != default:
            add(f"side.{key}.{side}", _overflow_label(state, rules, key, label(side)), "intimacy.side", id=key, side=side)


def _end_label(state, rules, key, action):
    """続けている動作をやめる名前。入れていない限界で手・口を止めてもらうのは、こらえること（v8.2.7、精査 A-01）。"""
    label = action.get("end_label", action["label"] + "をやめる")
    if key in ("h_maho_hand", "h_maho_mouth", "h_sumata", "h_maho_breasts", "h_maho_feet", "h_sixty_nine") and not state["intimacy"]["inserted"] and _intimacy_shape(state, rules, "h_endure"):
        label += "（こらえる）"
    return label


def _pace_entries(state, rules, add):
    """v8.2.13：最後にした、続いている行為の速さを変える（いつもの画面。口でしてもらうは3段の名前）。"""
    focus, pace = rules.pace_of(state)
    if focus is None:
        return
    order = ["slow", "normal", "fast"]
    # 限界のまま選ぶと、こらえきれずに出る（続けるのと同じ印。読み手の指摘 R-3）
    names = rules.pace["mouth_labels"] if focus == "h_maho_mouth" else rules.pace.get("named_labels", {}).get(focus)  # v8.2.21：胸に口づけるも3段の名前
    if names:
        for other in order:
            if other != pace:
                add(f"pace.{focus}.{other}", _overflow_label(state, rules, focus, names[other]), "intimacy.pace", id=focus, pace=other)
        return
    labels = rules.pace["labels"].get(focus) or rules.pace["labels"]["service" if rules.pace["actions"][focus] == "player" else "own"]  # v8.2.14：行為ごとの名前（真帆に動いてもらう）
    index = order.index(pace)
    if index < 2:
        add(f"pace.{focus}.{order[index + 1]}", _overflow_label(state, rules, focus, labels["up"]), "intimacy.pace", id=focus, pace=order[index + 1])
    if index > 0:
        add(f"pace.{focus}.{order[index - 1]}", _overflow_label(state, rules, focus, labels["down"]), "intimacy.pace", id=focus, pace=order[index - 1])


def _led_main(state, rules, add):
    """v8.3.3（依頼 B）：真帆が申し出て上になった・自分から入れた回で、真帆が動いているあいだの最初の画面。
    上から 任せる・もっとゆっくり・もっと激しく・止めてもらう、そのあとに 続けている触れ方・頭をなでる・下から突き上げる・こらえる・出す、最後に 終える。"""
    move = rules.actions["h_maho_move"]
    add("touch.h_maho_move", _overflow_label(state, rules, "h_maho_move", rules.settings["maho_led_moves"]["keep_label"]), "intimacy.action", id="h_maho_move")
    pace = state["intimacy"]["paces"].get("h_maho_move", "normal")
    labels = rules.pace["labels"]["h_maho_move"]
    if pace != "slow":
        add("pace.h_maho_move." + ("slow" if pace == "normal" else "normal"), _overflow_label(state, rules, "h_maho_move", labels["down"]), "intimacy.pace", id="h_maho_move", pace="slow" if pace == "normal" else "normal")
    if pace != "fast":
        add("pace.h_maho_move." + ("fast" if pace == "normal" else "normal"), _overflow_label(state, rules, "h_maho_move", labels["up"]), "intimacy.pace", id="h_maho_move", pace="fast" if pace == "normal" else "normal")
    add("end.h_maho_move", _end_label(state, rules, "h_maho_move", move), "intimacy.stop", id="h_maho_move")
    for contact in state["contacts"]:
        key = contact["action_id"]
        if key not in rules.actions or key == "h_maho_move":
            continue
        if key in rules.sides:
            _chest_entries(state, rules, add, key)
        else:
            add("touch." + key, _overflow_label(state, rules, key, rules.actions[key].get("continue_label", rules.actions[key]["label"] + "を続ける")), "intimacy.action", id=key)
        add("end." + key, _end_label(state, rules, key, rules.actions[key]), "intimacy.stop", id=key)
    thrust = rules.settings.get("thrust_up")
    for key in ("h_stroke_head",) + ((thrust["action"],) if thrust else ()) + tuple(k for k in QUICK_ACTIONS if k != "h_stroke_head"):
        if key in rules.actions and _intimacy_shape(state, rules, key):
            add("touch." + key, _overflow_label(state, rules, key, _position_label(state, rules, key, rules.actions[key]["label"])), "intimacy.action", id=key)
    focus, _ = rules.pace_of(state)
    if focus and focus != "h_maho_move":
        _pace_entries(state, rules, add)
    add("h.end", "終える（余力が尽きた）" if state["stamina"]["value"] == 0 else "終える", "intimacy.end")
    for key in _pages(rules):
        add("menu." + key, PAGES[key], "menu", page=key, offset=0)


def intimacy_entries(state, pack, page):
    result = []
    def add(identity, label, op, **args): result.append((identity, label, {"op": op, **args}))
    rules = pack.intimacy
    if state["intimacy"]:
        if page == "main" and rules.settings.get("maho_led_moves") and any(c["action_id"] == "h_maho_move" for c in state["contacts"]) and rules.maho_led(state):
            _led_main(state, rules, add)  # v8.3.3（依頼 B）：真帆が申し出て上になった回、真帆が動いているあいだの並び
            return result
        if page == "main":
            add("h.end", "終える（余力が尽きた）" if state["stamina"]["value"] == 0 else "終える", "intimacy.end")
            active = [c for c in state["contacts"] if c["action_id"] in rules.actions]
            for contact in active:
                key = contact["action_id"]
                action = rules.actions[key]
                if key in rules.sides:
                    _chest_entries(state, rules, add, key)  # v8.2.29：続けている側と、ほかの左右への切り替え
                else:
                    add("touch." + key, _overflow_label(state, rules, key, action.get("continue_label", action["label"] + "を続ける")), "intimacy.action", id=key)
                add("end." + key, _end_label(state, rules, key, action), "intimacy.stop", id=key)
            for key in QUICK_ACTIONS:
                action = rules.actions[key]
                if _intimacy_shape(state, rules, key):
                    add("touch." + key, _overflow_label(state, rules, key, action["label"]), "intimacy.action", id=key)  # v8.2.29：限界で頭をなでる（確かめ役 F-2）
            thrust = rules.settings.get("thrust_up")
            if thrust and _intimacy_shape(state, rules, thrust["action"]):
                key = thrust["action"]
                add("touch." + key, _position_label(state, rules, key, rules.actions[key]["label"]), "intimacy.action", id=key)  # v8.3.3（依頼 C）
            _pace_entries(state, rules, add)
            for key in _pages(rules):
                add("menu." + key, PAGES[key], "menu", page=key, offset=0)
            return result
        if page in INTIMACY_PAGES:
            blocked = []
            for key, action in rules.actions.items():
                if action["offer_only"] or not _in_page(rules, key, page):
                    continue
                if key in EXTRA_KEYS and not _intimacy_shape(state, rules, key):
                    continue  # v8.2.9：追加は、その行為をしてもらっている最中だけ並べる
                if key in ("h_move_slow", "h_move_normal", "h_move_fast") and _thrust_hides_moves(state, rules):
                    continue  # v8.3.3（依頼 C）：上に乗った真帆が動いているあいだは「下から突き上げる」だけ
                thrust = rules.settings.get("thrust_up")
                if thrust and key == thrust["action"] and not _intimacy_shape(state, rules, key):
                    continue  # 真帆が動いていないときは並べない（こちらの動き3つが出る）
                # v8.0.8：条件が合わない行動も隠さず、何をすれば選べるかを理由に出す（試運転の指摘）。
                active = any(c["action_id"] == key for c in state["contacts"])
                label = action.get("continue_label", action["label"] + "を続ける") if active else action["label"]
                if key in rules.sides:
                    _chest_entries(state, rules, add, key)  # v8.2.29：両方・右・左（口づけるは右・左）
                else:
                    add("touch." + key, _overflow_label(state, rules, key, _position_label(state, rules, key, label)), "intimacy.action", id=key)
                if active:
                    add("end." + key, _end_label(state, rules, key, action), "intimacy.stop", id=key)
                elif not _intimacy_shape(state, rules, key):
                    blocked.append(key)
            focus, _ = rules.pace_of(state)
            if focus and _in_page(rules, focus, page):
                _pace_entries(state, rules, add)  # v8.2.13：そのページの行為なら、ページでも速さを変えられる（読み手の指摘 M-4）
            if page != "h_position":
                # v8.2.0：体位が合わずに選べない行動があれば、その体位へ移る行動をこのページに並べる（4回目の試運転の指摘6・7）
                shown = {row[0] for row in result}
                # v8.4.0（010）：頁「手と体」（v8.4.0 では「寄り添う」）を足して、ほかの頁への行き先が1つ増えた。体位の近道は、選択肢の上限 32 に収まる分だけ並べる
                # （顔にまたがって舐めてもらっている最中の「触れる」が 33 になった。009 は上限を超えたことがないので、並びは変わらない）
                room = 32 - len(result) - len([key for key in _pages(rules) if key != page]) - 1
                for move in _position_moves(state, rules, blocked)[:6]:
                    if room <= 0:
                        break
                    if "touch." + move not in shown:
                        room -= 1
                        add("touch." + move, "体位を変える：" + rules.actions[move]["label"], "intimacy.action", id=move)
                        shown.add("touch." + move)
            for key in _pages(rules):
                if key != page:
                    add("menu." + key, "→ " + PAGES[key], "menu", page=key, offset=0)  # ほかのページへ直接（v8.2.0、指摘7）
            add("menu.main", "エッチの時間へ", "menu", page="main", offset=0)
            return result
    if page == "h_entry" and state["mode"] == "private":
        position = rules.raw["session"]["start_position"]["seated"] if all(state["actors"][a]["posture"] == "seated" for a in ("player", "maho")) else rules.raw["session"]["start_position"]["other"]
        for key, action in rules.actions.items():
            if action["entry"] and position in action["positions"]:
                add("touch." + key, action["label"], "intimacy.entry", id=key)
        add("menu.main", "いつもの時間へ", "menu", page="main", offset=0)
        return result
    if page == "records" and state["mode"] in ("normal", "private") and not state["intimacy"] and not state["scene"] and not state["offer"] and state["intimacy_history"]["count"] > 0:
        # v8.2.12：二人の記録（中身は get_view の record。見るだけで、時間・乱数は進めない）
        add("menu.main", "二人の時間へ" if state["mode"] == "private" else "いつもの時間へ", "menu", page="main", offset=0)
        return result
    if page == "settings" and state["mode"] in ("normal", "private") and not state["intimacy"] and not state["scene"] and not state["offer"]:
        term_labels = {"penis": "男性器", "vagina": "女性器", "semen": "精液", "breasts": "胸", "nipple": "乳首", "clitoris": "陰核", "love_juice": "愛液"}
        density_labels = {"standard": "標準", "explicit": "濃い"}
        speech_labels = {"few": "少なめ", "standard": "標準", "many": "多め"}
        gauge_labels = {"hidden": "隠す", "shown": "表示する"}
        # v8.2.29（ユーザー 2026-09-30）：呼び方のひな形は、例の語を添える（「控えめ／露骨」だけでは何が変わるかわからなかった）。
        # 1つずつ選ぶのは別のページ（設定の画面が長くなりすぎるため）。009 では「台詞の多さ」「続けるときの本文」を選ばせない（作品側で決める）
        simple = bool(rules.sides)
        for preset, label in (("mild", "控えめ"), ("standard", "ふつう" if simple else "標準"), ("explicit", "あけすけ" if simple else "露骨")):
            if state["settings"]["terms"] != rules.settings["term_presets"][preset]:
                words = rules.settings["term_presets"][preset]
                example = "（" + "・".join(dict.fromkeys((words["vagina"], words["penis"], words["love_juice"]))) + " など）"
                add("settings.preset." + preset, ("性器などの呼び方：" + label + example) if simple else "呼び方をまとめて：" + label, "settings.set", name="preset", value=preset)
        if simple:
            add("menu.settings_terms", "→ 呼び方を1つずつ選ぶ", "menu", page="settings_terms", offset=0)
        else:
            _term_entries(state, rules, add, term_labels)
        for density in ([] if "intensity" in rules.settings else rules.settings["density"]):  # v8.2.2（009）：濃さは高まりで決まり、選ばない
            if density != state["settings"]["density"]:
                add("settings.density." + density, "描写の濃さ：" + density_labels[density], "settings.set", name="density", value=density)
        for speech in ([] if simple else rules.settings["speech_offset"]):
            if speech != state["settings"]["speech"]:
                add("settings.speech." + speech, "台詞の多さ：" + speech_labels[speech], "settings.set", name="speech", value=speech)
        for gauges in rules.settings["gauges"]:
            if gauges != state["settings"]["gauges"]:
                add("settings.gauges." + gauges, "真帆の数値：" + gauge_labels[gauges], "settings.set", name="gauges", value=gauges)
        if rules.auto and "speeds" in rules.auto:
            # v8.2.28（ユーザー 2026-09-30「自動プレイが早すぎる」）：自動で続けるときの待ち時間の速さ。切は自動で続けない
            current = state["settings"].get("auto_speed", rules.auto["default"])
            for choice in rules.auto["choices"]:
                if choice != current:
                    add("settings.auto_speed." + choice, "自動で続ける：" + AUTO_SPEED_LABELS[choice], "settings.set", name="auto_speed", value=choice)
        add("menu.main", "二人の時間へ" if state["mode"] == "private" else "いつもの時間へ", "menu", page="main", offset=0)
    if page == "settings_terms" and state["mode"] in ("normal", "private") and not state["intimacy"] and not state["scene"] and not state["offer"]:
        # v8.2.29：呼び方を1つずつ選ぶ（設定の画面から）
        _term_entries(state, rules, add, TERM_LABELS)
        add("menu.settings", "→ 設定へ戻る", "menu", page="settings", offset=0)
        add("menu.main", "二人の時間へ" if state["mode"] == "private" else "いつもの時間へ", "menu", page="main", offset=0)
    return result


TERM_LABELS = {"penis": "男性器", "vagina": "女性器", "semen": "精液", "breasts": "胸", "nipple": "乳首", "clitoris": "陰核", "love_juice": "愛液"}


def _term_entries(state, rules, add, term_labels):
    for term, words in rules.settings["terms"].items():
        for n, word in enumerate(words, 1):
            if word != state["settings"]["terms"][term]:
                add(f"settings.term.{term}.{n}", term_labels[term] + "の呼び方：" + word, "settings.set", name=term, value=word)


def _position_moves(state, rules, blocked):
    """体位だけが合わずに選べない行動について、今選べる体位の変更のうち、その行動が選べるようになるもの（v8.2.0）。"""
    intimate = state["intimacy"]
    current = intimate["position"]
    candidates = []
    for move, row in rules.actions.items():
        target = row["sets"]["position"]
        if row["category"] != "position" or row["offer_only"] or not target or target == current:
            continue
        if intimate["inserted"] and target not in rules.positions[current]["linked"]:
            continue  # 入れたままでは、つながったまま移れる体位だけ
        if _intimacy_shape(state, rules, move):
            candidates.append((move, target))
    moves = []
    try:
        for move, target in candidates:
            intimate["position"] = target  # 一時的に体位だけ変えて確かめる（すぐ戻す）
            if any(_intimacy_shape(state, rules, key) for key in blocked):
                moves.append(move)
    finally:
        intimate["position"] = current
    return moves


FINISH_KEYS = ("h_finish_inside", "h_finish_outside", "h_finish_hand", "h_finish_mouth", "h_finish_sumata", "h_finish_breasts", "h_finish_feet", "h_finish_sixty_nine")
SERVICE_KEYS = {"h_finish_hand": "h_maho_hand", "h_finish_mouth": "h_maho_mouth", "h_finish_sumata": "h_sumata", "h_finish_breasts": "h_maho_breasts", "h_finish_feet": "h_maho_feet", "h_finish_sixty_nine": "h_sixty_nine"}
EXTRA_KEYS = {"h_extra_lick": ("h_maho_breasts",), "h_extra_balls": ("h_maho_hand", "h_maho_mouth")}
EXTRA_KEYS_NAME = {"h_extra_lick": "lick", "h_extra_balls": "balls"}


def _intimacy_shape(state, rules, key):
    intimate = state["intimacy"]
    row = rules.actions[key]
    needs = row["needs"]
    if key in FINISH_KEYS and intimate["player"]["arousal"] < rules.raw["player"]["finish_from"]: return False
    service = SERVICE_KEYS.get(key)
    if service and not any(c["action_id"] == service for c in state["contacts"]): return False
    if key in EXTRA_KEYS:
        # v8.2.9：追加は、その行為をしてもらっている最中で、まだ足していないときだけ
        active = {c["action_id"] for c in state["contacts"]}
        if not any(base in active for base in EXTRA_KEYS[key]) or EXTRA_KEYS_NAME[key] in intimate["extras"]: return False
    if key == "h_endure" and (intimate["player"]["arousal"] < rules.raw["player"]["arousal_max"] or intimate["player"]["endured"] >= rules.raw["player"]["endure"]["per_peak"]): return False
    if key == "h_wipe" and intimate["mess"] is None: return False
    thrust = rules.settings.get("thrust_up")
    if thrust and key == thrust["action"] and not any(c["action_id"] == thrust["with"] for c in state["contacts"]): return False
    if intimate["position"] not in row["positions"]: return False
    if key in rules.action_facings and rules.facing(state) not in rules.action_facings[key]: return False  # v8.4.0（010）
    if needs["inserted"] is not None and needs["inserted"] != intimate["inserted"]: return False
    if needs["after"] and not intimate["after"]: return False
    for actor in ("player", "maho"):
        for layer, choices in needs[actor + "_clothing"].items():
            if state["actors"][actor]["clothing"][layer] not in choices: return False
    return True


TALK_ACTIONS = (
    "talk", "affection", "compliment", "gratitude", "together_words",
    "check_mood", "share_day", "reassurance",
)
TOUCH_ACTIONS = (
    "head", "hair", "cheek", "shoulder", "arm", "back", "hands",
    "forehead", "hug", "waist", "kiss",
    # B2（009 だけにある）：恋人の触れ合いと、いつもの触れ合いから深める
    "back_hug", "finger_lace", "cheek_kiss", "lap_pillow", "lap_pillow_take",
    "deep_kiss", "ear_kiss", "chest_touch", "thigh_touch", "under_clothes", "chest_under", "push_down",
)


def entries(state, pack, repository, page):
    result = []
    def add(identity, label, op, **args): result.append((identity, label, {"op": op, **args}))
    active_contacts = {contact["action_id"]: contact for contact in state["contacts"]}
    def action_label(identity):
        return CONTINUE_LABELS.get(identity, pack.actions[identity]["label"] + "のを続ける") if identity in active_contacts else pack.actions[identity]["label"]
    def add_contact_end(identity):
        add("end." + identity, END_LABELS.get(identity, pack.actions[identity]["label"] + "のをやめる"), "action.end", id=identity)
    scene = state["scene"]
    if state["offer"]:
        kind = state["offer"]["kind"]
        if pack.intimacy and kind == "hold_back":
            add("offer.accept", "続ける", "offer.accept")
            add("offer.decline", "今日はここまで", "offer.decline")
        else:
            add("offer.accept", "そうしよう", "offer.accept")
            add("offer.decline", "今はやめておく", "offer.decline")
        return result
    if scene:
        definition = repository.get(scene["release"]).scenes[scene["scene_id"]]
        node = next(n for n in definition["nodes"] if n["id"] == scene["node"])
        for choice in node["choices"]: add("scene." + choice["id"], choice["label"], "scene.choose", id=choice["id"])
        if node["pause"]: add("scene.pause", "話を保留する", "scene.pause")
        if node["pause"] and state["relation"]["stage"] >= 3 and state["mode"] == "normal": add("private.begin", "話を保留して二人で部屋へ行く", "private.begin")
        if definition["id"] != "opening":  # v8.5.11：導入は「導入を飛ばす」で終える（区切ると最後の頁が出ない）
            add("scene.cancel", "この話を区切る", "scene.cancel")
        if node["micro"]:
            if state["distance"] != "near":
                add("near", "そばへ寄る", "approach")
            for key in node["micro"]:
                add("touch." + key, action_label(key), "action", id=key)
                if key in active_contacts:
                    add_contact_end(key)
            for contact in state["contacts"]:
                if contact["action_id"] not in node["micro"]:
                    add_contact_end(contact["action_id"])
        for parked in state["suspended"]: add("drop." + parked["id"], "保留した「" + repository.get(parked["release"]).scenes[parked["scene_id"]]["label"] + "」を終える", "scene.cancel", id=parked["id"])
        return result
    name, offset = page
    if pack.intimacy and pack.intimacy.sleep_play and state.get("sleep_play"):
        return sleep_entries(state, pack, name)  # 段階C（010）：寝込みの最中は、寝込みの手だけ
    if pack.intimacy and pack.intimacy.events and state.get("event_play"):
        return event_entries(state, pack)  # 段階C（010、v8.5.1）：イベントの最中は、イベントの手だけ
    if pack.intimacy and pack.intimacy.co_sleep and state.get("co_sleep"):
        return co_sleep_entries(state, pack)  # 段階C（010、v8.5.6）：添い寝の間は、添い寝の手だけ
    if pack.intimacy and pack.intimacy.ask and state.get("ask_play"):
        return ask_entries(state, pack)  # 段階C（010、v8.5.10）：してもらっている間は、その手だけ
    ensure(name in PAGES and type(offset) is int and offset >= 0, "page", "画面の指定が違う。")
    if pack.intimacy and (state["intimacy"] or name in STAGE_B_PAGES):
        special = intimacy_entries(state, pack, name)
        if special:
            return special
    ensure(name not in STAGE_B_PAGES or pack.intimacy, "page", "この画面は今の原稿版にない。")
    if name == "main":
        if pack.life and state["mode"] == "normal" and not any(x["status"] == "running" for x in state["activities"]):
            from .progression import day_time
            from . import clock
            now = state["world"]["now"]
            base = now - day_time(now)
            if clock.date_time(base).weekday() in pack.life.weekdays:
                for block in pack.life.blocks:
                    start, end = base + block["start_minute"], base + block["end_minute"]
                    if start - pack.life.go_ahead <= now < end:
                        add("work.go", "仕事に戻る" if now >= start else "仕事へ行く", "work.go")
                        break
        if state["distance"] != "near":
            add("near", "そばへ寄る", "approach")
        if state["maho_sleep"]["state"] == "dozing" and state["actors"]["player"]["location"] == state["actors"]["maho"]["location"]:
            add("maho.wake", "真帆を起こす", "maho.wake")
        if pack.intimacy and pack.intimacy.sleep_play and state["mode"] == "normal":
            # 段階C（010、v8.5.0）：眠っている真帆に触れる（うたた寝）・真帆の部屋へそっと行く（就寝後）・このあいだのことを謝る（怒らせた・警戒の間）
            # v8.5.3：晩酌でほろ酔い以上になった夜は、どちらも出さない（お酒を飲んで眠った真帆には触れない）
            from .event_play import drank_tonight
            drank = drank_tonight(state)
            if not drank and state["maho_sleep"]["state"] == "dozing" and state["actors"]["player"]["location"] == state["actors"]["maho"]["location"]:
                add("sleep.begin", "眠っている真帆に、そっと触れる", "sleep.begin")
            if not drank and state["maho_sleep"]["state"] == "asleep" and state["actors"]["player"]["location"] in ("living_room", "kitchen", "player_room"):
                add("sleep.visit", "真帆の部屋へ、そっと行く", "sleep.visit")
            record = state.get("sleep_record")
            if record and record["cooling"] and state["maho_sleep"]["state"] == "awake" and state["actors"]["player"]["location"] == state["actors"]["maho"]["location"]:
                from .progression import life_day
                if record["cooling"]["until"] > life_day(state["world"]["now"]):
                    add("sleep.apologize", "このあいだのことを謝る", "sleep.apologize")
        if not pack.intimacy:
            add("listen", "真帆の様子を聞く", "idle")
        elif state["maho_sleep"]["state"] == "awake" and state["actors"]["player"]["location"] == state["actors"]["maho"]["location"]:
            # 009：選んでも真帆が話すとは限らない（真帆から誘うきっかけを待つ）ので「見る」にした（v8.0.5、試運転の指摘1）。
            add("listen", "真帆の様子を見る", "idle")
        bath = pack.life.bath if pack.intimacy and pack.life and pack.life.bath else None
        if pack.intimacy and pack.intimacy.nap:
            # v8.5.7：少し眠る（居間、夕方〜夜、真帆と一緒）。目を覚ました直後だけ、引き寄せる・気づかないふり
            from .nap import nap_blocked, pull_open
            if pull_open(state, pack):
                add("nap.pull", pack.intimacy.nap.labels["pull"], "nap.answer", pull=True)
                add("nap.ignore", pack.intimacy.nap.labels["ignore"], "nap.answer", pull=False)
            elif nap_blocked(state, pack) is None:
                add("nap", pack.intimacy.nap.label, "nap")
        if pack.intimacy and pack.intimacy.co_sleep:
            # v8.5.6：一緒に寝ようと誘う（夜、恋人、真帆が起きていて一緒のとき。暮らしの日に1回）
            from .co_sleep import invite_blocked
            if invite_blocked(state, pack) is None:
                add("cosleep.invite", pack.intimacy.co_sleep.labels["invite"], "cosleep.invite")
        events = pack.intimacy.events if pack.intimacy else None
        if events and state["mode"] == "normal" and state["maho_sleep"]["state"] == "awake" and state["actors"]["player"]["location"] == state["actors"]["maho"]["location"]:
            # v8.5.3：こちらから誘うイベント（晩酌・野外）。場所・時間帯・関係の段階・夕食のあと・条件・その暮らしの日にまだ誘っていない、がそろうときだけ出す（一緒にお風呂と同じ）
            from .event_play import entry_blocked
            for kind, define in events.events.items():
                if define.entry and entry_blocked(state, pack, kind, define) is None:
                    add("event.invite." + kind, define.entry["label"], "event.invite", kind=kind)
        if bath and state["mode"] == "normal" and state["relation"]["stage"] >= bath["invite"]["show_stage"]:
            # v8.2.0：風呂の時間が近づいたら、入る前に一度だけ誘える（3回目の試運転の指摘4）
            from .progression import day_time, life_day
            today = life_day(state["world"]["now"])
            if bath["invite_from"] <= day_time(state["world"]["now"]) < bath["until"] and today not in (state["bath"]["day"], state["bath"]["invited_day"]):
                add("bath.invite", "一緒にお風呂に入ろうと誘う", "bath.invite")
        for key in PAGES:
            # 009：設定と、エッチを1回以上したら「二人の記録」（v8.2.12）
            if key in STAGE_B_PAGES and not (pack.intimacy and (key == "settings" or key == "records" and state["intimacy_history"]["count"] > 0)):
                continue
            if key != "main": add("menu." + key, PAGES[key], "menu", page=key, offset=0)
        if state["mode"] == "private":
            add("private.end", "二人の時間を区切る", "private.end")
            add("room.talk", "二人でゆっくり話す", "scene.begin", id="room_conversation")
        else: add("private.begin", "二人で部屋へ行く" + _private_limit(state, pack, repository), "private.begin")
        if pack.intimacy and state["mode"] == "private":
            # 009：二人の時間の中では選べない「過ごす」「休む」は並べない（区切ってから選ぶ。v8.1.0、3回目の試運転の指摘6）
            result[:] = [row for row in result if row[0] not in ("menu.move", "menu.activities")]
            return result
        add("wait.30", "30分過ごす", "wait", minutes=30)
        add("wait.120", "2時間過ごす", "wait", minutes=120)
        add("sleep", "休んで翌朝を迎える", "sleep")
        return result
    if name == "talk":
        for key in TALK_ACTIONS:
            if key in pack.actions:
                add("touch." + key, action_label(key), "action", id=key)
        add("memory.tea", "一緒のお茶を思い出す", "reminisce")
        for definition in pack.scenes.values():
            if definition.get("activity_kind") or definition["id"] in ("town_trip", "opening"): continue  # v8.5.11：導入（opening）は新しく始めたときだけ
            if pack.intimacy and definition["id"] in MILESTONE_SCENES and state["relation"]["stage"] >= MILESTONE_SCENES[definition["id"]]: continue  # 009：迎え済みの節目は並べない
            if pack.intimacy and any(e["op"] == "promise.create" for n in definition["nodes"] for c in n["choices"] for e in c["effects"]): continue  # 009：約束の話は「約束と共同作業」だけに並べる（v8.2.4、ユーザー了承）
            add("begin." + definition["id"], definition["label"], "scene.begin", id=definition["id"])
    elif name == "touch":
        if state["distance"] != "near":
            add("near", "そばへ寄る", "approach")
        # Structural releases declare the human-facing touch set explicitly.
        # Older releases retain their original all-actions menu for save fidelity.
        action_ids = TOUCH_ACTIONS if "compliment" in pack.actions else tuple(pack.actions)
        if pack.intimacy and (pack.intimacy.daily_hidden or pack.intimacy.daily_extra):
            # v8.4.0（010）：指を絡めるは手をつなぐにまとめた（親密になったら自動で絡める）。両手をつなぐは手をつなぐの次に並べる
            hidden = set(pack.intimacy.daily_hidden) - set(active_contacts)
            action_ids = tuple(k for key in action_ids for k in ((key,) + (pack.intimacy.daily_extra if key == "hands" else ())) if k not in hidden)
        gate = pack.intimacy.b2["gate"]["touches"] if pack.intimacy else {}
        if pack.intimacy and state["mode"] == "private" and not state["intimacy"]:
            # B2：二人の時間の中では、触れ方を深める行動をいつもの「触れ合う」に並べる（ページ「触れ方を深める」はなくした）。
            rules = pack.intimacy
            position = rules.raw["session"]["start_position"]["seated"] if all(state["actors"][a]["posture"] == "seated" for a in ("player", "maho")) else rules.raw["session"]["start_position"]["other"]
            for key, action in rules.actions.items():
                if action["entry"] and position in action["positions"]:
                    add("touch." + key, action["label"], "intimacy.entry", id=key)
            if rules.self_entry and position in rules.actions["h_self"]["positions"]:
                add("touch.h_self_entry", rules.self_entry["label"], "intimacy.self_entry")  # 段階C（010、v8.5.8）：起きている真帆の前で自分で高める
        for key in action_ids:
            if key not in pack.actions:
                continue
            if key in gate and state["mode"] == "private" and key not in active_contacts:
                continue  # 続けている深める触れ合いは、二人の時間でも続ける・やめるを出す（検査役G2 M-5）
            if pack.intimacy and key in pack.intimacy.daily_sides:
                # v8.4.0（010）：手をつなぐ左右（touch.<行為>＝既定の側、side.<行為>.<左右>＝ほかの側）
                row = pack.intimacy.daily_sides[key]
                current = active_contacts[key].get("side", row["default"]) if key in active_contacts else None
                labels = row["labels"]
                add("touch." + key, labels["keep"] if current == row["default"] else labels["switch"][row["default"]] if current else labels["start"][row["default"]], "action", id=key)
                for side in row["choices"]:
                    if side != row["default"]:
                        add(f"side.{key}.{side}", labels["keep"] if current == side else labels["switch"][side] if current else labels["start"][side], "action.side", id=key, side=side)
            else:
                add("touch." + key, action_label(key), "action", id=key)
            if key in active_contacts:
                add_contact_end(key)
        if pack.intimacy and pack.intimacy.ask:
            # 段階C（010、v8.5.10）：頼む（見せて・手で・口で）。並べたうえで、時間・余力・雨などはグレーアウト（理由つき）、口は開くまで出さない
            from .ask import ask_listed
            if ask_listed(state, pack):
                labels = pack.intimacy.ask.labels
                add("ask.show", labels["show"], "ask.show")
                for kind in pack.intimacy.ask.kinds:
                    add("ask.serve." + kind, labels[kind], "ask.serve", kind=kind)
        for posture, label in [("standing", "立つ"), ("seated", "座る"), ("reclined", "横になる")]:
            if state["actors"]["player"]["posture"] != posture:
                add("posture." + posture, label, "posture", value=posture)
    elif name == "activities":
        for key, definition in pack.catalog["activities"].items():
            if key not in ("private_time", "town_trip", "install"): add("activity." + key, definition["label"], "activity.begin", kind=key)
        add("trip.begin", "町へ出かける", "trip.begin")
        if pack.life and pack.life.fishing and (state.get("fish") or {}).get("book"):
            add("fish.book", "真帆の手帳（釣った魚）を見る", "fish.book")  # v8.5.11：図鑑
    elif name == "move":
        for key, definition in pack.catalog["locations"].items():
            if key in ("town", "maho_room"): continue
            if key == state["actors"]["player"]["location"]: continue
            add("move.solo." + key, "一人で" + definition["label"] + "へ", "move", location=key)
            if key != "player_room": add("move.joint." + key, "二人で" + definition["label"] + "へ", "move", location=key, together=True)
    elif name == "plans":
        for kind in pack.catalog["promise_kinds"]: add("begin.promise_" + kind, pack.catalog["activities"][kind]["label"] + "約束をする", "scene.begin", id="promise_" + kind)
        for promise in state["promises"]:
            label = pack.catalog["activities"][promise["kind"]]["label"]
            place = "（" + pack.catalog["locations"][promise["place"]]["label"] + "）" if pack.intimacy else ""  # 009：約束の場所（v8.2.3）
            add("fulfil." + promise["id"], "約束の「" + label + "」を始める" + place, "activity.begin", kind=promise["kind"], promise_id=promise["id"])
            add("postpone." + promise["id"], label + "約束を延期", "promise.postpone", id=promise["id"])
            add("cancel." + promise["id"], label + "約束を取りやめ", "promise.cancel", id=promise["id"])
        for op, label in [("plan", "棚を置く計画を立てる"), ("order", "棚を注文する"), ("install", "二人で棚を設置する"), ("finish", "設置を確かめる"), ("cancel", "棚の計画を区切る")]: add("project." + op, label, "project." + op)
    elif name == "orders":
        if pack.life and pack.life.town:
            # v8.5.11：島の町の売店で、品の取り寄せを頼む（売店にいないときはグレーアウト）
            shop = pack.life.town["order"]
            for kind in shop["items"]:
                add("shop." + kind, pack.catalog["locations"][shop["place"]]["label"] + "で" + pack.catalog["items"][kind]["label"] + "の取り寄せを頼む", "shop.order", kind=kind)
        for kind, definition in pack.catalog["items"].items(): add("buy." + kind, definition["label"] + "を注文", "order.create", kind=kind)
        for order in state["orders"]:
            label = pack.catalog["items"][order["catalog_id"]]["label"]
            add("receive." + order["id"], label + "を受け取る", "order.receive", id=order["id"])
            add("cancel." + order["id"], label + "の注文を取り消す", "order.cancel", id=order["id"])
    elif name == "inventory":
        for item in state["items"]: add("give." + item["id"], pack.catalog["items"][item["catalog_id"]]["label"] + "を真帆へ渡す", "item.give", id=item["id"])
    elif name == "memories":
        pinned = {m["id"] for m in state["memories"]["pinned"]}
        memories = {m["id"]: m for m in state["memories"]["recent"] + state["memories"]["pinned"]}
        for memory in sorted(memories.values(), key=lambda x: (x["at"], x["id"]), reverse=True):
            is_pinned = memory["id"] in pinned
            add("pin." + memory["id"], ("固定を外す " if is_pinned else "大切に残す ") + memory["kind"], "memory.pin", id=memory["id"], pin=not is_pinned)
    elif name == "inbox":
        for message in reversed(state["inbox"]): add("read." + message["id"], pack.catalog["actors"][message["sender"]]["name"] + "の便り", "inbox.read", id=message["id"])
    elif name == "appearance":
        for actor in ("player", "maho"):
            for outfit, label in [("work", "仕事着"), ("casual", "普段着"), ("room", "部屋着")]:
                for hair in pack.catalog["hair"][actor]:
                    current = state["actors"][actor]
                    if current["outfit"] == outfit and current["hair"] == hair:
                        continue
                    add("prepare." + actor + "." + outfit + "." + hair, state["actors"][actor]["name"] + "の" + label + "・" + {"short": "短髪", "tied": "結び髪", "down": "下ろした髪"}[hair], "prepare", actor=actor, outfit=outfit, hair=hair)
    elif name == "resume":
        for parked in state["suspended"]:
            label = repository.get(parked["release"]).scenes[parked["scene_id"]]["label"]
            add("resume." + parked["id"], label + "を続ける", "scene.resume", id=parked["id"])
            add("drop." + parked["id"], label + "を区切る", "scene.cancel", id=parked["id"])
    total = len(result)
    # All content lists, including future scenes, use the same bounded pagination.
    size = 30 if pack.intimacy and name == "touch" else 24  # B2：触れ合いは1ページに収める（上限32のうち戻るなどの分を残す）
    offset = min(offset, max(0, ((total - 1) // size) * size))
    result = result[offset:offset + size]
    if offset: add("menu.previous", "前の一覧へ", "menu", page=name, offset=max(0, offset - size))
    if offset + size < total: add("menu.next", "次の一覧へ", "menu", page=name, offset=offset + size)
    add("menu.main", "いつもの時間へ", "menu", page="main", offset=0)
    return result


def build_choices(state, pack, repository, page, frame, test_cheat_intimacy=False):
    choices, plans, explanations = [], {}, {}
    for identity, label, plan in entries(state, pack, repository, page):
        ensure(identity not in plans, "choice_duplicate", "操作IDが重複している。")
        available, reason, duration = True, None, 0
        if plan["op"] != "menu":
            preview = Context(clone_state(state), pack, repository, frame, test_cheat_intimacy)
            try:
                preview.apply(plan)
                preview.finalize()
                validate_state(preview.s, pack, repository, test_cheat_intimacy)
                duration = preview.now - state["world"]["now"] - preview.auto_minutes  # 自動の仕事の分は、選んだ操作の所要分に入れない
            except GameError as error:
                if pack.intimacy and error.code == "h_tier":
                    # v8.2.19（ユーザー 2026-09-29 07:03）：エッチの回数で開く行為は、開くまで一覧に出さない。
                    # 「もう入れたのに、なぜ口はだめなのか」と画面の都合が透けて見えるため。服・体位・高まりなど、その場で満たせる理由は今までどおり出す
                    continue
                available, reason = False, error.code
                explanations[identity] = error.message
                if pack.intimacy and label.endswith("（もうこらえきれない）"):
                    label = label[:-len("（もうこらえきれない）")]  # 選べないときは添えない（v8.2.7、精査 A-04・F-15）
        choices.append({"id": identity, "label": label, "available": available, "reason": reason, "duration": duration})
        plans[identity] = plan
    ensure(choices and len(choices) <= 32, "choice_limit", "操作一覧が空、または上限を超えている。")
    return choices, plans, explanations


def _private_limit(state, pack, repository):
    """v8.2.30（通し確かめ 1・2・8）：二人の時間に使える時刻（仕事の始まりか、夜の区切り）。恋人になってからの 009 だけ。"""
    if not pack.intimacy or not pack.intimacy.deadline_close or state["relation"]["stage"] < 3:
        return ""
    from . import clock
    limit, work = Context(clone_state(state), pack, repository, None, False)._session_deadline()
    return "（" + clock.format_time(limit)[-5:] + ("まで・このあと仕事）" if work else "まで）")



def sleep_entries(state, pack, name):
    """段階C（010、v8.5.0）：寝込みの最中の選択肢。行動はデータ（sleep_play 節）の順に、その行動のページ（既定は main）に並べる。
    条件（when）に当たらない行動は出さない。ほかのページは、選べる行動があるときだけ入口を出す。待つ・離れるはいつも出す。"""
    rules = pack.intimacy.sleep_play
    result = []
    def add(identity, label, op, **args): result.append((identity, label, {"op": op, **args}))
    page = name if name in rules.pages else "main"
    context = Context(state, pack, None, None, False)
    values = pack.registry.values(state)
    shown = {}
    for key, row in rules.actions.items():
        if key in ("sp_wait", "sp_leave") or not context.sleep_action_open(key, values):
            continue
        shown.setdefault(row.get("page", "main"), []).append((key, row))
    for key, row in shown.get(page, []):
        add("sleep." + key, row["label"], "sleep.act", id=key)
    for key, label in rules.pages.items():
        if key != page and (key == "main" or key in shown):
            add("sleep.menu." + key, label + "へ", "menu", page=key, offset=0)
    add("sleep.sp_wait", rules.actions["sp_wait"]["label"], "sleep.act", id="sp_wait")
    add("sleep.sp_leave", rules.actions["sp_leave"]["label"], "sleep.leave")
    return result


def co_sleep_entries(state, pack):
    """段階C（010、v8.5.6）：添い寝の選択肢。talk：話す・目を閉じる。asleep：このまま眠る・寝顔を見る・眠っている真帆に触れる（寝込み）。"""
    rules = pack.intimacy.co_sleep
    labels = rules.labels
    result = []
    def add(identity, label, op, **args): result.append((identity, label, {"op": op, **args}))
    if state["co_sleep"]["phase"] == "talk":
        add("cosleep.talk", labels["talk"], "cosleep.talk")
        add("cosleep.close_eyes", labels["close_eyes"], "cosleep.close_eyes")
    else:
        add("sleep", labels["sleep"], "sleep")
        add("cosleep.look", labels["look"], "cosleep.look")
        from .event_play import drank_tonight
        if "cosleep" in pack.intimacy.sleep_play.kind_factor and not drank_tonight(state):
            add("sleep.begin", labels["touch"], "sleep.begin")
    return result


def ask_entries(state, pack):
    """段階C（010、v8.5.10）：してもらっている間の手（続けてもらう・出す・やめてもらう）。上限まで高まったら続けられない（出すか、やめてもらう）。"""
    result = []
    def add(identity, label, op, **args): result.append((identity, label, {"op": op, **args}))
    rules, play = pack.intimacy.ask, state["ask_play"]
    if play["arousal"] < rules.serve["max"]:
        add("ask.next", rules.labels["next"], "ask.next")
    if play["arousal"] >= rules.serve["finish_from"]:
        add("ask.finish", rules.labels["finish"], "ask.finish")
    add("ask.stop", rules.labels["stop"], "ask.stop")
    return result


def event_entries(state, pack):
    """段階C（010、v8.5.1）：イベントのエッチの選択肢（1ページ）。段ごとに決まった手だけを出す（イベントの型）。
    pre：その場の触れ合い・上がる。offer：このまま・やめておく。position：体位。foreplay：続けてもらう・入れる。main：入れる／動く（3段）・触れる・果てる。"""
    from .event_rules import PACES
    play = state["event_play"]
    define = pack.intimacy.events.events[play["kind"]]
    labels = dict(define.labels, **define.meal_labels.get(play.get("meal"), {}))  # v8.5.11：休日の昼の支度は「お昼のあとにする」
    context = Context(state, pack, None, None, False)
    values = pack.registry.values(state)
    result = []
    def add(identity, label, op, **args): result.append((identity, label, {"op": op, **args}))
    phase = play["phase"]
    if phase == "pre":
        for key, row in define.pre.items():
            if context.event_open(row, values):
                add("event.pre." + key, row["label"], "event.act", id=key)
        add("event.leave", labels["leave"], "event.leave")
    elif phase == "offer":
        add("event.accept", labels["accept"], "event.offer", accept=True)
        add("event.decline", labels["decline"], "event.offer", accept=False)
    elif phase == "position":
        for key, row in define.positions.items():
            if context.event_open(row, values):
                add("event.pos." + key, row["label"], "event.position", id=key)
    elif phase == "warn":
        # v8.5.4：人目（野外）。足音・灯りが近づいた：息を殺す／急いで服を直す／やめる
        choices = define.exposure["choices"]
        add("event.hush", choices["hush"], "event.hush")
        add("event.fix", choices["fix"], "event.hide", how="fix")
        add("event.stop", choices["stop"], "event.hide", how="stop")
    elif phase == "foreplay":
        if play["step"] < len(define.foreplay):
            add("event.next", labels["next"], "event.next")
        if play["step"] >= 1:
            add("event.insert", labels["insert"], "event.insert")
    else:
        if context.event_can_finish():
            add("event.finish.inside", labels["finish_inside"], "event.finish", where="inside")
            add("event.finish.outside", labels["finish_outside"], "event.finish", where="outside")
        if not context._event_must_finish():
            if not play["inserted"]:
                add("event.insert", labels["insert"], "event.insert")
            else:
                for pace in PACES:
                    add("event.move." + pace, define.moves[pace]["label"], "event.move", pace=pace)
            for key, row in define.touches.items():
                if context.event_open(row, values):
                    add("event.touch." + key, row["label"], "event.touch", id=key)
    return result
