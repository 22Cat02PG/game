"""v8.2.30（ユーザー 2026-10-01「じゃあお願い」）：別の Claude の通し確かめ（報告_v8229通し.md）の 1〜6・8〜17 の直し。
公開の選択肢（Engine.choose／get_view）から確かめる（時刻・慣れ・高まりの準備だけ内部で行う）。"""
import json
import tempfile
import unittest
from pathlib import Path

from nagishima.codec import digest
from nagishima.content import Pack
from nagishima.engine import Engine
from nagishima.progression import day_time
from tools.run_stage_b_routes import Route

ROOT = Path(__file__).resolve().parents[1]


def meanings(engine):
    return [b["meaning"] for b in engine.get_view()["blocks"]]


class V8230(unittest.TestCase):
    def route(self, seed, tier="familiar", **kw):
        route = Route(seed, tier=tier, **({"day_offset": 3, "hour": 13} | kw))
        self.addCleanup(route.close)
        return route

    def choice(self, route, identity):
        return next((c for c in route.engine.get_view()["choices"] if c["id"] == identity), None)

    # ---- 1・2：昼休みは、仕事の始まりが区切り。部屋へ行く前にも出し、始めに真帆が短い時間だと言う ----
    def test_lunch_limit_is_shown_and_said(self):
        route = self.route(3001, day_offset=2, hour=12, minute=20)
        self.assertEqual(self.choice(route, "private.begin")["label"], "二人で部屋へ行く（13:00まで・このあと仕事）")
        route.begin()
        self.assertEqual(meanings(route.engine)[0], "h.begin.short")
        status = route.engine.get_view()["status"]["intimacy"]
        self.assertEqual((status["deadline"][-9:], status["night"]), ("13:00（仕事）", "このあと仕事"))

    def test_night_limit_label(self):
        route = self.route(3002, day_offset=1, hour=20, minute=30)  # 木曜（翌日は仕事）
        self.assertEqual(self.choice(route, "private.begin")["label"], "二人で部屋へ行く（22:00まで）")
        route.begin()
        self.assertNotIn("h.begin.short", meanings(route.engine))

    # ---- 3：休みの日は普段着 ----
    def test_holiday_clothes(self):
        route = self.route(3003, day_offset=2, hour=23)  # 金曜の夜に眠って、土曜の朝へ
        route.choose("sleep")
        state = route.engine.snapshot()
        self.assertGreater(day_time(state["world"]["now"]), 7 * 60)
        self.assertEqual((state["actors"]["maho"]["outfit"], state["actors"]["player"]["outfit"]), ("casual", "casual"))

    # ---- 6：上になる申し出は、その回に申し出るかを一度だけ決める（慣れで35%ほど） ----
    def test_straddle_offer_rate(self):
        percent = json.loads((ROOT / "tools/stage_b/intimacy_009.json").read_text(encoding="utf-8"))["lead"]["session_percent"]
        rolls = [int(digest([seed, "lead_session", "intimacy.5", "h_lead_straddle"])[:12], 16) % 100 < percent["familiar"] for seed in range(1000)]
        self.assertLess(sum(rolls), 450)

    # ---- 8：初めての回は、時間がないと始めない。風呂は20時から ----
    def test_first_time_needs_time(self):
        route = self.route(3008, tier="first", day_offset=1, hour=21, minute=20)  # 木曜の夜、22:00 まで40分
        route.begin()
        self.assertIn("h.decline.first_time", meanings(route.engine))
        self.assertIsNone(route.engine.snapshot()["intimacy"])
        early = self.route(3009, tier="first", day_offset=1, hour=20, minute=30)
        early.begin()
        self.assertIsNotNone(early.engine.snapshot()["intimacy"])

    def test_bath_from_twenty(self):
        pack = Pack(ROOT / "content/releases/interaction_009")
        self.assertEqual((pack.life.bath["from"], pack.life.bath["invite_from"]), (20 * 60, 19 * 60 + 30))

    # ---- 9：引き留めに応えると、真帆の一言 ----
    def test_hold_back_accept_line(self):
        route = self.route(3010, tier="few")
        route.begin()
        route.action("h_chest_over")
        if route.engine.get_view()["page"] != "main":
            route.choose("menu.main")
        route.choose("h.end")
        self.assertEqual(route.engine.snapshot()["offer"]["kind"], "hold_back")
        route.choose("offer.accept")
        self.assertIn("h.hold_back.accepted", meanings(route.engine))

    # ---- 10：余韻に入ったら、動く・指の行為は終わる ----
    def test_after_ends_moves(self):
        route = self.route(3011)
        route.begin()
        for key in ("h_lift_upper", "h_strip_lower", "h_shift_under", "h_strip_self", "h_pos_player_above"):
            route.action(key)
        route.engine._state["intimacy"]["maho"].update(arousal=60, band="mid")
        route.engine._install_choices()
        route.action("h_insert")
        route.action("h_move_normal")
        route.engine._state["intimacy"]["after"] = True  # 準備：真帆に動いてもらって達したあとと同じ（余韻の行為を選べる）
        route.engine._install_choices()
        route.action("h_after_hold")
        active = {c["action_id"] for c in route.engine.snapshot()["contacts"]}
        self.assertNotIn("h_move_normal", active)

    # ---- 15：触れ合いの終わりの一言を種類で分ける ----
    def test_contact_end_kinds(self):
        pack = Pack(ROOT / "content/releases/interaction_009")
        for kind in ("hug", "lap_give", "lap_take", "kiss"):
            authored = [t for t in pack.by_meaning["system.contact_ended." + kind] if not t["fallback"]]
            self.assertGreaterEqual(len(authored), 3, kind)
            for text in authored:
                self.assertNotIn("手を", text["body"][:6], text["id"])

    # ---- 本文の条件（4・5・12・13・14・16） ----
    def test_text_conditions(self):
        pack = Pack(ROOT / "content/releases/interaction_009")
        texts = pack.by_text
        opener = json.dumps(texts["x5.h_chest_skin.start.familiar.s.v1"]["when"])
        self.assertIn('"intimacy.actions_started", "op": "le", "value": 3', opener)
        self.assertNotIn("触れて確かめたい", texts["b2.h.deflect.insert.few.s.v2"]["body"])
        self.assertIn('"intimacy.facing", "op": "eq", "value": "face"', json.dumps(texts["o36.h.deadline.work_close.s.v1"]["when"]))
        self.assertIn('"actor.maho.clothing.upper", "op": "eq", "value": "off"', json.dumps(texts["o36.h.after_time.s.v3"]["when"]))
        self.assertNotIn("vagina", texts["p2.h_strip_under.first.s.v2"]["slots"])
        afternoon = [t for t in pack.by_meaning["offer.shared.quiet"] if t["id"].startswith("o37.")]
        self.assertEqual(len(afternoon), 5)
        for text in afternoon:
            self.assertNotIn("片付けを終え", text["body"])

    # ---- 11：締め切りのあとの最後の手は、続ける本文に台詞を出さない ----
    def test_last_step_after_deadline_is_quiet(self):
        route = self.route(3012, day_offset=0, hour=12, minute=20)
        route.begin()
        seen = []
        for _ in range(30):
            state = route.engine.snapshot()["intimacy"]
            if state is None or state["wrap_up"] == 0:
                break
            route.engine._state["intimacy"]["maho"].update(arousal=30, band="low")
            route.engine._install_choices()
            route.action("h_kiss_deep")
        if route.engine.snapshot()["intimacy"]["wrap_up"] == 0:
            for block in route.engine.get_view()["blocks"]:
                if block["meaning"].startswith("h_kiss_deep."):
                    self.assertNotIn("「", block["body"])

    # ---- 17：慣れのチートは、前の回を数日前に満たされたことにする ----
    def test_tier_cheat_history(self):
        route = self.route(3013, tier="few")
        hist = route.engine.snapshot()["intimacy_history"]
        self.assertEqual(hist["last_result"], "satisfied")
        self.assertLessEqual(hist["last_at"], route.engine.snapshot()["world"]["now"] - 2 * 1440)


if __name__ == "__main__":
    unittest.main()
