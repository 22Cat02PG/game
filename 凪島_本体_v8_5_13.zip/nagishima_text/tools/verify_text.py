"""Fast acceptance check for the text prototype.

This is separate from the older full runtime gate. It checks the new bounded
Session/CLI-facing API, then completes the public autoplay route for several
seeds and compares a second run with the same seed and commands.
"""
from copy import deepcopy
import argparse
from datetime import datetime, timezone
import io
import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
import time
import unittest
from uuid import uuid4

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from nagishima.autoplay import next_command
from nagishima.codec import digest, write_json
from nagishima.engine import Engine
from nagishima.recording import stable
from nagishima.session import Session


SEEDS = [0, 1, 42, 20380407, 2147483647]


def play(seed, root, release, commands, transcript):
    game = Session(Engine(root, seed=seed, release=release, autosave=False), max_turns=200)
    transcript.extend(block['body'] for block in game.observe()['view']['blocks'])
    while not game.observe()["run"]["ended"]:
        if game.cleared:  # releases where life continues after relation 4 (interaction_007)
            game.finish("cleared")
            break
        command = next_command(game.observe()["view"], game.observe()["state"])
        if command is None:
            game.finish("policy_stalled")
            break
        commands.append(command)
        old = game.observe()
        label = next(c['label'] for c in old['view']['choices'] if c['id'] == command['id'])
        response = game.execute(command)
        if response['state']['world']['operation_seq'] != old['state']['world']['operation_seq']:
            transcript.append('\n> ' + label)
            transcript.extend(block['body'] for block in response['view']['blocks'])
        if not response["ok"]:
            game.finish("error")
            break
    return game.observe(), commands


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--release', default='interaction_005')
    args = parser.parse_args()
    started = time.perf_counter()
    stamp = datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S') + '-' + uuid4().hex[:6]
    artifacts = ROOT / 'verification/text_runs' / stamp
    artifacts.mkdir(parents=True)
    route_results = []
    success = True
    with TemporaryDirectory(prefix="nagishima-text-verify-") as temporary:
        base = Path(temporary)
        for seed in SEEDS:
            commands, transcript = [], []
            try:
                first, commands = play(seed, base / ("first-" + str(seed)), args.release, commands, transcript)
            except Exception as error:
                write_json(artifacts / f'seed{seed}.failure.json', {'seed': seed, 'release': args.release,
                           'commands': commands, 'error': type(error).__name__ + ': ' + str(error)})
                success = False
                route_results.append({'seed': seed, 'reason': 'error', 'commands': len(commands)})
                continue
            (artifacts / f'seed{seed}.jsonl').write_text(''.join(json.dumps(c) + '\n' for c in commands), encoding='utf-8')
            if seed == 42:
                (ROOT / 'verification/prose_sample.txt').write_text('\n\n'.join(transcript) + '\n\n' + (first['run']['ending'] or ''), encoding='utf-8')
            second = Session(Engine(base / ("second-" + str(seed)), seed=seed, release=args.release, autosave=False), max_turns=200)
            for command in commands:
                response = second.execute(deepcopy(command))
                if not response["ok"]:
                    second.finish("error")
                    break
            if second.reason is None and second.cleared:
                second.finish("cleared")
            replay = second.observe()
            same = digest(stable(first)) == digest(stable(replay))
            completed = first["run"]["reason"] in ("completed", "cleared") and first["state"]["relation"]["stage"] == 4
            clean = first["state"]["scene"] is None and first["state"]["offer"] is None
            item = {"seed": seed, "commands": len(commands), "reason": first["run"]["reason"],
                    "stage": first["state"]["relation"]["stage"], "clean_terminal": clean,
                    "deterministic_replay": same}
            route_results.append(item)
            if not (completed and clean and same):
                write_json(artifacts / f'seed{seed}.failure.json', {'seed': seed, 'release': args.release,
                           'commands': commands, 'first': first, 'replay': replay})
            success = success and completed and clean and same and len(commands) <= 200

        suite = unittest.TestSuite([
            unittest.defaultTestLoader.loadTestsFromName('tests.test_automation'),
            unittest.defaultTestLoader.loadTestsFromName('tests.test_prose'),
        ])
        test_output = io.StringIO()
        result = unittest.TextTestRunner(stream=test_output, verbosity=2).run(suite)
        (artifacts / 'tests.txt').write_text(test_output.getvalue(), encoding='utf-8')
        success = success and result.wasSuccessful()

    output = {"kind": "text_prototype", "release": args.release, "success": success, "seeds": route_results,
              'reproduction_artifacts': artifacts.relative_to(ROOT).as_posix(),
              "automation_tests": {"run": result.testsRun, "failures": len(result.failures),
                                   "errors": len(result.errors), "skipped": len(result.skipped)},
              "seconds": round(time.perf_counter() - started, 3),
              "commands": "same seed + same command IDs + same release reproduces state and prose"}
    target = ROOT / "verification" / "text_results.json"
    target.parent.mkdir(exist_ok=True)
    target.write_text(json.dumps(output, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(output, ensure_ascii=False, indent=2))
    return 0 if success else 1


if __name__ == "__main__":
    raise SystemExit(main())
