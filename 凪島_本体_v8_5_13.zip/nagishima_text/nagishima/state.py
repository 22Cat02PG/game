from collections import Counter
from copy import deepcopy
from pathlib import Path

from .codec import read_json, digest
from .conditions import typed, evaluate
from .errors import ensure
from .schema import validate as validate_schema
from . import clock
from . import progression

SCHEMA = read_json(Path(__file__).with_name("state.schema.json"))
from .stage_b_state import install_schema, add_neutral, validate as validate_stage_b
install_schema(SCHEMA)


def new_state(pack, seed, name):
    ensure(type(seed) is int and 0 <= seed <= 2147483647, "seed", "seedは0以上の整数で指定する。")
    ensure(type(name) is str and 1 <= len(name.strip()) <= 20 and not any(ord(c) < 32 for c in name), "name", "名前は制御文字を含まない1〜20文字で指定する。")
    now = clock.minutes(pack.catalog["start_at"])
    actors = {key: {"name": name.strip() if key == "player" else pack.catalog["actors"][key]["name"], "location": "living_room", "posture": "seated", "outfit": "work", "hair": "short" if key == "player" else "tied"} for key in ("player", "maho")}
    facts = {key: {"id": key, "value": deepcopy(value["initial"]), "revision": 1, "source_event": "canon", "created_at": now} for key, value in pack.catalog["facts"].items()}
    knowledge = {key: {} for key in pack.catalog["actors"]}
    for key, definition in pack.catalog["facts"].items():
        for actor in definition["known_by"]:
            ensure(facts[key]["value"] is not None, "initial_knowledge", "未確定の事実を初期知識にできない。")
            knowledge[actor][key] = {"snapshot": deepcopy(facts[key]), "learned_at": now}
    state = {
        "world": {"now": now, "awake_deadline": clock.next_clock(now, 300), "processed_until": now, "seed": seed, "operation_seq": 0, "next_instance": 1, "rng": {"world": 0, "director": 0, "text": 0}, "pending_notices": []},
        "actors": actors, "distance": "normal", "mode": "normal", "private_instance": None,
        "relation": {"stage": 0, "dating_since": None, "life_since": None, "milestones": []},
        "contacts": [], "activities": [], "scene": None, "suspended": [], "offer": None,
        "facts": facts, "knowledge": knowledge,
        "experience": {key: {"count": 0, "first_at": None, "last_at": None, "by_origin": {"player": 0, "maho": 0}} for key in pack.actions},
        "interaction_streak": None,
        "affinity": progression.neutral_affinity(), "desire": 0, "maho_sleep": progression.neutral_sleep(),
        "habits": {key: {"count_days": 0, "last_day": None, "established_at": None} for key in pack.catalog["habits"]},
        "progress": {key: 0 for key in ("shared_activities", "personal_stories", "fulfilled_promises", "completed_activities", "completed_projects")},
        "promises": [], "promise_history": [], "orders": [], "order_history": [], "items": [], "project": None,
        "memories": {"recent": [], "pinned": [], "summaries": {}},
        "intention": None, "mood": {key: 0 for key in ("joy", "shy", "ease", "interest")}, "cooldowns": [], "last_goal": None,
        "inbox": [], "gallery": [], "recent_text": [], "history": [],
    }
    return add_neutral(state, pack)


def validate_state(state, pack, repository, test_cheat_intimacy=False):
    validate_schema(state, SCHEMA)
    validate_stage_b(state, pack)
    c, now = pack.catalog, state["world"]["now"]
    ensure(state["world"]["processed_until"] == now <= state["world"]["awake_deadline"], "world_time", "時刻と生活更新の記録が一致しない。")
    ensure(set(state["facts"]) == set(c["facts"]) and set(state["knowledge"]) == set(c["actors"]), "state_registry", "保存の事実・人物が登録と一致しない。")
    ensure(set(state["experience"]) == set(pack.actions) and set(state["habits"]) == set(c["habits"]), "state_registry", "経験・習慣が登録と一致しない。")
    streak = state["interaction_streak"]
    if streak is not None:
        ensure(streak["action_id"] in pack.actions and streak["count"] <= state["experience"][streak["action_id"]]["by_origin"]["player"], "interaction_streak", "連続行動の記録が経験と一致しない。")
    for actor, value in state["actors"].items():
        ensure(value["location"] in c["locations"] and value["posture"] in c["postures"] and value["outfit"] in c["outfits"] and value["hair"] in c["hair"][actor], "actor_state", "人物の現在状態が未登録。")
    together = state["actors"]["player"]["location"] == state["actors"]["maho"]["location"]
    ensure(state["distance"] != "near" or together, "distance", "別の場所では近い距離にできない。")
    for key, fact in state["facts"].items():
        ensure(key == fact["id"] and fact["created_at"] <= now, "fact", "事実のIDまたは日時が違う。")
        typed(fact["value"], c["facts"][key]["spec"])
    for actor, facts in state["knowledge"].items():
        for key, record in facts.items():
            ensure(key in state["facts"] and record["snapshot"]["id"] == key, "knowledge", "存在しない事実の知識。")
            snap, fact = record["snapshot"], state["facts"][key]
            typed(snap["value"], c["facts"][key]["spec"], False)
            ensure(snap["revision"] <= fact["revision"] and snap["created_at"] <= record["learned_at"] <= now, "knowledge", "知識の版または日時が違う。")
            ensure(snap["revision"] != fact["revision"] or snap["value"] == fact["value"], "knowledge", "同じ版の事実が食い違っている。")
    stage = state["relation"]["stage"]
    milestones = state["relation"]["milestones"]
    ensure([x["stage"] for x in milestones] == list(range(1, stage + 1)), "milestone", "関係の節目が一致しない。")
    ensure((stage >= 3) == (state["relation"]["dating_since"] is not None) and (stage >= 4) == (state["relation"]["life_since"] is not None), "milestone", "関係の成立日が一致しない。")
    for milestone in milestones:
        ensure(milestone["id"] == c["milestones"][milestone["stage"] - 1]["id"] and milestone["at"] <= now, "milestone", "節目の種類または日時が不正。")
    if stage >= 3: ensure(state["relation"]["dating_since"] == milestones[2]["at"], "milestone", "交際の成立日が節目と一致しない。")
    if stage >= 4: ensure(state["relation"]["life_since"] == milestones[3]["at"], "milestone", "暮らしの成立日が節目と一致しない。")
    for habit in state["habits"].values():
        ensure((habit["count_days"] == 0) == (habit["last_day"] is None), "habit", "習慣の日数と最終日が一致しない。")
        if habit["last_day"] is not None: ensure(habit["last_day"] <= now // 1440 and habit["count_days"] <= habit["last_day"] + 1, "habit", "習慣の日付が不正。")
        ensure((habit["count_days"] >= 3) == (habit["established_at"] is not None), "habit", "習慣の成立日が日数と一致しない。")
        if habit["established_at"] is not None: ensure(habit["established_at"] <= now, "habit", "習慣の成立日が未来になっている。")
    for experience in state["experience"].values():
        ensure(sum(experience["by_origin"].values()) == experience["count"], "experience", "経験の開始者別集計が合わない。")
        if experience["count"] == 0:
            ensure(experience["first_at"] is None and experience["last_at"] is None, "experience", "未経験に日時がある。")
        else:
            ensure(experience["first_at"] is not None and experience["first_at"] <= experience["last_at"] <= now, "experience", "経験の日時が合わない。")
    scenes = [x for x in [state["scene"], *state["suspended"]] if x]
    scene_ids = {x["id"] for x in scenes}
    ensure(len(scene_ids) == len(scenes) and not (state["scene"] and state["offer"]), "question", "場面が重複、または問いが二件ある。")
    activity_ids = {a["id"] for a in state["activities"]}
    ensure(len(activity_ids) == len(state["activities"]) and sum(a["status"] == "running" for a in state["activities"]) <= 1, "activity", "進行中の活動が重複している。")
    for scene in scenes:
        source = repository.get(scene["release"])
        ensure(source.control_hash == pack.control_hash and scene["scene_id"] in source.scenes, "scene_release", "場面の版が本体と一致しない。")
        definition = source.scenes[scene["scene_id"]]
        ensure(scene["definition_sha256"] == digest(definition) and scene["scene_revision"] == definition["revision"], "scene_release", "保存した場面が書き換わっている。")
        ensure(scene["node"] in {n["id"] for n in definition["nodes"]} and set(scene["locals"]) == set(definition["locals"]), "scene", "保存した区切り・局所値が違う。")
        node = next(n for n in definition["nodes"] if n["id"] == scene["node"])
        ensure(node["choices"] and not node.get("end") and not node.get("auto"), "scene", "保存した場面が入力待ちの区切りではない。")
        for key, value in scene["locals"].items():
            typed(value, definition["locals"][key])
        if scene["activity_id"]:
            ensure(scene["activity_id"] in activity_ids, "activity", "場面の活動が見つからない。")
        if scene is not state["scene"]:
            ensure(scene["saved_frame"] is not None, "scene", "保留した問いがない。")
            ensure(scene["saved_frame"]["question_owner"] == scene["id"] and scene["saved_frame"]["release"] == scene["release"] and scene["saved_frame"]["blocks"] and scene["saved_frame"]["blocks"][-1]["meaning"] == node["meaning"], "scene", "保留した問いの持ち主か本文が一致しない。")
        else: ensure(scene["saved_frame"] is None, "scene", "進行中の場面に保留用の表示が残っている。")
    for activity in state["activities"]:
        ensure(activity["kind"] in c["activities"] and activity["location"] in c["locations"], "activity", "活動が未登録。")
        ensure(activity["participants"] == ["player", "maho"] and activity["started_at"] <= now and activity["remaining_minutes"] <= c["activities"][activity["kind"]]["minutes"], "activity", "活動の参加者・日時・残り時間が不正。")
        if activity["promise_id"]: ensure(any(p["id"] == activity["promise_id"] for p in state["promises"]), "activity", "活動に終了済みの約束が残っている。")
        if activity["scene_owner"]:
            owner = next((s for s in scenes if s["id"] == activity["scene_owner"]), None)
            ensure(owner is not None and owner["activity_id"] == activity["id"], "activity", "活動の所有関係が違う。")
            ensure((activity["status"] == "running") == (owner is state["scene"]), "activity", "活動の保留状態が一致しない。")
        else: ensure(activity["kind"] == "private_time" and activity["id"] == state["private_instance"] and activity["status"] == "running", "activity", "場面に属さない活動が不正。")
    if state["mode"] == "private":
        ensure(state["private_instance"] in activity_ids and stage >= 3 and together and state["actors"]["player"]["location"] in ("player_room", "maho_room"), "private", "二人の時間の状態が合わない。")
    else:
        ensure(state["private_instance"] is None, "private", "終了した時間の記録が残っている。")
    used = Counter()
    values = pack.registry.values(state)
    action_ids = set()
    for contact in state["contacts"]:
        key = contact["action_id"]
        ensure(key in pack.actions and key not in action_ids, "contact", "接触が未登録または重複。")
        action_ids.add(key)
        action = pack.actions[key]
        ensure(action["ongoing"] and contact["resources"] == action["resources"] and (test_cheat_intimacy or stage >= action["min_stage"]), "contact", "接触の宣言が一致しない。")
        ensure(evaluate(action["maintain"], values) is True and (not action["near"] or state["distance"] == "near"), "contact", "続けられない接触が残っている。")
        ensure(all(state["actors"][a]["posture"] in action["postures"] for a in ("player", "maho")), "contact", "姿勢と接触が両立しない。")
        ensure(contact["started_at"] <= now and state["experience"][key]["count"] > 0, "contact", "接触の経験または時刻が合わない。")
        if "side" in contact:  # v8.4.0（010）：手をつなぐ側は、その版で左右を選べる触れ合いだけ
            ensure(pack.intimacy is not None and key in pack.intimacy.daily_sides and contact["side"] in pack.intimacy.daily_sides[key]["choices"], "contact", "手をつなぐ側の宣言が不正。")
        if contact["lifetime"] == "scene":
            ensure(contact["owner_id"] in scene_ids, "contact_owner", "接触を所有する場面がない。")
        elif contact["lifetime"] == "private":
            ensure(contact["owner_id"] is not None and contact["owner_id"] == state["private_instance"], "contact_owner", "接触を所有する時間がない。")
        else:
            ensure(contact["owner_id"] is None, "contact_owner", "継続動作に別の所有者がある。")
        used.update(contact["resources"])
    ensure(all(used[key] <= capacity for key, capacity in c["resources"].items()), "resources", "資源が二重に使われている。")
    for item in state["items"]:
        ensure(item["catalog_id"] in c["items"] and item["owner"] in ("player", "maho") and item["storage"] in {"inventory", *c["locations"]}, "item", "物の登録または所有が違う。")
        if item["installed_at"] is not None: ensure(item["installed_at"] <= now and item["storage"] != "inventory", "item", "設置日時・保管場所が不正。")
    for key, spec in c["items"].items():
        held = sum(i["quantity"] for i in state["items"] if i["catalog_id"] == key)
        pending = sum(o["quantity"] for o in state["orders"] if o["catalog_id"] == key)
        ensure(held + pending <= spec["capacity"], "item_capacity", "所持品と入荷予定が上限を超えている。")
    for promise in state["promises"]:
        ensure(promise["status"] == "pending" and promise["kind"] in c["promise_kinds"] and promise["place"] in c["locations"] and promise["resolved_at"] is None, "promise", "未完了の約束が不正。")
    for promise in state["promises"] + state["promise_history"]:
        ensure(promise["kind"] in c["promise_kinds"] and promise["participants"] == ["player", "maho"] and promise["place"] in c["activities"][promise["kind"]]["locations"] and promise["created_at"] <= now and promise["due_at"] > promise["created_at"], "promise", "約束の内容が不正。")
    for promise in state["promise_history"]: ensure(promise["status"] in ("fulfilled", "cancelled") and promise["resolved_at"] is not None and promise["created_at"] <= promise["resolved_at"] <= now, "promise", "解決済みの約束が不正。")
    for order in state["orders"]:
        ensure(order["status"] in ("ordered", "delivered") and order["catalog_id"] in c["items"], "order", "注文の状態が不正。")
        ensure(order["due_at"] > now if order["status"] == "ordered" else order["due_at"] <= now, "order", "配送時刻と状態が合わない。")
        ensure(order["resolved_at"] is None, "order", "未完了の注文に終了日がある。")
    for order in state["orders"] + state["order_history"]: ensure(order["catalog_id"] in c["items"] and order["created_at"] <= now and order["due_at"] > order["created_at"], "order", "注文の内容が不正。")
    for order in state["order_history"]: ensure(order["status"] in ("received", "cancelled") and order["resolved_at"] is not None and order["created_at"] <= order["resolved_at"] <= now, "order", "解決済みの注文が不正。")
    if state["project"]:
        project = state["project"]
        ensure(project["catalog_id"] in c["items"] and c["items"][project["catalog_id"]]["large"], "project", "共同作業の品物が違う。")
        if project["status"] in ("ordered", "delivered"):
            order = next((o for o in state["orders"] if o["id"] == project["order_id"]), None)
            ensure(order is not None and order["status"] == project["status"], "project", "注文と共同作業が食い違っている。")
    def memory_valid(memory):
        ensure(memory["kind"] in c["memory_kinds"] and memory["at"] <= now and memory["location"] in c["locations"] and set(memory["participants"]) <= c["actors"].keys(), "memory", "思い出の根拠が不正。")
        spec = c["memory_specs"][memory["kind"]]
        keys = [f["id"] for f in memory["facts"]]
        ensure(len(set(keys)) == len(keys) and set(keys) <= set(spec["facts"]) and memory["choice_summary"].keys() <= spec["summary"].keys(), "memory", "思い出の内容が登録を超えている。")
        for key, value in memory["choice_summary"].items(): typed(value, spec["summary"][key])
        for fact in memory["facts"]:
            ensure(fact["id"] in c["facts"] and fact["revision"] <= state["facts"][fact["id"]]["revision"] and fact["created_at"] <= memory["at"], "memory", "思い出の事実が不正。")
            typed(fact["value"], c["facts"][fact["id"]]["spec"], False)
    for memory in state["memories"]["recent"] + state["memories"]["pinned"]:
        memory_valid(memory)
    for key, summary in state["memories"]["summaries"].items():
        ensure(key in c["memory_kinds"] and summary["first"]["kind"] == summary["last"]["kind"] == key, "memory", "記憶の集計が不正。")
        memory_valid(summary["first"])
        memory_valid(summary["last"])
        ensure(summary["first"]["at"] <= summary["last"]["at"], "memory", "思い出の集計日時が逆転している。")
    for scene in scenes:
        for memory in scene["memories"]: memory_valid(memory)
    for message in state["inbox"]:
        ensure(message["sender"] in c["actors"] and message["recipient"] in c["actors"] and message["at"] <= now and (message["read_at"] is None or message["at"] <= message["read_at"] <= now), "message", "便りの人物・日時が不正。")
        for fact in message["facts"]:
            ensure(fact["id"] in c["facts"] and fact["revision"] <= state["facts"][fact["id"]]["revision"] and fact["created_at"] <= message["at"], "message", "便りの知識が不正。")
            typed(fact["value"], c["facts"][fact["id"]]["spec"], False)
    ensure(state["intention"] is None or state["intention"]["kind"] in c["goals"], "goal", "希望が未登録。")
    if state["offer"]:
        offer = state["offer"]
        ensure(offer["kind"] in c["offers"] and offer["started_at"] <= now and offer["accept_action"] in ("offer.accept", "private.begin") and offer["decline_action"] == "offer.decline", "offer", "返事を待つ誘いが不正。")
        ensure(offer["source_goal"] is None or offer["source_goal"] in c["goals"], "offer", "誘いの根拠が未登録。")
    maho_free = not state["scene"] and not state["offer"] and not state["contacts"] and state["mode"] == "normal" and not any(a["status"] == "running" for a in state["activities"])
    progression.check_state(state, pack.progression, maho_free, clock.minutes(c["start_at"]))
    all_ids = [x["id"] for group in (state["contacts"], state["activities"], scenes, state["promises"], state["promise_history"], state["orders"], state["order_history"], state["items"]) for x in group]
    ensure(len(all_ids) == len(set(all_ids)), "instance_id", "実行記録のIDが重複している。")
