"""v8.4.21（ユーザー 2026-10-07 13:41「進めろ。次があるだろ」）：010 だけ。
本文の再会を減らす 七束目（手をつなぐ・耳もと首すじ・服の上から胸・もう一度深く口づけるの落ち着いた反応、もっとせがむ合図の mid・高い反応）。"""
import re
import unittest
from pathlib import Path

from nagishima.content import Pack

ROOT = Path(__file__).resolve().parents[1]
P009 = Pack(ROOT / "content/releases/interaction_009")
P010 = Pack(ROOT / "content/releases/interaction_010")
NEW = [t for t in P010.texts if t["id"].startswith("cmp.") and re.match(r"u[1-4]", t["id"].rsplit(".", 1)[1])]
PREV = lambda name: {"field": f"flow.prev.{name}", "op": "eq", "value": False}  # noqa: E731


class V8421(unittest.TestCase):
    def test_009_unchanged(self):
        self.assertFalse(any(t["id"].startswith("cmp.") for t in P009.texts))

    def test_new_scenes(self):
        meanings = {t["meaning"] for t in NEW}
        self.assertEqual(meanings, {"h_hands.start", "h_ear_neck.start", "h_chest_over.start", "h.sign.wants_more", "h_kiss_deep.again"})
        flow = P010.intimacy.flow
        for text in NEW:
            a, b = text["id"].rsplit(".", 2)[1:]
            self.assertEqual(text["group"], f"cmp.{text['meaning']}.{a}")  # v8.4.20：まとまりは前半ごと
            if "bcalm" in b:
                self.assertIn(PREV("urgent"), text["when"]["all"], text["id"])
            if "bhot" in b:
                self.assertIn(PREV("end"), text["when"]["all"], text["id"])
            if text["meaning"] == "h.sign.wants_more":
                self.assertIn("begging", flow.info(text)[3], text["id"])
            if a.startswith("op"):  # つなぎ直す前半は「絡め」「からめ」を書いた後半とつながない
                self.assertNotIn("からめ", text["body"])

    def test_review_fixes(self):
        """読む係の指摘（v8421/read）での直し。"""
        hands_both = {"field": "contact.h_hands_both.active", "op": "eq", "value": False}
        back = {"field": "contact.h_back.active", "op": "eq", "value": False}
        for text in P010.texts:
            if not text["id"].startswith("cmp."):
                continue
            a, b = text["id"].rsplit(".", 2)[1:]
            self.assertFalse(b == "u3enbcalm02" and a in ("x2enaface02", "x3enaface02", "x4enaface03", "x1enaback01", "x2enaback01", "x4enaback01"), text["id"])
            if text["meaning"] == "h.sign.wants_more" and a in ("w6wmaface03", "w5wmaface03", "w6wmaface01"):
                self.assertIn(hands_both, text["when"]["all"], text["id"])
            if text["meaning"] == "h.sign.wants_more" and a in ("w5wmaback01", "w6wmaface01", "w7wmaface02"):
                self.assertIn(back, text["when"]["all"], text["id"])
            self.assertFalse(any("わたし" in q for q in re.findall(r"「[^」]*」", text["body"])), text["id"])
        self.assertFalse(any(t["id"].endswith((".u2kabcalm03", ".u3wmbhot02")) for t in NEW))
        self.assertTrue(any("「手、つかまっちゃった」" in t["body"] for t in NEW))


if __name__ == "__main__":
    unittest.main()
