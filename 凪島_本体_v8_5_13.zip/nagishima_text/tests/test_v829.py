"""v8.2.9（ユーザー了承 2026-09-28 10:06〜10:31）：素股・胸でしてもらう（パイずり）・足でしてもらう（足コキ）、
追加（先端を舐める・玉を揉む）、お願いの履歴と真帆の申し出。公開の選択肢から確かめる（時刻・高まり・回数などの準備だけ内部で行う）。"""
import unittest

from tools.run_stage_b_routes import Route


def choices(engine):
    return {c["id"]: c for c in engine.get_view()["choices"]}


def meanings(engine):
    return [b["meaning"] for b in engine.get_view()["blocks"]]


def variants(engine):
    return [b["variant"] for b in engine.get_view()["blocks"]]


def explain(engine, identity):
    return engine.get_view()["explanations"].get(identity)


def authored(variant, meaning):
    """Opus か grok（第9陣・第10陣）の本文か（v8.2.11：grok の本文が入って、どちらが選ばれるかは乱数しだい）。"""
    return ("." + meaning + ".") in ("." + variant) and not variant.endswith(".base")


class V829(unittest.TestCase):
    def route(self, *args, **kwargs):
        route = Route(*args, **kwargs)
        self.addCleanup(route.close)
        return route

    def ready(self, seed, tier, position="h_pos_lying_face", upper=False, arousal=50, band="mid", **kwargs):
        route = self.route(seed, tier=tier, day_offset=2, **kwargs)
        route.begin()
        keys = ["h_strip_lower", "h_shift_under", "h_strip_self"] + (["h_strip_upper"] if upper else []) + [position]
        for key in keys:
            route.action(key)
        route.engine._state["intimacy"]["maho"].update(arousal=arousal, band=band)  # 準備：真帆の高まり
        route.engine._install_choices()
        return route

    def to_main(self, route):
        if route.engine.get_view()["page"] != "main":
            route.choose("menu.main")

    def set_experience(self, route, key, count):
        """準備：これまでにした（お願いした）回数。日時と開始者別の集計も合わせる。"""
        now = route.engine.snapshot()["world"]["now"]
        route.engine._state["experience"][key] = {"count": count, "first_at": now - 2880, "last_at": now - 1440, "by_origin": {"player": count, "maho": 0}}
        route.engine._install_choices()

    def contacts(self, route):
        return [c["action_id"] for c in route.engine.snapshot()["contacts"]]

    # ---- 素股 ----
    def test_sumata_from_behind_to_finish(self):
        first = self.ready(301, "first", position="h_pos_player_above")
        first.choose("menu.main")
        first.choose("menu.h_connect")
        self.assertNotIn("touch.h_sumata", choices(first.engine))  # v8.2.19（ユーザー）：回数で開く行為は、開くまで一覧に出さない
        route = self.ready(302, "few", position="h_pos_from_behind")
        route.action("h_sumata")
        self.assertEqual(meanings(route.engine)[0], "h_sumata.first")  # v8.2.11：第9陣で初めての本文がそろった
        self.assertTrue(authored(variants(route.engine)[0], "h_sumata.first"), variants(route.engine))
        self.assertIn("h_sumata", self.contacts(route))
        for _ in range(8):
            route.action("h_sumata")
            if route.engine.snapshot()["intimacy"]["player"]["arousal"] >= 70:
                break
        state = route.engine.snapshot()["intimacy"]
        self.assertGreaterEqual(state["player"]["arousal"], 70)  # 素股は入れていなくても出せるところまで上がる
        self.assertLessEqual(state["maho"]["arousal"], 85)
        self.to_main(route)
        self.assertEqual(choices(route.engine)["touch.h_finish_sumata"]["label"], "股のあいだで出す")
        route.choose("touch.h_finish_sumata")
        state = route.engine.snapshot()["intimacy"]
        self.assertEqual((state["player"]["finishes"], state["mess"], state["inserted"]), (1, "outside", False))
        self.assertTrue(authored(variants(route.engine)[0], "h_finish_sumata.start"), variants(route.engine))

    def test_sumata_at_the_limit_overflows_and_stop_is_endure(self):
        route = self.ready(311, "few", position="h_pos_player_above")
        route.action("h_sumata")
        route.engine._state["intimacy"]["player"]["arousal"] = 100  # 準備：限界
        route.engine._install_choices()
        self.to_main(route)
        self.assertEqual(choices(route.engine)["touch.h_sumata"]["label"], "素股を続ける（もうこらえきれない）")
        self.assertEqual(choices(route.engine)["end.h_sumata"]["label"], "素股をやめる（こらえる）")
        route.choose("end.h_sumata")
        found = meanings(route.engine)
        self.assertEqual(found[0], "h_endure.sumata")
        self.assertLessEqual(set(found[1:]), {"h.stroke_back.endure"})  # v8.2.14：こらえたあと、真帆が頭を撫で返すことがある
        route2 = self.ready(312, "few", position="h_pos_player_above")
        route2.action("h_sumata")
        route2.engine._state["intimacy"]["player"]["arousal"] = 100
        route2.engine._install_choices()
        route2.action("h_sumata")
        self.assertEqual(meanings(route2.engine)[0], "h_overflow.sumata")
        self.assertEqual(route2.engine.snapshot()["intimacy"]["player"]["finishes"], 1)

    # ---- 胸でしてもらう・先端も舐めてもらう ----
    def test_breasts_with_lick_extra(self):
        route = self.ready(321, "few", upper=True)
        route.choose("menu.main")
        route.choose("menu.h_service")
        found = choices(route.engine)
        self.assertEqual(found["touch.h_maho_breasts"]["label"], "胸でしてもらう")
        self.assertNotIn("touch.h_extra_lick", found)  # 追加は、胸でしてもらっている最中だけ並ぶ
        route.choose("touch.h_maho_breasts")
        self.assertEqual(meanings(route.engine)[0], "h_maho_breasts.first")  # 初めてはお願いする本文
        self.assertTrue(authored(variants(route.engine)[0], "h_maho_breasts.first"), variants(route.engine))
        self.assertEqual(route.engine.pack.registry.values(route.engine.snapshot())["intimacy.facing"], "maho_breasts")
        self.to_main(route)
        self.assertEqual(choices(route.engine)["touch.h_extra_lick"]["label"], "先端も舐めてもらう")
        route.choose("touch.h_extra_lick")
        self.assertEqual(meanings(route.engine)[0], "h_extra_lick.start")
        self.assertEqual(route.engine.snapshot()["intimacy"]["extras"], ["lick"])
        before = route.engine.snapshot()["intimacy"]["player"]["arousal"]
        route.action("h_maho_breasts")
        self.assertIn(meanings(route.engine)[0], ("h_maho_breasts_lick.continue", "h_maho_breasts_lick.continue_short"))  # v8.2.22：続けているあいだは短い本文（長い本文は3手に1回）
        self.assertEqual(route.engine.snapshot()["intimacy"]["player"]["arousal"], min(100, before + 14 + 4))  # 追加の分だけ強く上がる
        self.to_main(route)
        self.assertNotIn("touch.h_extra_lick", choices(route.engine))  # 足したあとは並ばない
        route.choose("end.h_maho_breasts")
        self.assertEqual(route.engine.snapshot()["intimacy"]["extras"], [])  # 胸をやめると追加も終わる

    def test_breasts_needs_upper_off(self):
        route = self.ready(322, "few")
        route.choose("menu.main")
        route.choose("menu.h_service")
        self.assertFalse(choices(route.engine)["touch.h_maho_breasts"]["available"])
        self.assertIn("服をめくり上げる", explain(route.engine, "touch.h_maho_breasts"))  # めくるか脱がせる

    # ---- 足でしてもらう ----
    def test_feet_from_familiar(self):
        few = self.ready(331, "few")
        few.choose("menu.main")
        few.choose("menu.h_service")
        self.assertNotIn("touch.h_maho_feet", choices(few.engine))  # v8.2.19（ユーザー）：慣れで開く行為は、開くまで一覧に出さない
        route = self.ready(332, "familiar")
        route.action("h_maho_feet")
        self.assertEqual(meanings(route.engine)[0], "h_maho_feet.first")
        self.assertTrue(authored(variants(route.engine)[0], "h_maho_feet.first"), variants(route.engine))  # 初めてはお願いする本文（v8.2.11：grok の本文も）
        self.assertEqual(route.engine.pack.registry.values(route.engine.snapshot())["intimacy.facing"], "maho_feet")
        route.engine._state["intimacy"]["player"]["arousal"] = 80
        route.engine._install_choices()
        route.action("h_finish_feet")
        self.assertEqual(route.engine.snapshot()["intimacy"]["mess"], "outside")

    # ---- 玉も揉んでもらう（手・口） ----
    def test_balls_extra_with_hand_ends_with_hand(self):
        route = self.ready(341, "few")
        route.action("h_maho_hand")
        route.action("h_extra_balls")
        self.assertEqual(meanings(route.engine)[0], "h_extra_balls.start")
        route.action("h_maho_hand")
        self.assertIn(meanings(route.engine)[0], ("h_maho_hand_balls.continue", "h_maho_hand_balls.continue_short"))  # v8.2.22：続けているあいだは短い本文（長い本文は3手に1回）
        self.to_main(route)
        route.choose("end.h_maho_hand")
        route.action("h_maho_hand")
        route.action("h_maho_hand")
        self.assertNotEqual(meanings(route.engine)[0], "h_maho_hand_balls.continue")
        self.assertEqual(route.engine.snapshot()["intimacy"]["extras"], [])

    def test_balls_extra_with_mouth_keeps_mouth(self):
        route = self.ready(345, "few")
        route.action("h_maho_mouth")
        route.action("h_extra_balls")
        self.assertIn("h_maho_mouth", self.contacts(route))  # 口は終わらない
        route.action("h_maho_mouth")
        self.assertIn(meanings(route.engine)[0], ("h_maho_mouth_balls.continue", "h_maho_mouth_balls.continue_short"))  # v8.2.22：続けているあいだは短い本文（長い本文は3手に1回）
        route.action("h_maho_mouth")  # さらに続けても（settled の本文がなければ continue の本文）
        self.assertIn(meanings(route.engine)[0], ("h_maho_mouth_balls.continue", "h_maho_mouth_balls.continue_short"))  # v8.2.22：続けているあいだは短い本文（長い本文は3手に1回）

    def test_other_action_ends_breasts(self):
        route = self.ready(346, "few", upper=True)
        route.action("h_maho_breasts")
        route.action("h_check")  # 様子を聞くと、真帆は胸を離して答える
        self.assertNotIn("h_maho_breasts", self.contacts(route))
        self.assertFalse(variants(route.engine)[0].endswith(".base"), variants(route.engine))

    # ---- お願いの履歴：真帆が自分から ----
    def test_maho_offers_feet_after_three_requests(self):
        found = None
        for seed in range(351, 361):
            route = self.ready(seed, "familiar")
            self.set_experience(route, "h_maho_feet", 3)  # 準備：これまでに3回お願いした
            route.engine._state["intimacy"]["player"]["arousal"] = 30
            route.engine._install_choices()
            for _ in range(10):
                route.action("h_chest_over")  # v8.2.25（精査 A-3）：深い口づけ・耳元・胸に口づけている最中は、胸・足の申し出を出さない
                offer = route.engine.snapshot()["offer"]
                if offer and offer["kind"].startswith("h_lead_"):
                    route.choose("offer.decline")  # 上に乗る・自分から入れるの申し出は別の仕組み
                    continue
                if offer:
                    found = (route, offer["kind"])
                    break
            if found:
                break
        self.assertIsNotNone(found)
        route, kind = found
        self.assertEqual(kind, "h_help_feet")
        self.assertIn("offer.h_help.feet", meanings(route.engine))
        route.choose("offer.accept")
        self.assertIn("h_maho_feet", self.contacts(route))
        self.assertIn("h_help_feet", route.engine.snapshot()["intimacy"]["offered"])

    def test_no_offer_before_three_requests(self):
        route = self.ready(362, "familiar")
        self.set_experience(route, "h_maho_feet", 2)
        self.set_experience(route, "h_maho_breasts", 2)
        route.engine._state["intimacy"]["player"]["arousal"] = 30
        route.engine._install_choices()
        for _ in range(12):
            route.action("h_chest_over")  # v8.2.25：申し出が出うる行為で（口づけの最中は出さない）
            offer = route.engine.snapshot()["offer"]
            if offer:
                self.assertTrue(offer["kind"].startswith("h_lead_"), offer)
                route.choose("offer.decline")

    def test_maho_adds_balls_herself_after_requests(self):
        seen = False
        for seed in range(371, 381):
            route = self.ready(seed, "familiar")
            self.set_experience(route, "h_extra_balls", 3)  # 準備：玉を揉んでと3回お願いした
            route.action("h_maho_hand")
            for _ in range(4):
                if route.engine.snapshot()["intimacy"]["player"]["arousal"] >= 90:
                    break
                route.action("h_maho_hand")
                if "h_extra_balls.maho" in meanings(route.engine):
                    seen = True
                    self.assertEqual(route.engine.snapshot()["intimacy"]["extras"], ["balls"])
                    self.assertTrue(authored(variants(route.engine)[meanings(route.engine).index("h_extra_balls.maho")], "h_extra_balls.maho"))
                    break
            if seen:
                break
        self.assertTrue(seen)

    def test_limit_in_back_position_can_finish_by_sumata(self):
        route = self.ready(391, "few")
        for _ in range(20):
            route.action("h_maho_hand")
            if route.engine.snapshot()["intimacy"]["player"]["arousal"] >= 100:
                break
        route.action("h_pos_from_behind")
        self.to_main(route)
        route.choose("menu.h_clothes")
        # v8.2.29：限界でも口づけ・愛撫は選べるので、服の行動の理由で確かめる
        self.assertEqual(explain(route.engine, "touch.h_lift_upper"), "もう限界だ。「こらえる」か、出す（このまま入れても、こらえきれない）。口づけや愛撫はできる。")
        self.to_main(route)
        route.choose("menu.h_connect")
        self.assertEqual(choices(route.engine)["touch.h_sumata"]["label"], "素股をする（もうこらえきれない）")


if __name__ == "__main__":
    unittest.main()
