"""v8.0.5：試運転の指摘と段階B再監査（v8.0.4）の直しを、公開経路で確かめる。

準備（時刻・一部の数値）だけ内部状態を使う。以降は Engine.choose／get_view だけで操作する。
開始日 2038-04-07 は水曜（勤務日）。勤務は 8:30〜12:00、13:00〜15:00、15:15〜17:30。
"""
import json
import tempfile
import unittest
from pathlib import Path

from nagishima.engine import Engine
from nagishima.errors import GameError
from nagishima.menus import entries

ROOT = Path(__file__).resolve().parents[1]
H_PAGES = {"kiss": "h_touch", "caress": "h_touch", "undress": "h_clothes", "position": "h_position",
           "insert": "h_connect", "move": "h_connect", "words": "h_words", "after": "h_words"}


class Play:
    def __init__(self, test, hour=19, minute=0, release="interaction_009", tier="few", cheat=True, seed=42, day=0):
        self.test = test
        self.temp = tempfile.TemporaryDirectory(prefix="nagishima-v805-")
        test.addCleanup(self.temp.cleanup)
        self.e = Engine(self.temp.name, seed=seed, release=release, autosave=False, test_cheats=True)
        if cheat:
            self.e.enable_test_cheat("all")
            if tier and release == "interaction_009":
                self.e.enable_test_cheat("intimacy_tier:" + tier)
        self.at(hour, minute, day)

    def at(self, hour, minute=0, day=0):
        world = self.e._state["world"]
        start = getattr(self, "_day", None)
        if start is None:
            self._day = start = world["now"] // 1440
        new = (start + day) * 1440 + hour * 60 + minute
        world.update(now=new, processed_until=new)
        world["awake_deadline"] = ((new - 300) // 1440 + 1) * 1440 + 300
        self.e._install_choices()
        if self.e.pack.intimacy:
            from tools.run_stage_b_routes import dinner_done, bath_done
            dinner_done(self.e)  # v8.1.0：自動の夕食は、試験の準備で済んだことにする
            bath_done(self.e)  # v8.2.0：自動の風呂も同じ

    @property
    def s(self):
        return self.e.snapshot()

    def view(self):
        return self.e.get_view()

    def option(self, identity):
        return next((c for c in self.view()["choices"] if c["id"] == identity), None)

    def choose(self, identity):
        view = self.view()
        option = next((c for c in view["choices"] if c["id"] == identity), None)
        self.test.assertIsNotNone(option, (identity, [c["id"] for c in view["choices"]]))
        self.test.assertTrue(option["available"], (identity, option, view["explanations"].get(identity)))
        return self.e.choose(identity, view["revision"], view["session"])

    def page(self, name):
        offer = self.s["offer"]
        if offer and offer["kind"].startswith("h_lead_"):
            self.choose("offer.decline")
        if self.view()["page"] != "main" and self.option("menu.main") is not None:
            self.choose("menu.main")
        if name != "main":
            self.choose("menu." + name)

    def h(self, key):
        offer = self.s["offer"]
        if offer and offer["kind"].startswith("h_lead_"):
            self.choose("offer.decline")
        if self.option("touch." + key) is None:
            if self.option("menu.main") is not None and self.view()["page"] != "main":
                self.choose("menu.main")
            if self.option("touch." + key) is None:
                self.choose("menu." + H_PAGES[self.e.pack.intimacy.actions[key]["category"]])
        return self.choose("touch." + key)

    def meanings(self, result=None):
        return [b["meaning"] for b in (result or self.view())["blocks"]]

    def minute(self):
        return self.s["world"]["now"] % 1440


class Playtest1Listen(unittest.TestCase):
    def test_009_label_is_look_and_only_when_together(self):
        p = Play(self)
        self.assertEqual(p.option("listen")["label"], "真帆の様子を見る")
        p.page("move")
        p.choose("move.solo.kitchen")
        p.page("main")
        self.assertIsNone(p.option("listen"))

    def test_008_label_is_unchanged(self):
        p = Play(self, release="interaction_008", tier=None)
        self.assertEqual(p.option("listen")["label"], "真帆の様子を聞く")

    def test_listen_texts_with_maho_lines_exist(self):
        rows = [r for r in json.loads((ROOT / "tools/stage_b/life_texts.json").read_text(encoding="utf-8")) if r["meaning"] == "system.listen"]
        self.assertGreaterEqual(len(rows), 6)
        self.assertTrue(all("「" in r["body"] for r in rows))


class Playtest2ActionTime(unittest.TestCase):
    def test_talk_touch_continue_listen_take_time_in_normal_mode(self):
        p = Play(self, hour=19)
        p.page("talk")
        start = p.s["world"]["now"]
        p.choose("touch.talk")
        self.assertEqual(p.s["world"]["now"] - start, 5)
        p.page("touch")
        if p.option("near") is not None:
            p.choose("near")
        start = p.s["world"]["now"]
        p.choose("touch.hands")
        self.assertEqual(p.s["world"]["now"] - start, 2)
        start = p.s["world"]["now"]
        p.choose("touch.hands")
        self.assertEqual(p.s["world"]["now"] - start, 2)
        p.page("main")
        start = p.s["world"]["now"]
        p.choose("listen")
        self.assertEqual(p.s["world"]["now"] - start, 5)

    def test_choice_shows_duration(self):
        p = Play(self, hour=19)
        p.page("talk")
        self.assertEqual(p.option("touch.talk")["duration"], 5)

    def test_no_time_in_private(self):
        p = Play(self, hour=19)
        p.choose("private.begin")
        start = p.s["world"]["now"]
        p.page("talk")
        p.choose("touch.talk")
        self.assertEqual(p.s["world"]["now"], start)

    def test_break_end_goes_to_work_automatically(self):
        # v8.0.8：仕事の時刻になったら、そのまま仕事へ行く。選択肢の所要分は、その操作の分だけ。
        p = Play(self, hour=12, minute=58)
        p.page("talk")
        self.assertEqual(p.option("touch.talk")["duration"], 2)
        result = p.choose("touch.talk")
        self.assertEqual(p.meanings(result)[-1], "work.block.afternoon")
        self.assertEqual(p.minute(), 15 * 60)
        self.assertEqual(p.view()["status"]["work"], "15:15から")

    def test_at_work_time_only_work(self):
        # 準備は内部：仕事の時刻ちょうどの状態を作る（ふだんは自動で仕事へ行くので、この状態にはとどまらない）。
        p = Play(self, hour=13)
        p.page("talk")
        option = p.option("touch.talk")
        self.assertFalse(option["available"])
        self.assertEqual(option["reason"], "work_time")
        p.page("main")
        self.assertTrue(p.option("work.go")["available"])
        self.assertEqual(p.option("work.go")["label"], "仕事に戻る")

    def test_wait_stops_at_work_then_work_and_lunch(self):
        p = Play(self, hour=7, minute=30)
        self.assertEqual(p.view()["status"]["work"], "8:30から")
        self.assertEqual(p.option("wait.120")["duration"], 60)
        result = p.choose("wait.120")
        self.assertEqual(p.meanings(result)[:3], ["system.waited", "work.block.morning", "work.lunch"])
        self.assertEqual(p.minute(), 12 * 60 + 20)

    def test_008_actions_take_no_time(self):
        p = Play(self, hour=19, release="interaction_008", tier=None)
        p.page("talk")
        start = p.s["world"]["now"]
        p.choose("touch.talk")
        self.assertEqual(p.s["world"]["now"], start)


class Playtest3Meal(unittest.TestCase):
    def test_meal_allows_talk_only_and_ends_contacts(self):
        p = Play(self, hour=15, day=3)  # v8.2.26：夕食を済ませた夜はもう食事をしない（v8.2.19 から 21時にしていた）。休みの日の昼下がりに
        p.page("move")
        p.choose("move.joint.kitchen")
        p.page("touch")
        if p.option("near") is not None:
            p.choose("near")
        p.choose("touch.hands")
        self.assertTrue(p.s["contacts"])
        p.page("activities")
        result = p.choose("activity.meal")
        self.assertEqual(p.s["contacts"], [])
        self.assertIn("system.contact_ended", p.meanings(result))
        micro = {c["id"] for c in p.view()["choices"] if c["id"].startswith("touch.")}
        self.assertEqual(micro, {"touch.talk"})

    def test_v806_help_and_repair_also_hands_free(self):
        for kind in ("help", "repair"):
            with self.subTest(kind=kind):
                p = Play(self, hour=19)
                p.page("touch")
                if p.option("near") is not None:
                    p.choose("near")
                p.choose("touch.hands")
                p.page("move")
                p.choose("move.joint.workshop")
                p.page("touch")
                if p.option("near") is not None:
                    p.choose("near")
                if not any(c["action_id"] == "hands" for c in p.s["contacts"]):
                    p.choose("touch.hands")
                p.page("activities")
                result = p.choose("activity." + kind)
                self.assertEqual(p.s["contacts"], [])
                self.assertIn("system.contact_ended", p.meanings(result))
                micro = {c["id"] for c in p.view()["choices"] if c["id"].startswith("touch.")}
                self.assertEqual(micro, {"touch.talk"})

    def test_008_meal_scene_is_unchanged(self):
        p8 = json.loads((ROOT / "content/releases/interaction_008/scenes.json").read_text(encoding="utf-8"))
        for kind in ("meal", "help", "repair"):
            scene = next(s for s in p8 if s["id"] == "activity_" + kind)
            self.assertEqual(scene["nodes"][0]["micro"], ["talk", "head", "hands", "kiss"])


class CheckerFixes(unittest.TestCase):
    """独立した検査役（G・H）が v8.0.5 の途中で見つけた抜け道。"""

    def test_g01_resuming_meal_ends_contacts(self):
        p = Play(self, hour=15, day=3)  # test_meal_allows_talk_only_and_ends_contacts と同じ（v8.2.26：夕食を済ませた夜はもう食事をしない）
        p.page("move")
        p.choose("move.joint.kitchen")
        p.page("activities")
        p.choose("activity.meal")
        p.choose("scene.pause")
        p.page("touch")
        if p.option("near") is not None:
            p.choose("near")
        p.choose("touch.hands")
        self.assertTrue(p.s["contacts"])
        p.page("resume")
        p.choose(next(c["id"] for c in p.view()["choices"] if c["id"].startswith("resume.")))
        self.assertEqual(p.s["contacts"], [])

    def test_g02_no_topics_resume_or_offers_at_work(self):
        # 準備は内部：仕事の時刻ちょうど（v8.0.8 からは、ふだんは自動で仕事へ行く）。
        p = Play(self, hour=8, minute=30)
        p.page("talk")
        topics = [c for c in p.view()["choices"] if c["id"].startswith("begin.")]
        self.assertTrue(topics)
        self.assertTrue(all(not c["available"] and c["reason"] == "work_time" for c in topics), topics)
        p.page("main")
        self.assertFalse(p.option("listen")["available"])
        self.assertTrue(p.option("work.go")["available"])

    def test_g02_no_kiss_back_offer_at_work_start(self):
        p = Play(self, hour=8, minute=26)
        p.page("touch")
        if p.option("near") is not None:
            p.choose("near")
        p.choose("touch.kiss")
        result = p.choose("touch.kiss")
        self.assertIn("work.block.morning", p.meanings(result))
        self.assertTrue(p.s["offer"] is None or p.s["offer"]["kind"] != "kiss_back")

    def test_h21_one_contact_ended_text_when_several_end(self):
        p = Play(self, hour=19)
        p.page("touch")
        if p.option("near") is not None:
            p.choose("near")
        p.choose("touch.hands")
        p.choose("touch.hair")
        p.page("move")
        result = p.choose("move.solo.kitchen")
        self.assertEqual(p.meanings(result).count("system.contact_ended"), 1)


class Playtest808(unittest.TestCase):
    """v8.0.8：2回目の試運転の指摘。"""

    def test_wait_ends_contacts(self):
        p = Play(self, hour=19)
        p.page("touch")
        if p.option("near") is not None:
            p.choose("near")
        p.choose("touch.head")
        p.page("main")
        result = p.choose("wait.30")
        self.assertEqual(p.s["contacts"], [])
        self.assertEqual(p.meanings(result).count("system.contact_ended"), 1)

    def test_blocked_touch_names_contact_and_how_to_end(self):
        p = Play(self, hour=19)
        p.page("touch")
        if p.option("near") is not None:
            p.choose("near")
        p.choose("touch.head")
        self.assertFalse(p.option("touch.cheek")["available"])
        self.assertEqual(p.view()["explanations"]["touch.cheek"], "「頭を撫でる」を続けていて、手や姿勢がふさがっている。先に「頭を撫でるのをやめる」を選ぶ。")

    def test_locked_intimacy_actions_are_listed_with_steps(self):
        p = Play(self, hour=20, tier="first")
        p.choose("private.begin")
        p.page("touch")
        p.choose("touch.h_kiss_deep")
        p.page("h_connect")
        option = p.option("touch.h_insert")
        self.assertFalse(option["available"])
        self.assertEqual(p.view()["explanations"]["touch.h_insert"], "先に「下を脱がせる」→「下着をずらす」、「自分の下を脱ぐ」、体位を「横になって向き合う」か「真帆の上に重なる」にする。")  # v8.2.1：向かい合って横になってもつながれる
        for key in ("h_strip_lower", "h_shift_under", "h_strip_self", "h_pos_player_above"):
            p.h(key)
        p.page("h_connect")
        self.assertTrue(p.option("touch.h_insert")["available"])

    def test_spent_stamina_guides_to_end(self):
        p = Play(self, hour=20, tier="few")
        p.choose("private.begin")
        p.page("touch")
        p.choose("touch.h_kiss_deep")
        for key in ("h_strip_lower", "h_shift_under", "h_strip_self", "h_pos_player_above"):
            p.h(key)
        # 準備は内部：余力1、真帆は入れられる高まり、主人公は出せる高まり。
        p.e._state["stamina"]["value"] = 1
        p.e._state["intimacy"]["maho"]["arousal"] = 60
        p.e._install_choices()
        p.h("h_insert")
        p.e._state["intimacy"]["player"]["arousal"] = 90
        p.e._install_choices()
        result = p.h("h_finish_inside")
        self.assertIn("h.spent", p.meanings(result))
        spent = next(b for b in result["blocks"] if b["meaning"] == "h.spent")
        level = "high" if p.s["intimacy"]["maho"]["satisfaction"] >= 60 else "low_mid"
        self.assertEqual(spent["variant"].startswith("o6.h.spent.unsatisfied."), level == "low_mid", (spent["variant"], p.s["intimacy"]["maho"]))
        p.page("main")
        self.assertEqual(p.option("h.end")["label"], "終える（余力が尽きた）")
        p.page("h_connect")
        self.assertEqual(p.view()["explanations"]["touch.h_move_slow"], "余力が尽きた。口づけや指で触れることはできる。締めくくるなら「抱きしめて休む」か「終える」。")

    def test_lunch_texts_exist(self):
        rows = [r for r in json.loads((ROOT / "tools/stage_b/life_texts.json").read_text(encoding="utf-8")) if r["meaning"] == "work.lunch"]
        self.assertGreaterEqual(len(rows), 5)


class Playtest4BusyMessage(unittest.TestCase):
    def test_busy_in_private_names_private_time(self):
        p = Play(self, hour=19)
        p.choose("private.begin")
        # v8.1.0：二人の時間の中では選べない「過ごす」「休む」「移動」「一緒に過ごす」は並べない（3回目の試運転の指摘6）
        ids = {c["id"] for c in p.view()["choices"]}
        self.assertFalse(ids & {"menu.activities", "menu.move", "wait.30", "wait.120", "sleep"})
        self.assertIn("private.end", ids)
        from nagishima.context import Context
        from nagishima.codec import clone_state
        from nagishima.errors import GameError
        context = Context(clone_state(p.e._state), p.e.pack, p.e.repository, p.e._frame, True)
        with self.assertRaises(GameError) as caught:
            context.apply({"op": "move", "location": "kitchen"})
        self.assertEqual(caught.exception.message, "進行中の「二人の時間」を先に終える。最初の画面の「二人の時間を区切る」で終えられる。")


class Playtest5Milestones(unittest.TestCase):
    def test_reached_milestones_are_hidden(self):
        p = Play(self, hour=19)
        self.assertEqual(p.s["relation"]["stage"], 3)
        p.page("talk")
        ids = {c["id"] for c in p.view()["choices"]}
        for n in (1, 2, 3):
            self.assertNotIn("begin.milestone_%d" % n, ids)
        self.assertIn("begin.milestone_4", ids)

    def test_early_milestone_reason(self):
        p = Play(self, hour=19, cheat=False)
        p.page("talk")
        option = p.option("begin.milestone_2")
        self.assertFalse(option["available"])
        self.assertEqual(p.view()["explanations"]["begin.milestone_2"], "先に前の節目を迎える。")


class LunchSoftlockE01D01(unittest.TestCase):
    def test_private_end_after_prepare_at_lunch(self):
        p = Play(self, hour=12, minute=5)
        p.choose("private.begin")
        p.page("appearance")
        for _ in range(6):
            option = next(c for c in p.view()["choices"] if c["id"].startswith("prepare.player.") and c["available"])
            p.choose(option["id"])
        p.page("main")
        self.assertTrue(p.option("private.end")["available"])
        result = p.choose("private.end")
        self.assertEqual(p.s["mode"], "normal")
        self.assertIn("work.block.afternoon", p.meanings(result))

    def test_intimacy_end_before_work_without_hold_back(self):
        p = Play(self, hour=12, minute=25)
        p.choose("private.begin")
        p.page("appearance")
        p.choose(next(c["id"] for c in p.view()["choices"] if c["id"].startswith("prepare.player.") and c["available"]))
        p.page("touch")
        p.choose("touch.h_kiss_deep")
        p.page("main")
        self.assertTrue(p.option("h.end")["available"])
        result = p.choose("h.end")
        self.assertIsNone(p.s["offer"])
        self.assertIsNone(p.s["intimacy"])
        self.assertIn("h.ended.unsatisfied", p.meanings(result))
        self.assertIn("work.block.afternoon", p.meanings(result))


class AuditLifeFixes(unittest.TestCase):
    def test_d05_prepare_sleeping_or_absent_maho_refused(self):
        p = Play(self, hour=19)
        p.page("appearance")
        option = p.option("prepare.maho.casual.down") or next(c for c in p.view()["choices"] if c["id"].startswith("prepare.maho."))
        self.assertFalse(option["available"])

    def test_f11_maho_stays_with_player_in_her_room(self):
        p = Play(self, hour=20)
        p.choose("private.begin")
        p.page("main")
        p.choose("private.end")
        # 真帆の部屋にいる形は誘いから。準備は内部：二人とも真帆の部屋に置く。
        p.e._state["actors"]["player"]["location"] = p.e._state["actors"]["maho"]["location"] = "maho_room"
        p.e._install_choices()
        p.choose("wait.30")
        self.assertEqual((p.s["actors"]["player"]["location"], p.s["actors"]["maho"]["location"]), ("maho_room", "maho_room"))

    def test_d08_affection_before_work_does_not_start_private(self):
        p = Play(self, hour=7, minute=50)
        p.choose("private.begin")
        p.choose("private.end")
        p.page("touch")
        if p.option("near") is not None:
            p.choose("near")
        p.choose("touch.hands")
        p.page("talk")
        self.assertTrue(p.option("touch.affection")["available"])
        p.choose("touch.affection")
        self.assertEqual(p.s["mode"], "normal")


class AuditIntimacyFixes(unittest.TestCase):
    def begin(self, p):
        p.choose("private.begin")
        p.page("touch")
        p.choose("touch.h_kiss_deep")

    def test_d06_after_hold_past_deadline_ends(self):
        p = Play(self, hour=21, minute=20, tier="familiar")
        self.begin(p)
        p.at(22, 5)
        p.e._state["intimacy"]["after"] = True
        p.e._state["intimacy"]["wrap_up"] = 0
        p.e._install_choices()
        result = p.h("h_after_hold")
        self.assertIsNone(p.s["intimacy"])
        self.assertIn("h.ended.deadline", p.meanings(result))

    def test_e03_deflect_reaching_deadline_emits_deadline(self):
        p = Play(self, hour=20, minute=50, tier="first")  # v8.2.30：初めての回は締め切りまで60分ないと始めない（21:20 → 20:50）
        self.begin(p)
        for key in ("h_pos_lying_face", "h_strip_lower", "h_shift_under"):
            p.h(key)
        p.at(21, 59)
        result = p.h("h_touch_direct")
        self.assertEqual(p.meanings(result)[-2:], ["h.deflect.hand", "h.deadline"])
        self.assertEqual(p.s["intimacy"]["wrap_up"], 1)

    def test_f02_no_check_after_deadline(self):
        p = Play(self, hour=21, minute=20, tier="few")
        self.begin(p)
        p.at(21, 59)
        p.h("h_kiss_deep")
        self.assertIsNotNone(p.s["intimacy"]["wrap_up"])
        p.page("h_words")
        option = p.option("touch.h_check")
        self.assertFalse(option["available"])
        self.assertTrue(p.option("touch.h_feel")["available"])

    def test_b003_withdraw_at_limit_calms_and_allows_reinsert(self):
        p = Play(self, hour=20, tier="familiar")
        self.begin(p)
        for key in ("h_strip_lower", "h_shift_under", "h_strip_self", "h_pos_player_above"):
            p.h(key)
        p.e._state["intimacy"]["maho"]["arousal"] = 60
        p.e._install_choices()
        p.h("h_insert")
        p.e._state["intimacy"]["player"]["arousal"] = 100
        p.e._install_choices()
        p.h("h_withdraw")
        self.assertEqual(p.s["intimacy"]["player"]["arousal"], 60)
        p.page("h_connect")
        self.assertTrue(p.option("touch.h_insert")["available"])

    def test_b002_insert_does_not_signal_wants_more(self):
        p = Play(self, hour=20, tier="familiar")
        self.begin(p)
        for key in ("h_strip_lower", "h_shift_under", "h_strip_self", "h_pos_player_above"):
            p.h(key)
        p.e._state["intimacy"]["maho"]["arousal"] = 85
        p.e._state["intimacy"]["maho"]["band"] = "high"
        p.e._install_choices()
        result = p.h("h_insert")
        self.assertNotIn("h.sign.wants_more", p.meanings(result))

    def test_f15_continuing_fast_after_climax_is_not_deflected(self):
        p = Play(self, hour=20, tier="familiar")
        self.begin(p)
        for key in ("h_strip_lower", "h_shift_under", "h_strip_self", "h_pos_player_above"):
            p.h(key)
        p.e._state["intimacy"]["maho"]["arousal"] = 85
        p.e._state["intimacy"]["maho"]["band"] = "high"
        p.e._install_choices()
        p.h("h_insert")
        p.h("h_move_fast")
        # 準備は内部：真帆が達した直後（高まり40）にする。
        p.e._state["intimacy"]["maho"].update(arousal=40, band="mid", climaxes=1, climax_source="inserted")
        p.e._state["intimacy"]["player"]["arousal"] = 20
        p.e._install_choices()
        result = p.h("h_move_fast")
        self.assertNotIn("h.deflect.fast", p.meanings(result))

    def test_f15_starting_fast_after_climax_uses_after_climax_text(self):
        p = Play(self, hour=20, tier="few")
        self.begin(p)
        for key in ("h_strip_lower", "h_shift_under", "h_strip_self", "h_pos_player_above"):
            p.h(key)
        p.e._state["intimacy"]["maho"]["arousal"] = 60
        p.e._install_choices()
        p.h("h_insert")
        p.e._state["intimacy"]["maho"].update(arousal=40, band="mid", climaxes=1, climax_source="inserted")
        p.e._install_choices()
        result = p.h("h_move_fast")
        block = next(b for b in result["blocks"] if b["meaning"] == "h.deflect.fast")
        self.assertTrue(block["variant"].startswith("o5.h.deflect.fast.few.after_climax."), block["variant"])

    def test_f05_kiss_ends_on_position_change(self):
        p = Play(self, hour=20, tier="few")
        self.begin(p)
        self.assertTrue(any(c["action_id"] == "h_kiss_deep" for c in p.s["contacts"]))
        p.h("h_pos_lying_face")
        self.assertFalse(any(c["action_id"] == "h_kiss_deep" for c in p.s["contacts"]))

    def test_e08_postures_reset_after_intimacy(self):
        p = Play(self, hour=20, tier="few")
        self.begin(p)
        p.h("h_pos_lying_face")
        p.page("main")
        p.choose("h.end")
        if p.s["offer"]:
            p.choose("offer.decline")
        self.assertEqual((p.s["actors"]["player"]["posture"], p.s["actors"]["maho"]["posture"]), ("seated", "seated"))


class AuditCheatFixes(unittest.TestCase):
    def test_tier_cheat_refused_before_lovers_and_marks_save(self):
        p = Play(self, cheat=False)
        with self.assertRaises(GameError):
            p.e.enable_test_cheat("intimacy_tier:familiar")
        p.e.enable_test_cheat("all")
        p.e.enable_test_cheat("intimacy_tier:familiar")
        self.assertTrue(p.e._payload()["test_cheats"]["contact_unlock"])

    def test_tier_cheat_refused_on_008_with_clear_message(self):
        p = Play(self, release="interaction_008", tier=None)
        with self.assertRaises(GameError) as caught:
            p.e.enable_test_cheat("intimacy_tier:few")
        self.assertIn("interaction_009", str(caught.exception))


class AuditInviteWindow(unittest.TestCase):
    def test_b007_invite_needs_travel_time(self):
        p = Play(self, hour=21, minute=26, tier="few")
        rules = p.e.pack.intimacy
        state = p.e._state
        state["desire"] = 100
        self.assertEqual(state["actors"]["player"]["location"], "living_room")
        self.assertFalse(rules.invite_ready(state, p.e.pack.progression, p.e.pack.life))
        p.at(21, 24)
        self.assertTrue(rules.invite_ready(p.e._state, p.e.pack.progression, p.e.pack.life))


class AuditTexts(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from nagishima.content import Pack
        cls.p9 = Pack(ROOT / "content/releases/interaction_009")

    def test_touch_direct_never_uses_vagina_slot(self):
        for text in self.p9.texts:
            if text["meaning"].startswith("h_touch_direct.") and not text["fallback"]:
                self.assertNotIn("{vagina}", text["body"], text["id"])

    def test_climax_together_does_not_repeat_player_finish(self):
        for text in self.p9.texts:
            if text["meaning"] == "h.climax.together" and not text["fallback"]:
                for phrase in ("こちらも果て", "こちらも同時に", "こちらも並んで"):
                    self.assertNotIn(phrase, text["body"], text["id"])

    def test_deflect_fast_grok_texts_only_before_climax(self):
        for text in self.p9.texts:
            if text["meaning"] == "h.deflect.fast" and not text["fallback"]:
                fields = {c["field"]: c for c in text["when"]["all"]}
                self.assertIn("intimacy.maho.climaxes", fields, text["id"])


if __name__ == "__main__":
    unittest.main()
