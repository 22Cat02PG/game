"""Compare Stage A autoplay observations against the untouched v7.1.2 tree."""
import argparse
import json
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]


def run(root, release, policy, seed):
    with tempfile.TemporaryDirectory(prefix="nagishima-compat-") as tmp:
        command = [sys.executable, "-m", "nagishima", policy, "--release", release,
                   "--seed", str(seed), "--max-turns", "250", "--no-autosave",
                   "--data-dir", str(Path(tmp) / "data"), "--log", str(Path(tmp) / "run.jsonl")]
        process = subprocess.run(command, cwd=root, capture_output=True, text=True, encoding="utf-8")
        lines = [json.loads(line) for line in process.stdout.splitlines()]
        assert lines and process.returncode == 0, (root, release, policy, seed, process.stderr, lines[-1:] if lines else [])
        return [normalize(line) for line in lines]


def normalize(value):
    if isinstance(value, dict):
        return {key: normalize(item) for key, item in value.items() if key not in {"log", "session"}}
    if isinstance(value, list): return [normalize(item) for item in value]
    return value


def first_difference(left, right, path="root"):
    if type(left) is not type(right): return path, left, right
    if isinstance(left, dict):
        for key in left.keys() | right.keys():
            if key not in left or key not in right: return path + "." + key, left.get(key), right.get(key)
            result = first_difference(left[key], right[key], path + "." + key)
            if result: return result
    elif isinstance(left, list):
        if len(left) != len(right): return path + ".length", len(left), len(right)
        for index, (a, b) in enumerate(zip(left, right)):
            result = first_difference(a, b, path + f"[{index}]")
            if result: return result
    elif left != right: return path, left, right
    return None


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    args = parser.parse_args()
    rows = []
    for release in ("interaction_003", "interaction_006", "interaction_007", "interaction_008"):
        for policy in ("--autoplay", "--autoplay-social", "--autoplay-presence"):
            for seed in (0, 42):
                old = run(args.base, release, policy, seed)
                new = run(ROOT, release, policy, seed)
                rows.append({"release": release, "policy": policy, "seed": seed,
                             "same": old == new, "old_count": len(old), "new_count": len(new)})
                if old != new: rows[-1]["first_difference"] = first_difference(old, new)
                print(rows[-1], flush=True)
    target = ROOT / "verification" / "stage_b_compat.json"
    target.write_text(json.dumps(rows, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return 0 if all(row["same"] for row in rows) else 1


if __name__ == "__main__":
    sys.exit(main())
