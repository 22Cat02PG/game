from pathlib import Path
import hashlib
import json
import math
import os
import re
import tempfile

from .errors import GameError, ensure

ID = re.compile(r"[a-z][a-z0-9_.-]{0,99}\Z")
MAX_SAVE_BYTES = 32 * 1024 * 1024


def clone_state(value):
    """Independent copy of an already validated, JSON-only runtime state."""
    return json.loads(json.dumps(value, ensure_ascii=False, separators=(",", ":"), allow_nan=False))


def identifier(value):
    ensure(type(value) is str and ID.fullmatch(value), "invalid_id", "登録IDの形式が違う。")
    return value


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def bytes_digest(value):
    return hashlib.sha256(value).hexdigest()


def decode(raw):
    def pairs(values):
        result = {}
        for key, value in values:
            ensure(key not in result, "duplicate_key", "JSONの項目が重複している。")
            result[key] = value
        return result

    def constant(value):
        raise GameError("invalid_number", "有限でない数値は使えない。")

    def finite_float(value):
        result = float(value)
        if not math.isfinite(result):
            raise GameError("invalid_number", "有限でない数値は使えない。")
        return result

    try:
        return json.loads(raw, object_pairs_hook=pairs, parse_constant=constant, parse_float=finite_float)
    except (UnicodeError, json.JSONDecodeError, RecursionError, ValueError) as error:
        if isinstance(error, GameError):
            raise
        raise GameError("invalid_json", "JSONを読めない。") from error


def read_json(path, limit=MAX_SAVE_BYTES):
    path = Path(path)
    ensure(path.stat().st_size <= limit, "file_size", "ファイルが上限を超えている。")
    return decode(path.read_bytes())


def exact(value, required, optional=()):
    ensure(type(value) is dict and set(required) <= value.keys() <= set(required) | set(optional), "invalid_fields", "不足または未登録の項目がある。")


def write_atomic(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
        if os.name == "posix":
            descriptor = os.open(path.parent, os.O_RDONLY)
            try:
                os.fsync(descriptor)
            finally:
                os.close(descriptor)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def write_json(path, value):
    write_atomic(path, json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False).encode("utf-8") + b"\n")
