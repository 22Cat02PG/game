"""Stage B authored grok texts in 009 (B-50/B-51 of each imported wave)."""
import json
import subprocess
import sys
import unittest
from pathlib import Path

from nagishima.content import Pack
from tools.build_intimacy_release import b2_conditions, text_fix_conditions

ROOT = Path(__file__).resolve().parents[1]
COMPLETE_WAVES = (1, 2, 3)  # 取り込みが完了した陣


class StageBTexts(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.pack = Pack(ROOT / "content/releases/interaction_009")
        cls.jobs = {}
        for wave in (1, 2, 3):
            for job in json.loads((ROOT / f"authoring/b_jobs/grok_wave_{wave}.json").read_text(encoding="utf-8")):
                cls.jobs[job["id"]] = job
        cls.rows = json.loads((ROOT / "tools/stage_b/b_texts.json").read_text(encoding="utf-8"))
        # v8.0.5：生成が grok の本文の when に足す条件（opus_texts_009.json の when_patches）
        cls.patches = {}
        for patch in json.loads((ROOT / "tools/stage_b/opus_texts_009.json").read_text(encoding="utf-8"))["when_patches"]:
            cls.patches.setdefault(patch["meaning"], []).extend(patch["add"])

    def test_every_adopted_text_is_in_009_with_job_conditions(self):
        by_id = {t["id"]: t for t in self.pack.texts}
        for row in self.rows:
            job = self.jobs[row["job_id"]]
            text = by_id[row["id"]]
            when = {"all": job["when"]["all"] + self.patches[job["_meaning"]]} if job["_meaning"] in self.patches else job["when"]
            extra = b2_conditions({"meaning": job["_meaning"], "when": when, "body": row["body"]})  # B2：本文の語から足す条件
            if extra:
                when = {"all": when["all"] + extra}
            fix_when, fix_body, _ = text_fix_conditions()  # v8.2.25：精査の直し（条件の足しと本文の直し）
            fixed = [c for c in fix_when.get(row["id"], []) if c not in when["all"]]
            if fixed:
                when = {"all": when["all"] + fixed}
            self.assertEqual((text["meaning"], text["when"], text["group"], text["body"], text["fallback"]),
                             (job["_meaning"], when, job["group"], fix_body.get(row["id"], row["body"]), False), row["id"])

    def test_fallback_remains_one_per_meaning(self):
        for meaning in self.pack.meanings:
            self.assertEqual(sum(t["fallback"] for t in self.pack.by_meaning[meaning]), 1, meaning)

    def test_machine_checks_and_complete_waves(self):
        waves = ",".join(str(w) for w in COMPLETE_WAVES)
        result = subprocess.run([sys.executable, str(ROOT / "tools/check_stage_b_texts.py"), "--complete-waves", waves],
                                cwd=ROOT, capture_output=True, text=True, encoding="utf-8")
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)


if __name__ == "__main__":
    unittest.main()
