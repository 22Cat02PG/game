"""Test cheats stay opt-in and make their state replayable."""
from tempfile import TemporaryDirectory
import unittest

from nagishima.engine import Engine
from nagishima.session import Session
from tests.support import activity, do, press, stage_one


class TestCheat(unittest.TestCase):
    def test_normal_runs_reject_the_cheat(self):
        with TemporaryDirectory() as directory:
            engine = Engine(directory, seed=9, autosave=False)
            session = Session(engine)
            before = engine.snapshot()
            response = session.execute({"command": "cheat", "action": "contact_unlock"})
            self.assertFalse(response["ok"])
            self.assertEqual(response["error"]["code"], "cheat_disabled")
            self.assertEqual(engine.snapshot(), before)

    def test_intimacy_cheat_unlocks_action_without_promoting_relation(self):
        with TemporaryDirectory() as directory:
            engine = Engine(directory, seed=9, autosave=False, test_cheats=True)
            session = Session(engine)
            enabled = session.execute({"command": "cheat", "action": "contact_unlock"})
            self.assertTrue(enabled["ok"])
            self.assertEqual(enabled["result"]["relation_stage"], 0)
            self.assertTrue(session.execute({"command": "choose", "id": "menu.touch"})["ok"])
            self.assertTrue(session.execute({"command": "choose", "id": "near"})["ok"])
            view = session.execute({"command": "actions"})
            kiss = next(choice for choice in view["result"] if choice["id"] == "touch.kiss")
            self.assertTrue(kiss["available"])
            result = session.execute({"command": "choose", "id": "touch.kiss"})
            self.assertTrue(result["ok"])
            self.assertEqual(result["state"]["relation"]["stage"], 0)
            self.assertEqual(result["state"]["experience"]["kiss"]["count"], 1)
            self.assertTrue(session.execute({"command": "save", "slot": "slot01"})["ok"])
            resumed = Session(Engine(directory, seed=9, autosave=False, test_cheats=True))
            loaded = resumed.execute({"command": "load", "slot": "slot01"})
            self.assertTrue(loaded["ok"])
            self.assertTrue(resumed.engine.get_diagnostics()["test_cheats"]["contact_unlock_active"])
            blocked = Session(Engine(directory, seed=9, autosave=False))
            rejected = blocked.execute({"command": "load", "slot": "slot01"})
            self.assertFalse(rejected["ok"])
            self.assertEqual(rejected["error"]["code"], "cheat_disabled")

    def test_invalid_cheat_name_does_not_activate_override(self):
        with TemporaryDirectory() as directory:
            engine = Engine(directory, seed=9, autosave=False, test_cheats=True)
            session = Session(engine)
            response = session.execute({"command": "cheat", "action": "unknown"})
            self.assertFalse(response["ok"])
            self.assertEqual(response["error"]["code"], "cheat_action")
            self.assertFalse(engine.get_diagnostics()["test_cheats"]["contact_unlock_active"])

    def test_full_cheat_opens_private_room_and_survives_save_load(self):
        with TemporaryDirectory() as directory:
            engine = Engine(directory, seed=9, autosave=False, test_cheats=True)
            session = Session(engine)
            enabled = session.execute({"command": "cheat", "action": "all"})
            self.assertTrue(enabled["ok"], enabled.get("error"))
            self.assertEqual(enabled["state"]["relation"]["stage"], 3)
            self.assertEqual(enabled["state"]["mood"], {"joy": 2, "shy": 2, "ease": 2, "interest": 2})
            self.assertEqual([m["stage"] for m in enabled["state"]["relation"]["milestones"]], [1, 2, 3])
            self.assertFalse(enabled["run"]["ended"])
            private = next(c for c in enabled["available_actions"] if c["id"] == "private.begin")
            self.assertTrue(private["available"])
            self.assertTrue(session.execute({"command": "save", "slot": "slot01"})["ok"])
            resumed = Session(Engine(directory, seed=9, autosave=False, test_cheats=True))
            loaded = resumed.execute({"command": "load", "slot": "slot01"})
            self.assertTrue(loaded["ok"], loaded.get("error"))
            self.assertTrue(resumed.engine.get_diagnostics()["test_cheats"]["all_active"])
            room = resumed.execute({"command": "choose", "id": "private.begin"})
            self.assertTrue(room["ok"], room.get("error"))
            self.assertEqual(room["state"]["mode"], "private")
            self.assertEqual(room["state"]["actors"]["player"]["location"], "player_room")
            self.assertFalse(room["run"]["ended"])
            blocked = Session(Engine(directory, seed=9, autosave=False))
            rejected = blocked.execute({"command": "load", "slot": "slot01"})
            self.assertFalse(rejected["ok"])
            self.assertEqual(rejected["error"]["code"], "cheat_disabled")

    def test_full_cheat_is_repeatable_from_seed_and_commands(self):
        results = []
        for _ in range(2):
            with TemporaryDirectory() as directory:
                session = Session(Engine(directory, seed=42, release="interaction_005", autosave=False, test_cheats=True))
                for command in ({"command": "cheat", "action": "all"},
                                {"command": "choose", "id": "private.begin"},
                                {"command": "choose", "id": "private.end"}):
                    response = session.execute(command)
                    self.assertTrue(response["ok"], response.get("error"))
                results.append((response["state"], response["view"]["blocks"], response["available_actions"]))
        self.assertEqual(results[0], results[1])

    def test_full_cheat_requires_maho_present_and_normal_mode(self):
        with TemporaryDirectory() as directory:
            engine = Engine(directory, seed=42, release="interaction_006", autosave=False, test_cheats=True)
            session = Session(engine)
            for _ in range(3):
                self.assertTrue(session.execute({"command": "choose", "id": "wait.30"})["ok"])
            self.assertNotEqual(engine.snapshot()["actors"]["player"]["location"], engine.snapshot()["actors"]["maho"]["location"])
            before, revision = engine.snapshot(), engine.get_view()["revision"]
            rejected = session.execute({"command": "cheat", "action": "all"})
            self.assertEqual(rejected["error"]["code"], "location")
            self.assertEqual(engine.snapshot(), before)
            self.assertEqual(engine.get_view()["revision"], revision)

            other = Session(Engine(directory, seed=42, release="interaction_006", autosave=False, test_cheats=True))
            self.assertTrue(other.execute({"command": "cheat", "action": "all"})["ok"])
            self.assertTrue(other.execute({"command": "choose", "id": "private.begin"})["ok"])
            before, revision = other.engine.snapshot(), other.engine.get_view()["revision"]
            rejected = other.execute({"command": "cheat", "action": "all"})
            self.assertEqual(rejected["error"]["code"], "private")
            self.assertEqual(other.engine.snapshot(), before)
            self.assertEqual(other.engine.get_view()["revision"], revision)

    def test_full_cheat_rejects_suspended_milestone(self):
        with TemporaryDirectory() as directory:
            engine = Engine(directory, seed=42, release="interaction_006", autosave=False, test_cheats=True)
            session = Session(engine)
            do(engine, "talk", "begin.two_cups")
            press(engine, "scene.tea")
            press(engine, "scene.remember")
            activity(engine, "tea")
            do(engine, "talk", "begin.milestone_1")
            press(engine, "scene.pause")
            self.assertEqual(engine.snapshot()["suspended"][0]["scene_id"], "milestone_1")
            before, revision = engine.snapshot(), engine.get_view()["revision"]
            rejected = session.execute({"command": "cheat", "action": "all"})
            self.assertEqual(rejected["error"]["code"], "answer_first")
            self.assertEqual(engine.snapshot(), before)
            self.assertEqual(engine.get_view()["revision"], revision)

    def test_full_cheat_allows_other_suspended_scene(self):
        with TemporaryDirectory() as directory:
            engine = Engine(directory, seed=42, release="interaction_006", autosave=False, test_cheats=True)
            session = Session(engine)
            do(engine, "talk", "begin.two_cups")
            press(engine, "scene.pause")
            self.assertEqual(engine.snapshot()["suspended"][0]["scene_id"], "two_cups")
            response = session.execute({"command": "cheat", "action": "all"})
            self.assertTrue(response["ok"], response.get("error"))
            self.assertEqual(response["state"]["relation"]["stage"], 3)

    def test_intimacy_cheat_exposes_compliment_at_stage_zero(self):
        with TemporaryDirectory() as directory:
            engine = Engine(directory, seed=42, release="interaction_006", autosave=False, test_cheats=True)
            session = Session(engine)
            self.assertTrue(session.execute({"command": "cheat", "action": "contact_unlock"})["ok"])
            self.assertTrue(session.execute({"command": "choose", "id": "menu.talk"})["ok"])
            choices = session.execute({"command": "actions"})["result"]
            compliment = next(choice for choice in choices if choice["id"] == "touch.compliment")
            self.assertTrue(compliment["available"])
            self.assertEqual(engine.snapshot()["relation"]["stage"], 0)

    def test_full_cheat_breaks_streak_but_intimacy_cheat_does_not(self):
        with TemporaryDirectory() as directory:
            engine = Engine(directory, seed=42, release="interaction_006", autosave=False, test_cheats=True)
            session = Session(engine)
            stage_one(engine)
            self.assertTrue(session.execute({"command": "cheat", "action": "contact_unlock"})["ok"])
            self.assertTrue(session.execute({"command": "choose", "id": "menu.talk"})["ok"])
            for _ in range(2):
                self.assertTrue(session.execute({"command": "choose", "id": "touch.compliment"})["ok"])
            self.assertEqual(engine.snapshot()["interaction_streak"]["count"], 2)
            self.assertTrue(session.execute({"command": "cheat", "action": "contact_unlock"})["ok"])
            self.assertEqual(engine.snapshot()["interaction_streak"]["count"], 2)
            self.assertTrue(session.execute({"command": "choose", "id": "menu.main"})["ok"])
            self.assertTrue(session.execute({"command": "cheat", "action": "all"})["ok"])
            self.assertIsNone(engine.snapshot()["interaction_streak"])
            self.assertTrue(session.execute({"command": "choose", "id": "menu.talk"})["ok"])
            response = session.execute({"command": "choose", "id": "touch.compliment"})
            self.assertTrue(response["ok"], response.get("error"))
            self.assertEqual(engine.snapshot()["interaction_streak"]["count"], 1)
            self.assertIn("compliment.start", [block["meaning"] for block in response["view"]["blocks"]])

    def test_repeated_full_cheat_records_mood_only_result(self):
        with TemporaryDirectory() as directory:
            engine = Engine(directory, seed=42, release="interaction_006", autosave=False, test_cheats=True)
            session = Session(engine)
            for _ in range(2):
                response = session.execute({"command": "cheat", "action": "all"})
                self.assertTrue(response["ok"], response.get("error"))
            history = [entry for entry in engine.snapshot()["history"] if entry["choice"] == "cheat.all"]
            self.assertEqual([entry["outcome"] for entry in history], ["relation.3", "mood.max"])


if __name__ == "__main__":
    unittest.main()
