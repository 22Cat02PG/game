"""第14陣（p14、深い口づけを続けたままの本文）の返事を読む。raw_14/*.txt（新規 テキスト ドキュメント (142)〜(144).txt）→ pool_14.json。"""
import collections, glob, json, os, re
base = '/home/claude/work/b2'
jobs = {}
for path in sorted(glob.glob(f'{base}/grok_b2_wave_*.json')):
    for j in json.load(open(path, encoding='utf-8')):
        jobs[j['id']] = j
used = collections.defaultdict(int)
for e in json.load(open('b2_判定.json', encoding='utf-8')):
    used[e['job_id']] = max(used[e['job_id']], int(e['id'].rsplit('.v', 1)[1]))
pool = collections.defaultdict(list); problems = []; seen_ids = collections.Counter()
for f in sorted(glob.glob('raw_14/*.txt'), key=lambda p: int(os.path.basename(p)[:-4])):
    t = open(f, encoding='utf-8').read()
    rows = [(m.group(1), m.group(2), json.loads('"' + m.group(3) + '"')) for m in re.finditer(
        r'\{\s*"id"\s*:\s*"((?:p14)\.[^"]+)"\s*,\s*"job_id"\s*:\s*"((?:p14)\.[^"]+)"\s*,\s*"body"\s*:\s*"((?:[^"\\]|\\.)*)"\s*\}', t, re.S)]
    if len(re.findall(r'"job_id"', t)) != len(rows):
        problems.append((f, 'parse', len(re.findall(r'"job_id"', t)), len(rows)))
    for tid, jid, body in rows:
        if jid not in jobs:
            problems.append((f, 'unknown job', jid)); continue
        seen_ids[tid] += 1
        used[jid] += 1
        pool[jid].append({"id": f"{jid}.v{used[jid]}", "job_id": jid, "body": body, "file": os.path.basename(f), "grok_id": tid})
sup = {}
want = {j for j in jobs if j.startswith(("p14.",))}
missing = sorted(want - set(pool))
dup = {k: v for k, v in seen_ids.items() if v > 1}
expect = {j: (sup[j]['本数'] if j in sup else jobs[j]['candidates']) for j in want}
short = {j: len(v) for j, v in pool.items() if len(v) < expect.get(j, 5)}
over = {j: len(v) for j, v in pool.items() if len(v) > expect.get(j, 5)}
extra = sorted(set(pool) - want)
print('texts', sum(len(v) for v in pool.values()), 'jobs', len(pool), 'of', len(want), 'missing', len(missing), 'dup grok ids', len(dup), 'short', len(short), 'over', len(over), 'problems', problems[:10])
print('extra (not requested)', extra[:10]); print('missing sample', missing[:10]); print('over sample', list(over.items())[:5]); print('short sample', list(short.items())[:5])
json.dump(pool, open('pool_14.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
json.dump({"missing": missing, "dup": dup, "short": short, "over": over}, open('pool_14_report.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
