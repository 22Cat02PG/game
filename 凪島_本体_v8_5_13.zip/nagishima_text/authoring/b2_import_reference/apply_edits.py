"""Opus の直しを b2_判定.json に重ね、b2_texts.json と本体の tools/stage_b・authoring/b2_results を書き直す。

使い方：python3 apply_edits.py edits.json   （edits.json は {id: {"body": ..., "reason": ...}}。body が null なら不採用にする）
"""
import collections
import json
import os
import sys

HERE = "/home/claude/work/b2import"
OUT = os.environ.get("NAGISHIMA_OUT", "/home/claude/work/v810/nagishima_text")  # v8.2.24：書き出す本体を環境変数で選べるように
rec = json.load(open(f"{HERE}/b2_判定.json", encoding="utf-8"))
index = {e["id"]: e for e in rec}
for path in sys.argv[1:]:
    edits = json.load(open(path, encoding="utf-8"))
    for tid, edit in edits.items():
        e = index[tid]
        assert e["verdict"] != "reject", tid
        note = "Opus：" + edit["reason"]
        e["reason"] = (e["reason"] + "；" if e["reason"] else "") + note
        if edit["body"] is None:
            e["verdict"] = "reject"
            e.pop("body", None)
        else:
            e["verdict"] = "fix"
            e["body"] = edit["body"]
json.dump(rec, open(f"{HERE}/b2_判定.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
adopted = [{"id": e["id"], "job_id": e["job_id"], "body": e.get("body", e["orig"])} for e in rec if e["verdict"] != "reject"]
json.dump(adopted, open(f"{HERE}/b2_texts.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
json.dump(adopted, open(f"{OUT}/tools/stage_b/b2_texts.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
os.makedirs(f"{OUT}/authoring/b2_results", exist_ok=True)
fixes = {e["id"]: {"orig": e["orig"], "body": e["body"], "reason": e["reason"]} for e in rec if e["verdict"] == "fix"}
json.dump(fixes, open(f"{OUT}/authoring/b2_results/本文の直し.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
by_job = collections.defaultdict(lambda: {"adopt": [], "rejected": []})
for e in rec:
    if e["verdict"] == "reject":
        by_job[e["job_id"]]["rejected"].append({"id": e["id"], "file": e["file"], "reason": e["reason"]})
    else:
        by_job[e["job_id"]]["adopt"].append(e["id"])
json.dump([{"job_id": j, **v} for j, v in by_job.items()], open(f"{OUT}/authoring/b2_results/判定.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("adopted", len(adopted), "fixes", len(fixes), collections.Counter(e["verdict"] for e in rec))
