"""4回目の試運転の指摘（2026-09-27）に合わせた grok への依頼（Opus）。

- 第5陣（p5.）：「向かい合って横になる」でつながる（入れる・動く3つの速さ・中で出す・外で出す・こらえきれずに出る・抜く）。指摘6。
- 第6陣（p6.）：いつもの時間に、服の中に入れた手で胸に直接触れる（chest_under）。指摘1。
- 濃い版の試し（x1.）：出番の多い場面の「描写の濃さ：濃い」用の本文（style＝explicit）。指摘3。

出力：grok_b2_wave_5.json・grok_b2_wave_6.json・grok_b2_wave_x1.json、grok依頼_B2_第5陣/・第6陣/・濃い版_試し/、第5陣以降_一覧.json
"""
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path("/home/claude/work/v810/nagishima_text")
PROMPT = (OUT / "grokプロンプト_v3_0.txt").read_text(encoding="utf-8")
BED = "二人の個室のどちらかのベッド（どちらの部屋かは書かない）"
HOME = "二人の家の中（居間・台所・どちらかの個室のどれか。場所の名前は書かない）"
TIER = {"first": "初回（1回目のエッチ）", "few": "数回（2〜5回目）", "familiar": "慣れ（6回目以降）", "few_familiar": "数回か慣れ（2回目以降）"}
TIER_WHEN = {"first": ("eq", "first"), "few": ("eq", "few"), "familiar": ("eq", "familiar"), "few_familiar": ("in", ["few", "familiar"])}
FIRST_TIME = "この行為は今回が最初（この事実を地の文で言葉にしない。戸惑いは動作で表す）"
LOWER_OPEN = "真帆の下は、下着をずらしてあるか脱いでいる（下着について書かない）。こちらは下を脱いでいる"
LYING_FACE = "二人とも横向きに寝て、向かい合っている（真帆の脚がこちらの腰に絡んでいる。抱き合える近さ）"
MOVE = {
    "h_move_slow": ("こちらがゆっくり動く", "こちらがゆっくりした動きを続ける", "こちらがゆっくりした動きをさらに続ける"),
    "h_move_normal": ("こちらが少し速く動く", "こちらが少し速い動きを続ける", "こちらが少し速い動きをさらに続ける"),
    "h_move_fast": ("こちらが激しく動く", "こちらが激しい動きを続ける", "こちらが激しい動きをさらに続ける"),
}
MOVE_MUST = "速さを変える。体位を変える。達する"
FINISH_MUST = "妊娠・避妊に触れる。真帆が止める。台詞で「待って」「止まって」と言う（止める意味に読める）。中・外に触れる台詞。「入った」「出てる」のような実況の台詞"
OVERFLOW_MUST = FINISH_MUST + "。出すと自分で決めたように書く"
waves = {"5": [], "6": [], "x1": []}


def job(wave, meaning, tier, s, meaning_text, state, *, pos=None, origin="主人公", must_not=None, when=None, split_other=None, cands=5):
    parts = [f"p{wave}", meaning] + ([tier] if tier else []) + ([pos] if pos else []) + ([split_other] if split_other else []) + [s]
    identity = ".".join(parts)
    conditions = list(when or [])
    if tier:
        op, value = TIER_WHEN[tier]
        conditions.insert(0, {"field": "intimacy.tier", "op": op, "value": value})
    if pos:
        conditions.append({"field": "intimacy.position", "op": "eq", "value": pos})
    row = {"id": identity, "meaning": meaning_text, "speech": s == "s", "length": "100〜160字", "origin": origin, "candidates": cands,
           "state": state, "_wave": f"B2-{wave}", "_meaning": meaning, "_split": {"tier": tier, "position": pos, "other": split_other},
           "when": {"all": conditions}, "group": "b." + meaning}
    if must_not:
        row["must_not"] = must_not
    assert not any(j["id"] == identity for w in waves.values() for j in w), identity
    waves[wave].append(row)


# ---- 第5陣：向かい合って横になる（lying_face）でつながる ----
pos = "lying_face"
for tier in ("first", "few", "familiar"):
    common = {"場所": BED, "慣れ": TIER[tier], "体位": LYING_FACE, "服": LOWER_OPEN}
    for s in ("s", "n"):
        job("5", "h_insert.start", tier, s, "向かい合って横になったまま、こちらがゆっくりと真帆の中に入る", {**common, "挿入": "この本文で入る"}, pos=pos, must_not="動き始める。痛みを大げさにする。体位を変える（仰向けにする、上に重なる）")
    for speed, (m_start, m_cont, m_settled) in MOVE.items():
        for s in ("s", "n"):
            job("5", speed + ".start", tier, s, m_start, {**common, "挿入": "している"}, pos=pos, must_not=MOVE_MUST)
            job("5", speed + ".continue", tier, s, m_cont, {**common, "続いている動作": "前の本文から続いている（" + m_cont + "）", "挿入": "している"}, pos=pos, must_not=MOVE_MUST)
        job("5", speed + ".settled", tier, "n", m_settled, {**common, "続いている動作": "前の本文から続いている（" + m_cont + "）", "挿入": "している"}, pos=pos, must_not=MOVE_MUST)
    for s in ("s", "n"):
        job("5", "h_finish_inside.start", tier, s, "こちらが真帆の中で達する", {**common, "挿入": "している"}, pos=pos, must_not=FINISH_MUST)
        job("5", "h_finish_outside.start", tier, s, "こちらが抜いて、真帆の外で達する", {**common, "挿入": "している（この本文で抜く）"}, pos=pos, must_not=FINISH_MUST)
        job("5", "h_overflow.inside", tier, s, "限界まで高まったまま動き続けたこちらが、こらえきれずに真帆の中で果てる",
            {**common, "挿入": "している", "主人公": "もう限界だったのに、そのまま動き続けた（出すと決めてはいない）"}, pos=pos, must_not=OVERFLOW_MUST)
for tier in ("first", "few_familiar"):
    for s in ("s", "n"):
        job("5", "h_withdraw.start", tier, s, "こちらが真帆の中から抜く", {"場所": BED, "慣れ": TIER[tier], "体位": LYING_FACE, "服": LOWER_OPEN, "挿入": "している（この本文で抜く）"},
            pos=pos, must_not="達する。服を着る")

# ---- 第6陣：服の中で胸に触れる（いつもの時間） ----
TEXTS = ("こちらが服の中に入れた手で、真帆の胸に直接触れる", "こちらが服の中で、真帆の胸に触れ続ける", "こちらが服の中で、真帆の胸にさらに触れ続ける")
MUST6 = "服をめくる・脱がせる。秘所や下に触れる。部屋へ移る。胸の先を口に含む"
for other, relation, cond in (("before_h", "恋人（まだエッチはしていない）", {"field": "intimacy.history_count", "op": "eq", "value": 0}),
                              ("after_h", "恋人（エッチをしたことがある）", {"field": "intimacy.history_count", "op": "ge", "value": 1})):
    base = {"場所": HOME, "関係": relation, "服": "普段着（服の種類は書かない）。こちらの手は裾から服の中に入っている（服はめくれていない）", "姿勢": "書かない（立っているか座っているかは書かない）"}
    job("6", "chest_under.first", None, "s", TEXTS[0], {**base, "経験": FIRST_TIME}, must_not=MUST6, when=[cond], split_other=other)
    for s in ("s", "n"):
        job("6", "chest_under.start", None, s, TEXTS[0], base, must_not=MUST6, when=[cond], split_other=other)
        job("6", "chest_under.continue", None, s, TEXTS[1], {**base, "続いている動作": "前の本文から続いている（" + TEXTS[1] + "）"}, must_not=MUST6, when=[cond], split_other=other)
    job("6", "chest_under.settled", None, "n", TEXTS[2], {**base, "続いている動作": "前の本文から続いている（" + TEXTS[1] + "）"}, must_not=MUST6, when=[cond], split_other=other)

# ---- 濃い版の試し（x1.）：出番の多い場面の複製（style＝explicit） ----
DENSE = "濃い：性器・体液・結合部の音と感触・体の反応を具体的に、露骨に書く（記号 {penis} {vagina} {semen} {love_juice} {clitoris} {nipple} {breasts} を積極的に使う。擬音も使ってよい）"
source = {}
for w in (1, 2, 3):
    for j in json.loads((ROOT / f"authoring/b_jobs/grok_wave_{w}.json").read_text(encoding="utf-8")):
        source[j["id"]] = j
PILOT = ["b3.h_insert.start.familiar.player_above.s", "b3.h_move_slow.start.familiar.player_above.n", "b3.h_move_normal.start.familiar.player_above.s",
         "b3.h_move_normal.continue.familiar.player_above.n", "b3.h_move_fast.start.familiar.player_above.s", "b3.h_move_fast.continue.familiar.player_above.n",
         "b3.h_move_fast.settled.familiar.player_above.n", "b3.h_finish_inside.start.familiar.player_above.s", "b3.h.climax.together.familiar.s",
         "b3.h.climax.maho.familiar.inserted.n", "b3.h_move_normal.start.familiar.maho_above.s", "b3.h_move_fast.start.familiar.maho_above.n"]
for key in PILOT:
    src = source[key]
    state = dict(src["state"])
    if "下着がずらされている" in state.get("服", ""):
        state["服"] = LOWER_OPEN
    state["描写"] = DENSE
    row = {"id": "x1." + key.split(".", 1)[1], "meaning": src["meaning"], "speech": src["speech"], "length": "120〜200字", "origin": src["origin"], "candidates": 5,
           "state": state, "_wave": "B2-x1", "_meaning": src["_meaning"], "_split": src["_split"], "when": src["when"], "group": src["group"], "style": "explicit"}
    if src.get("must_not"):
        row["must_not"] = src["must_not"]
    waves["x1"].append(row)

# ---- 出力 ----
LABEL = {"5": ("第5陣", "向かい合って横になってつながる"), "6": ("第6陣", "服の中で胸に触れる（いつもの時間）"), "x1": ("濃い版_試し", "描写の濃さ：濃い の試し")}
DENSE_NOTE = ("\n\nこの依頼は、ゲームの設定「描写の濃さ：濃い」を選んだ人向けの本文です。同じ場面の標準の本文はすでにあります。"
              "標準より露骨に、性器・体液・結合部の音と感触・体の反応を具体的に書いてください（state の「描写」のとおり）。"
              "この依頼に限り、プロンプトの「部位の語と記号は地の文で1本に2つまで」は「4つまで（同じ語・記号は2回まで）」に読み替えてください。擬音（湿った音・肌がぶつかる音）も使ってよいです。"
              "それ以外の規則（台詞の数、慣れの段階の語、地の文で器官を名前で呼ばず記号を使う、記号を台詞に書かない、妊娠・避妊に触れない、must_not）は同じです。")
listing = {}
for wave, rows in waves.items():
    (OUT / f"grok_b2_wave_{wave}.json").write_text(json.dumps(rows, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
    name, label = LABEL[wave]
    folder = OUT / f"grok依頼_B2_{name}"
    folder.mkdir(exist_ok=True)
    for old in folder.glob("*.txt"):
        old.unlink()
    number = 0
    for speech, kind in ((True, "台詞あり"), (False, "台詞なし")):
        part = [r for r in rows if r["speech"] == speech]
        if not part:
            continue
        count = -(-len(part) // 13)
        size = -(-len(part) // count)
        for index in range(0, len(part), size):
            chunk = part[index:index + size]
            number += 1
            lines = [json.dumps({"id": r["id"], "meaning": r["meaning"], "speech": r["speech"], "length": r["length"], "origin": r["origin"], "本数": r["candidates"],
                                 **({"must_not": r["must_not"]} if r.get("must_not") else {}), "state": r["state"]}, ensure_ascii=False) for r in chunk]
            body = ("指示\n"
                    f"次の{len(chunk)}件の job を書いてください（段階Bの2版目・{label}・{kind}）。本数は各 job の「本数」のとおりです（合わせて{sum(r['candidates'] for r in chunk)}本）。"
                    "途中で切れそうなら、job の区切りで止めてください。「続けて」と言われたら、止めた job の次から出してください。"
                    + (DENSE_NOTE if wave == "x1" else "") + "\n\n[\n  " + ",\n  ".join(lines) + "\n]\n\n"
                    "プロンプト\n" + PROMPT)
            (folder / f"B2_{name}_{number:02d}.txt").write_text(body, encoding="utf-8")
    listing[name] = {"jobs": len(rows), "texts": sum(r["candidates"] for r in rows), "files": sorted(p.name for p in folder.glob("*.txt"))}
(OUT / "第5陣以降_一覧.json").write_text(json.dumps(listing, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
print(json.dumps(listing, ensure_ascii=False))
