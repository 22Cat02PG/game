"""濃い版・前戯（x5.）：つながる前の行為の「描写の濃さ：濃い」用の本文（Opus、2026-09-27 15:47 ユーザー了承）。

範囲：初回・数回・慣れ × 胸に直接触れる・胸に口づける・下着の上から触れる・秘所に指で触れる・指を中に入れる・口で愛撫する・
      手でしてもらう・口でしてもらう・手の中で出す・口の中で出す・こらえきれずに手／口の中で出す、と、指や口で真帆が達する。
元の job（段階B 第1〜3陣 b1〜b3.、段階B2 第1・2・4陣 p1.・p2.・p4.）の meaning・state・when・must_not を引き継ぎ、「描写」を足す。
いつもの暮らしの触れ合い（居間など）は対象外。
出力：grok_b2_wave_x5.json、grok依頼_B2_濃い版/B2_濃い版_44〜.txt（01〜43 は消さない）
"""
import glob
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path("/home/claude/work/v810/nagishima_text")
PROMPT = (OUT / "grokプロンプト_v3_0.txt").read_text(encoding="utf-8")
DENSE = "濃い：性器・体液・体の反応と、触れる音・感触を具体的に、露骨に書く（記号 {penis} {vagina} {semen} {love_juice} {clitoris} {nipple} {breasts} を積極的に使う。擬音も使ってよい）"
ACTIONS = [("h_chest_skin", "胸に直接触れる"), ("h_chest_mouth", "胸に口づける"), ("h_touch_under", "下着の上から触れる"), ("h_touch_direct", "秘所に指で触れる"),
           ("h_finger_in", "指を中に入れる"), ("h_player_mouth", "口で愛撫する"), ("h_maho_hand", "手でしてもらう"), ("h_maho_mouth", "口でしてもらう"),
           ("h_finish_hand", "手の中で出す"), ("h_finish_mouth", "口の中で出す"), ("h_overflow", "こらえきれずに出す"), ("h.climax.maho", "指や口で真帆が達する")]
CHEST = {"h_chest_skin", "h_chest_mouth"}
BACK_FACE = "真帆の顔は正面からは見えない（横顔・振り返り・肩越しなら書いてよい）"
PHASE = {"first": 0, "start": 1, "continue": 2, "settled": 3}
TIER = {"first": 0, "few": 1, "familiar": 2, "few_familiar": 1}

paths = sorted(glob.glob(str(ROOT / "authoring/b_jobs/grok_wave_[123].json"))) + sorted(glob.glob(str(ROOT / "authoring/b2_jobs/grok_b2_wave_[1-6].json")))
source = {}
for path in paths:
    for j in json.loads(Path(path).read_text(encoding="utf-8")):
        source[j["id"]] = j


def action_of(job):
    m = job["_meaning"]
    if m == "h.climax.maho":
        return m if job["_split"].get("other") in ("not_inserted", "mouth") else None
    if m == "h_overflow.inside":
        return None
    head = m.split(".")[0]
    return head if head in dict(ACTIONS) else None


def tier_of(job):
    tier = job["_split"]["tier"]
    return tier[0] if isinstance(tier, list) and len(tier) == 1 else tier


def dense_row(src):
    state = dict(src["state"])
    if src["_split"].get("other") == "back" and "こちらからは見えない" not in state.get("体位", ""):
        state.setdefault("顔", BACK_FACE)  # 背を向けた場面で、体位の欄に顔のことが書いていないときだけ
    state["描写"] = DENSE
    row = {"id": "x5." + src["id"].split(".", 1)[1], "meaning": src["meaning"], "speech": src["speech"], "length": "120〜200字", "origin": src["origin"], "candidates": 5,
           "state": state, "_wave": "B2-x5", "_meaning": src["_meaning"], "_split": src["_split"], "when": src["when"], "group": src["group"], "style": "explicit"}
    if src.get("must_not"):
        row["must_not"] = src["must_not"]
    return row


groups = []
for action, label in ACTIONS:
    rows = [dense_row(s) for s in source.values() if action_of(s) == action]
    rows.sort(key=lambda r: (TIER.get(tier_of(r), 3), PHASE.get(r["_meaning"].split(".")[1], 9) if r["_meaning"].count(".") else 0, r["id"]))
    groups.append((action, label, rows))
# 手の中・口の中で出すは小さいので1ファイルに
hand = next(g for g in groups if g[0] == "h_finish_hand")
mouth = next(g for g in groups if g[0] == "h_finish_mouth")
groups = [g for g in groups if g[0] not in ("h_finish_hand", "h_finish_mouth")]
groups.insert([g[0] for g in groups].index("h_overflow"), ("h_finish_hand", "手の中・口の中で出す", hand[2] + mouth[2]))
rows_all = [r for _, _, rows in groups for r in rows]
assert len({r["id"] for r in rows_all}) == len(rows_all)

BASE_NOTE = ("\n\nこの依頼は、ゲームの設定「描写の濃さ：濃い」を選んだ人向けの本文です。同じ場面の標準の本文はすでにあります。"
             "標準より露骨に、性器・体液・体の反応と、触れる音・感触を具体的に書いてください（state の「描写」のとおり）。"
             "この依頼に限り、プロンプトの「部位の語と記号は地の文で1本に2つまで」は「4つまで（同じ語・記号は2回まで）」に読み替えてください。擬音（湿った音・吸う音など）も使ってよいです。"
             "\nstate の慣れが「初回」の job では、露骨に書くのは地の文の感触と体の反応だけです。真帆の台詞・表情・動作は初回の戸惑いと照れのままにし、台詞の語は初回の語（胸、ここ）だけにしてください。地の文に「初めて」と書かない規則も同じです。"
             "\nstate の服・体位・挿入のとおりに書いてください（下着の上から触れる job では下着の上から。脱がせる・ずらす・入れるは書かない）。真帆が口でしている job の台詞は、口を離した合間の短い一言です。"
             "続けている動作の job（「続けている」「さらに続けている」）は、前の本文と同じ動き・同じ結びにしないでください。"
             "state に「顔」があるときは、そのとおりにしてください（真帆の表情を正面から見たようには書かない）。")
NIPPLE_NOTE = ("\n真帆の上の服は、着ているかめくれているか決まっていません。{nipple}・乳輪・胸の肌を直接書く本文は、上の服がめくれているときだけ出します（ゲームの側で条件を付けます）。"
               "そのため、各 job の5本のうち、{nipple}・乳輪・胸の肌を直接書くのは2本までにしてください。")
FINISH_NOTE = ("\n出す・果てる本文では、台詞で「待って」「止まって」を使わない。「入った」「出てる」のような実況の台詞にしない。"
               "こらえきれずに出す job は、出すと決めて出したように書かない（こらえようとしたのに、こらえきれなかった流れで）。")
TAIL = "\nそれ以外の規則（台詞の数、慣れの段階の語、地の文で器官を名前で呼ばず記号を使う、記号を台詞に書かない、妊娠・避妊に触れない、must_not）は同じです。"

(OUT / "grok_b2_wave_x5.json").write_text(json.dumps(rows_all, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
folder = OUT / "grok依頼_B2_濃い版"
number = 43
listing = []
for action, label, rows in groups:
    note = BASE_NOTE + ("" if action in CHEST else NIPPLE_NOTE) + (FINISH_NOTE if action in ("h_finish_hand", "h_finish_mouth", "h_overflow") else "") + TAIL
    splits = ((None, "台詞あり・なし"),) if len(rows) <= 13 else ((True, "台詞あり"), (False, "台詞なし"))
    for speech, kind in splits:
        part = [r for r in rows if speech is None or r["speech"] == speech]
        count = -(-len(part) // 13)
        size = -(-len(part) // count)
        for index in range(0, len(part), size):
            chunk = part[index:index + size]
            number += 1
            lines = [json.dumps({"id": r["id"], "meaning": r["meaning"], "speech": r["speech"], "length": r["length"], "origin": r["origin"], "本数": r["candidates"],
                                 **({"must_not": r["must_not"]} if r.get("must_not") else {}), "state": r["state"]}, ensure_ascii=False) for r in chunk]
            body = ("指示\n"
                    f"次の{len(chunk)}件の job を書いてください（段階Bの2版目・描写の濃さ：濃い・前戯・{label}・{kind}）。本数は各 job の「本数」のとおりです（合わせて{sum(r['candidates'] for r in chunk)}本）。"
                    "途中で切れそうなら、job の区切りで止めてください。「続けて」と言われたら、止めた job の次から出してください。"
                    + note + "\n\n[\n  " + ",\n  ".join(lines) + "\n]\n\n"
                    "プロンプト\n" + PROMPT)
            file_name = f"B2_濃い版_{number:02d}_前戯_{label}_{kind}.txt"
            (folder / file_name).write_text(body, encoding="utf-8")
            listing.append({"file": file_name, "jobs": len(chunk), "texts": sum(r["candidates"] for r in chunk)})
(OUT / "濃い版_前戯_一覧.json").write_text(json.dumps({"jobs": len(rows_all), "texts": sum(r["candidates"] for r in rows_all), "files": listing}, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
print(len(rows_all), sum(r["candidates"] for r in rows_all))
for item in listing:
    print(item["file"], item["jobs"], item["texts"])
