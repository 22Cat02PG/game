"""Small, bounded play session shared by humans and automation.

The Engine remains the only owner of game rules. A turn here is one submitted
command (including errors and queries), not a minute of simulated island life.
"""
from .codec import decode, exact
from .errors import GameError, ensure


COMMANDS = {
    "view": ((), ()), "state": ((), ()), "actions": ((), ()),
    "choose": (("id",), ("revision", "session")),
    "save": ((), ("slot",)), "load": ((), ("slot", "backup")),
    "slots": ((), ()), "collection": ((), ("kind", "id")),
    "diagnostics": ((), ()), "cheat": (("action",), ()), "adopt": (("release",), ()),
    "quit": ((), ()),
}

ENDING = "真帆と、これからも凪島で暮らしていくことを選んだ。二人の日常は、この先も続く。テキスト試作版・完。"


class Session:
    def __init__(self, engine, max_turns=200, test_cheats=None):
        ensure(type(max_turns) is int and 1 <= max_turns <= 100000,
               "max_turns", "max_turnsは1〜100000の整数で指定する。")
        self.engine = engine
        self.test_cheats = getattr(engine, "test_cheats", False) if test_cheats is None else test_cheats
        ensure(type(self.test_cheats) is bool, "test_cheats", "test_cheatsは真偽値で指定する。")
        self.max_turns = max_turns
        self.turns = 0
        self.reason = None
        self._check_end()

    def _check_end(self):
        state = self.engine.snapshot()
        if state["relation"]["stage"] == 4 and not state["scene"] and not state["offer"] and not self.life_continues():
            self.reason = "completed"
        elif self.reason is None and self.turns >= self.max_turns:
            self.reason = "max_turns"

    def life_continues(self):
        rules = self.engine.pack.progression
        return bool(rules and rules.life_after_stage4)

    @property
    def cleared(self):
        return self.engine.snapshot()["relation"]["stage"] == 4 and self.life_continues()

    def finish(self, reason):
        ensure(reason in ("commands_exhausted", "eof", "quit", "error", "policy_stalled", "interrupted", "cleared"),
               "end_reason", "未登録の終了理由。")
        if self.reason is None:
            self.reason = reason
        return self.observe()

    def observe(self):
        view = self.engine.get_view()
        return {
            "state": self.engine.snapshot(), "view": view,
            "available_actions": [] if self.reason else [c for c in view["choices"] if c["available"]],
            "run": {"turns": self.turns, "max_turns": self.max_turns,
                    "ended": self.reason is not None, "reason": self.reason,
                    "completed": self.reason == "completed", "cleared": self.cleared,
                    "ending": ENDING if self.reason == "completed" else None},
        }

    def execute_line(self, line):
        try:
            value = decode(line)
        except GameError as error:
            return self._execute(None, error)
        return self.execute(value)

    def execute(self, value):
        return self._execute(value)

    def _execute(self, value, input_error=None):
        if self.reason is not None:
            return {"ok": False, "error": {"code": "run_ended", "message": "この実行は終了している。"}, **self.observe()}
        self.turns += 1
        try:
            if input_error:
                raise input_error
            ensure(type(value) is dict and type(value.get("command")) is str,
                   "request", "commandを文字列で指定する。")
            command = value["command"]
            ensure(command in COMMANDS, "command", "未登録のcommand。")
            required, optional = COMMANDS[command]
            exact(value, ("command", *required), optional)
            result = self._dispatch(command, value)
            response = {"ok": True, "result": result}
        except (GameError, OSError, KeyError, TypeError, ValueError) as error:
            response = {"ok": False, "error": {"code": getattr(error, "code", "invalid_request"), "message": str(error)}}
        self._check_end()
        return {**response, **self.observe()}

    def _dispatch(self, command, value):
        engine = self.engine
        if command == "view":
            return engine.get_view()
        if command == "state":
            return engine.snapshot()
        if command == "actions":
            return engine.get_view()["choices"]
        if command == "choose":
            ensure(("revision" in value) == ("session" in value), "request", "revisionとsessionは両方指定するか両方省略する。")
            view = engine.get_view()
            return engine.choose(value["id"], value.get("revision", view["revision"]), value.get("session", view["session"]))
        if command == "save":
            return engine.save(value.get("slot", "slot01"))
        if command == "load":
            return engine.load(value.get("slot", "slot01"), value.get("backup", False))
        if command == "slots":
            return engine.storage.slots()
        if command == "collection":
            ensure(type(value.get("kind", "memories")) is str, "request", "kindは文字列で指定する。")
            return engine.get_collection(value.get("kind", "memories"), value.get("id"))
        if command == "diagnostics":
            return engine.get_diagnostics()
        if command == "cheat":
            ensure(self.test_cheats, "cheat_disabled", "テストチートは--test-cheats付きの実行でだけ使える。")
            return engine.enable_test_cheat(value["action"])
        if command == "adopt":
            return engine.adopt_release(value["release"])
        if command == "quit":
            self.reason = "quit"
            return {"message": "終了した。"}
        raise AssertionError(command)
