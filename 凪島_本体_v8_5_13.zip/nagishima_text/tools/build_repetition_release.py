"""Create a new prose-only release from the reviewed repetition batch.

This is a replacement migration, not the additions-only authoring publisher.
The source release is never changed and no human approval is inferred.
"""

from copy import deepcopy
from pathlib import Path
import os
import shutil
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from nagishima.codec import bytes_digest, read_json, write_json
from nagishima.content import FILES, Pack

SOURCE = "interaction_003"
TARGET = "interaction_004"
BATCH = ROOT / "collaboration" / "batches" / "repetition_presence_001" / "final_text.json"
RELEASES = ROOT / "content" / "releases"


def main():
    source = Pack(RELEASES / SOURCE)
    target = RELEASES / TARGET
    if target.exists():
        raise SystemExit(f"公開済み版を上書きしない: {target}")
    batch = read_json(BATCH)
    if batch["batch_id"] != "repetition_presence_001" or batch["source_release"] != SOURCE:
        raise SystemExit("執筆バッチの出典が一致しない")
    items = batch["items"]
    ids = [item["text_id"] for item in items]
    if len(items) != 24 or len(set(ids)) != 24:
        raise SystemExit("24本文のIDが不足または重複")
    by_id = {item["text_id"]: item for item in items}
    texts = deepcopy(source.texts)
    changed = set()
    variants = {}
    for text in texts:
        item = by_id.get(text["id"])
        if item is None:
            continue
        if item["meaning_id"] != text["meaning"] or text["fallback"]:
            raise SystemExit(f"意味または基本本文の指定が不正: {text['id']}")
        body = item["body"]
        if not isinstance(body, str) or not 45 <= len(body) <= 160:
            raise SystemExit(f"本文の長さが不正: {text['id']}")
        if item["source"] not in {"gemini_3_8_flash", "codex_revision"}:
            raise SystemExit(f"執筆元が不明: {text['id']}")
        text["body"] = body
        variants[text["meaning"]] = variants.get(text["meaning"], 0) + 1
        text["group"] = f"{text['meaning']}.i004.v{variants[text['meaning']]}"
        changed.add(text["id"])
    if changed != set(ids) or set(variants.values()) != {3} or len(variants) != 8:
        raise SystemExit("原稿IDまたは意味の照合に失敗")

    temporary = Path(tempfile.mkdtemp(prefix=".building-repetition-", dir=RELEASES))
    try:
        for name in FILES:
            value = texts if name == "texts.json" else read_json(source.path / name)
            write_json(temporary / name, value)
        manifest = {
            "id": TARGET,
            "rules_version": source.manifest["rules_version"],
            "files": {name: bytes_digest((temporary / name).read_bytes()) for name in FILES},
            "control_sha256": source.control_hash,
        }
        write_json(temporary / "release.json", manifest)
        write_json(temporary / "revision_provenance.json", {
            "source_release": SOURCE,
            "source_sha256": source.hash,
            "batch_id": batch["batch_id"],
            "status": "working_draft",
            "reviewed": False,
            "note": "Claude Sonnet 5初稿をGemini 3.8 Flashで清書。気分の返答6本はGeminiの再清書が失敗したためCodexが修正。人間の承認は記録していない。",
            "items": [{"text_id": item["text_id"], "source": item["source"]} for item in items],
        })
        Pack(temporary)
        os.rename(temporary, target)
    finally:
        if temporary.exists():
            shutil.rmtree(temporary)
    print(target)


if __name__ == "__main__":
    main()
