"""JSONL run records plus a copy of the starting userdata for exact replay.

The checkpoint is intentionally plain files. No pickle or executable input is
used. Runtime content hashes and response fingerprints detect changed rules.
"""
from copy import deepcopy
from pathlib import Path
import json
import shutil

from .codec import decode, digest
from . import RULES_VERSION
from .errors import ensure


def stable(value):
    """Session tokens prevent stale UI input, but are not simulation randomness."""
    if isinstance(value, dict):
        return {key: stable(item) for key, item in value.items() if key != "session"}
    if isinstance(value, list):
        return [stable(item) for item in value]
    return value


def fingerprint(response):
    return digest(stable(response))


def runtime_hash():
    root = Path(__file__).parent
    return digest({p.name: p.read_text(encoding="utf-8") for p in sorted(root.glob("*.py"))})


class RunLog:
    def __init__(self, path, data_dir, config, release_hash):
        self.path = Path(path).resolve()
        self.initial = self.path.with_name(self.path.name + ".initial")
        data = Path(data_dir).resolve()
        ensure(not self.path.is_relative_to(data) and not data.is_relative_to(self.initial),
               "log_path", "ログはuserdataの外に置く。")
        ensure(not self.path.exists() and not self.initial.exists(),
               "log_exists", "既存のログは上書きしない。別の--logを指定する。")
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.initial.mkdir()
        if data.exists():
            shutil.copytree(data, self.initial / "data")
        else:
            (self.initial / "data").mkdir()
        self.stream = self.path.open("x", encoding="utf-8", newline="\n")
        self.write({"type": "start", "format": 1, "config": config,
                    "checkpoint": self.initial.name, "runtime_sha256": runtime_hash(),
                    "rules_version": RULES_VERSION,
                    "release_sha256": release_hash})

    def write(self, value):
        self.stream.write(json.dumps(value, ensure_ascii=False, allow_nan=False) + "\n")
        self.stream.flush()

    def command(self, raw, before_session, response):
        # Preserve stale tokens; only a currently valid token is rebound on replay.
        rebind = False
        try:
            value = decode(raw)
            rebind = type(value) is dict and value.get("session") == before_session
        except ValueError:
            pass
        self.write({"type": "command", "input": raw, "rebind_session": rebind,
                    "response": response, "sha256": fingerprint(response)})

    def end(self, observation, **extra):
        self.write({"type": "end", **deepcopy(observation), **extra,
                    "sha256": fingerprint(observation)})

    def close(self):
        self.stream.close()
