"""Reproducible public-choice Stage B routes (only time is prepared internally)."""
import json
from pathlib import Path
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from nagishima.engine import Engine

PAGES = {"kiss": "h_touch", "caress": "h_touch", "undress": "h_clothes", "position": "h_position",
         "insert": "h_connect", "move": "h_connect", "tease": "h_connect", "grind": "h_connect", "mutual": "h_service", "finish": "h_connect", "words": "h_words", "after": "h_words", "service": "h_service", "self": "h_service"}
# B2：夜（19時〜翌5時）にエッチを終えると、そのまま一緒に眠って翌朝になる。終えた後の状態を確かめる経路は、休日の昼に走らせる。
DAYTIME = {"day_offset": 3, "hour": 13}
QUICK = ("h_finish_inside", "h_finish_outside", "h_finish_hand", "h_finish_mouth", "h_finish_sumata", "h_finish_breasts", "h_finish_feet", "h_finish_sixty_nine",
         "h_extra_lick", "h_extra_balls", "h_endure", "h_withdraw", "h_after_hold")


def dinner_done(engine):
    """v8.1.0：夕食（18:30〜20:30 の最初の空いた時に自動）を、その日は済んだことにする。試験の準備だけに使う（時刻と同じく内部で用意する）。"""
    from nagishima.progression import life_day
    state = engine._state
    if not engine.pack.life or not engine.pack.life.meals:
        return
    day = life_day(state["world"]["now"])
    state["cooldowns"] = [x for x in state["cooldowns"] if x["group"] != "meal_dinner"] + [
        {"group": "meal_dinner", "day": day, "completed_activity_count": state["progress"]["completed_activities"]}]
    engine._install_choices()


def bath_done(engine):
    """v8.2.0：風呂（21:00〜00:30 の最初の空いた時に自動）を、その日は済んだことにする（湯上がりにはしない）。試験の準備だけに使う。"""
    from nagishima.progression import life_day
    state = engine._state
    if "bath" not in state:
        return
    state["bath"]["day"] = life_day(state["world"]["now"])
    engine._install_choices()


class Route:
    def __init__(self, seed, hour=19, minute=0, tier="first", day_offset=0, dinner=False, bath=False, release="interaction_009"):
        self.temp = tempfile.TemporaryDirectory(prefix="nagishima-route-")
        self.engine = Engine(self.temp.name, seed=seed, release=release, autosave=False, test_cheats=True)  # v8.3.3：010 の試験は release で選ぶ
        self.engine.enable_test_cheat("all")
        self.engine.enable_test_cheat("intimacy_tier:" + tier)
        now = self.engine._state["world"]["now"]
        new_time = (now // 1440 + day_offset) * 1440 + hour * 60 + minute
        self.engine._state["world"].update(now=new_time, processed_until=new_time)
        self.engine._state["world"]["awake_deadline"] += day_offset * 1440
        self.engine._install_choices()
        if not dinner:
            dinner_done(self.engine)
        if not bath:
            bath_done(self.engine)
        self.seed, self.commands = seed, []

    def close(self): self.temp.cleanup()

    def choose(self, identity):
        view = self.engine.get_view()
        choice = next((item for item in view["choices"] if item["id"] == identity), None)
        if choice is None or not choice["available"]:
            raise AssertionError((identity, view["page"], choice, self.engine.snapshot()["intimacy"], self.commands))
        self.commands.append(identity)
        return self.engine.choose(identity, view["revision"], view["session"])

    def action(self, key):
        if self.engine.snapshot()["offer"] and self.engine.snapshot()["offer"]["kind"].startswith("h_lead_"):
            self.choose("offer.decline")
        identity = "touch." + key
        view = self.engine.get_view()
        if not any(c["id"] == identity for c in view["choices"]):
            if view["page"] != "main": self.choose("menu.main")
            if key not in QUICK:
                category = self.engine.pack.intimacy.actions[key]["category"]
                self.choose("menu." + self.engine.pack.intimacy.action_pages.get(key, PAGES[category]))  # v8.4.0（010）：頁「手と体」（h_close）
        return self.choose(identity)

    def begin(self, entry="h_kiss_deep"):
        self.choose("private.begin")
        self.choose("menu.touch")  # B2：触れ方を深める行動は、いつもの「触れ合う」に並ぶ
        self.choose("touch." + entry)

    def status(self):
        state = self.engine.snapshot()
        return {"seed": self.seed, "commands": self.commands, "now": state["world"]["now"],
                "intimacy": state["intimacy"], "history": state["intimacy_history"],
                "blocks": [b["meaning"] for b in self.engine.get_view()["blocks"]]}


def satisfied(route):
    route.begin()
    for key in ("h_check", "h_check", "h_feel", "h_feel"):
        route.action(key)
    for _ in range(8): route.action("h_kiss_deep")
    for key in ("h_chest_over", "h_lift_upper", "h_chest_skin", "h_strip_lower", "h_shift_under",
                "h_strip_self", "h_pos_player_above", "h_insert"):
        route.action(key)
    # v8.2.29（ユーザー 2026-09-30「一回の行為が短い」）：入れてから果てるまでが長くなったので、真帆が達するか、こちらが出す手前まで動く
    for _ in range(10):
        intimate = route.engine.snapshot()["intimacy"]
        if intimate["maho"]["climaxes"] or intimate["player"]["arousal"] >= 90:
            break
        while route.engine.snapshot()["offer"]:
            route.choose("offer.decline")
        route.action("h_move_normal")
    route.action("h_finish_inside")
    route.action("h_after_hold")
    route.action("h_after_hold")
    if route.engine.get_view()["page"] != "main": route.choose("menu.main")
    route.choose("h.end")
    assert route.engine.snapshot()["intimacy"] is None, route.status()
    assert route.engine.snapshot()["intimacy_history"]["last_result"] == "satisfied", route.status()


def quick_hold(route):
    route.begin()
    route.choose("h.end")
    assert route.engine.snapshot()["offer"]["kind"] == "hold_back", route.status()
    route.choose("offer.decline")
    assert route.engine.snapshot()["intimacy_history"]["last_result"] == "unsatisfied", route.status()


def deadline(route):
    route.begin()
    for _ in range(20):
        if route.engine.snapshot()["intimacy"]["wrap_up"] is not None: break
        route.action("h_kiss_deep")
    assert route.engine.snapshot()["intimacy"]["wrap_up"] == 1, route.status()
    route.action("h_feel")  # v8.0.5：締め切りの後は「様子を聞く」を選べない（監査 F-02）
    assert route.engine.snapshot()["intimacy"]["wrap_up"] == 0, route.status()
    if route.engine.get_view()["page"] != "main": route.choose("menu.main")
    route.choose("h.end")
    blocks = route.status()["blocks"]
    assert "h.ended.deadline" in blocks and "h.sleep_together.unsatisfied" in blocks, route.status()  # B2：夜に終えたら一緒に眠る


def stamina_zero(route):
    for cycle in range(3):
        route.begin()
        while route.engine.snapshot()["intimacy"]["maho"]["arousal"] < 40:
            route.action("h_kiss_deep")
        for key in ("h_strip_lower", "h_shift_under", "h_strip_self", "h_pos_player_above", "h_insert"):
            route.action(key)
        while route.engine.snapshot()["intimacy"]["player"]["arousal"] < 70:
            route.action("h_move_normal")
        route.action("h_finish_inside")
        if route.engine.get_view()["page"] != "main": route.choose("menu.main")
        route.choose("h.end")
        assert route.engine.snapshot()["offer"]["kind"] == "hold_back", route.status()
        if cycle == 2:
            assert route.engine.snapshot()["stamina"]["value"] == 0, route.status()
        route.choose("offer.decline")
    assert route.engine.snapshot()["intimacy_history"]["count"] == 3, route.status()


def to_evening(route):
    """休日の昼から、真帆が誘える時刻（19時）へ。経路と同じく、時刻だけを内部で用意する。"""
    rules = route.engine.pack.intimacy
    from nagishima.progression import day_time
    state = route.engine._state
    assert state["offer"] is None and state["intimacy"] is None and state["mode"] == "normal", route.status()
    now = state["world"]["now"]
    target = now - day_time(now) + rules.invite_from
    assert target >= now, route.status()
    state["world"].update(now=target, processed_until=target)
    route.engine._install_choices()
    dinner_done(route.engine)
    bath_done(route.engine)


def listen_for_invite(route):
    for _ in range(4):
        route.choose("listen")
        offer = route.engine.snapshot()["offer"]
        if offer and offer["kind"] == "intimacy_invite": return
        if offer: route.choose("offer.decline")
    raise AssertionError(route.status())


def invite(route):
    # B2：夜に終えると翌朝になるので、休日の昼に二度終えてから、夜の誘いを待つ（Route は DAYTIME で作る）
    quick_hold(route)
    quick_hold(route)
    to_evening(route)
    listen_for_invite(route)
    assert route.engine.snapshot()["offer"]["kind"] == "intimacy_invite", route.status()
    route.choose("offer.accept")
    state = route.engine.snapshot()
    assert state["intimacy"]["entry"] == "invite" and state["intimacy"]["origin"] == "maho", route.status()
    assert state["actors"]["player"]["location"] == "maho_room", route.status()


def maho_lead_together(route):
    # v8.2.30（通し確かめ 6）：申し出るかは回ごとに決まる（数回 25%＋淫乱度）。申し出のない回は終えて、次の回で待つ
    route.engine.enable_test_cheat("lewdness:70")
    for _ in range(8):
        route.begin()
        route.action("h_strip_lower")
        route.action("h_strip_self")
        for _ in range(16):
            if route.engine.snapshot()["offer"]: break
            route.action("h_kiss_deep")
        offer = route.engine.snapshot()["offer"]
        if offer and offer["kind"] == "h_lead_straddle":
            break
        while route.engine.snapshot()["offer"]:
            route.choose("offer.decline")
        if route.engine.get_view()["page"] != "main": route.choose("menu.main")
        route.choose("h.end")
        while route.engine.snapshot()["offer"]:
            route.choose("offer.decline")
    assert route.engine.snapshot()["offer"]["kind"] == "h_lead_straddle", route.status()
    route.choose("offer.accept")
    assert route.engine.snapshot()["intimacy"]["position"] == "maho_above", route.status()
    route.action("h_shift_under")
    route.action("h_insert")
    for _ in range(120):  # v8.2.29：入れてから果てるまでを長くした
        state = route.engine.snapshot()
        maho, player = state["intimacy"]["maho"], state["intimacy"]["player"]
        if player["arousal"] >= 70 and maho["arousal"] >= 94:
            route.action("h_finish_inside")
            assert "h.climax.together" in route.status()["blocks"], route.status()
            return
        if player["arousal"] >= 100:
            if player["endured"] == 0: route.action("h_endure")
            else:
                route.action("h_finish_inside")
                route.action("h_after_hold")
                route.action("h_after_hold")
        elif maho["arousal"] >= 88 and player["arousal"] < 70:
            route.action("h_kiss_deep")  # v8.2.29：真帆が先に高まるので、口づけでこちらが追いつくのを待つ
        else:
            route.action("h_move_normal")
    raise AssertionError(route.status())


def route_for(name, seed):
    """経路ごとの開始時刻（B2：終えた後の状態を確かめる経路は、夜に終えると翌朝になるので休日の昼から）。"""
    if name == "workday_deadline": return Route(seed, hour=21, minute=24, tier="few")  # v8.2.30：初めての回は締め切りまで60分ないと始めない
    if name == "maho_lead_together": return Route(seed, tier="few", day_offset=2)
    if name == "stamina_zero_hold_back": return Route(seed, day_offset=3, hour=10)
    if name == "maho_invite": return Route(seed, **DAYTIME)
    return Route(seed)


def main():
    rows = []
    for name, runner in (("first_satisfied", satisfied), ("first_hold_back_decline", quick_hold),
                         ("workday_deadline", deadline), ("stamina_zero_hold_back", stamina_zero),
                         ("maho_invite", invite), ("maho_lead_together", maho_lead_together)):
        for seed in (0, 42, 20380407):
            route = route_for(name, seed)
            try:
                runner(route)
                result = {"route": name, "seed": seed, "success": True, "commands": route.commands,
                          "result": route.engine.snapshot()["intimacy_history"]["last_result"]}
            except Exception as error:
                result = {"route": name, "seed": seed, "success": False, "error": repr(error), "commands": route.commands}
            finally: route.close()
            rows.append(result)
            print(name, seed, result["success"], result.get("error", ""), flush=True)
    target = ROOT / "verification" / "stage_b_routes.json"
    target.write_text(json.dumps(rows, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return 0 if all(row["success"] for row in rows) else 1


if __name__ == "__main__": sys.exit(main())
