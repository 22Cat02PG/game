@echo off
chcp 65001 >nul
cd /d "%~dp0"
rem Stage B working release (interaction_010, with the v8.3.3+ fixes) with test cheats.
call "%~dp0start.bat" --release interaction_010 --test-cheats %*
exit /b %errorlevel%
