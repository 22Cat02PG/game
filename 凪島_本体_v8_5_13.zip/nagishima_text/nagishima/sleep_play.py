"""段階C（010、v8.5.0）：眠っている真帆に触れる（寝込み）・夜這い・翌朝・警戒。
仕様は docs/凪島_段階C_仕様_2026-10-08.md の第2・3・5.1・6.3節、足し方は第16節。決まりの数値は intimacy.json の sleep_play 節（nagishima/sleep_rules.py）。
- 同意は事前に聞かない。受け入れは目覚めたときの態度と翌朝の反応で示す。好感度の差は、目覚めやすさと反応で出す。
- 行動・夜の印・目覚めの反応・翌朝の一言は、データ（sleep_play 節）で足せる。エンジンが決めるのは、ゲージの動き・寝たふり・時刻・場所・状態の整合だけ。
- 状態：sleep_play（寝込みの最中だけ）と sleep_record（受け入れた回数・触れ方の慣れ・怒らせた日・夜の記録）。どちらも sleep_play 節のある版だけ持つ。"""
from .codec import digest
from .conditions import evaluate
from .errors import GameError, ensure
from .progression import change_desire, day_time, life_day
from .sleep_rules import GAUGES
from .stage_b_state import neutral_sleep_record

PLAYER_ROOMS = ("living_room", "kitchen", "player_room")  # 夜這いに出られる場所（住まいの中）
GAUGE_LINE_ORDER = ("discomfort", "wake", "pleasure")  # 段が上がったときの様子の一文は、1手に1つ（不快・目覚め・快感の順）
RANK = {"low": 0, "mid": 1, "high": 2}


class SleepPlay:
    @property
    def sr(self):
        rules = self.pack.intimacy.sleep_play if self.pack.intimacy else None
        ensure(rules is not None, "sleep_play", "この原稿版に寝込みは登録されていない。")
        return rules

    def sleep_record(self):
        if "sleep_record" not in self.s:
            self.s["sleep_record"] = neutral_sleep_record()
        return self.s["sleep_record"]

    def sleep_cooling(self):
        """怒らせた・警戒の間なら、その記録（終わる日を過ぎていれば None）。"""
        record = self.s.get("sleep_record")
        cooling = record["cooling"] if record else None
        if cooling is None or cooling["until"] <= life_day(self.now):
            return None
        return cooling

    def sleep_guarded(self):
        cooling = self.sleep_cooling() if self.pack.intimacy and self.pack.intimacy.sleep_play else None
        return bool(cooling and cooling["kind"] == "guard")

    def sleep_action_open(self, identity, values=None):
        """その行動を今選べるか（行動の条件 when）。メニューと sleep_act の両方で使う。"""
        row = self.sr.actions[identity]
        return "when" not in row or evaluate(row["when"], values if values is not None else self.pack.registry.values(self.s)) is True

    def _require_sleep_free(self):
        ensure(not self.s.get("sleep_play") and self.s["mode"] == "normal" and self.s["intimacy"] is None and not self.s["scene"] and not self.s["offer"],
               "sleep_play", "今は選べない。")
        from .event_play import drank_tonight
        ensure(not drank_tonight(self.s), "sleep_play", "今夜の真帆は、お酒を飲んで眠った。")  # v8.5.3：晩酌でほろ酔い以上になった夜は、寝込みに入らない

    def _require_not_cooling(self):
        cooling = self.sleep_cooling()
        if cooling:
            raise GameError("sleep_cooling", f"今は触れられない（あと{cooling['until'] - life_day(self.now)}日）。")
        night = self.sleep_record()["night"]
        if night and night["reaction"] is not None and night["day"] == life_day(self.now):
            raise GameError("sleep_cooling", "今夜はもう起こしてしまった。")  # 目覚めさせた夜（その生活日）は、もう一度は始めない

    # ---- 入口 ----
    def sleep_begin(self):
        """眠っている（うたた寝・就寝中の）真帆と同じ場所で、そっと触れはじめる。"""
        self.sr
        self._require_sleep_free()
        state = self.s["maho_sleep"]["state"]
        ensure(state in ("dozing", "asleep") and self.values()["together"], "sleep_play", "眠っている真帆と同じ場所にいるときに選ぶ。")
        self._require_not_cooling()
        if self.s.get("co_sleep"):
            # v8.5.6：添い寝で隣に眠る真帆（目覚めの倍率は kinds.cosleep）
            ensure(self.s["co_sleep"]["phase"] == "asleep" and "cosleep" in self.sr.kind_factor, "sleep_play", "今は選べない。")
            self._sleep_start("cosleep")
            return
        self._sleep_start("doze" if state == "dozing" else "asleep")

    def sleep_visit(self):
        """夜這い：就寝後の真帆の部屋へそっと行く。警戒の間は鍵がかかっている。"""
        rules = self.sr
        self._require_sleep_free()
        player = self.s["actors"]["player"]
        ensure(self.s["maho_sleep"]["state"] == "asleep" and player["location"] in PLAYER_ROOMS, "sleep_visit", "真帆が部屋で眠っているときに、家の中から行く。")
        cooling = self.sleep_cooling()
        if cooling and cooling["kind"] == "guard":
            self.require_time(rules.action_minutes)
            self.advance(rules.action_minutes)
            self.emit("sp.visit.locked")
            return
        self._require_not_cooling()
        self.require_time(5)
        self.s["contacts"] = []
        self.advance(5)
        player["location"], player["posture"] = "maho_room", "seated"
        self.s["distance"] = "near"
        self.emit("sp.visit.enter")
        self._sleep_start("asleep")

    def _sleep_start(self, kind):
        rules = self.sr
        record = self.sleep_record()
        depth = rules.depth(self.s["affinity"]["value"], record["accepted"])
        pleasure = rules.start_pleasure if self.s["desire"] >= rules.start_desire else 0
        gauges = {"wake": 0, "discomfort": 0, "pleasure": pleasure}
        self.s["sleep_play"] = {"id": self.new_id("sleep"), "kind": kind, "started_at": self.now, "depth": depth, "gauges": gauges,
                                "fake": self._fake_roll(depth), "strain": 0, "used": [], "last": None, "level": 0, "flags": [], "talked": False, "warned": False,
                                "bands": {g: rules.band(v) for g, v in gauges.items()}}
        self.s["interaction_streak"] = None
        self.emit("sp.begin." + kind)

    def _fake_roll(self, depth):
        """寝たふり（隠しの値）：始めた時点で決める。恋人で関係が深く、欲求が高いときだけ。同じ seed・同じ操作なら同じ結果。"""
        fake = self.sr.fake
        if not (self.s["relation"]["stage"] >= 3 and depth >= fake["lover_depth"] and self.s["desire"] >= fake["lover_desire"]):
            return False
        return int(digest([self.s["world"]["seed"], "sleep_fake", self.s["world"]["operation_seq"], life_day(self.now)])[:8], 16) % 100 < fake["percent"]

    # ---- 寝込みの間 ----
    def _play(self):
        play = self.s.get("sleep_play")
        ensure(play, "sleep_play", "眠っている真帆に触れていない。")
        return play

    def sleep_act(self, identity):
        """行動：時間を進め、使った記録・直前の行動・段階・印を更新して本文を出し、ゲージを動かす（本文はゲージを動かす前の状態で選ぶ）。"""
        rules = self.sr
        play = self._play()
        ensure(identity in rules.actions and identity != "sp_leave", "sleep_action", "寝込みの行動が未登録。")
        ensure(self.sleep_action_open(identity), "sleep_action", "今は選べない。")
        row = rules.actions[identity]
        minutes = row.get("minutes") or (rules.wait_minutes if identity == "sp_wait" else rules.action_minutes)
        self.require_time(minutes)
        self.advance(minutes)
        if identity not in play["used"]:
            play["used"].append(identity)
        play["last"] = identity
        play["level"] = max(play["level"], row.get("level", 0))
        flags = set(play["flags"]) | set(row.get("sets", ()))
        play["flags"] = sorted(flags - set(row.get("clears", ())))
        self.emit("sp." + identity[3:])
        self._sleep_gauges(identity, row)
        self._sleep_after_step()

    def _sleep_gauges(self, identity, row):
        rules = self.sr
        play = self.s["sleep_play"]
        g = play["gauges"]
        record = self.sleep_record()
        old = dict(g)
        for gauge in GAUGES:
            base = row[gauge]
            if base > 0:
                factor = rules.multipliers[play["depth"]][gauge]
                if gauge == "wake":
                    factor *= rules.kind_factor[play["kind"]]
                if gauge == "discomfort" and record["habits"].get(identity):
                    factor *= rules.habit_factor  # 受け入れられた夜に使った触れ方は、次から不快が半分
                delta = int(base * factor + 0.5)
            else:
                delta = base
            g[gauge] = max(0, min(100, g[gauge] + delta))
        if identity != "sp_wait" and day_time(self.now) >= rules.dawn_from:
            g["wake"] = min(100, g["wake"] + rules.dawn_plus)  # 夜明けが近いと目覚めやすい
        if play["fake"]:
            fake = rules.fake
            g["wake"] = min(g["wake"], fake["hold_at"])  # 寝たふりの間、目覚めは止まる（見た目は眠ったまま）
            strain = max(0, g["discomfort"] - old["discomfort"])
            if g["pleasure"] >= fake["pleasure_at"]:
                strain += fake["pleasure_plus"]
            play["strain"] = min(1000, play["strain"] + strain + max(0, g["pleasure"] - old["pleasure"]))
        self._sleep_lines()

    def _sleep_lines(self):
        """寝たふりが崩れる手前・寝言・ゲージの段が上がった様子の一文（1手に1つまで）。"""
        rules = self.sr
        play = self.s["sleep_play"]
        g = play["gauges"]
        if play["fake"] and not play["warned"] and play["strain"] >= rules.fake_limit(play["depth"]) * rules.fake["warn_ratio"]:
            play["warned"] = True
            self.emit("sp.state.strain")
        if not play["talked"]:
            if g["pleasure"] >= rules.sleeptalk_at and g["pleasure"] >= g["discomfort"]:
                play["talked"] = True
                self.emit("sp.sleeptalk.good")
            elif g["discomfort"] >= rules.sleeptalk_at:
                play["talked"] = True
                self.emit("sp.sleeptalk.bad")
        raised = next((gauge for gauge in GAUGE_LINE_ORDER if RANK[rules.band(g[gauge])] > RANK[play["bands"][gauge]]), None)
        play["bands"] = {key: max(play["bands"][key], rules.band(g[key]), key=RANK.get) for key in GAUGES}  # 段は下がらない（同じ段の一文を繰り返さない）
        if raised:
            self.emit(f"sp.state.{raised}.{rules.band(g[raised])}")

    def _sleep_after_step(self):
        rules = self.sr
        play = self.s["sleep_play"]
        g = play["gauges"]
        if play["fake"] and play["strain"] >= rules.fake_limit(play["depth"]):
            self._sleep_wake("fake_crumble" if g["pleasure"] >= g["discomfort"] else "fake_stop")
            return
        if g["wake"] >= 100 or g["discomfort"] >= 100:
            self._sleep_wake()
            return
        if play["kind"] == "doze":
            plan = self.pack.progression.doze_plan(self.s["world"]["seed"], life_day(self.now))
            if plan is None or day_time(self.now) >= plan[1]:
                self._sleep_wake()  # うたた寝の終わり：自然に目を覚ます

    # ---- 離れる ----
    def sleep_leave(self):
        self.sr
        play = self._play()
        g = play["gauges"]
        reveal_now = reveal_later = False
        if play["fake"]:
            # 崩れる前に離れたら、半分はその場で「起きてたよ」と明かし、ほかは翌朝に明かす
            reveal_now = int(digest([self.s["world"]["seed"], "sleep_reveal", play["id"]])[:8], 16) % 2 == 0
            reveal_later = not reveal_now
        self.emit("sp.leave.fake_reveal" if reveal_now else "sp.leave." + play["kind"])
        if reveal_now and g["pleasure"] >= g["discomfort"]:
            self._sleep_accepted(play["used"])
        kind = play["kind"]
        self._sleep_close(reaction=None, fake_reveal=reveal_later)
        if reveal_now and kind == "doze":
            self.s["maho_sleep"].update(state="awake", since=None)
            self.s["actors"]["maho"]["posture"] = "seated"

    def _sleep_accepted(self, used):
        """受け入れられた：回数を数え、その夜に使った触れ方を慣れとして残す（待つは数えない）。"""
        record = self.sleep_record()
        record["accepted"] += 1
        for key in used:
            if key != "sp_wait" and key in self.sr.actions:
                record["habits"][key] = record["habits"].get(key, 0) + 1

    def _sleep_effects(self, row, used):
        """反応・翌朝の結果（accepted・cooling・affinity_loss・desire）を当てる。"""
        rules = self.sr
        record = self.sleep_record()
        if row.get("accepted"):
            self._sleep_accepted(used)
        if row.get("cooling"):
            record["cooling"] = {"kind": row["cooling"], "until": life_day(self.now) + rules.cooling_days[row["cooling"]]}
        if row.get("affinity_loss"):
            self._sleep_affinity_loss(row["affinity_loss"])
        if row.get("desire"):
            change_desire(self.s, self.pack.progression, row["desire"])

    def _sleep_close(self, reaction, fake_reveal=False):
        """寝込みを終える。夜の記録を残し、主人公は自分の部屋（うたた寝なら居間のまま）へ。"""
        play = self.s["sleep_play"]
        record = self.sleep_record()
        record["night"] = {"day": life_day(self.now), "kind": play["kind"], "pleasure": play["gauges"]["pleasure"], "discomfort": play["gauges"]["discomfort"],
                           "level": play["level"], "flags": list(play["flags"]), "used": list(play["used"]), "fake_reveal": fake_reveal, "reaction": reaction}
        self.s["sleep_play"] = None
        if play["kind"] == "asleep":
            player = self.s["actors"]["player"]
            player["location"], player["posture"] = "player_room", "standing"
            self.s["distance"] = "normal"

    # ---- 目覚め ----
    def _first_row(self, rows, values):
        return next(row for row in rows if evaluate(row["when"], values) is True)  # 表の最後はいつも当たる（読み込みで確かめる）

    def _sleep_reaction(self, forced=None):
        """目覚めの反応：寝たふりが崩れたときはエンジンが決め、ほかはデータの表を上から見る。
        受け入れる反応でも、恋人（段階3以上）・目覚める時刻までに時間がある・accept_when のどれかを欠けば、fallback の表から選び直す。"""
        rules = self.sr
        values = self.pack.registry.values(self.s)
        reaction = forced or self._first_row(rules.reaction_order, values)["id"]
        if reaction in rules.accept and not (self.s["relation"]["stage"] >= 3 and self._sleep_can_continue() and evaluate(rules.accept_when, values) is True):
            reaction = self._first_row(rules.reaction_fallback, values)["id"]
        return reaction

    def _sleep_can_continue(self):
        """起きているエッチへ移れる時刻か（二人の時間を始められるだけの時間が、目覚める時刻までにあるか）。"""
        minutes = self.pack.catalog["activities"]["private_time"]["minutes"]
        return self.now + minutes <= self.s["world"]["awake_deadline"]

    def _sleep_wake(self, forced=None):
        rules = self.sr
        play = self.s["sleep_play"]
        reaction = self._sleep_reaction(forced)
        row = rules.reactions[reaction]
        self.emit("sp.wake." + reaction)
        self._sleep_effects(dict(row, accepted=row["accept"] or row.get("accepted", False)), play["used"])
        if row["accept"]:
            self.cosleep_end(leave=False)  # 添い寝の夜：起きているエッチへ移る（v8.5.6）
            self._sleep_to_awake()
            return
        kind = play["kind"]
        self._sleep_close(reaction=reaction)
        if kind == "cosleep" and row.get("cosleep", "leave") == "leave":
            self.cosleep_end(leave=True)  # 添い寝の夜：反応の cosleep が leave なら自分の部屋へ戻る（stay なら、そのまま並んで眠る。v8.5.6）
        if kind == "doze":
            self.s["maho_sleep"].update(state="awake", since=None)
            self.s["actors"]["maho"]["posture"] = "seated"

    def _sleep_affinity_loss(self, amount):
        """親密度は下げるが、関係の段階は下げない（段階の下限で止める）。"""
        rules = self.pack.progression
        stage = self.s["relation"]["stage"]
        floor = rules.min_affinity[stage - 1] if stage >= 1 else 0
        affinity = self.s["affinity"]
        affinity["value"] = max(min(floor, affinity["value"]), affinity["value"] - amount)

    def _sleep_to_awake(self):
        """受け入れる反応：真帆が目を覚まし、自分から引き寄せて、そのまま起きているエッチへ（真帆の高まりは眠っている間の快感の半分）。"""
        play = self.s["sleep_play"]
        rules = self.ir
        pleasure = play["gauges"]["pleasure"]
        self.s["sleep_play"] = None
        self.s["maho_sleep"].update(state="awake", since=None)
        event_len = len(self.events)
        if self.s["actors"]["player"]["location"] not in rules.raw["session"]["locations"]:
            self.move(rules.raw["session"]["invite_room"], True, True)
        self.begin_private()
        self._begin_intimacy("wake", "maho")
        self.events = self.events[:event_len]
        arousal = min(rules.raw["maho"]["climax_at"] - 1, pleasure // 2)
        self.s["intimacy"]["maho"]["arousal"] = arousal
        self.s["intimacy"]["maho"]["band"] = rules.band(arousal)

    # ---- 翌朝・警戒・謝る ----
    def sleep_morning(self):
        """目覚めた朝の一言（前の夜の寝込み）。目覚めさせた夜は、その反応の翌朝の一言。目覚めなかった夜は、翌朝の表を上から見る。
        本文は夜の記録が残っている間に選び（条件 sleep.night.*）、結果はそのあとで当てる。"""
        rules = self.pack.intimacy.sleep_play if self.pack.intimacy else None
        record = self.s.get("sleep_record")
        if rules is None or not record or not record["night"]:
            return
        night = record["night"]
        if night["day"] == life_day(self.now) - 1:
            if night["reaction"] is not None:
                morning = rules.reactions[night["reaction"]].get("morning")
                if morning:
                    self.emit("sp.morning." + morning)
                    record["morning"] = {"day": life_day(self.now), "id": morning}  # v8.5.13：朝食の本文を一言に合わせる（条件 sleep.morning）
            else:
                row = self._first_row(rules.morning_order, self.pack.registry.values(self.s))
                if row["id"]:
                    self.emit("sp.morning." + row["id"])
                    record["morning"] = {"day": life_day(self.now), "id": row["id"]}
                self._sleep_effects(row, night["used"])
        record["night"] = None

    def sleep_apologize(self):
        """怒らせた・警戒の間に謝ると、終わりを1日早める（1日1回）。"""
        self.sr
        record = self.sleep_record()
        cooling = self.sleep_cooling()
        ensure(cooling is not None, "sleep_apologize", "謝ることはない。")
        self.require_awake()
        ensure(self.values()["together"] and self.s["mode"] == "normal" and not self.s["scene"] and not self.s["offer"], "sleep_apologize", "真帆と同じ場所で落ち着いて話す。")
        today = life_day(self.now)
        ensure(record["apologized_day"] != today, "sleep_apologize", "今日はもう謝った。")
        self.charge_minutes("talk")
        record["apologized_day"] = today
        cooling["until"] -= 1
        self.emit("sp.apologize.ended" if cooling["until"] <= today else "sp.apologize")
