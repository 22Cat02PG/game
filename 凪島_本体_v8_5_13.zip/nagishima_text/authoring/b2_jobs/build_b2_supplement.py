"""B2 の補充（2026-09-27、v8.1.1）：grok への依頼ファイルを作る。

- 採用が2本しかない job（書き足してもらう。元の job の state のまま）
- 遊び回り（tools/check_b2_sweep.py）で、書かれた本文がなかった場面の新しい job（grok_b2_wave_4.json に入れる）

出力：grok依頼_B2_補充/B2_補充_XX.txt（「指示」＋「プロンプト」）、grok_b2_wave_4.json（新しい job）、補充_一覧.json
"""
import json
import sys
from pathlib import Path

OUT = Path(__file__).resolve().parent
PROMPT = (OUT / "grokプロンプト_v3_0.txt").read_text(encoding="utf-8")
jobs = {}
for wave in (1, 2, 3):
    for row in json.loads((OUT / f"grok_b2_wave_{wave}.json").read_text(encoding="utf-8")):
        jobs[row["id"]] = row

SHORT = [
    "p1.h_finish_outside.start.familiar.side_lying.s",
    "p1.h_move_normal.start.few.leg_up.s",
    "p1.h_move_slow.continue.familiar.leg_up.s",
    "p2.h_finger_in.continue.familiar.s",
    "p3.chest_touch.start.after_h.n",
    "p3.deep_kiss.settled.after_h.n",
    "p3.ear_kiss.settled.before_h.n",
    "p3.thigh_touch.continue.after_h.n",
    "p3.thigh_touch.settled.after_h.n",
    "p3.thigh_touch.settled.before_h.n",
    "p3.under_clothes.continue.after_h.n",
    "p3.under_clothes.settled.before_h.n",
]
new_path = OUT / "grok_b2_wave_4.json"
NEW = json.loads(new_path.read_text(encoding="utf-8")) if new_path.exists() else []

rows = []
for job_id in SHORT:
    row = dict(jobs[job_id])
    row["candidates"] = 4
    rows.append(row)
rows += NEW

folder = OUT / "grok依頼_B2_補充"
folder.mkdir(exist_ok=True)
for old in folder.glob("*.txt"):
    old.unlink()
BATCH = 13
number = 0
for speech, label in ((True, "台詞あり"), (False, "台詞なし")):
    part = [r for r in rows if r["speech"] == speech]
    if not part:
        continue
    count = -(-len(part) // BATCH)
    size = -(-len(part) // count)
    for index in range(0, len(part), size):
        chunk = part[index:index + size]
        total = sum(r["candidates"] for r in chunk)
        number += 1
        lines = [json.dumps({"id": r["id"], "meaning": r["meaning"], "speech": r["speech"], "length": r["length"], "origin": r["origin"], "本数": r["candidates"],
                             **({"must_not": r["must_not"]} if r.get("must_not") else {}), "state": r["state"]}, ensure_ascii=False) for r in chunk]
        body = ("指示\n"
                f"次の{len(chunk)}件の job を書いてください（段階Bの2版目・補充・{label}）。本数は各 job の「本数」のとおりです（合わせて{total}本）。"
                "途中で切れそうなら、job の区切りで止めてください。「続けて」と言われたら、止めた job の次から出してください。\n\n[\n  " + ",\n  ".join(lines) + "\n]\n\n"
                "プロンプト\n" + PROMPT)
        (folder / f"B2_補充_{number:02d}.txt").write_text(body, encoding="utf-8")
(OUT / "補充_一覧.json").write_text(json.dumps({"short": SHORT, "new": [r["id"] for r in NEW],
                                              "files": sorted(p.name for p in folder.glob("*.txt"))}, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
print(len(rows), "jobs", sum(r["candidates"] for r in rows), "texts", sorted(p.name for p in folder.glob("*.txt")))
