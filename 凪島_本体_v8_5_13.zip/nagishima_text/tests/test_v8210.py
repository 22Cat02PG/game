"""v8.2.10（ユーザー了承 2026-09-28 10:43・10:45）：顔面騎乗（face_sit）・シックスナイン（sixty_nine）と、その間の移行。
顔面騎乗で舐めているあいだに、真帆が自分から体を倒してシックスナインへ移る申し出。公開の選択肢から確かめる（高まりなどの準備だけ内部で行う）。"""
import unittest

from tools.run_stage_b_routes import Route


def choices(engine):
    return {c["id"]: c for c in engine.get_view()["choices"]}


def meanings(engine):
    return [b["meaning"] for b in engine.get_view()["blocks"]]


def variants(engine):
    return [b["variant"] for b in engine.get_view()["blocks"]]


def explain(engine, identity):
    return engine.get_view()["explanations"].get(identity)


def authored(variant, meaning):
    """Opus か grok（第9陣・第10陣）の本文か（v8.2.11：grok の本文が入って、どちらが選ばれるかは乱数しだい）。"""
    return ("." + meaning + ".") in ("." + variant) and not variant.endswith(".base")


class V8210(unittest.TestCase):
    def route(self, *args, **kwargs):
        route = Route(*args, **kwargs)
        self.addCleanup(route.close)
        return route

    def ready(self, seed, tier, arousal=50, band="mid", **kwargs):
        route = self.route(seed, tier=tier, day_offset=2, **kwargs)
        route.begin()
        for key in ("h_strip_lower", "h_shift_under", "h_strip_self", "h_pos_lying_face"):
            route.action(key)
        route.engine._state["intimacy"]["maho"].update(arousal=arousal, band=band)  # 準備：真帆の高まり
        route.engine._install_choices()
        return route

    def facing(self, route):
        return route.engine.pack.registry.values(route.engine.snapshot())["intimacy.facing"]

    def set_experience(self, route, key, count):
        """準備：これまでにした回数。日時と開始者別の集計も合わせる。"""
        now = route.engine.snapshot()["world"]["now"]
        route.engine._state["experience"][key] = {"count": count, "first_at": now - 2880, "last_at": now - 1440, "by_origin": {"player": count, "maho": 0}}
        route.engine._install_choices()

    def contacts(self, route):
        return [c["action_id"] for c in route.engine.snapshot()["contacts"]]

    def decline_leads(self, route):
        offer = route.engine.snapshot()["offer"]
        if offer and offer["kind"] in ("h_lead_straddle", "h_lead_takein"):
            route.choose("offer.decline")

    def test_face_sit_first_time_and_licking(self):
        first = self.ready(401, "first")
        first.choose("menu.main")
        first.choose("menu.h_position")
        self.assertNotIn("touch.h_pos_face_sit", choices(first.engine))  # v8.2.19：回数で開く行為は、開くまで一覧に出さない
        route = self.ready(402, "few")
        route.action("h_pos_face_sit")
        self.assertEqual(meanings(route.engine)[0], "h_pos_face_sit.first")
        self.assertTrue(authored(variants(route.engine)[0], "h_pos_face_sit.first"), variants(route.engine))
        self.assertEqual(self.facing(route), "face_sit")
        route.action("h_face_lick")
        self.assertEqual(meanings(route.engine)[0], "h_face_lick.first")  # 初めて下から舐められる戸惑い（読み手の指摘 A-8）
        self.assertTrue(authored(variants(route.engine)[0], "h_face_lick.first"), variants(route.engine))
        again = self.ready(403, "familiar")
        self.set_experience(again, "h_face_lick", 2)
        again.action("h_pos_face_sit")
        again.action("h_face_lick")
        self.assertTrue(authored(variants(again.engine)[0], "h_face_lick.start"), variants(again.engine))
        seen = []
        for _ in range(8):
            self.decline_leads(route)
            if route.engine.snapshot()["offer"]:
                route.choose("offer.decline")
            route.action("h_face_lick")
            seen += meanings(route.engine)
            if route.engine.snapshot()["intimacy"]["maho"]["climaxes"]:
                break
        state = route.engine.snapshot()["intimacy"]
        self.assertEqual((state["maho"]["climaxes"], state["maho"]["climax_source"]), (1, "mouth"))
        self.assertIn("h.climax.maho.face_sit", seen)  # 顔の上で達する本文
        signs = [m for m in seen if m.startswith("h.sign.") and m.split(".")[2] in ("mid", "high", "near")]
        self.assertTrue(signs)
        self.assertTrue(all(m.endswith(".face_sit") for m in signs), signs)

    def test_sixty_nine_to_finish_in_her_mouth(self):
        route = self.ready(411, "few")
        route.action("h_pos_face_sit")
        route.action("h_pos_sixty_nine")
        self.assertEqual(meanings(route.engine)[0], "h_pos_sixty_nine.first")
        self.assertEqual(self.facing(route), "sixty_nine")
        route.choose("menu.main")
        route.choose("menu.h_service")
        self.assertEqual(choices(route.engine)["touch.h_sixty_nine"]["label"], "舐め合う")
        route.choose("touch.h_sixty_nine")
        self.assertEqual(meanings(route.engine)[0], "h_sixty_nine.first")
        before = route.engine.snapshot()["intimacy"]
        route.action("h_sixty_nine")
        after = route.engine.snapshot()["intimacy"]
        self.assertGreater(after["player"]["arousal"], before["player"]["arousal"])
        route.engine._state["intimacy"]["player"]["arousal"] = 80  # 準備：出せるところまで
        route.engine._install_choices()
        route.action("h_finish_sixty_nine")
        state = route.engine.snapshot()["intimacy"]
        self.assertEqual((state["player"]["finishes"], state["mess"]), (1, "mouth"))
        self.assertTrue(authored(variants(route.engine)[0], "h_finish_sixty_nine.start"), variants(route.engine))

    def test_sixty_nine_limit_overflow_and_endure(self):
        route = self.ready(421, "familiar")
        route.action("h_pos_sixty_nine")
        route.action("h_sixty_nine")
        route.engine._state["intimacy"]["player"]["arousal"] = 100  # 準備：限界
        route.engine._install_choices()
        if route.engine.get_view()["page"] != "main":
            route.choose("menu.main")
        self.assertEqual(choices(route.engine)["end.h_sixty_nine"]["label"], "口を離してもらう（こらえる）")
        route.choose("end.h_sixty_nine")
        self.assertEqual(meanings(route.engine)[0], "h_endure.sixty_nine")
        other = self.ready(422, "familiar")
        other.action("h_pos_sixty_nine")
        other.action("h_sixty_nine")
        other.engine._state["intimacy"]["player"]["arousal"] = 100
        other.engine._install_choices()
        other.action("h_sixty_nine")
        self.assertEqual(meanings(other.engine)[0], "h_overflow.sixty_nine")
        self.assertEqual(other.engine.snapshot()["intimacy"]["mess"], "mouth")

    def test_maho_turns_around_herself(self):
        accepted = declined = False
        for seed in range(431, 491):  # v8.2.30：申し出るかは回ごとに決まる（数回 25%）ので、多めの seed で確かめる
            route = self.ready(seed, "few")
            self.set_experience(route, "h_sixty_nine", 1)  # 準備：前に舐め合ったことがある
            route.action("h_pos_face_sit")
            route.action("h_face_lick")
            route.engine._state["intimacy"]["player"]["arousal"] = 40  # 準備：こちらも張りつめてきた
            route.engine._install_choices()
            for _ in range(4):
                offer = route.engine.snapshot()["offer"]
                if offer and offer["kind"] == "h_lead_sixty_nine":
                    break
                if offer:
                    route.choose("offer.decline")
                route.action("h_face_lick")
            offer = route.engine.snapshot()["offer"]
            if not offer or offer["kind"] != "h_lead_sixty_nine":
                continue
            self.assertIn("offer.h_lead.sixty_nine", meanings(route.engine))
            if not accepted:
                route.choose("offer.accept")
                state = route.engine.snapshot()
                self.assertEqual(state["intimacy"]["position"], "sixty_nine")
                self.assertIn("h_sixty_nine", [c["action_id"] for c in state["contacts"]])  # 舐め合うのが始まっている
                self.assertEqual(meanings(route.engine)[0], "h_lead_sixty_nine.start")
                if route.engine.get_view()["page"] != "main":
                    route.choose("menu.main")
                self.assertEqual(choices(route.engine)["touch.h_sixty_nine"]["label"], "舐め合い続ける")
                accepted = True
            elif not declined:
                route.choose("offer.decline")
                self.assertEqual(meanings(route.engine)[0], "offer.h_lead.sixty_nine_declined")
                self.assertEqual(route.engine.snapshot()["intimacy"]["position"], "face_sit")
                declined = True
            if accepted and declined:
                break
        self.assertTrue(accepted and declined)

    def test_maho_does_not_offer_before_first_sixty_nine(self):
        # 舐め合ったことがなければ、真帆は自分から向きを変える申し出をしない（初めては戸惑う。読み手の指摘 C-3）
        for seed in range(431, 451):
            route = self.ready(seed, "few")
            route.action("h_pos_face_sit")
            route.action("h_face_lick")
            route.engine._state["intimacy"]["player"]["arousal"] = 40
            route.engine._install_choices()
            for _ in range(4):
                offer = route.engine.snapshot()["offer"]
                self.assertFalse(offer and offer["kind"] == "h_lead_sixty_nine", seed)
                if offer:
                    route.choose("offer.decline")
                route.action("h_face_lick")
            self.assertNotIn("h_lead_sixty_nine", route.engine.snapshot()["intimacy"]["leads"])

    def test_face_words_still_shown_during_breasts(self):
        # 顔の語のある胸の本文は、胸でしてもらう最中（向き maho_breasts）にも出る（v8.2.10 の遊び回りで、慣れの「胸で続けてもらう」が仮の本文に落ちた）
        route = self.route(471, tier="familiar", day_offset=2)
        route.begin()
        for key in ("h_strip_lower", "h_shift_under", "h_strip_self", "h_strip_upper", "h_pos_lying_face"):
            route.action(key)
        self.set_experience(route, "h_maho_breasts", 2)
        route.action("h_maho_breasts")
        self.assertEqual(self.facing(route), "maho_breasts")
        seen = []
        for _ in range(4):
            offer = route.engine.snapshot()["offer"]
            if offer:
                route.choose("offer.decline")
            route.action("h_maho_breasts")
            seen += [v for v in variants(route.engine) if ".h_maho_breasts" in v or v.startswith("h_maho_breasts")]
        self.assertTrue(seen)
        self.assertFalse([v for v in seen if v.endswith(".base")], seen)  # 仮の本文に落ちない

    def test_deadline_from_behind_on_workday_eve(self):
        # 後ろからの体位で、仕事の前の夜に締め切りが来ても、仮の本文に落ちない（遊び回りで見つかった以前からの抜け）
        pack = self.route(481, tier="few", day_offset=2).engine.pack
        values = {"intimacy.tier": "few", "night.kind": "workday_eve", "intimacy.facing": "back"}
        self.assertTrue([t["id"] for t in pack.by_meaning["h.deadline"] if not t["fallback"] and t["id"].startswith("o24.")])
        from nagishima.conditions import evaluate
        usable = [t["id"] for t in pack.by_meaning["h.deadline"] if not t["fallback"]
                  and all(evaluate(c, values) is True for c in t["when"]["all"] if c.get("field") in values)
                  and all(c.get("field") in values for c in t["when"]["all"])]
        self.assertTrue(usable)

    def test_limit_does_not_move_to_face_sit(self):
        route = self.ready(461, "few")
        for _ in range(20):
            route.action("h_maho_hand")
            if route.engine.snapshot()["intimacy"]["player"]["arousal"] >= 100:
                break
        route.choose("menu.main") if route.engine.get_view()["page"] != "main" else None
        route.choose("menu.h_position")
        self.assertFalse(choices(route.engine)["touch.h_pos_face_sit"]["available"])
        self.assertTrue(explain(route.engine, "touch.h_pos_face_sit").startswith("もう限界だ。"))
        self.assertTrue(choices(route.engine)["touch.h_pos_player_above"]["available"])


if __name__ == "__main__":
    unittest.main()
