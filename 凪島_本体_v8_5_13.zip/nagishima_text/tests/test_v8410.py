"""v8.4.10（ユーザー 2026-10-07 06:23「進めて」）：010 だけ。
体位を移る本文のうち、真帆の気持ちがゆるむ本文（「ほっとしたように」「安心する」「落ち着く」）は、せがんだ直後（flow.prev.begging）には出さない。
立って後ろから→ベッドの本文は、せがんだ直後の本文を足した。「せがんだ直後には出さない」条件は受ける本文に数えない。"""
import unittest
from copy import deepcopy
from pathlib import Path

from nagishima.content import Pack
from tools.run_stage_b_routes import Route

ROOT = Path(__file__).resolve().parents[1]
P009 = Pack(ROOT / "content/releases/interaction_009")
P010 = Pack(ROOT / "content/releases/interaction_010")
NOT_BEGGING = {"field": "flow.prev.begging", "op": "eq", "value": False}
STAND = ("v843.h_pos_side_lying.start.stand.s.v1", "v843.h_pos_sitting_close.start.stand.s.v1")


def act(route, key):
    while route.engine.snapshot()["offer"]:
        route.choose("offer.decline")
    route.action(key)


class V8410(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        route = Route(8461, tier="familiar", release="interaction_010", hour=21, day_offset=2)
        try:
            route.begin()
            act(route, "h_kiss_deep")
            cls.state = route.engine.snapshot()
        finally:
            route.close()
        cls.urge = next(t for t in P010.by_meaning["h.sign.wants_more"] if "もっと" in t["body"] and not t["fallback"])
        cls.calm = next(t for t in P010.by_meaning["h_kiss_deep.continue_short"] if not t["fallback"])

    def moved_from_standing(self, prev):
        state = deepcopy(self.state)
        state["contacts"] = []
        state["recent_text"] = state["recent_text"][-5:] + [{"id": prev["id"], "group": prev["group"], "release": "interaction_010"}]
        state["intimacy"]["position"] = state["intimacy"]["position_from"] = "standing_back"
        return state

    def pick(self, meaning, state):
        state = deepcopy(state)  # select は出した本文を最近の本文に足す
        return P010.select(meaning, state, {}, P010.registry.values(state))[0]["variant"]

    def test_009_unchanged(self):
        self.assertFalse(any(t["id"].startswith("v8410.") for t in P009.by_text.values()))
        self.assertFalse(any(NOT_BEGGING in t["when"].get("all", []) for t in P009.by_text.values()))

    def test_calm_moves_not_after_begging(self):
        # v8.4.12 から、部品を組み合わせた本文（cmp.）の反応にも「せがんだ直後には出さない」が付く。ここでは v8.4.10 で条件を付けた本文だけを数える
        # v8.4.17 の短い一行（v8417.、手をつないでいるあいだ）にも付くので、それも除く
        calm = [t for t in P010.by_text.values() if NOT_BEGGING in t["when"].get("all", []) and not t["id"].startswith(("cmp.", "v8417."))]
        self.assertEqual(len(calm), 16)
        self.assertTrue(all(t["meaning"].startswith(("h_pos_", "h_limit_move")) for t in calm))
        self.assertIn("v843.h_pos_player_above.start.bed.s.v1", {t["id"] for t in calm})
        for identity in STAND:
            self.assertIn(NOT_BEGGING, P010.by_text[identity]["when"]["all"])

    def test_receiver_counts_only_positive_conditions(self):
        flow = P010.intimacy.flow
        self.assertFalse(flow.receiver(P010.by_text[STAND[0]]))
        self.assertTrue(flow.receiver(P010.by_text["v8410.h_pos_side_lying.start.stand.begging.n.v1"]))
        self.assertTrue(all(flow.receiver(t) for t in P010.by_text.values() if t["id"].startswith("v846.")))

    def test_after_begging_from_standing(self):
        state = self.moved_from_standing(self.urge)
        self.assertTrue(self.pick("h_pos_side_lying.start", state).startswith("v8410.h_pos_side_lying.start.stand.begging."))
        self.assertTrue(self.pick("h_pos_sitting_close.start", state).startswith("v8410.h_pos_sitting_close.start.stand.begging."))
        state = self.moved_from_standing(self.calm)
        self.assertFalse(self.pick("h_pos_sitting_close.start", state).startswith("v8410."))


if __name__ == "__main__":
    unittest.main()
