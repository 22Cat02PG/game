"""Run bounded automatic play samples and summarize conversational variety.

This is a small inspection tool for the text prototype.  It deliberately uses
the same Session dispatcher and autoplay policy as the normal automation path;
it only collects observations and never changes game rules.
"""

from __future__ import annotations

import argparse
import json
import sys
from collections import Counter
from pathlib import Path
from tempfile import TemporaryDirectory

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from nagishima.autoplay import next_command, next_social_command, next_presence_command
from nagishima.engine import Engine
from nagishima.session import Session
from nagishima.progression import life_day


def run(seed: int, release: str, max_commands: int, policy, data_dir: Path) -> dict:
    engine = Engine(data_dir, seed=seed, release=release, autosave=False)
    start_day = life_day(engine.snapshot()["world"]["now"])
    session = Session(engine, max_commands)
    bodies: list[str] = []
    command_ids: list[str] = []
    for _ in range(max_commands):
        observed = session.observe()
        view = observed["view"]
        state = observed["state"]
        if observed["run"]["ended"]:
            break
        if observed["run"]["cleared"]:
            session.finish("cleared")
            break
        command = policy(view, state)
        if command is None:
            session.finish("policy_stalled")
            break
        command_ids.append(command.get("id", command["command"]))
        before_text_rng = state["world"]["rng"]["text"]
        response = session.execute(command)
        if response.get("ok"):
            new_blocks = response["state"]["world"]["rng"]["text"] - before_text_rng
            bodies.extend(block["body"] for block in response["view"]["blocks"][:new_blocks])
    final = session.observe()
    return {
        "seed": seed,
        "commands": len(command_ids),
        "terminal": final["run"],
        "stage": final["state"]["relation"]["stage"],
        "life_days": life_day(final["state"]["world"]["now"]) - start_day,
        "intimacy_count": final["state"].get("intimacy_history", {}).get("count", 0),
        "intimacy_last_result": final["state"].get("intimacy_history", {}).get("last_result"),
        "texts": len(bodies),
        "unique_texts": len(set(bodies)),
        "duplicate_texts": len(bodies) - len(set(bodies)),
        "top_repeats": Counter(bodies).most_common(5),
        "command_ids": command_ids,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--release", default="interaction_005")
    parser.add_argument("--seeds", type=int, default=20)
    parser.add_argument("--max-commands", type=int, default=200)
    parser.add_argument("--policy", choices=("reference", "social", "presence"), default="social")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    policy = next_presence_command if args.policy == "presence" else next_social_command if args.policy == "social" else next_command
    with TemporaryDirectory(prefix="nagishima-immersion-") as temporary:
        base = Path(temporary)
        samples = [run(seed, args.release, args.max_commands, policy, base / str(seed)) for seed in range(args.seeds)]
    report = {
        "release": args.release,
        "seeds": args.seeds,
        "max_commands": args.max_commands,
        "policy": args.policy,
        "completed": sum(sample["terminal"]["reason"] in ("completed", "cleared") for sample in samples),
        "samples": samples,
    }
    payload = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(payload, encoding="utf-8")
    print(payload, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
