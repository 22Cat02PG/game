"""State defaults and cross-field invariants for releases with intimacy.json."""
from copy import deepcopy
import re

from .codec import exact
from .errors import GameError, ensure


def install_schema(schema):
    # Keep the 003--008 state layout untouched. These are optional at the
    # generic schema layer and required only for an intimacy-enabled pack.
    for key in ("stamina", "intimacy_history", "settings", "bath", "text_seen", "sleep_record", "event_record"):
        schema["properties"][key] = {"type": "object"}
    schema["properties"]["intimacy"] = {"anyOf": [{"type": "object"}, {"type": "null"}]}
    schema["properties"]["sleep_play"] = {"anyOf": [{"type": "object"}, {"type": "null"}]}  # 段階C（010、v8.5.0）：寝込みの最中
    schema["properties"]["event_play"] = {"anyOf": [{"type": "object"}, {"type": "null"}]}  # 段階C（010、v8.5.1）：イベントのエッチの最中
    schema["properties"]["drink_night"] = {"type": "object"}  # 段階C（010、v8.5.3）：お酒を飲んだ夜（晩酌でほろ酔い以上）
    schema["properties"]["co_sleep"] = {"anyOf": [{"type": "object"}, {"type": "null"}]}  # 段階C（010、v8.5.6）：添い寝の間
    schema["properties"]["nap"] = {"anyOf": [{"type": "object"}, {"type": "null"}]}  # 段階C（010、v8.5.7）：うたた寝から目を覚ました時刻と反応
    schema["properties"]["event_morning"] = {"anyOf": [{"type": "object"}, {"type": "null"}]}  # 段階C（010、v8.5.9）：イベントの翌朝の一言
    schema["properties"]["ask"] = {"type": "object"}  # 段階C（010、v8.5.10）：頼むの記録（その日の回数・最後に頼んだ時刻・見せた回数）
    schema["properties"]["ask_play"] = {"anyOf": [{"type": "object"}, {"type": "null"}]}  # 段階C（010、v8.5.10）：してもらっている間
    schema["properties"]["fish"] = {"type": "object"}
    schema["properties"]["town"] = {"type": "object"}  # 段階C（010、v8.5.11）：二人で島の町の店に来た回数  # 段階C（010、v8.5.11）：釣りの記録（真帆の手帳の図鑑・その日の釣果）
    schema["$defs"]["actor"]["properties"]["clothing"] = {"type": "object"}


def add_neutral(state, pack):
    rules = pack.intimacy
    if not rules:
        return state
    stamina = rules.raw["player"]["stamina_max"]
    state["stamina"] = {"value": stamina}
    state["intimacy_history"] = {"count": 0, "first_at": None, "last_at": None, "last_result": None,
                                 "by_entry": {"private": 0, "invite": 0, "wake": 0}, "declined_at": None, "slept_together": False,
                                 "lewdness": 0, "maho_climaxes": 0, "finishes": 0}  # v8.2.12：淫乱度と、二人の記録の数
    config = rules.settings
    default = config["default"]
    state["settings"] = {"terms": deepcopy(config["term_presets"][default["term_preset"]]),
                         "density": default["density"], "speech": default["speech"], "gauges": default["gauges"]}
    for actor in ("player", "maho"):
        state["actors"][actor]["clothing"] = {"upper": "worn", "lower": "worn"}
    state["intimacy"] = None
    if pack.life and pack.life.bath:
        state["bath"] = neutral_bath()
    return state


def neutral_bath():
    """009（v8.2.0）：風呂。day＝入った生活日、after_until＝湯上がりの終わり、together＝その入浴が一緒だったか、invited_day＝誘った生活日。"""
    return {"day": None, "after_until": None, "together": False, "together_count": 0, "invited_day": None}


TEXT_KEY = re.compile(r"^[0-9a-f]{10}$")


def validate_text_seen(state, rules):
    """v8.4.11（010）：本文ごとに最後に出た番号（text_seen.last：本文の鍵 → 選んだ回数の通し番号）。設定 text_memory のある版だけ持つ。"""
    if "text_seen" not in state:
        return
    ensure(rules.text_memory is not None, "state_fields", "この版は本文の記録（text_seen）を持たない。")
    seen = state["text_seen"]
    exact(seen, ["last"])
    serial = state["world"]["rng"]["text"]
    last = seen["last"]
    ensure(type(last) is dict and len(last) <= 4 * rules.text_memory["horizon"], "text_seen", "本文の記録の数が不正。")
    ensure(all(TEXT_KEY.match(key) and type(value) is int and 0 <= value < serial for key, value in last.items()), "text_seen", "本文の記録が不正。")


def validate(state, pack):
    rules = pack.intimacy
    if rules is None:
        # intimacy.json のない版（003〜008）の状態は v7.1.2 と同じ形。段階Bの項目は持たない（v8.0.5、監査 A-07）。
        for key in ("stamina", "intimacy_history", "settings", "intimacy", "bath", "text_seen", "sleep_play", "sleep_record", "event_play", "event_record", "drink_night", "co_sleep", "nap", "event_morning", "ask", "ask_play", "fish", "town"):
            ensure(key not in state, "state_fields", "state に未登録の項目 " + key)
        for actor in state["actors"].values():
            ensure("clothing" not in actor, "state_fields", "actor に未登録の項目 clothing")
        return
    now = state["world"]["now"]
    maximum = rules.raw["player"]["stamina_max"]
    validate_bath(state, pack)
    for key in ("stamina", "intimacy_history", "settings", "intimacy"):
        ensure(key in state, "state_fields", "段階Bの保存状態が不足。")
    stamina = state["stamina"]
    exact(stamina, ["value"])
    ensure(type(stamina["value"]) is int and 0 <= stamina["value"] <= maximum, "stamina", "余力が範囲外。")
    hist = state["intimacy_history"]
    exact(hist, ["count", "first_at", "last_at", "last_result", "by_entry", "declined_at", "slept_together", "lewdness", "maho_climaxes", "finishes"])
    ensure(type(hist["slept_together"]) is bool and (not hist["slept_together"] or hist["count"] > 0), "intimacy_history", "一緒に眠った記録が不正。")
    exact(hist["by_entry"], ["private", "invite", "wake"], ["event"] if rules.events else [])  # 段階C（010、v8.5.1）：イベントのエッチの回数（終えた回からだけ持つ）
    ensure(all(type(n) is int and n >= 0 for n in hist["by_entry"].values()), "intimacy_history", "始まり方の回数が不正。")
    ensure(type(hist["count"]) is int and hist["count"] == sum(hist["by_entry"].values()), "intimacy_history", "エッチの回数が合わない。")
    lewd_max = rules.lewd["max"] if rules.lewd else 0
    ensure(all(type(hist[key]) is int and hist[key] >= 0 for key in ("lewdness", "maho_climaxes", "finishes")) and hist["lewdness"] <= lewd_max, "intimacy_history", "淫乱度・記録の数が不正。")
    ensure(hist["count"] > 0 or hist["lewdness"] == hist["maho_climaxes"] == hist["finishes"] == 0, "intimacy_history", "未経験に淫乱度・記録の数がある。")
    if hist["count"] == 0:
        ensure(hist["first_at"] is hist["last_at"] is hist["last_result"] is None, "intimacy_history", "未経験に日時がある。")
    else:
        ensure(type(hist["first_at"]) is int and type(hist["last_at"]) is int and hist["first_at"] <= hist["last_at"] <= now and hist["last_result"] in ("satisfied", "unsatisfied"), "intimacy_history", "経験の日時・結果が不正。")
    ensure(hist["declined_at"] is None or type(hist["declined_at"]) is int and hist["declined_at"] <= now, "intimacy_history", "断られた日時が不正。")
    settings = state["settings"]
    exact(settings, ["terms", "density", "speech", "gauges"], ["continue_text", "auto_speed"])  # v8.2.20：続けるときの本文（ない保存は既定＝短い）。v8.2.28：自動で続ける速さ（ない保存は既定＝ふつう）
    ensure("continue_text" not in settings or rules.short and settings["continue_text"] in rules.short["choices"], "settings", "続けるときの本文の設定が未登録。")
    ensure("auto_speed" not in settings or rules.auto and "speeds" in rules.auto and settings["auto_speed"] in rules.auto["choices"], "settings", "自動で続ける速さの設定が未登録。")
    exact(settings["terms"], rules.settings["terms"])
    ensure(all(value in rules.settings["terms"][key] for key, value in settings["terms"].items()), "settings", "差し込みの設定が未登録。")
    ensure(settings["density"] in rules.settings["density"] and settings["speech"] in rules.settings["speech_offset"] and settings["gauges"] in rules.settings["gauges"], "settings", "表示設定が未登録。")
    validate_text_seen(state, rules)
    for actor in ("player", "maho"):
        clothing = state["actors"][actor].get("clothing")
        ensure(type(clothing) is dict, "clothing", "服の状態が不足。")
        exact(clothing, ["upper", "lower"])
        for layer in ("upper", "lower"):
            ensure(clothing[layer] in rules.raw["clothing"][actor][layer], "clothing", "服の状態が未登録。")
    validate_sleep(state, pack)
    validate_event(state, pack)
    validate_co_sleep(state, pack)  # v8.5.6
    validate_nap(state, pack)  # v8.5.7
    validate_ask(state, pack)  # v8.5.10
    validate_fish(state, pack)  # v8.5.11
    town = pack.life.town if pack.life else None
    record = state.get("town")
    if record is not None:
        # v8.5.11：二人で店に来た回数（visits：店 → 回数）
        ensure(town is not None and type(record) is dict and set(record) == {"visits"} and type(record["visits"]) is dict and set(record["visits"]) <= set(town["places"])
               and all(type(v) is int and v >= 1 for v in record["visits"].values()), "town", "島の町の記録が不正。")
    intimate = state["intimacy"]
    if intimate is None:
        ensure(all(state["actors"][actor]["clothing"][layer] == "worn" for actor in ("player", "maho") for layer in ("upper", "lower")), "clothing", "エッチの外で服の状態が残っている。")
        ensure(not any(c["action_id"] in rules.actions for c in state["contacts"]), "contact", "エッチの接触が外に残っている。")
        return
    ensure(type(intimate) is dict, "intimacy", "エッチの状態が不正。")
    exact(intimate, ["id", "entry", "origin", "started_at", "position", "inserted", "after", "maho", "player", "hold_back_used", "leads", "wrap_up", "deflected", "satisfaction_uses", "help_offered", "mess", "begged", "extras", "offered", "paces", "pace_focus", "stroked_back"], ["sides", "move_before", "position_from", "calm", "finish_outcome", "afterglow"])  # v8.2.29：胸に触れる左右（選んだときだけ持つ）
    ensure(type(intimate["id"]) is str and intimate["id"].startswith("intimacy.") and intimate["entry"] in ("private", "invite", "wake") and intimate["origin"] in ("player", "maho"), "intimacy", "始まり方が不正。")
    ensure(type(intimate["started_at"]) is int and intimate["started_at"] <= now and state["mode"] == "private" and state["private_instance"] is not None and state["maho_sleep"]["state"] == "awake" and state["relation"]["stage"] >= 3, "intimacy", "エッチの場所・時刻が不正。")
    ensure(state["actors"]["player"]["location"] == state["actors"]["maho"]["location"] and state["actors"]["player"]["location"] in rules.raw["session"]["locations"], "intimacy", "二人が同じ部屋にいない。")
    ensure(state["offer"] is None or state["offer"]["kind"] in ("hold_back", "h_lead_straddle", "h_lead_takein", "h_lead_sixty_nine", "h_help_hand", "h_help_mouth", "h_help_breasts", "h_help_feet"), "intimacy", "別の誘いが開いている。")
    ensure(intimate["position"] in rules.positions and type(intimate["inserted"]) is bool and type(intimate["after"]) is bool, "intimacy", "体位・挿入が不正。")
    pose = rules.positions[intimate["position"]]
    ensure(all(state["actors"][actor]["posture"] == pose["postures"][actor] for actor in ("player", "maho")), "intimacy", "体位と姿勢が違う。")
    if intimate["inserted"]:
        ensure(pose["insertion"] and state["actors"]["maho"]["clothing"]["lower"] in ("aside", "off") and state["actors"]["player"]["clothing"]["lower"] == "off", "intimacy", "挿入中の体位・服が不正。")
    for actor, keys in (("maho", ["arousal", "satisfaction", "climaxes", "band", "climax_source", "sensitive"]), ("player", ["arousal", "finishes", "endured", "refractory"])):
        exact(intimate[actor], keys)
    m, p = intimate["maho"], intimate["player"]
    ensure(all(type(m[key]) is int and 0 <= m[key] <= 100 for key in ("arousal", "satisfaction")) and type(m["climaxes"]) is int and m["climaxes"] >= 0 and m["band"] in ("low", "mid", "high", "near"), "intimacy", "真帆の高まり・満足が不正。")
    ensure(type(p["arousal"]) is int and 0 <= p["arousal"] <= rules.raw["player"]["arousal_max"] and type(p["finishes"]) is int and 0 <= p["finishes"] <= maximum - stamina["value"], "intimacy", "主人公の高まり・回数が不正。")
    ensure(type(p["endured"]) is int and 0 <= p["endured"] <= rules.raw["player"]["endure"]["per_peak"] and type(p["refractory"]) is int and 0 <= p["refractory"] <= rules.raw["player"]["refractory_actions"] * max(1, maximum), "intimacy", "こらえる・不応期が不正。")  # v8.2.34：果てた回数ごとに長くなる
    ensure(type(intimate["hold_back_used"]) is bool and type(intimate["help_offered"]) is bool and type(intimate["begged"]) is bool and type(intimate["stroked_back"]) is bool, "intimacy", "問いの記録が不正。")
    extras, offered = intimate["extras"], intimate["offered"]
    ensure(type(extras) is list and len(set(extras)) == len(extras) and set(extras) <= {"lick", "balls"}, "intimacy", "追加の記録が不正。")
    ensure(type(offered) is list and len(set(offered)) == len(offered) and set(offered) <= {"h_help_breasts", "h_help_feet", "h_extra_lick", "h_extra_balls"}, "intimacy", "真帆の申し出の記録が不正。")
    # v8.2.13：続けている行為の速さ（速さを変えられる行為だけ。最後にした行為）
    pace_actions = rules.pace["actions"] if rules.pace else {}
    active = {c["action_id"] for c in state["contacts"]}
    ensure(type(intimate["paces"]) is dict and all(key in pace_actions and key in active and value in ("slow", "normal", "fast") for key, value in intimate["paces"].items()), "intimacy", "速さの記録が不正。")
    ensure(intimate["pace_focus"] is None or intimate["pace_focus"] in pace_actions and intimate["pace_focus"] in active, "intimacy", "速さを変える行為が不正。")
    ensure(intimate.get("move_before", "none") in ("none", "slow", "normal", "fast"), "intimacy", "動く速さの記録が不正。")  # v8.4.2（010）
    ensure("position_from" not in intimate or intimate["position_from"] in rules.positions, "intimacy", "移る前の体位の記録が不正。")  # v8.4.3（010）
    ensure("calm" not in intimate or (type(intimate["calm"]) is int and 0 <= intimate["calm"] <= 10), "intimacy", "刺激のない手の数が不正。")  # v8.4.5（010）
    ensure(intimate.get("finish_outcome", "rest") in ("climax", "near", "high", "rest"), "intimacy", "中に出す手の結果が不正。")  # v8.4.7（010）
    ensure("afterglow" not in intimate or (type(intimate["afterglow"]) is int and 0 <= intimate["afterglow"] <= 10), "intimacy", "余韻の手数が不正。")  # v8.4.8（010）
    sides = intimate.get("sides", {})
    ensure(type(sides) is dict and all(key in rules.sides and key in active and value in rules.sides[key] for key, value in sides.items()), "intimacy", "胸に触れる左右の記録が不正。")
    leads = intimate["leads"]
    ensure(type(leads) is list and len(set(leads)) == len(leads) <= rules.raw["lead"]["per_session"] and set(leads) <= set(rules.raw["lead"]["actions"]), "intimacy", "真帆の申し出の記録が不正。")
    # v8.2.3：最後に出した場所（出したあとだけ）と、真帆が達した直後か
    ensure(intimate["mess"] in (None, "inside", "outside", "hand", "mouth") and (intimate["mess"] is None or p["finishes"] > 0), "intimacy", "出した場所の記録が不正。")
    ensure(type(m["sensitive"]) is bool and (not m["sensitive"] or m["climaxes"] > 0), "intimacy", "達した直後の記録が不正。")
    ensure(m["climax_source"] in (None, "inserted", "finger", "mouth") and (m["climax_source"] is None) == (m["climaxes"] == 0), "intimacy", "真帆が達したときの行動が不正。")
    wrap = intimate["wrap_up"]
    # v8.2.29：もうすぐ達しそうなときは延ばす（deadline_close）。昼は仕事の始まりも締め切り
    grace = max(rules.raw["nights"]["grace_actions"], rules.deadline_close["grace_actions"] if rules.deadline_close else 0)
    ensure(wrap is None or type(wrap) is int and 0 <= wrap <= grace and (now >= rules.deadline(now, pack.life) or rules.deadline_close is not None and _in_work_block(now, pack)), "intimacy", "締め切りの記録が不正。")
    ensure(type(intimate["deflected"]) is list and len(set(intimate["deflected"])) == len(intimate["deflected"]) and set(intimate["deflected"]) <= rules.actions.keys(), "intimacy", "止めた行動が不正。")
    uses = intimate["satisfaction_uses"]
    ensure(type(uses) is dict and set(uses) <= rules.actions.keys() and all(type(n) is int and 0 <= n <= rules.actions[key]["effects"]["satisfaction_per_session"] for key, n in uses.items()), "intimacy", "満足の回数が不正。")
    for contact in state["contacts"]:
        key = contact["action_id"]
        if key in rules.actions:
            ensure(intimate["position"] in rules.actions[key]["positions"] and contact["lifetime"] == "private", "intimacy", "体位と継続動作が合わない。")


def validate_bath(state, pack):
    """009（v8.2.0）：風呂の記録。life.json に bath のある版だけが持つ。"""
    if not (pack.life and pack.life.bath):
        ensure("bath" not in state, "state_fields", "state に未登録の項目 bath")
        return
    from .progression import life_day
    ensure("bath" in state, "state_fields", "風呂の保存状態が不足。")
    bath, now = state["bath"], state["world"]["now"]
    exact(bath, ["day", "after_until", "together", "together_count", "invited_day"])
    today = life_day(now)
    ensure(bath["day"] is None or type(bath["day"]) is int and bath["day"] <= today, "bath", "風呂に入った日が不正。")
    ensure(bath["invited_day"] is None or type(bath["invited_day"]) is int and bath["invited_day"] <= today, "bath", "風呂に誘った日が不正。")
    ensure(bath["after_until"] is None or type(bath["after_until"]) is int and bath["day"] is not None, "bath", "湯上がりの記録が不正。")
    ensure(type(bath["together"]) is bool and type(bath["together_count"]) is int and bath["together_count"] >= int(bath["together"]), "bath", "一緒に入った記録が不正。")


def _in_work_block(now, pack):
    """v8.2.29：仕事の時間の中か（昼の締め切りのあと、エッチを続けている間）。"""
    from . import clock
    from .progression import day_time
    life = pack.life
    if not life:
        return False
    day = now - day_time(now)
    if clock.date_time(day).weekday() not in life.weekdays:
        return False
    return any(day + block["start_minute"] <= now < day + block["end_minute"] for block in life.blocks)


SLEEP_PLAY_KEYS = ["id", "kind", "started_at", "depth", "gauges", "fake", "strain", "used", "last", "level", "flags", "talked", "warned", "bands"]
SLEEP_RECORD_KEYS = ["accepted", "habits", "cooling", "night", "apologized_day"]
NIGHT_KEYS = ["day", "kind", "pleasure", "discomfort", "level", "flags", "used", "fake_reveal", "reaction"]


def neutral_sleep_record():
    """段階C（010、v8.5.0）：寝込みの記録。accepted＝受け入れられた夜の数、habits＝受け入れられた夜に使った触れ方の数、
    cooling＝怒らせた・警戒の終わる日、night＝目覚める前に離れた・目覚めた夜の記録（翌朝の一言とその条件 sleep.night.*）、apologized_day＝謝った日。
    v8.5.13：morning＝その朝に出た翌朝の一言 {day, id}（任意。一言が出た朝に足す。条件 sleep.morning）。"""
    return {"accepted": 0, "habits": {}, "cooling": None, "night": None, "apologized_day": None}


def _names(value, known):
    return type(value) is list and len(set(value)) == len(value) and set(value) <= set(known)


def validate_sleep(state, pack):
    rules = pack.intimacy.sleep_play if pack.intimacy else None
    if rules is None:
        for key in ("sleep_play", "sleep_record"):
            ensure(key not in state, "state_fields", "state に未登録の項目 " + key)
        return
    from .progression import life_day
    from .sleep_rules import KINDS, GAUGES, DEPTHS, LEVEL_MAX
    now, today = state["world"]["now"], life_day(state["world"]["now"])
    record = state.get("sleep_record")
    if record is not None:
        exact(record, SLEEP_RECORD_KEYS, ["morning"])  # v8.5.13：morning（その朝の翌朝の一言）は任意。前の保存にはない
        morning = record.get("morning")
        ensure(morning is None or type(morning) is dict and set(morning) == {"day", "id"} and type(morning["day"]) is int and morning["day"] <= today
               and morning["id"] in rules.morning_ids, "sleep_record", "翌朝の一言の記録が不正。")
        ensure(type(record["accepted"]) is int and record["accepted"] >= 0, "sleep_record", "寝込みの回数が不正。")
        ensure(type(record["habits"]) is dict and all(key in rules.actions and type(n) is int and n > 0 for key, n in record["habits"].items()), "sleep_record", "寝込みの慣れの記録が不正。")
        cooling = record["cooling"]
        ensure(cooling is None or type(cooling) is dict and set(cooling) == {"kind", "until"} and cooling["kind"] in rules.cooling_days and type(cooling["until"]) is int, "sleep_record", "怒らせた記録が不正。")
        night = record["night"]
        if night is not None:
            exact(night, NIGHT_KEYS)
            ensure(type(night["day"]) is int and night["day"] <= today and night["kind"] in rules.kind_factor and all(type(night[k]) is int and 0 <= night[k] <= 100 for k in ("pleasure", "discomfort")), "sleep_record", "夜の記録が不正。")
            ensure(type(night["level"]) is int and 0 <= night["level"] <= LEVEL_MAX and _names(night["flags"], rules.flags) and _names(night["used"], rules.actions) and type(night["fake_reveal"]) is bool, "sleep_record", "夜の記録が不正。")
            ensure(night["reaction"] is None or night["reaction"] in rules.reactions, "sleep_record", "夜の記録の反応が不正。")
        ensure(record["apologized_day"] is None or type(record["apologized_day"]) is int and record["apologized_day"] <= today, "sleep_record", "謝った日が不正。")
    play = state.get("sleep_play")
    if not play:
        return
    ensure(record is not None, "sleep_play", "寝込みの記録がない。")
    exact(play, SLEEP_PLAY_KEYS)
    ensure(type(play["id"]) is str and play["id"].startswith("sleep.") and play["kind"] in rules.kind_factor and type(play["started_at"]) is int and play["started_at"] <= now, "sleep_play", "寝込みの始まりが不正。")
    ensure(play["depth"] in DEPTHS, "sleep_play", "関係の深さが不正。")
    ensure(type(play["gauges"]) is dict and set(play["gauges"]) == set(GAUGES) and all(type(v) is int and 0 <= v <= 100 for v in play["gauges"].values()), "sleep_play", "ゲージが不正。")
    ensure(type(play["bands"]) is dict and set(play["bands"]) == set(GAUGES) and all(v in ("low", "mid", "high") for v in play["bands"].values()), "sleep_play", "ゲージの段が不正。")
    ensure(type(play["fake"]) is bool and type(play["strain"]) is int and 0 <= play["strain"] <= 1000, "sleep_play", "寝たふりの記録が不正。")
    ensure(_names(play["used"], rules.actions) and "sp_leave" not in play["used"] and (play["last"] is None if not play["used"] else play["last"] in play["used"]), "sleep_play", "使った触れ方の記録が不正。")
    ensure(type(play["level"]) is int and 0 <= play["level"] <= LEVEL_MAX and _names(play["flags"], rules.flags) and play["flags"] == sorted(play["flags"]), "sleep_play", "寝込みの段階・印が不正。")
    ensure(all(type(play[k]) is bool for k in ("talked", "warned")), "sleep_play", "寝込みの記録が不正。")
    maho, player = state["actors"]["maho"], state["actors"]["player"]
    sleep = state["maho_sleep"]["state"]
    ensure((play["kind"] == "doze" and sleep == "dozing") or (play["kind"] in ("asleep", "cosleep") and sleep == "asleep"), "sleep_play", "真帆の眠りと寝込みの種類が合わない。")
    ensure((play["kind"] == "cosleep") == bool(state.get("co_sleep")), "sleep_play", "添い寝と寝込みの種類が合わない。")  # v8.5.6
    ensure(player["location"] == maho["location"] and state["mode"] == "normal" and state["intimacy"] is None and not state["scene"] and not state["offer"], "sleep_play", "寝込みの場所・状態が不正。")


EVENT_PLAY_KEYS = ["id", "kind", "started_at", "phase", "position", "step", "inserted", "maho", "player", "climaxes", "finishes", "used", "last", "noticed", "h", "h_at", "drunk",
                   "exposure", "warned", "resume", "acts"]


def validate_ask(state, pack):
    """段階C（010、v8.5.10）：頼むの記録（ask）と、してもらっている間（ask_play）。ask 節のある版だけ持つ。"""
    rules = pack.intimacy.ask if pack.intimacy else None
    if rules is None:
        for key in ("ask", "ask_play"):
            ensure(key not in state, "state_fields", "state に未登録の項目 " + key)
        return
    from .progression import life_day
    now = state["world"]["now"]
    record = state.get("ask")
    if record is not None:
        exact(record, ["day", "shown", "served", "enough", "last_show", "last_serve", "declined", "under", "inside"])
        ensure(type(record["day"]) is int and record["day"] <= life_day(now) and all(type(record[k]) is int and record[k] >= 0 for k in ("shown", "served", "under", "inside"))
               and type(record["enough"]) is list and set(record["enough"]) <= {"show", "serve"} and len(set(record["enough"])) == len(record["enough"])
               and all(record[k] is None or type(record[k]) is int and record[k] <= now for k in ("last_show", "last_serve", "declined")), "ask", "頼むの記録が不正。")
    play = state.get("ask_play")
    if play:
        exact(play, ["kind", "place", "started_at", "arousal", "steps"])
        ensure(play["kind"] in rules.kinds and play["place"] in rules.places and type(play["started_at"]) is int and play["started_at"] <= now
               and type(play["arousal"]) is int and 0 <= play["arousal"] <= rules.serve["max"] and type(play["steps"]) is int and play["steps"] >= 0, "ask_play", "してもらっている間の記録が不正。")
        player, maho = state["actors"]["player"], state["actors"]["maho"]
        ensure(state["mode"] == "normal" and state["intimacy"] is None and not state["scene"] and not state["offer"] and state["maho_sleep"]["state"] == "awake"
               and player["location"] == maho["location"] and rules.place_of.get(player["location"]) == play["place"]
               and not any(state.get(k) for k in ("sleep_play", "event_play", "co_sleep")), "ask_play", "してもらっている間の状態が不正。")


def validate_fish(state, pack):
    """段階C（010、v8.5.11）：釣りの記録。book：種ごとの釣った数、day：その日（暮らしの日）、sessions：その日の釣りの回数、last：最後の釣果（none＝釣れなかった）、
    new：最後の釣果が図鑑に初めての種か、dinner：その日の夕食に出す魚（食べたら null）。life.json の fishing 節のある版だけ持つ。"""
    rules = pack.life.fishing if pack.life else None
    record = state.get("fish")
    if rules is None:
        ensure(record is None, "state_fields", "state に未登録の項目 fish")
        return
    if record is None:
        return
    from .progression import life_day
    exact(record, ["book", "day", "sessions", "last", "new", "dinner"])
    species = rules["species"]
    ensure(type(record["book"]) is dict and set(record["book"]) <= set(species) and all(type(v) is int and v >= 1 for v in record["book"].values())
           and type(record["day"]) is int and record["day"] <= life_day(state["world"]["now"]) and type(record["sessions"]) is int and record["sessions"] >= 0
           and (record["last"] == "none" or record["last"] in record["book"]) and type(record["new"]) is bool and (not record["new"] or record["last"] in record["book"])
           and (record["dinner"] is None or record["dinner"] in record["book"] and species[record["dinner"]]["dinner"]), "fish", "釣りの記録が不正。")


def validate_nap(state, pack):
    """段階C（010、v8.5.7）：うたた寝から目を覚ました時刻と、そのあいだの真帆の反応（nap 節のある版だけ持つ）。"""
    rules = pack.intimacy.nap if pack.intimacy else None
    nap = state.get("nap")
    if rules is None:
        ensure("nap" not in state, "state_fields", "state に未登録の項目 nap")
        return
    if nap:
        exact(nap, ["at", "id"])
        ensure(type(nap["at"]) is int and nap["at"] <= state["world"]["now"] and nap["id"] in rules.reactions, "nap", "うたた寝の記録が不正。")


def validate_co_sleep(state, pack):
    """段階C（010、v8.5.6）：添い寝の間（co_sleep）。co_sleep 節のある版だけ持つ。talk：二人とも真帆の部屋で横になり、真帆は起きている。asleep：真帆は眠っている。"""
    rules = pack.intimacy.co_sleep if pack.intimacy else None
    cs = state.get("co_sleep")
    if rules is None:
        ensure("co_sleep" not in state, "state_fields", "state に未登録の項目 co_sleep")
        return
    if not cs:
        return
    from .progression import life_day
    exact(cs, ["day", "phase", "since"])
    now = state["world"]["now"]
    ensure(cs["phase"] in ("talk", "asleep") and type(cs["day"]) is int and cs["day"] == life_day(now) and type(cs["since"]) is int and cs["since"] <= now, "co_sleep", "添い寝の記録が不正。")
    player, maho = state["actors"]["player"], state["actors"]["maho"]
    ensure(player["location"] == maho["location"] == "maho_room" and player["posture"] == maho["posture"] == "reclined" and state["mode"] == "normal"
           and state["intimacy"] is None and not state.get("event_play"), "co_sleep", "添い寝の場所・状態が不正。")
    ensure(state["maho_sleep"]["state"] == ("awake" if cs["phase"] == "talk" else "asleep"), "co_sleep", "添い寝と真帆の眠りが合わない。")


def validate_event(state, pack):
    """段階C（010、v8.5.1）：イベントのエッチの最中（event_play）。events 節のある版だけ持つ。"""
    rules = pack.intimacy.events if pack.intimacy else None
    if rules is None:
        for key in ("event_play", "event_record", "drink_night", "event_morning"):
            ensure(key not in state, "state_fields", "state に未登録の項目 " + key)
        return
    from .progression import life_day
    night = state.get("drink_night")
    if night is not None:
        # v8.5.3：お酒を飲んだ夜（最後の一晩だけ）。day：暮らしの日、drunk：その夜いちばん酔った段（1 ほろ酔い〜）
        levels = max((len(d.drunk["levels"]) for d in rules.events.values() if d.drunk), default=0)
        ensure(levels > 0 and type(night) is dict and set(night) == {"day", "drunk"} and type(night["day"]) is int and night["day"] <= life_day(state["world"]["now"])
               and type(night["drunk"]) is int and 1 <= night["drunk"] <= levels, "drink_night", "お酒を飲んだ夜の記録が不正。")
    morning = state.get("event_morning")
    if morning is not None:
        # v8.5.9：イベントの翌朝の一言（最後の一つだけ）。kind・id（その翌朝の一言）、h：そのイベントでエッチまで進んだか、at：終えた時刻
        ensure(type(morning) is dict and set(morning) == {"kind", "id", "h", "at"} and morning["kind"] in rules.events
               and morning["id"] in rules.events[morning["kind"]].mornings and type(morning["h"]) is bool
               and type(morning["at"]) is int and morning["at"] <= state["world"]["now"], "event_morning", "イベントの翌朝の一言の記録が不正。")
    record = state.get("event_record")
    if record is not None:
        # v8.5.2：イベントごとのエッチの回数と最後の生活日（エッチまで進んだ回からだけ持つ）
        ensure(type(record) is dict and set(record) <= rules.events.keys(), "event_record", "イベントの記録が不正。")
        for row in record.values():
            ensure(type(row) is dict and set(row) == {"count", "last_day"} and type(row["count"]) is int and row["count"] >= 1
                   and type(row["last_day"]) is int and row["last_day"] <= life_day(state["world"]["now"]), "event_record", "イベントの記録が不正。")
        ensure(sum(row["count"] for row in record.values()) == state["intimacy_history"]["by_entry"].get("event", 0), "event_record", "イベントの回数が合わない。")
    play = state.get("event_play")
    if not play:
        return
    from .event_play import PHASES
    exact(play, EVENT_PLAY_KEYS, ["meal"])
    # v8.5.11：台所だけが支度の食事（夕食・休日の昼）を持つ
    ensure(("meal" in play) == (play["kind"] == "kitchen") and play.get("meal", "dinner") in ("dinner", "lunch"), "event_play", "台所の支度の食事が不正。")
    ensure(play["kind"] in rules.events and type(play["id"]) is str and play["id"].startswith("event.") and type(play["started_at"]) is int and play["started_at"] <= state["world"]["now"], "event_play", "イベントの始まりが不正。")
    define, ir = rules.events[play["kind"]], pack.intimacy
    # v8.5.4：warn（人目で足音が近づいた）のあいだは、resume に元の段を持つ
    ensure(play["phase"] in PHASES and (play["phase"] == "warn") == (play["resume"] is not None) and (play["resume"] is None or play["resume"] in PHASES and play["resume"] != "warn"),
           "event_play", "イベントの段が不正。")
    phase = play["resume"] if play["phase"] == "warn" else play["phase"]
    ensure(type(play["h"]) is bool and play["h"] == (phase in ("foreplay", "main")) and type(play["noticed"]) is bool, "event_play", "イベントの段が不正。")
    ensure(play["noticed"] or phase == "pre", "event_play", "気づく前にエッチへ進んでいる。")
    ensure((play["position"] is None) == (not play["h"]) and (play["position"] is None or play["position"] in define.positions), "event_play", "イベントの体位が不正。")
    ensure((play["h_at"] is None) == (not play["h"]) and (play["h_at"] is None or type(play["h_at"]) is int and play["started_at"] <= play["h_at"] <= state["world"]["now"]), "event_play", "エッチへ移った時刻が不正。")
    ensure(type(play["step"]) is int and 0 <= play["step"] <= len(define.foreplay) and (play["h"] or play["step"] == 0), "event_play", "前戯の段が不正。")
    ensure(type(play["inserted"]) is bool and (not play["inserted"] or phase == "main"), "event_play", "入れた記録が不正。")
    ensure(type(play["maho"]) is int and 0 <= play["maho"] < ir.raw["maho"]["climax_at"] and type(play["player"]) is int and 0 <= play["player"] <= ir.raw["player"]["arousal_max"], "event_play", "高まりが不正。")
    ensure(type(play["climaxes"]) is int and play["climaxes"] >= 0 and type(play["finishes"]) is int and play["finishes"] == 0, "event_play", "達した・果てた回数が不正。")
    ensure(type(play["used"]) is list and len(set(play["used"])) == len(play["used"]) and set(play["used"]) <= define.pre.keys(), "event_play", "使った触れ合いが不正。")
    ensure(type(play["acts"]) is int and play["acts"] >= len(play["used"]), "event_play", "その場の手の数が不正。")  # v8.5.5
    ensure(play["last"] is None or play["last"] in define.last_keys(), "event_play", "直前の手が不正。")
    ensure(type(play["drunk"]) is int and 0 <= play["drunk"] <= 1000 and (define.drunk is not None or play["drunk"] == 0)
           and (define.drunk is None or define.drunk_level(play["drunk"]) < len(define.drunk["levels"])), "event_play", "酔いの記録が不正。")  # v8.5.3
    exposure = define.exposure
    ensure(type(play["exposure"]) is int and type(play["warned"]) is bool and (exposure is not None or play["exposure"] == 0 and not play["warned"] and play["phase"] != "warn")
           and (exposure is None or 0 <= play["exposure"] < exposure["max"] and (play["phase"] != "warn" or play["warned"])), "event_play", "人目の記録が不正。")  # v8.5.4
    ensure(state["mode"] == "normal" and state["intimacy"] is None and not state["scene"] and not state["offer"] and not state.get("sleep_play") and state["maho_sleep"]["state"] == "awake", "event_play", "イベントの最中の状態が不正。")
    ensure(state["actors"]["player"]["location"] == state["actors"]["maho"]["location"], "event_play", "イベントの最中に二人が別の場所にいる。")
