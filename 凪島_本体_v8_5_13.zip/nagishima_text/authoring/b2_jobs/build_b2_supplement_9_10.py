"""第9陣・第10陣の補充（2026-09-28、v8.2.11）：採用が3本に届かなかった job を、元の job の state のまま書き足してもらう。

- 対象：grok_b2_wave_9・x8・10・x9 の job のうち、tools/stage_b/b2_texts.json の採用が 0〜2本の job（同じ job id のまま。返事は b2import の parse で v6 以降に続けて番号を振る）。
- 不採用の多くは「台詞なしの本文が台詞ありの本文から台詞を抜いただけ」「別の job とほぼ同じ文の並び」だったので、採用済みの本文を「すでにある本文」として見せ、重ねないよう頼む。
- 新しい job の JSON は作らない（grok_b2_wave_*.json を増やさない）。
出力：grok依頼_B2_第9・10陣_補充/B2_補充9_10_XX.txt、第9・10陣_補充_一覧.json
"""
import collections
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
PROMPT = (OUT / "grokプロンプト_v3_0.txt").read_text(encoding="utf-8")
jobs = {}
for name in ("9", "x8", "10", "x9"):
    for row in json.loads((OUT / f"grok_b2_wave_{name}.json").read_text(encoding="utf-8")):
        jobs[row["id"]] = row
adopted = collections.defaultdict(list)
for text in json.loads((ROOT / "tools/stage_b/b2_texts.json").read_text(encoding="utf-8")):
    if text["job_id"] in jobs:
        adopted[text["job_id"]].append(text["body"])
short = [j for j in jobs if len(adopted[j]) < 3]
NOTE = ("\n\nこの依頼は、前に書いてもらった job の書き足し（補充）です。どの job も、採用できた本文が少なかったものです。"
        "不採用の多くは次のどれかでした：台詞なしの本文が、台詞ありの本文から台詞を抜いただけになっている／数回と慣れ、別の体位の job とほぼ同じ文の並び／"
        "体位と合わない描写（背を向けた体位で顔・睫毛・唇が見える、真帆がまたがる体位で「腰が浮く」「脚を閉じて挟む」）／入れたように読める語（「沈める」「浅く入る」「中」「奥」）／"
        "出す場面で促す・許す台詞（「出して」「いいよ」「大丈夫」）／シックスナインで口に含んだまま話す・真帆の顔が見える／飲んだかどうかが分かる書き方。"
        "各 job の「すでにある本文」は採用済みの本文です。書き出し・結び・台詞・文の並びを、これとも、同じファイルのほかの本文とも重ねないでください。"
        "濃い本文（id が x8. x9. で始まる job）は、標準より露骨に書いてください。この job に限り、部位の語と記号は地の文で1本に4つまで（同じ語・記号は2回まで）、擬音も使ってよいです。"
        "\nそれ以外の規則（台詞の数、慣れの段階の語、地の文で器官を名前で呼ばず記号を使う、記号を台詞に書かない、妊娠・避妊に触れない、must_not）は同じです。")
folder = OUT / "grok依頼_B2_第9・10陣_補充"
folder.mkdir(exist_ok=True)
for old in folder.glob("*.txt"):
    old.unlink()
rows = [dict(jobs[j], candidates=4 if len(adopted[j]) else 5) for j in short]
names, size = [], 10
for number, index in enumerate(range(0, len(rows), size), 1):
    chunk = rows[index:index + size]
    lines = [json.dumps({"id": r["id"], "meaning": r["meaning"], "speech": r["speech"], "length": r["length"], "origin": r["origin"], "本数": r["candidates"],
                         "must_not": r["must_not"], "state": r["state"], "すでにある本文": adopted[r["id"]]}, ensure_ascii=False) for r in chunk]
    body = ("指示\n"
            f"次の{len(chunk)}件の job を書いてください（段階Bの2版目・第9陣と第10陣の補充）。本数は各 job の「本数」のとおりです（合わせて{sum(r['candidates'] for r in chunk)}本）。"
            "speech が true の job は真帆の台詞がちょうど1つ、false の job は台詞なしです。出力の id は job の id のあとに .v1 から番号を振ってください（取り込むときに振り直します）。"
            "途中で切れそうなら、job の区切りで止めてください。「続けて」と言われたら、止めた job の次から出してください。"
            + NOTE + "\n\n[\n  " + ",\n  ".join(lines) + "\n]\n\n" "プロンプト\n" + PROMPT)
    name = f"B2_補充9_10_{number:02d}.txt"
    (folder / name).write_text(body, encoding="utf-8")
    names.append(name)
listing = {"files": names, "jobs": {r["id"]: {"採用済み": len(adopted[r["id"]]), "本数": r["candidates"]} for r in rows},
           "本数": sum(r["candidates"] for r in rows)}
(OUT / "第9・10陣_補充_一覧.json").write_text(json.dumps(listing, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
print(len(rows), "jobs", listing["本数"], "texts", names)
