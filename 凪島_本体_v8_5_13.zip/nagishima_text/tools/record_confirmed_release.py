"""確定した原稿版のファイルの検査値と、自動プレイの出力の検査値を verification/stage_b_legacy_goldens.json に足す（v8.3.0）。
これで test_stage_b の test_b01・test_b02 が、確定した版の中身と動きが変わらないことを確かめる。
使い方：python3 tools/record_confirmed_release.py interaction_009"""
import argparse
import hashlib
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from check_stage_b_compat import ROOT, run  # noqa: E402


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("release")
    args = parser.parse_args()
    releases = ROOT / "content/releases"
    target = ROOT / "verification/stage_b_legacy_goldens.json"
    goldens = json.loads(target.read_text(encoding="utf-8"))
    files = {}
    for file in sorted((releases / args.release).rglob("*")):
        if file.is_file():
            files[str(file.relative_to(releases)).replace("\\", "/")] = hashlib.sha256(file.read_bytes()).hexdigest()
    goldens["published_files"].update(files)
    added = 0
    for policy in ("--autoplay", "--autoplay-social", "--autoplay-presence"):
        for seed in (0, 42):
            observed = run(ROOT, args.release, policy, seed)
            raw = json.dumps(observed, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
            goldens["autoplay"][f"{args.release}/{policy}/{seed}"] = hashlib.sha256(raw).hexdigest()
            added += 1
    target.write_text(json.dumps(goldens, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(args.release, len(files), "files,", added, "autoplay outputs →", target)


if __name__ == "__main__":
    main()
