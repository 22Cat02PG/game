from datetime import datetime, timedelta
from .codec import digest

EPOCH = datetime(2000, 1, 1)


def minutes(iso):
    return int((datetime.fromisoformat(iso) - EPOCH).total_seconds() // 60)


def date_time(value):
    return EPOCH + timedelta(minutes=value)


def format_time(value):
    return date_time(value).strftime("%Y-%m-%d %H:%M")


def next_clock(now, minute):
    target = now // 1440 * 1440 + minute
    return target if target > now else target + 1440


def slot(now):
    minute = now % 1440
    return "morning" if 300 <= minute < 720 else "noon" if 720 <= minute < 1020 else "evening" if 1020 <= minute < 1260 else "night"


def weather(seed, day):
    return ("clear", "cloudy", "rain")[int(digest([seed, "weather", day])[:12], 16) % 3]


def delivery(now, large):
    day = now // 1440 + 1
    if large:
        while date_time(day * 1440).weekday() != 3:
            day += 1
    return day * 1440 + 600


def anniversary_day(original, year):
    date = date_time(original)
    try:
        anniversary = date.replace(year=year, hour=0, minute=0)
    except ValueError:
        anniversary = date.replace(year=year, month=2, day=28, hour=0, minute=0)
    return int((anniversary - EPOCH).total_seconds() // 60)


def anniversary_window(state, kind):
    original = state["relation"]["dating_since" if kind == "dating" else "life_since"]
    if original is None: return None
    now = state["world"]["now"]
    year = date_time(now).year
    # Check the previous year too: a Dec 31 anniversary has a January grace period.
    for target_year in (year, year - 1):
        if target_year <= date_time(original).year: continue
        at = anniversary_day(original, target_year)
        days = now // 1440 - at // 1440
        if 0 <= days <= 7:
            summary = state["memories"]["summaries"].get("anniversary_" + kind)
            celebrated = summary and summary["last"]["choice_summary"].get("year") == target_year
            return {"year": target_year, "late_days": days, "available": not celebrated}
    return None
