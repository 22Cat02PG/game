"""Package source, fixtures and handoff documents; never include player data."""
from pathlib import Path
import argparse
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from nagishima.codec import bytes_digest, write_json

DIRECTORIES = ("nagishima", "content", "tests", "tools", "authoring", "docs", "design", "verification", "examples", "collaboration")
ROOT_FILES = ("README.md", "AGENTS.md", "はじめに_ほかのAIへ.md", "完成判定.md", "引き継ぎ.md", "start.sh", "start.bat", "start_test.bat", "start_009.bat", "start_009_test.bat", "start_010.bat", "start_010_test.bat")
EXCLUDE_FILES = {"check_runtime_v711.log", "audit_presence_v711.log", "startbat_v711.stdout", "startbat_v711.jsonl",
                 "compat_output.jsonl", "compat_run.jsonl", "compat_run.jsonl.initial", "compat_console.txt",
                 "stage_b_startbat.jsonl", "stage_b_startbat_console.txt"}
EXCLUDE_DIRS = {"compat_temp", "stage_b_startbat_data"}


def main():
    parser = argparse.ArgumentParser(description="本体と資料をZIPへまとめる。userdataは含めない。")
    parser.add_argument("--output", default=str(ROOT.parent / "凪島_本体_v8_5_13.zip"))
    args = parser.parse_args()
    paths = [ROOT / name for name in ROOT_FILES]
    for directory in DIRECTORIES:
        paths.extend(p for p in (ROOT / directory).rglob("*") if p.is_file() and "__pycache__" not in p.parts and p.suffix != ".pyc"
                     and p.name not in EXCLUDE_FILES and not (EXCLUDE_DIRS & set(p.parts))
                     and "startbat_v711.jsonl.initial" not in p.parts)
    if not all(p.is_file() for p in paths): raise SystemExit("必要な資料が不足している。")
    manifest = {"package": "nagishima_text_v8_5_13", "files": {p.relative_to(ROOT).as_posix(): bytes_digest(p.read_bytes()) for p in sorted(paths)}}
    manifest_path = ROOT / "PACKAGE_MANIFEST.json"
    write_json(manifest_path, manifest)
    output = Path(args.output)
    if output.resolve().is_relative_to(ROOT): raise SystemExit("ZIPの出力先は本体フォルダーの外にする。")
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(paths + [manifest_path]):
            archive.write(path, "nagishima_text/" + path.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(output) as archive:
        if archive.testzip() is not None: raise SystemExit("ZIPの検査に失敗した。")
    print(output)
    print(f"{len(paths) + 1} files, {output.stat().st_size} bytes")


if __name__ == "__main__": main()
