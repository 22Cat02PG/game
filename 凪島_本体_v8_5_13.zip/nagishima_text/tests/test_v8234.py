"""v8.2.34（ユーザー 2026-10-01 13:33「進めて」）：別の Claude のエッチ場面の総ざらい（報告_v8233総ざらい.md）の 1〜8・10 の直し。"""
import json
import re
import unittest
from copy import deepcopy
from pathlib import Path

from nagishima.conditions import evaluate
from nagishima.content import Pack
from nagishima.context import Context
from tools.run_stage_b_routes import Route

ROOT = Path(__file__).resolve().parents[1]
PACK = Pack(ROOT / "content/releases/interaction_009")


def meanings(engine):
    return [b["meaning"] for b in engine.get_view()["blocks"]]


def candidates(meaning, state):
    values = PACK.registry.values(state)
    return [t for t in PACK.by_meaning[meaning] if not t["fallback"] and evaluate(t["when"], values) is True]


class V8234(unittest.TestCase):
    def route(self, seed, tier="familiar", **kw):
        route = Route(seed, tier=tier, **({"day_offset": 3, "hour": 13} | kw))
        self.addCleanup(route.close)
        return route

    def context(self, route):
        engine = route.engine
        return Context(deepcopy(engine._state), engine.pack, engine.repository, None, True)

    # ---- 1：延ばすのは、残りの手で果てる道があるときだけ（行為の高まりの上限から求める） ----
    def test_close_ways(self):
        route = self.route(7001, tier="few", day_offset=0, hour=12, minute=20)
        route.begin()
        at = (route.engine.snapshot()["world"]["now"] // 1440) * 1440 + 13 * 60
        for contact, maho, player, expected in (("h_self", 20, 80, "h.deadline.work"), ("h_maho_hand", 20, 80, "h.deadline.work_close"),
                                                ("h_chest_skin", 92, 10, "h.deadline.work"), ("h_tease", 92, 10, "h.deadline.work"),
                                                ("h_finger_in", 92, 10, "h.deadline.work_close"), ("h_player_mouth", 92, 10, "h.deadline.work_close")):
            context = self.context(route)
            context.s["world"]["now"] = at
            context.s["contacts"] = [{"action_id": contact, "continues": 0}]
            context.s["intimacy"]["maho"].update(arousal=maho, band=context.ir.band(maho))
            context.s["intimacy"]["player"]["arousal"] = player
            context._deadline_step(None, (at, True))
            self.assertEqual(context.events[-1]["meaning"], expected, contact)

    # ---- 2：素股・舐める・舐め合う・外に出す本文も、呼び方「膣」を「秘所」で出す（速さの本文も） ----
    def test_outer_term_lick_and_grind(self):
        route = self.route(7002)
        route.begin()
        context = self.context(route)
        for meaning in ("h_sumata.start", "h_sumata_fast.continue", "h_player_mouth.start", "h_player_mouth_fast.continue", "h_face_lick.start",
                        "h_sixty_nine.start", "h_finish_sumata.start", "h_finish_outside.start"):
            context.emit(meaning)
            self.assertEqual(context.events[-1]["bindings"]["vagina"], "秘所", meaning)
        context.emit("h_insert.start")
        self.assertEqual(context.events[-1]["bindings"]["vagina"], "膣")

    # ---- 3：同時に達する瞬間の「いきそう」 ----
    def test_together_says_it(self):
        for text in PACK.texts:
            if text["meaning"].startswith("h.climax.together") and "いきそう" in text["body"]:
                self.assertRegex(text["body"], r"(いってる|いった|イって|いっちゃ(っ|う)|達し|果て)", text["id"])

    # ---- 4：申し出のあとの本文は、最初の「真帆に動いてもらう」だけ ----
    def test_led_only_first(self):
        route = self.route(7004)
        route.begin()
        state = route.engine.snapshot()
        state["experience"]["h_lead_straddle"]["last_at"] = state["world"]["now"]
        state["recent_text"].append({"id": "x.h_lead_straddle.start.v1", "group": "x", "release": "interaction_009"})
        self.assertTrue(PACK.registry.values(state)["intimacy.maho_led_fresh"])
        state["recent_text"].append({"id": "o34.h_maho_move.start.led.familiar.face.s.v1", "group": "x", "release": "interaction_009"})
        self.assertFalse(PACK.registry.values(state)["intimacy.maho_led_fresh"])
        for text in PACK.texts:
            if text["id"].startswith("o34.h_maho_move.") and ".led." in text["id"]:
                self.assertIn('"intimacy.maho_led_fresh"', json.dumps(text["when"]), text["id"])

    # ---- 5・7：胸で達する台詞は胸に触れているとき。背を向けた体位で顔を見る2本 ----
    def test_conditions(self):
        for identity in ("x2.h.climax.maho.familiar.inserted.s.v3", "x2.h.climax.together.familiar.back.s.v5"):
            self.assertIn('"contact.h_chest_skin.active"', json.dumps(PACK.by_text[identity]["when"]), identity)
        for identity in ("b3.h.sign.wants_more.familiar.s.v3", "b2.h.climax.maho.few.not_inserted.n.v7"):
            self.assertIn('"intimacy.facing", "op": "ne", "value": "back"', json.dumps(PACK.by_text[identity]["when"]), identity)

    # ---- 6：慣れた回の深い口づけの本文 ----
    def test_kiss_pool(self):
        route = self.route(7006)
        route.begin()
        self.assertGreaterEqual(len(candidates("h_kiss_deep.start", route.engine.snapshot())), 20)

    # ---- 8：果てた回数ごとに回復を遅くする ----
    def test_refractory_grows(self):
        for seed, finishes_before, expected in ((7008, 0, 2), (7009, 1, 4), (7010, 2, 6)):
            route = self.route(seed)
            route.begin()
            route.action("h_strip_self")
            route.action("h_maho_hand")
            route.engine._state["intimacy"]["player"].update(arousal=100, refractory=0, finishes=finishes_before)
            route.engine._state["stamina"]["value"] -= finishes_before  # 果てた回数と余力は合わせる
            route.engine._install_choices()
            route.action("h_finish_hand")
            self.assertEqual(route.engine.snapshot()["intimacy"]["player"]["refractory"], expected)

    # ---- ユーザーの提案（13:40）：回復を待つあいだも口・舐め合い・手はしてもらえ、口は2倍で回復する ----
    def test_revive_by_service(self):
        route = self.route(7011)
        route.begin()
        route.action("h_strip_self")
        route.engine._state["intimacy"]["maho"].update(arousal=50, band="mid")
        route.action("h_maho_hand")
        route.engine._state["intimacy"]["player"]["arousal"] = 100
        route.engine._install_choices()
        route.action("h_finish_hand")
        self.assertEqual(route.engine.snapshot()["intimacy"]["player"]["refractory"], 2)
        route.engine._state["intimacy"]["maho"].update(arousal=50, band="mid")
        route.engine._install_choices()
        route.action("h_maho_mouth")  # 回復を待つあいだでも選べる。口は1手で2手ぶん
        player = route.engine.snapshot()["intimacy"]["player"]
        self.assertEqual((player["refractory"], player["arousal"]), (0, 0))
        self.assertIn("h.player.recovered.mouth", meanings(route.engine))

    def test_revive_by_hand_and_not_breasts(self):
        route = self.route(7012)
        route.begin()
        route.action("h_strip_self")
        route.engine._state["intimacy"]["maho"].update(arousal=50, band="mid")
        route.action("h_maho_hand")
        route.engine._state["intimacy"]["player"]["arousal"] = 100
        route.engine._install_choices()
        route.action("h_finish_hand")
        route.action("h_maho_hand")
        self.assertEqual(route.engine.snapshot()["intimacy"]["player"]["refractory"], 1)  # 手はふつうの速さ
        route.action("h_maho_hand")
        self.assertIn("h.player.recovered.hand", meanings(route.engine))
        route2 = self.route(7013)
        route2.begin()
        route2.action("h_strip_self")
        route2.engine._state["intimacy"]["player"]["refractory"] = 2
        route2.engine._state["intimacy"]["player"]["finishes"] = 1
        route2.engine._state["stamina"]["value"] -= 1
        route2.engine._install_choices()
        if route2.engine.get_view()["page"] != "main":
            route2.choose("menu.main")
        route2.choose("menu.h_service")
        view = route2.engine.get_view()
        breasts = next((c for c in view["choices"] if c["id"] == "touch.h_maho_breasts"), None)
        if breasts is not None:
            self.assertFalse(breasts["available"])
            self.assertIn("出したばかり", view["explanations"].get("touch.h_maho_breasts", ""))

    # ---- 10：抱きしめて休むを続けて選ぶと、2回目からは続きの本文 ----
    def test_after_hold_again(self):
        route = self.route(7010)
        route.begin()
        route.engine._state["intimacy"]["after"] = True
        route.engine._install_choices()
        route.action("h_after_hold")
        self.assertIn("h_after_hold.start", meanings(route.engine))
        route.action("h_after_hold")
        self.assertIn("h_after_hold.again", meanings(route.engine))

    def test_texts(self):
        data = json.loads((ROOT / "tools/stage_b/opus_texts_v8234.json").read_text(encoding="utf-8"))
        self.assertEqual(len(data["texts"]), 41)
        for row in data["texts"]:
            if row["id"] != "o41.h.player.recovered.n.v1":  # v8.2.35 で言い換えた（text_fixes の body）
                self.assertEqual(PACK.by_text[row["id"]]["body"], row["body"])
            self.assertNotIn("{vagina}", row["body"])


if __name__ == "__main__":
    unittest.main()
