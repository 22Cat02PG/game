"""5回目の試運転の指摘（v8.2.3）と、任された B2 の残り（申し出・回復の合図・達した直後の敏感さ）の試験。
公開の選択肢から確かめる（時刻・高まりなどの準備だけ内部で行う）。"""
import contextlib
import io
import tempfile
import unittest
from unittest import mock

from nagishima.engine import Engine
from tools.run_stage_b_routes import Route


def choices(engine):
    return {c["id"]: c for c in engine.get_view()["choices"]}


def meanings(engine):
    return [b["meaning"] for b in engine.get_view()["blocks"]]


def variants(engine):
    return [b["variant"] for b in engine.get_view()["blocks"]]


def pick(engine, identity):
    view = engine.get_view()
    choice = next(c for c in view["choices"] if c["id"] == identity)
    assert choice["available"], (identity, view["explanations"].get(identity))
    return engine.choose(identity, view["revision"], view["session"])


class Playtest5(unittest.TestCase):
    def route(self, *args, **kwargs):
        route = Route(*args, **kwargs)
        self.addCleanup(route.close)
        return route

    def engine(self, seed=5):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        return Engine(temp.name, seed=seed, release="interaction_009", autosave=False)

    # ---- 指摘1：一覧を開いただけのときは、前の本文をもう一度出さない ----
    def test_1_opening_a_menu_does_not_repeat_the_narration(self):
        from nagishima import __main__ as cli
        with tempfile.TemporaryDirectory() as temp:
            opening = Engine(temp, seed=20380407, release="interaction_009", autosave=False).get_view()["blocks"][-1]["body"]
        with tempfile.TemporaryDirectory() as data, tempfile.TemporaryDirectory() as logs:
            out = io.StringIO()
            with mock.patch("builtins.input", side_effect=["menu.talk", "choose menu.main", "終了"]), contextlib.redirect_stdout(out):
                cli.main(["--release", "interaction_009", "--data-dir", data, "--no-autosave", "--log", logs + "/run.jsonl"])
        text = out.getvalue()
        self.assertEqual(text.count(opening), 1, text[-1500:])  # 一覧を開いても、戻っても、本文を繰り返さない
        self.assertIn("\n― 話す ―\n", text)
        self.assertIn("\n― いつもの時間 ―\n", text)
        self.assertIn("[touch.talk]", text.split("\n― 話す ―\n", 1)[1])
        self.assertRegex(text, r"\d+\. → 話す　\[menu\.talk\]")  # 一覧を開く項目の印

    # ---- 指摘2・3：約束はこちらが切り出す。同じ約束があるうちは作れない。場所を書く ----
    def test_2_3_promise_is_proposed_by_player_and_names_the_place(self):
        engine = self.engine()
        pick(engine, "menu.plans")
        pick(engine, "begin.promise_walk")
        body = engine.get_view()["blocks"][-1]["body"]
        self.assertEqual(meanings(engine)[-1], "promise.walk.ask")
        self.assertIn("海岸", body)
        self.assertTrue(body.startswith(("一緒に散歩", "散歩の約束", "海岸まで")), body)  # こちらが切り出す
        pick(engine, "scene.yes")
        self.assertEqual([p["kind"] for p in engine.snapshot()["promises"]], ["walk"])
        pick(engine, "menu.plans")
        found = choices(engine)
        self.assertFalse(found["begin.promise_walk"]["available"])
        self.assertIn("散歩する約束は、もう交わしている", engine.get_view()["explanations"]["begin.promise_walk"])
        fulfil = next(c for c in found.values() if c["id"].startswith("fulfil."))
        self.assertTrue(fulfil["label"].endswith("（海岸）"), fulfil["label"])
        self.assertFalse(fulfil["available"])
        self.assertEqual(engine.get_view()["explanations"][fulfil["id"]], "約束の場所は海岸。二人で海岸へ移動する。")
        # 二つ目（お茶）は作れる。三つ目はない（種類が二つ）が、二つあるときの理由を確かめる
        pick(engine, "begin.promise_tea")
        self.assertIn("居間", engine.get_view()["blocks"][-1]["body"])
        pick(engine, "scene.yes")
        pick(engine, "menu.plans")
        self.assertIn("お茶を飲む約束は、もう交わしている", engine.get_view()["explanations"]["begin.promise_tea"])
        # 約束の話は「約束と共同作業」だけに並ぶ（「話す」には並べない。v8.2.4）
        pick(engine, "menu.main")
        pick(engine, "menu.talk")
        self.assertFalse(any(c.startswith("begin.promise_") for c in choices(engine)))

    def test_3b_promise_limit_reason_when_two_are_pending(self):
        engine = self.engine(6)
        pick(engine, "menu.plans")
        pick(engine, "begin.promise_walk")
        pick(engine, "scene.yes")
        from nagishima.context import Context
        context = Context(engine.snapshot(), engine.pack, engine.repository, engine._frame)
        walk = context.s["promises"][0]
        context.s["promises"].append(dict(walk, id="promise.99"))  # この版の約束は二種類なので、二つ目は内部で置く
        self.assertEqual(context.promise_blocker("tea"), "約束は二つまで。先にどちらかを果たすか、取りやめる。")

    # ---- 指摘4：入れていないときも、限界でこらえられる。こらえたら入れられる ----
    def _ready(self, seed, tier, service):
        route = self.route(seed, tier=tier, day_offset=2)
        route.begin()
        for key in ("h_strip_lower", "h_shift_under", "h_strip_self", "h_pos_lying_face"):
            route.action(key)
        for _ in range(15):
            route.action(service)
            if route.engine.snapshot()["intimacy"]["player"]["arousal"] >= 100:
                break
        self.assertEqual(route.engine.snapshot()["intimacy"]["player"]["arousal"], 100)
        return route

    def test_4_endure_at_the_limit_without_insertion_then_insert(self):
        route = self._ready(31, "few", "h_maho_hand")
        route.choose("menu.main")
        self.assertTrue(choices(route.engine)["touch.h_endure"]["available"])
        route.choose("menu.h_connect")
        insert = choices(route.engine)["touch.h_insert"]  # v8.2.4：限界のまま入れると、入れた途端に出る（選ぶ前に分かる）
        self.assertTrue(insert["available"])
        self.assertEqual(insert["label"], "ゆっくり入れる（もうこらえきれない）")
        route.choose("menu.h_clothes")  # v8.2.29：限界でも口づけ・愛撫は選べるので、服の行動の理由で確かめる
        self.assertIn("「こらえる」", route.engine.get_view()["explanations"]["touch.h_lift_upper"])
        route.action("h_endure")
        state = route.engine.snapshot()
        self.assertEqual(state["intimacy"]["player"]["arousal"], 60)
        self.assertNotIn("h_maho_hand", [c["action_id"] for c in state["contacts"]])
        self.assertEqual(meanings(route.engine), ["h_endure.hand"])
        self.assertTrue(variants(route.engine)[0].startswith(("o7.h_endure.out.hand.", "p7.h_endure.hand.")), variants(route.engine))
        route.engine._state["intimacy"]["maho"]["arousal"] = 60  # 準備：真帆の高まり（入れられるところまで）
        route.engine._install_choices()
        route.action("h_insert")
        self.assertTrue(route.engine.snapshot()["intimacy"]["inserted"])
        self.assertEqual(route.engine.snapshot()["intimacy"]["player"]["finishes"], 0)  # こらえたあとは、ふつうに入る
        self.assertTrue(meanings(route.engine)[0].startswith("h_insert."))
        # 同じ山の2回目はこらえられない（出すか抜く）
        route.engine._state["intimacy"]["player"]["arousal"] = 100
        route.engine._install_choices()
        route.choose("menu.main")
        self.assertNotIn("touch.h_endure", choices(route.engine))

    def test_4d_insert_at_the_limit_finishes_on_entry(self):
        """v8.2.4（ユーザーの要望）：限界のまま入れると、入れた途端にこらえきれずに中で出る。入れる本文は出さず、専用の本文だけ。"""
        route = self._ready(34, "few", "h_maho_hand")
        route.engine._state["intimacy"]["maho"].update(arousal=60, band="mid")  # 準備：入れられるところまで
        route.engine._install_choices()
        route.action("h_insert")
        state = route.engine.snapshot()["intimacy"]
        self.assertTrue(state["inserted"])
        self.assertEqual((state["player"]["finishes"], state["player"]["arousal"], state["mess"]), (1, 0, "inside"))
        found = meanings(route.engine)
        self.assertIn("h_overflow.insert", found)
        self.assertFalse(any(m.startswith(("h_insert.", "h.sign.mid", "h.sign.high")) for m in found), found)
        self.assertTrue(variants(route.engine)[found.index("h_overflow.insert")].startswith(("o11.h_overflow.insert.face.", "x6.h_overflow.insert.few.face.")), variants(route.engine))
        # 真帆がまだのときは止められて、入らない（出さない）
        early = self._ready(35, "few", "h_maho_hand")
        early.action("h_insert")
        state = early.engine.snapshot()["intimacy"]
        self.assertEqual((state["inserted"], state["player"]["finishes"]), (False, 0))
        self.assertIn("h.deflect.insert", meanings(early.engine))

    def test_4b_endure_with_mouth_uses_the_mouth_text(self):
        route = self._ready(32, "familiar", "h_maho_mouth")
        route.action("h_endure")
        self.assertEqual(meanings(route.engine), ["h_endure.mouth"])
        self.assertNotIn("h_maho_mouth", [c["action_id"] for c in route.engine.snapshot()["contacts"]])

    def test_4c_inserted_endure_keeps_grok_texts(self):
        route = self.route(33, tier="familiar", day_offset=2)
        route.begin()
        for key in ("h_strip_lower", "h_shift_under", "h_strip_self", "h_pos_player_above"):
            route.action(key)
        route.engine._state["intimacy"]["maho"]["arousal"] = 60
        route.engine._install_choices()
        route.action("h_insert")
        route.engine._state["intimacy"]["player"]["arousal"] = 100
        route.engine._install_choices()
        route.action("h_endure")
        self.assertEqual(meanings(route.engine)[0], "h_endure.start")
        self.assertFalse(variants(route.engine)[0].startswith("o7."))

    # ---- 指摘5：出した場所を記録し、拭いてあげる ----
    def _connected(self, seed, tier="familiar"):
        route = self.route(seed, tier=tier, day_offset=2)
        route.begin()
        for key in ("h_strip_lower", "h_shift_under", "h_strip_self", "h_pos_player_above"):
            route.action(key)
        route.engine._state["intimacy"]["maho"]["arousal"] = 60
        route.engine._install_choices()
        route.action("h_insert")
        route.engine._state["intimacy"]["player"]["arousal"] = 80  # 準備：出せるところまで
        route.engine._install_choices()
        return route

    def test_5_wipe_after_finishing_inside(self):
        route = self._connected(41)
        route.action("h_finish_inside")
        self.assertEqual(route.engine.snapshot()["intimacy"]["mess"], "inside")
        route.choose("menu.h_words")
        self.assertFalse(choices(route.engine)["touch.h_wipe"]["available"])
        self.assertIn("抜く", route.engine.get_view()["explanations"]["touch.h_wipe"])
        route.action("h_withdraw")
        self.assertEqual(route.engine.get_view()["page"], "main")
        self.assertTrue(choices(route.engine)["touch.h_wipe"]["available"])  # 出したあとは、いつもの画面に出る
        before = route.engine.snapshot()["intimacy"]["maho"]["satisfaction"]
        route.action("h_wipe")
        self.assertEqual(meanings(route.engine)[0], "h_wipe.start")
        self.assertTrue(variants(route.engine)[0].startswith(("o10.h_wipe.inside.", "p7.h_wipe.start.")) and ".inside." in variants(route.engine)[0], variants(route.engine))
        state = route.engine.snapshot()["intimacy"]
        self.assertIsNone(state["mess"])
        self.assertGreater(state["maho"]["satisfaction"], before)
        self.assertNotIn("touch.h_wipe", choices(route.engine))

    def test_5b_wipe_follows_where_it_landed(self):
        route = self._connected(42)
        route.action("h_finish_outside")
        self.assertEqual(route.engine.snapshot()["intimacy"]["mess"], "outside")
        route.action("h_wipe")
        self.assertTrue(variants(route.engine)[0].startswith(("o10.h_wipe.outside.", "p7.h_wipe.start.")) and ".outside." in variants(route.engine)[0], variants(route.engine))
        hand = self._ready(43, "first", "h_maho_hand")
        hand.action("h_finish_hand")
        self.assertEqual(hand.engine.snapshot()["intimacy"]["mess"], "hand")
        hand.action("h_wipe")
        self.assertTrue(variants(hand.engine)[0].startswith(("o10.h_wipe.hand.first.", "p7.h_wipe.start.first.hand.")), variants(hand.engine))

    # ---- 任された3点：回復の合図・達した直後の敏感さ・自分から入れる申し出 ----
    def test_6_recovery_sign_once_refractory_ends(self):
        route = self._connected(51)
        route.action("h_finish_inside")
        route.action("h_kiss_deep")
        self.assertNotIn("h.player.recovered", meanings(route.engine))
        route.action("h_kiss_deep")
        self.assertIn("h.player.recovered", meanings(route.engine))
        self.assertEqual(route.engine.snapshot()["intimacy"]["player"]["refractory"], 0)
        route.action("h_kiss_deep")
        self.assertNotIn("h.player.recovered", meanings(route.engine))

    def test_7_sensitive_right_after_her_climax(self):
        route = self.route(61, tier="few", day_offset=2)
        route.begin()
        for key in ("h_strip_lower", "h_shift_under", "h_pos_lying_face"):
            route.action(key)
        route.engine._state["intimacy"]["maho"].update(arousal=97, band="near")  # 準備：達する手前
        route.engine._install_choices()
        for _ in range(5):
            route.action("h_touch_direct")
            if route.engine.snapshot()["intimacy"]["maho"]["climaxes"]:
                break
        self.assertIn("h.climax.maho", meanings(route.engine))
        self.assertTrue(route.engine.snapshot()["intimacy"]["maho"]["sensitive"])
        route.action("h_touch_direct")
        self.assertEqual(meanings(route.engine)[1], "h.sign.sensitive")
        self.assertFalse(route.engine.snapshot()["intimacy"]["maho"]["sensitive"])
        route.action("h_touch_direct")
        self.assertNotIn("h.sign.sensitive", meanings(route.engine))  # 直後の1手だけ
        # 言葉をはさむと出ない
        quiet = self.route(61, tier="few", day_offset=2)
        quiet.begin()
        for key in ("h_strip_lower", "h_shift_under", "h_pos_lying_face"):
            quiet.action(key)
        quiet.engine._state["intimacy"]["maho"].update(arousal=97, band="near")
        quiet.engine._install_choices()
        for _ in range(5):
            quiet.action("h_touch_direct")
            if quiet.engine.snapshot()["intimacy"]["maho"]["climaxes"]:
                break
        quiet.action("h_feel")
        quiet.action("h_touch_direct")
        self.assertNotIn("h.sign.sensitive", meanings(quiet.engine))

    def test_8_takein_offer_after_straddle(self):
        """「上に乗る」の申し出のあとでも、「自分から入れる」の申し出が出る（種類ごとに1回）。"""
        seen = False
        for seed in range(70, 90):
            route = Route(seed, tier="familiar", day_offset=2)
            try:
                route.begin()
                for key in ("h_strip_lower", "h_shift_under", "h_strip_self", "h_pos_maho_above"):
                    route.action(key)
                intimate = route.engine._state["intimacy"]
                intimate["leads"] = ["h_lead_straddle"]  # 準備：上に乗る申し出は済んだ
                intimate["maho"].update(arousal=85, band="high")
                route.engine._install_choices()
                for _ in range(4):
                    if route.engine.snapshot()["offer"]:
                        break
                    route.engine._state["intimacy"]["maho"].update(arousal=85, band="high")
                    route.engine._install_choices()
                    route.choose("menu.main") if route.engine.get_view()["page"] != "main" else None
                    route.choose("menu.h_touch")
                    route.choose("touch.h_kiss_deep")
                offer = route.engine.snapshot()["offer"]
                if offer:
                    self.assertEqual(offer["kind"], "h_lead_takein")
                    self.assertEqual(route.engine.snapshot()["intimacy"]["leads"], ["h_lead_straddle", "h_lead_takein"])
                    route.choose("offer.accept")
                    self.assertTrue(route.engine.snapshot()["intimacy"]["inserted"])
                    seen = True
                    break
            finally:
                route.close()
        self.assertTrue(seen)


if __name__ == "__main__":
    unittest.main()
