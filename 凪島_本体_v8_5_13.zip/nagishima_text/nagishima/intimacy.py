"""Stage B semantic transactions; rendering and menus remain separate."""
from .codec import digest
from .errors import GameError, ensure
from .intimacy_rules import PACES, RESIDENCE

ORDER = {"low": 0, "mid": 1, "high": 2, "near": 3}
TIERS = {"first": 0, "few": 1, "familiar": 2}
FINISH = {"h_finish_inside", "h_finish_outside", "h_finish_hand", "h_finish_mouth", "h_finish_sumata", "h_finish_breasts", "h_finish_feet", "h_finish_sixty_nine"}
DEADLINE_ACTIONS = FINISH | {"h_withdraw", "h_after_hold", "h_wipe"}
WRAP_KEEP_CATEGORIES = ("finish", "after", "kiss", "words")  # v8.2.32：切り上げを言ったあとも選べる種類（様子を聞くは別に止める）
WRAP_KEEP = ("h_stroke_head",)
# v8.2.34（ユーザー 2026-10-01 13:40 の提案「してもらうで早く復活」、13:50「それでいいよ。進めて」）：
# 出したあとの回復を待つあいだも、口・舐め合い・手はしてもらえる。1手で進む回復の手（口・舐め合いは2、手は1）。高まりは回復するまで上がらない。胸・足は回復してから。
REVIVE = {"h_maho_mouth": 2, "h_sixty_nine": 2, "h_maho_hand": 1}
REVIVE_TEXT = {"h_maho_mouth": "mouth", "h_sixty_nine": "mouth", "h_maho_hand": "hand"}
AGAIN_TEXT = ("h_after_hold",)  # v8.2.34：同じ回に2回目からは .again の本文を出す行為
STOPPED_SAY = ("h_maho_mouth", "h_maho_hand", "h_maho_breasts", "h_maho_feet", "h_sixty_nine")  # v8.2.32：止めたときに真帆の一言を出す行為
LIMIT_ACTIONS = FINISH | {"h_endure", "h_withdraw", "h_check", "h_feel"}
MOVES = ("h_move_slow", "h_move_normal", "h_move_fast", "h_maho_move")  # v8.2.14：真帆に動いてもらう
# v8.2.29：限界で口づけ・愛撫をしても続く刺激（真帆の手・真帆の動き）。頭をなでるときは stroke.lead_actions も
LIMIT_STIMULATION = ("h_maho_hand", "h_maho_move")
AFTER_STOPS = MOVES + ("h_touch_direct", "h_touch_under", "h_finger_in", "h_tease", "h_thigh")  # v8.2.30：余韻に入ったら終える行為
AFTER_TIME_MIN = 15  # v8.2.29：昼に終えたあとの時間が、これより短ければ一言を出さない（確かめ役 F-5）
INSERTS = ("h_insert", "h_insert_deep")  # ゆっくり入れる・一気に奥まで入れる（v8.2.5）
AFTER_CHEST = ("h_after_bury", "h_after_suckle")  # v8.2.21：余韻の胸（顔を埋める・甘えて吸う）
# v8.2.22：余韻の行為を選んだときに終える、続いている余韻の行為（抱きしめて休むは顔を上げる、拭くは起き上がる）
AFTER_ENDS = {"h_after_hold": AFTER_CHEST, "h_wipe": AFTER_CHEST + ("h_after_legs",)}
MOUTH_BUSY = ("h_player_mouth", "h_face_lick", "h_maho_mouth", "h_sixty_nine")  # v8.2.24：どちらかの口がふさがっている行為
MOUTH_AND_SERVICE = ("h_player_mouth", "h_maho_mouth", "h_maho_hand", "h_self", "h_sumata", "h_maho_breasts", "h_maho_feet", "h_face_lick", "h_sixty_nine")
# v8.2.25（精査 A-3）：胸・足でしてあげる申し出（真帆が脚のあいだ・向かいへ移る本文）を出さない最中。口と奉仕に、深い口づけ・耳元・胸に口づけるを足す
REQUEST_OFFER_BUSY = MOUTH_AND_SERVICE + ("h_kiss_deep", "h_ear_neck", "h_chest_mouth")
WANTS_MORE_SIGNS = ("h.sign.wants_more", "h.sign.wants_more_urge")
# v8.2.26：物足りなさの数え直し（入れた）の目印。入れる・奥まで入れる・自分から入れる、と限界のまま入れて果てる本文
INSERT_STARTS = ("h_insert.", "h_insert_deep.", "h_lead_takein.", "h_overflow.insert")


def is_sign(meaning, signs):
    """v8.2.25（精査 A-7・D-1）：合図の意味か。向きで差し替えた意味（h.sign.wants_more.face_sit など）も同じ合図として数える。"""
    return any(meaning == sign or meaning.startswith(sign + ".") for sign in signs)
OVERFLOW_TEXT = {"h_finish_inside": "h_overflow.inside", "h_finish_hand": "h_overflow.hand", "h_finish_mouth": "h_overflow.mouth",
                 "h_finish_sumata": "h_overflow.sumata", "h_finish_breasts": "h_overflow.breasts", "h_finish_feet": "h_overflow.feet",
                 "h_finish_sixty_nine": "h_overflow.sixty_nine"}
SERVICE_CONTACT = {"h_finish_hand": "h_maho_hand", "h_finish_mouth": "h_maho_mouth",
                   "h_finish_sumata": "h_sumata", "h_finish_breasts": "h_maho_breasts", "h_finish_feet": "h_maho_feet",  # v8.2.9：素股・胸・足
                   "h_finish_sixty_nine": "h_sixty_nine"}  # v8.2.10：シックスナイン
# v8.2.9：今している行為に足す「追加」（先端を舐める・玉を揉む）。キーは追加の行動、値は足せる行為
ORDER_SAT = {"low": 0, "mid": 1, "high": 2}  # v8.2.12：満足の段の順
EXTRAS = {"h_extra_lick": ("h_maho_breasts",), "h_extra_balls": ("h_maho_hand", "h_maho_mouth")}
EXTRA_NAME = {"h_extra_lick": "lick", "h_extra_balls": "balls"}
# v8.2.9：お願いした回数で、真帆が自分から申し出る・自分から追加する（エッチの履歴）
REQUEST_OFFERS = {"h_help_breasts": "h_maho_breasts", "h_help_feet": "h_maho_feet"}
HELP_OFFERS = {"h_help_hand": ("h_maho_hand", "offer.h_help.hand"), "h_help_mouth": ("h_maho_mouth", "offer.h_help.mouth"),
               "h_help_breasts": ("h_maho_breasts", "offer.h_help.breasts"), "h_help_feet": ("h_maho_feet", "offer.h_help.feet")}
# v8.2.3（5回目の試運転の指摘5）：最後に出した場所。「拭いてあげる」（h_wipe）で消える
MESS = {"h_finish_inside": "inside", "h_finish_outside": "outside", "h_finish_hand": "hand", "h_finish_mouth": "mouth",
        "h_finish_sumata": "outside", "h_finish_breasts": "outside", "h_finish_feet": "outside", "h_finish_sixty_nine": "mouth"}  # 素股・胸・足は肌に出す（拭くは「外」）
# v8.2.3：真帆が達した直後に、この分類の行動（と入れる）を続けると、敏感になっている一言（h.sign.sensitive）を足す
SENSITIVE_CATEGORIES = ("caress", "move", "tease", "grind", "mutual")
_UNDECIDED = object()  # v8.3.3：まだ決めていない（自分で高めるときの申し出）


class Intimacy:
    @property
    def ir(self):
        ensure(self.pack.intimacy is not None, "intimacy", "この原稿版にエッチは登録されていない。")
        return self.pack.intimacy

    def _charge_intimacy(self, minutes):
        activity = self.activity(self.s["private_instance"])
        # v8.2.29（ユーザー 2026-09-30「あと一手で絶頂できるタイミングで仕事の時間だ、が入る」）：エッチの手は、仕事の始まりをまたいで進められる。
        # 仕事の始まりは、この回の締め切り（_session_deadline）として扱い、締めくくりの一言と、残りの手（wrap_up）で区切る。
        advancing, self._work_advancing = getattr(self, "_work_advancing", False), self.s["intimacy"] is not None and self.ir.deadline_close is not None
        try:
            self.advance(minutes)
        finally:
            self._work_advancing = advancing
        activity["charged_minutes"] += minutes
        activity["remaining_minutes"] = max(0, self.pack.catalog["activities"]["private_time"]["minutes"] - activity["charged_minutes"])

    def _session_deadline(self):
        """v8.2.29：この回の締め切り。夜の切り上げる時刻と、昼の仕事の始まりの早いほう。(時刻, 仕事の始まりか)"""
        night = self.ir.deadline(self.now, self.pack.life)
        intimate = self.s["intimacy"]
        if intimate is not None and intimate["entry"] == "wake" and self.ir.sleep_play:
            # 段階C（010）：寝込みから起きているエッチへ移った回は、夜の区切りを過ぎていても、移ってから awake_minutes まで（目覚める時刻まで）
            night = max(night, min(intimate["started_at"] + self.ir.sleep_play.awake_minutes, self.s["world"]["awake_deadline"]))
        if self.ir.deadline_close is None:
            return night, False
        work = self.minutes_to_work(max(1, night - self.now + 1))
        if work is not None and self.now + work < night:
            return self.now + work, True
        return night, False

    def _position(self):
        start = self.ir.raw["session"]["start_position"]
        return start["seated"] if all(self.s["actors"][actor]["posture"] == "seated" for actor in ("player", "maho")) else start["other"]

    def _begin_intimacy(self, entry, origin):
        rules = self.ir
        ensure(self.s["mode"] == "private" and self.s["private_instance"] is not None and self.s["intimacy"] is None and self.s["relation"]["stage"] >= 3, "intimacy", "二人の時間の中で始める。")
        self.require_awake()
        ensure(self.s["actors"]["player"]["location"] == self.s["actors"]["maho"]["location"] and self.s["actors"]["player"]["location"] in rules.raw["session"]["locations"], "intimacy", "部屋で二人そろって始める。")
        self.s["contacts"] = []
        position = self._position()
        self.s["intimacy"] = {"id": self.new_id("intimacy"), "entry": entry, "origin": origin, "started_at": self.now,
            "position": position, "inserted": False, "after": False,
            "maho": {"arousal": 0, "satisfaction": 0, "climaxes": 0, "band": "low", "climax_source": None, "sensitive": False},
            "player": {"arousal": 0, "finishes": 0, "endured": 0, "refractory": 0},
            "hold_back_used": False, "leads": [], "wrap_up": None, "deflected": [], "satisfaction_uses": {}, "help_offered": False, "mess": None, "begged": False, "extras": [], "offered": [], "paces": {}, "pace_focus": None, "stroked_back": False}
        for actor, posture in rules.positions[position]["postures"].items():
            self.s["actors"][actor]["posture"] = posture

    def intimacy_entry(self, identity):
        rules = self.ir
        ensure(identity in rules.actions and rules.actions[identity]["entry"], "intimacy", "入口の行動が違う。")
        ensure(self.s["mode"] == "private" and self.s["intimacy"] is None, "intimacy", "二人の時間の中で選ぶ。")
        position = self._position()
        ensure(position in rules.actions[identity]["positions"], "h_state", "今の姿勢では触れ方を深められない。")
        if self._entry_declined():
            return
        self._begin_intimacy("private", "player")
        if self._session_deadline()[1] and "h.begin.short" in self.pack.meanings:
            self.emit("h.begin.short")  # v8.2.30（通し確かめ 1）：仕事の前（朝・昼休み）は、短い時間だと真帆が最初に言う
        self.intimacy_action(identity)

    def intimacy_self_entry(self):
        """段階C（010、v8.5.8、仕様 第10節）：二人の時間（エッチの前）に、起きている真帆の前で自分で高める。
        真帆の反応：decline_when に当たれば困って話をそらし（欲求 decline_desire、断られた扱い）、エッチは始まらない。
        当たらなければエッチを始めて「自分で高める」（h_self）へ。そのあとの真帆の様子（見ている・目をそらす・手や口の申し出）は、エッチの中の決まりのまま。"""
        rules = self.ir
        entry = rules.self_entry
        ensure(entry is not None, "intimacy", "この原稿版にはない。")
        ensure(self.s["mode"] == "private" and self.s["intimacy"] is None, "intimacy", "二人の時間の中で選ぶ。")
        ensure(self._position() in rules.actions["h_self"]["positions"], "h_state", "今の姿勢では選べない。")
        tier_from = rules.actions["h_self"]["needs"]["tier_from"]
        ensure(TIERS[rules.tier(self.s["intimacy_history"]["count"], self.pack.life)] >= TIERS[tier_from], "h_tier", "もう少し回数を重ねてから。")
        ensure(self.s["stamina"]["value"] > 0, "h_player", "余力が尽きた。")
        if self._entry_declined():
            return
        from .conditions import evaluate
        from .progression import change_desire
        if evaluate(entry["decline_when"], self.pack.registry.values(self.s)) is True:
            self._charge_intimacy(1)
            self.s["intimacy_history"]["declined_at"] = self.now
            self.emit("h.self_entry.decline")
            if self.pack.progression and entry["decline_desire"]:
                change_desire(self.s, self.pack.progression, entry["decline_desire"])
            return
        self.emit("h.self_entry.begin")
        event_len = len(self.events)
        self._begin_intimacy("private", "player")
        self.s["actors"]["player"]["clothing"]["lower"] = "off"  # 自分で前をくつろげる（始まりの本文が書く）
        self.events = self.events[:event_len]
        self.intimacy_action("h_self")

    def _entry_declined(self):
        """エッチを始める前の決まり（断られたばかり・仕事の前・時間が足りない・初めての回の時間・満ちたばかり）。断ったら本文を出して True。"""
        rules = self.ir
        now, history = self.now, self.s["intimacy_history"]
        quiet = history["declined_at"] is not None and now - history["declined_at"] <= rules.raw["session"]["decline_quiet_minutes"]
        ensure(not quiet, "h_quiet", "さっき断られたばかりだ。少し時間を置く。")
        # v8.2.25（精査 B-05）：いつもの触れ合いで「仕事の前だから」と止めた真帆は、その仕事の前には部屋でも始めない（同じ幅で断る）。
        # 止めていなければ、これまでどおり仕事の前の短い時間でも始められる（昼休みなど。終えるときは引き留めない）。
        work_before = rules.b2 and self.minutes_to_work(self.pack.catalog["activities"]["private_time"]["minutes"] + rules.b2["gate"]["work_margin_minutes"]) is not None
        if work_before and self._said_before_work() and "h.decline.work" in self.pack.meanings:
            self._charge_intimacy(1)
            history["declined_at"] = self.now
            self.emit("h.decline.work")
            return True
        if rules.deadline(now, self.pack.life) - now < rules.raw["session"]["min_minutes"]:
            self._charge_intimacy(1)
            history["declined_at"] = self.now
            self.emit("h.decline.time")
            return True
        if (rules.first_time_minutes and history["count"] == 0 and self._session_deadline()[0] - now < rules.first_time_minutes
                and "h.decline.first_time" in self.pack.meanings):
            # v8.2.30（通し確かめ 8）：初めての回は、急がずにできる時間がないと始めない（入れた5分後に「寝る時間」で切れていた）
            self._charge_intimacy(1)
            history["declined_at"] = self.now
            self.emit("h.decline.first_time")
            return True
        if history["last_result"] == "satisfied" and now - history["last_at"] <= rules.raw["session"]["rested_minutes"]:
            self._charge_intimacy(1)
            history["declined_at"] = self.now
            self.emit("h.decline.rested")
            return True
        return False

    def _said_before_work(self):
        """この仕事の前に、いつもの触れ合いで「仕事の前だから」（gate.react.deflect_time）と止めたか。最近の本文から見る（保存の形は変えない）。
        そのあと仕事・眠り・朝食をはさんでいれば、別の仕事の前（v8.2.25、精査 B-05）。"""
        for item in reversed(self.s["recent_text"]):
            meaning = self.repo.get(item["release"]).by_text[item["id"]]["meaning"]
            if meaning.startswith(("work.block.", "work.lunch", "system.slept", "h.morning", "life.breakfast")):
                return False
            if meaning == "gate.react.deflect_time":
                return True
        return False

    def intimacy_eligibility(self, identity, origin="player", overflow=False):
        rules = self.ir
        ensure(self.s["intimacy"] is not None, "intimacy", "エッチは始まっていない。")
        ensure(identity in rules.actions, "intimacy", "エッチの行動が未登録。")
        action = rules.actions[identity]
        intimate = self.s["intimacy"]
        needs = action["needs"]
        ensure(not action["offer_only"] or origin == "maho", "h_offer", "真帆の提案から選ぶ。")
        ensure(origin == action["origin"], "h_origin", "行動の開始者が違う。")
        # v8.2.19（試遊）：開くのは関係ではなくエッチの回数（初回・数回・慣れ）なので、足りない段階に合わせて言う
        ensure(TIERS[rules.tier(self.s["intimacy_history"]["count"], self.pack.life)] >= TIERS[needs["tier_from"]], "h_tier",
               "もっと慣れてから。" if needs["tier_from"] == "familiar" else "もう少し回数を重ねてから。")
        if identity == "h_stroke_head" and rules.stroke and (intimate["position"] not in action["positions"] or rules.facing(self.s) not in rules.stroke["facings"]):
            raise GameError("h_state", "今の姿勢では、真帆の頭に手が届かない。")  # v8.2.14：体位の案内より先に（読み手の指摘 S-7）
        thrust = rules.settings.get("thrust_up")
        if thrust and identity == thrust["action"] and not any(c["action_id"] == thrust["with"] for c in self.s["contacts"]):
            raise GameError("h_state", thrust["message"])
        if identity in rules.action_facings and rules.facing(self.s) not in rules.action_facings[identity]:
            raise GameError("h_state", "今の向きでは届かない。")  # v8.4.0（010）：額を寄せる・頬に触れる などは向きを選ぶ  # v8.3.3（依頼 C）：下から突き上げるのは、上に乗った真帆が動いているときだけ
        player = intimate["player"]
        endure_left = player["endured"] < rules.raw["player"]["endure"]["per_peak"]
        ready_needed = identity in (*INSERTS, "h_lead_takein", *MOVES, *FINISH) or needs["player_ready"]
        if player["arousal"] >= rules.raw["player"]["arousal_max"]:
            # B2：動きや、真帆の手・口を続けると、こらえきれずに出る（_overflow_target）。ほかの行動は選べない（手順の案内より先に言う）。
            caress_ok = rules.limit_caress is not None  # v8.2.29：限界でも口づけ・愛撫はできる
            # 今の体位でできる口づけ・愛撫があるときだけ言う（確かめ役 F-8：シックスナインでは体位を変えないとできない）
            caress_here = caress_ok and any(intimate["position"] in rules.actions[key]["positions"] for key, row in rules.actions.items() if row["category"] in ("kiss", "caress") and key != "h_stroke_head")
            caress_note = "口づけや愛撫はできる。" if caress_here else ""
            if intimate["inserted"]:
                # v8.2.7（精査 A-02）：同じ山でこらえたあとは「こらえる」を言わない
                limit_message = ("もう限界だ。出すか、こらえるか、抜く。" if endure_left else "もう限界だ。この山ではもうこらえられない。出すか、抜く。") + caress_note
            else:
                # v8.2.3：入れていないときも、こらえれば落ち着いて、入れることもできる。v8.2.4：このまま入れると、入れた途端に出る。
                # v8.2.7（精査 A-04・F-15）：「このまま入れても」は、入れられる（体位・服・慣れ）ときだけ言う
                can_insert = not overflow and any(key != identity and self._overflow_target(key) for key in INSERTS)
                # v8.2.29（ユーザー 2026-09-30「手でしてもらうしか表示されてないのに、手か口に出すが表示されてる」）：
                # 今してもらっている行為があれば「このまま」、なければ今の体位・服・慣れで頼める手・口だけを言う
                active = {c["action_id"] for c in self.s["contacts"]}
                parts = {"h_maho_hand": "手", "h_maho_mouth": "口", "h_maho_breasts": "胸", "h_maho_feet": "足", "h_sixty_nine": "口"}
                current = next((parts[key] for key in parts if key in active), None)
                ways = [] if overflow else [parts[key] for key in ("h_maho_hand", "h_maho_mouth") if self._overflow_target(key)]
                service_here = bool(current or ways)
                # v8.2.9：入れられなくても、素股ならその場で出せる（このまま素股をすると、こらえきれない）
                grind_here = not can_insert and not service_here and not overflow and identity != "h_sumata" and self._overflow_target("h_sumata")
                tail = ("出す（このまま入れても、こらえきれない）" if can_insert else "このまま真帆の" + current + "で出す" if current
                        else "真帆の" + "か".join(ways) + "で出す" if ways
                        else "出す（このまま素股をしても、こらえきれない）" if grind_here else "体位を変えて出す")
                limit_message = ("もう限界だ。「こらえる」か、" if endure_left else "もう限界だ。この山ではもうこらえられない。") + tail + "。" + caress_note
            # v8.2.8（ユーザー了承 2026-09-28）：入れていない限界でも、体位だけは変えられる（背を向けた体位で「限界のまま入れる」ため）
            reposition = not intimate["inserted"] and action["category"] == "position" and rules.positions[action["sets"]["position"]]["insertion"]  # 入れるための体位だけ（v8.2.10）
            allowed = identity in LIMIT_ACTIONS or overflow or reposition or self._overflow_target(identity) or caress_ok and action["category"] in ("kiss", "caress")
            if allowed and not overflow and not intimate["inserted"] and needs["inserted"] is True:
                allowed = False  # v8.2.7（精査 D-6）：入れていない限界で、入れていることが要る行動（抜く・中で出す）は、手順を案内しない
            if not allowed and not overflow and not intimate["inserted"] and identity in INSERTS and self._insert_needs_only_position(identity):
                # v8.2.8：服はそろっていて体位だけが合わないときは、体位を変えれば入れられる（入れた途端に出る）ことを言う
                hint = self._shape_hint(identity)
                raise GameError("h_limit", (hint[:-1] if hint and hint.endswith("。") else "先に体位を変える") + "（入れた途端に、こらえきれない）。")
            ensure(allowed, "h_limit", limit_message)
        if identity in EXTRAS:
            ensure(player["refractory"] == 0, "h_player", "出したばかりで、今はまだ動けない。")  # v8.2.35（確かめ役 2）：回復を待つあいだは、追加（先端を舐める・玉を揉む）を新しく始めない
            # v8.2.9：追加（先端を舐める・玉を揉む）は、その行為をしてもらっている最中だけ
            active = {c["action_id"] for c in self.s["contacts"]}
            ensure(any(key in active for key in EXTRAS[identity]), "h_state", "先に「" + "」か「".join(rules.actions[key]["label"] for key in EXTRAS[identity]) + "」。")
            ensure(EXTRA_NAME[identity] not in self._active_extras(), "h_state", "もう、してもらっている。")
        if ready_needed:
            # 余力が尽きたときは、終えるか抱きしめて休むへ誘う（v8.0.8、試運転の指摘）。手順の案内より先に言う（v8.2.7、精査 D-4）。
            ensure(self.s["stamina"]["value"] > 0, "h_player", "余力が尽きた。口づけや指で触れることはできる。締めくくるなら「抱きしめて休む」か「終える」。")
        wrap = intimate["wrap_up"]
        # v8.2.29：昼は仕事の始まりで区切る（「今夜」と言わない）
        work_wrap = wrap is not None and self._session_deadline()[1]
        go = self._work_verb() if work_wrap else None  # 朝は「行く」、昼休みのあとは「戻る」（確かめ役 F-10）
        wrap_time = f"もう仕事に{go}時間だ。" if work_wrap else "今夜はもう切り上げる時間だ。"
        wrap_said = f"真帆はもう、仕事に{go[0]}こうと言った。" if work_wrap and go == "行く" else "真帆はもう、仕事に戻ろうと言った。" if work_wrap else "真帆はもう、今夜は切り上げると言った。"
        if wrap and self._close_grace():
            wrap_said = "最後まで、と真帆は言った。今は体位や服を変えない。"  # 延ばしたあいだ（確かめ役 F-11）
        if wrap == 0:
            ensure(identity in DEADLINE_ACTIONS, "h_deadline", wrap_time)
        if wrap is not None:
            # 真帆が切り上げを言ったあとは、様子を聞かない（v8.0.5、監査 F-02）。
            ensure(identity != "h_check", "h_deadline", wrap_said)
            # v8.2.7（精査 C-24）：切り上げを言ったあとは、新しく入れる・体位を変える・脱がせるを始めない（出す・抜く・余韻・拭くはできる）
            ensure(not (identity in (*INSERTS, "h_lead_takein", "h_lead_straddle") or action["category"] in ("position", "undress")), "h_deadline", wrap_said)
            # v8.2.32（確かめ役 1）：切り上げを言ったあとは、今している行為の続き・果てる・抜く・余韻・口づけ・頭を撫でる・速さを変えるだけ。
            # 新しく口でしてもらう・素股・愛撫などを始めない（「行かなきゃ」の直後に初めての口淫が始まっていた）
            active = {c["action_id"] for c in self.s["contacts"]}
            ensure(identity in active or identity in DEADLINE_ACTIONS or action["category"] in WRAP_KEEP_CATEGORIES or identity in WRAP_KEEP
                   or (action["category"] == "move" and intimate["inserted"]), "h_deadline", wrap_said)
        if identity in SERVICE_CONTACT and not overflow and not any(c["action_id"] == SERVICE_CONTACT[identity] for c in self.s["contacts"]):
            # v8.2.7（精査 D-5）：手・口の中で出すは、先に手・口でしてもらう手順（服・体位）も一緒に言う
            service = SERVICE_CONTACT[identity]
            label = "「" + rules.actions[service]["label"] + "」"
            sub = self._shape_hint(service)
            if sub and sub.startswith("先に") and sub.endswith("。"):
                raise GameError("h_state", sub[:-1] + "、" + label + "。")
            raise GameError("h_state", sub or "先に" + label + "。")
        hint = self._shape_hint(identity)
        if hint:
            if wrap is not None and hint != "先に「" + rules.actions["h_withdraw"]["label"] + "」。":
                raise GameError("h_deadline", wrap_time if wrap == 0 else wrap_said)  # 手順が選べない（精査 D-3）
            # v8.2.7（精査 D-1・D-4・D-5）：形の手順のあとにも要ることを添える
            if needs["maho_band"] and ORDER[rules.band(intimate["maho"]["arousal"])] < ORDER[needs["maho_band"]]:
                hint += "真帆の高まりも待つ。"
            if identity in FINISH and player["arousal"] < rules.raw["player"]["finish_from"]:
                hint += "出せるのは、高まってから。"
            if ready_needed and player["refractory"] > 0 and identity not in REVIVE:
                hint += "出したばかりで、すぐには動けない。"
            raise GameError("h_state", hint)
        if action["category"] == "position" and intimate["inserted"] and intimate["position"] not in rules.positions[action["sets"]["position"]]["linked"]:
            # B2：入れたまま移れるのは、上から重なる・片脚を抱える・両脚を肩にかけるのあいだだけ。
            raise GameError("h_state", "先に「" + rules.actions["h_withdraw"]["label"] + "」。")
        facing = rules.facing(self.s)
        if identity in ("h_check", "h_feel") and facing in ("player_mouth", "maho_mouth") and not (facing == "maho_mouth" and intimate["paces"].get("h_maho_mouth") == "slow"):
            ending = "h_player_mouth" if facing == "player_mouth" else "h_maho_mouth"
            raise GameError("h_state", "口での愛撫の最中は話せない。先に「" + rules.actions[ending]["end_label"] + "」。")
        if needs["maho_band"]:
            ensure(ORDER[rules.band(intimate["maho"]["arousal"])] >= ORDER[needs["maho_band"]], "h_state", "真帆の高まりを待つ。")
        if identity in intimate["deflected"] and not self._maho_ready(identity):
            raise GameError("h_ready", "さっき止められた。もう少し様子を見る。")
        if ready_needed and identity not in REVIVE:
            ensure(player["refractory"] == 0, "h_player", "出したばかりで、今はまだ動けない。")
        if identity in FINISH:
            ensure(player["arousal"] >= rules.raw["player"]["finish_from"], "h_player", "まだ出すほど高まっていない。")
        if identity == "h_endure":
            # v8.2.7（精査 A-03・D-7）：まだ限界でないときと、この山でこらえたあとを分ける
            ensure(player["arousal"] >= rules.raw["player"]["arousal_max"], "h_limit", "限界が来たときに選べる。")
            ensure(endure_left, "h_limit", "この山ではもうこらえられない。")
        if identity == "h_wipe":
            ensure(intimate["mess"] is not None, "h_state", "出したあとに選べる。")
        # v8.2.29：仕事の始まりは締め切り（_session_deadline）で区切るので、ここでは起きていられる時間だけを見る
        advancing, self._work_advancing = getattr(self, "_work_advancing", False), rules.deadline_close is not None or getattr(self, "_work_advancing", False)
        try:
            self.require_time(action["minutes"])
        finally:
            self._work_advancing = advancing
        return action

    def _deflect(self, meaning, identity):
        """真帆が止める（h.deflect.*）。止めた行動を覚え、1分進める。止められた1分で締め切りに達したときも、締め切りの一言を出す（v8.0.5、監査 E-03・A-05）。"""
        rules, intimate = self.ir, self.s["intimacy"]
        self.emit(meaning)
        if identity not in intimate["deflected"]: intimate["deflected"].append(identity)
        old_wrap, deadline = intimate["wrap_up"], self._session_deadline()
        self._charge_intimacy(1)
        self._deadline_step(old_wrap, deadline)
        self._recover_step()

    def _work_verb(self):
        """v8.2.29：仕事の締め切りの言い方。その日の最初の仕事の前は「行く」、昼休みのあとは「戻る」。"""
        from .progression import day_time
        life = self.pack.life
        now = day_time(self.now)
        blocks = sorted(life.blocks, key=lambda b: b["start_minute"])
        current = next((b for b in blocks if b["start_minute"] <= now < b["end_minute"]), None) or next((b for b in blocks if b["start_minute"] > now), None)
        return "行く" if current is None or current is blocks[0] else "戻る"

    def _close_grace(self):
        """v8.2.29：いまの残りの手が、もうすぐ達しそうで延ばしたものか（この回の最後の締め切りの一言で見る。保存の形は変えない）。"""
        for item in reversed(self.s["recent_text"]):
            meaning = self.repo.get(item["release"]).by_text[item["id"]]["meaning"]
            if meaning.startswith(("h.ended.", "h.begin.")) or not meaning.startswith(("h_", "h.")):
                return False
            if meaning == "h.deadline" or meaning.startswith("h.deadline."):
                return meaning in ("h.deadline.close", "h.deadline.work_close")
        return False

    def _deadline_step(self, old_wrap, deadline, done=False):
        """締め切りに達した手で、締めくくりの一言と残りの手（wrap_up）。締め切りのあとは残りを1つ減らす。
        v8.2.29（ユーザー 2026-09-30）：昼は仕事の始まりも締め切り（h.deadline.work）。達した時点で真帆が「もうすぐ」か、こちらが出せる高さなら、
        deadline_close.grace_actions 手まで延ばす（h.deadline.close・h.deadline.work_close）。延ばしたあとに達した・出した手で、残りは0。"""
        rules, intimate = self.ir, self.s["intimacy"]
        at, work = deadline
        if old_wrap is None and self.now >= at:
            # v8.2.33（確かめ役 1）：延ばすのは、残りの手で果てる道が続いているときだけ（v8.2.32 で、締め切りのあとは新しい行為を始めないため）。
            # v8.2.34（総ざらい 1）：道は一覧で持たず、行為から求める。真帆：入れている、または真帆の高まりの上限が達する高さに届く行為。
            # こちら：入れている、または果てる選択肢のある行為（手・口・胸・足・素股・舐め合う。自分で高めるは果てる選択肢がないので入れない）。
            active = {c["action_id"] for c in self.s["contacts"]}
            climax_at = rules.raw["maho"]["climax_at"]
            maho_way = intimate["inserted"] or any(rules.actions[key]["effects"].get("maho_arousal_cap", 0) >= climax_at for key in active if key in rules.actions)
            player_way = intimate["inserted"] or bool(active & set(SERVICE_CONTACT.values()))
            close = (rules.deadline_close is not None and not done
                     and ((rules.band(intimate["maho"]["arousal"]) == "near" and maho_way)
                          or (intimate["player"]["arousal"] >= rules.raw["player"]["finish_from"] and player_way)))
            meaning = ("h.deadline.work_close" if close else "h.deadline.work") if work else ("h.deadline.close" if close else "h.deadline")
            if meaning not in self.pack.meanings:
                meaning, close = "h.deadline", False
            self.emit(meaning)
            intimate["wrap_up"] = rules.deadline_close["grace_actions"] if close else rules.raw["nights"]["grace_actions"]
        elif old_wrap is not None:
            intimate["wrap_up"] = 0 if done else max(0, old_wrap - 1)

    def _maho_ready(self, identity):
        """真帆の高まりが、その行動を止めない段にあるか（needs.maho_ready。なければ止めない）。
        v8.2.25（精査 A-2）：ねだったあと（高まりがねだる高さのまま）は、入れる・一気に奥まで入れるを止めない
        （「早く、奥までちょうだい」の次の手で「奥はもう少し、ほぐれてから」と止めていた。淫乱度でねだる高さが「高い」より下がるため）。"""
        rules, intimate = self.ir, self.s["intimacy"]
        ready = rules.actions[identity]["needs"]["maho_ready"]
        if not ready or ORDER[rules.band(intimate["maho"]["arousal"])] >= ORDER[ready]:
            return True
        beg_from = self._lewd("beg_arousal", rules.raw["maho"]["arousal_bands"]["high_from"])
        # v8.2.26（ユーザー了承 2026-09-30）：ねだったあとは「激しく」も止めない（「全部欲しい」の直後に「激しいのはまだ」と言っていた）
        return identity in INSERTS + ("h_move_fast",) and intimate["begged"] and intimate["maho"]["arousal"] >= beg_from

    def _active_extras(self):
        """いま効いている追加（その行為が続いているものだけ）。v8.2.9。"""
        intimate = self.s["intimacy"]
        active = {c["action_id"] for c in self.s["contacts"]}
        return [name for key, name in EXTRA_NAME.items() if name in intimate["extras"] and any(base in active for base in EXTRAS[key])]

    def _calm_hand(self, identity, old_arousal):
        """v8.4.5（010）：刺激のない手（撫でる・頬・手をつなぐ・体位を変える・話す など。settings.calm.actions）。
        A：その手では真帆の高まりの段を上げない（段の境目の手前で止める。合図も出ない）。
        B：入れておらず、ほかに続いている刺激（胸・指・口など）もない刺激のない手が settle_after 手続いたら（neutral の手＝体位を変える・話すは数えない）、高まりを一段下げる
           （段の境目の手前まで。floor の段より下へは下げない）。何も触れていないのに「達しかける」が出ないように。"""
        rules, intimate = self.ir, self.s["intimacy"]
        maho, calm = intimate["maho"], rules.calm
        if identity not in calm["actions"]:
            intimate["calm"] = 0
            return
        bars = rules.raw["maho"]["arousal_bands"]
        starts = {"mid": bars["mid_from"], "high": bars["high_from"], "near": bars["near_from"]}
        band = rules.band(old_arousal)
        upper = {"low": "mid", "mid": "high", "high": "near"}.get(band)
        if upper:
            maho["arousal"] = min(maho["arousal"], max(old_arousal, starts[upper] - 1))
        stimulated = intimate["inserted"] or any(c["action_id"] in rules.actions and c["action_id"] not in calm["actions"]
                                                 and rules.actions[c["action_id"]]["category"] != "position" for c in self.s["contacts"])
        if stimulated:
            intimate["calm"] = 0
        elif identity not in calm["neutral"]:  # 体位を変える・話すは、数えも打ち切りもしない（移るあいだに冷めない）
            intimate["calm"] = min(10, intimate.get("calm", 0) + 1)
        band = rules.band(maho["arousal"])
        if intimate.get("calm", 0) >= calm["settle_after"] and ORDER[band] > ORDER[calm["floor"]]:
            maho["arousal"] = starts[band] - 1
            maho["band"] = min(maho["band"], rules.band(maho["arousal"]), key=ORDER.get)
            intimate["calm"] = 0

    def _insert_needs_only_position(self, identity):
        """入れる行動で、服と慣れはそろっていて、今の体位だけが合わないか（v8.2.8、限界のあいだの体位の変更）。"""
        rules, intimate = self.ir, self.s["intimacy"]
        action = rules.actions[identity]
        if intimate["position"] in action["positions"] or TIERS[rules.tier(self.s["intimacy_history"]["count"], self.pack.life)] < TIERS[action["needs"]["tier_from"]]:
            return False
        for actor in ("maho", "player"):
            for layer, choices in action["needs"][actor + "_clothing"].items():
                if self.s["actors"][actor]["clothing"][layer] not in choices:
                    return False
        return True

    def _overflow_target(self, identity):
        """B2：高まり100で動き・真帆の手や口を続けると、その代わりにする出す行動。なければ None。"""
        rules, intimate = self.ir, self.s["intimacy"]
        target = rules.b2["overflow"].get(identity)
        if not target or intimate["player"]["arousal"] < rules.raw["player"]["arousal_max"]:
            return None
        if identity in MOVES and not intimate["inserted"]:
            return None
        try:
            # v8.2.4：限界のまま入れる（h_insert）は、入れることそのものが選べるかを確かめる（出すのは入れたあと）
            self.intimacy_eligibility(identity if identity in INSERTS else target, "player", overflow=True)
        except GameError:
            return None
        return target

    def _shape_hint(self, identity):
        """体位・服・つながり・余韻の条件が合わないとき、何をすれば選べるかの説明（v8.0.8、試運転の指摘）。合っていれば None。

        B2：抜く → 体位を変える → 服 → つながる の順に出し、服を変える行動がその体位で選べるかも見る（検査役G2 L-1）。
        """
        rules, intimate = self.ir, self.s["intimacy"]
        action = rules.actions[identity]
        needs = action["needs"]
        tier = TIERS[rules.tier(self.s["intimacy_history"]["count"], self.pack.life)]
        usable = {key: row for key, row in rules.actions.items() if not row["offer_only"] and TIERS[row["needs"]["tier_from"]] <= tier}
        if action["sets"]["position"] and action["sets"]["position"] == intimate["position"] and intimate["position"] not in action["positions"]:
            return "今はこの体位になっている。"
        if needs["inserted"] is True and not intimate["inserted"] and identity not in ("h_insert", "h_lead_takein"):
            # v8.2.1（別係 H-01）：入れていないときの動く・出す・抜く・こらえるは、「ゆっくり入れる」に要る手順（服・体位）をそのまま出す
            insert = self._shape_hint("h_insert")
            join = "「" + rules.actions["h_insert"]["label"] + "」でつながる"
            if "h_insert" in intimate["deflected"] and not self._maho_ready("h_insert"):
                join += "（さっき止められたので、真帆の高まりを待ってから）"  # v8.2.7（精査 D-2）
            if insert is None:
                return "先に" + join + "。"
            if insert.startswith("先に") and insert.endswith("。"):
                return insert[:-1] + "、" + join + "。"
            return insert
        current = intimate["position"]

        def clothing_steps(where):
            """体位 where で選べる行動だけで、服をたどる（最短）。たどれない層があれば None。"""
            steps = []
            for actor in ("maho", "player"):
                for layer, choices in needs[actor + "_clothing"].items():
                    state0 = self.s["actors"][actor]["clothing"][layer]
                    if state0 in choices:
                        continue
                    queue, seen, path = [(state0, [])], {state0}, None
                    while queue:
                        state, route = queue.pop(0)
                        if state in choices:
                            path = route
                            break
                        for row in usable.values():
                            if where not in row["positions"]:
                                continue
                            target = row["sets"][actor + "_clothing"].get(layer)
                            allowed = row["needs"][actor + "_clothing"].get(layer)
                            if target and target not in seen and (allowed is None or state in allowed):
                                seen.add(target)
                                queue.append((target, route + [row["label"]]))
                    if path is None:
                        return None
                    steps.append("→".join("「" + label + "」" for label in path))
            return steps

        targets = [current] if current in action["positions"] else [p for p in action["positions"]]
        if current in targets:
            targets += [p for p in action["positions"] if p != current]
        chosen = None
        for where in targets:
            cloth = clothing_steps(where)
            if cloth is None:
                continue
            if where == current:
                chosen = (where, cloth, None)
                break
            moves = [row["label"] for row in usable.values() if row["sets"]["position"] == where and current in row["positions"]]
            if moves:
                chosen = (where, cloth, moves[0])
                if current not in action["positions"]:
                    # 行動がその体位で選べないときは、選べる体位を並べる（これまでと同じ出し方）
                    options = [row["label"] for row in usable.values() if row["sets"]["position"] in action["positions"] and current in row["positions"]
                               and clothing_steps(row["sets"]["position"]) is not None]
                    chosen = (where, cloth, "か".join("「" + label + "」" for label in dict.fromkeys(options)) if options else "「" + moves[0] + "」")
                else:
                    chosen = (where, cloth, "「" + moves[0] + "」")
                break
        if chosen is None:
            return "今の服や体位ではできない。"
        where, cloth, move = chosen
        steps = []
        if intimate["inserted"] and (needs["inserted"] is False or move):
            steps.append("「" + rules.actions["h_withdraw"]["label"] + "」")
        here = clothing_steps(current) if move else None
        if here is not None:
            steps += here  # 服は今の体位で変えられるなら先に（これまでの出し方）
            steps.append("体位を" + move + "にする")
        else:
            if move:
                steps.append("体位を" + move + "にする")
            steps += cloth
        if needs["inserted"] is True and not intimate["inserted"]:
            steps.append("「" + rules.actions["h_insert"]["label"] + "」でつながる")
        if steps:
            return "先に" + "、".join(steps) + "。"
        if needs["after"] and not intimate["after"]:
            return "出した後か、真帆が達した後の余韻の中で選べる。"
        return None

    def intimacy_action(self, identity, origin="player"):
        rules, intimate = self.ir, self.s["intimacy"]
        if (origin == "player" and intimate is not None and rules.limit_caress is not None and identity in rules.actions
                and rules.actions[identity]["category"] in ("kiss", "caress") and intimate["player"]["arousal"] >= rules.raw["player"]["arousal_max"]):
            # v8.2.29（ユーザー 2026-09-30「限界でも愛撫とかはできるんじゃ？」）：限界のまま口づけ・愛撫をしても、真帆の手や真帆の動きは続くので、こらえきれずに出る
            self.intimacy_eligibility(identity, origin)  # 選べる愛撫か（体位・服）を先に確かめる
            active = {c["action_id"] for c in self.s["contacts"]}
            # 頭をなでるときは、真帆がしてくれている行為（口・胸も）が続く（v8.2.14 の設計。確かめ役 F-2）
            sources = LIMIT_STIMULATION + (tuple(rules.stroke["lead_actions"]) if identity == "h_stroke_head" and rules.stroke else ())
            for source in dict.fromkeys(sources):
                target = self._overflow_target(source) if source in active else None
                if target:
                    text = "h_overflow.maho_move" if source == "h_maho_move" and "h_overflow.maho_move" in self.pack.meanings else OVERFLOW_TEXT[target]
                    if source == "h_maho_mouth" and intimate["paces"].get("h_maho_mouth") == "slow" and "h_overflow.mouth_slow" in self.pack.meanings:
                        text = "h_overflow.mouth_slow"
                    return self._act(target, origin, text)
            self._limit_caress = True
            try:
                return self._act(identity, origin)
            finally:
                self._limit_caress = False
        target = self._overflow_target(identity) if origin == "player" and self.s["intimacy"] is not None else None
        if target and identity in INSERTS:
            return self._overflow_insert(identity, origin)
        if target:
            # こらえきれずに出る（B2、ユーザー決定）：選んだ行動の代わりに、出す行動の効果と専用の本文。
            text = OVERFLOW_TEXT[target]
            if identity == "h_maho_move" and "h_overflow.maho_move" in self.pack.meanings:
                text = "h_overflow.maho_move"  # v8.2.14：真帆の動きで、こらえきれずに
            return self._act(target, origin, text)
        inserted_before = self.s["intimacy"] is not None and self.s["intimacy"]["inserted"]
        result = self._act(identity, origin)
        if identity in (*INSERTS, "h_lead_takein") and not inserted_before:
            self._maho_led_starts()
        return result

    def _maho_led_starts(self):
        """v8.3.3（依頼 B）：真帆が申し出て上になった・自分から入れた回は、入れた時点で真帆の動き（h_maho_move）がそのまま始まる（010 の設定 maho_led_moves）。
        最初の本文は、申し出のあとの専用の本文（o34.h_maho_move.*.led.*、条件 intimacy.maho_led_fresh）。速さを変えられるよう、速さの的にする。"""
        rules, intimate = self.ir, self.s["intimacy"]
        if not rules.settings.get("maho_led_moves") or intimate is None or not intimate["inserted"] or not rules.maho_led(self.s):
            return
        if any(c["action_id"] == "h_maho_move" for c in self.s["contacts"]) or self.s["offer"]:
            return
        try:
            self.intimacy_eligibility("h_maho_move", "player")
        except GameError:
            return  # 入れた途端に出た・体位が合わない などは始めない
        phase = self.action("h_maho_move", "player", "private", emit_text=False)
        meaning = "h_maho_move.first" if phase == "first" and self.pack.has_authored("h_maho_move.first", self.pack.registry.values(self.s)) else "h_maho_move.start"
        self.emit(meaning)
        intimate["pace_focus"] = "h_maho_move"

    def _overflow_insert(self, identity, origin):
        """v8.2.4（ユーザーの要望）：限界のまま入れると、入れた途端にこらえきれずに中で出る。
        入れる行動の効果（止められたら入れない）のあとに、中で出す行動の効果と専用の本文（h_overflow.insert）。入れる本文と合図は出さない。"""
        intimate = self.s["intimacy"]
        before, wrap_before, climaxes_before = len(self.events), intimate["wrap_up"], intimate["maho"]["climaxes"]
        self._act(identity, origin)
        if not intimate["inserted"]:
            return  # 真帆に止められた（h.deflect.insert・h.deflect.deep）
        # v8.2.7（精査 A-05・A-06・C-17・F-2）：入れる手の本文・合図・達する・締め切りの一言は出さず、果てる本文のあとへ回す
        first = self.events[before:]
        self.events[before:] = [e for e in first if not e["meaning"].startswith((identity + ".", "h.sign.", "h.climax.", "h.deadline"))]
        if any(e["meaning"] == "h.deadline" or e["meaning"].startswith("h.deadline.") for e in first):
            intimate["wrap_up"] = wrap_before  # 締め切りは出す手で判定し直す（一言は果てる本文のあと）
        climaxed = intimate["maho"]["climaxes"] > climaxes_before
        mid = len(self.events)
        text = "h_overflow.insert_deep" if identity == "h_insert_deep" and "h_overflow.insert_deep" in self.pack.meanings else "h_overflow.insert"
        self._act("h_finish_inside", origin, text)
        self.events[mid:] = [e for e in self.events[mid:] if not e["meaning"].startswith("h.sign.")]
        if climaxed and not any(e["meaning"].startswith("h.climax.") for e in self.events[mid:]):
            # 入れた途端に真帆も達した：二人いっしょの本文を、果てる本文のすぐあとに出す。次の1手は敏感さ
            at = next(i for i in range(mid, len(self.events)) if self.events[i]["meaning"] == text) + 1
            self.emit("h.climax.together")
            self.events.insert(at, self.events.pop())
            intimate["maho"]["sensitive"] = True

    def _act(self, identity, origin, overflow_text=None):
        try:
            return self._act_inner(identity, origin, overflow_text)
        finally:
            self._prune_paces()
            if self.s["intimacy"] is not None:
                self.s["intimacy"].pop("finish_outcome", None)  # v8.4.7（010）：その手の本文の条件にだけ使う（保存には残さない）

    def _prune_paces(self):
        """v8.2.13：続いていない行為の速さを消す（読み手の指摘 M-1）。"""
        intimate = self.s["intimacy"]
        if intimate is None:
            return
        active = {c["action_id"] for c in self.s["contacts"]}
        intimate["paces"] = {key: value for key, value in intimate["paces"].items() if key in active}
        if intimate["pace_focus"] not in active:
            intimate["pace_focus"] = None
        if "sides" in intimate:
            intimate["sides"] = {key: value for key, value in intimate["sides"].items() if key in active}  # v8.2.29：終えた行為の左右は消す

    def _act_inner(self, identity, origin, overflow_text=None):
        action = self.intimacy_eligibility(identity, origin, overflow=bool(overflow_text))
        rules = self.ir
        intimate = self.s["intimacy"]
        # v8.2.13：終わった行為の速さは消す（また始めたら「ふつう」から）
        active_now = {c["action_id"] for c in self.s["contacts"]}
        intimate["paces"] = {key: value for key, value in intimate["paces"].items() if key in active_now}
        if intimate["pace_focus"] not in active_now:
            intimate["pace_focus"] = None
        mouth_slow = intimate["paces"].get("h_maho_mouth") == "slow"  # 舌だけで舐めてもらっていたところから出す（読み手の指摘 M-7）
        facing_before = rules.facing(self.s)  # v8.2.14：こらえる前の向き（脚のあいだにいた真帆は撫で返さない。読み手の指摘 S-6）
        maho_moving = "h_maho_move" in active_now
        stroke_uses_before = intimate["satisfaction_uses"].get("h_stroke_head", 0)
        needs, effects, sets = action["needs"], action["effects"], action["sets"]
        before_band = rules.band(intimate["maho"]["arousal"])
        sensitive, intimate["maho"]["sensitive"] = intimate["maho"]["sensitive"], False  # 達した直後の1手だけ（v8.2.3）
        if identity == "h_stroke_head":
            intimate["maho"]["sensitive"] = sensitive  # 撫でるだけでは「達した直後の1手」を使わない（v8.2.14 読み手の指摘 S-8）
        # 続けている動き（真帆が達した直後の「激しく動き続ける」など）は止めない（v8.0.5、監査 B-008・F-15）。
        continuing = any(c["action_id"] == identity for c in self.s["contacts"])
        if not continuing and not self._maho_ready(identity):
            kind = next(kind for kind, ids in rules.raw["deflect"].items() if identity in ids)
            self._deflect("h.deflect." + kind, identity)
            return
        if needs["maho_ready"] and identity in intimate["deflected"]:
            intimate["deflected"].remove(identity)
        if rules.move_before and identity in ("h_move_slow", "h_move_normal", "h_move_fast") and not continuing:
            # v8.4.2（010）：速さを変えた最初の本文が、上げたのか落としたのか（ふつうの速さの「速さを一段上げる」本文を、速いところから落としたときに出さない）
            intimate["move_before"] = next((key[7:] for key in ("h_move_slow", "h_move_normal", "h_move_fast") if key in active_now), "none")
        old_wrap = intimate["wrap_up"]
        deadline = self._session_deadline()  # v8.2.29：昼は仕事の始まりも
        old_deadline = deadline[0]
        # 口での愛撫・奉仕は、ほかの行動を選んだら終えて向き合う形に戻る（B2 仕様 第4節。検査役G2 M-1）
        keep = {identity} | ({SERVICE_CONTACT[identity]} if identity in SERVICE_CONTACT else set()) | set(EXTRAS.get(identity, ()))  # v8.2.9：胸・足と追加も
        if identity == "h_stroke_head" and rules.stroke:
            keep |= set(rules.stroke["lead_actions"])  # v8.2.14：撫でても、真帆がしてくれている行為は続く
        keep |= set(rules.keep_service.get(identity, ()))  # v8.4.0（010）：手をつなぐ・頬に触れるでは、口でしてもらう・口で愛撫するは続く
        # v8.2.3：入れていないときにこらえたら、止めてもらったのが手か口かで本文を分ける（こらえると真帆の手・口は止まる。actions の replaces）
        endure_out = None
        # v8.2.8：入れていない限界で体位を変えるときは、真帆の手・口を止めてもらい、専用の本文（h_limit_move）を出す
        limit_move = (action["category"] == "position" and not intimate["inserted"] and intimate["player"]["arousal"] >= rules.raw["player"]["arousal_max"]
                      and "h_limit_move.start" in self.pack.meanings)
        if limit_move:
            self.s["contacts"] = [c for c in self.s["contacts"] if c["action_id"] not in SERVICE_CONTACT.values()]
        if identity == "h_endure" and intimate["inserted"] and maho_moving and "h_endure.maho_move" in self.pack.meanings:
            endure_out = "h_endure.maho_move"  # v8.2.14：真帆に動いてもらっていて、こらえる（止めてもらう。読み手の指摘 S-1）
        if identity == "h_endure" and not intimate["inserted"]:
            active = {c["action_id"] for c in self.s["contacts"]}
            # v8.2.9：素股・胸・足でしてもらっていたときも、それに合わせた本文にする（なければ手の本文）
            kind = next((k for k, key in (("sixty_nine", "h_sixty_nine"), ("mouth", "h_maho_mouth"), ("breasts", "h_maho_breasts"), ("feet", "h_maho_feet"), ("sumata", "h_sumata")) if key in active), "hand")
            if kind == "hand" and "h_maho_hand" not in active and "h_endure.none" in self.pack.meanings:
                kind = "none"  # v8.4.2（010）：何もしてもらっていないときにこらえる（手の本文は「真帆の手を止める」書き方。四つん這いで出ていた）
            endure_out = "h_endure." + kind if "h_endure." + kind in self.pack.meanings else "h_endure.hand"
        # v8.2.9：胸・足でしてもらうのも、口と同じく、ほかの行動を選んだら終える（真帆の体勢が変わるため）
        self.s["contacts"] = [c for c in self.s["contacts"] if c["action_id"] not in ("h_player_mouth", "h_maho_mouth", "h_maho_breasts", "h_maho_feet", "h_face_lick", "h_sixty_nine") or c["action_id"] in keep]
        limit_caress = getattr(self, "_limit_caress", False)
        if limit_caress:
            # v8.2.29：限界で口づけ・愛撫に移るときは、こちらの動き（動く・素股・自分で高める）を止める
            self.s["contacts"] = [c for c in self.s["contacts"] if c["action_id"] not in ("h_move_slow", "h_move_normal", "h_move_fast", "h_sumata", "h_self")]
        intimate["extras"] = self._active_extras()  # 続けている行為が終わった追加は消す（v8.2.9）
        extras_before = list(intimate["extras"])
        side_change = None
        if identity in rules.sides:
            # v8.2.29（ユーザー 2026-09-30）：胸に触れる左右。touch.<行為> は既定（手は両方、口は右）、side.<行為>.<左右> はその側
            default = rules.default_side(self.s, identity)  # v8.4.0：手をつなぐは向きで既定が変わる
            side = getattr(self, "_chosen_side", None) or default
            current = intimate.get("sides", {}).get(identity, default)
            if identity in active_now and current != side:
                side_change = side
            sides = {key: value for key, value in intimate.get("sides", {}).items() if key != identity}
            if side != default or identity in rules.side_defaults or rules.one_hand_busy(self.s, identity):
                sides[identity] = side  # v8.4.0：向きで既定が変わる行為は、体位を変えても持ち替えないよう、いつも残す。v8.4.2：片手で触れた側も、手が空いても残す
            if sides or "sides" in intimate:
                intimate["sides"] = sides
        last_at = self.s["experience"][identity]["last_at"]
        again = last_at is not None and last_at >= intimate["started_at"]  # v8.2.34（総ざらい 10）：この回にもうしたか（下の action で今の時刻になる前に見る）
        phase = self.action(identity, origin, "private", emit_text=False)
        if sets["position"]:
            intimate["paces"] = {}  # v8.2.13：体を組み替えたら、速さは「ふつう」から（読み手の指摘 M-2）
            position = sets["position"]
            if rules.position_from:
                intimate["position_from"] = intimate["position"]  # v8.4.3（010）：移る前の体位（体位を移る本文の条件 intimacy.position_from・facing_from）
            intimate["position"] = position
            for actor, posture in rules.positions[position]["postures"].items():
                self.s["actors"][actor]["posture"] = posture
            self.s["contacts"] = [c for c in self.s["contacts"] if c["action_id"] == identity or c["action_id"] not in rules.actions or position in rules.actions[c["action_id"]]["positions"]]
            # v8.4.1（010）：体を組み替えるので、手をつなぐ・抱きしめるなどは終える（体位を移る本文は、真帆が手をつく・こちらが腰を支える書き方が多い）
            self.s["contacts"] = [c for c in self.s["contacts"] if c["action_id"] == identity or c["action_id"] not in rules.position_stops]
        if identity in rules.action_stops:
            stopped = [c["action_id"] for c in self.s["contacts"] if c["action_id"] in rules.action_stops[identity]]
            self.s["contacts"] = [c for c in self.s["contacts"] if c["action_id"] not in rules.action_stops[identity]]  # v8.4.2（010）：上の服を脱ぐ・脱がせるなら、手をつなぐなどを終える
            if stopped and rules.release:
                self.contact_released(stopped, identity)  # v8.4.5（010）：ほどく一言
        if rules.action_facings:
            # v8.4.0（010）：向きが変わって届かなくなった触れ合いは終える（口でしてもらい始めたら、抱きしめる・背中を撫でる・両手をつなぐは終える。
            # 胸や足でしてもらう・顔にまたがる・舐め合うでは、手をつなぐも終える）。体位で届かなくなるのは上の positions で終える
            facing_now = rules.facing(self.s)
            self.s["contacts"] = [c for c in self.s["contacts"] if c["action_id"] == identity or c["action_id"] not in rules.action_facings or facing_now in rules.action_facings[c["action_id"]]]
        if action["category"] not in ("kiss", "caress", "move", "tease", "grind"):
            # 口づけは、服・体位・つながる・出す・言葉・余韻の行動をはさんだら途切れる（v8.0.5、監査 F-05。B2 で耳元・首筋も）。
            self.s["contacts"] = [c for c in self.s["contacts"] if c["action_id"] not in rules.actions or rules.actions[c["action_id"]]["category"] != "kiss"]
        if action["category"] == "after":
            # 抱きしめて休むときは、口や手での愛撫・奉仕を終える（B2）。
            # v8.2.21：抱きしめて休む・拭くを選んだら、胸に顔を埋める・甘えて吸うも終える（顔を上げる）
            # v8.2.22：脚を絡めるは、抱きしめて休む・顔を埋める・甘えて吸うと同時にできる（拭くでは終える）
            ends = AFTER_ENDS.get(identity, ())
            # v8.2.30（通し確かめ 10）：余韻に入ったら、動く・指で触れる・焦らす行為も終える（休んでいるのに「動いてもらう」が続いていた）
            self.s["contacts"] = [c for c in self.s["contacts"] if c["action_id"] not in MOUTH_AND_SERVICE and c["action_id"] not in ends and c["action_id"] not in AFTER_STOPS + rules.after_stops]
            intimate["paces"] = {key: value for key, value in intimate["paces"].items() if key not in AFTER_STOPS}  # v8.4.0：rules.after_stops（010：抱きしめる・背中・両手）
        inserted_before = intimate["inserted"]
        for actor in ("maho", "player"):
            self.s["actors"][actor]["clothing"].update(sets[actor + "_clothing"])
        if sets["inserted"] is not None:
            intimate["inserted"] = sets["inserted"]
            if not intimate["inserted"]:
                self.s["contacts"] = [c for c in self.s["contacts"] if c["action_id"] not in MOVES + rules.inserted_stops]  # v8.4.1：腕を引く・引き寄せて抱きしめるも
        self._charge_intimacy(action["minutes"])
        if action["category"] not in ("after", "words", "position") and identity not in ("h_withdraw", "h_stroke_head"):  # v8.2.14：撫でるだけでは余韻は続く
            intimate["after"] = False  # 抜く・体位を変える・拭くでは余韻は続く（v8.2.7、精査 C-01）
            # v8.2.22：余韻が終わったら、続いていた余韻の行為（顔を埋める・甘えて吸う・脚を絡める）も終える
            self.s["contacts"] = [c for c in self.s["contacts"] if c["action_id"] not in rules.actions or rules.actions[c["action_id"]]["category"] != "after"]
        maho, player = intimate["maho"], intimate["player"]
        tier = rules.tier(self.s["intimacy_history"]["count"], self.pack.life)
        # v8.2.13：速さを変えられる行為は、頼んだ速さで高まる（真帆は帯ごとの割合、こちらは player_percent）
        pace_target = rules.pace["actions"].get(identity) if rules.pace else None
        own_pace = intimate["paces"].get(identity, "normal") if pace_target else None
        gain, pace = rules.maho_gain(effects["maho_arousal"], tier, before_band, own_pace if pace_target in ("maho", "both") else action["pace"])
        old_arousal = maho["arousal"]
        maho["arousal"] = min(effects["maho_arousal_cap"], maho["arousal"] + gain) if maho["arousal"] < effects["maho_arousal_cap"] else maho["arousal"]
        if rules.calm:
            self._calm_hand(identity, old_arousal)
        if phase in ("first", "start") and intimate["satisfaction_uses"].get(identity, 0) < effects["satisfaction_per_session"]:
            added = effects["satisfaction"]
            if tier == "first" and action["heart"]:
                added = added * rules.raw["maho"]["first_heart_percent"] // 100
            maho["satisfaction"] = min(100, maho["satisfaction"] + added)
            intimate["satisfaction_uses"][identity] = intimate["satisfaction_uses"].get(identity, 0) + 1
        if self.s["stamina"]["value"]:
            # 入れていないときの上限は、真帆の手・口では当てない。自分で高めるだけでは self_cap まで（B2）。
            if intimate["inserted"] or action["category"] in ("service", "grind", "mutual"):
                limit = rules.raw["player"]["arousal_max"]
            elif action["category"] == "self":
                limit = rules.b2["self_cap"]
            else:
                limit = rules.raw["player"]["cap_not_inserted"]
            if player["arousal"] < limit and not (player["refractory"] > 0 and identity in REVIVE):  # v8.2.34：回復を待つあいだの口・手では、高まりはまだ上がらない
                # v8.2.9：追加（先端を舐める・玉を揉む）が効いている行為は、こちらの高まりが少し強く上がる
                bonus = rules.b2["requests"]["extra_bonus"] if any(identity in EXTRAS[key] and EXTRA_NAME[key] in extras_before for key in EXTRAS) else 0
                added = effects["player_arousal"] * (rules.pace["player_percent"][own_pace] if pace_target in ("player", "both") else 100) // 100
                player["arousal"] = min(limit, player["arousal"] + added + bonus)
        if limit_caress and not intimate["inserted"]:
            player["arousal"] = rules.raw["player"]["arousal_max"] - rules.limit_caress["cool"]  # v8.2.29：何もされていなければ、少し落ち着く
        if identity == "h_withdraw" and player["arousal"] >= rules.raw["player"]["arousal_max"]:
            # 限界で抜いたときは、こらえるのと同じところまで落ち着く。抜いたあとに入れ直せる（v8.0.5、監査 B-003・D-02）。
            player["arousal"] = rules.raw["player"]["endure"]["back_to"]
        if identity == "h_endure":
            player["arousal"] = rules.raw["player"]["endure"]["back_to"]
            player["endured"] += 1
            self.s["contacts"] = [c for c in self.s["contacts"] if c["action_id"] not in MOVES]
        spent = False
        if identity in FINISH:
            self.s["stamina"]["value"] -= 1
            spent = self.s["stamina"]["value"] == 0
            player["finishes"] += 1
            player["arousal"], player["endured"] = 0, 0
            player["refractory"] = rules.raw["player"]["refractory_actions"] * player["finishes"]  # v8.2.34（総ざらい 8）：1回目2手、2回目4手、3回目6手
            intimate["after"] = True
            intimate["mess"] = MESS[identity]
        quiet = action["category"] in rules.b2["quiet_sign_categories"]
        if quiet:
            # 真帆がする行動と自分で高めるでは、真帆は達しない（B2）。
            maho["arousal"] = min(maho["arousal"], rules.raw["maho"]["climax_at"] - 1)
        climax = maho["arousal"] >= rules.raw["maho"]["climax_at"]
        if climax:
            maho["climaxes"] += 1
            maho["climax_source"] = "inserted" if inserted_before or intimate["inserted"] else "mouth" if identity in ("h_player_mouth", "h_face_lick", "h_sixty_nine") else "finger"  # 入れた手で達したときも inserted（v8.2.1、別係 H-02）
            maho["satisfaction"] = min(100, maho["satisfaction"] + rules.raw["maho"]["climax_satisfaction"])
            maho["arousal"] = rules.raw["maho"]["after_climax"]
            maho["sensitive"] = True
            intimate["after"] = True
        if rules.afterglow:
            # v8.4.8（010）：真帆が達したら余韻に入る（値は達してからの手数）。min_hands 手を過ぎ、高まりが until_arousal まで戻ったら余韻を出る
            # （中に出すと高まりが一度に 25 上がるので、手数も見る。本文の条件 intimacy.maho.afterglow）
            if climax:
                intimate["afterglow"] = 0
            elif "afterglow" in intimate:
                intimate["afterglow"] = min(10, intimate["afterglow"] + 1)
                if intimate["afterglow"] >= rules.afterglow["min_hands"] and maho["arousal"] >= rules.afterglow["until_arousal"]:
                    del intimate["afterglow"]
        finish = rules.finish_outcome if rules.finish_outcome and identity in rules.finish_outcome["actions"] else None
        if finish:
            # v8.4.7（010）：中に出す手の真帆の結果。果てる本文を選ぶ条件（intimacy.finish_outcome）。達したときは、このあと二人いっしょに達する本文
            band_now = rules.band(maho["arousal"])
            intimate["finish_outcome"] = "climax" if climax else band_now if band_now in ("near", "high") else "rest"
        # 行為の「初めて」の本文は、書いた慣れの段階（初回、または数回）の回でだけ使う。
        # それより慣れた回に初めてする行為は、その回の慣れの「始め」の本文を出す（段階B仕様 改訂2）。
        text_phase = phase
        if phase == "first" and not self.pack.has_authored(identity + ".first", self.pack.registry.values(self.s)):
            text_phase = "start"
        # v8.1.1：「さらに続ける」の本文がない行動（自分で高める）と場面では、「続ける」の本文を出す（仮の本文に落とさない）。
        if phase == "settled" and not self.pack.has_authored(identity + ".settled", self.pack.registry.values(self.s)):
            text_phase = "continue"
        meaning = identity + "." + text_phase
        if again and text_phase == "start" and (identity in AGAIN_TEXT or identity in rules.again_actions) and self.pack.has_authored(identity + ".again", self.pack.registry.values(self.s)):
            meaning = identity + ".again"  # v8.2.34（総ざらい 10）：抱きしめて休むを続けて選ぶと、2回目からは続きの本文
        if pace_target:
            intimate["pace_focus"] = identity
        values_now = self.pack.registry.values(self.s)
        pace_change = getattr(self, "_pace_change", None)
        if pace_change and pace_target and self.pack.has_authored(identity + ".pace_" + pace_change, values_now):
            meaning = identity + ".pace_" + pace_change  # v8.2.13：速さを変えた1手は、その本文（「もっと激しく」と頼む・変える）
        elif pace_target and own_pace != "normal" and text_phase in ("continue", "settled"):  # 追加が効いていても速さの本文を先に（読み手の指摘 R-1）
            # v8.2.13：ゆっくり・激しくのあいだは、その速さで続ける本文（h_maho_mouth_fast.continue など。なければ いつもの本文）
            for variant_phase in dict.fromkeys((text_phase, "continue")):
                variant = identity + "_" + own_pace + "." + variant_phase
                if variant in self.pack.meanings and self.pack.has_authored(variant, values_now):
                    meaning = variant
                    break
        if text_phase in ("continue", "settled") and meaning == identity + "." + text_phase:
            # v8.2.9：追加が効いているときは、追加しながら続ける本文（h_maho_breasts_lick.continue など。なければ いつもの本文）
            values = self.pack.registry.values(self.s)
            for key, name in EXTRA_NAME.items():
                if name not in extras_before or identity not in EXTRAS[key]:
                    continue
                for variant_phase in dict.fromkeys((text_phase, "continue")):
                    variant = identity + "_" + name + "." + variant_phase
                    if variant in self.pack.meanings and self.pack.has_authored(variant, values):
                        meaning = variant
                        break
        revive_now = intimate["player"]["refractory"] > 0  # v8.2.35：回復を待つあいだか（この手の回復を進める前に見る）
        combo = None if revive_now else self._combo(identity)  # v8.2.35（確かめ役 2）：回復を待つあいだは組み合わせの本文（硬さを前提にする）を使わない
        if combo and not meaning.startswith(identity + ".pace_"):
            # v8.2.21（ユーザー 2026-09-29 09:42）：胸を吸いながら手でしてもらう、のように二つが同時に続いているときは、組み合わせの本文
            variant = combo["meaning"] + (".start" if text_phase in ("first", "start") else ".continue")
            if variant in self.pack.meanings and self.pack.has_authored(variant, self.pack.registry.values(self.s)):
                meaning = variant
        if side_change and not meaning.startswith(identity + ".pace_") and self.pack.has_authored(identity + ".side_" + side_change, self.pack.registry.values(self.s)):
            meaning = identity + ".side_" + side_change  # v8.2.29：左右を切り替えた1手
        if identity == "h_stroke_head" and rules.stroke:
            meaning = self._stroke_head(stroke_uses_before)  # v8.2.14：頭をなでる（場面ごとの本文と、真帆がしてくれている行為の熱）
        if revive_now and identity in REVIVE:
            # v8.2.35（確かめ役 2）：回復を待つあいだの手・口・舐め合いは、柔らかいままの専用の本文だけ（速さ・追加・左右の本文よりも先。硬さの語を出さない）
            revive = identity + (".revive_start" if text_phase in ("first", "start") else ".revive")
            if revive in self.pack.meanings and self.pack.has_authored(revive, self.pack.registry.values(self.s)):
                meaning = revive
        chosen = overflow_text or endure_out or ("h_limit_move.start" if limit_move else meaning)
        if mouth_slow and identity == "h_finish_mouth":
            slow_text = {"h_overflow.mouth": "h_overflow.mouth_slow"}.get(chosen, "h_finish_mouth.from_slow" if chosen.startswith("h_finish_mouth.") else None)
            if slow_text and slow_text in self.pack.meanings and self.pack.has_authored(slow_text, self.pack.registry.values(self.s)):
                chosen = slow_text
        chosen = self._combo_finish(identity, active_now, chosen, overflow_text)
        if chosen == meaning:
            chosen = self._short_text(identity, chosen)
        help_kind = _UNDECIDED
        if identity == "h_self" and phase not in ("first", "start") and rules.settings.get("self_offer_replaces_line"):
            # v8.3.3（依頼 A）：この手で真帆の申し出が開くなら、続けている様子の1行は出さず、申し出の本文だけにする
            # （「まだがまんして？」の直後に「口でしようか」が出ていた）。この手で締め切りに達するなら申し出は開かない（_deadline_step と同じ判定）
            help_kind = self._self_help_kind(old_wrap is not None or self.now >= deadline[0])
        if help_kind in (_UNDECIDED, None):
            self.emit(chosen)
        if rules.stroke and identity in rules.stroke["stroke_back"]["after"] and facing_before in rules.stroke["facings"] and facing_before not in ("maho_mouth", "maho_breasts"):
            self._maybe_stroke_back(identity)
        if identity in EXTRAS:
            intimate["extras"] = [name for name in intimate["extras"] if name != EXTRA_NAME[identity]] + [EXTRA_NAME[identity]]
        if identity == "h_wipe":
            intimate["mess"] = None  # 本文は拭く前の state で選ぶ
        calm_hand = bool(rules.calm) and identity in rules.calm["actions"]  # v8.4.5（010）：刺激のない手（手をつなぐ など）では「敏感になっている」一言も出さない
        if sensitive and (action["category"] in SENSITIVE_CATEGORIES or identity in INSERTS) and not climax and identity != "h_stroke_head" and not calm_hand:
            self.emit("h.sign.sensitive")
        new_band = rules.band(maho["arousal"])
        # v8.2.8：焦らして真帆の高まりが「高い」に届いたら、真帆がねだる（1回のエッチで1回。高まりの合図の代わり）
        beg_from = self._lewd("beg_arousal", rules.raw["maho"]["arousal_bands"]["high_from"])  # v8.2.12：大胆になると早くねだる
        beg = (action["category"] == "tease" and not climax and not intimate["begged"] and (ORDER[new_band] >= ORDER["high"] or maho["arousal"] >= beg_from)
               and "h.sign.beg" in self.pack.meanings)
        if climax:
            self.emit("h.climax.together" if identity in FINISH else "h.climax.maho")
            maho["band"] = new_band
        elif beg:
            self.emit("h.sign.beg")
            intimate["begged"] = True
            maho["band"] = max(new_band, maho["band"], key=ORDER.get)
        elif ORDER[new_band] > ORDER[maho["band"]] and quiet:
            maho["band"] = new_band  # 合図は出さない（真帆の反応は行動の本文の中で書く。B2）
        elif ORDER[new_band] > ORDER[maho["band"]] and finish:
            maho["band"] = new_band  # v8.4.7（010）：中に出した手では合図を出さない（果てる本文が真帆の高まりを書く）
        elif ORDER[new_band] > ORDER[maho["band"]]:
            self.emit("h.sign." + new_band)
            maho["band"] = new_band
        else:
            cap_stalled = effects["maho_arousal"] > 0 and old_arousal >= effects["maho_arousal_cap"] and maho["arousal"] == old_arousal
            effective = own_pace if pace_target in ("maho", "both") else action["pace"]  # v8.2.13：頼んだ速さで（読み手の指摘 M-6）
            wants_more = (effective == "slow" and pace <= rules.raw["maho"]["wants_more_pace_at_or_below"] or cap_stalled) and identity != "h_maho_move"  # 速さを決めているのは真帆（v8.2.14 読み手の指摘 S-3）
            # 物足りなさの合図は、口づけ・愛撫・動きを続けているときだけ（v8.0.5、監査 B-002・F-07・F-09）。
            wants_more = wants_more and action["category"] in ("kiss", "caress", "move", "tease", "grind", "mutual") and phase in ("continue", "settled")
            # 締め切りの後（と締め切りに達した手）は、物足りなさの合図を出さない（v8.0.5、監査 F-02）。
            wants_more = wants_more and old_wrap is None and self.now < old_deadline
            # v8.2.25（精査 D-8）：速さを変えた手（「もっと強く」に応えた・変えた手）には出さない。次の続けた手から
            wants_more = wants_more and not pace_change
            recent = [self.repo.get(item["release"]).by_text[item["id"]]["meaning"] for item in self.s["recent_text"][-3:]]
            recent += [item["meaning"] for item in self.events]
            if wants_more:
                self._wants_more(identity, recent)
        self._deadline_step(old_wrap, deadline, done=climax or identity in FINISH)
        if identity not in FINISH:
            self._recover_step(identity)
        if spent and "h.spent" in self.pack.meanings:
            self.emit("h.spent")  # 余力が尽きたことを一言で伝える（v8.0.8）
        if identity == "h_after_hold" and old_wrap == 0:
            # 締め切りの後の「抱きしめて休む」は1回まで。そのまま終える（v8.0.5、監査 D-06）。
            self.intimacy_end()
            return
        if identity == "h_self":
            if help_kind not in (_UNDECIDED, None) and (self.s["offer"] or intimate["wrap_up"] is not None):
                self.emit(chosen)  # 先に決めた申し出が開けなくなったとき（起きない見込み）は、出さなかった1行を出す
            else:
                self._self_reaction(phase, help_kind)
        # 続けている行為が終わった追加は消す（v8.2.9）
        intimate["extras"] = [name for name in intimate["extras"] if name in self._active_extras()]
        if not overflow_text and identity in SERVICE_CONTACT.values() and phase in ("continue", "settled"):
            self._maybe_extra_by_maho(identity)
        self._maybe_lead()
        self._maybe_request_offer()

    def _combo(self, identity):
        """v8.2.21：identity を含む組み合わせで、二つとも続いているもの（なければ None）。"""
        active = {c["action_id"] for c in self.s["contacts"]}
        return next((combo for combo in self.ir.combos if identity in combo["actions"] and all(key in active for key in combo["actions"])), None)

    def _combo_finish(self, identity, active_before, chosen, overflow_text):
        """v8.2.21：組み合わせが続いていたところで出す（<meaning>.finish）・こらえきれずに出る（<meaning>.overflow）本文。"""
        for combo in self.ir.combos:
            if identity != combo["finish"] or not all(key in active_before for key in combo["actions"]):
                continue
            if overflow_text and overflow_text != OVERFLOW_TEXT.get(identity):
                return chosen
            variant = combo["meaning"] + (".overflow" if overflow_text else ".finish")
            if variant in self.pack.meanings and self.pack.has_authored(variant, self.pack.registry.values(self.s)):
                return variant
        return chosen

    def _short_text(self, identity, meaning):
        """v8.2.20（ユーザー 2026-09-29）：続けているあいだは、短い本文（<意味>_short）を出す。長い本文は、続けた手の数が long_every の倍数の手だけ。
        短い本文がない行為・条件と、設定の「続けるときの本文」が long のときは、これまでどおり長い本文。"""
        rules = self.ir
        if not rules.short or not meaning.endswith((".continue", ".settled")):
            return meaning
        # v8.2.29（ユーザー 2026-09-30）：設定「続けるときの本文」はなくした（いつも短い1行。前の保存に long が残っていても短くする）
        active = next((c for c in self.s["contacts"] if c["action_id"] == identity), None)
        every = rules.short["long_every"]
        if active is None or every and active["continues"] % every == 0:
            return meaning
        values = self.pack.registry.values(self.s)
        pat = self._pat_line(meaning, values)
        if pat:
            return pat
        # v8.2.23：短い本文は新しく書いた1行（長い本文とは材料が別）。「さらに続ける」の手も、続ける手と同じ短い1行から選ぶ
        for short in dict.fromkeys((meaning + "_short", meaning.rsplit(".", 1)[0] + ".continue_short")):
            if short in self.pack.meanings and self.pack.has_authored(short, values):
                return short
        return meaning

    def _pat_line(self, meaning, values):
        """v8.2.22（ユーザー 2026-09-29 11:37）：胸に口づけている続きの短い手で、ときどき真帆がこちらの頭を撫でる一行（b2.pat）。続けて2手は出さない。"""
        rules = self.ir
        target = rules.pat["meanings"].get(meaning.split(".")[0]) if rules.pat else None
        if not target or target not in self.pack.meanings or not self.pack.has_authored(target, values):
            return None
        if any(self.repo.get(item["release"]).by_text[item["id"]]["meaning"].startswith("h.pat.") for item in self.s["recent_text"][-2:]):
            return None  # 前の手（とその合図）で撫でたばかり
        tier = rules.tier(self.s["intimacy_history"]["count"], self.pack.life)
        chance = rules.pat["chance_percent"][tier] + rules.pat["lewd_plus"][rules.lewd_band(self.s["intimacy_history"]["lewdness"])]
        roll = int(digest([self.s["world"]["seed"], "pat", self.s["intimacy"]["id"], self.s["world"]["operation_seq"]])[:12], 16) % 100
        return target if roll < chance else None

    def _recover_step(self, identity=None):
        """出したあとの「今はまだ動けない」を1手ぶん進める。解けたら、続けられることを一言で伝える（v8.2.3、回復の合図）。
        v8.2.34：真帆に口・舐め合いでしてもらっている手は2手ぶん進む（REVIVE）。口・手で回復したときは、その一言（h.player.recovered.mouth・hand）。"""
        intimate = self.s["intimacy"]
        player = intimate["player"]
        before = player["refractory"]
        serving = identity in REVIVE and any(c["action_id"] == identity for c in self.s["contacts"])
        player["refractory"] = max(0, before - (REVIVE[identity] if serving else 1))
        if before > 0 and player["refractory"] == 0 and self.s["stamina"]["value"] > 0 and intimate["wrap_up"] is None and "h.player.recovered" in self.pack.meanings:
            meaning = "h.player.recovered." + REVIVE_TEXT[identity] if serving else "h.player.recovered"
            self.emit(meaning if meaning in self.pack.meanings else "h.player.recovered")

    def _self_reaction(self, phase, decided=_UNDECIDED):
        """B2：自分で高めているときの真帆。始めた手は見ている様子、続けた手では手・口の申し出（1回のエッチで1回）。
        decided：v8.3.3（010）で、本文を出す前に決めた申し出（_UNDECIDED なら、ここで決める＝009 と同じ）。"""
        rules, intimate = self.ir, self.s["intimacy"]
        tier = rules.tier(self.s["intimacy_history"]["count"], self.pack.life)
        if phase in ("first", "start"):
            watch = tier == "familiar" or tier == "few" and ORDER[rules.band(intimate["maho"]["arousal"])] >= ORDER["mid"]
            self.emit("h.self.react." + ("watch" if watch else "look_away"))
            return
        kind = self._self_help_kind(intimate["wrap_up"] is not None) if decided is _UNDECIDED else decided
        if kind is None:
            return
        intimate["help_offered"] = True
        self._open_intimacy_offer(kind, HELP_OFFERS[kind][1])

    def _self_help_kind(self, wrapping):
        """自分で高めている続けた手で、真帆が手・口を申し出るか（申し出の種類、なければ None）。wrapping：締め切りの一言を出した・この手で出す。"""
        rules, intimate = self.ir, self.s["intimacy"]
        tier = rules.tier(self.s["intimacy_history"]["count"], self.pack.life)
        offer = rules.b2["help_offer"]
        if intimate["help_offered"] or self.s["offer"] or wrapping or intimate["player"]["arousal"] < offer["min_player_arousal"]:
            return None
        roll = int(digest([self.s["world"]["seed"], "help", intimate["id"], self.s["world"]["operation_seq"]])[:12], 16)
        if roll % 100 >= offer["chance_percent"]:
            return None
        mouth = TIERS[tier] >= TIERS[offer["mouth_tier_from"]] and (roll // 100) % 2 == 1
        kind = "h_help_mouth" if mouth else "h_help_hand"
        try:
            self.intimacy_eligibility(HELP_OFFERS[kind][0], "player")
        except GameError:
            return None
        return kind

    def _stroke_head(self, uses_before):
        """v8.2.14：頭をなでたときの本文の意味。真帆がしてくれている行為があれば、その速さを1段上げる（効き目は1回のエッチで2回まで）。"""
        rules, intimate = self.ir, self.s["intimacy"]
        active = [c["action_id"] for c in self.s["contacts"]]
        limit = rules.actions["h_stroke_head"]["effects"]["satisfaction_per_session"]
        if uses_before >= limit:
            return "h_stroke_head.again"
        if intimate["after"]:
            return "h_stroke_head.after"  # 余韻：熱は入れない（読み手の指摘 M-3）
        lead = next((key for key in rules.stroke["lead_actions"] if key in active), None)
        if lead == "h_maho_move" and intimate["player"]["refractory"] > 0:
            lead = None  # 出したばかりで続けられないときは上げない
        if lead and rules.pace and lead in rules.pace["actions"]:
            order = ["slow", "normal", "fast"]
            pace = intimate["paces"].get(lead, "normal")
            up = order[order.index(pace) + 1] if pace != "fast" else None
            if up == "fast" and lead == "h_maho_move" and not self._maho_ready("h_move_fast"):
                # v8.2.26：真帆がまだ「激しく」を止める高まりなら、嬉しくても激しくはならない（精査 A-8）。
                # v8.2.29（確かめ役 F-12）：そのときは「腰が激しくなる」本文でなく、撫でられて和らぐ本文（again）
                return "h_stroke_head.again"
            if up:
                intimate["paces"][lead] = up  # 嬉しくて、熱が入る
                intimate["pace_focus"] = lead
        if "h_maho_mouth" in active:
            return "h_stroke_head.mouth"
        if "h_maho_breasts" in active:
            return "h_stroke_head.breasts"
        if "h_maho_hand" in active:
            return "h_stroke_head.hand"
        if intimate["inserted"]:
            # 真帆が上で「腰が激しくなる」のは、真帆に動いてもらっているときだけ（読み手の指摘 M-4）
            return "h_stroke_head.maho_top" if "h_maho_move" in active else "h_stroke_head.player_top"
        return "h_stroke_head.kiss"

    def _maybe_stroke_back(self, identity):
        """v8.2.14：抱きしめて休む・こらえるとき、真帆がこちらの頭を撫で返す（1回のエッチで1回）。"""
        rules, intimate = self.ir, self.s["intimacy"]
        back = rules.stroke["stroke_back"]
        if intimate["stroked_back"] or rules.facing(self.s) not in rules.stroke["facings"]:
            return  # 1回のエッチで1回。真帆の手がこちらの頭に届く向きのときだけ
        if self._maho_hands_held():
            return  # v8.4.1（010）：両手をつないでいる・両腕を引いているあいだは、真帆の手が空いていない
        kind = "after" if identity == "h_after_hold" else "endure"
        meaning = "h.stroke_back." + kind
        if meaning not in self.pack.meanings:
            return
        tier = rules.tier(self.s["intimacy_history"]["count"], self.pack.life)
        chance = back["chance_percent"][tier] + back["lewd_plus"][rules.lewd_band(self.s["intimacy_history"]["lewdness"])]
        roll = int(digest([self.s["world"]["seed"], "stroke_back", intimate["id"], self.s["world"]["operation_seq"]])[:12], 16) % 100
        if back["chance_percent"][tier] and roll < chance:
            intimate["stroked_back"] = True
            self.emit(meaning)

    def _lewd(self, key, base=0):
        """v8.2.12：今の淫乱度の段での効き目（intimacy_009.json の b2.lewdness）。"""
        rules = self.ir
        return rules.lewd_value(rules.lewd_band(self.s["intimacy_history"]["lewdness"]), key, base)

    def _request_roll(self, kind):
        return int(digest([self.s["world"]["seed"], "request", kind, self.s["intimacy"]["id"], self.s["world"]["operation_seq"]])[:12], 16) % 100

    def _maybe_extra_by_maho(self, identity):
        """v8.2.9：何回かお願いされた追加は、真帆が自分から始めることがある（1回のエッチで種類ごとに1回）。"""
        rules, intimate = self.ir, self.s["intimacy"]
        req = rules.b2["requests"]
        if intimate["player"]["arousal"] >= rules.raw["player"]["arousal_max"] or self.s["offer"]:
            return
        for key, bases in EXTRAS.items():
            name = EXTRA_NAME[key]
            if identity not in bases or name in self._active_extras() or key in intimate["offered"] or key + ".maho" not in self.pack.meanings:
                continue
            if self._done_this_session(key):
                continue  # v8.2.25（精査 A-4）：この回にもう頼んだ追加は、真帆から「言われる前に」始めない
            # v8.2.12：淫乱度の段で、お願いの回数を減らし、確率を上げる
            if self.s["experience"][key]["count"] < max(1, req["threshold"] - self._lewd("threshold_minus")) or self._request_roll(key) >= req["extra_chance_percent"] + self._lewd("chance_plus"):
                continue
            intimate["offered"].append(key)
            intimate["extras"].append(name)
            self.emit(key + ".maho")
            return

    def _done_this_session(self, key):
        """この回（エッチ）の中で、もうその行動をしたか（経験の最後の時刻が、この回の始まり以後）。v8.2.25。"""
        last = self.s["experience"][key]["last_at"]
        return last is not None and last >= self.s["intimacy"]["started_at"]

    def _maho_hands_held(self):
        """v8.4.1（010）：真帆の両手がふさがっている（両手をつなぐ・両腕を引く）。009 にはこの行為がないので、いつも False。"""
        return any(c["action_id"] in self.ir.actions and {"maho.left_hand", "maho.right_hand"} <= set(c["resources"]) for c in self.s["contacts"])

    def _maybe_request_offer(self):
        """v8.2.9：何回かお願いされた行為（胸・足）は、真帆が自分から申し出ることがある（1回のエッチで種類ごとに1回）。"""
        rules, intimate = self.ir, self.s["intimacy"]
        req = rules.b2["requests"]
        player = intimate["player"]
        if self.s["offer"] or intimate["inserted"] or intimate["wrap_up"] is not None or player["refractory"] > 0 or self._maho_hands_held():
            return
        if not req["offer_min_player_arousal"] <= player["arousal"] < rules.raw["player"]["arousal_max"]:
            return
        if any(c["action_id"] in REQUEST_OFFER_BUSY for c in self.s["contacts"]):
            return  # v8.2.25（精査 A-3）：口づけ・耳元・胸に口づけている最中も出さない（申し出の本文は、真帆が脚のあいだ・向かいへ移る）
        for kind, key in REQUEST_OFFERS.items():
            if kind in intimate["offered"] or self.s["experience"][key]["count"] < max(1, req["threshold"] - self._lewd("threshold_minus")):
                continue
            if self._done_this_session(key):
                continue  # v8.2.25（精査 A-4・C-06）：この回にもうしてもらった行為は申し出ない（「今日は言われる前に」「前に頼まれたの」と食い違う）
            try:
                self.intimacy_eligibility(key, "player")
            except GameError:
                continue
            if self._request_roll(kind) >= req["offer_chance_percent"] + self._lewd("chance_plus"):
                continue
            intimate["offered"].append(kind)
            self._open_intimacy_offer(kind, HELP_OFFERS[kind][1])
            return

    def _wants_more(self, identity, recent):
        """物足りなさの合図。v8.2.24（ユーザー 2026-09-30「直すよ」）：出すたびに間を空け（b2.wants_more.gaps）、回数が重なると焦れた合図
        （h.sign.wants_more_urge）に変える。数は保存に持たず、最近の本文（recent_text）から数える。
        v8.2.26（ユーザー了承 2026-09-30、精査 D-3）：数えるのは「こちらが応えるまで」。胸と口づけを行き来しても数え続ける（待たされている真帆は
        だんだん焦れる）。応えた＝高まりの段が上がった（h.sign.mid・high・near、ねだる）・達した・速さを上げた・入れた。この回の始まりより前は数えない。
        手の数は、合図のあとに続けたエッチの行動の本文（h_*）の数。"""
        config = self.ir.b2.get("wants_more") if self.ir.b2 else None
        signs = WANTS_MORE_SIGNS
        if config is None:
            if not any(is_sign(meaning, signs[:1]) for meaning in recent[-3:]):
                self.emit(signs[0])
            return
        count, steps, since = 0, 0, None
        for item in reversed(self.s["recent_text"]):
            meaning = self.repo.get(item["release"]).by_text[item["id"]]["meaning"]
            if not meaning.startswith(("h_", "h.")) or meaning.startswith(("h.ended.", "h.begin.", "h.sleep_together", "h.morning", "h.decline")):
                break  # この回の外
            if meaning.startswith(("h.climax.", "h.sign.beg")) or is_sign(meaning, ("h.sign.mid", "h.sign.high", "h.sign.near")) or meaning.endswith(".pace_fast"):
                break  # 応えた（高まりが上がった・達した・速さを上げた）
            if meaning.startswith(INSERT_STARTS):
                break  # 入れた
            if is_sign(meaning, signs):
                count += 1
                if since is None:
                    since = steps  # いちばん新しい合図のあとに続けた手の数
            elif meaning.startswith(("h_", "h.pat.")):
                steps += 1  # 胸に口づけている手の「頭を撫でる一行」も、続けた1手
        if count == 0:
            # 応えたあと（数え直した直後）も、前の合図から gaps[0] 手は空ける（「物足りない」→「もうすぐ」→すぐ「物足りない」にしない）
            if self._steps_since_wants_more() + 1 >= config["gaps"][0]:
                self.emit(signs[0])
            return
        gap = config["gaps"][min(count, len(config["gaps"])) - 1]
        if since + 1 < gap:  # いまの手を足して数える
            return
        urge = count >= config["urge_from"] and self.pack.has_authored(signs[1], self.pack.registry.values(self.s))
        self.emit(signs[1] if urge else signs[0])

    def _steps_since_wants_more(self):
        """この回の中で、いちばん新しい物足りなさの合図のあとに続けた手の数（なければ大きな数）。v8.2.26。"""
        steps = 0
        for item in reversed(self.s["recent_text"]):
            meaning = self.repo.get(item["release"]).by_text[item["id"]]["meaning"]
            if not meaning.startswith(("h_", "h.")) or meaning.startswith(("h.ended.", "h.begin.", "h.sleep_together", "h.morning", "h.decline")):
                break
            if is_sign(meaning, WANTS_MORE_SIGNS):
                return steps
            if meaning.startswith(("h_", "h.pat.")):
                steps += 1
        return 10 ** 6

    def _maybe_lead(self):
        rules, intimate = self.ir, self.s["intimacy"]
        # v8.2.3：申し出は種類ごとに1回まで、1回のエッチで lead.per_session 回まで（「上に乗る」のあとに「自分から入れる」が出るように）
        if len(intimate["leads"]) >= rules.raw["lead"]["per_session"] or intimate["wrap_up"] is not None or self.s["offer"] or TIERS[rules.tier(self.s["intimacy_history"]["count"], self.pack.life)] < TIERS[rules.raw["lead"]["tier_from"]]: return
        if intimate["player"]["arousal"] >= rules.raw["player"]["arousal_max"]: return
        if self._maho_hands_held(): return  # v8.4.1（010）：両手をつないでいる・両腕を引いているあいだは申し出ない（申し出の本文は真帆が手を添える書き方が多い）
        active = {c["action_id"] for c in self.s["contacts"]}
        for key in ("h_lead_takein", "h_lead_straddle", "h_lead_sixty_nine"):
            if key in intimate["leads"] or key not in rules.actions:
                continue
            # v8.2.24（ユーザー 2026-09-30）：「上になる」は向かい合って手が届く体勢の申し出。口で愛撫している・してもらっている最中、
            # 真帆の高まりが高い・もうすぐのときは出さない（クンニの最中に「胸に手を置き、顔を寄せる」が出ていた）。
            # 深い口づけの最中は出してよい（口づけをほどいて言う本文。いちばん多い出どころ）。
            # v8.2.26（ユーザー了承 2026-09-30、精査 D-7）：高まりで止めるのは「もうすぐ」だけ（「高い」でも止めると、胸や口づけで先に高まってから
            # 下を脱がせる流れで申し出が出なくなっていた。高まった真帆が「上になるね」と言い出すのは自然な流れ）
            if key == "h_lead_straddle" and (active & set(MOUTH_AND_SERVICE) or rules.band(intimate["maho"]["arousal"]) == "near"):
                continue
            # 「自分から入れる」は、どちらかの口がふさがっている最中は出さない（真帆が上にいて、素股などからは出してよい）
            if key == "h_lead_takein" and active & set(MOUTH_BUSY):
                continue
            if key == "h_lead_sixty_nine" and not (any(c["action_id"] == "h_face_lick" for c in self.s["contacts"]) and intimate["player"]["arousal"] >= rules.b2["sixty_nine"]["lead_min_player_arousal"] - self._lewd("sixty_nine_arousal_minus")
                                                   and self.s["experience"]["h_sixty_nine"]["count"] >= rules.b2["sixty_nine"]["lead_min_experience"]):
                continue  # v8.2.10：顔面騎乗で舐めているあいだ、こちらが張りつめてきたら、舐め合ったことがあれば、真帆が自分から向きを変える
            try:
                self.intimacy_eligibility(key, "maho")
            except GameError:
                continue
            lead = rules.raw["lead"]
            tier = rules.tier(self.s["intimacy_history"]["count"], self.pack.life)
            chained = key == "h_lead_takein" and "h_lead_straddle" in intimate["leads"]  # 上になったあとに自分から入れるのは、同じ流れ
            if tier in lead.get("session_percent", {}) and not chained:
                # v8.2.30（通し確かめ 6）：この回に申し出るかを、回ごとに一度だけ決める（毎回どこかで出て、台本に見えていた）
                roll = int(digest([self.s["world"]["seed"], "lead_session", intimate["id"], key])[:12], 16) % 100
                if roll >= lead["session_percent"][tier] + self._lewd("lead_chance_plus"):
                    continue
                deadline, work = self._session_deadline()
                if deadline - self.now < lead.get("quiet_before_deadline", {}).get("work" if work else "night", 0):
                    continue  # 締め切りの直前には申し出ない（上になった途端に時間切れになっていた）
            chance = int(digest([self.s["world"]["seed"], "lead", intimate["id"], self.s["world"]["operation_seq"]])[:12], 16) % 100
            if chance < lead["chance_percent"] + self._lewd("lead_chance_plus"):
                intimate["leads"].append(key)
                self._open_intimacy_offer(key, {"h_lead_takein": "offer.h_lead.takein", "h_lead_straddle": "offer.h_lead.straddle", "h_lead_sixty_nine": "offer.h_lead.sixty_nine"}[key])
            return

    def gate_react(self, identity):
        """B2：いつもの時間に深める触れ合いをしたときの真帆の反応（誘う／許す／場所・時間を理由にやんわり止める）。"""
        rules = self.ir
        gate = rules.b2["gate"]
        touch = gate["touches"][identity]
        from .life_rules import bath_level_bonus
        level = self.pack.progression.desire_level(self.s["desire"] + bath_level_bonus(self.s, self.pack.life))  # 湯上がりは誘いやすい（v8.2.0）
        location = self.s["actors"]["player"]["location"]
        travel = 0 if location == rules.raw["session"]["invite_room"] else 5 if location in RESIDENCE else 10
        need = self.pack.catalog["activities"]["private_time"]["minutes"] + travel
        def stop(meaning):
            if any(c["action_id"] == identity for c in self.s["contacts"]):
                self.s["contacts"] = [c for c in self.s["contacts"] if c["action_id"] != identity]
            self.emit(meaning)
        session_min = rules.raw["session"]["min_minutes"]
        if rules.first_time_minutes and self.s["intimacy_history"]["count"] == 0:
            session_min = max(session_min, rules.first_time_minutes)  # v8.2.30：初めての回は、時間のあるときに誘う
        late = self.s["world"]["awake_deadline"] - self.now < need or rules.deadline(self.now, self.pack.life) - self.now < session_min + travel
        if self.minutes_to_work(need + gate["work_margin_minutes"]) is not None:
            stop("gate.react.deflect_time")  # 仕事の前
            return
        if late:
            stop("gate.react.deflect_late")  # 夜遅い（v8.2.1、別係 L-01）
            return
        hist = self.s["intimacy_history"]
        rested = hist["last_result"] == "satisfied" and self.now - hist["last_at"] <= rules.raw["session"]["rested_minutes"]
        quiet = hist["declined_at"] is not None and self.now - hist["declined_at"] <= rules.raw["session"]["decline_quiet_minutes"]
        wants = level == "press" or level == "invite" and (touch["strong"] or location in rules.raw["session"]["locations"])
        if wants and not rested and not quiet and not self.s["offer"] and self.can_offer("gate_invite") and len(self.s["activities"]) < 4:
            self.record_offer("gate_invite")
            # 個室の中では「部屋へ行こう」でなく、ここで続きを誘う（v8.2.1、別係 L-02）
            here = location in rules.raw["session"]["locations"]
            self._open_intimacy_offer("gate_invite_" + identity, "gate.react.invite_here" if here else "gate.react.invite")
            return
        if location in gate["public_rooms"] and touch["strong"] and level == "low":
            stop("gate.react.deflect_place")
            return
        if self.can_offer("gate_allow"):
            self.record_offer("gate_allow")
            if identity == "push_down":
                for actor in ("player", "maho"):
                    self.s["actors"][actor]["posture"] = "reclined"  # 押し倒したまま受け入れた（v8.2.1、別係 T2-02）
            self.emit("gate.react.allow")

    def _accept_gate(self, identity):
        """B2：深める触れ合いからの誘いを受けたら、真帆の部屋で二人の時間とエッチを始め、その触れ合いの続きから。"""
        rules = self.ir
        self.s["offer"], self.s["intention"] = None, None
        room = rules.raw["session"]["invite_room"]
        event_len = len(self.events)
        here = self.s["actors"]["player"]["location"] in rules.raw["session"]["locations"]  # 個室の中なら、そのまま（v8.2.1、別係 L-02）
        if not here and self.s["actors"]["player"]["location"] != room:
            self.move(room, True, True)
        self.begin_private()
        if identity == "push_down":
            for actor in ("player", "maho"):
                self.s["actors"][actor]["posture"] = "reclined"
        self._begin_intimacy("invite", "maho")
        self.events = self.events[:event_len]
        self.emit("h.begin.invite_here" if here else "h.begin.invite")
        follow = rules.b2["gate"]["touches"][identity]["h_action"]
        if follow:
            try:
                self.intimacy_action(follow)
            except GameError:
                pass

    def _open_intimacy_offer(self, kind, meaning):
        self.s["offer"] = {"id": self.new_id("offer"), "kind": kind, "cooldown_group": kind, "source_goal": None,
                           "started_at": self.now, "accept_action": "offer.accept", "decline_action": "offer.decline"}
        self.emit(meaning)

    def intimacy_end(self, forced=None):
        rules, intimate = self.ir, self.s["intimacy"]
        ensure(intimate is not None, "intimacy", "エッチは始まっていない。")
        chosen_at = self.now  # 一緒に眠るかは、終えると決めた時刻で決める（二人の時間の残りを進める前。検査役G2 M-3）
        satisfaction = intimate["maho"]["satisfaction"]
        deadline = rules.deadline(self.now, self.pack.life) - self.now
        if forced is None and intimate["wrap_up"] is not None:
            # v8.2.29：昼の仕事の始まりで区切ったときは、仕事へ戻る一言（夜の「明日」「寝る」の本文にしない）
            meaning = "h.ended.work" if self._session_deadline()[1] and "h.ended.work" in self.pack.meanings else "h.ended.deadline"
        elif forced is None and deadline < rules.raw["nights"]["read_air_minutes"]:
            meaning = "h.ended.read_air"
        elif forced is None and satisfaction < rules.raw["maho"]["satisfaction_levels"]["high_from"] and not intimate["hold_back_used"] and self.minutes_to_work(rules.raw["nights"]["read_air_minutes"]) is None:
            # 仕事の前（昼休みの終わりなど）は引き留めない。続けても仕事の時間で何もできないため（v8.0.5、監査 B-006）。
            intimate["hold_back_used"] = True
            # v8.2.25（精査 A-6）：終えようとしたところで、口・奉仕の行為を終え、顔にまたがる・シックスナインから向き合う形へ戻る。
            # 引き留めの本文は、向き合って手や顔が届く前提（真帆がこちらの顔にまたがったまま「鼻先を頬にすり寄せた」が出ていた）。
            # 深い口づけは続けたまま（口づけしたまま引き留める本文がある）。
            self.s["contacts"] = [c for c in self.s["contacts"] if c["action_id"] not in MOUTH_AND_SERVICE]
            self._face_again(("face_sit", "sixty_nine"))
            intimate["extras"] = self._active_extras()
            self._prune_paces()  # 終えた行為の速さも消す（残ると状態の検査に落ち、「終える」が選べなかった。確かめ役 A N-2）
            self._open_intimacy_offer("hold_back", "h.hold_back")
            return
        elif satisfaction >= rules.raw["maho"]["satisfaction_levels"]["high_from"]:
            meaning = "h.ended.satisfied"
        else:
            meaning = "h.ended.unsatisfied"
        # 終えるときは、向き合って横になり、続けていた触れ方を終えてから一言（B2：背を向けた体位や口の最中の本文と食い違わないように）。
        self.s["contacts"] = [c for c in self.s["contacts"] if c["action_id"] not in rules.actions]
        self._face_again(("back", "face_sit", "sixty_nine"))  # v8.2.25（精査 A-6）：顔にまたがる・シックスナインも
        self.emit(meaning)
        result = "satisfied" if satisfaction >= rules.raw["maho"]["satisfaction_levels"]["high_from"] else "unsatisfied"
        desire_before = self.s["desire"]
        hist = self.s["intimacy_history"]
        hist["count"] += 1
        hist["first_at"] = hist["first_at"] if hist["first_at"] is not None else self.now
        hist["last_at"], hist["last_result"] = self.now, result
        hist["by_entry"][intimate["entry"]] += 1
        lewd = rules.lewd
        if lewd:
            # v8.2.12：淫乱度は下がらない。毎回・満足・真帆が達した回数・この回に初めてした行為（服・言葉・余韻を除く）で上がる
            new_act = any(key in rules.actions and rules.actions[key]["category"] not in ("undress", "words", "after") and entry["first_at"] is not None and entry["first_at"] >= intimate["started_at"]
                          for key, entry in self.s["experience"].items())
            gain = (lewd["per_session"] + (lewd["satisfied"] if result == "satisfied" else 0) + lewd["per_climax"] * min(lewd["climax_max"], intimate["maho"]["climaxes"])
                    + (lewd["new_act"] if new_act else 0))
            # 何もないまま終えた回（真帆が満たされず、達せず、こちらも出していない）では上がらない（読み手の指摘 S-8）
            counted = (intimate["maho"]["climaxes"] > 0 or intimate["player"]["finishes"] > 0
                       or ORDER_SAT[rules.satisfaction_level(satisfaction)] >= ORDER_SAT[lewd["min_satisfaction"]])
            hist["lewdness"] = min(lewd["max"], hist["lewdness"] + (gain if counted else 0))
        hist["maho_climaxes"] += intimate["maho"]["climaxes"]
        hist["finishes"] += intimate["player"]["finishes"]
        self.remember("intimacy", summary={"result": result})
        # v8.2.29（ユーザー 2026-09-30「一回終わったら時間飛ばすのはあり？」）：眠らずに終えたら、寄り添って過ごして身支度をする時間（after_time.minutes）を進め、居間へ。
        # 二人の時間の残り（区切るときに進む分）もこの時間に含める。仕事の始まり・起きていられる限界の手前までで切り、15分に満たなければ一言も出さない。
        # 一言は服・姿勢を戻す前に選ぶ（脱いでいない回に「服を着る」、座っていた回に「横になったまま」と書かないように。確かめ役 F-5）
        after_minutes = 0
        if not (rules.sleep_night(chosen_at) and self.s["actors"]["player"]["location"] != "town") and rules.after_time and "h.after_time" in self.pack.meanings:
            after_minutes = rules.after_time["minutes"]
            work = self.minutes_to_work(after_minutes)
            after_minutes = min(after_minutes, after_minutes if work is None else work, max(0, self.s["world"]["awake_deadline"] - self.now))
            if after_minutes >= AFTER_TIME_MIN:
                self.emit("h.after_time")
            else:
                after_minutes = 0
        for actor in ("player", "maho"):
            self.s["actors"][actor]["clothing"] = {"upper": "worn", "lower": "worn"}
            self.s["actors"][actor]["posture"] = "seated"  # 体位で変えた姿勢を戻す（v8.0.5、監査 E-08）
        self.s["contacts"] = [c for c in self.s["contacts"] if c["action_id"] not in rules.actions]
        self.s["intimacy"] = None
        event_len, ended_at = len(self.events), self.now
        self.end_private()
        self.events = self.events[:event_len]
        self.s["desire"] = rules.raw["desire_after"]["satisfied"] if result == "satisfied" else min(100, desire_before + rules.raw["desire_after"]["unsatisfied_add"])
        if rules.sleep_night(chosen_at) and self.s["actors"]["player"]["location"] != "town":
            # 夜に終えたら、そのまま同じベッドで眠って翌朝へ（B2、ユーザー決定）。
            self.emit("h.sleep_together." + result)
            hist["slept_together"] = True
            self.sleep(together=True)
        elif after_minutes:
            minutes = max(0, after_minutes - (self.now - ended_at))  # 区切るときに進んだ二人の時間の残りを引く
            minutes = min(minutes, max(0, self.s["world"]["awake_deadline"] - self.now))
            before = self.now
            if minutes:
                self.advance(minutes)
            self.auto_minutes += self.now - before
            for actor in self.s["actors"].values():
                actor["location"], actor["posture"] = rules.after_time["after"], "seated"
            self.s["distance"] = "normal"

    def _face_again(self, facings):
        """体位の向きが facings のどれかなら、向き合って横になる形へ戻す（抜ける）。終える・引き留めの一言の前に（B2、v8.2.25）。"""
        rules, intimate = self.ir, self.s["intimacy"]
        if rules.positions[intimate["position"]]["facing"] not in facings:
            return
        intimate["position"], intimate["inserted"] = rules.raw["session"]["start_position"]["other"], False
        intimate["paces"], intimate["pace_focus"] = {}, None
        self.s["contacts"] = [c for c in self.s["contacts"] if c["action_id"] not in rules.actions or intimate["position"] in rules.actions[c["action_id"]]["positions"]]
        for actor, posture in rules.positions[intimate["position"]]["postures"].items():
            self.s["actors"][actor]["posture"] = posture

    def intimacy_side(self, identity, side):
        """v8.2.29（ユーザー 2026-09-30「絵をタップしたいから選べる形がいい。両方も可能なように」）：胸に触れる左右を選んで、その行為をする（始める・続ける・切り替える）。"""
        rules = self.ir
        ensure(self.s["intimacy"] is not None and identity in rules.sides and side in rules.side_choices(self.s, identity), "h_side", "左右を選べない。")
        self._chosen_side = side
        try:
            self.intimacy_action(identity)
        finally:
            self._chosen_side = None

    def intimacy_pace(self, identity, pace):
        """v8.2.13：続けている行為の速さを変えて、その行為を1手続ける（本文は <行為>.pace_<速さ>）。"""
        rules = self.ir
        if identity in rules.sides and self.s["intimacy"] is not None:
            self._chosen_side = rules.side_of(self.s, identity)  # v8.2.29（確かめ役 F-9）：速さを変えても、触れている左右はそのまま
            try:
                return self._intimacy_pace(identity, pace)
            finally:
                self._chosen_side = None
        return self._intimacy_pace(identity, pace)

    def _intimacy_pace(self, identity, pace):
        rules = self.ir
        ensure(self.s["intimacy"] is not None and rules.pace is not None and identity in rules.pace["actions"], "h_pace", "速さを変えられない。")
        ensure(pace in PACES and any(c["action_id"] == identity for c in self.s["contacts"]), "h_pace", "続けている行為の速さを変える。")
        ensure(self.s["intimacy"]["paces"].get(identity, "normal") != pace, "h_pace", "もう、その速さだ。")
        if identity == "h_maho_move" and pace == "fast" and not self._maho_ready("h_move_fast") and "h.deflect.maho_fast" in self.pack.meanings:
            # v8.2.26（ユーザー了承 2026-09-30、精査 A-8）：真帆が自分で動くときも、「激しく」はこちらが動くときと同じ高まりを待つ
            # （「激しいのはまだ」と止めた直後に、真帆に動いてもらう形なら激しくなっていた）
            ensure("h_move_fast" not in self.s["intimacy"]["deflected"], "h_ready", "さっき止められた。もう少し様子を見る。")
            self._deflect("h.deflect.maho_fast", "h_move_fast")
            self._prune_paces()
            return
        if identity == "h_maho_move" and pace == "fast" and "h_move_fast" in self.s["intimacy"]["deflected"]:
            self.s["intimacy"]["deflected"].remove("h_move_fast")  # 高まって、もう止めない
        self.s["intimacy"]["paces"][identity] = pace
        self._pace_change = pace
        try:
            self.intimacy_action(identity)
        finally:
            self._pace_change = None

    def intimacy_stop(self, identity):
        ensure(self.s["intimacy"] is not None and identity in self.ir.actions and any(c["action_id"] == identity for c in self.s["contacts"]), "contact", "この動作は続いていない。")
        if identity in SERVICE_CONTACT.values() and self.endure_on_stop():
            # v8.2.7（精査 A-01・F-1）：入れていない限界で手・口を止めてもらうのは、こらえること（本文は手・口に合わせる）
            return self.intimacy_action("h_endure")
        self.s["contacts"] = [c for c in self.s["contacts"] if c["action_id"] != identity]
        self.s["intimacy"]["extras"] = self._active_extras()  # v8.2.9：やめた行為の追加も終わる
        self.s["intimacy"]["paces"].pop(identity, None)  # v8.2.13：やめた行為の速さも終わる
        if self.s["intimacy"]["pace_focus"] == identity:
            self.s["intimacy"]["pace_focus"] = None
        if "sides" in self.s["intimacy"]:
            self.s["intimacy"]["sides"].pop(identity, None)  # v8.2.29（確かめ役 F-1）：やめた行為の左右も終わる
        meaning = "h.stopped." + identity[2:]
        if identity in STOPPED_SAY and meaning in self.pack.meanings:
            self.emit(meaning)  # v8.2.32（確かめ役 8）：真帆がしている行為を止めてもらったときの一言（本文が出ず、止めたことが分からなかった）

    def endure_on_stop(self):
        """入れていない限界で、こらえられるか（手・口を止めてもらう＝こらえる。v8.2.7）。"""
        intimate = self.s["intimacy"]
        if intimate is None or intimate["inserted"] or intimate["player"]["arousal"] < self.ir.raw["player"]["arousal_max"]:
            return False
        try:
            self.intimacy_eligibility("h_endure")
        except GameError:
            return False
        return True

    def intimacy_setting(self, name, value):
        rules = self.ir
        ensure(self.s["intimacy"] is None and self.s["mode"] in ("normal", "private") and not self.s["scene"] and not self.s["offer"], "settings", "設定はエッチの前に変更する。")
        if name == "preset":
            ensure(value in rules.settings["term_presets"], "settings", "一括設定が未登録。")
            self.s["settings"]["terms"] = dict(rules.settings["term_presets"][value])
        elif name in rules.settings["terms"]:
            ensure(value in rules.settings["terms"][name], "settings", "語の候補が未登録。")
            self.s["settings"]["terms"][name] = value
        elif name == "density":
            ensure(value in rules.settings["density"], "settings", "描写の濃さが未登録。")
            self.s["settings"]["density"] = value
        elif name == "speech":
            ensure(value in rules.settings["speech_offset"], "settings", "台詞の多さが未登録。")
            self.s["settings"]["speech"] = value
        elif name == "gauges":
            ensure(value in rules.settings["gauges"], "settings", "ゲージ表示が未登録。")
            self.s["settings"]["gauges"] = value
        elif name == "continue_text" and rules.short:
            ensure(value in rules.short["choices"], "settings", "続けるときの本文が未登録。")
            self.s["settings"]["continue_text"] = value  # v8.2.20
        elif name == "auto_speed" and rules.auto and "speeds" in rules.auto:
            ensure(value in rules.auto["choices"], "settings", "自動で続ける速さが未登録。")
            self.s["settings"]["auto_speed"] = value  # v8.2.28
        else:
            raise GameError("settings", "設定の種類が未登録。")

    def open_offer(self, kind, group, accept_action="offer.accept", decline_action="offer.decline"):
        if self.pack.intimacy and kind == "intimacy_invite":
            self.require_awake()
            ensure(self.ir.invite_ready(self.s, self.pack.progression, self.pack.life) and self.can_offer("intimacy"), "offer", "今は誘いを出せない。")
            self.record_offer("intimacy")
            self._open_intimacy_offer("intimacy_invite", "offer.intimacy.press" if self.pack.progression.desire_level(self.s["desire"]) == "press" else "offer.intimacy.invite")
            return
        return super().open_offer(kind, group, accept_action, decline_action)

    def accept_offer(self):
        offer = self.s["offer"]
        if self.pack.intimacy and offer and offer["kind"].startswith("gate_invite_"):
            self._accept_gate(offer["kind"][len("gate_invite_"):])
            return
        if self.pack.intimacy and offer and offer["kind"] in HELP_OFFERS:
            self.s["offer"], self.s["intention"] = None, None
            self.intimacy_action(HELP_OFFERS[offer["kind"]][0])
            return
        if self.pack.intimacy and offer and offer["kind"] in ("intimacy_invite", "hold_back", "h_lead_straddle", "h_lead_takein", "h_lead_sixty_nine"):
            kind = offer["kind"]
            self.s["offer"], self.s["intention"] = None, None
            if kind == "hold_back":
                if "h.hold_back.accepted" in self.pack.meanings:
                    self.emit("h.hold_back.accepted")  # v8.2.30（通し確かめ 9）：引き留めに応えて続けると、真帆の短い一言
                return
            if kind == "h_lead_sixty_nine":
                # v8.2.10：真帆が自分から向きを変えてシックスナインへ。移る本文のあと、舐め合うのが始まっている（始めの本文は出さない）
                self.intimacy_action(kind, "maho")
                if self.s["intimacy"]["position"] == "sixty_nine" and not any(c["action_id"] == "h_sixty_nine" for c in self.s["contacts"]):
                    self.action("h_sixty_nine", "player", "private", emit_text=False)
                    self.s["intimacy"]["pace_focus"] = "h_sixty_nine"  # v8.2.13：すぐ速さを変えられる（読み手の指摘 M-3）
                return
            if kind in ("h_lead_straddle", "h_lead_takein"):
                self.intimacy_action(kind, "maho")
                return
            room = self.ir.raw["session"]["invite_room"]
            event_len = len(self.events)
            if self.s["actors"]["player"]["location"] != room:
                self.move(room, True, True)
            self.begin_private()
            self._begin_intimacy("invite", "maho")
            self.events = self.events[:event_len]
            self.emit("h.begin.invite")
            return
        return super().accept_offer()

    def decline_offer(self):
        offer = self.s["offer"]
        if self.pack.intimacy and offer and (offer["kind"].startswith("gate_invite_") or offer["kind"] in HELP_OFFERS):
            self.s["offer"], self.s["intention"] = None, None
            if offer["kind"].startswith("gate_invite_"):
                # v8.2.25（精査 B-06）：触れ合いからの誘い（部屋へ行こう）を断られたら、その日の夜の誘いは済んだことにする
                # （「じゃあ、また今度」の10分後に、夜の誘いを初めてのように出していた）
                self.record_offer("intimacy")
            self.emit("offer.gate.declined" if offer["kind"].startswith("gate_invite_") else "offer.h_help.declined")
            return
        if self.pack.intimacy and offer and offer["kind"] in ("intimacy_invite", "hold_back", "h_lead_straddle", "h_lead_takein", "h_lead_sixty_nine"):
            kind = offer["kind"]
            self.s["offer"], self.s["intention"] = None, None
            if kind == "hold_back":
                self.intimacy_end(forced="unsatisfied")
            elif kind == "intimacy_invite":
                self.emit("offer.intimacy.declined")
            elif kind == "h_lead_sixty_nine" and "offer.h_lead.sixty_nine_declined" in self.pack.meanings:
                self.emit("offer.h_lead.sixty_nine_declined")  # 顔の上にいる真帆の本文（v8.2.10）
            else:
                self.emit("offer.h_lead.declined")
            return
        return super().decline_offer()
