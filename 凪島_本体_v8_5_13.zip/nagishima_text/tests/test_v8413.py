"""v8.4.13（ユーザー 2026-10-07 11:04「続けて」・11:05「進めて」）：010 だけ。
真帆が上へ移る（部品の組み合わせ）のつなぎ目：反応の部品の頭の「真帆は」を外す（「真帆は〜。真帆は〜。」を作らない）。
移り方の最後の文と反応の最初の文で同じ言い回しが重なる組み合わせは作らない。"""
import re
import unittest
from pathlib import Path

from nagishima.content import Pack

ROOT = Path(__file__).resolve().parents[1]
P009 = Pack(ROOT / "content/releases/interaction_009")
P010 = Pack(ROOT / "content/releases/interaction_010")
PREFIX = "cmp.h_pos_maho_above.start."


def sentences(text):
    return [s for s in re.split(r"(?<=。)", text) if s.strip()]


class V8413(unittest.TestCase):
    def test_009_unchanged(self):
        self.assertFalse(any(t["id"].startswith("cmp.") for t in P009.by_meaning["h_pos_maho_above.start"]))

    def test_no_repeated_subject(self):
        for text in P010.by_text.values():
            if text["id"].startswith("cmp."):
                parts = sentences(text["body"])
                for first, second in zip(parts, parts[1:]):
                    self.assertFalse(first.startswith("真帆は") and second.startswith("真帆は"), text["id"])
        body = P010.by_text[PREFIX + "w1pasittingclose02.w1pb01"]["body"]
        self.assertIn("そこへまたがった。落ちてきた髪を耳にかけず", body)
        # 台詞で始まる反応は、そのまま
        self.assertIn("またがった。「", P010.by_text[PREFIX + "w1pasittingclose02.w1pb03"]["body"])

    def test_overlapping_joins_dropped(self):
        # 「こちらの腰の上でまたがりなおした。こちらの腰の上で〜」「髪をかき上げてから〜。髪をかき上げもせず〜」
        self.assertNotIn(PREFIX + "w1palap02.w3pb25", P010.by_text)
        self.assertNotIn(PREFIX + "w2pabackbed03.w2pbbeg04", P010.by_text)
        self.assertIn(PREFIX + "w1palap02.w1pb01", P010.by_text)
        texts = [t for t in P010.by_meaning["h_pos_maho_above.start"] if t["id"].startswith(PREFIX)]
        self.assertGreater(len(texts), 4000)
        for text in texts:
            parts = sentences(text["body"])
            for first, second in zip(parts, parts[1:]):
                self.assertFalse("腰の上" in first and "腰の上" in second, text["id"])
                self.assertFalse("髪をかき上げ" in first and "髪をかき上げ" in second, text["id"])


if __name__ == "__main__":
    unittest.main()
