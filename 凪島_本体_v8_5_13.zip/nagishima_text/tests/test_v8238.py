"""v8.2.38（ユーザー 2026-10-02 09:05「じゃあそれで」）：009 では、エッチをしないまま二人の時間が終わっても欲求を0にしない。
ユーザーの試遊（昼休みにキスで欲求100 → 部屋で話して二人の時間を終えたら0）。段階A の「二人の時間で満たされる」は 006〜008 だけ。"""
import tempfile
import unittest

from nagishima.engine import Engine
from tools.run_stage_b_routes import Route


class V8238(unittest.TestCase):
    def route(self, seed, tier="familiar", **kw):
        route = Route(seed, tier=tier, **({"day_offset": 3, "hour": 19} | kw))
        self.addCleanup(route.close)
        return route

    def end_private(self, route):
        if route.engine.get_view()["page"] != "main":
            route.choose("menu.main")
        route.choose("private.end")

    # ---- エッチをせずに二人の時間を終えても、欲求は残る ----
    def test_keep_without_h(self):
        route = self.route(9101)
        route.choose("private.begin")
        route.choose("menu.touch")
        for _ in range(4):
            route.choose("touch.kiss")
        before = route.engine.snapshot()["desire"]
        self.assertGreater(before, 0)
        self.end_private(route)
        state = route.engine.snapshot()
        self.assertEqual(state["mode"], "normal")
        self.assertEqual(state["desire"], before)

    # ---- エッチをした回は、これまでどおり（物足りないまま終えたら +50、満足なら 0） ----
    def test_after_h_unchanged(self):
        route = self.route(9102)
        route.engine._state["desire"] = 30
        route.engine._install_choices()
        route.begin()
        route.choose("h.end")
        if route.engine.snapshot()["offer"]:
            route.choose("offer.decline")
        state = route.engine.snapshot()
        self.assertEqual(state["intimacy_history"]["last_result"], "unsatisfied")
        self.assertEqual(state["desire"], 30 + 50 - 20)  # 物足りない +50。夜に終えたので一緒に眠って翌朝（ひと晩で -20）

    # ---- 008（段階A）は、これまでどおり二人の時間で0に戻る ----
    def test_stage_a_unchanged(self):
        with tempfile.TemporaryDirectory(prefix="nagishima-v8238-") as tmp:
            engine = Engine(tmp, seed=9103, release="interaction_008", autosave=False, test_cheats=True)
            self.assertIsNone(engine.pack.intimacy)
            # 決まり（progression の set_after_private）がそのまま使われることだけを見る
            self.assertEqual(engine.pack.progression.desire_after_private, 0)


if __name__ == "__main__":
    unittest.main()
