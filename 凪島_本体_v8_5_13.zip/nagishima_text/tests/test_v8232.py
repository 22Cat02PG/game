"""v8.2.32（ユーザー 2026-10-01 10:18「進めて」）：別の Claude のエッチ場面の確かめ（報告_v8231エッチ.md）の 1〜9 の直し。"""
import json
import re
import unittest
from copy import deepcopy
from pathlib import Path

from nagishima.conditions import evaluate
from nagishima.content import Pack
from nagishima.context import Context
from tools.run_stage_b_routes import Route

ROOT = Path(__file__).resolve().parents[1]
PACK = Pack(ROOT / "content/releases/interaction_009")


def meanings(engine):
    return [b["meaning"] for b in engine.get_view()["blocks"]]


def candidates(meaning, state):
    values = PACK.registry.values(state)
    return [t for t in PACK.by_meaning[meaning] if not t["fallback"] and evaluate(t["when"], values) is True]


def choice(route, identity):
    """その選択肢を、行為の種類のページで探す（主画面に戻ってから）。"""
    engine = route.engine
    if engine.get_view()["page"] != "main":
        route.choose("menu.main")
    key = identity.split(".", 1)[1]
    category = engine.pack.intimacy.actions[key]["category"]
    from tools.run_stage_b_routes import PAGES
    route.choose("menu." + PAGES[category])
    view = engine.get_view()
    return next((c for c in view["choices"] if c["id"] == identity), None), view


class V8232(unittest.TestCase):
    def route(self, seed, tier="few", **kw):
        route = Route(seed, tier=tier, **({"day_offset": 3, "hour": 13} | kw))
        self.addCleanup(route.close)
        return route

    def lunch_past_deadline(self, seed):
        route = self.route(seed, day_offset=0, hour=12, minute=20)
        route.begin()
        route.action("h_strip_self")
        for _ in range(30):
            if route.engine.snapshot()["intimacy"]["wrap_up"] is not None:
                break
            route.engine._state["intimacy"]["maho"].update(arousal=30, band="low")
            route.engine._install_choices()
            route.action("h_kiss_deep")
        self.assertIsNotNone(route.engine.snapshot()["intimacy"]["wrap_up"])
        return route

    # ---- 1：仕事の時間を告げたあとは、新しい行為を始めない（続き・果てる・余韻・口づけはできる） ----
    def test_no_new_act_after_deadline(self):
        route = self.lunch_past_deadline(5001)
        for identity in ("touch.h_maho_mouth", "touch.h_maho_hand", "touch.h_sumata", "touch.h_touch_direct"):
            found, view = choice(route, identity)
            if found is not None:
                self.assertFalse(found["available"], identity)
                self.assertIn("仕事", view["explanations"].get(identity) or found.get("reason", ""), identity)
        found, view = choice(route, "touch.h_kiss_deep")
        self.assertTrue(found and found["available"], view["explanations"].get("touch.h_kiss_deep"))

    # ---- 7：区切りの表示は、過ぎたあとも始めたときの時刻 ----
    def test_deadline_status_after_passing(self):
        route = self.lunch_past_deadline(5002)
        status = route.engine.get_view()["status"]["intimacy"]
        self.assertTrue(status["deadline"].endswith("13:00（仕事）を過ぎた"), status["deadline"])
        self.assertEqual(status["night"], "このあと仕事")

    # ---- 2：初めての夜の初めて入れる本文に、濃い本文（x4）を出さない（横になって向き合う・上から重なる） ----
    def test_first_night_insert(self):
        route = self.route(5003, tier="first", day_offset=0, hour=20)
        route.begin()
        state = route.engine.snapshot()
        self.assertEqual(state["intimacy_history"]["count"], 0)
        for position in ("lying_face", "player_above"):
            state["intimacy"]["position"] = position
            for meaning in ("h_insert.first", "h_insert.start"):
                self.assertFalse([t["id"] for t in candidates(meaning, state) if t["id"].startswith("x4.")], (position, meaning))
        x4 = [t for t in PACK.texts if t["id"].startswith("x4.h_insert.start.first.")]
        self.assertEqual(len(x4), 20)
        for text in x4:  # 二回目からは出る
            self.assertIn('"intimacy.history_count", "op": "ge", "value": 1', json.dumps(text["when"]), text["id"])

    # ---- 3：達した瞬間の本文が「いきそう」だけで終わらない ----
    def test_climax_says_it(self):
        for text in PACK.texts:
            if text["meaning"].startswith("h.climax.maho") and re.search(r"いきそう|イきそう", text["body"]):
                self.assertRegex(text["body"], r"(いってる|いった|イって|いっちゃ(っ|う)|達し|達する|果て)", text["id"])

    # ---- 4：めくれた服の本文は、上をめくっているときだけ ----
    def test_lifted_wording(self):
        for text in PACK.texts:
            self.assertNotIn("めくれた{nipple}", text["body"], text["id"])
        for identity in ("x2.h_finish_inside.start.familiar.from_behind.n.v5", "x2.h_move_slow.start.familiar.side_lying.n.v4", "x3.h_move_slow.start.familiar.reverse_ride.s.v4"):
            self.assertIn('"actor.maho.clothing.upper", "op": "eq", "value": "raised"', json.dumps(PACK.by_text[identity]["when"]), identity)

    # ---- 5：胸・耳首筋・頭を撫でる本文は、入れていないときは外側の語 ----
    def test_outer_term_chest(self):
        route = self.route(5005)
        route.begin()
        engine = route.engine
        context = Context(deepcopy(engine._state), engine.pack, engine.repository, None, True)
        for meaning in ("h_chest_mouth.start", "h_chest_skin.start", "h_ear_neck.start", "h_touch_under.start"):
            context.emit(meaning)
            self.assertEqual(context.events[-1]["bindings"]["vagina"], "秘所", meaning)
        context.s["intimacy"]["inserted"] = True
        context.emit("h_chest_skin.start")
        self.assertEqual(context.events[-1]["bindings"]["vagina"], "膣")
        context.emit("h_touch_under.start")
        self.assertEqual(context.events[-1]["bindings"]["vagina"], "秘所")

    # ---- 6：高まったまま仕事の前に終えるときは、さっぱり切り替える一言を出さない ----
    def test_work_end_while_high(self):
        route = self.route(5006, day_offset=0, hour=12, minute=20)
        route.begin()
        state = route.engine.snapshot()
        state["intimacy"]["maho"].update(arousal=90, band="near")
        for posture in ("seated", "reclined"):
            state["actors"]["maho"]["posture"] = posture
            found = candidates("h.ended.work", state)
            self.assertGreaterEqual(len(found), 4, posture)
            self.assertFalse([t["id"] for t in found if t["id"].startswith("o36.")], posture)
        state["intimacy"]["maho"].update(arousal=20, band="low")
        self.assertTrue([t for t in candidates("h.ended.work", state) if t["id"].startswith("o36.")])

    # ---- 8：真帆がしている行為を止めてもらうと、真帆の一言 ----
    def test_stopped_line(self):
        route = self.route(5008)
        route.begin()
        route.action("h_strip_self")
        route.action("h_maho_hand")
        self.assertLess(route.engine.snapshot()["intimacy"]["player"]["arousal"], 100)
        found, view = choice(route, "touch.h_maho_hand")
        route.choose("menu.main")
        route.choose("end.h_maho_hand")
        self.assertIn("h.stopped.maho_hand", meanings(route.engine))
        self.assertFalse(any(c["action_id"] == "h_maho_hand" for c in route.engine.snapshot()["contacts"]))

    # ---- 9：文の継ぎ目の重なり ----
    def test_clause_fixes(self):
        texts = PACK.by_text
        self.assertNotIn("沈んだ腰が動かず吐息だけ残る", texts["x3.h_finish_inside.start.few.lying_face.n.v3"]["body"])
        self.assertNotIn("一段はっきりする", texts["x3.h_move_normal.start.few.lying_face.n.v1"]["body"])
        self.assertEqual(texts["x2.h_move_fast.start.familiar.from_behind.s.v5"]["body"].count("腰が跳ね"), 1)
        self.assertEqual(texts["x7.h.sign.beg.few.face.s.v4"]["body"].count("開いたまま"), 1)

    def test_texts(self):
        data = json.loads((ROOT / "tools/stage_b/opus_texts_v8232.json").read_text(encoding="utf-8"))
        self.assertEqual(len(data["texts"]), 20)
        for row in data["texts"]:
            self.assertEqual(PACK.by_text[row["id"]]["body"], row["body"])


if __name__ == "__main__":
    unittest.main()
