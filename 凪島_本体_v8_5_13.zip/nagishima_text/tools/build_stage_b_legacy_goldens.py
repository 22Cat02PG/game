"""Capture immutable v7.1.2 output hashes for Stage B compatibility tests."""
import argparse
import hashlib
import json
from pathlib import Path

from check_stage_b_compat import ROOT, run


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    args = parser.parse_args()
    releases = args.base / "content/releases"
    hashes = {}
    for n in range(3, 9):
        release = f"interaction_{n:03d}"
        for file in (releases / release).rglob("*"):
            if file.is_file():
                hashes[str(file.relative_to(releases)).replace("\\", "/")] = hashlib.sha256(file.read_bytes()).hexdigest()
    outputs = {}
    for release in ("interaction_003", "interaction_006", "interaction_007", "interaction_008"):
        for policy in ("--autoplay", "--autoplay-social", "--autoplay-presence"):
            for seed in (0, 42):
                observed = run(args.base, release, policy, seed)
                raw = json.dumps(observed, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
                outputs[f"{release}/{policy}/{seed}"] = hashlib.sha256(raw).hexdigest()
    target = ROOT / "verification/stage_b_legacy_goldens.json"
    target.write_text(json.dumps({"published_files": hashes, "autoplay": outputs}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(len(hashes), len(outputs), target)


if __name__ == "__main__": main()
