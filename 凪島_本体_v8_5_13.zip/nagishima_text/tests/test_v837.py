"""v8.3.7（ユーザー 2026-10-02）：010 だけ。
- 中に出すと真帆の高まりが大きく上がる（8 → 25。慣れの割合で 初めて12・数回20・慣れ25）。「25でいい」
- プレイヤーがしていない行為・書かれていない前提（手をつなぐ前提・何を握るか分からない手・選んでいない行為）の描写を直し、胸の描写の拾い漏れに胸の条件を足した。
  「プレイヤーは実際にしてないプレイが唐突に内容に出ると困惑するからどうにかしてほしい」"""
import re
import unittest
from pathlib import Path

from nagishima.content import Pack

ROOT = Path(__file__).resolve().parents[1]
P009 = Pack(ROOT / "content/releases/interaction_009")
P010 = Pack(ROOT / "content/releases/interaction_010")
HAND_PREMISE = re.compile(r"(絡めた|重ねた|つないだ)(手|指)|握り返")


class V837(unittest.TestCase):
    def test_finish_inside_gain(self):
        self.assertEqual(P009.intimacy.actions["h_finish_inside"]["effects"]["maho_arousal"], 8)
        self.assertEqual(P010.intimacy.actions["h_finish_inside"]["effects"]["maho_arousal"], 25)
        self.assertEqual(P010.intimacy.actions["h_finish_outside"]["effects"]["maho_arousal"], 0)
        rules = P010.intimacy
        self.assertEqual([rules.maho_gain(25, tier, "high", "none")[0] for tier in ("first", "few", "familiar")], [12, 20, 25])

    def test_reported_line(self):
        """ユーザーの指摘：「握った手がびくんと大きく跳ねる。」（いつ握った？）"""
        identity = "q.h_move_normal.first.g1.h2.v16"
        self.assertIn("、握った手がびくん", P009.by_text[identity]["body"])
        self.assertIn("シーツを握った手がびくん", P010.by_text[identity]["body"])

    def test_hand_premise_samples(self):
        for identity in ("q.h_move_slow.few.g1.h1.v2", "q.h_move_normal.few.g1.h2.v11", "o36.h.deadline.close.s.v2", "b3.h.climax.together.familiar.n.v5"):
            self.assertRegex(P009.by_text[identity]["body"], HAND_PREMISE, identity)
            self.assertNotRegex(P010.by_text[identity]["body"], HAND_PREMISE, identity)

    def test_chest_conditions(self):
        for identity in ("x3.h_move_slow.start.few.lying_face.s.v4", "x2.h_finish_inside.start.few.sitting_face.s.v5"):
            if identity not in P010.by_text:
                continue  # v8.4.7 で消した本文（中に出す本文で、どの結果にも合わないもの）
            self.assertNotIn("contact.h_chest_skin.active", str(P009.by_text[identity]["when"]))
            self.assertIn("contact.h_chest_skin.active", str(P010.by_text[identity]["when"]))
        self.assertIn("contact.h_chest_mouth.active", str(P010.by_text["x2.h_finish_inside.start.familiar.maho_above.n.v5"]["when"]))

    def test_player_feeling(self):
        identity = "o6.h.spent.unsatisfied.n.v4"
        self.assertIn("気持ちのまま", P009.by_text[identity]["body"])
        self.assertNotIn("気持ち", P010.by_text[identity]["body"])


if __name__ == "__main__":
    unittest.main()
