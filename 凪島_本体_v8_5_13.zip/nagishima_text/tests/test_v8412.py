"""v8.4.12（ユーザー 2026-10-07 08:42「始めて」）：010 だけ。本文の再会を減らす 一束目。
様子を聞く・気持ちを伝える・真帆が上へ移るを、部品の組み合わせ（cmp.<場面>.<a>.<b>）で増やした。様子を聞くの何度か・慣れたの本文 14本は両方で出す。"""
import unittest
from copy import deepcopy
from pathlib import Path

from nagishima.content import Pack
from tools.run_stage_b_routes import Route

ROOT = Path(__file__).resolve().parents[1]
P009 = Pack(ROOT / "content/releases/interaction_009")
P010 = Pack(ROOT / "content/releases/interaction_010")
FF = {"field": "intimacy.tier", "op": "in", "value": ["few", "familiar"]}
BEGGING = {"field": "flow.prev.begging", "op": "eq", "value": True}
SCENES = ("h_check.start", "h_feel.start", "h_pos_maho_above.start")


def composed(meaning):
    return [t for t in P010.by_meaning[meaning] if t["id"].startswith("cmp.")]


class V8412(unittest.TestCase):
    def test_009_unchanged(self):
        for meaning in SCENES:
            self.assertFalse(any(t["id"].startswith("cmp.") for t in P009.by_meaning[meaning]))
        self.assertEqual(P009.by_text["o15.h_check.start.few.low.s.v1"]["when"]["all"][0], {"field": "intimacy.tier", "op": "eq", "value": "few"})

    def test_widened_check_texts(self):
        when = P010.by_text["o15.h_check.start.few.mid.n.v2"]["when"]["all"]
        self.assertIn(FF, when)
        self.assertNotIn({"field": "intimacy.tier", "op": "eq", "value": "few"}, when)
        # 「今さら？」は慣れただけのまま
        self.assertIn({"field": "intimacy.tier", "op": "eq", "value": "familiar"}, P010.by_text["o15.h_check.start.familiar.low.s.v1"]["when"]["all"])

    def test_composed_conditions(self):
        self.assertGreater(len(composed("h_check.start")), 1000)
        self.assertGreater(len(composed("h_feel.start")), 1000)
        self.assertGreater(len(composed("h_pos_maho_above.start")), 4000)
        for meaning in SCENES:
            for text in composed(meaning):
                when = text["when"]["all"]
                self.assertIn(FF, when, text["id"])
                self.assertEqual(len(P010._memory_keys(text)), 2)
        for text in composed("h_check.start"):
            when = text["when"]["all"]
            self.assertIn({"field": "contact.h_move_normal.active", "op": "eq", "value": False}, when)
            self.assertIn({"field": "intimacy.maho.afterglow", "op": "eq", "value": False}, when)
        for text in composed("h_feel.start") + composed("h_check.start"):
            if {"field": "intimacy.facing", "op": "eq", "value": "back"} in text["when"]["all"]:
                self.assertIn({"field": "intimacy.position", "op": "ne", "value": "reverse_ride"}, text["when"]["all"], text["id"])
        # 移る前の体位：後ろからなどは移る前の体位に合わせた本文（先に出す）、向かい合う体位からはどこからでも出る本文と並べる
        behind = [t for t in composed("h_pos_maho_above.start") if t["id"].split(".")[3].startswith(("w2pabackbed01", "w4pabackbed01"))]
        self.assertTrue(behind)
        self.assertTrue(all({"field": "intimacy.position_from", "op": "in", "value": ["from_behind"]} in t["when"]["all"] for t in behind))
        lying = [t for t in composed("h_pos_maho_above.start") if t["id"].split(".")[3].startswith("w1pafacelying01")]
        self.assertTrue(all({"field": "intimacy.position_from", "op": "eq", "value": "lying_face"} in t["when"]["all"] for t in lying))
        # せがんだ直後の部品は受ける本文（先に出す）
        begging = [t for t in composed("h_pos_maho_above.start") + composed("h_check.start") if BEGGING in t["when"]["all"]]
        self.assertGreater(len(begging), 200)
        self.assertTrue(all(P010.intimacy.flow.receiver(t) for t in begging))

    def test_check_after_begging_picks_receiver(self):
        route = Route(8461, tier="familiar", release="interaction_010", hour=21, day_offset=2)
        self.addCleanup(route.close)
        route.begin()
        state = route.engine.snapshot()
        state["contacts"] = []
        state["intimacy"]["maho"]["band"] = "mid"
        urge = next(t for t in P010.by_meaning["h.sign.wants_more"] if "もっと" in t["body"] and not t["fallback"])
        state["recent_text"] = state["recent_text"][-5:] + [{"id": urge["id"], "group": urge["group"], "release": "interaction_010"}]
        chosen = P010.select("h_check.start", deepcopy(state), {}, P010.registry.values(state))[0]["variant"]
        self.assertTrue(P010.intimacy.flow.receiver(P010.by_text[chosen]), chosen)


if __name__ == "__main__":
    unittest.main()
