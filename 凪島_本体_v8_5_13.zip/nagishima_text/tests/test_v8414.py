"""v8.4.14（ユーザー 2026-10-07 11:05「進めて」）：010 だけ。本文の再会を減らす 二束目。
一束目の三場面に真帆の反応の部品を足し、頭を撫でる・抱きしめる・もう一度深く口づける・体位を移る三つ・胸に直に触れる・もっとせがむ合図を部品の組み合わせで増やした。"""
import json
import re
import unittest
from pathlib import Path

from nagishima.content import Pack

ROOT = Path(__file__).resolve().parents[1]
P009 = Pack(ROOT / "content/releases/interaction_009")
P010 = Pack(ROOT / "content/releases/interaction_010")
FF = {"field": "intimacy.tier", "op": "in", "value": ["few", "familiar"]}
FACE = {"field": "intimacy.facing", "op": "eq", "value": "face"}
BACK = {"field": "intimacy.facing", "op": "eq", "value": "back"}
KISS_ON = {"field": "contact.h_kiss_deep.active", "op": "eq", "value": True}
KISS_OFF = {"field": "contact.h_kiss_deep.active", "op": "eq", "value": False}
NEW = ("h_stroke_head.again", "h_stroke_head.kiss", "h_hug.start", "h_kiss_deep.again", "h_pos_sitting_close.start", "h_pos_lying_face.start",
       "h_pos_player_above.start", "h_chest_skin.start", "h.sign.wants_more")
MOVES = ("h_pos_sitting_close.start", "h_pos_lying_face.start", "h_pos_player_above.start")
BEGGING = re.compile(json.loads((ROOT / "content/releases/interaction_010/intimacy.json").read_text(encoding="utf-8"))["settings"]["flow"]["moods"]["begging"])


def composed(meaning, writers=("w5", "w6", "w7", "w8")):
    return [t for t in P010.by_meaning[meaning] if t["id"].startswith("cmp.") and any(f".{w}" in t["id"] for w in writers)]


def sentences(text):
    return [s for s in re.split(r"(?<=。)", text) if s.strip()]


class V8414(unittest.TestCase):
    def test_009_unchanged(self):
        for meaning in NEW + ("h_check.start", "h_feel.start", "h_pos_maho_above.start"):
            self.assertFalse(any(t["id"].startswith("cmp.") for t in P009.by_meaning.get(meaning, [])), meaning)

    def test_counts_and_tier(self):
        least = {"h_check.start": 1000, "h_feel.start": 1000, "h_pos_maho_above.start": 2000, "h_stroke_head.again": 300, "h_stroke_head.kiss": 400,
                 "h_hug.start": 400, "h_kiss_deep.again": 100, "h_pos_sitting_close.start": 200, "h_pos_lying_face.start": 200,
                 "h_pos_player_above.start": 200, "h_chest_skin.start": 100, "h.sign.wants_more": 150}
        for meaning, count in least.items():
            texts = composed(meaning)
            self.assertGreater(len(texts), count, meaning)
            for text in texts:
                self.assertIn(FF, text["when"]["all"], text["id"])
                self.assertEqual(len(P010._memory_keys(text)), 2)

    def test_joins(self):
        for text in P010.by_text.values():
            if text["id"].startswith("cmp."):
                parts = sentences(text["body"])
                for first, second in zip(parts, parts[1:]):
                    self.assertFalse(first.startswith("真帆は") and second.startswith("真帆は"), text["id"])
                self.assertNotIn("。、", text["body"], text["id"])
        # 頭を撫でる（2回目から）は一文
        for text in composed("h_stroke_head.again"):
            self.assertEqual(len(sentences(text["body"])), 1, text["id"])
            self.assertIn(FACE, text["when"]["all"])
        # 移り方が真帆の動作で終わるときは、反応の頭の「真帆は」を外す
        body = P010.by_text["cmp.h_pos_sitting_close.start.w8msaplayerabove01.w5msbcalm01"]["body"]
        self.assertIn("隣に並んだ。こちらの膝に手を置いて", body)
        # こちらの動作で終わる移り方（「真帆が〜すると、〜重ねた」）のあとは外さない
        self.assertIn("体を重ねた。真帆は", P010.by_text["cmp.h_pos_player_above.start.w6mpaback01.w5mpbcalm01"]["body"])

    def test_kiss_and_hands(self):
        for text in composed("h_stroke_head.kiss"):
            when = text["when"]["all"]
            self.assertFalse(KISS_ON in when and KISS_OFF in when, text["id"])
            if ".w5skakiss" in text["id"] or ".w6skakiss" in text["id"]:
                self.assertIn(KISS_ON, when)
        for text in composed("h_chest_skin.start"):
            when = text["when"]["all"]
            side = [c for c in when if c.get("field") == "intimacy.side.h_chest_skin"]
            self.assertEqual(len(side), 1, text["id"])
            if "csaback" in text["id"]:
                self.assertIn(BACK, when)

    def test_moves_origin(self):
        for meaning in MOVES:
            for text in composed(meaning):
                origin = [c for c in text["when"]["all"] if c.get("field") == "intimacy.position_from"]
                self.assertTrue(origin, text["id"])
                if "aback" in text["id"].split(".")[-2]:
                    self.assertIn({"field": "intimacy.position_from", "op": "in", "value": ["from_behind", "side_lying", "prone_back"]}, origin)
                if "amahoabove" in text["id"].split(".")[-2]:
                    self.assertEqual(origin, [{"field": "intimacy.position_from", "op": "eq", "value": "maho_above"}])
        # 「体ごと横向きに寝かせる」は、移る前が横向きで後ろからのときは出さない（もう横向きに寝ている）
        self.assertIn({"field": "intimacy.position_from", "op": "in", "value": ["from_behind", "prone_back"]},
                      P010.by_text["cmp.h_pos_lying_face.start.w8mlaback01.w5mlbcalm02"]["when"]["all"])

    def test_wants_more_is_begging(self):
        texts = composed("h.sign.wants_more")
        self.assertTrue(texts)
        for text in texts:
            self.assertTrue(BEGGING.search(text["body"]), text["id"])
            self.assertIn(KISS_OFF, text["when"]["all"])


if __name__ == "__main__":
    unittest.main()


class V8414Order(unittest.TestCase):
    """組み合わせた本文は、後半（真帆の反応）の部品が出てからの長さで比べる（settings.text_memory.composed）。"""

    def test_setting(self):
        self.assertEqual(P010.intimacy.text_memory["composed"], "reaction_first")
        self.assertIsNone(P009.intimacy.text_memory)

    def test_reactions_rotate_with_old_texts(self):
        from copy import deepcopy
        from tools.run_stage_b_routes import Route
        route = Route(8462, tier="familiar", release="interaction_010", hour=21, day_offset=2)
        self.addCleanup(route.close)
        route.begin()
        state = route.engine.snapshot()
        state["contacts"] = []
        state["intimacy"]["maho"]["band"] = "mid"
        picks = []
        for _ in range(40):
            state["recent_text"] = []
            chosen = P010.select("h_check.start", state, {}, P010.registry.values(state))[0]["variant"]
            picks.append(chosen.rsplit(".", 1)[1] if chosen.startswith("cmp.") else chosen)
        # 一巡するまで、同じ反応の部品も、前からある本文も戻らない
        self.assertEqual(len(set(picks)), len(picks), picks)
        self.assertGreater(sum(1 for p in picks if p.startswith("w")), 20)
