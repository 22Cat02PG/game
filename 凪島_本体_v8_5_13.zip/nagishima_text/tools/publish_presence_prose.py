"""Publish extra sensory and reciprocal prose for frequently repeated daily events."""

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from nagishima.authoring import publish
from nagishima.codec import digest, write_json
from nagishima.content import Pack


ADDITIONS = {
    "system.listen": [
        "言葉を止めると、窓の外から波の音が一つ届いた。真帆はその間に気づいてこちらを見て、話してもよさそうか確かめるように小さく首を傾けた。",
        "真帆の手元へ目を向けると、彼女も作業を止めた。急かされていないと分かったらしく、少し考えてからこちらへ体を向ける。",
        "こちらが聞く姿勢を見せると、真帆は一度だけ息を整えた。何でもないふうにしていた表情がほどけ、今の気持ちを探す静かな時間が生まれた。",
        "部屋の小さな物音だけを残して待っていると、真帆と目が合った。彼女はかすかに笑い、こちらがちゃんと見ていることを受け取ったようだった。",
    ],
    "offer.shared": [
        "「ちょうどお湯を沸かそうと思ってたの。一緒に飲む？」真帆は台所のほうを見てから振り返った。カップを二つ並べる時間まで楽しみにしている声だった。",
        "真帆は窓の明るさを確かめてから、「少し休もうか。隣、空けておくね」と声をかけた。同じ景色を見ながらお茶を飲みたいらしい。",
        "「今なら、ゆっくりお茶にできそう」真帆は自分の分だけでなく、こちらのカップも用意するつもりで返事を待った。目元には小さな期待が浮かんでいる。",
        "真帆は肩の力を抜いて、「休憩を一人分で終わらせるの、少しもったいないな」と笑った。何気ない時間をこちらと分けたい、という誘いだった。",
    ],
    "offer.declined": [
        "「そっか。じゃあ、また気が向いたときに」真帆はあっさりうなずき、自分の時間へ戻った。断られたことを引きずる様子はなく、部屋の空気も穏やかなままだった。",
        "真帆は「了解」と短く答え、こちらの返事をそのまま受け取った。無理に理由を聞かず、次に声をかけてもよい余白だけを残している。",
        "「うん、今じゃないんだね」真帆は納得したように笑った。誘いはそこで終わり、二人はそれぞれの過ごし方へ自然に戻った。",
        "返事を聞いた真帆は、小さく手を振って「気にしないで」と言った。予定が合わないことも暮らしの一部として、軽やかに受け止めている。",
    ],
    "activity.tea.begin": [
        "湯気の立つカップを二つ置くと、真帆は自分の席を少しこちらへ寄せた。「熱いうちに、でもゆっくり飲もう」甘い香りが二人の間に広がる。",
        "真帆はカップを両手で包み、最初のひと口の前にこちらを見た。「こうして同じタイミングで休めると、ちゃんと一緒に暮らしてる感じがするね」",
        "茶葉が開くのを待ちながら、真帆は今日あった小さなことを一つ話した。大きな出来事ではないからこそ、同じ食卓で分け合えるのがうれしそうだった。",
        "「今日はこっちのカップを使おうかな」真帆は棚から選んだ器を見せた。ささやかな選択を口にしながら、二人のお茶の時間を始める。",
    ],
    "activity.tea.end": [
        "カップの底が見えるころ、真帆は名残惜しそうに最後の香りを確かめた。「ごちそうさま。また一緒に飲もうね」席を立つ声は満足げだった。",
        "真帆は空になった二つのカップを重ねず、並べたまま眺めた。「同じ時間に休めたのがよかったな」そう言って、ゆっくり片づけを始める。",
        "お茶を飲み終えた真帆は、温まった指先をほどくように伸ばした。「よし、少し元気になった。付き合ってくれてありがとう」",
        "静かになった湯気を見て、真帆は小さく笑った。「終わると早かった気がするね」二人で過ごした時間の余韻を残しながらカップを持ち上げた。",
    ],
    "activity.quiet.begin": [
        "真帆は隣に腰を落ち着け、背もたれへゆっくり体を預けた。会話を探す代わりに、同じ部屋の音を一緒に聞くつもりらしい。",
        "「しばらく、ここにいるね」真帆はそれだけ伝えて静かになった。近くに人の気配がある安心を、言葉を足さずに分け合っている。",
        "窓から入る風にカーテンが揺れ、真帆の髪もわずかに動いた。彼女は目を細め、こちらと同じ静けさの中で呼吸を整えている。",
        "真帆は読みかけのものを脇へ置き、何もしない時間を選んだ。時おりこちらを見る視線が、離れずに過ごしていることを確かめている。",
    ],
    "activity.quiet.end": [
        "真帆はゆっくり姿勢を戻し、「そばに人がいる静けさって、いいね」と言った。休んでいる間も孤独ではなかったことが、柔らかな声に表れている。",
        "静かな時間を終えると、真帆は一度大きく伸びをした。「ちゃんと休めた。あなたも少し楽になってたらいいな」",
        "真帆は窓の外からこちらへ視線を戻し、穏やかに笑った。何も話さなかった時間まで二人のものになったことを、うれしく感じているようだった。",
        "「そろそろ動こうか」真帆はそう言いながらも、すぐには立ち上がらなかった。もう少しだけ残った静けさを惜しむように、隣で息をついている。",
    ],
    "activity.completed": [
        "二人で使ったものを元の場所へ戻す。真帆は片づいた様子を見てうなずき、過ごした時間ごと大切にしまうように最後の一つへ手を伸ばした。",
        "ひと区切りつくと、真帆はこちらの顔を見て「一緒だと、終わったあとまで気持ちがいいね」と笑った。二人の間に満足した空気が残る。",
        "真帆は終わった用事を指で数えるように確かめ、それから肩の力を抜いた。結果だけでなく、途中を一緒に過ごせたことにも満たされている。",
        "時間の区切りを迎え、真帆は小さく息をついた。隣にいたこちらへ自然に「ありがとう」と告げ、そのまま次の穏やかな時間へ戻っていく。",
    ],
}


def main():
    source = Pack(ROOT / "content/releases/prose_001")
    bundles = []
    for meaning, bodies in ADDITIONS.items():
        for index, body in enumerate(bodies, 1):
            suffix = meaning.replace(".", "_") + f"_{index}"
            job = {
                "id": "job.presence_002." + suffix,
                "source_release": source.id,
                "source_sha256": source.hash,
                "meaning": meaning,
                "when": {"all": []},
                "slots": [],
                "group": meaning + ".presence_002",
                "required": [],
                "forbidden": [],
                "reviewers": ["presence_review"],
                "min_chars": 30,
                "max_chars": 500,
            }
            draft = {"id": meaning + f".p002.{index}", "job_id": job["id"],
                     "job_sha256": digest(job), "body": body}
            review = {
                "job_sha256": digest(job), "draft_sha256": digest(draft),
                "reviewer": "presence_review", "verdict": "accept",
                "checks": {key: True for key in ("outcome", "knowledge", "continuity", "voice", "variation")},
                "notes": "既存結果を変えず、真帆の身体動作、周囲の音、距離感を補う短い生活描写として確認した。",
            }
            bundles.append({"job": job, "draft": draft, "reviews": [review]})
    target = ROOT / "content/releases/prose_002"
    pack = Pack(target) if target.exists() else Pack(publish(source, target.parent, "prose_002", bundles))
    report = {
        "release": pack.id, "source_release": source.id, "sha256": pack.hash,
        "added_texts": len(bundles), "total_texts": len(pack.texts),
        "meanings_expanded": sorted(ADDITIONS), "same_game_rules": pack.control_hash == source.control_hash,
    }
    write_json(ROOT / "verification/presence_prose_inventory.json", report)
    print(report)


if __name__ == "__main__":
    main()
