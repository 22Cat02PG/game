"""v8.4.17（ユーザー 2026-10-07 13:41「進めろ。次があるだろ」）：010 だけ。
本文の再会を減らす 四束目（胸に手で触れたまま体位を移る前半、自分の上を脱ぐ・真帆の上を脱がせる・服の上から胸・胸の右左両方、短い一行）。"""
import unittest
from pathlib import Path

from nagishima.content import Pack

ROOT = Path(__file__).resolve().parents[1]
P009 = Pack(ROOT / "content/releases/interaction_009")
P010 = Pack(ROOT / "content/releases/interaction_010")
NEW = [t for t in P010.texts if t["id"].startswith("v8417.") or (t["id"].startswith("cmp.") and any(f".y{n}" in t["id"] for n in range(1, 5)))]
CHEST_HAND = {"any": [{"field": "contact.h_chest_over.active", "op": "eq", "value": True}, {"field": "contact.h_chest_skin.active", "op": "eq", "value": True}]}
OFF = lambda action: {"field": f"contact.{action}.active", "op": "eq", "value": False}  # noqa: E731
WORN = {"field": "actor.maho.clothing.upper", "op": "eq", "value": "worn"}


class V8417(unittest.TestCase):
    def test_009_unchanged(self):
        self.assertFalse(any(t["id"].startswith(("cmp.", "v8417.")) for t in P009.texts))

    def test_new_scenes(self):
        meanings = {t["meaning"] for t in NEW}
        for meaning in ("h_pos_maho_above.start", "h_pos_sitting_close.start", "h_pos_lying_face.start", "h_pos_player_above.start",
                        "h_strip_self_upper.start", "h_strip_upper.start", "h_chest_over.start",
                        "h_chest_skin.side_left", "h_chest_skin.side_right", "h_chest_skin.side_both",
                        "h_hands.continue_short", "system.contact_released.hug", "system.contact_released.hands"):
            self.assertIn(meaning, meanings)
        self.assertGreater(len(NEW), 1500)

    def test_chest_hand_moves(self):
        moves = [t for t in NEW if t["meaning"].startswith("h_pos_")]
        self.assertTrue(moves)
        for text in moves:
            when = text["when"]["all"]
            self.assertIn(CHEST_HAND, when, text["id"])
            self.assertIn(OFF("h_chest_mouth"), when)
            # 胸に触れている最中は出さない後半（胸の触れ合いを両方「ない」とする条件）とはつながない
            self.assertFalse(OFF("h_chest_over") in when and OFF("h_chest_skin") in when, text["id"])

    def test_clothes_and_sides(self):
        for text in NEW:
            a = text["id"].rsplit(".", 2)[1] if text["id"].startswith("cmp.") else ""
            if text["meaning"] == "h_chest_over.start":
                self.assertIn(WORN, text["when"]["all"], text["id"])
            if "coaface" in a:
                self.assertIn({"field": "intimacy.side.h_chest_over", "op": "in", "value": ["right", "left"]}, text["when"]["all"])
        # 胸の左右：後半は左・右・両方で同じ部品を使う
        for meaning in ("h_chest_skin.side_left", "h_chest_skin.side_right", "h_chest_skin.side_both"):
            self.assertTrue(any(t["id"].endswith(".y1clbcalm01") for t in P010.by_meaning[meaning]))

    def test_strip_conditions(self):
        # 脱がせる本文を選ぶときには、もう脱いだ（off）になっているので、「脱ぐ前の服」の条件は付けない
        for text in P010.texts:
            if text["meaning"] in ("h_strip_upper.start", "h_strip_upper.first"):
                self.assertNotIn(WORN, text["when"]["all"], text["id"])
            if text["meaning"] == "h_strip_under.start":
                self.assertNotIn({"field": "actor.maho.clothing.lower", "op": "eq", "value": "underwear"}, text["when"]["all"], text["id"])

    def test_review_fixes(self):
        flow = P010.intimacy.flow
        self.assertIn("holding", flow.info({"id": "x", "meaning": "h_hands.start", "body": "真帆の手を取って指を絡める。"})[3])
        for text in NEW:
            if text["meaning"].startswith("h_pos_"):
                self.assertIn({"field": "flow.prev.holding", "op": "eq", "value": False}, text["when"]["all"], text["id"])
        self.assertNotIn("cmp.h_chest_over.start.y1coaface02.y3cobcalm04", P010.by_text)

    def test_short_lines(self):
        line = P010.by_text["v8417.h_hands.continue_short.y4hc05"]
        self.assertIn(OFF("h_kiss_deep"), line["when"]["all"])  # 台詞の一行は、口づけているあいだは出さない
        self.assertIn({"field": "intimacy.active", "op": "eq", "value": True}, P010.by_text["v8417.system.contact_released.hug.y3hr03"]["when"]["all"])

    def test_pairs(self):
        self.assertNotIn("cmp.h_strip_self_upper.start.y3sua02.y2subcalm02", P010.by_text)  # 脇へ放った服を手から取り上げる
        self.assertIn("cmp.h_strip_self_upper.start.y1sua01.y2subcalm02", P010.by_text)


if __name__ == "__main__":
    unittest.main()
