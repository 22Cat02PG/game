"""v8.2.28（ユーザー 2026-09-30「自動プレイが早すぎる。すごくよかったけど、そこが難点」→ Opus の案を了承「おけ．では始めて」）：
自動で続けるの待ち時間を長くし、設定の画面で速さ（ゆっくり・ふつう・はやい・切）を選べるようにし、止め方の案内を待つたびに出す。
公開の選択肢（Engine.choose／get_view）とテキスト版の画面から確かめる（高まりの準備だけ内部で行う）。"""
import contextlib
import io
import unittest
from copy import deepcopy
from unittest import mock

import nagishima.__main__ as cli
from nagishima.auto_continue import auto_next
from nagishima.session import Session
from nagishima.stage_b_state import validate as validate_intimacy_state
from tests.test_v8220 import FakeLog
from tools.run_stage_b_routes import Route


class V8228(unittest.TestCase):
    def route(self, seed):
        route = Route(seed, tier="familiar", day_offset=2)
        self.addCleanup(route.close)
        return route

    def set_speed(self, route, speed):
        route.choose("menu.settings")
        route.choose("settings.auto_speed." + speed)
        route.choose("menu.main")

    def moving(self, route):
        route.begin()
        for key in ("h_strip_lower", "h_shift_under", "h_strip_self", "h_pos_lying_face"):
            route.action(key)
        route.engine._state["intimacy"]["maho"].update(arousal=45, band="mid")  # 準備：入れられるところまで
        route.engine._install_choices()
        route.action("h_insert")
        self.calm(route)
        route.action("h_move_normal")
        return route

    def calm(self, route):
        intimate = route.engine._state["intimacy"]
        intimate["maho"].update(arousal=30, band="mid")
        intimate["player"]["arousal"] = 10
        route.engine._install_choices()

    def expected(self, route, percent):
        auto = route.engine.pack.intimacy.auto
        characters = sum(len(block["body"]) for block in route.engine.get_view()["blocks"])
        return min(auto["max_ms"], max(auto["min_ms"], auto["base_ms"] + auto["per_char_ms"] * characters)) * percent // 100

    def test_default_wait_is_longer(self):
        route = self.moving(self.route(2801))
        auto = route.engine.pack.intimacy.auto
        self.assertEqual((auto["base_ms"], auto["per_char_ms"], auto["min_ms"], auto["max_ms"]), (2000, 110, 3500, 16000))
        wait = auto_next(route.engine.pack, route.engine.snapshot(), route.engine.get_view(), "touch.h_move_normal")
        self.assertEqual(wait, self.expected(route, 100))
        self.assertGreaterEqual(wait, 3500)
        # 30字の短い1行なら、v8.2.27 まで（1.5秒＋1字 0.06秒＝3.3秒）より長い 5.3秒
        self.assertEqual(min(16000, max(3500, 2000 + 110 * 30)), 5300)

    def test_speed_setting_scales_wait_and_off_stops(self):
        for speed, percent in (("slow", 150), ("fast", 60)):
            with self.subTest(speed=speed):
                route = self.route(2802)
                self.set_speed(route, speed)
                self.assertEqual(route.engine.snapshot()["settings"]["auto_speed"], speed)
                self.moving(route)
                wait = auto_next(route.engine.pack, route.engine.snapshot(), route.engine.get_view(), "touch.h_move_normal")
                self.assertEqual(wait, self.expected(route, percent))
        route = self.route(2803)
        self.set_speed(route, "off")
        self.moving(route)
        self.assertIsNone(auto_next(route.engine.pack, route.engine.snapshot(), route.engine.get_view(), "touch.h_move_normal"))

    def test_settings_page_lists_other_speeds(self):
        route = self.route(2804)
        route.choose("menu.settings")
        choices = {c["id"]: c["label"] for c in route.engine.get_view()["choices"]}
        self.assertNotIn("settings.auto_speed.normal", choices)  # 今の速さ（既定）は並べない
        self.assertEqual(choices["settings.auto_speed.slow"], "自動で続ける：ゆっくり")
        self.assertEqual(choices["settings.auto_speed.fast"], "自動で続ける：はやい")
        self.assertEqual(choices["settings.auto_speed.off"], "自動で続ける：切")
        route.choose("settings.auto_speed.slow")
        self.assertIn("settings.auto_speed.normal", {c["id"] for c in route.engine.get_view()["choices"]})

    def test_old_saves_without_speed_are_valid(self):
        route = self.route(2805)
        state = deepcopy(route.engine.snapshot())
        self.assertNotIn("auto_speed", state["settings"])  # 既定は保存に書かない（v8.2.27 までの保存と同じ形）
        validate_intimacy_state(state, route.engine.pack)
        state["settings"]["auto_speed"] = "off"
        validate_intimacy_state(state, route.engine.pack)
        state["settings"]["auto_speed"] = "turbo"
        with self.assertRaises(Exception):
            validate_intimacy_state(state, route.engine.pack)

    def test_cli_shows_hint_every_wait_with_speed(self):
        route = self.route(2806)
        self.set_speed(route, "slow")
        self.moving(route)
        route.engine._state["intimacy"]["maho"]["arousal"] = 0  # 準備：3手のうちに真帆がもうすぐにならないように
        session = Session(route.engine, 400, test_cheats=True)
        waited = []
        outcomes = iter([("next", None), ("next", None), ("stop", None)])
        def wait_key(ms):
            waited.append(ms)
            return next(outcomes)
        buffer = io.StringIO()
        with mock.patch.object(cli, "wait_key", side_effect=wait_key), \
                mock.patch("builtins.input", side_effect=["choose touch.h_move_normal", EOFError]), contextlib.redirect_stdout(buffer):
            cli.interactive(session, FakeLog())
        output = buffer.getvalue()
        self.assertEqual(output.count("（自動で続ける・ゆっくり　Enter で次へ／ほかのキーで止める）"), 3)
        self.assertTrue(all(ms >= 3500 * 150 // 100 for ms in waited), waited)
        self.assertIn("速さ（ゆっくり・ふつう・はやい・切）は、エッチの前に設定の画面で選ぶ。", output)

    def test_cli_toggle_when_setting_is_off(self):
        route = self.route(2807)
        self.set_speed(route, "off")
        self.moving(route)
        session = Session(route.engine, 400, test_cheats=True)
        log = FakeLog()
        buffer = io.StringIO()
        with mock.patch.object(cli, "wait_key", side_effect=AssertionError("切なのに待った")), \
                mock.patch("builtins.input", side_effect=["自動", "choose touch.h_move_normal", EOFError]), contextlib.redirect_stdout(buffer):
            cli.interactive(session, log)
        self.assertIn("自動で続ける：設定で「切」になっている", buffer.getvalue())
        self.assertEqual(len(log.lines), 1)


if __name__ == "__main__":
    unittest.main()
