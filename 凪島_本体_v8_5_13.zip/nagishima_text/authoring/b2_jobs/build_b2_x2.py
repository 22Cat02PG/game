"""濃い版の本番（x2.）：「描写の濃さ：濃い」用の本文（style＝explicit）を grok に頼む（Opus、2026-09-27、ユーザー了承 13:56）。

範囲：数回・慣れ × 主な5体位（真帆の上に重なる・上になってもらう・後ろから・向かい合って膝に乗ってもらう・横向きで後ろから寄り添う）
      × 入れる・動く（3つの速さの始め・続き・さらに続き）・中で出す・外で出す・こらえきれずに出る、と、達する（真帆が入れたまま達する・同時に達する）。
試し（x1.）で書いた12件は除く。元の job（段階B 第1〜3陣、段階B2 第1陣）の meaning・state・when・must_not を引き継ぎ、「描写」を足す。

出力：grok_b2_wave_x2.json、grok依頼_B2_濃い版/（1ファイル＝1チャット）、濃い版_一覧.json
"""
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path("/home/claude/work/v810/nagishima_text")
PROMPT = (OUT / "grokプロンプト_v3_0.txt").read_text(encoding="utf-8")
LOWER_OPEN = "真帆の下は、下着をずらしてあるか脱いでいる（下着について書かない）。こちらは下を脱いでいる"
DENSE = "濃い：性器・体液・結合部の音と感触・体の反応を具体的に、露骨に書く（記号 {penis} {vagina} {semen} {love_juice} {clitoris} {nipple} {breasts} を積極的に使う。擬音も使ってよい）"
BACK_FACE = "真帆の顔は正面からは見えない（横顔・振り返り・肩越しなら書いてよい）"
TIERS = ("few", "familiar")
POSITIONS = ("player_above", "maho_above", "from_behind", "sitting_face", "side_lying")
BACK = ("from_behind", "side_lying")
MEANINGS = ["h_insert.start"] + [f"{m}.{p}" for m in ("h_move_slow", "h_move_normal", "h_move_fast") for p in ("start", "continue", "settled")] + [
    "h_finish_inside.start", "h_finish_outside.start", "h_overflow.inside"]
TIER_JA = {"few": "数回", "familiar": "慣れ"}
POS_JA = {"player_above": "上に重なる", "maho_above": "上になってもらう", "from_behind": "後ろから", "sitting_face": "膝に乗ってもらう", "side_lying": "横向きで後ろから"}

source = {}
for w in (1, 2, 3):
    for j in json.loads((ROOT / f"authoring/b_jobs/grok_wave_{w}.json").read_text(encoding="utf-8")):
        source[j["id"]] = j
for j in json.loads((ROOT / "authoring/b2_jobs/grok_b2_wave_1.json").read_text(encoding="utf-8")):
    source[j["id"]] = j
done = {j["id"].split(".", 1)[1] for j in json.loads((ROOT / "authoring/b2_jobs/grok_b2_wave_x1.json").read_text(encoding="utf-8"))}


def tier_of(job):
    tier = job["_split"]["tier"]
    return tier[0] if isinstance(tier, list) and len(tier) == 1 else tier


def dense_row(src, back):
    state = dict(src["state"])
    if "下着がずらされている" in state.get("服", ""):
        state["服"] = LOWER_OPEN
    if back:
        state["顔"] = BACK_FACE
    state["描写"] = DENSE
    row = {"id": "x2." + src["id"].split(".", 1)[1], "meaning": src["meaning"], "speech": src["speech"], "length": "120〜200字", "origin": src["origin"], "candidates": 5,
           "state": state, "_wave": "B2-x2", "_meaning": src["_meaning"], "_split": src["_split"], "when": src["when"], "group": src["group"], "style": "explicit"}
    if src.get("must_not"):
        row["must_not"] = src["must_not"]
    return row


groups = []  # (ファイル名の元, 行)
for tier in TIERS:
    for pos in POSITIONS:
        rows = []
        for src in source.values():
            if tier_of(src) == tier and src["_split"].get("position") == pos and src["_meaning"] in MEANINGS and src["id"].split(".", 1)[1] not in done:
                rows.append(dense_row(src, pos in BACK))
        rows.sort(key=lambda r: (MEANINGS.index(r["_meaning"]), r["id"]))
        groups.append((f"{TIER_JA[tier]}_{POS_JA[pos]}", rows))
climax = []
for src in source.values():
    other = src["_split"].get("other")
    if tier_of(src) in TIERS and (src["_meaning"] == "h.climax.maho" and other in ("inserted", "inserted_back") or src["_meaning"] == "h.climax.together"):
        if src["id"].split(".", 1)[1] not in done:
            climax.append(dense_row(src, other in ("inserted_back", "back")))
climax.sort(key=lambda r: r["id"])
groups.append(("達する", climax))

rows_all = [r for _, rows in groups for r in rows]
ids = [r["id"] for r in rows_all]
assert len(ids) == len(set(ids)), "id が重なる"
for tier in TIERS:
    for pos in POSITIONS:
        count = sum(1 for r in rows_all if tier_of(r) == tier and r["_split"].get("position") == pos)
        expected = 23 - sum(1 for key in done if f".{tier}.{pos}." in key)
        assert count == expected, (tier, pos, count, expected)

DENSE_NOTE = ("\n\nこの依頼は、ゲームの設定「描写の濃さ：濃い」を選んだ人向けの本文です。同じ場面の標準の本文はすでにあります。"
              "標準より露骨に、性器・体液・結合部の音と感触・体の反応を具体的に書いてください（state の「描写」のとおり）。"
              "この依頼に限り、プロンプトの「部位の語と記号は地の文で1本に2つまで」は「4つまで（同じ語・記号は2回まで）」に読み替えてください。擬音（湿った音・肌がぶつかる音）も使ってよいです。"
              "真帆の上の服は、着ているかめくれているか決まっていません。{nipple}・乳輪・胸の肌を直接書く本文は、上の服がめくれているときだけ出します（ゲームの側で条件を付けます）。"
              "そのため、各 job の5本のうち、{nipple}・乳輪・胸の肌を直接書くのは2本までにしてください。"
              "state に「顔」があるときは、そのとおりにしてください（真帆の表情を正面から見たようには書かない）。"
              "動く本文では、真帆やこちらが今にも達しそうだとは書かないでください（高まりの段階は別の本文が受け持ちます）。"
              "達する本文で「同時に達する」ときは、こちらが達したことを新しく起こった出来事として重ねて書かないでください（こちらの達し方は別の本文で書いてあります）。"
              "それ以外の規則（台詞の数、慣れの段階の語、地の文で器官を名前で呼ばず記号を使う、記号を台詞に書かない、妊娠・避妊に触れない、must_not）は同じです。")

(OUT / "grok_b2_wave_x2.json").write_text(json.dumps(rows_all, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
folder = OUT / "grok依頼_B2_濃い版"
folder.mkdir(exist_ok=True)
for old in folder.glob("*.txt"):
    old.unlink()
number = 0
listing = []
for name, rows in groups:
    for speech, kind in ((True, "台詞あり"), (False, "台詞なし")):
        part = [r for r in rows if r["speech"] == speech]
        if not part:
            continue
        count = -(-len(part) // 13)
        size = -(-len(part) // count)
        for index in range(0, len(part), size):
            chunk = part[index:index + size]
            number += 1
            lines = [json.dumps({"id": r["id"], "meaning": r["meaning"], "speech": r["speech"], "length": r["length"], "origin": r["origin"], "本数": r["candidates"],
                                 **({"must_not": r["must_not"]} if r.get("must_not") else {}), "state": r["state"]}, ensure_ascii=False) for r in chunk]
            body = ("指示\n"
                    f"次の{len(chunk)}件の job を書いてください（段階Bの2版目・描写の濃さ：濃い・{name.replace('_', '・')}・{kind}）。本数は各 job の「本数」のとおりです（合わせて{sum(r['candidates'] for r in chunk)}本）。"
                    "途中で切れそうなら、job の区切りで止めてください。「続けて」と言われたら、止めた job の次から出してください。"
                    + DENSE_NOTE + "\n\n[\n  " + ",\n  ".join(lines) + "\n]\n\n"
                    "プロンプト\n" + PROMPT)
            file_name = f"B2_濃い版_{number:02d}_{name}_{kind}.txt"
            (folder / file_name).write_text(body, encoding="utf-8")
            listing.append({"file": file_name, "jobs": len(chunk), "texts": sum(r["candidates"] for r in chunk)})
summary = {"jobs": len(rows_all), "texts": sum(r["candidates"] for r in rows_all), "files": listing}
(OUT / "濃い版_一覧.json").write_text(json.dumps(summary, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
print(json.dumps({"jobs": summary["jobs"], "texts": summary["texts"], "files": len(listing)}, ensure_ascii=False))
for item in listing:
    print(item["file"], item["jobs"], item["texts"])
