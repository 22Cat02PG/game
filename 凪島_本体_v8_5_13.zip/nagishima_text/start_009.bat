@echo off
chcp 65001 >nul
cd /d "%~dp0"
rem Stage B (interaction_009, with intimacy).
call "%~dp0start.bat" --release interaction_009 %*
exit /b %errorlevel%
