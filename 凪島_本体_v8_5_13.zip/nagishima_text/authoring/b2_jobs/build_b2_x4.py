"""濃い版・初回（x4.）：1回目のエッチの、つながる場面の「描写の濃さ：濃い」用の本文（Opus、2026-09-27 15:41 ユーザーが判断を任せた）。

範囲：初回 × 真帆の上に重なる・向かい合って横になる（初回に選べる、つながる体位はこの2つ）
      × 入れる・動く（ゆっくり・少し速く。激しくは数回から）・中で出す・外で出す・こらえきれずに出る（それぞれ「その行動の初め」を含む）、
      と、達する（真帆が入れたまま達する・同時に達する）。
元の job（段階B 第1陣 b1.、段階B2 第1陣 p1.・第5陣 p5.）の meaning・state・when・must_not を引き継ぎ、「描写」を足す。
出力：grok_b2_wave_x4.json、grok依頼_B2_濃い版/B2_濃い版_39〜.txt（x2・x3 のファイルは消さない）
"""
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path("/home/claude/work/v810/nagishima_text")
PROMPT = (OUT / "grokプロンプト_v3_0.txt").read_text(encoding="utf-8")
LOWER_OPEN = "真帆の下は、下着をずらしてあるか脱いでいる（下着について書かない）。こちらは下を脱いでいる"
DENSE = "濃い：性器・体液・結合部の音と感触・体の反応を具体的に、露骨に書く（記号 {penis} {vagina} {semen} {love_juice} {clitoris} {nipple} {breasts} を積極的に使う。擬音も使ってよい）"
POSITIONS = ("player_above", "lying_face")
MEANINGS = [m for base in ("h_insert", "h_move_slow", "h_move_normal") for m in (base + ".first", base + ".start")] + [
    "h_move_slow.continue", "h_move_slow.settled", "h_move_normal.continue", "h_move_normal.settled",
    "h_finish_inside.first", "h_finish_inside.start", "h_finish_outside.first", "h_finish_outside.start", "h_overflow.inside"]
POS_JA = {"player_above": "上に重なる", "lying_face": "向かい合って横になる"}

source = {}
for j in json.loads((ROOT / "authoring/b_jobs/grok_wave_1.json").read_text(encoding="utf-8")):
    source[j["id"]] = j
for w in (1, 5):
    for j in json.loads((ROOT / f"authoring/b2_jobs/grok_b2_wave_{w}.json").read_text(encoding="utf-8")):
        source[j["id"]] = j


def tier_of(job):
    tier = job["_split"]["tier"]
    return tier[0] if isinstance(tier, list) and len(tier) == 1 else tier


def dense_row(src):
    state = dict(src["state"])
    if "下着がずらされている" in state.get("服", ""):
        state["服"] = LOWER_OPEN
    state["描写"] = DENSE
    row = {"id": "x4." + src["id"].split(".", 1)[1], "meaning": src["meaning"], "speech": src["speech"], "length": "120〜200字", "origin": src["origin"], "candidates": 5,
           "state": state, "_wave": "B2-x4", "_meaning": src["_meaning"], "_split": src["_split"], "when": src["when"], "group": src["group"], "style": "explicit"}
    if src.get("must_not"):
        row["must_not"] = src["must_not"]
    return row


groups = []
for pos in POSITIONS:
    rows = [dense_row(s) for s in source.values() if tier_of(s) == "first" and s["_split"].get("position") == pos and s["_meaning"] in MEANINGS]
    rows.sort(key=lambda r: (MEANINGS.index(r["_meaning"]), r["id"]))
    groups.append((f"初回_{POS_JA[pos]}", rows))
climax = [dense_row(s) for s in source.values() if tier_of(s) == "first" and (s["_meaning"] == "h.climax.maho" and s["_split"].get("other") == "inserted" or s["_meaning"] == "h.climax.together")]
climax.sort(key=lambda r: r["id"])
groups.append(("初回_達する", climax))
rows_all = [r for _, rows in groups for r in rows]
assert len({r["id"] for r in rows_all}) == len(rows_all)

DENSE_NOTE = ("\n\nこの依頼は、ゲームの設定「描写の濃さ：濃い」を選んだ人向けの本文です。同じ場面の標準の本文はすでにあります。"
              "標準より露骨に、性器・体液・結合部の音と感触・体の反応を具体的に書いてください（state の「描写」のとおり）。"
              "この依頼に限り、プロンプトの「部位の語と記号は地の文で1本に2つまで」は「4つまで（同じ語・記号は2回まで）」に読み替えてください。擬音（湿った音・肌がぶつかる音）も使ってよいです。"
              "\n今回は二人の1回目のエッチです。露骨に書くのは、地の文の感触と体の反応です。真帆の台詞・表情・動作は、初回の戸惑いと照れのままにしてください（慣れた様子や、自分から求める積極さにしない）。"
              "台詞の語は初回の語（胸、ここ）だけです。痛みを大げさにしない。出血や、初めてであることの説明は書かない（地の文に「初めて」と書かない規則のとおり）。"
              "\n真帆の上の服は、着ているかめくれているか決まっていません。{nipple}・乳輪・胸の肌を直接書く本文は、上の服がめくれているときだけ出します（ゲームの側で条件を付けます）。そのため、各 job の5本のうち、{nipple}・乳輪・胸の肌を直接書くのは2本までにしてください。"
              "動く本文では、真帆やこちらが今にも達しそうだとは書かないでください（高まりの段階は別の本文が受け持ちます）。"
              "速さだけ違う job（ゆっくり・少し速く）の本文は、同じ番号どうしで書き出し・流れ・結びを変えてください（速さの語だけを替えた写しは使えません）。"
              "中で出した・果てた直後の台詞に「大丈夫」「そのままでいい」「離さなくていい」のような、中に出したことを許す意味に読める言い方を使わないでください。"
              "達する本文で「同時に達する」ときは、こちらが達したことを新しく起こった出来事として重ねて書かないでください。"
              "それ以外の規則（台詞の数、慣れの段階の語、地の文で器官を名前で呼ばず記号を使う、記号を台詞に書かない、妊娠・避妊に触れない、must_not）は同じです。")

(OUT / "grok_b2_wave_x4.json").write_text(json.dumps(rows_all, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
folder = OUT / "grok依頼_B2_濃い版"
number = 38
listing = []
for name, rows in groups:
    splits = ((None, "台詞あり・なし"),) if len(rows) <= 13 else ((True, "台詞あり"), (False, "台詞なし"))  # 小さな組は1ファイルに
    for speech, kind in splits:
        part = [r for r in rows if speech is None or r["speech"] == speech]
        if not part:
            continue
        count = -(-len(part) // 13)
        size = -(-len(part) // count)
        for index in range(0, len(part), size):
            chunk = part[index:index + size]
            number += 1
            lines = [json.dumps({"id": r["id"], "meaning": r["meaning"], "speech": r["speech"], "length": r["length"], "origin": r["origin"], "本数": r["candidates"],
                                 **({"must_not": r["must_not"]} if r.get("must_not") else {}), "state": r["state"]}, ensure_ascii=False) for r in chunk]
            body = ("指示\n"
                    f"次の{len(chunk)}件の job を書いてください（段階Bの2版目・描写の濃さ：濃い・{name.replace('_', '・')}・{kind}）。本数は各 job の「本数」のとおりです（合わせて{sum(r['candidates'] for r in chunk)}本）。"
                    "途中で切れそうなら、job の区切りで止めてください。「続けて」と言われたら、止めた job の次から出してください。"
                    + DENSE_NOTE + "\n\n[\n  " + ",\n  ".join(lines) + "\n]\n\n"
                    "プロンプト\n" + PROMPT)
            file_name = f"B2_濃い版_{number:02d}_{name}_{kind}.txt"
            (folder / file_name).write_text(body, encoding="utf-8")
            listing.append({"file": file_name, "jobs": len(chunk), "texts": sum(r["candidates"] for r in chunk)})
(OUT / "濃い版_初回_一覧.json").write_text(json.dumps({"jobs": len(rows_all), "texts": sum(r["candidates"] for r in rows_all), "files": listing}, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
print(len(rows_all), sum(r["candidates"] for r in rows_all))
for item in listing:
    print(item["file"], item["jobs"], item["texts"])
