"""Public-route checks for the structural interaction expansion."""

from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from nagishima.autoplay import next_command, next_presence_command
from nagishima.codec import read_json
from nagishima.content import Pack
from nagishima.engine import Engine
from nagishima.session import Session


ROOT = Path(__file__).resolve().parents[1]


def press(engine, identity):
    view = engine.get_view()
    return engine.choose(identity, view["revision"], view["session"])


def reach_stage_three(engine):
    game = Session(engine, max_turns=200)
    commands = []
    while engine.snapshot()["relation"]["stage"] < 3:
        observed = game.observe()
        command = next_command(observed["view"], observed["state"])
        if command is None:
            raise AssertionError({"reason": "policy_stalled", "commands": commands})
        commands.append(command["id"])
        response = game.execute(command)
        if not response["ok"]:
            raise AssertionError({"response": response, "commands": commands})
    return commands


class InteractionExpansionTests(unittest.TestCase):
    def setUp(self):
        temporary = TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.directory = Path(temporary.name)

    def engine(self, suffix="game", **kwargs):
        return Engine(self.directory / suffix, release="interaction_003", autosave=False, **kwargs)

    def test_release_adds_explicit_conversation_and_body_actions(self):
        source = Pack(ROOT / "content/releases/prose_002")
        pack = Pack(ROOT / "content/releases/interaction_003")
        self.assertEqual(len(pack.actions), 20)
        self.assertEqual(len(pack.texts) - len(source.texts), 240)
        self.assertNotEqual(pack.control_hash, source.control_hash)
        for identity in ("compliment", "gratitude", "together_words", "check_mood", "share_day", "reassurance"):
            self.assertIn(identity, pack.actions)
        for identity in ("hair", "cheek", "shoulder", "arm", "back", "forehead", "waist"):
            self.assertIn(identity, pack.actions)
            self.assertTrue(pack.actions[identity]["near"])
        drafts = read_json(ROOT / "content/releases/interaction_003/interaction_drafts.json")
        self.assertTrue(drafts["texts"])
        self.assertTrue(all(item["status"] == "working_draft" and item["reviewed"] is False for item in drafts["texts"]))

    def test_talk_and_touch_menus_have_clear_scopes(self):
        engine = self.engine(seed=7)
        press(engine, "menu.talk")
        talk_ids = {item["id"] for item in engine.get_view()["choices"]}
        self.assertIn("touch.compliment", talk_ids)
        self.assertIn("touch.check_mood", talk_ids)
        self.assertNotIn("touch.cheek", talk_ids)
        press(engine, "menu.main")
        press(engine, "menu.touch")
        touch_ids = {item["id"] for item in engine.get_view()["choices"]}
        self.assertIn("touch.cheek", touch_ids)
        self.assertIn("touch.forehead", touch_ids)
        self.assertNotIn("touch.talk", touch_ids)
        self.assertNotIn("touch.compliment", touch_ids)
        self.assertFalse(next(item for item in engine.get_view()["choices"] if item["id"] == "touch.cheek")["available"])
        self.assertEqual(next(item for item in engine.get_view()["choices"] if item["id"] == "touch.cheek")["reason"], "relationship")

    def test_repeated_kiss_changes_response_and_maho_can_kiss_back(self):
        engine = self.engine(seed=42)
        commands = reach_stage_three(engine)
        if engine.get_view()["page"] != "main":
            press(engine, "menu.main")
        if engine.snapshot()["distance"] != "near":
            press(engine, "near")
        press(engine, "menu.touch")
        first = press(engine, "touch.kiss")
        second = press(engine, "touch.kiss")
        self.assertEqual(first["blocks"][-1]["meaning"], "kiss.first")
        self.assertEqual([block["meaning"] for block in second["blocks"]], ["kiss.repeat", "offer.kiss_back"])
        self.assertEqual(engine.snapshot()["offer"]["kind"], "kiss_back")
        press(engine, "offer.accept")
        experience = engine.snapshot()["experience"]["kiss"]
        self.assertEqual(experience["by_origin"], {"player": 2, "maho": 1})
        self.assertEqual(engine.get_view()["status"]["mood_label"], "熱っぽく高揚している")
        self.assertIn("頬は熱を帯び", engine.get_view()["status"]["presence"])
        press(engine, "menu.touch")
        third = press(engine, "touch.kiss")
        self.assertEqual(third["blocks"][-1]["meaning"], "kiss.start")
        self.assertIsNone(engine.snapshot()["offer"])
        self.assertLessEqual(len(commands), 200)

    def test_cheat_can_reach_new_touch_and_save_active_contact(self):
        engine = self.engine(seed=91, test_cheats=True)
        game = Session(engine, max_turns=50, test_cheats=True)
        self.assertTrue(game.execute({"command": "cheat", "action": "contact_unlock"})["ok"])
        for identity in ("near", "menu.touch", "touch.hair"):
            self.assertTrue(game.execute({"command": "choose", "id": identity})["ok"])
        labels = {item["id"]: item["label"] for item in engine.get_view()["choices"]}
        order = [item["id"] for item in engine.get_view()["choices"]]
        self.assertEqual(labels["touch.hair"], "髪に触れたままでいる")
        self.assertEqual(labels["end.hair"], "髪から手を離す")
        self.assertEqual(order.index("end.hair"), order.index("touch.hair") + 1)
        engine.save()
        restored = Engine(self.directory / "game", seed=0, autosave=False, test_cheats=True)
        restored.load()
        self.assertEqual(restored.active_release, "interaction_003")
        self.assertEqual(restored.snapshot(), engine.snapshot())
        self.assertEqual(restored.get_view()["status"]["presence"], engine.get_view()["status"]["presence"])

    def test_same_seed_and_commands_select_same_new_text(self):
        bodies = []
        for suffix in ("a", "b"):
            engine = self.engine(suffix, seed=123, test_cheats=True)
            game = Session(engine, test_cheats=True)
            game.execute({"command": "cheat", "action": "contact_unlock"})
            game.execute({"command": "choose", "id": "menu.talk"})
            response = game.execute({"command": "choose", "id": "touch.compliment"})
            bodies.append(response["view"]["blocks"][-1])
        self.assertEqual(bodies[0], bodies[1])

    def test_presence_autoplay_exercises_reciprocity_then_completes(self):
        game = Session(self.engine("presence-auto", seed=17), max_turns=200)
        commands = []
        while game.reason is None:
            observed = game.observe()
            command = next_presence_command(observed["view"], observed["state"])
            self.assertIsNotNone(command, {"commands": commands, "state": observed["state"]})
            commands.append(command["id"])
            self.assertTrue(game.execute(command)["ok"], {"commands": commands})
        state = game.observe()["state"]
        self.assertEqual(game.reason, "completed")
        self.assertEqual(state["experience"]["hug"]["by_origin"]["maho"], 1)
        self.assertEqual(state["experience"]["kiss"]["by_origin"]["maho"], 1)
        self.assertEqual(state["experience"]["compliment"]["count"], 2)
        self.assertGreaterEqual(state["experience"]["kiss"]["count"], 4)
        self.assertEqual(state["experience"]["hair"]["count"], 1)
        self.assertEqual(state["experience"]["back"]["count"], 1)
        self.assertEqual(state["experience"]["waist"]["count"], 1)
        self.assertLessEqual(len(commands), 200)


if __name__ == "__main__":
    unittest.main()
