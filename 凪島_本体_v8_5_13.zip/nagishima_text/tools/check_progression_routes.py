"""Stage A route check (acceptance A-80/A-81) for interaction_007.

Runs the three reference policies on several seeds until run.cleared, twice
each, and compares the command lists and final states.  With --write it also
records examples/clear_i007.jsonl (base policy, seed 42) and its expectation.
Engine public API only; isolated temporary directories; autosave disabled.
"""
import argparse
import json
import sys
from pathlib import Path
from tempfile import TemporaryDirectory

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from nagishima.autoplay import next_command, next_presence_command, next_social_command  # noqa: E402
from nagishima.codec import digest  # noqa: E402
from nagishima.engine import Engine  # noqa: E402
from nagishima.progression import life_day  # noqa: E402
from nagishima.session import Session  # noqa: E402

RELEASE = "interaction_007"
BASE_SEEDS = [0, 1, 42, 20380407, 2147483647]
MODES = {"autoplay": (next_command, BASE_SEEDS), "autoplay-social": (next_social_command, BASE_SEEDS), "autoplay-presence": (next_presence_command, list(range(20)))}
MAX_TURNS = 1500


def play(policy, seed):
    with TemporaryDirectory() as directory:
        engine = Engine(directory, seed=seed, release=RELEASE, autosave=False)
        session = Session(engine, MAX_TURNS)
        start = life_day(engine.snapshot()["world"]["now"])
        commands, reason = [], None
        while session.turns < MAX_TURNS:
            if session.cleared:
                reason = "cleared"
                break
            command = policy(engine.get_view(), engine.snapshot())
            if command is None:
                reason = "policy_stalled"
                break
            response = session.execute(command)
            if not response["ok"]:
                reason = "error:" + response["error"]["code"]
                break
            commands.append(command)
        state = engine.snapshot()
        return {"reason": reason or "max_turns", "turns": len(commands), "stage": state["relation"]["stage"],
                "milestone_days": [life_day(m["at"]) - start + 1 for m in state["relation"]["milestones"]],
                "final_day": life_day(state["world"]["now"]) - start + 1, "affinity": state["affinity"]["value"],
                "desire": state["desire"], "state_sha256": digest(state), "commands": commands}


def main():
    global RELEASE
    parser = argparse.ArgumentParser()
    parser.add_argument("--write", action="store_true", help="examples/clear_i007.jsonl と期待値を書き出す")
    parser.add_argument("--release", choices=("interaction_007", "interaction_008"), default=RELEASE)
    args = parser.parse_args()
    RELEASE = args.release
    rows, ok = [], True
    for mode, (policy, seeds) in MODES.items():
        for seed in seeds:
            first, second = play(policy, seed), play(policy, seed)
            same = first["commands"] == second["commands"] and first["state_sha256"] == second["state_sha256"]
            ok &= same and first["reason"] == "cleared"
            rows.append({"mode": mode, "seed": seed, "reproduced": same, **{k: v for k, v in first.items() if k != "commands"}})
            print(f"{mode:18} seed {seed:>10}  {first['reason']:8} turns {first['turns']:4}  milestones(day) {first['milestone_days']}  reproduced {same}")
    report = ROOT / "verification" / ("stage_a2_routes.json" if RELEASE == "interaction_008" else "stage_a_routes.json")
    report.parent.mkdir(exist_ok=True)
    report.write_text(json.dumps({"release": RELEASE, "max_turns": MAX_TURNS, "all_cleared_and_reproduced": ok, "runs": rows}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    if args.write:
        route = play(next_command, 42)
        assert route["reason"] == "cleared", route["reason"]
        lines = [json.dumps(c, ensure_ascii=False) for c in route["commands"]]
        (ROOT / "examples" / "clear_i007.jsonl").write_text("\n".join(lines) + "\n", encoding="utf-8")
        (ROOT / "examples" / "clear_i007.expected.json").write_text(json.dumps({
            "release": RELEASE, "seed": 42, "commands_file": "clear_i007.jsonl", "choose_commands": route["turns"],
            "final_stage": 4, "cleared": True, "milestone_days": route["milestone_days"], "final_state_sha256": route["state_sha256"],
            "note": "007 では真帆の誘いがシードで変わるため、この操作列は seed 42 専用。複数シードは tools/check_progression_routes.py で確認する。",
        }, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print("wrote examples/clear_i007.jsonl", route["turns"], "commands")
    print("ALL OK" if ok else "NG")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
