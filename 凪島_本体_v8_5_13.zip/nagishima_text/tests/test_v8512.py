"""v8.5.12（ユーザー 2026-10-09 6:22「始めていい。最後まで進めて」）：010 だけ。日常の場面が関係の段で変わる。
仕様 docs/凪島_段階C_仕様_2026-10-08.md の第22節。"""
import re
import unittest
from pathlib import Path

from nagishima.conditions import evaluate
from nagishima.content import Pack
from nagishima.progression import life_day
from nagishima.stage_b_state import neutral_sleep_record
from tools.run_stage_b_routes import Route

ROOT = Path(__file__).resolve().parents[1]
P009 = Pack(ROOT / "content/releases/interaction_009")
P010 = Pack(ROOT / "content/releases/interaction_010")
NEW = ("v8512.", "cmp.d12")
DAILY = ["system.approach", "system.listen", "life.breakfast", "system.slept", "work.block.morning", "work.block.afternoon", "work.block.late",
         "work.lunch", "life.dinner", "life.bath", "maho.went_to_bed", "offer.shared.tea", "offer.shared.quiet", "offer.shared.walk",
         "offer.shared.reading", "system.waited", "system.contact_ended", "talk.start", "gratitude.start", "share_day.start", "compliment.start",
         "together_words.start", "reassurance.start", "ev.kitchen.begin"] + [f"activity.{k}.{e}" for k in ("quiet", "walk", "reading", "tea", "help", "repair") for e in ("begin", "end")]
# 恋人になってから（段階3以上）は、新しい本文だけが出る場面（様子を見る・時間を過ごす・手を離す・話す（話しかける以外）・夕食の支度は、これまでの本文も残す）
LOVER_ONLY = ["system.approach", "life.breakfast", "system.slept", "work.block.morning", "work.block.afternoon", "work.block.late", "work.lunch",
              "life.dinner", "life.bath", "maho.went_to_bed", "offer.shared.tea", "offer.shared.quiet", "offer.shared.walk", "offer.shared.reading",
              "talk.start"] + [f"activity.{k}.{e}" for k in ("quiet", "walk", "reading", "tea", "help", "repair") for e in ("begin", "end")]
MIN_STAGE = {"compliment.start": 1, "together_words.start": 2, "reassurance.start": 2, "system.contact_ended": 1}
MINUTES = {"offer.shared.tea": [600, 900], "offer.shared.walk": [1000, 1100], "offer.shared.quiet": [1000, 1200, 1300], "offer.shared.reading": [1200, 1300]}
PLACES = {"offer.shared.walk": ["coast", "garden"], "activity.walk.begin": ["coast", "garden"], "activity.walk.end": ["coast", "garden"],
          "system.listen": ["living_room", "cafe", "pier"], "system.approach": ["living_room", "cafe"]}


def base_values():
    r = Route(11, hour=10, minute=0, day_offset=3, release="interaction_010", tier="familiar")
    values = P010.registry.values(r.engine._state)
    r.close()
    return values


def values(base, **change):
    v = dict(base, **{"relation.stage": 3, "sleep.cooling": "none", "sleep.night.has": False, "contact.hands_both.active": False, "contact.hug.active": False,
                      "desire.level": "low", "progression.days_since_milestone": 3, "together": True, "actor.player.location": "living_room",
                      "actor.maho.location": "living_room", "event.meal": "dinner", "fish.dinner": None, "world.minute": 600})
    v.update({key.replace("__", "."): value for key, value in change.items()})
    return v


def candidates(v, meaning):
    return [t["id"] for t in P010.by_meaning[meaning] if not t["fallback"] and evaluate(t["when"], v) is True]


def set_stage(engine, stage, last_days_ago=5):
    """関係の段を、節目の記録とそろえて置く。いちばん新しい節目は last_days_ago 日前。"""
    s, c = engine._state, engine.pack.catalog
    now = s["world"]["now"]
    at = lambda i: now - (last_days_ago + (stage - 1 - i) * 3) * 1440
    s["relation"].update(stage=stage, milestones=[{"id": c["milestones"][i]["id"], "stage": i + 1, "at": at(i), "source": "native"} for i in range(stage)],
                         dating_since=at(2) if stage >= 3 else None, life_since=at(3) if stage >= 4 else None)
    engine._install_choices()


def go(r, page):
    view = r.engine.get_view()
    if view["page"] != page:
        if view["page"] != "main":
            r.choose("menu.main")
        if page != "main":
            r.choose("menu." + page)


def clear(r):
    if r.engine._state.get("offer"):
        r.choose("offer.decline")


def morning(stage, milestone_last_night=False, cooling=None, night=False, seed=60):
    """21:30 から眠って、起きた朝の本文 {意味: id}。"""
    r = Route(seed, hour=21, minute=30, day_offset=4, release="interaction_010", tier="familiar")
    s = r.engine._state
    s["affinity"]["value"] = 0  # 次の節目を出さない
    set_stage(r.engine, stage)
    if milestone_last_night:
        milestones = s["relation"]["milestones"]
        milestones[-1]["at"] = s["world"]["now"] - 30
        s["relation"].update(dating_since=milestones[2]["at"] if stage >= 3 else None, life_since=milestones[3]["at"] if stage >= 4 else None)
    if cooling or night:
        s["sleep_record"] = neutral_sleep_record()
        if cooling:
            s["sleep_record"]["cooling"] = {"kind": cooling, "until": life_day(s["world"]["now"]) + 3}
    r.engine._install_choices()
    if night:
        # 前の夜の寝込みの記録（目覚めなかった夜。翌朝の一言は、起きたときに記録から決まる）
        s["sleep_record"]["night"] = {"day": life_day(s["world"]["now"]), "kind": None, "pleasure": 60, "discomfort": 0, "level": 1, "flags": [], "used": [],
                                      "fake_reveal": False, "reaction": None}
    clear(r)
    go(r, "main")
    view = r.choose("sleep")
    out = {b["meaning"]: b.get("variant") for b in view["blocks"]}
    r.close()
    return out


class V8512(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.base = base_values()

    def test_009_unchanged(self):
        self.assertFalse([i for i in P009.by_text if i.startswith(NEW)])
        self.assertTrue([i for i in P010.by_text if i.startswith("v8512.")])
        self.assertTrue([i for i in P010.by_text if i.startswith("cmp.d12")])

    def test_texts_cover_every_state(self):
        """段・怒っている／警戒している日・両手・体ごとの触れ合い・欲求・節目からの日数・時刻・場所のどの組み合わせでも、書いた本文がある。"""
        missing = []
        for meaning in DAILY:
            for stage in range(MIN_STAGE.get(meaning, 0), 5):
                for cooling in ("none", "angry", "guard"):
                    for hands in ((False, True) if stage >= 3 else (False,)):
                        for hug in (False, True):
                            for desire in (("low", "invite", "press") if stage >= 3 else ("low",)):
                                for days in (0, 1, 3):
                                    for night in ((False, True) if meaning == "system.slept" else (False,)):
                                        for together in ((True, False) if meaning == "system.waited" else (True,)):
                                            for minute in MINUTES.get(meaning, [600]):
                                                for place in PLACES.get(meaning, ["living_room"]):
                                                    v = values(self.base, relation__stage=stage, sleep__cooling=cooling, contact__hands_both__active=hands,
                                                               contact__hug__active=hug, desire__level=desire, progression__days_since_milestone=days,
                                                               sleep__night__has=night, together=together, world__minute=minute, actor__player__location=place)
                                                    if not candidates(v, meaning):
                                                        missing.append((meaning, stage, cooling, hands, hug, desire, days, night, together, minute, place))
        self.assertEqual(missing[:10], [])

    def test_lover_sees_only_new_texts(self):
        for stage in (3, 4):
            for meaning in LOVER_ONLY:
                v = values(self.base, relation__stage=stage, world__minute=MINUTES.get(meaning, [600])[0],
                           actor__player__location=PLACES.get(meaning, ["living_room"])[0])
                found = candidates(v, meaning)
                self.assertTrue(found, (stage, meaning))
                self.assertEqual([i for i in found if not i.startswith(NEW)], [], (stage, meaning))

    def test_early_stages_keep_old_texts(self):
        """同居を始めたころ（段階2まで）は、これまでの本文も候補に残る（段の本文と混ざる）。"""
        for meaning in ("life.breakfast", "system.slept", "work.lunch", "life.dinner", "talk.start", "activity.tea.begin"):
            v = values(self.base, relation__stage=1)
            found = candidates(v, meaning)
            self.assertTrue([i for i in found if not i.startswith(NEW)], meaning)
            self.assertTrue([i for i in found if i.startswith(NEW)], meaning)

    def test_approach_reaction_follows_stage(self):
        """そばへ寄る：始まり（こちらの動き）はどの段でも同じ部品、反応だけが段で変わる。"""
        leads = None
        for stage in range(5):
            found = [i for i in candidates(values(self.base, relation__stage=stage), "system.approach") if i.startswith("cmp.d12ap.")]
            bands = {i.split(".")[3].split("r")[0] for i in found}
            self.assertEqual(bands, {"b0"} if stage == 0 else {"b1"} if stage == 1 else {"b2"} if stage == 2 else {"b3"} if stage == 3 else {"b3", "b4"}, stage)
            stage_leads = {i.split(".")[2] for i in found}
            self.assertEqual(stage_leads, leads or stage_leads)
            leads = stage_leads
        self.assertEqual(len(leads), 6)
        old = [i for i in candidates(values(self.base, relation__stage=1), "system.approach") if not i.startswith(NEW)]
        self.assertTrue(old)
        self.assertFalse([i for i in candidates(values(self.base, relation__stage=2), "system.approach") if not i.startswith(NEW)])

    def test_mood_and_cooling_reactions(self):
        """恋人で欲求が高まっている日は、その様子の反応。怒っている・警戒している日は、その日の反応だけ（ふだんの本文は出さない）。"""
        want = candidates(values(self.base, desire__level="invite"), "system.approach")
        self.assertTrue([i for i in want if i.startswith("cmp.d12ap.") and i.split(".")[3].startswith("want")])
        for kind in ("angry", "guard"):
            for meaning in ("system.approach", "system.listen", "life.breakfast"):
                found = candidates(values(self.base, sleep__cooling=kind, relation__stage=1), meaning)
                self.assertTrue(found, (kind, meaning))
                # 様子を見るの、こちらの動きだけの短い本文（system.listen.p001.*、真帆の様子を書かない）は、その日も残る
                self.assertTrue(all(kind in i or i.startswith("system.listen.p001.") for i in found), (kind, meaning, found[:5]))
                self.assertTrue([i for i in found if kind in i], (kind, meaning))

    def test_listen_composed_not_in_town(self):
        for place in ("cafe", "shop"):
            found = candidates(values(self.base, actor__player__location=place, actor__maho__location=place), "system.listen")
            self.assertFalse([i for i in found if i.startswith("cmp.d12li.")], place)
        self.assertTrue([i for i in candidates(values(self.base), "system.listen") if i.startswith("cmp.d12li.")])

    def test_quiet_with_body_contact_keeps_old_texts(self):
        """抱きしめているあいだの静かに休むは、隣に座る新しい本文を出さず、これまでの本文。"""
        found = candidates(values(self.base, contact__hug__active=True), "activity.quiet.begin")
        self.assertTrue(found)
        self.assertFalse([i for i in found if i.startswith(NEW)])

    def test_hands_both_excludes_hand_texts(self):
        """両手をつないでいるあいだは、手を使う仕草の本文を出さない。"""
        for meaning in ("activity.quiet.begin", "talk.start"):
            held = candidates(values(self.base, contact__hands_both__active=True), meaning)
            free = candidates(values(self.base), meaning)
            self.assertTrue(held, meaning)
            self.assertLess(set(held), set(free), meaning)

    def test_morning_after_milestone(self):
        for stage in (1, 2, 3, 4):
            found = morning(stage, milestone_last_night=True)
            self.assertTrue(found["life.breakfast"].startswith(f"v8512.d2.breakfast.after{stage}."), (stage, found))
        self.assertFalse(morning(3)["life.breakfast"].startswith("v8512.d2.breakfast.after"))

    def test_cooling_morning(self):
        for kind, stage in (("angry", 3), ("guard", 1)):
            found = morning(stage, cooling=kind)
            self.assertTrue(found["system.slept"].startswith("v8512.slept.plain."), found)
            self.assertTrue(found["life.breakfast"].startswith(f"v8512.d2.breakfast.{kind}."), found)

    def test_night_record_morning_is_plain(self):
        """前の夜の寝込みの翌朝の一言が続く朝は、起きた一言が真帆の様子を書かない本文。"""
        found = morning(3, night=True)
        self.assertTrue(found["system.slept"].startswith("v8512.slept.plain."), found)
        self.assertTrue([m for m in found if m.startswith("sp.morning.")], found)
        ordinary = morning(3)
        self.assertTrue(ordinary["system.slept"].startswith("v8512.d2.slept.b3."), ordinary)

    def test_stage_walkthrough(self):
        """段を変えると、同じ「そばへ寄る」「話しかける」で出る本文が変わる。"""
        bands = {2: ("b2r",), 3: ("b3r",), 4: ("b3r", "b4r")}
        for stage in range(5):
            r = Route(40 + stage, hour=10, minute=0, day_offset=3, release="interaction_010", tier="familiar")
            r.engine._state["affinity"]["value"] = 0
            set_stage(r.engine, stage)
            clear(r)
            go(r, "main")
            view = r.engine.get_view()
            if any(c["id"] == "near" and c["available"] for c in view["choices"]):
                ids = [b.get("variant") for b in r.choose("near")["blocks"] if b["meaning"] == "system.approach"]
                self.assertEqual(len(ids), 1)
                if stage >= 2:
                    self.assertTrue(ids[0].startswith("cmp.d12ap.") and ids[0].split(".")[3].startswith(bands[stage]), (stage, ids))
            clear(r)
            go(r, "talk")
            r.choose("touch.talk")  # 初めての一回は、別の本文
            clear(r)
            go(r, "main")
            r.choose("wait.30")
            clear(r)
            go(r, "talk")
            ids = [b.get("variant") for b in r.choose("touch.talk")["blocks"] if b["meaning"] == "talk.start"]
            self.assertEqual(len(ids), 1, stage)
            if stage >= 3:
                self.assertTrue(ids[0].startswith("v8512.d7.talk."), (stage, ids))
            r.close()

    def test_text_style(self):
        """新しい本文：主人公の飲み物を決めない（器は「カップ」）、真帆を「彼女」と書かない、id は英数字、終わりは句点か括弧。"""
        new = [P010.by_text[i] for i in P010.by_text if i.startswith(NEW)]
        self.assertGreater(len(new), 700)
        for t in new:
            self.assertRegex(t["id"], r"^[\x21-\x7e]+$")
            for word in ("湯呑", "湯のみ", "彼女", "わたし", "確かめるように", "肩をすくめ"):
                self.assertNotIn(word, t["body"], t["id"])
            self.assertRegex(t["body"], r"[。」）！？…]$", t["id"])


if __name__ == "__main__":
    unittest.main()
