"""v8.2.31（ユーザー 2026-10-01「再開して」「提案が妥当である場合は直していい」）：Opus がエッチシーンを54回通して確かめた直し。
外側に触れる本文の呼び方、部屋へ行ったときの一言、毎回出る本文の候補の足し、始めの一言（台詞なし）、座ったまま仕事の前に終えたとき、
真帆がまたがっているときに自分の下を脱ぐ、初めての夜の初めて入れる本文。"""
import json
import unittest
from copy import deepcopy
from pathlib import Path

from nagishima.conditions import evaluate
from nagishima.content import Pack
from nagishima.context import Context
from tools.run_stage_b_routes import Route

ROOT = Path(__file__).resolve().parents[1]
PACK = Pack(ROOT / "content/releases/interaction_009")


def meanings(engine):
    return [b["meaning"] for b in engine.get_view()["blocks"]]


def candidates(meaning, state):
    values = PACK.registry.values(state)
    return [t for t in PACK.by_meaning[meaning] if not t["fallback"] and evaluate(t["when"], values) is True]


class V8231(unittest.TestCase):
    def route(self, seed, tier="familiar", **kw):
        route = Route(seed, tier=tier, **({"day_offset": 3, "hour": 13} | kw))
        self.addCleanup(route.close)
        return route

    def context(self, route):
        engine = route.engine
        return Context(deepcopy(engine._state), engine.pack, engine.repository, None, True)

    # ---- 呼び方：外側に触れる本文では「膣」を「秘所」で出す（ほかの呼び方と、中の本文はそのまま） ----
    def test_outer_term(self):
        route = self.route(4001)
        route.begin()
        route.action("h_strip_lower")
        self.assertEqual(route.engine.snapshot()["settings"]["terms"]["vagina"], "膣")
        context = self.context(route)
        for meaning, word in (("h_touch_under.start", "秘所"), ("h_thigh.start", "秘所"), ("h_tease.start", "秘所"), ("h_insert.start", "膣"), ("h_finger_in.start", "膣")):
            context.emit(meaning)
            self.assertEqual(context.events[-1]["bindings"]["vagina"], word, meaning)
        context.s["settings"]["terms"]["vagina"] = "おまんこ"
        context.emit("h_touch_under.start")
        self.assertEqual(context.events[-1]["bindings"]["vagina"], "おまんこ")
        # 画面に出る本文（{vagina} を含む本文を選ばせる）
        state = route.engine.snapshot()
        text = next(t for t in candidates("h_touch_under.start", state) if "{vagina}" in t["body"])
        context = self.context(route)
        context.emit("h_touch_under.start")
        bindings = context.events[-1]["bindings"]
        self.assertIn("秘所", text["body"].replace("{vagina}", bindings["vagina"]))

    # ---- 報告 7：部屋へ行ったときの一言 ----
    def test_private_began_after_first(self):
        route = self.route(4002, day_offset=0, hour=20)
        route.choose("private.begin")
        self.assertEqual(meanings(route.engine), ["private.began"])
        block = route.engine.get_view()["blocks"][0]
        self.assertTrue(block["variant"].startswith(("o38.", "k1.")), block["variant"])  # v8.2.36：慣れてからの本文（k1）も足した
        state = route.engine.snapshot()
        state["intimacy_history"]["count"] = 0
        ids = {t["id"] for t in candidates("private.began", state)}
        self.assertTrue({f"private.began.p001.{n}" for n in range(1, 5)} <= ids)
        self.assertFalse(any(i.startswith("o38.") for i in ids))

    # ---- 毎回出る本文の候補（向かい合い・慣れ） ----
    def test_pools_grew(self):
        route = self.route(4003)
        route.begin()
        state = route.engine.snapshot()
        self.assertEqual(state["intimacy"]["position"], "sitting_close")
        for meaning, least in (("h.sign.mid", 9), ("h.sign.high", 10), ("h.sign.near", 9), ("h_thigh.start", 12), ("h_kiss_deep.start", 10)):
            self.assertGreaterEqual(len(candidates(meaning, state)), least, meaning)

    # ---- 始めの一言：深い口づけのあいだ（台詞なし）も、昼休みに4本以上 ----
    def test_begin_short_quiet(self):
        route = self.route(4004, day_offset=0, hour=12, minute=20)
        route.begin()
        self.assertIn("h.begin.short", meanings(route.engine))
        state = route.engine.snapshot()
        quiet = [t for t in candidates("h.begin.short", state) if "「" not in t["body"]]
        self.assertGreaterEqual(len(quiet), 5)
        morning = self.route(4005, day_offset=0, hour=7, minute=50)
        state = morning.engine.snapshot()
        state["intimacy"] = deepcopy(route.engine.snapshot()["intimacy"])
        self.assertGreaterEqual(len([t for t in candidates("h.begin.short", state) if "「" not in t["body"]]), 4)

    # ---- 座ったまま仕事の前に終えたときは、起き上がる本文を出さない ----
    def test_work_end_seated(self):
        route = self.route(4006, day_offset=0, hour=12, minute=20)
        route.begin()
        state = route.engine.snapshot()
        self.assertEqual(state["actors"]["maho"]["posture"], "seated")
        for meaning in ("h.ended.work", "h.after_time"):
            found = candidates(meaning, state)
            self.assertGreaterEqual(len(found), 3, meaning)
            for text in found:
                self.assertFalse(any(w in text["body"] for w in ("起き上が", "身を起こ", "体を起こ", "起きよ", "重なっていた体")), text["id"])
        state["actors"]["maho"]["posture"] = "reclined"
        self.assertIn("o36.h.ended.work.s.v5", {t["id"] for t in candidates("h.ended.work", state)})

    # ---- 提案 1：真帆がまたがっているときに自分の下を脱ぐ ----
    def test_strip_self_maho_above(self):
        route = self.route(4007)
        route.begin()
        route.action("h_pos_maho_above")
        route.action("h_strip_self")
        blocks = [b for b in route.engine.get_view()["blocks"] if b["meaning"].startswith("h_strip_self.")]
        self.assertTrue(blocks and blocks[0]["variant"].startswith("o38.h_strip_self.start"), blocks)

    # ---- 提案 2：初めての夜の初めて入れる本文は、気持ちを書いた本文（濃い本文は二回目から） ----
    def test_first_insert_not_explicit(self):
        for n in range(1, 6):
            text = PACK.by_text[f"x4.h_insert.first.first.player_above.s.v{n}"]
            self.assertIn('"intimacy.history_count", "op": "ge", "value": 1', json.dumps(text["when"]))
        route = self.route(4008, tier="first", day_offset=0, hour=20)
        state = route.engine.snapshot()
        self.assertEqual(state["intimacy_history"]["count"], 0)
        route.begin()
        state = route.engine.snapshot()
        state["intimacy"]["position"] = "player_above"
        found = candidates("h_insert.first", state)
        self.assertTrue(found)
        self.assertFalse(any(t["id"].startswith("x4.") for t in found))

    # ---- 本文の形 ----
    def test_texts(self):
        data = json.loads((ROOT / "tools/stage_b/opus_texts_v8231.json").read_text(encoding="utf-8"))
        self.assertEqual(len(data["texts"]), 113)
        for row in data["texts"]:
            text = PACK.by_text[row["id"]]
            self.assertEqual(text["body"], row["body"])
            self.assertNotIn("{vagina}", text["body"])
            for word in ("妊娠", "避妊", "ゴム", "ピル"):
                self.assertNotIn(word, text["body"])


if __name__ == "__main__":
    unittest.main()
