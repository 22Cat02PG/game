"""v8.4.15（ユーザー 2026-10-07 13:39「直した方がいいやつは全部直して…進めて 全部」）：010 だけ。
読む係の指摘で残していたもののうち、不自然になるものを直した（組み合わせた本文に条件・直し・組み合わせない、前後の本文の流れの型）。"""
import json
import unittest
from pathlib import Path

from nagishima.conditions import evaluate
from nagishima.content import Pack

ROOT = Path(__file__).resolve().parents[1]
P009 = Pack(ROOT / "content/releases/interaction_009")
P010 = Pack(ROOT / "content/releases/interaction_010")
FLOW = json.loads((ROOT / "content/releases/interaction_010/intimacy.json").read_text(encoding="utf-8"))["settings"]["flow"]
PREV = lambda name: {"field": f"flow.prev.{name}", "op": "eq", "value": False}  # noqa: E731


class V8415(unittest.TestCase):
    def test_009_unchanged(self):
        self.assertIsNone(P009.intimacy.flow)

    def test_flow_types(self):
        for name in ("forehead", "temple", "nose", "forelock", "eye_level", "ear_mouth", "nod", "sweat", "giggle"):
            self.assertIn(name, FLOW["tags"])
        for name in ("service", "hush", "breathless"):
            self.assertIn(name, FLOW["moods"])
        self.assertIn(["hush", "playful"], FLOW["follow"])
        flow = P010.intimacy.flow
        # 頬・耳が色づく、まぶたが落ちるも数える
        self.assertIn("blush", flow.info({"id": "x", "meaning": "h_feel.start", "body": "真帆の耳の先が、じわじわと色を変えていく。"})[0])
        self.assertIn("eyes_closed", flow.info({"id": "y", "meaning": "h_feel.start", "body": "真帆のまぶたが落ちて、睫毛が震えた。"})[0])
        self.assertIn("service", flow.info({"id": "z", "meaning": "h_maho_feet.start", "body": "真帆は足の裏で{penis}を挟んだ。"})[3])

    def test_calm_parts_not_after_urgent(self):
        when = P010.by_text["cmp.h_check.start.w1caface01.w5cblow01"]["when"]
        for name in ("urgent", "overwhelmed", "service"):
            self.assertIn(PREV(name), when["all"])
        # 高い反応・汗の部品は、終わりを切り出した直後は出さない
        hot = [t for t in P010.by_meaning["h_feel.start"] if t["id"].endswith(".w5fbhot01")]
        self.assertTrue(hot)
        self.assertTrue(all(PREV("end") in t["when"]["all"] for t in hot))
        # 口・胸・足でしてもらった直後は、もう一度深く口づける（組み合わせた本文）を出さない
        for text in P010.by_meaning["h_kiss_deep.again"]:
            if text["id"].startswith("cmp."):
                self.assertIn(PREV("service"), text["when"]["all"])

    def test_pairs_parts_and_edits(self):
        self.assertNotIn("cmp.h_check.start.w1caface02.w6cblow02", P010.by_text)  # 「今どんな感じか」にうなずくだけ
        self.assertIn("cmp.h_check.start.w1caface01.w6cblow02", P010.by_text)  # 「つらくないか」にはうなずいてよい
        self.assertFalse(any(".w5pb04" in i for i in P010.by_text))
        self.assertIn("汗かいてきちゃった", P010.by_text["cmp.h_check.start.w1caface01.w3cbmid09"]["body"])
        # 「痛いところはないか」は、入れているか指を入れているときだけ
        inside = {"any": [{"field": "intimacy.inserted", "op": "eq", "value": True}, {"field": "contact.h_finger_in.active", "op": "eq", "value": True}]}
        self.assertIn(inside, P010.by_text["cmp.h_check.start.w1caface03.w1cblow02"]["when"]["all"])
        self.assertFalse(evaluate(inside, {"intimacy.inserted": False, "contact.h_finger_in.active": False}))


if __name__ == "__main__":
    unittest.main()
