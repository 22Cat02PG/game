from copy import deepcopy

from . import clock
from .codec import digest
from .progression import gain_affinity, change_desire, milestone_missing, life_day, day_time, DAY_START
from .conditions import evaluate, latest_memory


def clock_minutes(minute):
    """時計の分（0〜1439）を、暮らしの日の分（day_time と同じ 301〜1740）にする。"""
    return minute if minute > DAY_START else minute + 1440
from .errors import GameError, ensure


def work_clock(rules, now):
    """009 の状態表示：仕事中なら「仕事中（12:00まで）」、そうでなければ次の仕事の始まり（v8.0.8、試運転の指摘）。"""
    if not rules:
        return None
    def hhmm(minute):
        return f"{minute % 1440 // 60}:{minute % 60:02d}"
    for offset in range(0, 8):
        day = (now // 1440 + offset) * 1440
        if clock.date_time(day).weekday() not in rules.weekdays:
            continue
        for block in rules.blocks:
            start, end = day + block["start_minute"], day + block["end_minute"]
            if start <= now < end:
                return "仕事中（" + hhmm(end) + "まで）"
            if now < start:
                if offset == 0:
                    return hhmm(start) + "から"
                label = "明日" if offset == 1 else "月火水木金土日"[clock.date_time(day).weekday()] + "曜"
                return label + " " + hhmm(start) + "から"
    return None


class Life:
    def celebrate(self, kind):
        ensure(kind in ("dating", "life") and self.values()["together"], "anniversary", "二人で記念日を振り返る。")
        window = clock.anniversary_window(self.s, kind)
        ensure(window and window["available"], "anniversary", "今年の祝いの期間外、またはすでに祝っている。思い出はいつでも振り返れる。")
        self.remember("anniversary_" + kind, summary={"year": window["year"]})

    def require_time(self, duration):
        self.require_work_time(duration)
        ensure(type(duration) is int and duration >= 0 and self.now + duration <= self.s["world"]["awake_deadline"], "time", "この活動を終える時間が残っていない。休んでから続ける。")

    def work_block(self, now=None, ahead=False):
        rules = self.pack.life
        if not rules:
            return None
        now = self.now if now is None else now
        day = now - day_time(now)
        if clock.date_time(day).weekday() not in rules.weekdays:
            return None
        for block in rules.blocks:
            start, end = day + block["start_minute"], day + block["end_minute"]
            if (start - rules.go_ahead if ahead else start) <= now < end:
                return block
        return None

    def require_work_time(self, duration):
        if not self.pack.life or getattr(self, "_work_advancing", False) or duration <= 0:
            return
        now, target = self.now, self.now + duration
        for day_index in range(life_day(now), life_day(target) + 1):
            day = day_index * 1440
            if clock.date_time(day).weekday() not in self.pack.life.weekdays:
                continue
            for block in self.pack.life.blocks:
                start, end = day + block["start_minute"], day + block["end_minute"]
                ensure(not (start <= now < end or now < start < target), "work_time", "そろそろ仕事の時間だ。")

    def minutes_to_work(self, horizon):
        """009: minutes until the next work block starts within `horizon` minutes (0 inside a block), else None."""
        if not self.pack.life:
            return None
        now, target = self.now, self.now + horizon
        best = None
        for day_index in range(life_day(now), life_day(target) + 1):
            day = day_index * 1440
            if clock.date_time(day).weekday() not in self.pack.life.weekdays:
                continue
            for block in self.pack.life.blocks:
                start, end = day + block["start_minute"], day + block["end_minute"]
                if start <= now < end:
                    return 0
                if now < start < target:
                    best = start - now if best is None else min(best, start - now)
        return best

    def at_work(self):
        """009：仕事の時間の中（いつもの時間）。話題・保留した話の再開・真帆の誘いは開かない（v8.0.5、検査役G G-02）。"""
        return bool(self.pack.intimacy) and self.s["mode"] == "normal" and self.minutes_to_work(1) == 0

    def _work_event(self, block):
        rules = self.pack.life
        weekday = clock.date_time(self.now).weekday()
        fixed = rules.fixed.get((weekday, block["id"]))
        if fixed:
            return fixed
        day = life_day(self.now)
        base = self.now - day_time(self.now)
        count = 0
        for previous in rules.blocks:
            if previous["start_minute"] > block["start_minute"]:
                break
            if previous["id"] != block["id"] and not any(h["choice"] == "work.go" and h["at"] == base + previous["end_minute"] for h in self.s["history"]):
                continue
            if (weekday, previous["id"]) in rules.fixed:
                continue
            value = int(digest([self.s["world"]["seed"], "work_event", day, previous["id"]])[:12], 16)
            if value % 100 >= rules.event_chance or count >= rules.event_max:
                continue
            kind = rules.event_ids[(value // 100) % len(rules.event_ids)]
            if kind == "rain" and clock.weather(self.s["world"]["seed"], self.now // 1440) != "rain":
                continue
            count += 1
            if previous["id"] == block["id"]:
                return kind
        return None

    def go_work(self):
        block = self.work_block(ahead=True)
        ensure(block is not None and self.s["actors"]["player"]["location"] != "town" and self.s["mode"] == "normal" and not self.s["scene"] and not self.s["offer"] and not any(x["status"] == "running" for x in self.s["activities"]), "work_time", "そろそろ仕事の時間だ。")
        self.s["contacts"] = []
        target = self.now - day_time(self.now) + block["end_minute"]
        self._work_advancing = True
        try:
            self.advance(target - self.now)
        finally:
            self._work_advancing = False
        for actor in self.s["actors"].values():
            actor["location"], actor["posture"] = block["after"], "seated"
        self.s["distance"] = "normal"
        self.emit("work.block." + block["id"])
        event = self._work_event(block)
        if event:
            self.emit("work.event." + event)
        if self.pack.intimacy and self.pack.intimacy.events:
            self.event_rumor()  # 段階C（010、v8.5.4）：野外のエッチの翌日、島の人に遠回しに言われる
        lunch = self.pack.life.lunch
        if lunch and block["id"] == lunch["after_block"]:
            # 009：午前の仕事の後は、そのまま二人で昼食を取る（v8.0.8、試運転の指摘）。
            self.advance(min(lunch["minutes"], max(0, self.s["world"]["awake_deadline"] - self.now)))
            self.emit("work.lunch")
            if self.pack.intimacy:
                self.record_offer("meal_lunch")  # v8.2.19：昼の時間帯のうちは「食事をする」を選べない（meal_windows）
        self.allow_offer = True

    def meal_windows(self):
        """009（v8.2.19、GPT とユーザーの試遊）：自動の食事の記録と、その食事の時間帯（暮らしの日の分、day_time）。
        朝食は仕事の始まり（最初の勤務ブロック）まで、昼食は昼食をとる勤務ブロックの終わりから次のブロックの始まりまで、夕食は夕食の時間帯。"""
        life = self.pack.life
        if not self.pack.intimacy or not life or not life.meals:
            return []
        rows = [("meal_breakfast", "朝食", DAY_START + 1, life.blocks[0]["start_minute"])]
        if life.lunch:
            index = next(i for i, block in enumerate(life.blocks) if block["id"] == life.lunch["after_block"])
            start = life.blocks[index]["end_minute"]
            end = life.blocks[index + 1]["start_minute"] if index + 1 < len(life.blocks) else start + life.lunch["minutes"]
            rows.append(("meal_lunch", "昼食", start, end))
        dinner = life.meals["dinner"]
        rows.append(("meal_dinner", "夕食", dinner["from"], dinner["until"]))
        return rows

    def meal_eaten(self):
        """同じ食事の時間帯のうちに自動の食事を済ませていれば、その食事の名前（朝食・昼食・夕食）。なければ None。
        v8.2.25（指摘 R2・精査 B-01）：時間帯の少し前（meals.manual_before_minutes）から、手動の食事で済ませた分も見る。"""
        now = day_time(self.now)
        before = self.pack.life.meals.get("manual_before", 0) if self.pack.life and self.pack.life.meals else 0
        for group, label, start, end in self.meal_windows():
            if start - before <= now < end and not self.can_offer(group):
                return label
        return None

    def meal_block(self):
        """v8.2.26（ユーザー了承 2026-09-30、精査 B-01・確かめ役 B N5）：いま「食事をする」を止める理由。なければ None。
        - 夕食を済ませた（自動の夕食か、夕食として数えた手動の食事）暮らしの日は、その夜はもう食事をしない。
        - どの食事のあとも meals.gap_minutes（2時間半）は食事をしない。手動の食事は思い出（meal）の時刻、自動の朝食は起きて朝食を終えた時刻
          （眠ると 7:30 に起き、朝食の分だけ食べる）、自動の昼食は午前の勤務ブロックの終わりから昼食の分。保存の形は変えない。"""
        life = self.pack.life
        if not self.pack.intimacy or not life or not life.meals:
            return None
        dinner = life.meals["dinner"]
        if not self.can_offer("meal_dinner") and day_time(self.now) >= dinner["from"] - life.meals.get("manual_before", 0):
            return "今夜はもう夕食をとった。"
        gap = life.meals.get("gap", 0)
        if not gap:
            label = self.meal_eaten()
            return f"さっき{label}をとったばかり。" if label else None
        base = self.now - day_time(self.now)  # 暮らしの日の 0 分（day_time と足して時刻になる）
        ends = []
        memory = latest_memory(self.s, "meal")
        if memory is not None:
            ends.append((memory["at"], "食事"))
        if not self.can_offer("meal_breakfast"):
            ends.append((base + clock_minutes(450) + life.meals["breakfast"]["minutes"], "朝食"))
        if not self.can_offer("meal_lunch") and life.lunch:
            block = next(b for b in life.blocks if b["id"] == life.lunch["after_block"])
            ends.append((base + block["end_minute"] + life.lunch["minutes"], "昼食"))
        recent = [(at, label) for at, label in ends if 0 <= self.now - at < gap]
        if recent:
            return f"さっき{max(recent)[1]}をとったばかり。"
        return None

    def record_manual_meal(self):
        """v8.2.25（指摘 R2・精査 B-01）：「食事をする」を、食事の時間帯の中か、その少し前（meals.manual_before_minutes）に終えたら、
        その食事（朝食・昼食・夕食）を済ませたことにする。18:20 に終えた食事のあと、18:30 からの夕食がもう一度入っていた。"""
        before = self.pack.life.meals.get("manual_before", 0)
        now = day_time(self.now)
        for group, _label, start, end in self.meal_windows():
            if start - before <= now < end:
                self.record_offer(group)

    def auto_dinner(self):
        """009（v8.1.0）：夕食の時間帯に手が空いたら、二人で夕食を取る（1日1回。3回目の試運転の指摘4）。"""
        meals = self.pack.life.meals if self.pack.life else None
        if not meals or not self.pack.intimacy:
            return
        dinner = meals["dinner"]
        if not dinner["from"] <= day_time(self.now) < dinner["until"]:
            return
        if self.s["mode"] != "normal" or self.s["scene"] or self.s["offer"] or any(x["status"] == "running" for x in self.s["activities"]):
            return
        if self.s["maho_sleep"]["state"] != "awake" or self.s["actors"]["player"]["location"] == "town" or not self.can_offer("meal_dinner"):
            return
        if self.pack.life.town and self.in_town():
            return  # 段階C（010、v8.5.11）：島の町にいるあいだは、夕食の支度を始めない（喫茶店で食べてもよい。家に戻ってから）
        if self.deep_touching():
            return  # 深める触れ合いの最中は、夕食を後回しにする（v8.2.0、4回目の試運転の指摘4）
        if self.pack.intimacy.events and "kitchen" in self.pack.intimacy.events.events:
            # 段階C（010、v8.5.2）：すぐ食べ終えるのでなく、真帆が台所で支度を始める（支度の間は台所のイベント。居間で待てば、すぐ夕食まで進む）
            self.s["contacts"] = []
            for actor in self.s["actors"].values():
                actor["location"], actor["posture"] = "kitchen", "standing"
            self.event_begin("kitchen")
            self.dinner_now = True
            return
        self.eat_dinner()

    def eat_dinner(self, text=True):
        """夕食（台所で食べて、食後は居間へ）。text：夕食の一言を出すか（台所のエッチのあとは、終わりの一言が夕食まで書く）。"""
        dinner = self.pack.life.meals["dinner"]
        minutes = min(dinner["minutes"], max(0, self.s["world"]["awake_deadline"] - self.now))
        self.record_offer("meal_dinner")
        self.s["contacts"] = []
        for actor in self.s["actors"].values():
            actor["location"], actor["posture"] = dinner["after"], "seated"  # 台所で食べて、食後は居間へ
        self.s["distance"] = "normal"
        before = self.now
        self.advance(minutes)
        self.auto_minutes += self.now - before
        caught = self.fish_dinner_take() if self.pack.life.fishing else None
        if text:
            # 段階C（010、v8.5.11）：その日に釣った魚があれば、いつもの夕食の一言の代わりに、その魚の夕食
            self.emit("fish.dinner." + caught if caught else "life.dinner")
        self.dinner_now = True  # 夕食の直後は、風呂に誘えるように一度画面へ戻す（v8.2.0）

    def deep_touching(self):
        """いつもの時間に、深める触れ合い（深いキス・耳元・胸・太もも・服の中）を続けているか。"""
        gate = self.pack.intimacy.b2["gate"]["touches"] if self.pack.intimacy else {}
        return any(c["action_id"] in gate for c in self.s["contacts"])

    # ---- 風呂（009、v8.2.0。3回目の試運転の指摘4） ----
    def bath_rules(self):
        return self.pack.life.bath if self.pack.life and self.pack.intimacy and self.pack.life.bath else None

    def bath_desire(self, amount):
        """湯上がりの間は、話す・触れるで真帆の欲求が上がりやすい。"""
        from .life_rules import bath_after
        if amount > 0 and bath_after(self.s, self.pack.life):
            return amount * self.pack.life.bath["desire_percent"] // 100
        return amount

    def bath_ready(self, start):
        """今、風呂に入れるか（時間帯・手が空いている・真帆が起きていて家にいる・今日まだ入っていない）。"""
        rules = self.bath_rules()
        if not rules or self.s["bath"]["day"] == life_day(self.now):
            return False
        if not start <= day_time(self.now) < rules["until"]:
            return False
        if self.s["mode"] != "normal" or self.s["scene"] or self.s["offer"] or any(x["status"] == "running" for x in self.s["activities"]):
            return False
        if self.pack.life.town and self.in_town():
            return False  # 段階C（010、v8.5.11）：島の町にいるあいだは入らない
        return self.s["maho_sleep"]["state"] == "awake" and self.s["actors"]["player"]["location"] != "town"

    def take_bath(self, together):
        rules = self.bath_rules()
        day = life_day(self.now)
        minutes = min(rules["together_minutes" if together else "minutes"], max(0, self.s["world"]["awake_deadline"] - self.now))
        self.s["contacts"] = []
        for actor in self.s["actors"].values():
            actor["location"], actor["posture"] = rules["after"], "seated"  # 風呂の後は居間で過ごす
        self.s["distance"] = "normal"
        before = self.now
        self.advance(minutes)
        self.auto_minutes += self.now - before
        self.bath_done(day, together, desire=True)
        self.emit("life.bath.together" if together else "life.bath")

    def bath_done(self, day, together, desire):
        """風呂を済ませた記録と湯上がり（一人で入る・一緒に入る・浴室のイベント（段階C、010）で同じ）。desire：一緒に入って欲求が上がる（浴室でエッチまで進んだ回は、エッチの記録で決める）。"""
        rules, bath = self.bath_rules(), self.s["bath"]
        bath.update(day=day, after_until=self.now + rules["after_minutes"], together=together)
        self.dress_for("night")  # v8.2.19：湯上がりは髪を下ろし、部屋着に（本文の「ほどいた髪」と状態欄を合わせる。試遊）
        if together:
            bath["together_count"] += 1
            if desire and self.pack.progression:
                change_desire(self.s, self.pack.progression, rules["together_desire"])

    def auto_bath(self):
        """夜の決まった時間帯の最初の空いた時に、真帆が先に、続いてこちらが風呂に入る（1日1回）。"""
        rules = self.bath_rules()
        if not rules or getattr(self, "dinner_now", False) or self.deep_touching() or not self.bath_ready(rules["from"]):
            return  # 夕食の直後の手と、深める触れ合いの最中は入らない
        self.take_bath(False)

    def bath_reaction(self):
        """一緒に入ろうと誘ったときの真帆の答え（関係・エッチの回数・欲求で決まる。乱数は使わない）。"""
        rules, invite = self.bath_rules(), self.bath_rules()["invite"]
        if self.s["relation"]["stage"] < invite["accept_stage"]:
            return "refuse"
        count = self.s["intimacy_history"]["count"]
        if count < invite["accept_history"]:
            return "shy"
        order = {"low": 0, "invite": 1, "press": 2}
        level = self.pack.progression.desire_level(self.s["desire"]) if self.pack.progression else "low"
        if order[level] < order[invite["accept_level"]] and self.ir.tier(count, self.pack.life) != "familiar":
            return "deflect"
        return "accept"

    def bath_invite(self):
        """「一緒にお風呂に入ろうと誘う」。受けたら一緒に入る。断られたら、その日は一人で入る（時間帯なら続けて自動で）。"""
        rules = self.bath_rules()
        ensure(rules is not None, "bath", "この原稿版に風呂はない。")
        self.free()
        self.require_awake()
        ensure(self.s["mode"] == "normal", "bath", "二人の時間を区切ってから誘う。")
        ensure(self.values()["together"], "location", "真帆と同じ場所にいるときに誘う。")
        ensure(self.s["relation"]["stage"] >= rules["invite"]["show_stage"], "relationship", "まだ、そこまで誘える間柄ではない。")
        bath, today = self.s["bath"], life_day(self.now)
        ensure(bath["day"] != today, "bath", "今日はもう風呂を済ませた。")
        ensure(bath["invited_day"] != today, "bath", "今日はもう誘った。")
        ensure(rules["invite_from"] <= day_time(self.now) < rules["until"], "bath", "風呂の時間が近づいてから誘う。")
        bath["invited_day"] = today
        reaction = self.bath_reaction()
        if reaction == "accept" and self.pack.intimacy.events and "bath" in self.pack.intimacy.events.events:
            self.event_begin("bath")  # 段階C（010、v8.5.1）：浴室のイベント（洗い合う・気づく・浴室のエッチ）
        elif reaction == "accept":
            self.take_bath(True)
        else:
            self.emit("life.bath.invite." + reaction)

    def auto_work(self):
        """009：仕事の時刻になったら、そのまま仕事へ行く（v8.0.8、試運転の指摘）。"""
        if not self.at_work() or self.s["scene"] or self.s["offer"] or self.s["actors"]["player"]["location"] == "town" or any(x["status"] == "running" for x in self.s["activities"]):
            return
        before = self.now
        self.go_work()
        self.auto_minutes += self.now - before

    def free(self, allow_private=False):
        ensure(not self.s["scene"] and not self.s["offer"], "answer_first", "現在の問いに答えるか、保留・取りやめを選ぶ。")
        running = [x for x in self.s["activities"] if x["status"] == "running"]
        if running and not (allow_private and all(x["kind"] == "private_time" for x in running)):
            self.busy(running)

    def busy(self, running):
        if self.pack.intimacy:
            # 009：何を終えればよいか分かるように、活動の名前と終え方を出す（v8.0.5、試運転の指摘4）。
            labels = "・".join("二人の時間" if x["kind"] == "private_time" else self.pack.catalog["activities"][x["kind"]]["label"] for x in running)
            hint = "最初の画面の「二人の時間を区切る」で終えられる。" if any(x["kind"] == "private_time" for x in running) else "その活動の話で「ひと区切りまで過ごす」を選ぶ。"
            raise GameError("activity_busy", "進行中の「" + labels + "」を先に終える。" + hint)
        raise GameError("activity_busy", "進行中の活動を先に終える。")

    def notice(self, kind, source, at):
        identity = f"notice.{kind}.{source}"
        if not any(x["id"] == identity for x in self.s["world"]["pending_notices"]):
            self.s["world"]["pending_notices"].append({"id": identity, "kind": kind, "source_id": source, "at": at})
            self.s["world"]["pending_notices"] = self.s["world"]["pending_notices"][-64:]

    def message(self, kind, sender, at, body, facts=()):
        identity = f"message.{kind}.{at}"
        if not any(x["id"] == identity for x in self.s["inbox"]):
            self.s["inbox"].append({"id": identity, "kind": kind, "sender": sender, "recipient": "player", "at": at, "read_at": None, "facts": [deepcopy(self.s["facts"][key]) for key in facts], "body": body})
            self.s["inbox"] = self.s["inbox"][-64:]
            self.notice("message", identity, at)

    def advance(self, duration, protect=True, sleeping=False):
        ensure(type(duration) is int and 0 <= duration <= 10080, "duration", "一回の時間更新が範囲外。")
        self.require_work_time(duration)
        if not sleeping:
            self.require_time(duration)
        old, target = self.now, self.now + duration
        events = []
        for order in self.s["orders"]:
            if order["status"] == "ordered" and old < order["due_at"] <= target:
                events.append((order["due_at"], "order." + order["id"], "order", order))
        for day in range(old // 1440, target // 1440 + 1):
            weekday = clock.date_time(day * 1440).weekday()
            for definition in self.pack.catalog["messages"]:
                at = day * 1440 + definition["minute"]
                if definition["weekday"] == weekday and old < at <= target:
                    events.append((at, definition["id"], "message", definition))
        for at, identity, kind, value in sorted(events, key=lambda x: (x[0], x[1])):
            if kind == "order":
                value["status"] = "delivered"
                if self.s["project"] and self.s["project"]["order_id"] == value["id"] and self.s["project"]["status"] == "ordered":
                    self.s["project"]["status"] = "delivered"
                self.notice("delivery", value["id"], at)
                self.message("delivery_" + value["id"].replace(".", "_"), "shuichi", at, "修一は、頼まれた荷物を届けられたことに安堵し、保管所に着いたと知らせた。")
            else:
                self.message(value["id"], value["sender"], at, value["body"])
        self.s["world"]["now"] = target
        self.s["world"]["processed_until"] = target
        self.s["world"]["rng"]["world"] += target // 1440 - old // 1440
        # v8.2.25（精査 B-11）：二人で同じ場所にいるときは、待っても真帆だけ居間へ戻さない（海岸で二人で待つと、真帆が黙って居間へ移っていた）
        stay = self.pack.intimacy and self.s["actors"]["player"]["location"] == self.s["actors"]["maho"]["location"]
        if not protect and not stay and not self.s["scene"] and not self.s["offer"] and not self.s["contacts"] and not any(a["status"] == "running" for a in self.s["activities"]) and self.s["maho_sleep"]["state"] == "awake":
            weekday, minute = clock.date_time(target).weekday(), target % 1440
            destination = "workshop" if not self.pack.life and weekday < 5 and 540 <= minute < 720 else "living_room"
            self.s["actors"]["maho"]["location"] = destination
            self.s["distance"] = "normal"

    def move(self, destination, together=False, private_invitation=False):
        self.free()
        ensure(destination in self.pack.catalog["locations"] and destination != "town", "location", "この移動先は直接選べない。")
        current = self.s["actors"]["player"]["location"]
        ensure(current != "town", "trip", "町からは帰りの便で戻る。")
        if together:
            self.require_awake()
            ensure(self.values()["together"], "together", "同行するには二人が同じ場所にいる必要がある。")
        if destination in ("maho_room", "player_room") and (together or destination == "maho_room"):
            ensure(together and private_invitation and self.s["relation"]["stage"] >= 3, "room", "二人で部屋へ行く誘いから移動する。")
        duration = 0 if current == destination else 5 if self.pack.catalog["locations"][current]["group"] == self.pack.catalog["locations"][destination]["group"] == "residence" else 10
        if self.pack.life and self.pack.life.town:
            # 段階C（010、v8.5.11）：島の町の店は、開いている時刻（着く時刻で見る）だけ行ける
            from .island import town_closed
            closed = town_closed(self.pack, destination, self.now + duration)
            if closed:
                raise GameError("town_closed", closed)
        self.require_time(duration)
        kept, ended = [], []
        for contact in self.s["contacts"]:
            if not any(resource.startswith("maho.") for resource in contact["resources"]) or (together and self.pack.actions[contact["action_id"]]["keep_on_joint_move"]):
                kept.append(contact)
            else:
                ended.append(contact)
        self.s["contacts"] = kept
        if self.pack.intimacy and ended:
            self.contact_ended([c["action_id"] for c in ended])  # 009：まとめて終わるときは本文を1つだけ（v8.0.5、検査役H H-21）。v8.2.30：種類で分ける
        for _ in ([] if self.pack.intimacy else ended):
            self.emit("system.contact_ended")
        self.s["actors"]["player"]["location"] = destination
        if together:
            self.s["actors"]["maho"]["location"] = destination
        self.s["distance"] = "near" if together and any(self.pack.actions[x["action_id"]]["near"] for x in kept) else "normal"
        self.advance(duration)
        self.emit("system.moved")
        if together and self.pack.life and self.pack.life.town and destination in self.pack.life.town["places"]:
            self.town_visit(destination)  # v8.5.11：二人で店に来た回数（着いた本文は足す前の回数で選ぶ）

    def prepare(self, actor, outfit, hair):
        self.free(allow_private=True)
        ensure(actor in ("player", "maho") and outfit in self.pack.catalog["outfits"] and hair in self.pack.catalog["hair"][actor], "appearance", "身支度の指定が未登録。")
        ensure(self.s["actors"][actor]["location"] == actor + "_room", "appearance", "本人の部屋で身支度する。")
        if self.pack.intimacy and actor == "maho":
            # 009：真帆の身支度は、起きている真帆と同じ部屋にいるときだけ（監査 D-05）。
            self.require_awake()
            ensure(self.values()["together"], "appearance", "真帆のそばで身支度を手伝う。")
        ensure(not any(any(r.startswith(actor + ".") for r in x["resources"]) for x in self.s["contacts"]), "resources", "先に手や姿勢を使う動作を終える。")
        self.advance(5)
        self.s["actors"][actor].update(outfit=outfit, hair=hair)
        self.emit("system.prepared")

    def posture(self, value):
        ensure(value in self.pack.catalog["postures"], "posture", "姿勢が未登録。")
        ensure(not any("player.posture" in x["resources"] for x in self.s["contacts"]), "resources", "姿勢を固定する動作を先に終える。")
        self.s["actors"]["player"]["posture"] = value
        self.emit("system.posture")

    def require_awake(self):
        ensure(self.s["maho_sleep"]["state"] == "awake", "maho_sleeping", "真帆は眠っている。")

    def milestone_check(self, stage):
        missing = milestone_missing(self.s, self.pack.progression, stage, clock.minutes(self.pack.catalog["start_at"]))
        ensure("awake" not in missing, "maho_sleeping", "真帆は眠っている。")
        ensure("affinity" not in missing, "relationship", "この節目には、もう少し一緒に時間を重ねる必要がある。")
        ensure("days" not in missing, "relationship", "前の節目から、もう少し日を置いてから。")

    def wake_maho(self):
        ensure(self.s["maho_sleep"]["state"] == "dozing" and self.values()["together"], "maho_wake", "起こせるのは、同じ場所でうたた寝している真帆だけ。")
        self.s["maho_sleep"].update(state="awake", since=None)
        self.emit("maho.woken")

    def maho_routine(self):
        """Maho dozes, wakes and goes to bed after each state-changing operation."""
        rules = self.pack.progression
        if rules is None:
            return
        s, now = self.s, self.now
        sleep, maho, player = s["maho_sleep"], s["actors"]["maho"], s["actors"]["player"]
        t, day = day_time(now), life_day(now)
        plan = rules.doze_plan(s["world"]["seed"], day)
        free = not s["scene"] and not s["offer"] and not s["contacts"] and s["mode"] == "normal" and not any(a["status"] == "running" for a in s["activities"])
        together = lambda: player["location"] == maho["location"]
        if sleep["state"] == "dozing" and (plan is None or t >= plan[1]):
            sleep.update(state="awake", since=None)
            s["interaction_streak"] = None
            if together(): self.emit("maho.woke")
        if sleep["state"] != "awake" or not free:
            return
        bedtime = self.pack.intimacy.holiday_bedtime if self.pack.intimacy and self.pack.intimacy.night_kind(now, self.pack.life) == "holiday_eve" else rules.bedtime
        if t >= bedtime and (self.pack.intimacy or player["location"] != "maho_room"):
            if together(): self.emit("maho.went_to_bed")
            if player["location"] == "maho_room":
                # 009 では、真帆の部屋で就寝の時刻を迎えることがある（真帆の誘いで部屋へ行き、休日前夜の就寝を過ぎるなど）。
                # 眠っている真帆の部屋に主人公はいない（段階Aの不変条件。段階Cで改める）ので、主人公は自分の部屋へ戻る。
                player["location"], player["posture"] = "player_room", "standing"
                self.s["contacts"] = []
            maho["location"], maho["posture"] = "maho_room", "reclined"
            s["distance"] = "normal"
            sleep.update(state="asleep", since=now)
            s["interaction_streak"] = None
        elif plan and maho["location"] == "living_room" and sleep["doze_day"] != day and plan[0] <= t < plan[1] and not (self.pack.intimacy and self.pack.intimacy.sleep_play and self.sleep_guarded()):
            # 段階C（010）：警戒の間は、居間でうたた寝をしない
            sleep.update(state="dozing", since=now, doze_day=day)
            s["interaction_streak"] = None
            if together(): self.emit("maho.dozed_off")

    def sleep(self, together=False):
        self.free()
        ensure(self.s["actors"]["player"]["location"] != "town", "trip", "帰りの便で島へ戻ってから休む。")
        ensure(not (self.pack.life and self.pack.life.town and self.in_town()), "town", "家に帰ってから休む。")  # 段階C（010、v8.5.11）
        cosleep = bool(self.s.get("co_sleep"))  # 段階C（010、v8.5.6）：添い寝のまま眠る（同じベッドで翌朝）
        if cosleep:
            ensure(self.s["co_sleep"]["phase"] == "asleep", "co_sleep", "真帆が眠ってから眠る。")
            together = True
        rules = self.bath_rules()
        if rules and not together and self.bath_ready(rules["invite_from"]):
            self.take_bath(False)  # v8.2.0：風呂に入らずに休もうとしたら、先に入る
        if not together and self.pack.intimacy and self.pack.intimacy.events and not self.s.get("event_play") and self.event_night_visit():
            return  # 段階C（010、v8.5.5）：夜中に真帆が来た（眠りが途中で止まる）
        self.s["contacts"] = []
        target = clock.next_clock(self.now, 450)
        self.advance(target - self.now, sleeping=True)
        self.s["world"]["awake_deadline"] = clock.next_clock(self.now, 300)
        for actor in self.s["actors"].values():
            actor["location"], actor["posture"] = "living_room", "seated"
        self.s["distance"] = "normal"
        self.s["mood"] = {key: 0 for key in self.s["mood"]}
        self.s["intention"] = None
        if self.pack.progression: change_desire(self.s, self.pack.progression, self.pack.progression.desire_sleep_change)
        self.s["maho_sleep"].update(state="awake", since=None)
        if cosleep:
            self.emit("cs.morning")  # 添い寝した朝の一言（v8.5.6）
            self.s["co_sleep"] = None
        elif not together:
            self.emit("system.slept")  # 一緒に眠るとき（B2）は、眠りにつく一言（h.sleep_together）が代わり
        if self.pack.intimacy:
            self.s["stamina"]["value"] = self.pack.intimacy.raw["player"]["stamina_max"]
            history = self.s["intimacy_history"]
            # 段階C（010、v8.5.9）：前の夜のイベント（晩酌・真帆が来る）の翌朝の一言。そのイベントのエッチが前の夜の最後のエッチなら、
            # いつもの翌朝の一言（h.morning・h.morning_together）の代わりに出す
            event_morning = self.event_morning_take() if self.pack.intimacy.events else None
            replace = bool(event_morning and event_morning["h"] and history["last_at"] == event_morning["at"])
            if history["slept_together"]:
                # B2：エッチをした夜のまま、同じベッドで目覚めた一言
                if not replace:
                    self.emit("h.morning_together." + history["last_result"])
                history["slept_together"] = False
            elif history["last_at"] is not None and life_day(history["last_at"]) == life_day(self.now) - 1 and not replace:
                self.emit("h.morning." + history["last_result"])
            if event_morning:
                self.emit("ev." + event_morning["kind"] + ".morning." + event_morning["id"])
            if self.pack.intimacy.sleep_play:
                self.sleep_morning()  # 段階C（010）：前の夜の寝込みを受けた朝の一言
        meals = self.pack.life.meals if self.pack.life and self.pack.intimacy else None
        if meals:
            # 009（v8.1.0）：目覚めたら、二人で朝食（3回目の試運転の指摘4。一緒に眠った翌朝も、ここで台所へ移る）
            for actor in self.s["actors"].values():
                actor["location"], actor["posture"] = meals["breakfast"]["after"], "seated"  # 台所で食べて、食後は居間へ
            self.advance(meals["breakfast"]["minutes"])
            self.emit("life.breakfast")
            self.record_offer("meal_breakfast")  # v8.2.19：朝の時間帯のうちは「食事をする」を選べない（meal_windows）
            self.dress_for("day")  # v8.2.19：朝食のあとの身支度で、仕事着と結んだ髪に戻る

    def dress_for(self, part):
        """009（v8.2.19、試遊）：暮らしの決まった身支度。night＝風呂のあと（二人とも部屋着、真帆は髪を下ろす）、day＝朝食のあと（仕事着、真帆は髪を結ぶ。始めたときと同じ）。"""
        if not self.pack.intimacy:
            return
        outfit, hair = ("room", "down") if part == "night" else ("work", "tied")
        if part == "day" and self.pack.life and clock.date_time(life_day(self.now) * 1440).weekday() not in self.pack.life.weekdays:
            # v8.2.30（通し確かめ 3）：仕事のない日は普段着。髪は日によって結ぶ・下ろす（休日も一日じゅう仕事着だった）
            outfit, hair = "casual", ("down" if life_day(self.now) % 2 else "tied")
        if outfit in self.pack.catalog["outfits"]:  # 部屋着がない原稿版なら、髪だけ
            for actor in self.s["actors"].values():
                actor["outfit"] = outfit
        if hair in self.pack.catalog["hair"]["maho"]:
            self.s["actors"]["maho"]["hair"] = hair

    def activity(self, identity):
        value = next((x for x in self.s["activities"] if x["id"] == identity), None)
        ensure(value is not None, "activity", "活動がないか、すでに終わっている。")
        return value

    def begin_activity(self, kind, promise_id=None):
        self.free()
        self.require_awake()
        ensure(kind in self.pack.catalog["activities"] and kind not in ("private_time", "town_trip", "install"), "activity", "この活動は専用の入口から始める。")
        definition = self.pack.catalog["activities"][kind]
        if self.pack.intimacy and kind == "meal":
            # 009（v8.2.19、試遊）：自動の朝食・昼食・夕食を済ませたら、同じ食事の時間帯のうちは、もう一度食事をしない（場所の案内より先に言う）
            reason = self.meal_block()
            ensure(reason is None, "meal_recent", reason)
        if self.pack.intimacy:
            # 009（v8.2.3、5回目の試運転の指摘3）：どこへ移ればよいかを理由に書く。約束は約束の場所で果たす。
            labels = self.pack.catalog["locations"]
            promise = next((x for x in self.s["promises"] if x["id"] == promise_id), None) if promise_id else None
            places = [promise["place"]] if promise else definition["locations"]
            where = "か".join(labels[place]["label"] for place in places)
            reason = ("約束の場所は" + where + "。" if promise else "") + "二人で" + where + "へ移動する。"
            ensure(self.values()["together"] and self.s["actors"]["player"]["location"] in places, "activity_location", reason)
        ensure(self.values()["together"] and self.s["actors"]["player"]["location"] in definition["locations"], "activity_location", "二人で活動の場所へ移動する。")
        if self.pack.life and self.pack.life.fishing and kind == self.pack.life.fishing["activity"]:
            reason = self.fishing_block()  # 段階C（010、v8.5.11）：夜遅く（終わりが23時を過ぎる）は釣りをしない
            ensure(reason is None, "fishing", reason)
        if self.pack.intimacy and promise_id is None:
            # v8.2.7（精査 A-14）：約束と同じ活動を約束の場所で始めたら、約束を果たす
            match = next((x for x in self.s["promises"] if x["kind"] == kind and x["place"] == self.s["actors"]["player"]["location"]), None)
            if match:
                promise_id = match["id"]
        ensure(len(self.s["activities"]) < 4, "activity_full", "保留中の活動を先に整理する。")
        if self.pack.life and kind in self.pack.life.drink_activities and promise_id is None:
            today = life_day(self.now)
            consumed = sum(m["kind"] == kind and life_day(m["at"]) == today for m in self.s["memories"]["recent"])
            ensure(consumed < self.pack.life.drinks_per_day, "drink_limit", "今日はもう、お茶は十分に飲んだ。")
        self.require_time(definition["minutes"])
        if promise_id:
            promise = next((x for x in self.s["promises"] if x["id"] == promise_id), None)
            ensure(promise and promise["kind"] == kind and promise["place"] == self.s["actors"]["player"]["location"], "promise", "約束した活動と場所が一致しない。")
        identity = self.new_id("activity")
        self.s["activities"].append({"id": identity, "kind": kind, "participants": ["player", "maho"], "scene_owner": None, "status": "running", "location": self.s["actors"]["player"]["location"], "started_at": self.now, "charged_minutes": 0, "remaining_minutes": definition["minutes"], "promise_id": promise_id})
        if self.pack.life and kind in self.pack.life.hands_free_activities and self.s["contacts"]:
            # 009：食事の間は触れ合いを続けない（試運転の指摘3）。始めるときに続いている触れ合いを終える。
            ended = [c["action_id"] for c in self.s["contacts"]]
            self.s["contacts"] = []
            self.contact_ended(ended)
        elif self.pack.life and kind in self.pack.life.contact_stops:
            self.stop_contacts_for(kind)
        self.begin_scene("activity_" + kind, identity)

    def stop_contacts_for(self, kind):
        """v8.4.3（010）：活動を始める・続けるときに、その活動と両立しない触れ合い（life.json の actions.contact_stops）を終える。"""
        stops = self.pack.life.contact_stops.get(kind, ())
        ended = [c["action_id"] for c in self.s["contacts"] if c["action_id"] in stops]
        if ended:
            self.s["contacts"] = [c for c in self.s["contacts"] if c["action_id"] not in stops]
            self.contact_ended(ended)

    def complete_activity(self, identity):
        activity = self.activity(identity)
        ensure(activity["status"] == "running" and self.s["actors"]["player"]["location"] == self.s["actors"]["maho"]["location"] == activity["location"], "activity", "活動の場所か進行状態が変わっている。")
        self.advance(activity["remaining_minutes"])
        self.s["progress"]["shared_activities"] += 1
        self.s["progress"]["completed_activities"] += 1
        kind = activity["kind"]
        rules = self.pack.progression
        if kind == "private_time":
            gain_affinity(self.s, rules, "private_completed")
            # v8.2.38（009）：エッチをしないまま二人の時間が終わっても、欲求は残す（キスや話だけでは満たされない）。
            # エッチをした回は、終えたときに intimacy の desire_after で決め直す（この後に上書きする）
            keep = self.pack.intimacy is not None and self.pack.intimacy.raw["desire_after"].get("keep_after_private", False)
            if rules and not keep: change_desire(self.s, rules, set_to=rules.desire_after_private)
        else:
            gain_affinity(self.s, rules, "activity_completed")
        if kind in self.s["habits"]:
            habit = self.s["habits"][kind]
            if habit["last_day"] != self.now // 1440:
                habit["count_days"] += 1
                habit["last_day"] = self.now // 1440
                if habit["count_days"] >= 3 and habit["established_at"] is None:
                    habit["established_at"] = self.now
        if activity["promise_id"]:
            promise = next((x for x in self.s["promises"] if x["id"] == activity["promise_id"]), None)
            if promise:
                ensure(promise["kind"] == kind and promise["place"] == activity["location"], "promise", "約束の履行条件が合わない。")
                self.resolve_promise(promise, "fulfilled")
        self.remember(kind)
        if self.pack.life and self.pack.life.fishing and kind == self.pack.life.fishing["activity"]:
            self.fishing_result()  # 段階C（010、v8.5.11）：釣果（図鑑と、その日の夕食に出す魚）
        if self.pack.intimacy and kind == "meal" and self.pack.life and self.pack.life.meals:
            self.record_manual_meal()
        self.s["activities"].remove(activity)
        for scene in [self.s["scene"], *self.s["suspended"]]:
            if scene and scene["activity_id"] == identity:
                scene["activity_id"] = None
        for key, value in self.s["mood"].items():
            self.s["mood"][key] = min(value, 1)
        if not (self.pack.intimacy and kind == "private_time"):
            self.emit("activity.completed")  # 009：二人の時間の終わりは private.ended だけにする（家事の終わりの本文を出さない。監査 F-12）

    def cancel_activity(self, identity):
        activity = self.activity(identity)
        if activity["kind"] == "town_trip":
            target = self.now // 1440 * 1440 + 1260
            self.advance(max(0, target - self.now))
            for actor in self.s["actors"].values(): actor["location"] = "living_room"
            self.s["distance"] = "normal"
        else:
            minutes = min(5, max(0, self.s["world"]["awake_deadline"] - self.now))
            if self.pack.intimacy:
                limit = self.minutes_to_work(minutes)
                if limit is not None:
                    minutes = limit
            self.advance(minutes)
        self.s["activities"].remove(activity)
        for scene in [self.s["scene"], *self.s["suspended"]]:
            if scene and scene["activity_id"] == identity: scene["activity_id"] = None

    def begin_private(self):
        self.require_awake()
        ensure(not self.s["offer"] and self.s["mode"] == "normal" and self.s["relation"]["stage"] >= 3 and self.values()["together"], "private", "二人の時間を始める条件が整っていない。")
        if self.s["scene"]:
            self.pause_scene()
        self.free()
        ensure(len(self.s["activities"]) < 4, "activity_full", "保留した活動を先に整理する。")
        if self.s["actors"]["player"]["location"] not in ("player_room", "maho_room"):
            event_len = len(self.events)
            self.move("player_room", True, True)
            if self.pack.intimacy:
                self.events = self.events[:event_len]  # 009：部屋へ移る本文は出さず、private.began だけにする（監査 F-12）
        self.require_time(self.pack.catalog["activities"]["private_time"]["minutes"])
        identity = self.new_id("activity")
        self.s["activities"].append({"id": identity, "kind": "private_time", "participants": ["player", "maho"], "scene_owner": None, "status": "running", "location": self.s["actors"]["player"]["location"], "started_at": self.now, "charged_minutes": 0, "remaining_minutes": self.pack.catalog["activities"]["private_time"]["minutes"], "promise_id": None})
        self.s["mode"], self.s["private_instance"], self.s["distance"] = "private", identity, "near"
        self.s["interaction_streak"] = None
        self.emit("private.began")

    def end_private(self):
        ensure(self.s["private_instance"] is not None, "private", "二人の時間が始まっていない。")
        identity = self.s["private_instance"]
        self.close_owned("private", identity)
        activity = self.activity(identity)
        if self.pack.intimacy:
            # 009：二人の時間の残りが仕事の時刻にかかるときは、仕事の始まりまでで切る。「終える」はいつでも選べる（B-19、監査 E-01・D-01）。
            limit = self.minutes_to_work(activity["remaining_minutes"])
            if limit is not None:
                activity["remaining_minutes"] = limit
        if self.now + activity["remaining_minutes"] <= self.s["world"]["awake_deadline"]:
            self.complete_activity(identity)
        else:
            self.cancel_activity(identity)
        self.s["mode"], self.s["private_instance"] = "normal", None
        self.emit("private.ended")

    def promise_blocker(self, kind):
        """009（v8.2.3、5回目の試運転の指摘3）：同じ約束が残っているか、約束が二つあるときの理由。作れるなら None。"""
        if any(x["kind"] == kind for x in self.s["promises"]):
            return self.pack.catalog["activities"][kind]["label"] + "約束は、もう交わしている。果たすか、延期・取りやめを選ぶ。"
        if len(self.s["promises"]) >= 2:
            return "約束は二つまで。先にどちらかを果たすか、取りやめる。"
        return None

    def create_promise(self, kind):
        ensure(self.values()["together"] and kind in self.pack.catalog["promise_kinds"], "promise", "この用件は約束できない。")
        if self.pack.intimacy:
            blocker = self.promise_blocker(kind)
            ensure(blocker is None, "promise_full", blocker)
        ensure(len(self.s["promises"]) < 2 and not any(x["kind"] == kind for x in self.s["promises"]), "promise_full", "未完了の約束を整理してから作る。")
        self.s["promises"].append({"id": self.new_id("promise"), "kind": kind, "participants": ["player", "maho"], "place": self.pack.catalog["activities"][kind]["locations"][0], "due_at": (self.now // 1440 + 1) * 1440 + 1260, "status": "pending", "postpone_count": 0, "created_at": self.now, "resolved_at": None})
        self.emit("promise.created")

    def resolve_promise(self, promise, status):
        self.s["promises"].remove(promise)
        promise.update(status=status, resolved_at=self.now)
        self.s["promise_history"].append(promise)
        self.s["promise_history"] = self.s["promise_history"][-32:]
        if status == "fulfilled":
            self.s["progress"]["fulfilled_promises"] += 1
            gain_affinity(self.s, self.pack.progression, "promise_fulfilled")
        for activity in self.s["activities"]:
            if activity["promise_id"] == promise["id"]: activity["promise_id"] = None

    def cancel_promise(self, identity):
        promise = next((x for x in self.s["promises"] if x["id"] == identity), None)
        ensure(promise is not None, "promise", "未完了の約束がない。")
        self.resolve_promise(promise, "cancelled")
        self.emit("promise.cancelled")

    def postpone_promise(self, identity):
        promise = next((x for x in self.s["promises"] if x["id"] == identity), None)
        ensure(promise is not None, "promise", "未完了の約束がない。")
        promise["due_at"] = max(promise["due_at"], self.now) + 1440
        promise["postpone_count"] += 1
        self.emit("promise.postponed")

    def create_order(self, kind, quantity=1):
        ensure(kind in self.pack.catalog["items"] and type(quantity) is int and 0 < quantity <= 99, "order", "注文の指定が違う。")
        ensure(len(self.s["orders"]) < 8, "order_full", "荷物を受け取るか、未発送の注文を取り消す。")
        spec = self.pack.catalog["items"][kind]
        existing = sum(x["quantity"] for x in self.s["items"] if x["catalog_id"] == kind) + sum(x["quantity"] for x in self.s["orders"] if x["catalog_id"] == kind)
        ensure(existing + quantity <= spec["capacity"], "item_capacity", "入荷予定を含む所持上限に達している。")
        order = {"id": self.new_id("order"), "catalog_id": kind, "quantity": quantity, "due_at": clock.delivery(self.now, spec["large"]), "status": "ordered", "created_at": self.now, "resolved_at": None}
        self.s["orders"].append(order)
        self.emit("order.created")
        return order

    def finish_order(self, order, status):
        self.s["orders"].remove(order)
        order.update(status=status, resolved_at=self.now)
        self.s["order_history"].append(order)
        self.s["order_history"] = self.s["order_history"][-64:]

    def cancel_order(self, identity):
        order = next((x for x in self.s["orders"] if x["id"] == identity), None)
        ensure(order and order["status"] == "ordered", "order", "到着後の荷物は受取へ進む。")
        self.finish_order(order, "cancelled")
        if self.s["project"] and self.s["project"]["order_id"] == identity and self.s["project"]["status"] == "ordered":
            self.s["project"].update(status="planned", order_id=None)
        self.emit("order.cancelled")

    def receive_order(self, identity):
        ensure(self.s["actors"]["player"]["location"] == "living_room", "order_location", "居間の保管場所で荷物を受け取る。")
        order = next((x for x in self.s["orders"] if x["id"] == identity), None)
        ensure(order and order["status"] == "delivered", "order", "未到着か、すでに受け取った荷物。")
        self.add_item(order["catalog_id"], order["quantity"], "player")
        self.finish_order(order, "received")
        if self.s["project"] and self.s["project"]["order_id"] == identity and self.s["project"]["status"] == "delivered": self.s["project"]["status"] = "ready"
        self.emit("order.received")

    def add_item(self, kind, quantity, owner):
        item = next((x for x in self.s["items"] if x["catalog_id"] == kind and x["owner"] == owner and x["storage"] == "inventory" and x["installed_at"] is None), None)
        if item: item["quantity"] += quantity
        else: self.s["items"].append({"id": self.new_id("item"), "catalog_id": kind, "quantity": quantity, "owner": owner, "storage": "inventory", "installed_at": None})

    def give_item(self, identity):
        self.require_awake()
        item = next((x for x in self.s["items"] if x["id"] == identity), None)
        ensure(self.values()["together"] and item and item["owner"] == "player" and item["installed_at"] is None, "gift", "手元にある物を、同じ場所で渡す。")
        ensure(not any(x["action_id"] == "hold_mug" for x in self.s["contacts"]) or item["catalog_id"] != "mug", "resources", "持っているカップを先に置く。")
        ensure(not self.s["project"] or self.s["project"]["status"] in ("completed", "cancelled") or self.s["project"]["catalog_id"] != item["catalog_id"], "project", "共同作業に使う物は、作業を区切ってから渡す。")
        kind = item["catalog_id"]
        item["quantity"] -= 1
        if not item["quantity"]: self.s["items"].remove(item)
        self.add_item(kind, 1, "maho")
        self.remember("gift", summary={"item": kind})
        self.emit("item.given")

    def plan_project(self):
        self.require_awake()
        ensure(self.values()["together"] and (not self.s["project"] or self.s["project"]["status"] in ("completed", "cancelled")), "project", "現在の共同作業を先に区切る。")
        ensure(not any(x["catalog_id"] == "shelf" and x["installed_at"] is not None for x in self.s["items"]), "project", "棚はすでに設置されている。")
        owned = any(x["catalog_id"] == "shelf" for x in self.s["items"])
        pending = next((x for x in self.s["orders"] if x["catalog_id"] == "shelf"), None)
        self.s["project"] = {"id": self.new_id("project"), "catalog_id": "shelf", "location": "living_room", "order_id": pending["id"] if pending else None, "status": "ready" if owned else pending["status"] if pending else "planned", "started_at": self.now, "installed_at": None, "completed_at": None}
        self.emit("project.planned")

    def order_project(self):
        ensure(self.s["project"] and self.s["project"]["status"] == "planned", "project", "注文する共同作業がない。")
        order = self.create_order(self.s["project"]["catalog_id"])
        self.s["project"].update(order_id=order["id"], status="ordered")

    def install_project(self):
        self.free()
        self.require_awake()
        project = self.s["project"]
        ensure(project and project["status"] == "ready" and self.values()["together"] and self.s["actors"]["player"]["location"] == project["location"], "project", "二人で設置場所へ集まる。")
        ensure(not any(x["action_id"] == "hold_mug" for x in self.s["contacts"]), "resources", "手に持った物を先に置く。")
        item = next((x for x in self.s["items"] if x["catalog_id"] == project["catalog_id"]), None)
        ensure(item is not None, "project", "設置する物がない。")
        self.s["contacts"] = []
        self.advance(60)
        item.update(storage=project["location"], installed_at=self.now)
        project.update(status="installed", installed_at=self.now)
        self.emit("project.installed")

    def finish_project(self):
        self.require_awake()
        project = self.s["project"]
        ensure(project and project["status"] == "installed" and self.values()["together"] and self.s["actors"]["player"]["location"] == project["location"], "project", "二人で設置場所に戻り、完成を確かめる。")
        project.update(status="completed", completed_at=self.now)
        for key in ("completed_projects", "shared_activities", "completed_activities"): self.s["progress"][key] += 1
        self.remember("project", summary={"item": project["catalog_id"]})
        self.emit("project.completed")

    def cancel_project(self):
        project = self.s["project"]
        ensure(project and project["status"] not in ("installed", "completed", "cancelled"), "project", "取りやめられる作業がない。")
        if project["status"] == "ordered": self.cancel_order(project["order_id"])
        project["status"] = "cancelled"
        self.emit("project.cancelled")

    def commit_relation(self, stage, test_cheat=False):
        ensure(type(stage) is int and stage == self.s["relation"]["stage"] + 1 and 1 <= stage <= 4, "relationship", "次の節目だけを確定できる。")
        definition = self.pack.catalog["milestones"][stage - 1]
        ensure(test_cheat or evaluate(definition["when"], self.values()) is True, "relationship", "節目に必要な出来事がまだ揃っていない。")
        if not test_cheat: self.milestone_check(stage)
        self.s["relation"]["stage"] = stage
        self.s["relation"]["milestones"].append({"id": definition["id"], "stage": stage, "at": self.now, "source": "native"})
        if stage == 3: self.s["relation"]["dating_since"] = self.now
        if stage == 4:
            self.s["relation"]["life_since"] = self.now
            self.fact_set("relation.future_home", True)
            self.learn("player", "relation.future_home")
            self.learn("maho", "relation.future_home")
        self.remember("milestone", summary={"stage": stage})
        self.emit(f"relation.{stage}")

    def read_message(self, identity):
        message = next((x for x in self.s["inbox"] if x["id"] == identity), None)
        ensure(message is not None, "message", "この連絡は一覧にない。")
        if message["read_at"] is None:
            message["read_at"] = self.now
            for fact in message["facts"]:
                self.s["knowledge"][message["recipient"]][fact["id"]] = {"snapshot": deepcopy(fact), "learned_at": self.now}
        self.emit("message.read")
        self.events[-1]["body"] = message["body"]

    def pin_memory(self, identity, pin):
        ensure(type(pin) is bool, "memory", "固定の指定が違う。")
        memory = next((x for x in self.s["memories"]["recent"] + self.s["memories"]["pinned"] if x["id"] == identity), None)
        ensure(memory is not None, "memory", "固定する思い出が見つからない。")
        existing = next((x for x in self.s["memories"]["pinned"] if x["id"] == identity), None)
        if pin and not existing:
            ensure(len(self.s["memories"]["pinned"]) < 32, "memory_full", "残す思い出を一つ選び直す。")
            self.s["memories"]["pinned"].append(deepcopy(memory))
        elif not pin and existing: self.s["memories"]["pinned"].remove(existing)
        self.emit("memory.pinned" if pin else "memory.unpinned")

    def begin_trip(self):
        self.free()
        self.require_awake()
        ensure(self.values()["together"] and clock.date_time(self.now).weekday() in (5, 6) and self.now % 1440 <= 720, "trip", "町へは土日の昼の便で出かける。")
        ensure(len(self.s["activities"]) < 4, "activity_full", "保留中の活動を先に整理する。")
        day = self.now // 1440 * 1440
        self.require_time(day + 1260 - self.now)
        self.s["contacts"] = []
        self.advance(day + 780 - self.now)
        for actor in self.s["actors"].values(): actor["location"] = "town"
        self.s["distance"] = "normal"
        identity = self.new_id("activity")
        self.s["activities"].append({"id": identity, "kind": "town_trip", "participants": ["player", "maho"], "scene_owner": None, "status": "running", "location": "town", "started_at": day + 720, "charged_minutes": 60, "remaining_minutes": 480, "promise_id": None})
        self.begin_scene("town_trip", identity)

    def advance_trip(self, phase):
        ensure(self.s["scene"] and self.s["scene"]["activity_id"], "trip", "外出中ではない。")
        activity = self.activity(self.s["scene"]["activity_id"])
        ensure(activity["kind"] == "town_trip", "trip", "外出の活動が違う。")
        if phase == "town":
            target = self.now // 1440 * 1440 + 1200
            self.advance(max(0, target - self.now))
            activity["remaining_minutes"] = 60
        elif phase == "return":
            target = self.now // 1440 * 1440 + 1260
            self.advance(max(0, target - self.now))
            activity["remaining_minutes"] = 0
            self.complete_activity(activity["id"])
            for actor in self.s["actors"].values(): actor["location"] = "living_room"
            self.s["distance"] = "normal"
