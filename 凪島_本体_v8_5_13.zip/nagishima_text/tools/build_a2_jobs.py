"""Prepare machine-readable Stage A2 authoring requests, without drafting prose."""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from nagishima.content import Pack


def job(source, identity, meaning, group, required, forbidden, reviewer, when=None, low=20, high=200):
    return {"id": identity, "source_release": source.id, "source_sha256": source.hash,
            "meaning": meaning, "when": when or {"all": []}, "slots": [], "group": group,
            "required": required, "forbidden": forbidden, "reviewers": [reviewer],
            "min_chars": low, "max_chars": high}


def main():
    source = Pack(ROOT / "content" / "releases" / "interaction_008")
    target = ROOT / "authoring" / "a2_jobs"
    target.mkdir(exist_ok=True)
    touch = sorted(source.progression.touch_actions)
    phases = ("start", "repeat", "heated", "continue", "settled")
    existing = [text for text in source.texts if text["meaning"].split(".")[0] in touch and text["meaning"].split(".")[-1] in phases]
    common = ["未成立の移動・動作・約束を本文だけで成立させない。", "未登録の過去や相手の好みを捏造しない。"]
    j1 = [job(source, "job.a2.classify." + text["id"], text["meaning"], "a2.classification",
              ["対象本文ID: " + text["id"], "対象本文: " + text["body"], "tone を surprise／shy／natural、tier を first／few／familiar／any から分類し、id・tone・tier のJSONだけを返す。"],
              ["本文を書き換えない。", "JSON以外を出さない。"], "gemini.classification", low=1, high=500)
          for text in existing]
    j2, j3, j4 = [], [], []
    for action in touch:
        for phase in ("start", "repeat"):
            meaning = action + "." + phase
            if meaning not in source.meanings:
                continue
            for variant in range(1, 4):
                j2.append(job(source, f"job.a2.familiar.{action}.{phase}.{variant}", meaning, f"a2.familiar.{action}.{phase}",
                    ["慣れた触れ合いの自然な反応を書く。", "驚き・初々しさを入れない。", "台詞は一本文に一つまで。"], common,
                    "sonnet.prose", {"field": "experience." + action + ".tier", "op": "eq", "value": "familiar"}, 30, 500))
        for phase in ("continue", "settled", "repeat", "heated"):
            meaning = action + "." + phase
            if meaning not in source.meanings:
                continue
            for variant in range(1, 4):
                j3.append(job(source, f"job.a2.narration.{action}.{phase}.{variant}", meaning, f"a2.narration.{action}.{phase}",
                    ["台詞のない地の文を書く。", "慣れの段階にかかわらず成立させる。", "目の前の身体反応と時間の流れを具体的に書く。"],
                    common + ["かぎ括弧の台詞を入れない。"], "sonnet.prose", low=30, high=500))
    for meaning in sorted(m for m in source.meanings if m.startswith("offer.shared.") or m.startswith("work.block.") or m.startswith("work.event.")):
        for variant in range(1, 5):
            j4.append(job(source, f"job.a2.life.{meaning}.{variant}", meaning, f"a2.life.{meaning}",
                ["仮本文を差し替える日常の描写を書く。", "仕事はそのブロックの要約として、誘いは活動を明示する。", "台詞は一本文に一つまで。"],
                common, "sonnet.prose", low=30, high=500))
    for name, rows in (("j1_gemini_classification", j1), ("j2_sonnet_familiar", j2), ("j3_sonnet_narration", j3), ("j4_sonnet_life", j4)):
        (target / (name + ".json")).write_text(json.dumps(rows, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
        print(name, len(rows))
    (target / "README.md").write_text("A2 原稿依頼のみ。本文・検品・取り込みは未実施。登録済み meaning だけを対象にする。J1 は 142 件、J2 は 48 件、J3 は 66 件、J4 は 48 件。\n", encoding="utf-8")


if __name__ == "__main__":
    main()
