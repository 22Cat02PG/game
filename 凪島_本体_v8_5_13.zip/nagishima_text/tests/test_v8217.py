"""v8.2.17：同じ本文を2つの job で二重に採っていた1本を外した（x2.h.climax.together.few.back.n.v3。ユーザーの確認 2026-09-29 03:09）。
仮の本文（fallback）のほかは、同じ本文が2回入らないことを確かめる（v8.2.18 で「一気に奥まで入れて果てる」本文の写し deep. をやめた）。"""
import collections
import unittest

from tools.run_stage_b_routes import Route


class V8217(unittest.TestCase):
    def test_no_double_adopted_texts(self):
        route = Route(1701, tier="familiar", day_offset=2)
        texts = route.engine.pack.texts
        route.close()
        bodies = collections.defaultdict(list)
        for text in texts:
            if not text["fallback"]:
                bodies[text["body"]].append(text["id"])
        doubled = {body[:30]: ids for body, ids in bodies.items() if len(ids) > 1}
        self.assertEqual(doubled, {})
        self.assertNotIn("x2.h.climax.together.few.back.n.v3", {t["id"] for t in texts})
        self.assertFalse(any(t["id"].startswith("deep.") for t in texts))  # v8.2.18：写しをやめた


if __name__ == "__main__":
    unittest.main()
