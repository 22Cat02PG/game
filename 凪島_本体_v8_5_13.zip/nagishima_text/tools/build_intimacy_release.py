"""Build the Stage B release (009, confirmed in v8.3.0) from the immutable 008 release.
009 は確定済み（v8.3.0）。作り直しは断り、--verify で別の場所に作って同じかを比べる。次の版は --target content/releases/interaction_010。"""
import argparse
import json
import re
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from nagishima.codec import bytes_digest, digest
from nagishima.content import Pack, FILES, PROGRESSION, LIFE, INTIMACY

SOURCE = ROOT / "content/releases/interaction_008"
TARGET = ROOT / "content/releases/interaction_009"
DATA = ROOT / "tools/stage_b"
SPEC = ROOT / "docs/凪島_段階B_仕様と受入条件_2026-09-26.md"
PUBLISHED = {f"interaction_{n:03d}" for n in range(3, 10)}  # v8.3.0：009 を確定（ユーザー 2026-10-02）
LAYER_010 = DATA / "release_010.json"  # v8.3.3：010 だけの決まり・本文・本文の直し
VERIFY_ROOT = ROOT / ".rebuild_verify"  # --verify の作業場所（包む対象の外。終わったら消す）


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def dump(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")


def fallback_events():
    section = SPEC.read_text(encoding="utf-8").split("### 9.2 基本本文（fallback）", 1)[1].split("### 9.3", 1)[0]
    result = {}
    for meaning, body in re.findall(r"^\| `([^`]+)` \| ([^|]+) \|$", section, re.M):
        if meaning.startswith(("h.", "offer.")):
            result[meaning] = body.strip()
    assert len(result) == 26, (len(result), sorted(result))
    return result


TOKEN = re.compile(r"\{([a-z_]+)\}")
# v8.2.23：切り出しの熱さの札を、どの高まりで出し分けるか。してもらう行為（手・胸・足・自分で・口・胸を吸いながら手で）は、こちらの高まり。
HEAT_PLAYER = ("h_maho_hand", "h_maho_breasts", "h_maho_feet", "h_self", "h_maho_mouth", "h_suckle_hand")
HEAT_BASIS = {"maho": ("intimacy.maho.band", {"early": ["low", "mid"], "late": ["high", "near"]}),
              "player": ("intimacy.player.arousal_band", {"early": ["low"], "late": ["ready", "max"]})}
# v8.2.23：台詞・声（「…」）と地の文のあいだで改行する
LINE_BREAK_AFTER = re.compile(r"」(?=[^」\n])")
LINE_BREAK_BEFORE = re.compile(r"(?<=[^\n「」])「")

# B2（2026-09-27）：これまでの「どの体位でも」の本文を、向き・場所・服で振り分ける。
# 新しい体位（背を向けた体位・立った体位・座った体位）や、下着を脱がせた・上を脱がせた状態と食い違わないように、
# 本文の語で条件を足す（本文は変えない）。対象は、体位の条件を持たない段階Bの本文。
FACE_CUES = ("目が合", "見上げ", "見下ろ", "首に腕", "首に回", "胸に顔", "見つめ", "覗き", "のぞき込", "額", "唇を重", "口づけ", "向かい合",
             "背中に回", "抱きつ", "しがみつ", "顔を埋", "瞳", "目を合わせ", "こちらを見", "頬に触", "頬を寄せ", "胸元に顔", "胸に額")
BED_CUES = ("シーツ", "枕", "布団", "ベッド", "寝具", "マットレス")
# v8.2.7（精査 C-08）：背を向けた体位では見えない真帆の顔の語。振り返り・肩越し・横顔・振り向きがあれば見えるので足さない。
# 「こちらの唇」のように主人公の顔を言うもの、「陰唇」「入り口を開く」は数えない。
BACK_FACE = re.compile(r"(?<!陰)唇|睫|眉|表情|目元|目を細|目を伏|目を見開|目を閉じ|目を開|目が潤|目を潤|目の端|目尻|口元|口角|口の端|視線|まぶた|瞼|まばたき|瞬き|瞬く|頬を赤|頬が赤|頬を染|頬が染|頬がゆる|頬が緩|頬を紅|頬が紅|頬が熱|顔を赤|顔が赤|赤い顔|赤くなった顔|涙目|微笑|笑みを|(?<!入り)口を開|開いた口|顎を上げ|顎が上が")
BACK_VISIBLE = ("振り返", "振り向", "肩越し", "横顔")
# v8.2.7（精査 C-12）：様子を聞く本文で、こちらが動いていることを書くもの（動いていないとき・出した後は出さない）
MOVING_CUES = ("動きを緩", "動きを止め", "緩めて", "止まらなくて", "止まらないで", "腰を止め", "動きながら", "動くたび", "揺らしながら")
MOVE_ACTIVE = {"any": [{"field": "contact." + key + ".active", "op": "eq", "value": True} for key in ("h_move_slow", "h_move_normal", "h_move_fast")]}  # こちらが動いている印（真帆に動いてもらうは含めない。v8.2.14 読み手の指摘 M-7）
GENITAL_ACTIVE = {"any": [{"field": "contact." + key + ".active", "op": "eq", "value": True} for key in ("h_touch_direct", "h_touch_under", "h_finger_in", "h_player_mouth", "h_tease", "h_sumata", "h_face_lick", "h_sixty_nine")]}
GENITAL_CUES = re.compile(r"\{clitoris\}|\{vagina\}|\{love_juice\}|陰唇|入り口|内壁|奥|襞|割れ目|中が|秘所")
FINGER_CUES = re.compile(r"こちらの指|指の腹|指腹|指で|指を(締|咥|飲|包|離さ|逃が|くわ|濡ら)|指に(絡|吸)|指へ|指先を離さ")
SKIN_NIPPLE = re.compile(r"(こちらの肌|重なった肌|肌どうし|素肌).{0,12}(乳首|乳輪|\{nipple\})|(乳首|乳輪|\{nipple\}).{0,12}(こちらの肌|こちらの素肌)")


def back_face_seen(body):
    """背を向けた体位では見えない真帆の顔を書いているか（v8.2.7）。"""
    if any(cue in body for cue in BACK_VISIBLE):
        return False
    return any(body[max(0, m.start() - 4):m.start()] != "こちらの" for m in BACK_FACE.finditer(body))


def audit_conditions(meaning, fields, body):
    """v8.2.7（精査 C-07・C-08・C-12・C-16・A-08）：本文の語から足す条件（grok の本文と Opus の本文の両方）。fields は when の JSON。"""
    add = []
    unset_facing = '"intimacy.facing"' not in fields and '"intimacy.position"' not in fields
    if unset_facing and back_face_seen(body) and not meaning.startswith("h_pos_"):
        add.append({"field": "intimacy.facing", "op": "ne", "value": "back"})
    if meaning.startswith("h_check.") and any(cue in body for cue in MOVING_CUES):
        add.append(MOVE_ACTIVE)
    if meaning == "h.sign.sensitive":
        if '"intimacy.inserted", "op": "eq", "value": false' in fields and GENITAL_CUES.search(body):
            add.append(GENITAL_ACTIVE)  # 胸・太ももに触れたときは、秘所の反応を書く本文を出さない
        if "動いて" in body or "動かして" in body:
            add.append(MOVE_ACTIVE)
    if meaning == "h.climax.maho" and '"intimacy.maho.climax_source"' not in fields and FINGER_CUES.search(body):
        add.append({"field": "intimacy.maho.climax_source", "op": "ne", "value": "mouth"})  # 口で達したときに指の本文を出さない
    if SKIN_NIPPLE.search(body) and '"actor.player.clothing.upper"' not in fields:
        add.append({"field": "actor.player.clothing.upper", "op": "eq", "value": "off"})  # こちらの上を着ているのに素肌どうし
    if meaning.startswith("h_pos_player_above.") and '"intimacy.inserted"' not in fields:
        add.append({"field": "intimacy.inserted", "op": "eq", "value": False})  # 入れたまま戻る本文は Opus（o13）
    return add
# v8.2.10：してもらう最中は向きが変わる（胸 maho_breasts・足 maho_feet。真帆の顔は見える）。顔の語のある本文に「向き＝向かい合う」だけを足すと、
# その最中に出なくなっていた（遊び回りで h_maho_breasts.continue が仮の本文に落ちた）。顔面騎乗・シックスナインの本文は、その向きで出る前提で書いたので足さない。
OWN_FACING = ((("h_maho_breasts", "h_extra_lick", "h_finish_breasts", "h_endure.breasts", "h_overflow.breasts"), ["face", "maho_breasts"]),
              (("h_maho_feet", "h_finish_feet", "h_endure.feet", "h_overflow.feet"), ["face", "maho_feet"]),
              (("h_maho_mouth", "h_stroke_head.mouth"), ["face", "maho_mouth"]),  # v8.2.13：口でしてもらう最中も（読み手の指摘 R-2）
              (("h_stroke_head.breasts",), ["face", "maho_breasts"]))  # v8.2.14：撫でる本文も（読み手の指摘 M-5）
OWN_FACING_SKIP = ("h_pos_face_sit", "h_face_lick", "h_pos_sixty_nine", "h_sixty_nine", "h_finish_sixty_nine", "h_overflow.sixty_nine", "h_endure.sixty_nine",
                   "h_lead_sixty_nine", "offer.h_lead.sixty_nine")
LYING_CUES = ("仰向け", "横たわ", "寝転", "天井")
RAISED_CUES = ("めくれ", "めくり", "たくし上")


def b2_conditions(text):
    """本文の語から足す条件（B2）。段階Bでない本文には足さない。position の条件がある本文には、服の条件（下着・めくれ）だけ足す（v8.1.1）。"""
    meaning = text["meaning"]
    if not meaning.startswith(("h_", "h.")):
        return []
    fields = json.dumps(text["when"], ensure_ascii=False)
    body = text["body"]
    if '"intimacy.position"' in fields:
        # 体位を決めた本文でも、服は B2 で脱がせられるようになった（v8.1.1：下着を脱がせた後に「ずらした下着」の本文が出ないように）。
        add = []
        if "下着" in body and '"actor.maho.clothing.lower"' not in fields:
            add.append({"field": "actor.maho.clothing.lower", "op": "ne", "value": "off"})
        if any(cue in body for cue in RAISED_CUES) and '"actor.maho.clothing.upper"' not in fields:
            add.append({"field": "actor.maho.clothing.upper", "op": "ne", "value": "off"})
        return add + audit_conditions(meaning, fields, body)
    add = []
    if any(cue in body for cue in FACE_CUES) and not meaning.startswith(OWN_FACING_SKIP) and not meaning.endswith((".face_sit", ".sixty_nine")):
        allowed = next((values for prefixes, values in OWN_FACING if meaning.startswith(prefixes)), None)
        add.append({"field": "intimacy.facing", "op": "in", "value": allowed} if allowed else {"field": "intimacy.facing", "op": "eq", "value": "face"})
        fields += '"intimacy.facing"'  # 顔の条件はもう足した
    if any(cue in body for cue in BED_CUES):
        add.append({"field": "intimacy.position", "op": "ne", "value": "standing_back"})
    if any(cue in body for cue in LYING_CUES):
        add.append({"not": {"field": "intimacy.position", "op": "in", "value": ["standing_back", "sitting_face"]}})
    if "下着" in body:
        add.append({"field": "actor.maho.clothing.lower", "op": "ne", "value": "off"})
    if any(cue in body for cue in RAISED_CUES):
        add.append({"field": "actor.maho.clothing.upper", "op": "ne", "value": "off"})
    return add + audit_conditions(meaning, fields, body)


def b2_patch(rows):
    patched = []
    for text in rows:
        base = text["when"]["all"] if set(text["when"]) == {"all"} else [text["when"]]
        add = [c for c in b2_conditions(text) if c not in base]  # 同じ条件を二重に足さない（v8.2.7）
        if add:
            text["when"] = {"all": base + add}
            patched.append(text["id"])
    return patched


def authored_texts():
    """Adopted grok texts: id and body from tools/stage_b/b_texts.json, meaning/when/group from the Opus jobs."""
    path = DATA / "b_texts.json"
    if not path.exists():
        return []
    jobs = {}
    for wave in (1, 2, 3):
        for job in read(ROOT / f"authoring/b_jobs/grok_wave_{wave}.json"):
            jobs[job["id"]] = job
    result, seen = [], set()
    for row in read(path):
        job = jobs[row["job_id"]]
        assert row["id"].startswith(job["id"] + ".v") and row["id"] not in seen, row["id"]
        seen.add(row["id"])
        slots = list(dict.fromkeys(TOKEN.findall(row["body"])))
        result.append({"id": row["id"], "meaning": job["_meaning"], "when": job["when"], "slots": slots,
                       "group": job["group"], "body": row["body"], "fallback": False})
    return result


def b2_authored_conditions(meaning, when, body, back_positions, style=None):
    """B2 の grok の本文に足す条件。job の state で向きを決めていない本文だけが対象（v8.1.1）。

    - 向かい合う語（FACE_CUES）があれば「背を向けていない」（facing ne back）。口での愛撫の最中（player_mouth・maho_mouth）は顔が見えるので残す。
      背を向けた体位へ移る本文（h_pos_<背を向けた体位>）は、その体位の state で書いて読む係が確かめたので足さない（額を壁へ、など）。
    - 「下着」があれば「下が脱いでいない」（lower ne off）。下着を脱がせる本文（h_strip_under）は、脱がせることそのものなので足さない。
    どちらも、いまの行動の体位・服の条件では必ず成り立つ（将来、行動の体位や服の条件を広げたときの守り）。
    - 「描写の濃さ：濃い」用の本文（style explicit）で、乳首・乳輪を書くものは「上の服をめくったか脱いだ」とき（v8.2.1。濃い版の job は上の服を決めていない）。
    """
    if not meaning.startswith(("h_", "h.")):
        return []
    fields = json.dumps(when, ensure_ascii=False)
    add = []
    back_move = meaning.split(".")[0] in {"h_pos_" + p for p in back_positions}
    if ('"intimacy.facing"' not in fields and '"intimacy.position"' not in fields and any(cue in body for cue in FACE_CUES) and not back_move):
        add.append({"field": "intimacy.facing", "op": "ne", "value": "back"})
        fields += '"intimacy.facing"'  # 顔の条件はもう足した
    if "下着" in body and '"actor.maho.clothing.lower"' not in fields and not meaning.startswith("h_strip_under"):
        add.append({"field": "actor.maho.clothing.lower", "op": "ne", "value": "off"})
    if style == "explicit" and re.search(r"\{nipple\}|乳輪|乳首", body) and '"actor.maho.clothing.upper"' not in fields:
        add.append({"field": "actor.maho.clothing.upper", "op": "in", "value": ["raised", "off"]})
    if back_move:
        fields += '"intimacy.facing"'  # 背を向けた体位へ移る本文は、その体位の state で書いた
    return add + audit_conditions(meaning, fields, body)


def b2_when_patches():
    """id ごとに足す条件（tools/stage_b/b2_when_patches.json。v8.2.1、別係の監査）。"""
    path = DATA / "b2_when_patches.json"
    result = {}
    if path.exists():
        for patch in read(path)["patches"]:
            for identity in patch["ids"]:
                result.setdefault(identity, []).extend(patch["add"])
    return result


def authored_b2_texts():
    """B2 の grok の本文（採用分）：id と body は tools/stage_b/b2_texts.json、meaning・when・group は Opus の job（authoring/b2_jobs）。まだなければ空。"""
    path = DATA / "b2_texts.json"
    if not path.exists():
        return []
    jobs = {}
    for wave_path in sorted((ROOT / "authoring/b2_jobs").glob("grok_b2_wave_*.json")):  # 第1〜3陣と補充（第4、v8.1.1）
        for job in read(wave_path):
            jobs[job["id"]] = job
    positions = read(DATA / "intimacy_009.json")["positions"]
    back_positions = {name for name, position in positions.items() if position["facing"] == "back"}
    patches = b2_when_patches()
    result, seen = [], set()
    for row in read(path):
        job = jobs[row["job_id"]]
        assert row["id"].startswith(job["id"] + ".v") and row["id"] not in seen, row["id"]
        seen.add(row["id"])
        when = job["when"]
        add = b2_authored_conditions(job["_meaning"], when, row["body"], back_positions, job.get("style"))
        add += [c for c in patches.get(row["id"], []) if c not in add]  # 同じ条件を二重に足さない（v8.2.7）
        if add:
            base = when["all"] if set(when) == {"all"} else [when]
            when = {"all": base + add}
        text = {"id": row["id"], "meaning": job["_meaning"], "when": when, "slots": list(dict.fromkeys(TOKEN.findall(row["body"]))),
                "group": job["group"], "body": row["body"], "fallback": False}
        if job.get("style"):
            text["style"] = job["style"]  # v8.2.0：「描写の濃さ：濃い」用の本文（x1. など）
        result.append(text)
    return result


# v8.2.7（精査 F-9）：限界のまま「一気に奥まで入れる」で果てる本文（h_overflow.insert_deep）は、入り口で果てたと書かない。
# v8.2.7〜v8.2.17 は、ゆっくり入れて果てる本文のうち ENTRANCE の語がないものを写して使っていた（id の頭に "deep."）。
# v8.2.18 で grok の専用の本文（第13陣 p13・x12）が入ったので、写しをやめた。ENTRANCE は試験（tests/test_v827.py）が使う。
ENTRANCE = re.compile(r"入り口|亀頭を押|陰唇を(割|押し分|開)|陰唇のあいだ|半分も入らない|沈めきる前|先端が入り口|押し進めた拍子|割った拍子|先端を咥え")


def life_changes():
    """Opus-written life texts for 009 (spec 9.6 and sleep lines) and rewrites of inherited near-duplicate drafts."""
    added = read(DATA / "life_texts.json") if (DATA / "life_texts.json").exists() else []
    edits = read(DATA / "life_edits.json") if (DATA / "life_edits.json").exists() else {}
    rows = [{"id": r["id"], "meaning": r["meaning"], "when": r["when"], "slots": [], "group": r["group"], "body": r["body"], "fallback": False} for r in added]
    return rows, edits


def text_fix_conditions():
    """v8.2.25：text_fixes_v8225.json の、id ごとに足す条件（検査・試験が、本文の when を組み立て直すときに使う）と、直した本文。"""
    path = DATA / "text_fixes_v8225.json"
    when, bodies, drops = {}, {}, {}
    if path.exists():
        fixes = read(path)
        for patch in fixes["when"]:
            for identity in patch["ids"]:
                when.setdefault(identity, []).extend(c for c in patch["add"] if c not in when.get(identity, []))
        bodies = {edit["id"]: edit["body"] for edit in fixes["body"]}
        for patch in fixes.get("drop", []):
            for identity in patch["ids"]:
                drops.setdefault(identity, []).extend(patch["remove"])
    return when, bodies, drops


def apply_text_fixes(texts, fixes, done):
    """v8.2.25（精査）：tools/stage_b/text_fixes_v8225.json の、id ごとの条件の足しと本文の直し。done は済んだ (種類, id) の集合（二度足さない）。
    短い1行を組み立てる前に一度（もとの本文へ足すと、切り出しにも写る）、組み立てたあとにもう一度（短い1行そのものの id）。"""
    by_id = {t["id"]: t for t in texts}
    for patch in fixes["when"]:
        for identity in patch["ids"]:
            text = by_id.get(identity)
            if text is None or ("when", identity, json.dumps(patch["add"])) in done:
                continue
            base = text["when"]["all"] if set(text["when"]) == {"all"} else [text["when"]]
            text["when"] = {"all": base + [c for c in patch["add"] if c not in base]}
            done.add(("when", identity, json.dumps(patch["add"])))
    for patch in fixes.get("drop", []):
        for identity in patch["ids"]:
            text = by_id.get(identity)
            if text is None or ("drop", identity) in done:
                continue
            base = text["when"]["all"] if set(text["when"]) == {"all"} else [text["when"]]
            assert all(c in base for c in patch["remove"]), identity
            text["when"] = {"all": [c for c in base if c not in patch["remove"]]}
            done.add(("drop", identity))
    for edit in fixes["body"]:
        text = by_id.get(edit["id"])
        if text is None or ("body", edit["id"]) in done:
            continue
        assert text["body"] == edit["orig"], edit["id"]
        text["body"] = edit["body"]
        text["slots"] = list(dict.fromkeys(TOKEN.findall(edit["body"])))
        done.add(("body", edit["id"]))


def short_texts(texts, intimacy, registered=()):
    """続けているあいだの短い1行。意味は行為ごとに1つ（<行為>.continue_short。さらに続ける手も同じ1行から選ぶ）。
    - 切り出し（tools/stage_b/short_texts.json、v8.2.20〜23）：長い本文から、重ならない部分を2本ずつ（cut 1 → sh.<もと>、cut 2 → sh2.<もと>）。
      条件（when）と濃さ（style）は、組み立てたあとのもとの本文から写す。長い本文は、続けている手には出さない（long_every 0）ので、同じ言葉を2度読ませない。
    - 新しく書いた1行（tools/stage_b/short_texts_v2.json、v8.2.23）：慣れ・体位のまとまり・高まりの前半／後半の条件を行ごとに持つ。
    group は意味と形（台詞＋一文・台詞だけ・地の文だけ・声＋一文・声だけ）ごとにして、同じ形が続かないようにする。
    - v8.2.23：声だけの行（形 v、v.*）。切り出しの熱さの札（heat：early＝高まりの前半だけ、late＝後半だけ、null＝どちらでも）は、
      HEAT_BASIS の高まり（真帆、またはしてもらう行為ではこちら）の条件にして when へ足す（山場に落ち着いた行が出ないように）。
    - v8.2.23：台詞・声と地の文のあいだで改行する（1手を1〜2行で読ませる）。"""
    by_id = {t["id"]: t for t in texts}
    rows, meanings = [], set()
    def add(identity, meaning, when, body, form, style):
        assert form in ("s", "d", "a", "b", "v"), identity
        body = LINE_BREAK_AFTER.sub("」\n", LINE_BREAK_BEFORE.sub("\n「", body)) if form in ("s", "b") else body
        text = {"id": identity, "meaning": meaning, "when": json.loads(json.dumps(when)), "slots": list(dict.fromkeys(TOKEN.findall(body))),
                "group": "sh." + meaning + "." + form, "body": body, "fallback": False}
        if style:
            text["style"] = style
        rows.append(text)
        meanings.add(meaning)
    for row in read(DATA / "short_texts.json")["texts"]:
        source = by_id[row["source"]]
        assert not source["fallback"] and source["meaning"].endswith((".continue", ".settled")), row["source"]
        assert set(TOKEN.findall(row["body"])) <= set(source["slots"]), row["source"]
        prefix = "sh." if row.get("cut", 1) == 1 else "sh2."
        stem = source["meaning"].rsplit(".", 1)[0]
        when = source["when"]
        if row.get("heat"):
            field, values = HEAT_BASIS["player" if stem.startswith(HEAT_PLAYER) else "maho"]
            heat = {"field": field, "op": "in", "value": values[row["heat"]]}
            if heat not in when["all"]:  # v8.2.27：もとの本文にもう同じ条件があれば重ねない（精査 D-5 の直しで、もとの本文に足した）
                when = {"all": when["all"] + [heat]}
        add(prefix + source["id"], stem + ".continue_short", when, row["body"], row["form"], source.get("style"))
    back_positions = {name for name, position in intimacy["positions"].items() if position["facing"] == "back"}
    for row in read(DATA / "short_texts_v2.json")["texts"]:
        assert row["meaning"].endswith(".continue_short"), row["id"]
        # v8.2.23：新しく書いた行にも、B2 の grok の本文と同じく本文の語から条件を足す（下着→下を脱いでいない、向かい合う語→背を向けていない、など）
        when = row["when"]
        extra = [c for c in b2_authored_conditions(row["meaning"], when, row["body"], back_positions, row.get("style")) if c not in when["all"]]
        if extra:
            when = {"all": when["all"] + extra}
        add(row["id"], row["meaning"], when, row["body"], row["form"], row.get("style"))
    for meaning in sorted(meanings - set(registered)):  # 組み合わせの短い1行（v8.2.21）は、意味と基本の本文を登録済み
        stem = meaning.split(".")[0]
        # 速さ・追加・組み合わせの意味（h_maho_mouth_fast など）は、名前がいちばん長く重なる行為の名前で
        owner = max((key for key in intimacy["actions"] if stem == key or stem.startswith(key + "_")), key=len, default=None)
        action = intimacy["actions"][owner] if owner else {"label": "続ける"}
        rows.append({"id": meaning + ".base", "meaning": meaning, "when": {"all": []}, "slots": [], "group": meaning + ".base",
                     "body": "（" + action.get("continue_label", action["label"]) + "）", "fallback": True})
    return rows


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--replace-unpublished", action="store_true")
    parser.add_argument("--target", type=Path, default=TARGET)
    parser.add_argument("--verify", action="store_true", help="確定済みの 009 を別の場所に作って、同じかを比べる（009 は書き換えない）")
    args = parser.parse_args()
    target = args.target.resolve()
    assert target.is_relative_to(ROOT.resolve())
    if args.verify:
        published = target
        if VERIFY_ROOT.exists():
            shutil.rmtree(VERIFY_ROOT)
        target = VERIFY_ROOT / published.name
        try:
            build(target, args)
            same = {p.name: bytes_digest(p.read_bytes()) for p in target.iterdir() if p.is_file()} == {p.name: bytes_digest(p.read_bytes()) for p in published.iterdir() if p.is_file()}
        finally:
            shutil.rmtree(VERIFY_ROOT, ignore_errors=True)
        print("verify", published.name, "identical" if same else "DIFFERENT")
        raise SystemExit(0 if same else 1)
    if target.name in PUBLISHED:
        raise SystemExit("確定（公開）済みの release 003〜009 は作り直さない。009 と同じかは --verify で確かめる。次の版は --target content/releases/interaction_010 で作る。")
    if target.exists():
        if not args.replace_unpublished:
            raise SystemExit("対象が既にある。未公開版だけ --replace-unpublished で再生成できる。")
        shutil.rmtree(target)
    build(target, args)


def merge_into(base, patch):
    """v8.3.3：010 の層の決まりを足す（dict は中へ、それ以外は置き換え）。"""
    for key, value in patch.items():
        if key == "_note":
            continue
        if isinstance(value, dict) and isinstance(base.get(key), dict):
            merge_into(base[key], value)
        else:
            base[key] = value


def build(target, args):
    Pack(SOURCE)
    shutil.copytree(SOURCE, target)
    intimacy = read(DATA / "intimacy_009.json")
    # v8.3.3：010 からの直し（確定済みの 009 は変えない。009 の --verify はこの層を読まない）
    layer = read(LAYER_010) if target.name != "interaction_009" else None
    if layer:
        merge_into(intimacy, layer["intimacy"])
    catalog = read(target / "catalog.json")
    catalog["resources"].update({name: 1 for name in ("player.hips", "maho.chest", "maho.lower")})
    for term in intimacy["settings"]["terms"]:
        catalog["slots"][term] = {"source": "settings.terms." + term}
    catalog["memory_kinds"].append("intimacy")
    catalog["memory_specs"]["intimacy"] = {"facts": [], "summary": {"result": {"type": "enum", "values": ["satisfied", "unsatisfied"]}}}
    catalog["offers"].update({name: {"plan": {"op": "idle"}} for name in ("intimacy_invite", "hold_back", "h_lead_straddle", "h_lead_takein", "h_lead_sixty_nine")})
    # B2：自分で高めているときの真帆の申し出、いつもの触れ合いから深めたときの誘い
    catalog["offers"].update({name: {"plan": {"op": "idle"}} for name in ["h_help_hand", "h_help_mouth", "h_help_breasts", "h_help_feet"] + ["gate_invite_" + key for key in intimacy["b2"]["gate"]["touches"]]})
    catalog["goals"]["intimacy"] = {"priority": intimacy["invite"]["priority"], "when": {"field": "intimacy.invite_ready", "op": "eq", "value": True}, "offer": "intimacy_invite", "group": "intimacy", "reason": "desire"}
    if layer and layer.get("catalog_010"):
        # v8.5.11（010）：島の町の場所（喫茶店・売店）と活動（喫茶店でお茶・売店を見て回る・釣り）、食事の場所に喫茶店、活動の思い出の種類
        add = {k: v for k, v in layer["catalog_010"].items() if k != "_note"}
        assert not set(add["locations"]) & set(catalog["locations"]) and not set(add["activities"]) & set(catalog["activities"])
        catalog["locations"].update(add["locations"])
        catalog["activities"].update(add["activities"])
        for key, places in add["activity_locations"].items():
            catalog["activities"][key]["locations"] += [p for p in places if p not in catalog["activities"][key]["locations"]]
        for kind in add["activities"]:
            catalog["memory_kinds"].append(kind)
            catalog["memory_specs"][kind] = {"facts": [], "summary": {}}
    if layer and layer.get("goals_when"):
        # v8.4.3（010）：真帆の誘いのもと（goals）に条件を足す（両手をつないでいるのに「手、つないでもいい？」と誘っていた）
        for kind, extra in layer["goals_when"].items():
            if kind != "_note":
                catalog["goals"][kind]["when"] = {"all": [catalog["goals"][kind]["when"]] + extra}
    dump(target / "catalog.json", catalog)

    actions = read(target / "actions.json") + read(DATA / "actions_009追加.json") + (layer["actions"] if layer else [])
    if layer:
        # v8.4.0：010 で足した触れ合いと手や体がぶつかる行動は、選べばその触れ合いを終える（replaces に足す）
        extra = {key: value for key, value in layer.get("replaces_add", {}).items() if key != "_note"}
        assert set(extra) <= {row["id"] for row in actions}, sorted(set(extra) - {row["id"] for row in actions})
        for row in actions:
            row["replaces"] = row["replaces"] + [key for key in extra.get(row["id"], []) if key not in row["replaces"]]
    # v8.2.14（読み手の指摘 M-1・S-16）：こちらの「動く」を入れ替える行動は、「真帆に動いてもらう」も入れ替える（資源がぶつかって選べなくならないように）
    lacking = [row["id"] for row in actions if "h_move_normal" in row.get("replaces", []) and row["id"] != "h_maho_move" and "h_maho_move" not in row["replaces"]]
    assert not lacking, ("h_maho_move を replaces に足す", lacking)
    tuning_meanings = read(DATA / "life_tuning_009.json")["meanings"]
    meanings = sorted(read(target / "meanings.json") + read(DATA / "meanings_009追加.json") + list(tuning_meanings) + (layer["meanings"] if layer else []))
    dump(target / "actions.json", actions)
    dump(target / "meanings.json", meanings)
    progression = read(target / PROGRESSION)
    patch = read(DATA / "life_tuning_009.json")["progression"]
    # B2：いつもの触れ合いに足した行動を、触れる行動（親密度・欲求）に入れる
    progression["affinity"]["touch_actions"] += [key for key in patch["touch_start"] if key not in progression["affinity"]["touch_actions"]]
    progression["desire"]["touch_start"].update(patch["touch_start"])
    if layer and layer.get("progression_touch"):
        # v8.4.0：010 で足した暮らしの触れ合い（両手をつなぐ）も、触れる行動（親密度・欲求）に入れる
        progression["affinity"]["touch_actions"] += [key for key in layer["progression_touch"] if key not in progression["affinity"]["touch_actions"]]
        progression["desire"]["touch_start"].update(layer["progression_touch"])
    dump(target / PROGRESSION, progression)
    life = read(target / LIFE)
    life["offers"]["once_per_day"].append("intimacy")
    if tuning_offers := read(DATA / "life_tuning_009.json").get("offers_not_in_rain"):
        life["offers"]["not_in_rain"] = tuning_offers  # v8.2.26：雨の日には誘わない活動
    tuning = read(DATA / "life_tuning_009.json")
    # v8.0.5：いつもの時間の行動に所要分、食事中は触れ合いを止める、続ける本文の台詞の間隔（試運転の指摘2・3、監査 F-18）。
    life["actions"] = tuning["actions"]
    if layer and layer.get("life_hands_free"):
        # v8.4.2（010）：始めるときに続いている触れ合いを終える活動を足す（お茶・読書。両手がふさがる）
        life["actions"] = dict(life["actions"], hands_free=life["actions"]["hands_free"] + [k for k in layer["life_hands_free"]["add"] if k not in life["actions"]["hands_free"]])
    if layer and layer.get("life_contact_stops"):
        # v8.4.3（010）：始めるときに、決めた触れ合いだけを終える活動（散歩：両手をつないだままでは歩けない）
        life["actions"] = dict(life["actions"], contact_stops={k: v for k, v in layer["life_contact_stops"].items() if k != "_note"})
    life["lunch"] = tuning["lunch"]
    life["meals"] = tuning["meals"]  # v8.1.0：朝食・夕食を自動で（3回目の試運転の指摘4）
    life["bath"] = {k: v for k, v in tuning["bath"].items() if k != "_note"}  # v8.2.0：風呂（3回目の試運転の指摘4）
    life["speech"]["spacing"].update(tuning["spacing"])
    if layer and layer.get("life_010"):
        life.update({k: v for k, v in layer["life_010"].items() if k != "_note"})  # v8.5.11（010）：島の町・釣り・休日の昼の支度
    dump(target / LIFE, life)
    scenes = read(target / "scenes.json")
    for scene in scenes:
        micro = tuning["scene_micro"].get(scene["id"])
        if micro is not None:
            scene["revision"] += 1
            for node in scene["nodes"]:
                if node["micro"]:
                    node["micro"] = micro
        requires = tuning.get("scene_requires", {}).get(scene["id"])
        if requires is not None:  # v8.2.25（精査 B-12）：話を始める条件の足し
            scene["revision"] += 1
            base = scene["requires"]["all"] if set(scene["requires"]) == {"all"} else [scene["requires"]]
            scene["requires"] = {"all": base + requires}
        labels = tuning["scene_labels"].get(scene["id"])
        if labels is not None:  # v8.2.7（精査 F-8）：選択肢の名前
            scene["revision"] += 1
            for node in scene["nodes"]:
                for choice in node.get("choices", []):
                    if choice["id"] in labels:
                        choice["label"] = labels[choice["id"]]
    if layer and layer.get("scenes_010"):
        # v8.5.11（010）：活動の場面を足し（喫茶店でお茶・売店を見て回る・釣り）、食事の場面の場所に喫茶店を足す
        patch = layer["scenes_010"]
        assert not {x["id"] for x in patch["add"]} & {x["id"] for x in scenes}
        scenes.extend(patch["add"])
        for scene in scenes:
            places = patch["locations"].get(scene["id"])
            if places is None:
                continue
            scene["revision"] += 1
            for key in ("requires", "resume"):
                rows = [c for c in scene[key]["all"] if c.get("field") == "actor.player.location"]
                assert len(rows) == 1, (scene["id"], key)
                rows[0]["value"] = rows[0]["value"] + [p for p in places if p not in rows[0]["value"]]
    dump(target / "scenes.json", scenes)
    dump(target / INTIMACY, intimacy)

    texts = read(target / "texts.json")
    event_fallback = fallback_events()
    b2_fallback = read(DATA / "b2_fallback.json")["texts"]
    for meaning in read(DATA / "meanings_009追加.json"):
        if meaning in b2_fallback:
            body = b2_fallback[meaning]
        elif meaning in event_fallback:
            body = event_fallback[meaning]
        else:
            action_id, phase = meaning.rsplit(".", 1)
            action = intimacy["actions"][action_id]
            label = action.get("continue_label", action["label"]) if phase in ("continue", "settled") else action["label"]
            body = "（" + label + "）"
        texts.append({"id": meaning + ".base", "meaning": meaning, "when": {"all": []}, "slots": [], "group": meaning + ".base", "body": body, "fallback": True})
    for meaning, body in tuning_meanings.items():
        texts.append({"id": meaning + ".base", "meaning": meaning, "when": {"all": []}, "slots": [], "group": meaning + ".base", "body": body, "fallback": True})
    for meaning in layer["meanings"] if layer else ():
        texts.append({"id": meaning + ".base", "meaning": meaning, "when": {"all": []}, "slots": [], "group": meaning + ".base", "body": layer["fallback"][meaning], "fallback": True})
    life_rows, life_edits = life_changes()
    opus = read(DATA / "opus_texts_009.json")
    by_id = {t["id"]: t for t in texts}
    for identity, edit in life_edits.items():
        assert by_id[identity]["body"] == edit["orig"], identity  # 008 から受け継いだ本文だけを直す（v8.2.19：受け継いだ基本の本文 .base も直せる）
        by_id[identity]["body"] = edit["body"]
    texts.extend(life_rows)
    authored = authored_texts()
    for patch in opus["when_patches"]:
        hits = [t for t in authored if t["meaning"] == patch["meaning"]]
        assert hits, patch["meaning"]
        for t in hits:
            assert set(t["when"]) == {"all"}, t["id"]
            t["when"] = {"all": t["when"]["all"] + patch["add"]}
    opus_rows = [{"id": r["id"], "meaning": r["meaning"], "when": r["when"], "slots": list(dict.fromkeys(TOKEN.findall(r["body"]))), "group": r["group"], "body": r["body"], "fallback": False} for r in opus["texts"]]
    b2_opus = [{"id": r["id"], "meaning": r["meaning"], "when": r["when"], "slots": list(dict.fromkeys(TOKEN.findall(r["body"]))), "group": r["group"], "body": r["body"], "fallback": False}
               for r in read(DATA / "b2_opus_texts.json")["texts"]]
    b2_patched = b2_patch(authored + opus_rows + b2_opus)
    b2_authored = authored_b2_texts()  # B2 の本文は job の state で向き・服を指定して書いた。足す条件は b2_authored_conditions だけ（v8.1.1）
    texts.extend(authored)
    texts.extend(opus_rows)
    texts.extend(b2_opus)
    texts.extend(b2_authored)
    # v8.2.21：胸を吸いながら手でしてもらう・胸に口づける速さ・余韻の胸（Opus。濃い本文は style を持つ）
    v8221 = [dict({"id": r["id"], "meaning": r["meaning"], "when": r["when"], "slots": list(dict.fromkeys(TOKEN.findall(r["body"]))), "group": r["group"], "body": r["body"], "fallback": False},
                  **({"style": r["style"]} if r.get("style") else {})) for name in ("opus_texts_v8221.json", "opus_texts_v8222.json", "opus_texts_v8224.json", "opus_texts_v8225.json", "opus_texts_v8226.json", "opus_texts_v8229.json", "opus_texts_v8230.json", "opus_texts_v8231.json", "opus_texts_v8232.json", "opus_texts_v8233.json", "opus_texts_v8234.json", "opus_texts_v8235.json", "texts_k1_v8236.json") for r in read(DATA / name)["texts"]]
    # v8.2.23：続けている手の短い1行（組み合わせの短い1行・頭を撫でる一行も）は、台詞・声と地の文のあいだで改行する
    for text in v8221:
        if (text["meaning"].endswith(".continue_short") or text["meaning"].startswith("h.pat.")) and not re.fullmatch(r"「[^「」]*」", text["body"]):
            text["body"] = LINE_BREAK_AFTER.sub("」\n", LINE_BREAK_BEFORE.sub("\n「", text["body"]))
    texts.extend(v8221)
    layer_rows = [dict({"id": r["id"], "meaning": r["meaning"], "when": r["when"], "slots": list(dict.fromkeys(TOKEN.findall(r["body"]))), "group": r["group"], "body": r["body"], "fallback": False},
                       **({"style": r["style"]} if r.get("style") else {})) for r in (layer["texts"] if layer else [])]
    texts.extend(layer_rows)  # v8.3.3：010 の新しい本文
    fixes = read(DATA / "text_fixes_v8225.json")  # v8.2.25（精査）：条件の足しと本文の直し
    fixes_010 = layer["fixes"] if layer else {"when": [], "body": [], "drop": []}  # v8.3.3：010 だけの直し（009 の本文は変えない）
    fixed, fixed_010 = set(), set()
    apply_text_fixes(texts, fixes, fixed)
    short_rows = short_texts(texts, intimacy, meanings)
    texts.extend(short_rows)
    apply_text_fixes(texts, fixes, fixed)
    # v8.3.3：010 の直しは、短い1行を組み立てたあとに一度だけ当てる（短い1行は id を挙げて直す。もとの本文の直しを切り出しへ写さない）
    apply_text_fixes(texts, fixes_010, fixed_010)
    for done, source in ((fixed, fixes), (fixed_010, fixes_010)):
        expected = ({("when", i, json.dumps(p["add"])) for p in source["when"] for i in p["ids"]} | {("body", e["id"]) for e in source["body"]}
                    | {("drop", i) for p in source.get("drop", []) for i in p["ids"]})
        assert done == expected, sorted(expected - done)
    # v8.3.9：010 だけ、言い換えでは不自然なままになる本文を消す（release_010.json の fixes.remove。009 には無い）
    removed_010 = [i for p in fixes_010.get("remove", []) for i in p["ids"]]
    present = {t["id"]: t for t in texts}
    assert len(set(removed_010)) == len(removed_010) and set(removed_010) <= set(present), sorted(set(removed_010) - set(present))
    assert not any(present[i]["fallback"] for i in removed_010), "基本の本文は消さない"
    texts[:] = [t for t in texts if t["id"] not in set(removed_010)]
    short_meanings = sorted({t["meaning"] for t in short_rows if not t["fallback"]} - set(meanings))
    meanings = sorted(meanings + short_meanings)
    dump(target / "meanings.json", meanings)
    dump(target / "texts.json", texts)
    names = FILES + (PROGRESSION, LIFE, INTIMACY)
    control = {"catalog": catalog, "actions": actions, "progression": read(target / PROGRESSION), "life": life, "intimacy": intimacy}
    dump(target / "release.json", {"id": target.name, "rules_version": "nagishima-2.4", "files": {name: bytes_digest((target / name).read_bytes()) for name in names}, "control_sha256": digest(control)})
    dump(target / "rules_provenance.json", {"source_release": "interaction_008", "rules_version": "nagishima-2.4",
        "provisional_texts": {"author": "Claude Opus 5.5", "reviewed": False, "note": "仮本文・検品なし。段階Bの原稿で補う。", "text_ids": [m + ".base" for m in read(DATA / "meanings_009追加.json")]},
        "authored_texts": {"author": "grok（プロンプト v2.14・v2.15）", "reviewer": "Claude Opus 5.5（機械検査と判定。記録は authoring/b_results/）", "jobs": "authoring/b_jobs/grok_wave_1〜3.json", "text_ids": [t["id"] for t in authored]},
        "life_texts": {"author": "Claude Opus 5.5（仕様 9.6 の生活の本文と、眠り・目覚めの一言）", "data": "tools/stage_b/life_texts.json", "text_ids": [t["id"] for t in life_rows]},
        "opus_texts": {"author": "Claude Opus 5.5（真帆が達した直後の「激しく」を止める本文と、grok の本文の条件の足し）", "data": "tools/stage_b/opus_texts_009.json", "text_ids": [t["id"] for t in opus_rows], "patched_meanings": [p["meaning"] for p in opus["when_patches"]]},
        "life_tuning": {"author": "Claude Opus 5.5（v8.0.5：行動の所要分、食事中の触れ合い、続ける本文の台詞の間隔。B2：触れる行動に足した行動と欲求）", "data": "tools/stage_b/life_tuning_009.json"},
        "b2": {"author": "Claude Opus 5.5（段階Bの2版目：体位・行動・いつもの触れ合いの宣言、基本の本文、恋人の触れ合いと誘い・申し出を断ったときの本文、これまでの本文の向き・場所・服の条件）",
               "data": ["tools/stage_b/intimacy_009.json", "tools/stage_b/actions_009追加.json", "tools/stage_b/meanings_009追加.json", "tools/stage_b/b2_fallback.json", "tools/stage_b/b2_opus_texts.json"],
               "opus_text_ids": [t["id"] for t in b2_opus], "conditioned_text_ids": b2_patched},
        "b2_authored_texts": {"author": "grok（プロンプト v3.0）", "reviewer": "Claude Opus 5.5", "jobs": "authoring/b2_jobs/grok_b2_wave_1〜3.json", "data": "tools/stage_b/b2_texts.json", "text_ids": [t["id"] for t in b2_authored]},
        "life_edits": {"author": "Claude Opus 5.5（008 から受け継いだ本文のうち、基本の本文とほぼ同じ下書きの書き直し）", "data": "tools/stage_b/life_edits.json", "text_ids": sorted(life_edits)},
        "opus_texts_v8221": {"author": "Claude Opus 5.5（v8.2.21：胸を吸いながら手でしてもらう・胸に口づける速さ・余韻の胸。v8.2.22：頭を撫でる一行・脚を絡める。v8.2.24：物足りなさの合図の足しと焦れた合図。v8.2.25：精査の直しの本文。v8.2.29：胸の左右・締め切り・昼に終えたあと。v8.2.30：通し確かめの直し。v8.2.31：エッチシーンの確かめの直し。v8.2.32〜v8.2.35：エッチ場面の確かめ（別の Claude）の直し）", "data": ["tools/stage_b/opus_texts_v8221.json", "tools/stage_b/opus_texts_v8222.json", "tools/stage_b/opus_texts_v8224.json", "tools/stage_b/opus_texts_v8225.json", "tools/stage_b/opus_texts_v8226.json", "tools/stage_b/opus_texts_v8229.json", "tools/stage_b/opus_texts_v8230.json", "tools/stage_b/opus_texts_v8231.json", "tools/stage_b/opus_texts_v8232.json", "tools/stage_b/opus_texts_v8233.json", "tools/stage_b/opus_texts_v8234.json", "tools/stage_b/opus_texts_v8235.json"], "text_ids": [t["id"] for t in v8221 if not t["id"].startswith("k1.")]},
        "k1_texts_v8236": {"author": "別の Claude（エッチ場面の確かめ役。v8.2.36：慣れた回で同じ本文に気づきやすい18か所の足し）", "reviewer": "Claude Opus 5.5（取り込みで3本を直した。text_fixes_v8225.json の v8.2.36）", "data": "tools/stage_b/texts_k1_v8236.json", "text_ids": [t["id"] for t in v8221 if t["id"].startswith("k1.")]},
        "text_fixes_v8225": {"author": "Claude Opus 5.5（v8.2.25：精査の直し。id ごとの条件の足しと本文の直し）", "data": "tools/stage_b/text_fixes_v8225.json", "when_ids": sorted({i for p in fixes["when"] for i in p["ids"]}), "body_ids": [e["id"] for e in fixes["body"]]},
        "short_texts": {"author": "Claude Opus 5.5（v8.2.23：続けているあいだの短い1行。新しく書き起こし、別の Opus が読み直した）", "data": ["tools/stage_b/short_texts.json", "tools/stage_b/short_texts_v2.json"], "text_ids": [t["id"] for t in short_rows]},
        **({"release_010": {"author": "Claude（v8.3.3：エッチ場面の直し A〜F。010 だけ）", "data": "tools/stage_b/release_010.json", "text_ids": [t["id"] for t in layer_rows],
                            "when_ids": sorted({i for p in fixes_010["when"] for i in p["ids"]}), "body_ids": [e["id"] for e in fixes_010["body"]], "removed_ids": removed_010}} if layer else {})})
    pack = Pack(target)
    print(pack.id, len(pack.actions), len(pack.meanings), len(pack.texts), pack.control_hash)
    return pack


if __name__ == "__main__":
    main()
